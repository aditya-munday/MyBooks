package G1;

import java.io.Serializable;
import java.util.List;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* loaded from: classes.dex */
public final class a implements Serializable {
    public final List o;

    /* renamed from: p, reason: collision with root package name */
    public final Boolean f957p;

    /* renamed from: q, reason: collision with root package name */
    public final String f958q;

    /* renamed from: r, reason: collision with root package name */
    public final List f959r;

    public a(List list, Boolean bool, String str, List list2) {
        this.o = list;
        this.f957p = bool;
        this.f958q = str;
        this.f959r = list2;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj != null && a.class == obj.getClass()) {
            a aVar = (a) obj;
            List list = aVar.f959r;
            String str = aVar.f958q;
            Boolean bool = aVar.f957p;
            List list2 = aVar.o;
            List list3 = this.o;
            if (list3 == null ? list2 != null : !list3.equals(list2)) {
                return false;
            }
            Boolean bool2 = this.f957p;
            if (bool2 == null ? bool != null : !bool2.equals(bool)) {
                return false;
            }
            String str2 = this.f958q;
            if (str2 == null ? str != null : !str2.equals(str)) {
                return false;
            }
            List list4 = this.f959r;
            if (list4 != null) {
                return list4.equals(list);
            }
            if (list == null) {
                return true;
            }
        }
        return false;
    }

    public final int hashCode() {
        int i6;
        int i7;
        int i8;
        int i9 = 0;
        List list = this.o;
        if (list != null) {
            i6 = list.hashCode();
        } else {
            i6 = 0;
        }
        int i10 = i6 * 31;
        Boolean bool = this.f957p;
        if (bool != null) {
            i7 = bool.hashCode();
        } else {
            i7 = 0;
        }
        int i11 = (i10 + i7) * 31;
        String str = this.f958q;
        if (str != null) {
            i8 = str.hashCode();
        } else {
            i8 = 0;
        }
        int i12 = (i11 + i8) * 31;
        List list2 = this.f959r;
        if (list2 != null) {
            i9 = list2.hashCode();
        }
        return i12 + i9;
    }
}
