package s;

import com.shockwave.pdfium.R;

/* renamed from: s.a, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public abstract class AbstractC0742a {

    /* renamed from: a, reason: collision with root package name */
    public static final int[] f9353a = {R.attr.fontProviderAuthority, R.attr.fontProviderCerts, R.attr.fontProviderFallbackQuery, R.attr.fontProviderFetchStrategy, R.attr.fontProviderFetchTimeout, R.attr.fontProviderPackage, R.attr.fontProviderQuery, R.attr.fontProviderSystemFontFamily};

    /* renamed from: b, reason: collision with root package name */
    public static final int[] f9354b = {android.R.attr.font, android.R.attr.fontWeight, android.R.attr.fontStyle, android.R.attr.ttcIndex, android.R.attr.fontVariationSettings, R.attr.font, R.attr.fontStyle, R.attr.fontVariationSettings, R.attr.fontWeight, R.attr.ttcIndex};

    /* renamed from: c, reason: collision with root package name */
    public static final int[] f9355c = {R.attr.fontProviderQuery, R.attr.fontProviderSystemFontFamily, R.attr.fontVariationSettings};
}
