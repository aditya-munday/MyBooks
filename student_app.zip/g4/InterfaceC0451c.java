package g4;

import D.C0044i;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* renamed from: g4.c, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public interface InterfaceC0451c {
    C0044i a(C0044i c0044i);
}
