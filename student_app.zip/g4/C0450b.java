package g4;

import D.C0044i;
import java.util.ArrayList;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* renamed from: g4.b, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0450b implements InterfaceC0451c {

    /* renamed from: a, reason: collision with root package name */
    public final ArrayList f6794a = new ArrayList();

    @Override // g4.InterfaceC0451c
    public final C0044i a(C0044i c0044i) {
        ArrayList arrayList = this.f6794a;
        int size = arrayList.size();
        int i6 = 0;
        while (i6 < size) {
            Object obj = arrayList.get(i6);
            i6++;
            c0044i = ((InterfaceC0451c) obj).a(c0044i);
        }
        return c0044i;
    }
}
