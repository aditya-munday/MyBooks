package g4;

import D.C0044i;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* renamed from: g4.a, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0449a implements InterfaceC0451c {

    /* renamed from: a, reason: collision with root package name */
    public final int f6792a;

    /* renamed from: b, reason: collision with root package name */
    public final int f6793b;

    public C0449a(int i6) {
        this.f6792a = i6;
        this.f6793b = Integer.MAX_VALUE;
    }

    @Override // g4.InterfaceC0451c
    public final C0044i a(C0044i c0044i) {
        int i6 = c0044i.f570c;
        int i7 = c0044i.f569b;
        int i8 = this.f6793b;
        int i9 = this.f6792a;
        if (i6 <= i9 && i7 <= i8) {
            return c0044i;
        }
        float f6 = i6;
        float f7 = i9;
        float f8 = f6 / f7;
        float f9 = i7;
        float f10 = i8;
        float f11 = f6 / f9;
        if (f9 / f10 >= f8) {
            i9 = (int) (f10 * f11);
        } else {
            i8 = (int) (f7 / f11);
        }
        if (i9 % 2 != 0) {
            i9--;
        }
        if (i8 % 2 != 0) {
            i8--;
        }
        return new C0044i(i9, i8);
    }

    public C0449a(int i6, int i7) {
        this.f6792a = i6;
        this.f6793b = i7;
    }
}
