package defpackage;

import M4.u;
import M4.v;
import Z4.d;
import Z4.k;
import Z4.m;
import Z4.n;
import Z4.o;
import Z4.q;
import android.support.v4.media.session.a;
import c5.EnumC0327P;
import c5.EnumC0347k;
import c5.EnumC0356t;
import c5.EnumC0359w;
import c5.EnumC0360x;
import java.nio.ByteBuffer;
import java.util.List;
import java.util.Map;
import q5.h;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* loaded from: classes.dex */
public class g extends v {

    /* renamed from: d, reason: collision with root package name */
    public final /* synthetic */ int f6587d;

    public /* synthetic */ g(int i6) {
        this.f6587d = i6;
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r2v23, types: [Z4.k[]] */
    /* JADX WARN: Type inference failed for: r2v25, types: [Z4.m[]] */
    /* JADX WARN: Type inference failed for: r6v1, types: [Z4.k] */
    /* JADX WARN: Type inference failed for: r6v2 */
    /* JADX WARN: Type inference failed for: r6v3, types: [Z4.m] */
    @Override // M4.v
    public Object f(byte b6, ByteBuffer byteBuffer) {
        List list;
        List list2;
        List list3;
        List list4;
        List list5;
        List list6;
        List list7;
        List list8;
        Object obj;
        switch (this.f6587d) {
            case 0:
                h.e(byteBuffer, "buffer");
                if (b6 == -127) {
                    Object e = e(byteBuffer);
                    if (e instanceof List) {
                        list2 = (List) e;
                    } else {
                        list2 = null;
                    }
                    if (list2 == null) {
                        return null;
                    }
                    return new b((Boolean) list2.get(0));
                }
                if (b6 == -126) {
                    Object e6 = e(byteBuffer);
                    if (e6 instanceof List) {
                        list = (List) e6;
                    } else {
                        list = null;
                    }
                    if (list == null) {
                        return null;
                    }
                    return new a((Boolean) list.get(0));
                }
                return super.f(b6, byteBuffer);
            case 1:
                h.e(byteBuffer, "buffer");
                int i6 = 0;
                if (b6 == -127) {
                    Long l6 = (Long) e(byteBuffer);
                    if (l6 == null) {
                        return null;
                    }
                    int longValue = (int) l6.longValue();
                    m.f4311p.getClass();
                    ?? values = m.values();
                    int length = values.length;
                    while (i6 < length) {
                        obj = values[i6];
                        if (obj.o != longValue) {
                            i6++;
                        }
                    }
                    return null;
                }
                if (b6 == -126) {
                    Long l7 = (Long) e(byteBuffer);
                    if (l7 == null) {
                        return null;
                    }
                    int longValue2 = (int) l7.longValue();
                    k.f4304p.getClass();
                    ?? values2 = k.values();
                    int length2 = values2.length;
                    while (i6 < length2) {
                        obj = values2[i6];
                        if (obj.o != longValue2) {
                            i6++;
                        }
                    }
                    return null;
                }
                if (b6 == -125) {
                    Object e7 = e(byteBuffer);
                    if (e7 instanceof List) {
                        list8 = (List) e7;
                    } else {
                        list8 = null;
                    }
                    if (list8 == null) {
                        return null;
                    }
                    Object obj2 = list8.get(0);
                    h.c(obj2, "null cannot be cast to non-null type kotlin.Long");
                    long longValue3 = ((Long) obj2).longValue();
                    Object obj3 = list8.get(1);
                    h.c(obj3, "null cannot be cast to non-null type kotlin.Long");
                    long longValue4 = ((Long) obj3).longValue();
                    Object obj4 = list8.get(2);
                    h.c(obj4, "null cannot be cast to non-null type kotlin.Long");
                    long longValue5 = ((Long) obj4).longValue();
                    Object obj5 = list8.get(3);
                    h.c(obj5, "null cannot be cast to non-null type kotlin.Long");
                    return new Z4.g(longValue3, longValue4, longValue5, ((Long) obj5).longValue());
                }
                if (b6 == -124) {
                    Object e8 = e(byteBuffer);
                    if (e8 instanceof List) {
                        list7 = (List) e8;
                    } else {
                        list7 = null;
                    }
                    if (list7 == null) {
                        return null;
                    }
                    Object obj6 = list7.get(0);
                    h.c(obj6, "null cannot be cast to non-null type io.flutter.plugins.videoplayer.PlatformPlaybackState");
                    return new o((k) obj6);
                }
                if (b6 == -123) {
                    Object e9 = e(byteBuffer);
                    if (e9 instanceof List) {
                        list6 = (List) e9;
                    } else {
                        list6 = null;
                    }
                    if (list6 == null) {
                        return null;
                    }
                    Object obj7 = list6.get(0);
                    h.c(obj7, "null cannot be cast to non-null type kotlin.Boolean");
                    return new Z4.h(((Boolean) obj7).booleanValue());
                }
                if (b6 == -122) {
                    Object e10 = e(byteBuffer);
                    if (e10 instanceof List) {
                        list5 = (List) e10;
                    } else {
                        list5 = null;
                    }
                    if (list5 == null) {
                        return null;
                    }
                    Object obj8 = list5.get(0);
                    h.c(obj8, "null cannot be cast to non-null type kotlin.Long");
                    return new n(((Long) obj8).longValue());
                }
                if (b6 == -121) {
                    Object e11 = e(byteBuffer);
                    if (e11 instanceof List) {
                        list4 = (List) e11;
                    } else {
                        list4 = null;
                    }
                    if (list4 == null) {
                        return null;
                    }
                    Object obj9 = list4.get(0);
                    h.c(obj9, "null cannot be cast to non-null type kotlin.String");
                    m mVar = (m) list4.get(1);
                    Object obj10 = list4.get(2);
                    h.c(obj10, "null cannot be cast to non-null type kotlin.collections.Map<kotlin.String, kotlin.String>");
                    return new d((String) obj9, mVar, (Map) obj10, (String) list4.get(3));
                }
                if (b6 == -120) {
                    Object e12 = e(byteBuffer);
                    if (e12 instanceof List) {
                        list3 = (List) e12;
                    } else {
                        list3 = null;
                    }
                    if (list3 == null) {
                        return null;
                    }
                    Object obj11 = list3.get(0);
                    h.c(obj11, "null cannot be cast to non-null type kotlin.Long");
                    long longValue6 = ((Long) obj11).longValue();
                    Object obj12 = list3.get(1);
                    h.c(obj12, "null cannot be cast to non-null type kotlin.Long");
                    return new q(longValue6, ((Long) obj12).longValue());
                }
                return super.f(b6, byteBuffer);
                return obj;
            default:
                h.e(byteBuffer, "buffer");
                int i7 = 0;
                if (b6 == -127) {
                    Long l8 = (Long) e(byteBuffer);
                    if (l8 != null) {
                        int longValue7 = (int) l8.longValue();
                        EnumC0356t.f5643p.getClass();
                        EnumC0356t[] values3 = EnumC0356t.values();
                        int length3 = values3.length;
                        while (i7 < length3) {
                            EnumC0356t enumC0356t = values3[i7];
                            if (enumC0356t.o != longValue7) {
                                i7++;
                            } else {
                                return enumC0356t;
                            }
                        }
                    }
                } else if (b6 == -126) {
                    Long l9 = (Long) e(byteBuffer);
                    if (l9 != null) {
                        int longValue8 = (int) l9.longValue();
                        EnumC0347k.f5622p.getClass();
                        EnumC0347k[] values4 = EnumC0347k.values();
                        int length4 = values4.length;
                        while (i7 < length4) {
                            EnumC0347k enumC0347k = values4[i7];
                            if (enumC0347k.o != longValue8) {
                                i7++;
                            } else {
                                return enumC0347k;
                            }
                        }
                    }
                } else if (b6 == -125) {
                    Long l10 = (Long) e(byteBuffer);
                    if (l10 != null) {
                        int longValue9 = (int) l10.longValue();
                        EnumC0360x.f5655p.getClass();
                        EnumC0360x[] values5 = EnumC0360x.values();
                        int length5 = values5.length;
                        while (i7 < length5) {
                            EnumC0360x enumC0360x = values5[i7];
                            if (enumC0360x.o != longValue9) {
                                i7++;
                            } else {
                                return enumC0360x;
                            }
                        }
                    }
                } else if (b6 == -124) {
                    Long l11 = (Long) e(byteBuffer);
                    if (l11 != null) {
                        int longValue10 = (int) l11.longValue();
                        EnumC0327P.f5556p.getClass();
                        EnumC0327P[] values6 = EnumC0327P.values();
                        int length6 = values6.length;
                        while (i7 < length6) {
                            EnumC0327P enumC0327P = values6[i7];
                            if (enumC0327P.o != longValue10) {
                                i7++;
                            } else {
                                return enumC0327P;
                            }
                        }
                    }
                } else if (b6 == -123) {
                    Long l12 = (Long) e(byteBuffer);
                    if (l12 != null) {
                        int longValue11 = (int) l12.longValue();
                        EnumC0359w.f5653p.getClass();
                        EnumC0359w[] values7 = EnumC0359w.values();
                        int length7 = values7.length;
                        while (i7 < length7) {
                            EnumC0359w enumC0359w = values7[i7];
                            if (enumC0359w.o != longValue11) {
                                i7++;
                            } else {
                                return enumC0359w;
                            }
                        }
                    }
                } else {
                    return super.f(b6, byteBuffer);
                }
                return null;
        }
    }

    @Override // M4.v
    public void k(u uVar, Object obj) {
        switch (this.f6587d) {
            case 0:
                if (obj instanceof b) {
                    uVar.write(129);
                    k(uVar, a.z(((b) obj).f5064a));
                    return;
                } else if (obj instanceof a) {
                    uVar.write(130);
                    k(uVar, a.z(((a) obj).f4329a));
                    return;
                } else {
                    super.k(uVar, obj);
                    return;
                }
            case 1:
                if (obj instanceof m) {
                    uVar.write(129);
                    k(uVar, Long.valueOf(((m) obj).o));
                    return;
                }
                if (obj instanceof k) {
                    uVar.write(130);
                    k(uVar, Long.valueOf(((k) obj).o));
                    return;
                }
                if (obj instanceof Z4.g) {
                    uVar.write(131);
                    k(uVar, ((Z4.g) obj).a());
                    return;
                }
                if (obj instanceof o) {
                    uVar.write(132);
                    k(uVar, a.z(((o) obj).f4314a));
                    return;
                }
                if (obj instanceof Z4.h) {
                    uVar.write(133);
                    k(uVar, a.z(Boolean.valueOf(((Z4.h) obj).f4301a)));
                    return;
                }
                if (obj instanceof n) {
                    uVar.write(134);
                    k(uVar, a.z(Long.valueOf(((n) obj).f4313a)));
                    return;
                } else if (obj instanceof d) {
                    uVar.write(135);
                    k(uVar, ((d) obj).a());
                    return;
                } else if (obj instanceof q) {
                    uVar.write(136);
                    k(uVar, ((q) obj).a());
                    return;
                } else {
                    super.k(uVar, obj);
                    return;
                }
            default:
                if (obj instanceof EnumC0356t) {
                    uVar.write(129);
                    k(uVar, Long.valueOf(((EnumC0356t) obj).o));
                    return;
                }
                if (obj instanceof EnumC0347k) {
                    uVar.write(130);
                    k(uVar, Long.valueOf(((EnumC0347k) obj).o));
                    return;
                }
                if (obj instanceof EnumC0360x) {
                    uVar.write(131);
                    k(uVar, Long.valueOf(((EnumC0360x) obj).o));
                    return;
                } else if (obj instanceof EnumC0327P) {
                    uVar.write(132);
                    k(uVar, Long.valueOf(((EnumC0327P) obj).o));
                    return;
                } else if (obj instanceof EnumC0359w) {
                    uVar.write(133);
                    k(uVar, Long.valueOf(((EnumC0359w) obj).o));
                    return;
                } else {
                    super.k(uVar, obj);
                    return;
                }
        }
    }
}
