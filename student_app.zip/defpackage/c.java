package defpackage;

import X4.C0164b;
import p5.a;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* loaded from: classes.dex */
public final /* synthetic */ class c implements a {
    public final /* synthetic */ int o;

    public /* synthetic */ c(int i6) {
        this.o = i6;
    }

    @Override // p5.a
    public final Object c() {
        switch (this.o) {
            case 0:
                return new g(0);
            case 1:
                return new C0164b(1);
            case 2:
                return new g(1);
            case 3:
                return new g(1);
            case 4:
                return new g(2);
            default:
                return 33554432;
        }
    }
}
