package defpackage;

import T5.h;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* loaded from: classes.dex */
public final class a {

    /* renamed from: a, reason: collision with root package name */
    public final Boolean f4329a;

    public a(Boolean bool) {
        this.f4329a = bool;
    }

    public final boolean equals(Object obj) {
        if (!(obj instanceof a)) {
            return false;
        }
        if (this == obj) {
            return true;
        }
        return h.k(android.support.v4.media.session.a.z(this.f4329a), android.support.v4.media.session.a.z(((a) obj).f4329a));
    }

    public final int hashCode() {
        return android.support.v4.media.session.a.z(this.f4329a).hashCode();
    }

    public final String toString() {
        return "IsEnabledMessage(enabled=" + this.f4329a + ")";
    }
}
