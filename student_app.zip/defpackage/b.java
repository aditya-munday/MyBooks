package defpackage;

import T5.h;
import android.support.v4.media.session.a;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* loaded from: classes.dex */
public final class b {

    /* renamed from: a, reason: collision with root package name */
    public final Boolean f5064a;

    public b(Boolean bool) {
        this.f5064a = bool;
    }

    public final boolean equals(Object obj) {
        if (!(obj instanceof b)) {
            return false;
        }
        if (this == obj) {
            return true;
        }
        return h.k(a.z(this.f5064a), a.z(((b) obj).f5064a));
    }

    public final int hashCode() {
        return a.z(this.f5064a).hashCode();
    }

    public final String toString() {
        return "ToggleMessage(enable=" + this.f5064a + ")";
    }
}
