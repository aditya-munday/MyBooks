package defpackage;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* loaded from: classes.dex */
public interface f {

    /* renamed from: d, reason: collision with root package name */
    public static final e f6352d = e.f6014a;
}
