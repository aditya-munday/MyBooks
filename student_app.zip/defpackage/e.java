package defpackage;

import A.c;
import C4.AbstractC0034i;
import M4.b;
import M4.f;
import M4.l;
import android.app.Activity;
import android.support.v4.media.session.a;
import android.util.Log;
import g5.C0457f;
import h5.e;
import j2.C0508g;
import java.util.List;
import org.apache.tika.utils.StringUtils;
import q5.h;
import v3.u;
import z4.C0936a;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* loaded from: classes.dex */
public final class e {

    /* renamed from: a, reason: collision with root package name */
    public static final /* synthetic */ e f6014a = new Object();

    /* renamed from: b, reason: collision with root package name */
    public static final C0457f f6015b = new C0457f(new c(0));

    public static void a(e eVar, f fVar, final C0936a c0936a) {
        eVar.getClass();
        h.e(fVar, "binaryMessenger");
        String str = StringUtils.EMPTY;
        if (StringUtils.EMPTY.length() > 0) {
            str = ".".concat(StringUtils.EMPTY);
        }
        String j6 = AbstractC0034i.j("dev.flutter.pigeon.wakelock_plus_platform_interface.WakelockPlusApi.toggle", str);
        C0457f c0457f = f6015b;
        u uVar = new u(fVar, j6, (l) c0457f.a(), (C0508g) null);
        if (c0936a != null) {
            final int i6 = 0;
            uVar.y(new b() { // from class: d
                @Override // M4.b
                public final void e(Object obj, c cVar) {
                    List T6;
                    List T7;
                    Activity activity;
                    boolean z6;
                    switch (i6) {
                        case 0:
                            f fVar2 = c0936a;
                            h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            Object obj2 = ((List) obj).get(0);
                            h.c(obj2, "null cannot be cast to non-null type <root>.ToggleMessage");
                            try {
                                ((C0936a) fVar2).a((b) obj2);
                                T6 = a.z(null);
                            } catch (Throwable th) {
                                T6 = e.T(th.getClass().getSimpleName(), th.toString(), AbstractC0034i.k("Cause: ", th.getCause(), ", Stacktrace: ", Log.getStackTraceString(th)));
                            }
                            cVar.g(T6);
                            return;
                        default:
                            try {
                                V4.f fVar3 = ((C0936a) c0936a).o;
                                h.b(fVar3);
                                activity = fVar3.f3315a;
                            } catch (Throwable th2) {
                                T7 = e.T(th2.getClass().getSimpleName(), th2.toString(), AbstractC0034i.k("Cause: ", th2.getCause(), ", Stacktrace: ", Log.getStackTraceString(th2)));
                            }
                            if (activity != null) {
                                h.b(activity);
                                if ((activity.getWindow().getAttributes().flags & 128) != 0) {
                                    z6 = true;
                                } else {
                                    z6 = false;
                                }
                                T7 = a.z(new a(Boolean.valueOf(z6)));
                                cVar.g(T7);
                                return;
                            }
                            throw new b0.l();
                    }
                }
            });
        } else {
            uVar.y(null);
        }
        u uVar2 = new u(fVar, AbstractC0034i.j("dev.flutter.pigeon.wakelock_plus_platform_interface.WakelockPlusApi.isEnabled", str), (l) c0457f.a(), (C0508g) null);
        if (c0936a != null) {
            final int i7 = 1;
            uVar2.y(new b() { // from class: d
                @Override // M4.b
                public final void e(Object obj, c cVar) {
                    List T6;
                    List T7;
                    Activity activity;
                    boolean z6;
                    switch (i7) {
                        case 0:
                            f fVar2 = c0936a;
                            h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            Object obj2 = ((List) obj).get(0);
                            h.c(obj2, "null cannot be cast to non-null type <root>.ToggleMessage");
                            try {
                                ((C0936a) fVar2).a((b) obj2);
                                T6 = a.z(null);
                            } catch (Throwable th) {
                                T6 = e.T(th.getClass().getSimpleName(), th.toString(), AbstractC0034i.k("Cause: ", th.getCause(), ", Stacktrace: ", Log.getStackTraceString(th)));
                            }
                            cVar.g(T6);
                            return;
                        default:
                            try {
                                V4.f fVar3 = ((C0936a) c0936a).o;
                                h.b(fVar3);
                                activity = fVar3.f3315a;
                            } catch (Throwable th2) {
                                T7 = e.T(th2.getClass().getSimpleName(), th2.toString(), AbstractC0034i.k("Cause: ", th2.getCause(), ", Stacktrace: ", Log.getStackTraceString(th2)));
                            }
                            if (activity != null) {
                                h.b(activity);
                                if ((activity.getWindow().getAttributes().flags & 128) != 0) {
                                    z6 = true;
                                } else {
                                    z6 = false;
                                }
                                T7 = a.z(new a(Boolean.valueOf(z6)));
                                cVar.g(T7);
                                return;
                            }
                            throw new b0.l();
                    }
                }
            });
        } else {
            uVar2.y(null);
        }
    }
}
