package v4;

import I4.b;
import L4.j;
import M4.m;
import M4.n;
import M4.o;
import M4.p;
import android.content.ContentResolver;
import android.provider.Settings;
import q5.h;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* renamed from: v4.a, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0852a implements b, n {
    public p o;

    /* renamed from: p, reason: collision with root package name */
    public ContentResolver f10049p;

    @Override // I4.b
    public final void onAttachedToEngine(I4.a aVar) {
        h.e(aVar, "flutterPluginBinding");
        ContentResolver contentResolver = aVar.f1090a.getContentResolver();
        h.d(contentResolver, "getContentResolver(...)");
        this.f10049p = contentResolver;
        p pVar = new p(aVar.f1091b, "android_id");
        this.o = pVar;
        pVar.b(this);
    }

    @Override // I4.b
    public final void onDetachedFromEngine(I4.a aVar) {
        h.e(aVar, "binding");
        p pVar = this.o;
        if (pVar != null) {
            pVar.b(null);
        } else {
            h.h("channel");
            throw null;
        }
    }

    @Override // M4.n
    public final void onMethodCall(m mVar, o oVar) {
        h.e(mVar, "call");
        if (mVar.f1733a.equals("getId")) {
            try {
                ContentResolver contentResolver = this.f10049p;
                if (contentResolver != null) {
                    ((j) oVar).b(Settings.Secure.getString(contentResolver, "android_id"));
                    return;
                } else {
                    h.h("contentResolver");
                    throw null;
                }
            } catch (Exception e) {
                ((j) oVar).d("ERROR_GETTING_ID", "Failed to get Android ID", e.getLocalizedMessage());
                return;
            }
        }
        ((j) oVar).c();
    }
}
