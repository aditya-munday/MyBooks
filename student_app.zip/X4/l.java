package X4;

import J.C0094n;
import j5.EnumC0522a;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* loaded from: classes.dex */
public final class l implements A5.e {
    public final /* synthetic */ int o;

    /* renamed from: p, reason: collision with root package name */
    public final /* synthetic */ A5.e f3670p;

    /* renamed from: q, reason: collision with root package name */
    public final /* synthetic */ Object f3671q;

    public /* synthetic */ l(A5.e eVar, M.d dVar, int i6) {
        this.o = i6;
        this.f3670p = eVar;
        this.f3671q = dVar;
    }

    /* JADX WARN: Removed duplicated region for block: B:10:0x0027  */
    /* JADX WARN: Removed duplicated region for block: B:14:0x0077  */
    /* JADX WARN: Removed duplicated region for block: B:17:0x007a  */
    /* JADX WARN: Removed duplicated region for block: B:24:0x0064  */
    /* JADX WARN: Removed duplicated region for block: B:27:0x0074  */
    /* JADX WARN: Removed duplicated region for block: B:28:0x0045  */
    /* JADX WARN: Removed duplicated region for block: B:40:0x009f  */
    /* JADX WARN: Removed duplicated region for block: B:46:0x00ad  */
    /* JADX WARN: Removed duplicated region for block: B:57:0x00e9  */
    /* JADX WARN: Removed duplicated region for block: B:63:0x00f7  */
    /* JADX WARN: Removed duplicated region for block: B:74:0x0133  */
    /* JADX WARN: Removed duplicated region for block: B:80:0x0141  */
    /* JADX WARN: Removed duplicated region for block: B:91:0x017d  */
    /* JADX WARN: Removed duplicated region for block: B:97:0x018b  */
    @Override // A5.e
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final Object l(Object obj, i5.d dVar) {
        k kVar;
        int i6;
        p pVar;
        int i7;
        r rVar;
        int i8;
        s sVar;
        int i9;
        A5.n nVar;
        int i10;
        boolean z6;
        Object obj2;
        Object obj3;
        l lVar;
        switch (this.o) {
            case 0:
                if (dVar instanceof k) {
                    kVar = (k) dVar;
                    int i11 = kVar.f3668s;
                    if ((i11 & Integer.MIN_VALUE) != 0) {
                        kVar.f3668s = i11 - Integer.MIN_VALUE;
                        Object obj4 = kVar.f3667r;
                        i6 = kVar.f3668s;
                        if (i6 == 0) {
                            if (i6 == 1) {
                                Q5.a.K(obj4);
                            } else {
                                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                            }
                        } else {
                            Q5.a.K(obj4);
                            Object c6 = ((M.b) obj).c((M.d) this.f3671q);
                            kVar.f3668s = 1;
                            Object l6 = this.f3670p.l(c6, kVar);
                            EnumC0522a enumC0522a = EnumC0522a.o;
                            if (l6 == enumC0522a) {
                                return enumC0522a;
                            }
                        }
                        return g5.h.f6800a;
                    }
                }
                kVar = new k(this, dVar);
                Object obj42 = kVar.f3667r;
                i6 = kVar.f3668s;
                if (i6 == 0) {
                }
                return g5.h.f6800a;
            case 1:
                if (dVar instanceof p) {
                    pVar = (p) dVar;
                    int i12 = pVar.f3684s;
                    if ((i12 & Integer.MIN_VALUE) != 0) {
                        pVar.f3684s = i12 - Integer.MIN_VALUE;
                        Object obj5 = pVar.f3683r;
                        i7 = pVar.f3684s;
                        if (i7 == 0) {
                            if (i7 == 1) {
                                Q5.a.K(obj5);
                            } else {
                                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                            }
                        } else {
                            Q5.a.K(obj5);
                            Object c7 = ((M.b) obj).c((M.d) this.f3671q);
                            pVar.f3684s = 1;
                            Object l7 = this.f3670p.l(c7, pVar);
                            EnumC0522a enumC0522a2 = EnumC0522a.o;
                            if (l7 == enumC0522a2) {
                                return enumC0522a2;
                            }
                        }
                        return g5.h.f6800a;
                    }
                }
                pVar = new p(this, dVar);
                Object obj52 = pVar.f3683r;
                i7 = pVar.f3684s;
                if (i7 == 0) {
                }
                return g5.h.f6800a;
            case 2:
                if (dVar instanceof r) {
                    rVar = (r) dVar;
                    int i13 = rVar.f3694s;
                    if ((i13 & Integer.MIN_VALUE) != 0) {
                        rVar.f3694s = i13 - Integer.MIN_VALUE;
                        Object obj6 = rVar.f3693r;
                        i8 = rVar.f3694s;
                        if (i8 == 0) {
                            if (i8 == 1) {
                                Q5.a.K(obj6);
                            } else {
                                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                            }
                        } else {
                            Q5.a.K(obj6);
                            Object c8 = ((M.b) obj).c((M.d) this.f3671q);
                            rVar.f3694s = 1;
                            Object l8 = this.f3670p.l(c8, rVar);
                            EnumC0522a enumC0522a3 = EnumC0522a.o;
                            if (l8 == enumC0522a3) {
                                return enumC0522a3;
                            }
                        }
                        return g5.h.f6800a;
                    }
                }
                rVar = new r(this, dVar);
                Object obj62 = rVar.f3693r;
                i8 = rVar.f3694s;
                if (i8 == 0) {
                }
                return g5.h.f6800a;
            case 3:
                if (dVar instanceof s) {
                    sVar = (s) dVar;
                    int i14 = sVar.f3697s;
                    if ((i14 & Integer.MIN_VALUE) != 0) {
                        sVar.f3697s = i14 - Integer.MIN_VALUE;
                        Object obj7 = sVar.f3696r;
                        i9 = sVar.f3697s;
                        if (i9 == 0) {
                            if (i9 == 1) {
                                Q5.a.K(obj7);
                            } else {
                                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                            }
                        } else {
                            Q5.a.K(obj7);
                            Object c9 = ((M.b) obj).c((M.d) this.f3671q);
                            sVar.f3697s = 1;
                            Object l9 = this.f3670p.l(c9, sVar);
                            EnumC0522a enumC0522a4 = EnumC0522a.o;
                            if (l9 == enumC0522a4) {
                                return enumC0522a4;
                            }
                        }
                        return g5.h.f6800a;
                    }
                }
                sVar = new s(this, dVar);
                Object obj72 = sVar.f3696r;
                i9 = sVar.f3697s;
                if (i9 == 0) {
                }
                return g5.h.f6800a;
            default:
                if (dVar instanceof A5.n) {
                    nVar = (A5.n) dVar;
                    int i15 = nVar.f135t;
                    if ((i15 & Integer.MIN_VALUE) != 0) {
                        nVar.f135t = i15 - Integer.MIN_VALUE;
                        Object obj8 = nVar.f134s;
                        i10 = nVar.f135t;
                        z6 = true;
                        EnumC0522a enumC0522a5 = EnumC0522a.o;
                        if (i10 == 0) {
                            if (i10 != 1) {
                                if (i10 == 2) {
                                    lVar = nVar.f133r;
                                    Q5.a.K(obj8);
                                    if (z6) {
                                        return g5.h.f6800a;
                                    }
                                    throw new B5.a(lVar);
                                }
                                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                            }
                            Object obj9 = nVar.f137v;
                            l lVar2 = nVar.f133r;
                            Q5.a.K(obj8);
                            obj3 = obj9;
                            lVar = lVar2;
                            obj2 = obj8;
                        } else {
                            Q5.a.K(obj8);
                            C0094n c0094n = (C0094n) this.f3671q;
                            nVar.f133r = this;
                            nVar.f137v = obj;
                            nVar.f135t = 1;
                            Object h6 = c0094n.h(obj, nVar);
                            if (h6 != enumC0522a5) {
                                obj2 = h6;
                                obj3 = obj;
                                lVar = this;
                            } else {
                                return enumC0522a5;
                            }
                        }
                        if (!((Boolean) obj2).booleanValue()) {
                            A5.e eVar = lVar.f3670p;
                            nVar.f133r = lVar;
                            nVar.f137v = null;
                            nVar.f135t = 2;
                            if (eVar.l(obj3, nVar) == enumC0522a5) {
                                return enumC0522a5;
                            }
                        } else {
                            z6 = false;
                        }
                        if (z6) {
                        }
                    }
                }
                nVar = new A5.n(this, dVar);
                Object obj82 = nVar.f134s;
                i10 = nVar.f135t;
                z6 = true;
                EnumC0522a enumC0522a52 = EnumC0522a.o;
                if (i10 == 0) {
                }
                if (!((Boolean) obj2).booleanValue()) {
                }
                if (z6) {
                }
        }
    }

    public l(C0094n c0094n, A5.e eVar) {
        this.o = 4;
        this.f3671q = c0094n;
        this.f3670p = eVar;
    }
}
