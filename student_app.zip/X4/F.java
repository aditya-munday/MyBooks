package X4;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* loaded from: classes.dex */
public final class F {

    /* renamed from: a, reason: collision with root package name */
    public final String f3647a;

    /* renamed from: b, reason: collision with root package name */
    public final D f3648b;

    public F(String str, D d6) {
        this.f3647a = str;
        this.f3648b = d6;
    }

    public final boolean equals(Object obj) {
        if (!(obj instanceof F)) {
            return false;
        }
        if (this == obj) {
            return true;
        }
        F f6 = (F) obj;
        return T5.h.l(h5.e.T(this.f3647a, this.f3648b), h5.e.T(f6.f3647a, f6.f3648b));
    }

    public final int hashCode() {
        return h5.e.T(this.f3647a, this.f3648b).hashCode();
    }

    public final String toString() {
        return "StringListResult(jsonEncodedValue=" + this.f3647a + ", type=" + this.f3648b + ")";
    }
}
