package X4;

import j2.C0508g;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* loaded from: classes.dex */
public enum D {
    f3643q(0),
    f3644r(1),
    f3645s(2);


    /* renamed from: p, reason: collision with root package name */
    public static final C0508g f3642p = new C0508g(25, false);
    public final int o;

    D(int i6) {
        this.o = i6;
    }
}
