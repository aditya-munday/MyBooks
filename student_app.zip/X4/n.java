package X4;

import J.InterfaceC0087g;
import android.content.Context;
import j5.EnumC0522a;
import k5.AbstractC0567h;
import x5.InterfaceC0913u;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* loaded from: classes.dex */
public final class n extends AbstractC0567h implements p5.p {

    /* renamed from: s, reason: collision with root package name */
    public final /* synthetic */ int f3674s;

    /* renamed from: t, reason: collision with root package name */
    public q5.p f3675t;

    /* renamed from: u, reason: collision with root package name */
    public int f3676u;

    /* renamed from: v, reason: collision with root package name */
    public final /* synthetic */ String f3677v;

    /* renamed from: w, reason: collision with root package name */
    public final /* synthetic */ B f3678w;

    /* renamed from: x, reason: collision with root package name */
    public final /* synthetic */ q5.p f3679x;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public /* synthetic */ n(String str, B b6, q5.p pVar, i5.d dVar, int i6) {
        super(2, dVar);
        this.f3674s = i6;
        this.f3677v = str;
        this.f3678w = b6;
        this.f3679x = pVar;
    }

    @Override // p5.p
    public final Object h(Object obj, Object obj2) {
        InterfaceC0913u interfaceC0913u = (InterfaceC0913u) obj;
        i5.d dVar = (i5.d) obj2;
        switch (this.f3674s) {
            case 0:
                return ((n) m(dVar, interfaceC0913u)).p(g5.h.f6800a);
            case 1:
                return ((n) m(dVar, interfaceC0913u)).p(g5.h.f6800a);
            case 2:
                return ((n) m(dVar, interfaceC0913u)).p(g5.h.f6800a);
            default:
                return ((n) m(dVar, interfaceC0913u)).p(g5.h.f6800a);
        }
    }

    @Override // k5.AbstractC0560a
    public final i5.d m(i5.d dVar, Object obj) {
        switch (this.f3674s) {
            case 0:
                return new n(this.f3677v, this.f3678w, this.f3679x, dVar, 0);
            case 1:
                return new n(this.f3677v, this.f3678w, this.f3679x, dVar, 1);
            case 2:
                return new n(this.f3677v, this.f3678w, this.f3679x, dVar, 2);
            default:
                return new n(this.f3677v, this.f3678w, this.f3679x, dVar, 3);
        }
    }

    @Override // k5.AbstractC0560a
    public final Object p(Object obj) {
        q5.p pVar;
        q5.p pVar2;
        q5.p pVar3;
        q5.p pVar4;
        switch (this.f3674s) {
            case 0:
                int i6 = this.f3676u;
                if (i6 != 0) {
                    if (i6 == 1) {
                        pVar = this.f3675t;
                        Q5.a.K(obj);
                    } else {
                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                    }
                } else {
                    Q5.a.K(obj);
                    M.d dVar = new M.d(this.f3677v);
                    Context context = this.f3678w.o;
                    if (context != null) {
                        m mVar = new m(((InterfaceC0087g) ((x3.c) C.a(context)).f10281p).getData(), dVar, 0);
                        pVar = this.f3679x;
                        this.f3675t = pVar;
                        this.f3676u = 1;
                        obj = A5.s.c(mVar, this);
                        EnumC0522a enumC0522a = EnumC0522a.o;
                        if (obj == enumC0522a) {
                            return enumC0522a;
                        }
                    } else {
                        q5.h.h("context");
                        throw null;
                    }
                }
                pVar.o = obj;
                return g5.h.f6800a;
            case 1:
                int i7 = this.f3676u;
                if (i7 != 0) {
                    if (i7 == 1) {
                        pVar2 = this.f3675t;
                        Q5.a.K(obj);
                    } else {
                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                    }
                } else {
                    Q5.a.K(obj);
                    M.d dVar2 = new M.d(this.f3677v);
                    B b6 = this.f3678w;
                    Context context2 = b6.o;
                    if (context2 != null) {
                        g gVar = new g(((InterfaceC0087g) ((x3.c) C.a(context2)).f10281p).getData(), dVar2, b6, 1);
                        pVar2 = this.f3679x;
                        this.f3675t = pVar2;
                        this.f3676u = 1;
                        obj = A5.s.c(gVar, this);
                        EnumC0522a enumC0522a2 = EnumC0522a.o;
                        if (obj == enumC0522a2) {
                            return enumC0522a2;
                        }
                    } else {
                        q5.h.h("context");
                        throw null;
                    }
                }
                pVar2.o = obj;
                return g5.h.f6800a;
            case 2:
                int i8 = this.f3676u;
                if (i8 != 0) {
                    if (i8 == 1) {
                        pVar3 = this.f3675t;
                        Q5.a.K(obj);
                    } else {
                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                    }
                } else {
                    Q5.a.K(obj);
                    M.d dVar3 = new M.d(this.f3677v);
                    Context context3 = this.f3678w.o;
                    if (context3 != null) {
                        m mVar2 = new m(((InterfaceC0087g) ((x3.c) C.a(context3)).f10281p).getData(), dVar3, 1);
                        pVar3 = this.f3679x;
                        this.f3675t = pVar3;
                        this.f3676u = 1;
                        obj = A5.s.c(mVar2, this);
                        EnumC0522a enumC0522a3 = EnumC0522a.o;
                        if (obj == enumC0522a3) {
                            return enumC0522a3;
                        }
                    } else {
                        q5.h.h("context");
                        throw null;
                    }
                }
                pVar3.o = obj;
                return g5.h.f6800a;
            default:
                int i9 = this.f3676u;
                if (i9 != 0) {
                    if (i9 == 1) {
                        pVar4 = this.f3675t;
                        Q5.a.K(obj);
                    } else {
                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                    }
                } else {
                    Q5.a.K(obj);
                    M.d dVar4 = new M.d(this.f3677v);
                    Context context4 = this.f3678w.o;
                    if (context4 != null) {
                        m mVar3 = new m(((InterfaceC0087g) ((x3.c) C.a(context4)).f10281p).getData(), dVar4, 2);
                        pVar4 = this.f3679x;
                        this.f3675t = pVar4;
                        this.f3676u = 1;
                        obj = A5.s.c(mVar3, this);
                        EnumC0522a enumC0522a4 = EnumC0522a.o;
                        if (obj == enumC0522a4) {
                            return enumC0522a4;
                        }
                    } else {
                        q5.h.h("context");
                        throw null;
                    }
                }
                pVar4.o = obj;
                return g5.h.f6800a;
        }
    }
}
