package X4;

import J.InterfaceC0087g;
import android.content.Context;
import j5.EnumC0522a;
import k5.AbstractC0567h;
import x5.InterfaceC0913u;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* loaded from: classes.dex */
public final class v extends AbstractC0567h implements p5.p {

    /* renamed from: s, reason: collision with root package name */
    public int f3705s;

    /* renamed from: t, reason: collision with root package name */
    public final /* synthetic */ String f3706t;

    /* renamed from: u, reason: collision with root package name */
    public final /* synthetic */ B f3707u;

    /* renamed from: v, reason: collision with root package name */
    public final /* synthetic */ boolean f3708v;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public v(String str, B b6, boolean z6, i5.d dVar) {
        super(2, dVar);
        this.f3706t = str;
        this.f3707u = b6;
        this.f3708v = z6;
    }

    @Override // p5.p
    public final Object h(Object obj, Object obj2) {
        return ((v) m((i5.d) obj2, (InterfaceC0913u) obj)).p(g5.h.f6800a);
    }

    @Override // k5.AbstractC0560a
    public final i5.d m(i5.d dVar, Object obj) {
        return new v(this.f3706t, this.f3707u, this.f3708v, dVar);
    }

    @Override // k5.AbstractC0560a
    public final Object p(Object obj) {
        int i6 = this.f3705s;
        if (i6 != 0) {
            if (i6 == 1) {
                Q5.a.K(obj);
            } else {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
        } else {
            Q5.a.K(obj);
            M.d dVar = new M.d(this.f3706t);
            Context context = this.f3707u.o;
            if (context != null) {
                InterfaceC0087g a6 = C.a(context);
                u uVar = new u(dVar, this.f3708v, null);
                this.f3705s = 1;
                Object b6 = ((x3.c) a6).b(new M.c(uVar, null, 1), this);
                EnumC0522a enumC0522a = EnumC0522a.o;
                if (b6 == enumC0522a) {
                    return enumC0522a;
                }
            } else {
                q5.h.h("context");
                throw null;
            }
        }
        return g5.h.f6800a;
    }
}
