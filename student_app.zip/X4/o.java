package X4;

import k5.AbstractC0562c;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* loaded from: classes.dex */
public final class o extends AbstractC0562c {

    /* renamed from: r, reason: collision with root package name */
    public /* synthetic */ Object f3680r;

    /* renamed from: s, reason: collision with root package name */
    public int f3681s;

    /* renamed from: t, reason: collision with root package name */
    public final /* synthetic */ A5.l f3682t;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public o(A5.l lVar, i5.d dVar) {
        super(dVar);
        this.f3682t = lVar;
    }

    @Override // k5.AbstractC0560a
    public final Object p(Object obj) {
        this.f3680r = obj;
        this.f3681s |= Integer.MIN_VALUE;
        return this.f3682t.l(null, this);
    }
}
