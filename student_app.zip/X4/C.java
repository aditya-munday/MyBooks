package X4;

import J.I;
import J.InterfaceC0087g;
import J.J;
import android.content.Context;
import android.util.Base64;
import j2.C0508g;
import java.io.ByteArrayInputStream;
import java.io.ObjectInputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import org.apache.tika.parser.external.ExternalParsersConfigReaderMetKeys;
import x5.AbstractC0915w;
import x5.InterfaceC0913u;
import x5.W;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* loaded from: classes.dex */
public abstract class C {

    /* renamed from: a, reason: collision with root package name */
    public static final /* synthetic */ u5.d[] f3640a;

    /* renamed from: b, reason: collision with root package name */
    public static final L.b f3641b;

    static {
        i5.c cVar;
        q5.m mVar = new q5.m(q5.b.o, C.class, "sharedPreferencesDataStore", "getSharedPreferencesDataStore(Landroid/content/Context;)Landroidx/datastore/core/DataStore;", 1);
        q5.q.f9289a.getClass();
        f3640a = new u5.d[]{mVar};
        i5.i iVar = x5.C.f10286b;
        W w6 = new W();
        iVar.getClass();
        i5.j jVar = i5.j.o;
        if (w6 != jVar) {
            i5.i c6 = iVar.c(w6.getKey());
            if (c6 == jVar) {
                iVar = w6;
            } else {
                i5.e eVar = i5.e.o;
                i5.f fVar = (i5.f) c6.m(eVar);
                if (fVar == null) {
                    cVar = new i5.c(c6, w6);
                } else {
                    i5.i c7 = c6.c(eVar);
                    if (c7 == jVar) {
                        iVar = new i5.c(w6, fVar);
                    } else {
                        cVar = new i5.c(new i5.c(c7, w6), fVar);
                    }
                }
                iVar = cVar;
            }
        }
        f3641b = new L.b(L.a.f1533p, AbstractC0915w.a(iVar));
    }

    public static final InterfaceC0087g a(Context context) {
        x3.c cVar;
        q5.h.e(context, "<this>");
        L.b bVar = f3641b;
        u5.d dVar = f3640a[0];
        bVar.getClass();
        q5.h.e(dVar, "property");
        x3.c cVar2 = bVar.f1537d;
        if (cVar2 == null) {
            synchronized (bVar.f1536c) {
                try {
                    if (bVar.f1537d == null) {
                        Context applicationContext = context.getApplicationContext();
                        p5.l lVar = bVar.f1534a;
                        q5.h.d(applicationContext, "applicationContext");
                        List list = (List) lVar.a(applicationContext);
                        InterfaceC0913u interfaceC0913u = bVar.f1535b;
                        I i6 = new I(applicationContext, bVar);
                        q5.h.e(list, "migrations");
                        bVar.f1537d = new x3.c(new x3.c(new J.E(new J(new I(i6, 2)), android.support.v4.media.session.a.z(new B5.d(list, (i5.d) null, 3)), new C0508g(7, false), interfaceC0913u), 21), 21);
                    }
                    cVar = bVar.f1537d;
                    q5.h.b(cVar);
                } catch (Throwable th) {
                    throw th;
                }
            }
            return cVar;
        }
        return cVar2;
    }

    public static final boolean b(String str, Object obj, Set set) {
        q5.h.e(str, ExternalParsersConfigReaderMetKeys.METADATA_KEY_ATTR);
        if (set == null) {
            if (!(obj instanceof Boolean) && !(obj instanceof Long) && !(obj instanceof String) && !(obj instanceof Double)) {
                return false;
            }
            return true;
        }
        return set.contains(str);
    }

    public static final Object c(Object obj, m3.e eVar) {
        if (obj instanceof String) {
            String str = (String) obj;
            if (str.startsWith("VGhpcyBpcyB0aGUgcHJlZml4IGZvciBhIGxpc3Qu")) {
                if (str.startsWith("VGhpcyBpcyB0aGUgcHJlZml4IGZvciBhIGxpc3Qu!")) {
                    return obj;
                }
                String substring = str.substring(40);
                q5.h.d(substring, "substring(...)");
                eVar.getClass();
                q5.h.e(substring, "listString");
                Object readObject = new ObjectInputStream(new ByteArrayInputStream(Base64.decode(substring, 0))).readObject();
                q5.h.c(readObject, "null cannot be cast to non-null type kotlin.collections.List<*>");
                ArrayList arrayList = new ArrayList();
                for (Object obj2 : (List) readObject) {
                    if (obj2 instanceof String) {
                        arrayList.add(obj2);
                    }
                }
                return arrayList;
            }
            if (str.startsWith("VGhpcyBpcyB0aGUgcHJlZml4IGZvciBEb3VibGUu")) {
                String substring2 = str.substring(40);
                q5.h.d(substring2, "substring(...)");
                return Double.valueOf(Double.parseDouble(substring2));
            }
            return obj;
        }
        return obj;
    }
}
