package X4;

import k5.AbstractC0567h;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* loaded from: classes.dex */
public final class z extends AbstractC0567h implements p5.p {

    /* renamed from: s, reason: collision with root package name */
    public /* synthetic */ Object f3721s;

    /* renamed from: t, reason: collision with root package name */
    public final /* synthetic */ M.d f3722t;

    /* renamed from: u, reason: collision with root package name */
    public final /* synthetic */ long f3723u;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public z(M.d dVar, long j6, i5.d dVar2) {
        super(2, dVar2);
        this.f3722t = dVar;
        this.f3723u = j6;
    }

    @Override // p5.p
    public final Object h(Object obj, Object obj2) {
        z zVar = (z) m((i5.d) obj2, (M.b) obj);
        g5.h hVar = g5.h.f6800a;
        zVar.p(hVar);
        return hVar;
    }

    @Override // k5.AbstractC0560a
    public final i5.d m(i5.d dVar, Object obj) {
        z zVar = new z(this.f3722t, this.f3723u, dVar);
        zVar.f3721s = obj;
        return zVar;
    }

    @Override // k5.AbstractC0560a
    public final Object p(Object obj) {
        M.b bVar = (M.b) this.f3721s;
        Q5.a.K(obj);
        bVar.d(this.f3722t, new Long(this.f3723u));
        return g5.h.f6800a;
    }
}
