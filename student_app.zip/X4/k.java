package X4;

import k5.AbstractC0562c;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* loaded from: classes.dex */
public final class k extends AbstractC0562c {

    /* renamed from: r, reason: collision with root package name */
    public /* synthetic */ Object f3667r;

    /* renamed from: s, reason: collision with root package name */
    public int f3668s;

    /* renamed from: t, reason: collision with root package name */
    public final /* synthetic */ l f3669t;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public k(l lVar, i5.d dVar) {
        super(dVar);
        this.f3669t = lVar;
    }

    @Override // k5.AbstractC0560a
    public final Object p(Object obj) {
        this.f3667r = obj;
        this.f3668s |= Integer.MIN_VALUE;
        return this.f3669t.l(null, this);
    }
}
