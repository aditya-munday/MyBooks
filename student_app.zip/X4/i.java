package X4;

import J.C0095o;
import J.InterfaceC0087g;
import android.content.Context;
import j5.EnumC0522a;
import java.util.List;
import k5.AbstractC0567h;
import x5.InterfaceC0913u;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* loaded from: classes.dex */
public final class i extends AbstractC0567h implements p5.p {

    /* renamed from: s, reason: collision with root package name */
    public final /* synthetic */ int f3660s;

    /* renamed from: t, reason: collision with root package name */
    public int f3661t;

    /* renamed from: u, reason: collision with root package name */
    public final /* synthetic */ B f3662u;

    /* renamed from: v, reason: collision with root package name */
    public final /* synthetic */ List f3663v;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public /* synthetic */ i(B b6, List list, i5.d dVar, int i6) {
        super(2, dVar);
        this.f3660s = i6;
        this.f3662u = b6;
        this.f3663v = list;
    }

    @Override // p5.p
    public final Object h(Object obj, Object obj2) {
        InterfaceC0913u interfaceC0913u = (InterfaceC0913u) obj;
        i5.d dVar = (i5.d) obj2;
        switch (this.f3660s) {
            case 0:
                return ((i) m(dVar, interfaceC0913u)).p(g5.h.f6800a);
            case 1:
                return ((i) m(dVar, interfaceC0913u)).p(g5.h.f6800a);
            default:
                return ((i) m(dVar, interfaceC0913u)).p(g5.h.f6800a);
        }
    }

    @Override // k5.AbstractC0560a
    public final i5.d m(i5.d dVar, Object obj) {
        switch (this.f3660s) {
            case 0:
                return new i(this.f3662u, this.f3663v, dVar, 0);
            case 1:
                return new i(this.f3662u, this.f3663v, dVar, 1);
            default:
                return new i(this.f3662u, this.f3663v, dVar, 2);
        }
    }

    @Override // k5.AbstractC0560a
    public final Object p(Object obj) {
        switch (this.f3660s) {
            case 0:
                int i6 = this.f3661t;
                if (i6 != 0) {
                    if (i6 == 1) {
                        Q5.a.K(obj);
                        return obj;
                    }
                    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                Q5.a.K(obj);
                Context context = this.f3662u.o;
                i5.d dVar = null;
                if (context != null) {
                    InterfaceC0087g a6 = C.a(context);
                    C0095o c0095o = new C0095o(this.f3663v, dVar, 1);
                    this.f3661t = 1;
                    Object b6 = ((x3.c) a6).b(new M.c(c0095o, null, 1), this);
                    EnumC0522a enumC0522a = EnumC0522a.o;
                    if (b6 == enumC0522a) {
                        return enumC0522a;
                    }
                    return b6;
                }
                q5.h.h("context");
                throw null;
            case 1:
                int i7 = this.f3661t;
                if (i7 != 0) {
                    if (i7 == 1) {
                        Q5.a.K(obj);
                        return obj;
                    }
                    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                Q5.a.K(obj);
                this.f3661t = 1;
                Object b7 = B.b(this.f3662u, this.f3663v, this);
                EnumC0522a enumC0522a2 = EnumC0522a.o;
                if (b7 == enumC0522a2) {
                    return enumC0522a2;
                }
                return b7;
            default:
                int i8 = this.f3661t;
                if (i8 != 0) {
                    if (i8 == 1) {
                        Q5.a.K(obj);
                        return obj;
                    }
                    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                Q5.a.K(obj);
                this.f3661t = 1;
                Object b8 = B.b(this.f3662u, this.f3663v, this);
                EnumC0522a enumC0522a3 = EnumC0522a.o;
                if (b8 == enumC0522a3) {
                    return enumC0522a3;
                }
                return b8;
        }
    }
}
