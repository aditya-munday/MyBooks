package X4;

import k5.AbstractC0567h;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* loaded from: classes.dex */
public final class j extends AbstractC0567h implements p5.p {

    /* renamed from: s, reason: collision with root package name */
    public /* synthetic */ Object f3664s;

    /* renamed from: t, reason: collision with root package name */
    public final /* synthetic */ M.d f3665t;

    /* renamed from: u, reason: collision with root package name */
    public final /* synthetic */ String f3666u;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public j(M.d dVar, String str, i5.d dVar2) {
        super(2, dVar2);
        this.f3665t = dVar;
        this.f3666u = str;
    }

    @Override // p5.p
    public final Object h(Object obj, Object obj2) {
        j jVar = (j) m((i5.d) obj2, (M.b) obj);
        g5.h hVar = g5.h.f6800a;
        jVar.p(hVar);
        return hVar;
    }

    @Override // k5.AbstractC0560a
    public final i5.d m(i5.d dVar, Object obj) {
        j jVar = new j(this.f3665t, this.f3666u, dVar);
        jVar.f3664s = obj;
        return jVar;
    }

    @Override // k5.AbstractC0560a
    public final Object p(Object obj) {
        M.b bVar = (M.b) this.f3664s;
        Q5.a.K(obj);
        bVar.d(this.f3665t, this.f3666u);
        return g5.h.f6800a;
    }
}
