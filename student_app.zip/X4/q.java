package X4;

import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import k5.AbstractC0562c;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* loaded from: classes.dex */
public final class q extends AbstractC0562c {

    /* renamed from: r, reason: collision with root package name */
    public Set f3686r;

    /* renamed from: s, reason: collision with root package name */
    public Map f3687s;

    /* renamed from: t, reason: collision with root package name */
    public Iterator f3688t;

    /* renamed from: u, reason: collision with root package name */
    public M.d f3689u;

    /* renamed from: v, reason: collision with root package name */
    public int f3690v;

    /* renamed from: w, reason: collision with root package name */
    public /* synthetic */ Object f3691w;

    /* renamed from: x, reason: collision with root package name */
    public final /* synthetic */ B f3692x;
    public int y;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public q(B b6, AbstractC0562c abstractC0562c) {
        super(abstractC0562c);
        this.f3692x = b6;
    }

    @Override // k5.AbstractC0560a
    public final Object p(Object obj) {
        this.f3691w = obj;
        this.y |= Integer.MIN_VALUE;
        return B.b(this.f3692x, null, this);
    }
}
