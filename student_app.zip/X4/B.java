package X4;

import J.InterfaceC0087g;
import android.content.Context;
import android.util.Log;
import h5.AbstractC0470d;
import j5.EnumC0522a;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import k5.AbstractC0562c;
import k5.AbstractC0567h;
import x5.AbstractC0915w;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* loaded from: classes.dex */
public final class B implements I4.b, InterfaceC0168f {
    public Context o;

    /* renamed from: p, reason: collision with root package name */
    public g f3638p;

    /* renamed from: q, reason: collision with root package name */
    public final m3.e f3639q = new m3.e(24);

    public static final Object a(B b6, String str, String str2, AbstractC0567h abstractC0567h) {
        M.d dVar = new M.d(str);
        Context context = b6.o;
        if (context != null) {
            Object b7 = ((x3.c) C.a(context)).b(new M.c(new j(dVar, str2, null), null, 1), abstractC0567h);
            if (b7 == EnumC0522a.o) {
                return b7;
            }
            return g5.h.f6800a;
        }
        q5.h.h("context");
        throw null;
    }

    /* JADX WARN: Code restructure failed: missing block: B:18:0x00c1, code lost:
    
        if (r13 == r6) goto L34;
     */
    /* JADX WARN: Code restructure failed: missing block: B:19:0x00c3, code lost:
    
        return r6;
     */
    /* JADX WARN: Code restructure failed: missing block: B:40:0x007c, code lost:
    
        if (r13 == r6) goto L34;
     */
    /* JADX WARN: Removed duplicated region for block: B:15:0x0092  */
    /* JADX WARN: Removed duplicated region for block: B:23:0x00de A[RETURN] */
    /* JADX WARN: Removed duplicated region for block: B:32:0x0083  */
    /* JADX WARN: Removed duplicated region for block: B:33:0x00df A[RETURN] */
    /* JADX WARN: Removed duplicated region for block: B:34:0x0048  */
    /* JADX WARN: Removed duplicated region for block: B:8:0x0025  */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:18:0x00c1 -> B:11:0x00c4). Please report as a decompilation issue!!! */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public static final Object b(B b6, List list, AbstractC0562c abstractC0562c) {
        q qVar;
        int i6;
        Set set;
        Map linkedHashMap;
        Set set2;
        Map map;
        Set set3;
        int i7;
        Iterator it;
        Object c6;
        if (abstractC0562c instanceof q) {
            qVar = (q) abstractC0562c;
            int i8 = qVar.y;
            if ((i8 & Integer.MIN_VALUE) != 0) {
                qVar.y = i8 - Integer.MIN_VALUE;
                Object obj = qVar.f3691w;
                i6 = qVar.y;
                EnumC0522a enumC0522a = EnumC0522a.o;
                if (i6 == 0) {
                    if (i6 != 1) {
                        if (i6 == 2) {
                            i7 = qVar.f3690v;
                            M.d dVar = qVar.f3689u;
                            it = qVar.f3688t;
                            map = qVar.f3687s;
                            set3 = qVar.f3686r;
                            Q5.a.K(obj);
                            if (C.b(dVar.f1707a, obj, set3) && (c6 = C.c(obj, b6.f3639q)) != null) {
                                map.put(dVar.f1707a, c6);
                            }
                            if (!it.hasNext()) {
                                dVar = (M.d) it.next();
                                qVar.f3686r = set3;
                                qVar.f3687s = map;
                                qVar.f3688t = it;
                                qVar.f3689u = dVar;
                                qVar.f3690v = i7;
                                qVar.y = 2;
                                Context context = b6.o;
                                if (context != null) {
                                    obj = A5.s.c(new m(((InterfaceC0087g) ((x3.c) C.a(context)).f10281p).getData(), dVar, 3), qVar);
                                } else {
                                    q5.h.h("context");
                                    throw null;
                                }
                            } else {
                                return map;
                            }
                        } else {
                            throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                        }
                    } else {
                        linkedHashMap = qVar.f3687s;
                        set = qVar.f3686r;
                        Q5.a.K(obj);
                    }
                } else {
                    Q5.a.K(obj);
                    if (list != null) {
                        set = AbstractC0470d.f0(list);
                    } else {
                        set = null;
                    }
                    linkedHashMap = new LinkedHashMap();
                    qVar.f3686r = set;
                    qVar.f3687s = linkedHashMap;
                    qVar.y = 1;
                    Context context2 = b6.o;
                    if (context2 != null) {
                        obj = A5.s.c(new A1.l(((InterfaceC0087g) ((x3.c) C.a(context2)).f10281p).getData(), 28), qVar);
                    } else {
                        q5.h.h("context");
                        throw null;
                    }
                }
                set2 = (Set) obj;
                if (set2 == null) {
                    map = linkedHashMap;
                    set3 = set;
                    i7 = 0;
                    it = set2.iterator();
                    if (!it.hasNext()) {
                    }
                } else {
                    return linkedHashMap;
                }
            }
        }
        qVar = new q(b6, abstractC0562c);
        Object obj2 = qVar.f3691w;
        i6 = qVar.y;
        EnumC0522a enumC0522a2 = EnumC0522a.o;
        if (i6 == 0) {
        }
        set2 = (Set) obj2;
        if (set2 == null) {
        }
    }

    /* JADX WARN: Type inference failed for: r3v0, types: [q5.p, java.lang.Object] */
    @Override // X4.InterfaceC0168f
    public final Double d(String str, h hVar) {
        ?? obj = new Object();
        AbstractC0915w.j(new n(str, this, obj, null, 1));
        return (Double) obj.o;
    }

    @Override // X4.InterfaceC0168f
    public final List f(List list, h hVar) {
        return AbstractC0470d.d0(((Map) AbstractC0915w.j(new i(this, list, null, 2))).keySet());
    }

    @Override // X4.InterfaceC0168f
    public final void g(String str, String str2, h hVar) {
        AbstractC0915w.j(new w(this, str, str2, null, 2));
    }

    /* JADX WARN: Type inference failed for: r3v0, types: [q5.p, java.lang.Object] */
    @Override // X4.InterfaceC0168f
    public final Boolean h(String str, h hVar) {
        ?? obj = new Object();
        AbstractC0915w.j(new n(str, this, obj, null, 0));
        return (Boolean) obj.o;
    }

    @Override // X4.InterfaceC0168f
    public final void i(String str, boolean z6, h hVar) {
        AbstractC0915w.j(new v(str, this, z6, null));
    }

    /* JADX WARN: Type inference failed for: r3v0, types: [q5.p, java.lang.Object] */
    @Override // X4.InterfaceC0168f
    public final String j(String str, h hVar) {
        ?? obj = new Object();
        AbstractC0915w.j(new n(str, this, obj, null, 3));
        return (String) obj.o;
    }

    @Override // X4.InterfaceC0168f
    public final ArrayList l(String str, h hVar) {
        List list;
        String j6 = j(str, hVar);
        if (j6 != null && !j6.startsWith("VGhpcyBpcyB0aGUgcHJlZml4IGZvciBhIGxpc3Qu!") && j6.startsWith("VGhpcyBpcyB0aGUgcHJlZml4IGZvciBhIGxpc3Qu") && (list = (List) C.c(j6, this.f3639q)) != null) {
            ArrayList arrayList = new ArrayList();
            for (Object obj : list) {
                if (obj instanceof String) {
                    arrayList.add(obj);
                }
            }
            return arrayList;
        }
        return null;
    }

    /* JADX WARN: Type inference failed for: r3v0, types: [q5.p, java.lang.Object] */
    @Override // X4.InterfaceC0168f
    public final Long m(String str, h hVar) {
        ?? obj = new Object();
        AbstractC0915w.j(new n(str, this, obj, null, 2));
        return (Long) obj.o;
    }

    @Override // X4.InterfaceC0168f
    public final void n(String str, List list, h hVar) {
        AbstractC0915w.j(new w(this, str, "VGhpcyBpcyB0aGUgcHJlZml4IGZvciBhIGxpc3Qu".concat(this.f3639q.m(list)), null, 0));
    }

    @Override // X4.InterfaceC0168f
    public final void o(String str, double d6, h hVar) {
        AbstractC0915w.j(new y(str, this, d6, null));
    }

    @Override // I4.b
    public final void onAttachedToEngine(I4.a aVar) {
        q5.h.e(aVar, "binding");
        M4.f fVar = aVar.f1091b;
        q5.h.d(fVar, "getBinaryMessenger(...)");
        Context context = aVar.f1090a;
        q5.h.d(context, "getApplicationContext(...)");
        this.o = context;
        try {
            InterfaceC0168f.e.getClass();
            C0167e.b(fVar, this, "data_store");
            this.f3638p = new g(fVar, context, this.f3639q);
        } catch (Exception e) {
            Log.e("SharedPreferencesPlugin", "Received exception while setting up SharedPreferencesPlugin", e);
        }
        new C0163a().onAttachedToEngine(aVar);
    }

    @Override // I4.b
    public final void onDetachedFromEngine(I4.a aVar) {
        q5.h.e(aVar, "binding");
        M4.f fVar = aVar.f1091b;
        q5.h.d(fVar, "getBinaryMessenger(...)");
        InterfaceC0168f.e.getClass();
        C0167e.b(fVar, null, "data_store");
        g gVar = this.f3638p;
        if (gVar != null) {
            C0167e.b((M4.f) gVar.f3655p, null, "shared_preferences");
        }
        this.f3638p = null;
    }

    @Override // X4.InterfaceC0168f
    public final void p(String str, String str2, h hVar) {
        AbstractC0915w.j(new w(this, str, str2, null, 1));
    }

    @Override // X4.InterfaceC0168f
    public final F r(String str, h hVar) {
        String j6 = j(str, hVar);
        if (j6 == null) {
            return null;
        }
        if (j6.startsWith("VGhpcyBpcyB0aGUgcHJlZml4IGZvciBhIGxpc3Qu!")) {
            return new F(j6, D.f3644r);
        }
        if (j6.startsWith("VGhpcyBpcyB0aGUgcHJlZml4IGZvciBhIGxpc3Qu")) {
            return new F(null, D.f3643q);
        }
        return new F(null, D.f3645s);
    }

    @Override // X4.InterfaceC0168f
    public final void s(List list, h hVar) {
        AbstractC0915w.j(new i(this, list, null, 0));
    }

    @Override // X4.InterfaceC0168f
    public final Map t(List list, h hVar) {
        return (Map) AbstractC0915w.j(new i(this, list, null, 1));
    }

    @Override // X4.InterfaceC0168f
    public final void u(String str, long j6, h hVar) {
        AbstractC0915w.j(new A(str, this, j6, null));
    }
}
