package X4;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* renamed from: X4.f, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public interface InterfaceC0168f {
    public static final C0167e e = C0167e.f3653a;

    Double d(String str, h hVar);

    List f(List list, h hVar);

    void g(String str, String str2, h hVar);

    Boolean h(String str, h hVar);

    void i(String str, boolean z6, h hVar);

    String j(String str, h hVar);

    ArrayList l(String str, h hVar);

    Long m(String str, h hVar);

    void n(String str, List list, h hVar);

    void o(String str, double d6, h hVar);

    void p(String str, String str2, h hVar);

    F r(String str, h hVar);

    void s(List list, h hVar);

    Map t(List list, h hVar);

    void u(String str, long j6, h hVar);
}
