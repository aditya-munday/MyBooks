package X4;

import C4.AbstractC0034i;
import android.util.Log;
import g5.C0457f;
import j2.C0508g;
import java.util.List;
import org.apache.tika.fork.ContentHandlerProxy;
import org.apache.tika.utils.StringUtils;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* renamed from: X4.e, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0167e {

    /* renamed from: a, reason: collision with root package name */
    public static final /* synthetic */ C0167e f3653a = new Object();

    /* renamed from: b, reason: collision with root package name */
    public static final C0457f f3654b = new C0457f(new defpackage.c(1));

    public static M4.l a() {
        return (M4.l) f3654b.a();
    }

    public static void b(M4.f fVar, final InterfaceC0168f interfaceC0168f, String str) {
        String str2;
        q5.h.e(fVar, "binaryMessenger");
        if (str.length() > 0) {
            str2 = ".".concat(str);
        } else {
            str2 = StringUtils.EMPTY;
        }
        C0508g c6 = fVar.c();
        v3.u uVar = new v3.u(fVar, AbstractC0034i.j("dev.flutter.pigeon.shared_preferences_android.SharedPreferencesAsyncApi.setBool", str2), a(), c6);
        if (interfaceC0168f != null) {
            final int i6 = 6;
            uVar.y(new M4.b() { // from class: X4.d
                @Override // M4.b
                public final void e(Object obj, A.c cVar) {
                    List T6;
                    List T7;
                    List T8;
                    List T9;
                    List T10;
                    List T11;
                    List T12;
                    List T13;
                    List T14;
                    List T15;
                    List T16;
                    List T17;
                    List T18;
                    List T19;
                    List T20;
                    switch (i6) {
                        case 0:
                            InterfaceC0168f interfaceC0168f2 = interfaceC0168f;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list = (List) obj;
                            Object obj2 = list.get(0);
                            q5.h.c(obj2, "null cannot be cast to non-null type kotlin.String");
                            String str3 = (String) obj2;
                            Object obj3 = list.get(1);
                            q5.h.c(obj3, "null cannot be cast to non-null type kotlin.String");
                            String str4 = (String) obj3;
                            Object obj4 = list.get(2);
                            q5.h.c(obj4, "null cannot be cast to non-null type io.flutter.plugins.sharedpreferences.SharedPreferencesPigeonOptions");
                            try {
                                interfaceC0168f2.p(str3, str4, (h) obj4);
                                T6 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th) {
                                T6 = h5.e.T(th.getClass().getSimpleName(), th.toString(), AbstractC0034i.k("Cause: ", th.getCause(), ", Stacktrace: ", Log.getStackTraceString(th)));
                            }
                            cVar.g(T6);
                            return;
                        case 1:
                            InterfaceC0168f interfaceC0168f3 = interfaceC0168f;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list2 = (List) obj;
                            Object obj5 = list2.get(0);
                            q5.h.c(obj5, "null cannot be cast to non-null type kotlin.String");
                            String str5 = (String) obj5;
                            Object obj6 = list2.get(1);
                            q5.h.c(obj6, "null cannot be cast to non-null type kotlin.collections.List<kotlin.String>");
                            List list3 = (List) obj6;
                            Object obj7 = list2.get(2);
                            q5.h.c(obj7, "null cannot be cast to non-null type io.flutter.plugins.sharedpreferences.SharedPreferencesPigeonOptions");
                            try {
                                interfaceC0168f3.n(str5, list3, (h) obj7);
                                T7 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th2) {
                                T7 = h5.e.T(th2.getClass().getSimpleName(), th2.toString(), AbstractC0034i.k("Cause: ", th2.getCause(), ", Stacktrace: ", Log.getStackTraceString(th2)));
                            }
                            cVar.g(T7);
                            return;
                        case 2:
                            InterfaceC0168f interfaceC0168f4 = interfaceC0168f;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list4 = (List) obj;
                            Object obj8 = list4.get(0);
                            q5.h.c(obj8, "null cannot be cast to non-null type kotlin.String");
                            String str6 = (String) obj8;
                            Object obj9 = list4.get(1);
                            q5.h.c(obj9, "null cannot be cast to non-null type io.flutter.plugins.sharedpreferences.SharedPreferencesPigeonOptions");
                            try {
                                T8 = android.support.v4.media.session.a.z(interfaceC0168f4.j(str6, (h) obj9));
                            } catch (Throwable th3) {
                                T8 = h5.e.T(th3.getClass().getSimpleName(), th3.toString(), AbstractC0034i.k("Cause: ", th3.getCause(), ", Stacktrace: ", Log.getStackTraceString(th3)));
                            }
                            cVar.g(T8);
                            return;
                        case 3:
                            InterfaceC0168f interfaceC0168f5 = interfaceC0168f;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list5 = (List) obj;
                            Object obj10 = list5.get(0);
                            q5.h.c(obj10, "null cannot be cast to non-null type kotlin.String");
                            String str7 = (String) obj10;
                            Object obj11 = list5.get(1);
                            q5.h.c(obj11, "null cannot be cast to non-null type io.flutter.plugins.sharedpreferences.SharedPreferencesPigeonOptions");
                            try {
                                T9 = android.support.v4.media.session.a.z(interfaceC0168f5.h(str7, (h) obj11));
                            } catch (Throwable th4) {
                                T9 = h5.e.T(th4.getClass().getSimpleName(), th4.toString(), AbstractC0034i.k("Cause: ", th4.getCause(), ", Stacktrace: ", Log.getStackTraceString(th4)));
                            }
                            cVar.g(T9);
                            return;
                        case 4:
                            InterfaceC0168f interfaceC0168f6 = interfaceC0168f;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list6 = (List) obj;
                            Object obj12 = list6.get(0);
                            q5.h.c(obj12, "null cannot be cast to non-null type kotlin.String");
                            String str8 = (String) obj12;
                            Object obj13 = list6.get(1);
                            q5.h.c(obj13, "null cannot be cast to non-null type io.flutter.plugins.sharedpreferences.SharedPreferencesPigeonOptions");
                            try {
                                T10 = android.support.v4.media.session.a.z(interfaceC0168f6.d(str8, (h) obj13));
                            } catch (Throwable th5) {
                                T10 = h5.e.T(th5.getClass().getSimpleName(), th5.toString(), AbstractC0034i.k("Cause: ", th5.getCause(), ", Stacktrace: ", Log.getStackTraceString(th5)));
                            }
                            cVar.g(T10);
                            return;
                        case 5:
                            InterfaceC0168f interfaceC0168f7 = interfaceC0168f;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list7 = (List) obj;
                            Object obj14 = list7.get(0);
                            q5.h.c(obj14, "null cannot be cast to non-null type kotlin.String");
                            String str9 = (String) obj14;
                            Object obj15 = list7.get(1);
                            q5.h.c(obj15, "null cannot be cast to non-null type io.flutter.plugins.sharedpreferences.SharedPreferencesPigeonOptions");
                            try {
                                T11 = android.support.v4.media.session.a.z(interfaceC0168f7.m(str9, (h) obj15));
                            } catch (Throwable th6) {
                                T11 = h5.e.T(th6.getClass().getSimpleName(), th6.toString(), AbstractC0034i.k("Cause: ", th6.getCause(), ", Stacktrace: ", Log.getStackTraceString(th6)));
                            }
                            cVar.g(T11);
                            return;
                        case 6:
                            InterfaceC0168f interfaceC0168f8 = interfaceC0168f;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list8 = (List) obj;
                            Object obj16 = list8.get(0);
                            q5.h.c(obj16, "null cannot be cast to non-null type kotlin.String");
                            String str10 = (String) obj16;
                            Object obj17 = list8.get(1);
                            q5.h.c(obj17, "null cannot be cast to non-null type kotlin.Boolean");
                            boolean booleanValue = ((Boolean) obj17).booleanValue();
                            Object obj18 = list8.get(2);
                            q5.h.c(obj18, "null cannot be cast to non-null type io.flutter.plugins.sharedpreferences.SharedPreferencesPigeonOptions");
                            try {
                                interfaceC0168f8.i(str10, booleanValue, (h) obj18);
                                T12 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th7) {
                                T12 = h5.e.T(th7.getClass().getSimpleName(), th7.toString(), AbstractC0034i.k("Cause: ", th7.getCause(), ", Stacktrace: ", Log.getStackTraceString(th7)));
                            }
                            cVar.g(T12);
                            return;
                        case 7:
                            InterfaceC0168f interfaceC0168f9 = interfaceC0168f;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list9 = (List) obj;
                            Object obj19 = list9.get(0);
                            q5.h.c(obj19, "null cannot be cast to non-null type kotlin.String");
                            String str11 = (String) obj19;
                            Object obj20 = list9.get(1);
                            q5.h.c(obj20, "null cannot be cast to non-null type io.flutter.plugins.sharedpreferences.SharedPreferencesPigeonOptions");
                            try {
                                T13 = android.support.v4.media.session.a.z(interfaceC0168f9.l(str11, (h) obj20));
                            } catch (Throwable th8) {
                                T13 = h5.e.T(th8.getClass().getSimpleName(), th8.toString(), AbstractC0034i.k("Cause: ", th8.getCause(), ", Stacktrace: ", Log.getStackTraceString(th8)));
                            }
                            cVar.g(T13);
                            return;
                        case 8:
                            InterfaceC0168f interfaceC0168f10 = interfaceC0168f;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list10 = (List) obj;
                            Object obj21 = list10.get(0);
                            q5.h.c(obj21, "null cannot be cast to non-null type kotlin.String");
                            String str12 = (String) obj21;
                            Object obj22 = list10.get(1);
                            q5.h.c(obj22, "null cannot be cast to non-null type io.flutter.plugins.sharedpreferences.SharedPreferencesPigeonOptions");
                            try {
                                T14 = android.support.v4.media.session.a.z(interfaceC0168f10.r(str12, (h) obj22));
                            } catch (Throwable th9) {
                                T14 = h5.e.T(th9.getClass().getSimpleName(), th9.toString(), AbstractC0034i.k("Cause: ", th9.getCause(), ", Stacktrace: ", Log.getStackTraceString(th9)));
                            }
                            cVar.g(T14);
                            return;
                        case ContentHandlerProxy.PROCESSING_INSTRUCTION /* 9 */:
                            InterfaceC0168f interfaceC0168f11 = interfaceC0168f;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list11 = (List) obj;
                            List list12 = (List) list11.get(0);
                            Object obj23 = list11.get(1);
                            q5.h.c(obj23, "null cannot be cast to non-null type io.flutter.plugins.sharedpreferences.SharedPreferencesPigeonOptions");
                            try {
                                interfaceC0168f11.s(list12, (h) obj23);
                                T15 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th10) {
                                T15 = h5.e.T(th10.getClass().getSimpleName(), th10.toString(), AbstractC0034i.k("Cause: ", th10.getCause(), ", Stacktrace: ", Log.getStackTraceString(th10)));
                            }
                            cVar.g(T15);
                            return;
                        case 10:
                            InterfaceC0168f interfaceC0168f12 = interfaceC0168f;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list13 = (List) obj;
                            List list14 = (List) list13.get(0);
                            Object obj24 = list13.get(1);
                            q5.h.c(obj24, "null cannot be cast to non-null type io.flutter.plugins.sharedpreferences.SharedPreferencesPigeonOptions");
                            try {
                                T16 = android.support.v4.media.session.a.z(interfaceC0168f12.t(list14, (h) obj24));
                            } catch (Throwable th11) {
                                T16 = h5.e.T(th11.getClass().getSimpleName(), th11.toString(), AbstractC0034i.k("Cause: ", th11.getCause(), ", Stacktrace: ", Log.getStackTraceString(th11)));
                            }
                            cVar.g(T16);
                            return;
                        case 11:
                            InterfaceC0168f interfaceC0168f13 = interfaceC0168f;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list15 = (List) obj;
                            List list16 = (List) list15.get(0);
                            Object obj25 = list15.get(1);
                            q5.h.c(obj25, "null cannot be cast to non-null type io.flutter.plugins.sharedpreferences.SharedPreferencesPigeonOptions");
                            try {
                                T17 = android.support.v4.media.session.a.z(interfaceC0168f13.f(list16, (h) obj25));
                            } catch (Throwable th12) {
                                T17 = h5.e.T(th12.getClass().getSimpleName(), th12.toString(), AbstractC0034i.k("Cause: ", th12.getCause(), ", Stacktrace: ", Log.getStackTraceString(th12)));
                            }
                            cVar.g(T17);
                            return;
                        case 12:
                            InterfaceC0168f interfaceC0168f14 = interfaceC0168f;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list17 = (List) obj;
                            Object obj26 = list17.get(0);
                            q5.h.c(obj26, "null cannot be cast to non-null type kotlin.String");
                            String str13 = (String) obj26;
                            Object obj27 = list17.get(1);
                            q5.h.c(obj27, "null cannot be cast to non-null type kotlin.String");
                            String str14 = (String) obj27;
                            Object obj28 = list17.get(2);
                            q5.h.c(obj28, "null cannot be cast to non-null type io.flutter.plugins.sharedpreferences.SharedPreferencesPigeonOptions");
                            try {
                                interfaceC0168f14.g(str13, str14, (h) obj28);
                                T18 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th13) {
                                T18 = h5.e.T(th13.getClass().getSimpleName(), th13.toString(), AbstractC0034i.k("Cause: ", th13.getCause(), ", Stacktrace: ", Log.getStackTraceString(th13)));
                            }
                            cVar.g(T18);
                            return;
                        case 13:
                            InterfaceC0168f interfaceC0168f15 = interfaceC0168f;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list18 = (List) obj;
                            Object obj29 = list18.get(0);
                            q5.h.c(obj29, "null cannot be cast to non-null type kotlin.String");
                            String str15 = (String) obj29;
                            Object obj30 = list18.get(1);
                            q5.h.c(obj30, "null cannot be cast to non-null type kotlin.Long");
                            long longValue = ((Long) obj30).longValue();
                            Object obj31 = list18.get(2);
                            q5.h.c(obj31, "null cannot be cast to non-null type io.flutter.plugins.sharedpreferences.SharedPreferencesPigeonOptions");
                            try {
                                interfaceC0168f15.u(str15, longValue, (h) obj31);
                                T19 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th14) {
                                T19 = h5.e.T(th14.getClass().getSimpleName(), th14.toString(), AbstractC0034i.k("Cause: ", th14.getCause(), ", Stacktrace: ", Log.getStackTraceString(th14)));
                            }
                            cVar.g(T19);
                            return;
                        default:
                            InterfaceC0168f interfaceC0168f16 = interfaceC0168f;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list19 = (List) obj;
                            Object obj32 = list19.get(0);
                            q5.h.c(obj32, "null cannot be cast to non-null type kotlin.String");
                            String str16 = (String) obj32;
                            Object obj33 = list19.get(1);
                            q5.h.c(obj33, "null cannot be cast to non-null type kotlin.Double");
                            double doubleValue = ((Double) obj33).doubleValue();
                            Object obj34 = list19.get(2);
                            q5.h.c(obj34, "null cannot be cast to non-null type io.flutter.plugins.sharedpreferences.SharedPreferencesPigeonOptions");
                            try {
                                interfaceC0168f16.o(str16, doubleValue, (h) obj34);
                                T20 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th15) {
                                T20 = h5.e.T(th15.getClass().getSimpleName(), th15.toString(), AbstractC0034i.k("Cause: ", th15.getCause(), ", Stacktrace: ", Log.getStackTraceString(th15)));
                            }
                            cVar.g(T20);
                            return;
                    }
                }
            });
        } else {
            uVar.y(null);
        }
        v3.u uVar2 = new v3.u(fVar, AbstractC0034i.j("dev.flutter.pigeon.shared_preferences_android.SharedPreferencesAsyncApi.setString", str2), a(), c6);
        if (interfaceC0168f != null) {
            final int i7 = 12;
            uVar2.y(new M4.b() { // from class: X4.d
                @Override // M4.b
                public final void e(Object obj, A.c cVar) {
                    List T6;
                    List T7;
                    List T8;
                    List T9;
                    List T10;
                    List T11;
                    List T12;
                    List T13;
                    List T14;
                    List T15;
                    List T16;
                    List T17;
                    List T18;
                    List T19;
                    List T20;
                    switch (i7) {
                        case 0:
                            InterfaceC0168f interfaceC0168f2 = interfaceC0168f;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list = (List) obj;
                            Object obj2 = list.get(0);
                            q5.h.c(obj2, "null cannot be cast to non-null type kotlin.String");
                            String str3 = (String) obj2;
                            Object obj3 = list.get(1);
                            q5.h.c(obj3, "null cannot be cast to non-null type kotlin.String");
                            String str4 = (String) obj3;
                            Object obj4 = list.get(2);
                            q5.h.c(obj4, "null cannot be cast to non-null type io.flutter.plugins.sharedpreferences.SharedPreferencesPigeonOptions");
                            try {
                                interfaceC0168f2.p(str3, str4, (h) obj4);
                                T6 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th) {
                                T6 = h5.e.T(th.getClass().getSimpleName(), th.toString(), AbstractC0034i.k("Cause: ", th.getCause(), ", Stacktrace: ", Log.getStackTraceString(th)));
                            }
                            cVar.g(T6);
                            return;
                        case 1:
                            InterfaceC0168f interfaceC0168f3 = interfaceC0168f;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list2 = (List) obj;
                            Object obj5 = list2.get(0);
                            q5.h.c(obj5, "null cannot be cast to non-null type kotlin.String");
                            String str5 = (String) obj5;
                            Object obj6 = list2.get(1);
                            q5.h.c(obj6, "null cannot be cast to non-null type kotlin.collections.List<kotlin.String>");
                            List list3 = (List) obj6;
                            Object obj7 = list2.get(2);
                            q5.h.c(obj7, "null cannot be cast to non-null type io.flutter.plugins.sharedpreferences.SharedPreferencesPigeonOptions");
                            try {
                                interfaceC0168f3.n(str5, list3, (h) obj7);
                                T7 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th2) {
                                T7 = h5.e.T(th2.getClass().getSimpleName(), th2.toString(), AbstractC0034i.k("Cause: ", th2.getCause(), ", Stacktrace: ", Log.getStackTraceString(th2)));
                            }
                            cVar.g(T7);
                            return;
                        case 2:
                            InterfaceC0168f interfaceC0168f4 = interfaceC0168f;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list4 = (List) obj;
                            Object obj8 = list4.get(0);
                            q5.h.c(obj8, "null cannot be cast to non-null type kotlin.String");
                            String str6 = (String) obj8;
                            Object obj9 = list4.get(1);
                            q5.h.c(obj9, "null cannot be cast to non-null type io.flutter.plugins.sharedpreferences.SharedPreferencesPigeonOptions");
                            try {
                                T8 = android.support.v4.media.session.a.z(interfaceC0168f4.j(str6, (h) obj9));
                            } catch (Throwable th3) {
                                T8 = h5.e.T(th3.getClass().getSimpleName(), th3.toString(), AbstractC0034i.k("Cause: ", th3.getCause(), ", Stacktrace: ", Log.getStackTraceString(th3)));
                            }
                            cVar.g(T8);
                            return;
                        case 3:
                            InterfaceC0168f interfaceC0168f5 = interfaceC0168f;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list5 = (List) obj;
                            Object obj10 = list5.get(0);
                            q5.h.c(obj10, "null cannot be cast to non-null type kotlin.String");
                            String str7 = (String) obj10;
                            Object obj11 = list5.get(1);
                            q5.h.c(obj11, "null cannot be cast to non-null type io.flutter.plugins.sharedpreferences.SharedPreferencesPigeonOptions");
                            try {
                                T9 = android.support.v4.media.session.a.z(interfaceC0168f5.h(str7, (h) obj11));
                            } catch (Throwable th4) {
                                T9 = h5.e.T(th4.getClass().getSimpleName(), th4.toString(), AbstractC0034i.k("Cause: ", th4.getCause(), ", Stacktrace: ", Log.getStackTraceString(th4)));
                            }
                            cVar.g(T9);
                            return;
                        case 4:
                            InterfaceC0168f interfaceC0168f6 = interfaceC0168f;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list6 = (List) obj;
                            Object obj12 = list6.get(0);
                            q5.h.c(obj12, "null cannot be cast to non-null type kotlin.String");
                            String str8 = (String) obj12;
                            Object obj13 = list6.get(1);
                            q5.h.c(obj13, "null cannot be cast to non-null type io.flutter.plugins.sharedpreferences.SharedPreferencesPigeonOptions");
                            try {
                                T10 = android.support.v4.media.session.a.z(interfaceC0168f6.d(str8, (h) obj13));
                            } catch (Throwable th5) {
                                T10 = h5.e.T(th5.getClass().getSimpleName(), th5.toString(), AbstractC0034i.k("Cause: ", th5.getCause(), ", Stacktrace: ", Log.getStackTraceString(th5)));
                            }
                            cVar.g(T10);
                            return;
                        case 5:
                            InterfaceC0168f interfaceC0168f7 = interfaceC0168f;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list7 = (List) obj;
                            Object obj14 = list7.get(0);
                            q5.h.c(obj14, "null cannot be cast to non-null type kotlin.String");
                            String str9 = (String) obj14;
                            Object obj15 = list7.get(1);
                            q5.h.c(obj15, "null cannot be cast to non-null type io.flutter.plugins.sharedpreferences.SharedPreferencesPigeonOptions");
                            try {
                                T11 = android.support.v4.media.session.a.z(interfaceC0168f7.m(str9, (h) obj15));
                            } catch (Throwable th6) {
                                T11 = h5.e.T(th6.getClass().getSimpleName(), th6.toString(), AbstractC0034i.k("Cause: ", th6.getCause(), ", Stacktrace: ", Log.getStackTraceString(th6)));
                            }
                            cVar.g(T11);
                            return;
                        case 6:
                            InterfaceC0168f interfaceC0168f8 = interfaceC0168f;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list8 = (List) obj;
                            Object obj16 = list8.get(0);
                            q5.h.c(obj16, "null cannot be cast to non-null type kotlin.String");
                            String str10 = (String) obj16;
                            Object obj17 = list8.get(1);
                            q5.h.c(obj17, "null cannot be cast to non-null type kotlin.Boolean");
                            boolean booleanValue = ((Boolean) obj17).booleanValue();
                            Object obj18 = list8.get(2);
                            q5.h.c(obj18, "null cannot be cast to non-null type io.flutter.plugins.sharedpreferences.SharedPreferencesPigeonOptions");
                            try {
                                interfaceC0168f8.i(str10, booleanValue, (h) obj18);
                                T12 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th7) {
                                T12 = h5.e.T(th7.getClass().getSimpleName(), th7.toString(), AbstractC0034i.k("Cause: ", th7.getCause(), ", Stacktrace: ", Log.getStackTraceString(th7)));
                            }
                            cVar.g(T12);
                            return;
                        case 7:
                            InterfaceC0168f interfaceC0168f9 = interfaceC0168f;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list9 = (List) obj;
                            Object obj19 = list9.get(0);
                            q5.h.c(obj19, "null cannot be cast to non-null type kotlin.String");
                            String str11 = (String) obj19;
                            Object obj20 = list9.get(1);
                            q5.h.c(obj20, "null cannot be cast to non-null type io.flutter.plugins.sharedpreferences.SharedPreferencesPigeonOptions");
                            try {
                                T13 = android.support.v4.media.session.a.z(interfaceC0168f9.l(str11, (h) obj20));
                            } catch (Throwable th8) {
                                T13 = h5.e.T(th8.getClass().getSimpleName(), th8.toString(), AbstractC0034i.k("Cause: ", th8.getCause(), ", Stacktrace: ", Log.getStackTraceString(th8)));
                            }
                            cVar.g(T13);
                            return;
                        case 8:
                            InterfaceC0168f interfaceC0168f10 = interfaceC0168f;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list10 = (List) obj;
                            Object obj21 = list10.get(0);
                            q5.h.c(obj21, "null cannot be cast to non-null type kotlin.String");
                            String str12 = (String) obj21;
                            Object obj22 = list10.get(1);
                            q5.h.c(obj22, "null cannot be cast to non-null type io.flutter.plugins.sharedpreferences.SharedPreferencesPigeonOptions");
                            try {
                                T14 = android.support.v4.media.session.a.z(interfaceC0168f10.r(str12, (h) obj22));
                            } catch (Throwable th9) {
                                T14 = h5.e.T(th9.getClass().getSimpleName(), th9.toString(), AbstractC0034i.k("Cause: ", th9.getCause(), ", Stacktrace: ", Log.getStackTraceString(th9)));
                            }
                            cVar.g(T14);
                            return;
                        case ContentHandlerProxy.PROCESSING_INSTRUCTION /* 9 */:
                            InterfaceC0168f interfaceC0168f11 = interfaceC0168f;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list11 = (List) obj;
                            List list12 = (List) list11.get(0);
                            Object obj23 = list11.get(1);
                            q5.h.c(obj23, "null cannot be cast to non-null type io.flutter.plugins.sharedpreferences.SharedPreferencesPigeonOptions");
                            try {
                                interfaceC0168f11.s(list12, (h) obj23);
                                T15 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th10) {
                                T15 = h5.e.T(th10.getClass().getSimpleName(), th10.toString(), AbstractC0034i.k("Cause: ", th10.getCause(), ", Stacktrace: ", Log.getStackTraceString(th10)));
                            }
                            cVar.g(T15);
                            return;
                        case 10:
                            InterfaceC0168f interfaceC0168f12 = interfaceC0168f;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list13 = (List) obj;
                            List list14 = (List) list13.get(0);
                            Object obj24 = list13.get(1);
                            q5.h.c(obj24, "null cannot be cast to non-null type io.flutter.plugins.sharedpreferences.SharedPreferencesPigeonOptions");
                            try {
                                T16 = android.support.v4.media.session.a.z(interfaceC0168f12.t(list14, (h) obj24));
                            } catch (Throwable th11) {
                                T16 = h5.e.T(th11.getClass().getSimpleName(), th11.toString(), AbstractC0034i.k("Cause: ", th11.getCause(), ", Stacktrace: ", Log.getStackTraceString(th11)));
                            }
                            cVar.g(T16);
                            return;
                        case 11:
                            InterfaceC0168f interfaceC0168f13 = interfaceC0168f;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list15 = (List) obj;
                            List list16 = (List) list15.get(0);
                            Object obj25 = list15.get(1);
                            q5.h.c(obj25, "null cannot be cast to non-null type io.flutter.plugins.sharedpreferences.SharedPreferencesPigeonOptions");
                            try {
                                T17 = android.support.v4.media.session.a.z(interfaceC0168f13.f(list16, (h) obj25));
                            } catch (Throwable th12) {
                                T17 = h5.e.T(th12.getClass().getSimpleName(), th12.toString(), AbstractC0034i.k("Cause: ", th12.getCause(), ", Stacktrace: ", Log.getStackTraceString(th12)));
                            }
                            cVar.g(T17);
                            return;
                        case 12:
                            InterfaceC0168f interfaceC0168f14 = interfaceC0168f;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list17 = (List) obj;
                            Object obj26 = list17.get(0);
                            q5.h.c(obj26, "null cannot be cast to non-null type kotlin.String");
                            String str13 = (String) obj26;
                            Object obj27 = list17.get(1);
                            q5.h.c(obj27, "null cannot be cast to non-null type kotlin.String");
                            String str14 = (String) obj27;
                            Object obj28 = list17.get(2);
                            q5.h.c(obj28, "null cannot be cast to non-null type io.flutter.plugins.sharedpreferences.SharedPreferencesPigeonOptions");
                            try {
                                interfaceC0168f14.g(str13, str14, (h) obj28);
                                T18 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th13) {
                                T18 = h5.e.T(th13.getClass().getSimpleName(), th13.toString(), AbstractC0034i.k("Cause: ", th13.getCause(), ", Stacktrace: ", Log.getStackTraceString(th13)));
                            }
                            cVar.g(T18);
                            return;
                        case 13:
                            InterfaceC0168f interfaceC0168f15 = interfaceC0168f;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list18 = (List) obj;
                            Object obj29 = list18.get(0);
                            q5.h.c(obj29, "null cannot be cast to non-null type kotlin.String");
                            String str15 = (String) obj29;
                            Object obj30 = list18.get(1);
                            q5.h.c(obj30, "null cannot be cast to non-null type kotlin.Long");
                            long longValue = ((Long) obj30).longValue();
                            Object obj31 = list18.get(2);
                            q5.h.c(obj31, "null cannot be cast to non-null type io.flutter.plugins.sharedpreferences.SharedPreferencesPigeonOptions");
                            try {
                                interfaceC0168f15.u(str15, longValue, (h) obj31);
                                T19 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th14) {
                                T19 = h5.e.T(th14.getClass().getSimpleName(), th14.toString(), AbstractC0034i.k("Cause: ", th14.getCause(), ", Stacktrace: ", Log.getStackTraceString(th14)));
                            }
                            cVar.g(T19);
                            return;
                        default:
                            InterfaceC0168f interfaceC0168f16 = interfaceC0168f;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list19 = (List) obj;
                            Object obj32 = list19.get(0);
                            q5.h.c(obj32, "null cannot be cast to non-null type kotlin.String");
                            String str16 = (String) obj32;
                            Object obj33 = list19.get(1);
                            q5.h.c(obj33, "null cannot be cast to non-null type kotlin.Double");
                            double doubleValue = ((Double) obj33).doubleValue();
                            Object obj34 = list19.get(2);
                            q5.h.c(obj34, "null cannot be cast to non-null type io.flutter.plugins.sharedpreferences.SharedPreferencesPigeonOptions");
                            try {
                                interfaceC0168f16.o(str16, doubleValue, (h) obj34);
                                T20 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th15) {
                                T20 = h5.e.T(th15.getClass().getSimpleName(), th15.toString(), AbstractC0034i.k("Cause: ", th15.getCause(), ", Stacktrace: ", Log.getStackTraceString(th15)));
                            }
                            cVar.g(T20);
                            return;
                    }
                }
            });
        } else {
            uVar2.y(null);
        }
        v3.u uVar3 = new v3.u(fVar, AbstractC0034i.j("dev.flutter.pigeon.shared_preferences_android.SharedPreferencesAsyncApi.setInt", str2), a(), c6);
        if (interfaceC0168f != null) {
            final int i8 = 13;
            uVar3.y(new M4.b() { // from class: X4.d
                @Override // M4.b
                public final void e(Object obj, A.c cVar) {
                    List T6;
                    List T7;
                    List T8;
                    List T9;
                    List T10;
                    List T11;
                    List T12;
                    List T13;
                    List T14;
                    List T15;
                    List T16;
                    List T17;
                    List T18;
                    List T19;
                    List T20;
                    switch (i8) {
                        case 0:
                            InterfaceC0168f interfaceC0168f2 = interfaceC0168f;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list = (List) obj;
                            Object obj2 = list.get(0);
                            q5.h.c(obj2, "null cannot be cast to non-null type kotlin.String");
                            String str3 = (String) obj2;
                            Object obj3 = list.get(1);
                            q5.h.c(obj3, "null cannot be cast to non-null type kotlin.String");
                            String str4 = (String) obj3;
                            Object obj4 = list.get(2);
                            q5.h.c(obj4, "null cannot be cast to non-null type io.flutter.plugins.sharedpreferences.SharedPreferencesPigeonOptions");
                            try {
                                interfaceC0168f2.p(str3, str4, (h) obj4);
                                T6 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th) {
                                T6 = h5.e.T(th.getClass().getSimpleName(), th.toString(), AbstractC0034i.k("Cause: ", th.getCause(), ", Stacktrace: ", Log.getStackTraceString(th)));
                            }
                            cVar.g(T6);
                            return;
                        case 1:
                            InterfaceC0168f interfaceC0168f3 = interfaceC0168f;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list2 = (List) obj;
                            Object obj5 = list2.get(0);
                            q5.h.c(obj5, "null cannot be cast to non-null type kotlin.String");
                            String str5 = (String) obj5;
                            Object obj6 = list2.get(1);
                            q5.h.c(obj6, "null cannot be cast to non-null type kotlin.collections.List<kotlin.String>");
                            List list3 = (List) obj6;
                            Object obj7 = list2.get(2);
                            q5.h.c(obj7, "null cannot be cast to non-null type io.flutter.plugins.sharedpreferences.SharedPreferencesPigeonOptions");
                            try {
                                interfaceC0168f3.n(str5, list3, (h) obj7);
                                T7 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th2) {
                                T7 = h5.e.T(th2.getClass().getSimpleName(), th2.toString(), AbstractC0034i.k("Cause: ", th2.getCause(), ", Stacktrace: ", Log.getStackTraceString(th2)));
                            }
                            cVar.g(T7);
                            return;
                        case 2:
                            InterfaceC0168f interfaceC0168f4 = interfaceC0168f;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list4 = (List) obj;
                            Object obj8 = list4.get(0);
                            q5.h.c(obj8, "null cannot be cast to non-null type kotlin.String");
                            String str6 = (String) obj8;
                            Object obj9 = list4.get(1);
                            q5.h.c(obj9, "null cannot be cast to non-null type io.flutter.plugins.sharedpreferences.SharedPreferencesPigeonOptions");
                            try {
                                T8 = android.support.v4.media.session.a.z(interfaceC0168f4.j(str6, (h) obj9));
                            } catch (Throwable th3) {
                                T8 = h5.e.T(th3.getClass().getSimpleName(), th3.toString(), AbstractC0034i.k("Cause: ", th3.getCause(), ", Stacktrace: ", Log.getStackTraceString(th3)));
                            }
                            cVar.g(T8);
                            return;
                        case 3:
                            InterfaceC0168f interfaceC0168f5 = interfaceC0168f;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list5 = (List) obj;
                            Object obj10 = list5.get(0);
                            q5.h.c(obj10, "null cannot be cast to non-null type kotlin.String");
                            String str7 = (String) obj10;
                            Object obj11 = list5.get(1);
                            q5.h.c(obj11, "null cannot be cast to non-null type io.flutter.plugins.sharedpreferences.SharedPreferencesPigeonOptions");
                            try {
                                T9 = android.support.v4.media.session.a.z(interfaceC0168f5.h(str7, (h) obj11));
                            } catch (Throwable th4) {
                                T9 = h5.e.T(th4.getClass().getSimpleName(), th4.toString(), AbstractC0034i.k("Cause: ", th4.getCause(), ", Stacktrace: ", Log.getStackTraceString(th4)));
                            }
                            cVar.g(T9);
                            return;
                        case 4:
                            InterfaceC0168f interfaceC0168f6 = interfaceC0168f;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list6 = (List) obj;
                            Object obj12 = list6.get(0);
                            q5.h.c(obj12, "null cannot be cast to non-null type kotlin.String");
                            String str8 = (String) obj12;
                            Object obj13 = list6.get(1);
                            q5.h.c(obj13, "null cannot be cast to non-null type io.flutter.plugins.sharedpreferences.SharedPreferencesPigeonOptions");
                            try {
                                T10 = android.support.v4.media.session.a.z(interfaceC0168f6.d(str8, (h) obj13));
                            } catch (Throwable th5) {
                                T10 = h5.e.T(th5.getClass().getSimpleName(), th5.toString(), AbstractC0034i.k("Cause: ", th5.getCause(), ", Stacktrace: ", Log.getStackTraceString(th5)));
                            }
                            cVar.g(T10);
                            return;
                        case 5:
                            InterfaceC0168f interfaceC0168f7 = interfaceC0168f;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list7 = (List) obj;
                            Object obj14 = list7.get(0);
                            q5.h.c(obj14, "null cannot be cast to non-null type kotlin.String");
                            String str9 = (String) obj14;
                            Object obj15 = list7.get(1);
                            q5.h.c(obj15, "null cannot be cast to non-null type io.flutter.plugins.sharedpreferences.SharedPreferencesPigeonOptions");
                            try {
                                T11 = android.support.v4.media.session.a.z(interfaceC0168f7.m(str9, (h) obj15));
                            } catch (Throwable th6) {
                                T11 = h5.e.T(th6.getClass().getSimpleName(), th6.toString(), AbstractC0034i.k("Cause: ", th6.getCause(), ", Stacktrace: ", Log.getStackTraceString(th6)));
                            }
                            cVar.g(T11);
                            return;
                        case 6:
                            InterfaceC0168f interfaceC0168f8 = interfaceC0168f;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list8 = (List) obj;
                            Object obj16 = list8.get(0);
                            q5.h.c(obj16, "null cannot be cast to non-null type kotlin.String");
                            String str10 = (String) obj16;
                            Object obj17 = list8.get(1);
                            q5.h.c(obj17, "null cannot be cast to non-null type kotlin.Boolean");
                            boolean booleanValue = ((Boolean) obj17).booleanValue();
                            Object obj18 = list8.get(2);
                            q5.h.c(obj18, "null cannot be cast to non-null type io.flutter.plugins.sharedpreferences.SharedPreferencesPigeonOptions");
                            try {
                                interfaceC0168f8.i(str10, booleanValue, (h) obj18);
                                T12 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th7) {
                                T12 = h5.e.T(th7.getClass().getSimpleName(), th7.toString(), AbstractC0034i.k("Cause: ", th7.getCause(), ", Stacktrace: ", Log.getStackTraceString(th7)));
                            }
                            cVar.g(T12);
                            return;
                        case 7:
                            InterfaceC0168f interfaceC0168f9 = interfaceC0168f;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list9 = (List) obj;
                            Object obj19 = list9.get(0);
                            q5.h.c(obj19, "null cannot be cast to non-null type kotlin.String");
                            String str11 = (String) obj19;
                            Object obj20 = list9.get(1);
                            q5.h.c(obj20, "null cannot be cast to non-null type io.flutter.plugins.sharedpreferences.SharedPreferencesPigeonOptions");
                            try {
                                T13 = android.support.v4.media.session.a.z(interfaceC0168f9.l(str11, (h) obj20));
                            } catch (Throwable th8) {
                                T13 = h5.e.T(th8.getClass().getSimpleName(), th8.toString(), AbstractC0034i.k("Cause: ", th8.getCause(), ", Stacktrace: ", Log.getStackTraceString(th8)));
                            }
                            cVar.g(T13);
                            return;
                        case 8:
                            InterfaceC0168f interfaceC0168f10 = interfaceC0168f;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list10 = (List) obj;
                            Object obj21 = list10.get(0);
                            q5.h.c(obj21, "null cannot be cast to non-null type kotlin.String");
                            String str12 = (String) obj21;
                            Object obj22 = list10.get(1);
                            q5.h.c(obj22, "null cannot be cast to non-null type io.flutter.plugins.sharedpreferences.SharedPreferencesPigeonOptions");
                            try {
                                T14 = android.support.v4.media.session.a.z(interfaceC0168f10.r(str12, (h) obj22));
                            } catch (Throwable th9) {
                                T14 = h5.e.T(th9.getClass().getSimpleName(), th9.toString(), AbstractC0034i.k("Cause: ", th9.getCause(), ", Stacktrace: ", Log.getStackTraceString(th9)));
                            }
                            cVar.g(T14);
                            return;
                        case ContentHandlerProxy.PROCESSING_INSTRUCTION /* 9 */:
                            InterfaceC0168f interfaceC0168f11 = interfaceC0168f;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list11 = (List) obj;
                            List list12 = (List) list11.get(0);
                            Object obj23 = list11.get(1);
                            q5.h.c(obj23, "null cannot be cast to non-null type io.flutter.plugins.sharedpreferences.SharedPreferencesPigeonOptions");
                            try {
                                interfaceC0168f11.s(list12, (h) obj23);
                                T15 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th10) {
                                T15 = h5.e.T(th10.getClass().getSimpleName(), th10.toString(), AbstractC0034i.k("Cause: ", th10.getCause(), ", Stacktrace: ", Log.getStackTraceString(th10)));
                            }
                            cVar.g(T15);
                            return;
                        case 10:
                            InterfaceC0168f interfaceC0168f12 = interfaceC0168f;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list13 = (List) obj;
                            List list14 = (List) list13.get(0);
                            Object obj24 = list13.get(1);
                            q5.h.c(obj24, "null cannot be cast to non-null type io.flutter.plugins.sharedpreferences.SharedPreferencesPigeonOptions");
                            try {
                                T16 = android.support.v4.media.session.a.z(interfaceC0168f12.t(list14, (h) obj24));
                            } catch (Throwable th11) {
                                T16 = h5.e.T(th11.getClass().getSimpleName(), th11.toString(), AbstractC0034i.k("Cause: ", th11.getCause(), ", Stacktrace: ", Log.getStackTraceString(th11)));
                            }
                            cVar.g(T16);
                            return;
                        case 11:
                            InterfaceC0168f interfaceC0168f13 = interfaceC0168f;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list15 = (List) obj;
                            List list16 = (List) list15.get(0);
                            Object obj25 = list15.get(1);
                            q5.h.c(obj25, "null cannot be cast to non-null type io.flutter.plugins.sharedpreferences.SharedPreferencesPigeonOptions");
                            try {
                                T17 = android.support.v4.media.session.a.z(interfaceC0168f13.f(list16, (h) obj25));
                            } catch (Throwable th12) {
                                T17 = h5.e.T(th12.getClass().getSimpleName(), th12.toString(), AbstractC0034i.k("Cause: ", th12.getCause(), ", Stacktrace: ", Log.getStackTraceString(th12)));
                            }
                            cVar.g(T17);
                            return;
                        case 12:
                            InterfaceC0168f interfaceC0168f14 = interfaceC0168f;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list17 = (List) obj;
                            Object obj26 = list17.get(0);
                            q5.h.c(obj26, "null cannot be cast to non-null type kotlin.String");
                            String str13 = (String) obj26;
                            Object obj27 = list17.get(1);
                            q5.h.c(obj27, "null cannot be cast to non-null type kotlin.String");
                            String str14 = (String) obj27;
                            Object obj28 = list17.get(2);
                            q5.h.c(obj28, "null cannot be cast to non-null type io.flutter.plugins.sharedpreferences.SharedPreferencesPigeonOptions");
                            try {
                                interfaceC0168f14.g(str13, str14, (h) obj28);
                                T18 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th13) {
                                T18 = h5.e.T(th13.getClass().getSimpleName(), th13.toString(), AbstractC0034i.k("Cause: ", th13.getCause(), ", Stacktrace: ", Log.getStackTraceString(th13)));
                            }
                            cVar.g(T18);
                            return;
                        case 13:
                            InterfaceC0168f interfaceC0168f15 = interfaceC0168f;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list18 = (List) obj;
                            Object obj29 = list18.get(0);
                            q5.h.c(obj29, "null cannot be cast to non-null type kotlin.String");
                            String str15 = (String) obj29;
                            Object obj30 = list18.get(1);
                            q5.h.c(obj30, "null cannot be cast to non-null type kotlin.Long");
                            long longValue = ((Long) obj30).longValue();
                            Object obj31 = list18.get(2);
                            q5.h.c(obj31, "null cannot be cast to non-null type io.flutter.plugins.sharedpreferences.SharedPreferencesPigeonOptions");
                            try {
                                interfaceC0168f15.u(str15, longValue, (h) obj31);
                                T19 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th14) {
                                T19 = h5.e.T(th14.getClass().getSimpleName(), th14.toString(), AbstractC0034i.k("Cause: ", th14.getCause(), ", Stacktrace: ", Log.getStackTraceString(th14)));
                            }
                            cVar.g(T19);
                            return;
                        default:
                            InterfaceC0168f interfaceC0168f16 = interfaceC0168f;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list19 = (List) obj;
                            Object obj32 = list19.get(0);
                            q5.h.c(obj32, "null cannot be cast to non-null type kotlin.String");
                            String str16 = (String) obj32;
                            Object obj33 = list19.get(1);
                            q5.h.c(obj33, "null cannot be cast to non-null type kotlin.Double");
                            double doubleValue = ((Double) obj33).doubleValue();
                            Object obj34 = list19.get(2);
                            q5.h.c(obj34, "null cannot be cast to non-null type io.flutter.plugins.sharedpreferences.SharedPreferencesPigeonOptions");
                            try {
                                interfaceC0168f16.o(str16, doubleValue, (h) obj34);
                                T20 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th15) {
                                T20 = h5.e.T(th15.getClass().getSimpleName(), th15.toString(), AbstractC0034i.k("Cause: ", th15.getCause(), ", Stacktrace: ", Log.getStackTraceString(th15)));
                            }
                            cVar.g(T20);
                            return;
                    }
                }
            });
        } else {
            uVar3.y(null);
        }
        v3.u uVar4 = new v3.u(fVar, AbstractC0034i.j("dev.flutter.pigeon.shared_preferences_android.SharedPreferencesAsyncApi.setDouble", str2), a(), c6);
        if (interfaceC0168f != null) {
            final int i9 = 14;
            uVar4.y(new M4.b() { // from class: X4.d
                @Override // M4.b
                public final void e(Object obj, A.c cVar) {
                    List T6;
                    List T7;
                    List T8;
                    List T9;
                    List T10;
                    List T11;
                    List T12;
                    List T13;
                    List T14;
                    List T15;
                    List T16;
                    List T17;
                    List T18;
                    List T19;
                    List T20;
                    switch (i9) {
                        case 0:
                            InterfaceC0168f interfaceC0168f2 = interfaceC0168f;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list = (List) obj;
                            Object obj2 = list.get(0);
                            q5.h.c(obj2, "null cannot be cast to non-null type kotlin.String");
                            String str3 = (String) obj2;
                            Object obj3 = list.get(1);
                            q5.h.c(obj3, "null cannot be cast to non-null type kotlin.String");
                            String str4 = (String) obj3;
                            Object obj4 = list.get(2);
                            q5.h.c(obj4, "null cannot be cast to non-null type io.flutter.plugins.sharedpreferences.SharedPreferencesPigeonOptions");
                            try {
                                interfaceC0168f2.p(str3, str4, (h) obj4);
                                T6 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th) {
                                T6 = h5.e.T(th.getClass().getSimpleName(), th.toString(), AbstractC0034i.k("Cause: ", th.getCause(), ", Stacktrace: ", Log.getStackTraceString(th)));
                            }
                            cVar.g(T6);
                            return;
                        case 1:
                            InterfaceC0168f interfaceC0168f3 = interfaceC0168f;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list2 = (List) obj;
                            Object obj5 = list2.get(0);
                            q5.h.c(obj5, "null cannot be cast to non-null type kotlin.String");
                            String str5 = (String) obj5;
                            Object obj6 = list2.get(1);
                            q5.h.c(obj6, "null cannot be cast to non-null type kotlin.collections.List<kotlin.String>");
                            List list3 = (List) obj6;
                            Object obj7 = list2.get(2);
                            q5.h.c(obj7, "null cannot be cast to non-null type io.flutter.plugins.sharedpreferences.SharedPreferencesPigeonOptions");
                            try {
                                interfaceC0168f3.n(str5, list3, (h) obj7);
                                T7 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th2) {
                                T7 = h5.e.T(th2.getClass().getSimpleName(), th2.toString(), AbstractC0034i.k("Cause: ", th2.getCause(), ", Stacktrace: ", Log.getStackTraceString(th2)));
                            }
                            cVar.g(T7);
                            return;
                        case 2:
                            InterfaceC0168f interfaceC0168f4 = interfaceC0168f;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list4 = (List) obj;
                            Object obj8 = list4.get(0);
                            q5.h.c(obj8, "null cannot be cast to non-null type kotlin.String");
                            String str6 = (String) obj8;
                            Object obj9 = list4.get(1);
                            q5.h.c(obj9, "null cannot be cast to non-null type io.flutter.plugins.sharedpreferences.SharedPreferencesPigeonOptions");
                            try {
                                T8 = android.support.v4.media.session.a.z(interfaceC0168f4.j(str6, (h) obj9));
                            } catch (Throwable th3) {
                                T8 = h5.e.T(th3.getClass().getSimpleName(), th3.toString(), AbstractC0034i.k("Cause: ", th3.getCause(), ", Stacktrace: ", Log.getStackTraceString(th3)));
                            }
                            cVar.g(T8);
                            return;
                        case 3:
                            InterfaceC0168f interfaceC0168f5 = interfaceC0168f;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list5 = (List) obj;
                            Object obj10 = list5.get(0);
                            q5.h.c(obj10, "null cannot be cast to non-null type kotlin.String");
                            String str7 = (String) obj10;
                            Object obj11 = list5.get(1);
                            q5.h.c(obj11, "null cannot be cast to non-null type io.flutter.plugins.sharedpreferences.SharedPreferencesPigeonOptions");
                            try {
                                T9 = android.support.v4.media.session.a.z(interfaceC0168f5.h(str7, (h) obj11));
                            } catch (Throwable th4) {
                                T9 = h5.e.T(th4.getClass().getSimpleName(), th4.toString(), AbstractC0034i.k("Cause: ", th4.getCause(), ", Stacktrace: ", Log.getStackTraceString(th4)));
                            }
                            cVar.g(T9);
                            return;
                        case 4:
                            InterfaceC0168f interfaceC0168f6 = interfaceC0168f;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list6 = (List) obj;
                            Object obj12 = list6.get(0);
                            q5.h.c(obj12, "null cannot be cast to non-null type kotlin.String");
                            String str8 = (String) obj12;
                            Object obj13 = list6.get(1);
                            q5.h.c(obj13, "null cannot be cast to non-null type io.flutter.plugins.sharedpreferences.SharedPreferencesPigeonOptions");
                            try {
                                T10 = android.support.v4.media.session.a.z(interfaceC0168f6.d(str8, (h) obj13));
                            } catch (Throwable th5) {
                                T10 = h5.e.T(th5.getClass().getSimpleName(), th5.toString(), AbstractC0034i.k("Cause: ", th5.getCause(), ", Stacktrace: ", Log.getStackTraceString(th5)));
                            }
                            cVar.g(T10);
                            return;
                        case 5:
                            InterfaceC0168f interfaceC0168f7 = interfaceC0168f;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list7 = (List) obj;
                            Object obj14 = list7.get(0);
                            q5.h.c(obj14, "null cannot be cast to non-null type kotlin.String");
                            String str9 = (String) obj14;
                            Object obj15 = list7.get(1);
                            q5.h.c(obj15, "null cannot be cast to non-null type io.flutter.plugins.sharedpreferences.SharedPreferencesPigeonOptions");
                            try {
                                T11 = android.support.v4.media.session.a.z(interfaceC0168f7.m(str9, (h) obj15));
                            } catch (Throwable th6) {
                                T11 = h5.e.T(th6.getClass().getSimpleName(), th6.toString(), AbstractC0034i.k("Cause: ", th6.getCause(), ", Stacktrace: ", Log.getStackTraceString(th6)));
                            }
                            cVar.g(T11);
                            return;
                        case 6:
                            InterfaceC0168f interfaceC0168f8 = interfaceC0168f;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list8 = (List) obj;
                            Object obj16 = list8.get(0);
                            q5.h.c(obj16, "null cannot be cast to non-null type kotlin.String");
                            String str10 = (String) obj16;
                            Object obj17 = list8.get(1);
                            q5.h.c(obj17, "null cannot be cast to non-null type kotlin.Boolean");
                            boolean booleanValue = ((Boolean) obj17).booleanValue();
                            Object obj18 = list8.get(2);
                            q5.h.c(obj18, "null cannot be cast to non-null type io.flutter.plugins.sharedpreferences.SharedPreferencesPigeonOptions");
                            try {
                                interfaceC0168f8.i(str10, booleanValue, (h) obj18);
                                T12 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th7) {
                                T12 = h5.e.T(th7.getClass().getSimpleName(), th7.toString(), AbstractC0034i.k("Cause: ", th7.getCause(), ", Stacktrace: ", Log.getStackTraceString(th7)));
                            }
                            cVar.g(T12);
                            return;
                        case 7:
                            InterfaceC0168f interfaceC0168f9 = interfaceC0168f;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list9 = (List) obj;
                            Object obj19 = list9.get(0);
                            q5.h.c(obj19, "null cannot be cast to non-null type kotlin.String");
                            String str11 = (String) obj19;
                            Object obj20 = list9.get(1);
                            q5.h.c(obj20, "null cannot be cast to non-null type io.flutter.plugins.sharedpreferences.SharedPreferencesPigeonOptions");
                            try {
                                T13 = android.support.v4.media.session.a.z(interfaceC0168f9.l(str11, (h) obj20));
                            } catch (Throwable th8) {
                                T13 = h5.e.T(th8.getClass().getSimpleName(), th8.toString(), AbstractC0034i.k("Cause: ", th8.getCause(), ", Stacktrace: ", Log.getStackTraceString(th8)));
                            }
                            cVar.g(T13);
                            return;
                        case 8:
                            InterfaceC0168f interfaceC0168f10 = interfaceC0168f;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list10 = (List) obj;
                            Object obj21 = list10.get(0);
                            q5.h.c(obj21, "null cannot be cast to non-null type kotlin.String");
                            String str12 = (String) obj21;
                            Object obj22 = list10.get(1);
                            q5.h.c(obj22, "null cannot be cast to non-null type io.flutter.plugins.sharedpreferences.SharedPreferencesPigeonOptions");
                            try {
                                T14 = android.support.v4.media.session.a.z(interfaceC0168f10.r(str12, (h) obj22));
                            } catch (Throwable th9) {
                                T14 = h5.e.T(th9.getClass().getSimpleName(), th9.toString(), AbstractC0034i.k("Cause: ", th9.getCause(), ", Stacktrace: ", Log.getStackTraceString(th9)));
                            }
                            cVar.g(T14);
                            return;
                        case ContentHandlerProxy.PROCESSING_INSTRUCTION /* 9 */:
                            InterfaceC0168f interfaceC0168f11 = interfaceC0168f;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list11 = (List) obj;
                            List list12 = (List) list11.get(0);
                            Object obj23 = list11.get(1);
                            q5.h.c(obj23, "null cannot be cast to non-null type io.flutter.plugins.sharedpreferences.SharedPreferencesPigeonOptions");
                            try {
                                interfaceC0168f11.s(list12, (h) obj23);
                                T15 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th10) {
                                T15 = h5.e.T(th10.getClass().getSimpleName(), th10.toString(), AbstractC0034i.k("Cause: ", th10.getCause(), ", Stacktrace: ", Log.getStackTraceString(th10)));
                            }
                            cVar.g(T15);
                            return;
                        case 10:
                            InterfaceC0168f interfaceC0168f12 = interfaceC0168f;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list13 = (List) obj;
                            List list14 = (List) list13.get(0);
                            Object obj24 = list13.get(1);
                            q5.h.c(obj24, "null cannot be cast to non-null type io.flutter.plugins.sharedpreferences.SharedPreferencesPigeonOptions");
                            try {
                                T16 = android.support.v4.media.session.a.z(interfaceC0168f12.t(list14, (h) obj24));
                            } catch (Throwable th11) {
                                T16 = h5.e.T(th11.getClass().getSimpleName(), th11.toString(), AbstractC0034i.k("Cause: ", th11.getCause(), ", Stacktrace: ", Log.getStackTraceString(th11)));
                            }
                            cVar.g(T16);
                            return;
                        case 11:
                            InterfaceC0168f interfaceC0168f13 = interfaceC0168f;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list15 = (List) obj;
                            List list16 = (List) list15.get(0);
                            Object obj25 = list15.get(1);
                            q5.h.c(obj25, "null cannot be cast to non-null type io.flutter.plugins.sharedpreferences.SharedPreferencesPigeonOptions");
                            try {
                                T17 = android.support.v4.media.session.a.z(interfaceC0168f13.f(list16, (h) obj25));
                            } catch (Throwable th12) {
                                T17 = h5.e.T(th12.getClass().getSimpleName(), th12.toString(), AbstractC0034i.k("Cause: ", th12.getCause(), ", Stacktrace: ", Log.getStackTraceString(th12)));
                            }
                            cVar.g(T17);
                            return;
                        case 12:
                            InterfaceC0168f interfaceC0168f14 = interfaceC0168f;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list17 = (List) obj;
                            Object obj26 = list17.get(0);
                            q5.h.c(obj26, "null cannot be cast to non-null type kotlin.String");
                            String str13 = (String) obj26;
                            Object obj27 = list17.get(1);
                            q5.h.c(obj27, "null cannot be cast to non-null type kotlin.String");
                            String str14 = (String) obj27;
                            Object obj28 = list17.get(2);
                            q5.h.c(obj28, "null cannot be cast to non-null type io.flutter.plugins.sharedpreferences.SharedPreferencesPigeonOptions");
                            try {
                                interfaceC0168f14.g(str13, str14, (h) obj28);
                                T18 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th13) {
                                T18 = h5.e.T(th13.getClass().getSimpleName(), th13.toString(), AbstractC0034i.k("Cause: ", th13.getCause(), ", Stacktrace: ", Log.getStackTraceString(th13)));
                            }
                            cVar.g(T18);
                            return;
                        case 13:
                            InterfaceC0168f interfaceC0168f15 = interfaceC0168f;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list18 = (List) obj;
                            Object obj29 = list18.get(0);
                            q5.h.c(obj29, "null cannot be cast to non-null type kotlin.String");
                            String str15 = (String) obj29;
                            Object obj30 = list18.get(1);
                            q5.h.c(obj30, "null cannot be cast to non-null type kotlin.Long");
                            long longValue = ((Long) obj30).longValue();
                            Object obj31 = list18.get(2);
                            q5.h.c(obj31, "null cannot be cast to non-null type io.flutter.plugins.sharedpreferences.SharedPreferencesPigeonOptions");
                            try {
                                interfaceC0168f15.u(str15, longValue, (h) obj31);
                                T19 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th14) {
                                T19 = h5.e.T(th14.getClass().getSimpleName(), th14.toString(), AbstractC0034i.k("Cause: ", th14.getCause(), ", Stacktrace: ", Log.getStackTraceString(th14)));
                            }
                            cVar.g(T19);
                            return;
                        default:
                            InterfaceC0168f interfaceC0168f16 = interfaceC0168f;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list19 = (List) obj;
                            Object obj32 = list19.get(0);
                            q5.h.c(obj32, "null cannot be cast to non-null type kotlin.String");
                            String str16 = (String) obj32;
                            Object obj33 = list19.get(1);
                            q5.h.c(obj33, "null cannot be cast to non-null type kotlin.Double");
                            double doubleValue = ((Double) obj33).doubleValue();
                            Object obj34 = list19.get(2);
                            q5.h.c(obj34, "null cannot be cast to non-null type io.flutter.plugins.sharedpreferences.SharedPreferencesPigeonOptions");
                            try {
                                interfaceC0168f16.o(str16, doubleValue, (h) obj34);
                                T20 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th15) {
                                T20 = h5.e.T(th15.getClass().getSimpleName(), th15.toString(), AbstractC0034i.k("Cause: ", th15.getCause(), ", Stacktrace: ", Log.getStackTraceString(th15)));
                            }
                            cVar.g(T20);
                            return;
                    }
                }
            });
        } else {
            uVar4.y(null);
        }
        v3.u uVar5 = new v3.u(fVar, AbstractC0034i.j("dev.flutter.pigeon.shared_preferences_android.SharedPreferencesAsyncApi.setEncodedStringList", str2), a(), c6);
        if (interfaceC0168f != null) {
            final int i10 = 0;
            uVar5.y(new M4.b() { // from class: X4.d
                @Override // M4.b
                public final void e(Object obj, A.c cVar) {
                    List T6;
                    List T7;
                    List T8;
                    List T9;
                    List T10;
                    List T11;
                    List T12;
                    List T13;
                    List T14;
                    List T15;
                    List T16;
                    List T17;
                    List T18;
                    List T19;
                    List T20;
                    switch (i10) {
                        case 0:
                            InterfaceC0168f interfaceC0168f2 = interfaceC0168f;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list = (List) obj;
                            Object obj2 = list.get(0);
                            q5.h.c(obj2, "null cannot be cast to non-null type kotlin.String");
                            String str3 = (String) obj2;
                            Object obj3 = list.get(1);
                            q5.h.c(obj3, "null cannot be cast to non-null type kotlin.String");
                            String str4 = (String) obj3;
                            Object obj4 = list.get(2);
                            q5.h.c(obj4, "null cannot be cast to non-null type io.flutter.plugins.sharedpreferences.SharedPreferencesPigeonOptions");
                            try {
                                interfaceC0168f2.p(str3, str4, (h) obj4);
                                T6 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th) {
                                T6 = h5.e.T(th.getClass().getSimpleName(), th.toString(), AbstractC0034i.k("Cause: ", th.getCause(), ", Stacktrace: ", Log.getStackTraceString(th)));
                            }
                            cVar.g(T6);
                            return;
                        case 1:
                            InterfaceC0168f interfaceC0168f3 = interfaceC0168f;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list2 = (List) obj;
                            Object obj5 = list2.get(0);
                            q5.h.c(obj5, "null cannot be cast to non-null type kotlin.String");
                            String str5 = (String) obj5;
                            Object obj6 = list2.get(1);
                            q5.h.c(obj6, "null cannot be cast to non-null type kotlin.collections.List<kotlin.String>");
                            List list3 = (List) obj6;
                            Object obj7 = list2.get(2);
                            q5.h.c(obj7, "null cannot be cast to non-null type io.flutter.plugins.sharedpreferences.SharedPreferencesPigeonOptions");
                            try {
                                interfaceC0168f3.n(str5, list3, (h) obj7);
                                T7 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th2) {
                                T7 = h5.e.T(th2.getClass().getSimpleName(), th2.toString(), AbstractC0034i.k("Cause: ", th2.getCause(), ", Stacktrace: ", Log.getStackTraceString(th2)));
                            }
                            cVar.g(T7);
                            return;
                        case 2:
                            InterfaceC0168f interfaceC0168f4 = interfaceC0168f;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list4 = (List) obj;
                            Object obj8 = list4.get(0);
                            q5.h.c(obj8, "null cannot be cast to non-null type kotlin.String");
                            String str6 = (String) obj8;
                            Object obj9 = list4.get(1);
                            q5.h.c(obj9, "null cannot be cast to non-null type io.flutter.plugins.sharedpreferences.SharedPreferencesPigeonOptions");
                            try {
                                T8 = android.support.v4.media.session.a.z(interfaceC0168f4.j(str6, (h) obj9));
                            } catch (Throwable th3) {
                                T8 = h5.e.T(th3.getClass().getSimpleName(), th3.toString(), AbstractC0034i.k("Cause: ", th3.getCause(), ", Stacktrace: ", Log.getStackTraceString(th3)));
                            }
                            cVar.g(T8);
                            return;
                        case 3:
                            InterfaceC0168f interfaceC0168f5 = interfaceC0168f;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list5 = (List) obj;
                            Object obj10 = list5.get(0);
                            q5.h.c(obj10, "null cannot be cast to non-null type kotlin.String");
                            String str7 = (String) obj10;
                            Object obj11 = list5.get(1);
                            q5.h.c(obj11, "null cannot be cast to non-null type io.flutter.plugins.sharedpreferences.SharedPreferencesPigeonOptions");
                            try {
                                T9 = android.support.v4.media.session.a.z(interfaceC0168f5.h(str7, (h) obj11));
                            } catch (Throwable th4) {
                                T9 = h5.e.T(th4.getClass().getSimpleName(), th4.toString(), AbstractC0034i.k("Cause: ", th4.getCause(), ", Stacktrace: ", Log.getStackTraceString(th4)));
                            }
                            cVar.g(T9);
                            return;
                        case 4:
                            InterfaceC0168f interfaceC0168f6 = interfaceC0168f;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list6 = (List) obj;
                            Object obj12 = list6.get(0);
                            q5.h.c(obj12, "null cannot be cast to non-null type kotlin.String");
                            String str8 = (String) obj12;
                            Object obj13 = list6.get(1);
                            q5.h.c(obj13, "null cannot be cast to non-null type io.flutter.plugins.sharedpreferences.SharedPreferencesPigeonOptions");
                            try {
                                T10 = android.support.v4.media.session.a.z(interfaceC0168f6.d(str8, (h) obj13));
                            } catch (Throwable th5) {
                                T10 = h5.e.T(th5.getClass().getSimpleName(), th5.toString(), AbstractC0034i.k("Cause: ", th5.getCause(), ", Stacktrace: ", Log.getStackTraceString(th5)));
                            }
                            cVar.g(T10);
                            return;
                        case 5:
                            InterfaceC0168f interfaceC0168f7 = interfaceC0168f;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list7 = (List) obj;
                            Object obj14 = list7.get(0);
                            q5.h.c(obj14, "null cannot be cast to non-null type kotlin.String");
                            String str9 = (String) obj14;
                            Object obj15 = list7.get(1);
                            q5.h.c(obj15, "null cannot be cast to non-null type io.flutter.plugins.sharedpreferences.SharedPreferencesPigeonOptions");
                            try {
                                T11 = android.support.v4.media.session.a.z(interfaceC0168f7.m(str9, (h) obj15));
                            } catch (Throwable th6) {
                                T11 = h5.e.T(th6.getClass().getSimpleName(), th6.toString(), AbstractC0034i.k("Cause: ", th6.getCause(), ", Stacktrace: ", Log.getStackTraceString(th6)));
                            }
                            cVar.g(T11);
                            return;
                        case 6:
                            InterfaceC0168f interfaceC0168f8 = interfaceC0168f;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list8 = (List) obj;
                            Object obj16 = list8.get(0);
                            q5.h.c(obj16, "null cannot be cast to non-null type kotlin.String");
                            String str10 = (String) obj16;
                            Object obj17 = list8.get(1);
                            q5.h.c(obj17, "null cannot be cast to non-null type kotlin.Boolean");
                            boolean booleanValue = ((Boolean) obj17).booleanValue();
                            Object obj18 = list8.get(2);
                            q5.h.c(obj18, "null cannot be cast to non-null type io.flutter.plugins.sharedpreferences.SharedPreferencesPigeonOptions");
                            try {
                                interfaceC0168f8.i(str10, booleanValue, (h) obj18);
                                T12 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th7) {
                                T12 = h5.e.T(th7.getClass().getSimpleName(), th7.toString(), AbstractC0034i.k("Cause: ", th7.getCause(), ", Stacktrace: ", Log.getStackTraceString(th7)));
                            }
                            cVar.g(T12);
                            return;
                        case 7:
                            InterfaceC0168f interfaceC0168f9 = interfaceC0168f;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list9 = (List) obj;
                            Object obj19 = list9.get(0);
                            q5.h.c(obj19, "null cannot be cast to non-null type kotlin.String");
                            String str11 = (String) obj19;
                            Object obj20 = list9.get(1);
                            q5.h.c(obj20, "null cannot be cast to non-null type io.flutter.plugins.sharedpreferences.SharedPreferencesPigeonOptions");
                            try {
                                T13 = android.support.v4.media.session.a.z(interfaceC0168f9.l(str11, (h) obj20));
                            } catch (Throwable th8) {
                                T13 = h5.e.T(th8.getClass().getSimpleName(), th8.toString(), AbstractC0034i.k("Cause: ", th8.getCause(), ", Stacktrace: ", Log.getStackTraceString(th8)));
                            }
                            cVar.g(T13);
                            return;
                        case 8:
                            InterfaceC0168f interfaceC0168f10 = interfaceC0168f;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list10 = (List) obj;
                            Object obj21 = list10.get(0);
                            q5.h.c(obj21, "null cannot be cast to non-null type kotlin.String");
                            String str12 = (String) obj21;
                            Object obj22 = list10.get(1);
                            q5.h.c(obj22, "null cannot be cast to non-null type io.flutter.plugins.sharedpreferences.SharedPreferencesPigeonOptions");
                            try {
                                T14 = android.support.v4.media.session.a.z(interfaceC0168f10.r(str12, (h) obj22));
                            } catch (Throwable th9) {
                                T14 = h5.e.T(th9.getClass().getSimpleName(), th9.toString(), AbstractC0034i.k("Cause: ", th9.getCause(), ", Stacktrace: ", Log.getStackTraceString(th9)));
                            }
                            cVar.g(T14);
                            return;
                        case ContentHandlerProxy.PROCESSING_INSTRUCTION /* 9 */:
                            InterfaceC0168f interfaceC0168f11 = interfaceC0168f;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list11 = (List) obj;
                            List list12 = (List) list11.get(0);
                            Object obj23 = list11.get(1);
                            q5.h.c(obj23, "null cannot be cast to non-null type io.flutter.plugins.sharedpreferences.SharedPreferencesPigeonOptions");
                            try {
                                interfaceC0168f11.s(list12, (h) obj23);
                                T15 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th10) {
                                T15 = h5.e.T(th10.getClass().getSimpleName(), th10.toString(), AbstractC0034i.k("Cause: ", th10.getCause(), ", Stacktrace: ", Log.getStackTraceString(th10)));
                            }
                            cVar.g(T15);
                            return;
                        case 10:
                            InterfaceC0168f interfaceC0168f12 = interfaceC0168f;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list13 = (List) obj;
                            List list14 = (List) list13.get(0);
                            Object obj24 = list13.get(1);
                            q5.h.c(obj24, "null cannot be cast to non-null type io.flutter.plugins.sharedpreferences.SharedPreferencesPigeonOptions");
                            try {
                                T16 = android.support.v4.media.session.a.z(interfaceC0168f12.t(list14, (h) obj24));
                            } catch (Throwable th11) {
                                T16 = h5.e.T(th11.getClass().getSimpleName(), th11.toString(), AbstractC0034i.k("Cause: ", th11.getCause(), ", Stacktrace: ", Log.getStackTraceString(th11)));
                            }
                            cVar.g(T16);
                            return;
                        case 11:
                            InterfaceC0168f interfaceC0168f13 = interfaceC0168f;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list15 = (List) obj;
                            List list16 = (List) list15.get(0);
                            Object obj25 = list15.get(1);
                            q5.h.c(obj25, "null cannot be cast to non-null type io.flutter.plugins.sharedpreferences.SharedPreferencesPigeonOptions");
                            try {
                                T17 = android.support.v4.media.session.a.z(interfaceC0168f13.f(list16, (h) obj25));
                            } catch (Throwable th12) {
                                T17 = h5.e.T(th12.getClass().getSimpleName(), th12.toString(), AbstractC0034i.k("Cause: ", th12.getCause(), ", Stacktrace: ", Log.getStackTraceString(th12)));
                            }
                            cVar.g(T17);
                            return;
                        case 12:
                            InterfaceC0168f interfaceC0168f14 = interfaceC0168f;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list17 = (List) obj;
                            Object obj26 = list17.get(0);
                            q5.h.c(obj26, "null cannot be cast to non-null type kotlin.String");
                            String str13 = (String) obj26;
                            Object obj27 = list17.get(1);
                            q5.h.c(obj27, "null cannot be cast to non-null type kotlin.String");
                            String str14 = (String) obj27;
                            Object obj28 = list17.get(2);
                            q5.h.c(obj28, "null cannot be cast to non-null type io.flutter.plugins.sharedpreferences.SharedPreferencesPigeonOptions");
                            try {
                                interfaceC0168f14.g(str13, str14, (h) obj28);
                                T18 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th13) {
                                T18 = h5.e.T(th13.getClass().getSimpleName(), th13.toString(), AbstractC0034i.k("Cause: ", th13.getCause(), ", Stacktrace: ", Log.getStackTraceString(th13)));
                            }
                            cVar.g(T18);
                            return;
                        case 13:
                            InterfaceC0168f interfaceC0168f15 = interfaceC0168f;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list18 = (List) obj;
                            Object obj29 = list18.get(0);
                            q5.h.c(obj29, "null cannot be cast to non-null type kotlin.String");
                            String str15 = (String) obj29;
                            Object obj30 = list18.get(1);
                            q5.h.c(obj30, "null cannot be cast to non-null type kotlin.Long");
                            long longValue = ((Long) obj30).longValue();
                            Object obj31 = list18.get(2);
                            q5.h.c(obj31, "null cannot be cast to non-null type io.flutter.plugins.sharedpreferences.SharedPreferencesPigeonOptions");
                            try {
                                interfaceC0168f15.u(str15, longValue, (h) obj31);
                                T19 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th14) {
                                T19 = h5.e.T(th14.getClass().getSimpleName(), th14.toString(), AbstractC0034i.k("Cause: ", th14.getCause(), ", Stacktrace: ", Log.getStackTraceString(th14)));
                            }
                            cVar.g(T19);
                            return;
                        default:
                            InterfaceC0168f interfaceC0168f16 = interfaceC0168f;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list19 = (List) obj;
                            Object obj32 = list19.get(0);
                            q5.h.c(obj32, "null cannot be cast to non-null type kotlin.String");
                            String str16 = (String) obj32;
                            Object obj33 = list19.get(1);
                            q5.h.c(obj33, "null cannot be cast to non-null type kotlin.Double");
                            double doubleValue = ((Double) obj33).doubleValue();
                            Object obj34 = list19.get(2);
                            q5.h.c(obj34, "null cannot be cast to non-null type io.flutter.plugins.sharedpreferences.SharedPreferencesPigeonOptions");
                            try {
                                interfaceC0168f16.o(str16, doubleValue, (h) obj34);
                                T20 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th15) {
                                T20 = h5.e.T(th15.getClass().getSimpleName(), th15.toString(), AbstractC0034i.k("Cause: ", th15.getCause(), ", Stacktrace: ", Log.getStackTraceString(th15)));
                            }
                            cVar.g(T20);
                            return;
                    }
                }
            });
        } else {
            uVar5.y(null);
        }
        v3.u uVar6 = new v3.u(fVar, AbstractC0034i.j("dev.flutter.pigeon.shared_preferences_android.SharedPreferencesAsyncApi.setDeprecatedStringList", str2), a(), c6);
        if (interfaceC0168f != null) {
            final int i11 = 1;
            uVar6.y(new M4.b() { // from class: X4.d
                @Override // M4.b
                public final void e(Object obj, A.c cVar) {
                    List T6;
                    List T7;
                    List T8;
                    List T9;
                    List T10;
                    List T11;
                    List T12;
                    List T13;
                    List T14;
                    List T15;
                    List T16;
                    List T17;
                    List T18;
                    List T19;
                    List T20;
                    switch (i11) {
                        case 0:
                            InterfaceC0168f interfaceC0168f2 = interfaceC0168f;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list = (List) obj;
                            Object obj2 = list.get(0);
                            q5.h.c(obj2, "null cannot be cast to non-null type kotlin.String");
                            String str3 = (String) obj2;
                            Object obj3 = list.get(1);
                            q5.h.c(obj3, "null cannot be cast to non-null type kotlin.String");
                            String str4 = (String) obj3;
                            Object obj4 = list.get(2);
                            q5.h.c(obj4, "null cannot be cast to non-null type io.flutter.plugins.sharedpreferences.SharedPreferencesPigeonOptions");
                            try {
                                interfaceC0168f2.p(str3, str4, (h) obj4);
                                T6 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th) {
                                T6 = h5.e.T(th.getClass().getSimpleName(), th.toString(), AbstractC0034i.k("Cause: ", th.getCause(), ", Stacktrace: ", Log.getStackTraceString(th)));
                            }
                            cVar.g(T6);
                            return;
                        case 1:
                            InterfaceC0168f interfaceC0168f3 = interfaceC0168f;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list2 = (List) obj;
                            Object obj5 = list2.get(0);
                            q5.h.c(obj5, "null cannot be cast to non-null type kotlin.String");
                            String str5 = (String) obj5;
                            Object obj6 = list2.get(1);
                            q5.h.c(obj6, "null cannot be cast to non-null type kotlin.collections.List<kotlin.String>");
                            List list3 = (List) obj6;
                            Object obj7 = list2.get(2);
                            q5.h.c(obj7, "null cannot be cast to non-null type io.flutter.plugins.sharedpreferences.SharedPreferencesPigeonOptions");
                            try {
                                interfaceC0168f3.n(str5, list3, (h) obj7);
                                T7 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th2) {
                                T7 = h5.e.T(th2.getClass().getSimpleName(), th2.toString(), AbstractC0034i.k("Cause: ", th2.getCause(), ", Stacktrace: ", Log.getStackTraceString(th2)));
                            }
                            cVar.g(T7);
                            return;
                        case 2:
                            InterfaceC0168f interfaceC0168f4 = interfaceC0168f;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list4 = (List) obj;
                            Object obj8 = list4.get(0);
                            q5.h.c(obj8, "null cannot be cast to non-null type kotlin.String");
                            String str6 = (String) obj8;
                            Object obj9 = list4.get(1);
                            q5.h.c(obj9, "null cannot be cast to non-null type io.flutter.plugins.sharedpreferences.SharedPreferencesPigeonOptions");
                            try {
                                T8 = android.support.v4.media.session.a.z(interfaceC0168f4.j(str6, (h) obj9));
                            } catch (Throwable th3) {
                                T8 = h5.e.T(th3.getClass().getSimpleName(), th3.toString(), AbstractC0034i.k("Cause: ", th3.getCause(), ", Stacktrace: ", Log.getStackTraceString(th3)));
                            }
                            cVar.g(T8);
                            return;
                        case 3:
                            InterfaceC0168f interfaceC0168f5 = interfaceC0168f;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list5 = (List) obj;
                            Object obj10 = list5.get(0);
                            q5.h.c(obj10, "null cannot be cast to non-null type kotlin.String");
                            String str7 = (String) obj10;
                            Object obj11 = list5.get(1);
                            q5.h.c(obj11, "null cannot be cast to non-null type io.flutter.plugins.sharedpreferences.SharedPreferencesPigeonOptions");
                            try {
                                T9 = android.support.v4.media.session.a.z(interfaceC0168f5.h(str7, (h) obj11));
                            } catch (Throwable th4) {
                                T9 = h5.e.T(th4.getClass().getSimpleName(), th4.toString(), AbstractC0034i.k("Cause: ", th4.getCause(), ", Stacktrace: ", Log.getStackTraceString(th4)));
                            }
                            cVar.g(T9);
                            return;
                        case 4:
                            InterfaceC0168f interfaceC0168f6 = interfaceC0168f;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list6 = (List) obj;
                            Object obj12 = list6.get(0);
                            q5.h.c(obj12, "null cannot be cast to non-null type kotlin.String");
                            String str8 = (String) obj12;
                            Object obj13 = list6.get(1);
                            q5.h.c(obj13, "null cannot be cast to non-null type io.flutter.plugins.sharedpreferences.SharedPreferencesPigeonOptions");
                            try {
                                T10 = android.support.v4.media.session.a.z(interfaceC0168f6.d(str8, (h) obj13));
                            } catch (Throwable th5) {
                                T10 = h5.e.T(th5.getClass().getSimpleName(), th5.toString(), AbstractC0034i.k("Cause: ", th5.getCause(), ", Stacktrace: ", Log.getStackTraceString(th5)));
                            }
                            cVar.g(T10);
                            return;
                        case 5:
                            InterfaceC0168f interfaceC0168f7 = interfaceC0168f;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list7 = (List) obj;
                            Object obj14 = list7.get(0);
                            q5.h.c(obj14, "null cannot be cast to non-null type kotlin.String");
                            String str9 = (String) obj14;
                            Object obj15 = list7.get(1);
                            q5.h.c(obj15, "null cannot be cast to non-null type io.flutter.plugins.sharedpreferences.SharedPreferencesPigeonOptions");
                            try {
                                T11 = android.support.v4.media.session.a.z(interfaceC0168f7.m(str9, (h) obj15));
                            } catch (Throwable th6) {
                                T11 = h5.e.T(th6.getClass().getSimpleName(), th6.toString(), AbstractC0034i.k("Cause: ", th6.getCause(), ", Stacktrace: ", Log.getStackTraceString(th6)));
                            }
                            cVar.g(T11);
                            return;
                        case 6:
                            InterfaceC0168f interfaceC0168f8 = interfaceC0168f;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list8 = (List) obj;
                            Object obj16 = list8.get(0);
                            q5.h.c(obj16, "null cannot be cast to non-null type kotlin.String");
                            String str10 = (String) obj16;
                            Object obj17 = list8.get(1);
                            q5.h.c(obj17, "null cannot be cast to non-null type kotlin.Boolean");
                            boolean booleanValue = ((Boolean) obj17).booleanValue();
                            Object obj18 = list8.get(2);
                            q5.h.c(obj18, "null cannot be cast to non-null type io.flutter.plugins.sharedpreferences.SharedPreferencesPigeonOptions");
                            try {
                                interfaceC0168f8.i(str10, booleanValue, (h) obj18);
                                T12 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th7) {
                                T12 = h5.e.T(th7.getClass().getSimpleName(), th7.toString(), AbstractC0034i.k("Cause: ", th7.getCause(), ", Stacktrace: ", Log.getStackTraceString(th7)));
                            }
                            cVar.g(T12);
                            return;
                        case 7:
                            InterfaceC0168f interfaceC0168f9 = interfaceC0168f;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list9 = (List) obj;
                            Object obj19 = list9.get(0);
                            q5.h.c(obj19, "null cannot be cast to non-null type kotlin.String");
                            String str11 = (String) obj19;
                            Object obj20 = list9.get(1);
                            q5.h.c(obj20, "null cannot be cast to non-null type io.flutter.plugins.sharedpreferences.SharedPreferencesPigeonOptions");
                            try {
                                T13 = android.support.v4.media.session.a.z(interfaceC0168f9.l(str11, (h) obj20));
                            } catch (Throwable th8) {
                                T13 = h5.e.T(th8.getClass().getSimpleName(), th8.toString(), AbstractC0034i.k("Cause: ", th8.getCause(), ", Stacktrace: ", Log.getStackTraceString(th8)));
                            }
                            cVar.g(T13);
                            return;
                        case 8:
                            InterfaceC0168f interfaceC0168f10 = interfaceC0168f;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list10 = (List) obj;
                            Object obj21 = list10.get(0);
                            q5.h.c(obj21, "null cannot be cast to non-null type kotlin.String");
                            String str12 = (String) obj21;
                            Object obj22 = list10.get(1);
                            q5.h.c(obj22, "null cannot be cast to non-null type io.flutter.plugins.sharedpreferences.SharedPreferencesPigeonOptions");
                            try {
                                T14 = android.support.v4.media.session.a.z(interfaceC0168f10.r(str12, (h) obj22));
                            } catch (Throwable th9) {
                                T14 = h5.e.T(th9.getClass().getSimpleName(), th9.toString(), AbstractC0034i.k("Cause: ", th9.getCause(), ", Stacktrace: ", Log.getStackTraceString(th9)));
                            }
                            cVar.g(T14);
                            return;
                        case ContentHandlerProxy.PROCESSING_INSTRUCTION /* 9 */:
                            InterfaceC0168f interfaceC0168f11 = interfaceC0168f;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list11 = (List) obj;
                            List list12 = (List) list11.get(0);
                            Object obj23 = list11.get(1);
                            q5.h.c(obj23, "null cannot be cast to non-null type io.flutter.plugins.sharedpreferences.SharedPreferencesPigeonOptions");
                            try {
                                interfaceC0168f11.s(list12, (h) obj23);
                                T15 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th10) {
                                T15 = h5.e.T(th10.getClass().getSimpleName(), th10.toString(), AbstractC0034i.k("Cause: ", th10.getCause(), ", Stacktrace: ", Log.getStackTraceString(th10)));
                            }
                            cVar.g(T15);
                            return;
                        case 10:
                            InterfaceC0168f interfaceC0168f12 = interfaceC0168f;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list13 = (List) obj;
                            List list14 = (List) list13.get(0);
                            Object obj24 = list13.get(1);
                            q5.h.c(obj24, "null cannot be cast to non-null type io.flutter.plugins.sharedpreferences.SharedPreferencesPigeonOptions");
                            try {
                                T16 = android.support.v4.media.session.a.z(interfaceC0168f12.t(list14, (h) obj24));
                            } catch (Throwable th11) {
                                T16 = h5.e.T(th11.getClass().getSimpleName(), th11.toString(), AbstractC0034i.k("Cause: ", th11.getCause(), ", Stacktrace: ", Log.getStackTraceString(th11)));
                            }
                            cVar.g(T16);
                            return;
                        case 11:
                            InterfaceC0168f interfaceC0168f13 = interfaceC0168f;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list15 = (List) obj;
                            List list16 = (List) list15.get(0);
                            Object obj25 = list15.get(1);
                            q5.h.c(obj25, "null cannot be cast to non-null type io.flutter.plugins.sharedpreferences.SharedPreferencesPigeonOptions");
                            try {
                                T17 = android.support.v4.media.session.a.z(interfaceC0168f13.f(list16, (h) obj25));
                            } catch (Throwable th12) {
                                T17 = h5.e.T(th12.getClass().getSimpleName(), th12.toString(), AbstractC0034i.k("Cause: ", th12.getCause(), ", Stacktrace: ", Log.getStackTraceString(th12)));
                            }
                            cVar.g(T17);
                            return;
                        case 12:
                            InterfaceC0168f interfaceC0168f14 = interfaceC0168f;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list17 = (List) obj;
                            Object obj26 = list17.get(0);
                            q5.h.c(obj26, "null cannot be cast to non-null type kotlin.String");
                            String str13 = (String) obj26;
                            Object obj27 = list17.get(1);
                            q5.h.c(obj27, "null cannot be cast to non-null type kotlin.String");
                            String str14 = (String) obj27;
                            Object obj28 = list17.get(2);
                            q5.h.c(obj28, "null cannot be cast to non-null type io.flutter.plugins.sharedpreferences.SharedPreferencesPigeonOptions");
                            try {
                                interfaceC0168f14.g(str13, str14, (h) obj28);
                                T18 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th13) {
                                T18 = h5.e.T(th13.getClass().getSimpleName(), th13.toString(), AbstractC0034i.k("Cause: ", th13.getCause(), ", Stacktrace: ", Log.getStackTraceString(th13)));
                            }
                            cVar.g(T18);
                            return;
                        case 13:
                            InterfaceC0168f interfaceC0168f15 = interfaceC0168f;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list18 = (List) obj;
                            Object obj29 = list18.get(0);
                            q5.h.c(obj29, "null cannot be cast to non-null type kotlin.String");
                            String str15 = (String) obj29;
                            Object obj30 = list18.get(1);
                            q5.h.c(obj30, "null cannot be cast to non-null type kotlin.Long");
                            long longValue = ((Long) obj30).longValue();
                            Object obj31 = list18.get(2);
                            q5.h.c(obj31, "null cannot be cast to non-null type io.flutter.plugins.sharedpreferences.SharedPreferencesPigeonOptions");
                            try {
                                interfaceC0168f15.u(str15, longValue, (h) obj31);
                                T19 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th14) {
                                T19 = h5.e.T(th14.getClass().getSimpleName(), th14.toString(), AbstractC0034i.k("Cause: ", th14.getCause(), ", Stacktrace: ", Log.getStackTraceString(th14)));
                            }
                            cVar.g(T19);
                            return;
                        default:
                            InterfaceC0168f interfaceC0168f16 = interfaceC0168f;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list19 = (List) obj;
                            Object obj32 = list19.get(0);
                            q5.h.c(obj32, "null cannot be cast to non-null type kotlin.String");
                            String str16 = (String) obj32;
                            Object obj33 = list19.get(1);
                            q5.h.c(obj33, "null cannot be cast to non-null type kotlin.Double");
                            double doubleValue = ((Double) obj33).doubleValue();
                            Object obj34 = list19.get(2);
                            q5.h.c(obj34, "null cannot be cast to non-null type io.flutter.plugins.sharedpreferences.SharedPreferencesPigeonOptions");
                            try {
                                interfaceC0168f16.o(str16, doubleValue, (h) obj34);
                                T20 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th15) {
                                T20 = h5.e.T(th15.getClass().getSimpleName(), th15.toString(), AbstractC0034i.k("Cause: ", th15.getCause(), ", Stacktrace: ", Log.getStackTraceString(th15)));
                            }
                            cVar.g(T20);
                            return;
                    }
                }
            });
        } else {
            uVar6.y(null);
        }
        v3.u uVar7 = new v3.u(fVar, AbstractC0034i.j("dev.flutter.pigeon.shared_preferences_android.SharedPreferencesAsyncApi.getString", str2), a(), c6);
        if (interfaceC0168f != null) {
            final int i12 = 2;
            uVar7.y(new M4.b() { // from class: X4.d
                @Override // M4.b
                public final void e(Object obj, A.c cVar) {
                    List T6;
                    List T7;
                    List T8;
                    List T9;
                    List T10;
                    List T11;
                    List T12;
                    List T13;
                    List T14;
                    List T15;
                    List T16;
                    List T17;
                    List T18;
                    List T19;
                    List T20;
                    switch (i12) {
                        case 0:
                            InterfaceC0168f interfaceC0168f2 = interfaceC0168f;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list = (List) obj;
                            Object obj2 = list.get(0);
                            q5.h.c(obj2, "null cannot be cast to non-null type kotlin.String");
                            String str3 = (String) obj2;
                            Object obj3 = list.get(1);
                            q5.h.c(obj3, "null cannot be cast to non-null type kotlin.String");
                            String str4 = (String) obj3;
                            Object obj4 = list.get(2);
                            q5.h.c(obj4, "null cannot be cast to non-null type io.flutter.plugins.sharedpreferences.SharedPreferencesPigeonOptions");
                            try {
                                interfaceC0168f2.p(str3, str4, (h) obj4);
                                T6 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th) {
                                T6 = h5.e.T(th.getClass().getSimpleName(), th.toString(), AbstractC0034i.k("Cause: ", th.getCause(), ", Stacktrace: ", Log.getStackTraceString(th)));
                            }
                            cVar.g(T6);
                            return;
                        case 1:
                            InterfaceC0168f interfaceC0168f3 = interfaceC0168f;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list2 = (List) obj;
                            Object obj5 = list2.get(0);
                            q5.h.c(obj5, "null cannot be cast to non-null type kotlin.String");
                            String str5 = (String) obj5;
                            Object obj6 = list2.get(1);
                            q5.h.c(obj6, "null cannot be cast to non-null type kotlin.collections.List<kotlin.String>");
                            List list3 = (List) obj6;
                            Object obj7 = list2.get(2);
                            q5.h.c(obj7, "null cannot be cast to non-null type io.flutter.plugins.sharedpreferences.SharedPreferencesPigeonOptions");
                            try {
                                interfaceC0168f3.n(str5, list3, (h) obj7);
                                T7 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th2) {
                                T7 = h5.e.T(th2.getClass().getSimpleName(), th2.toString(), AbstractC0034i.k("Cause: ", th2.getCause(), ", Stacktrace: ", Log.getStackTraceString(th2)));
                            }
                            cVar.g(T7);
                            return;
                        case 2:
                            InterfaceC0168f interfaceC0168f4 = interfaceC0168f;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list4 = (List) obj;
                            Object obj8 = list4.get(0);
                            q5.h.c(obj8, "null cannot be cast to non-null type kotlin.String");
                            String str6 = (String) obj8;
                            Object obj9 = list4.get(1);
                            q5.h.c(obj9, "null cannot be cast to non-null type io.flutter.plugins.sharedpreferences.SharedPreferencesPigeonOptions");
                            try {
                                T8 = android.support.v4.media.session.a.z(interfaceC0168f4.j(str6, (h) obj9));
                            } catch (Throwable th3) {
                                T8 = h5.e.T(th3.getClass().getSimpleName(), th3.toString(), AbstractC0034i.k("Cause: ", th3.getCause(), ", Stacktrace: ", Log.getStackTraceString(th3)));
                            }
                            cVar.g(T8);
                            return;
                        case 3:
                            InterfaceC0168f interfaceC0168f5 = interfaceC0168f;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list5 = (List) obj;
                            Object obj10 = list5.get(0);
                            q5.h.c(obj10, "null cannot be cast to non-null type kotlin.String");
                            String str7 = (String) obj10;
                            Object obj11 = list5.get(1);
                            q5.h.c(obj11, "null cannot be cast to non-null type io.flutter.plugins.sharedpreferences.SharedPreferencesPigeonOptions");
                            try {
                                T9 = android.support.v4.media.session.a.z(interfaceC0168f5.h(str7, (h) obj11));
                            } catch (Throwable th4) {
                                T9 = h5.e.T(th4.getClass().getSimpleName(), th4.toString(), AbstractC0034i.k("Cause: ", th4.getCause(), ", Stacktrace: ", Log.getStackTraceString(th4)));
                            }
                            cVar.g(T9);
                            return;
                        case 4:
                            InterfaceC0168f interfaceC0168f6 = interfaceC0168f;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list6 = (List) obj;
                            Object obj12 = list6.get(0);
                            q5.h.c(obj12, "null cannot be cast to non-null type kotlin.String");
                            String str8 = (String) obj12;
                            Object obj13 = list6.get(1);
                            q5.h.c(obj13, "null cannot be cast to non-null type io.flutter.plugins.sharedpreferences.SharedPreferencesPigeonOptions");
                            try {
                                T10 = android.support.v4.media.session.a.z(interfaceC0168f6.d(str8, (h) obj13));
                            } catch (Throwable th5) {
                                T10 = h5.e.T(th5.getClass().getSimpleName(), th5.toString(), AbstractC0034i.k("Cause: ", th5.getCause(), ", Stacktrace: ", Log.getStackTraceString(th5)));
                            }
                            cVar.g(T10);
                            return;
                        case 5:
                            InterfaceC0168f interfaceC0168f7 = interfaceC0168f;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list7 = (List) obj;
                            Object obj14 = list7.get(0);
                            q5.h.c(obj14, "null cannot be cast to non-null type kotlin.String");
                            String str9 = (String) obj14;
                            Object obj15 = list7.get(1);
                            q5.h.c(obj15, "null cannot be cast to non-null type io.flutter.plugins.sharedpreferences.SharedPreferencesPigeonOptions");
                            try {
                                T11 = android.support.v4.media.session.a.z(interfaceC0168f7.m(str9, (h) obj15));
                            } catch (Throwable th6) {
                                T11 = h5.e.T(th6.getClass().getSimpleName(), th6.toString(), AbstractC0034i.k("Cause: ", th6.getCause(), ", Stacktrace: ", Log.getStackTraceString(th6)));
                            }
                            cVar.g(T11);
                            return;
                        case 6:
                            InterfaceC0168f interfaceC0168f8 = interfaceC0168f;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list8 = (List) obj;
                            Object obj16 = list8.get(0);
                            q5.h.c(obj16, "null cannot be cast to non-null type kotlin.String");
                            String str10 = (String) obj16;
                            Object obj17 = list8.get(1);
                            q5.h.c(obj17, "null cannot be cast to non-null type kotlin.Boolean");
                            boolean booleanValue = ((Boolean) obj17).booleanValue();
                            Object obj18 = list8.get(2);
                            q5.h.c(obj18, "null cannot be cast to non-null type io.flutter.plugins.sharedpreferences.SharedPreferencesPigeonOptions");
                            try {
                                interfaceC0168f8.i(str10, booleanValue, (h) obj18);
                                T12 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th7) {
                                T12 = h5.e.T(th7.getClass().getSimpleName(), th7.toString(), AbstractC0034i.k("Cause: ", th7.getCause(), ", Stacktrace: ", Log.getStackTraceString(th7)));
                            }
                            cVar.g(T12);
                            return;
                        case 7:
                            InterfaceC0168f interfaceC0168f9 = interfaceC0168f;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list9 = (List) obj;
                            Object obj19 = list9.get(0);
                            q5.h.c(obj19, "null cannot be cast to non-null type kotlin.String");
                            String str11 = (String) obj19;
                            Object obj20 = list9.get(1);
                            q5.h.c(obj20, "null cannot be cast to non-null type io.flutter.plugins.sharedpreferences.SharedPreferencesPigeonOptions");
                            try {
                                T13 = android.support.v4.media.session.a.z(interfaceC0168f9.l(str11, (h) obj20));
                            } catch (Throwable th8) {
                                T13 = h5.e.T(th8.getClass().getSimpleName(), th8.toString(), AbstractC0034i.k("Cause: ", th8.getCause(), ", Stacktrace: ", Log.getStackTraceString(th8)));
                            }
                            cVar.g(T13);
                            return;
                        case 8:
                            InterfaceC0168f interfaceC0168f10 = interfaceC0168f;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list10 = (List) obj;
                            Object obj21 = list10.get(0);
                            q5.h.c(obj21, "null cannot be cast to non-null type kotlin.String");
                            String str12 = (String) obj21;
                            Object obj22 = list10.get(1);
                            q5.h.c(obj22, "null cannot be cast to non-null type io.flutter.plugins.sharedpreferences.SharedPreferencesPigeonOptions");
                            try {
                                T14 = android.support.v4.media.session.a.z(interfaceC0168f10.r(str12, (h) obj22));
                            } catch (Throwable th9) {
                                T14 = h5.e.T(th9.getClass().getSimpleName(), th9.toString(), AbstractC0034i.k("Cause: ", th9.getCause(), ", Stacktrace: ", Log.getStackTraceString(th9)));
                            }
                            cVar.g(T14);
                            return;
                        case ContentHandlerProxy.PROCESSING_INSTRUCTION /* 9 */:
                            InterfaceC0168f interfaceC0168f11 = interfaceC0168f;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list11 = (List) obj;
                            List list12 = (List) list11.get(0);
                            Object obj23 = list11.get(1);
                            q5.h.c(obj23, "null cannot be cast to non-null type io.flutter.plugins.sharedpreferences.SharedPreferencesPigeonOptions");
                            try {
                                interfaceC0168f11.s(list12, (h) obj23);
                                T15 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th10) {
                                T15 = h5.e.T(th10.getClass().getSimpleName(), th10.toString(), AbstractC0034i.k("Cause: ", th10.getCause(), ", Stacktrace: ", Log.getStackTraceString(th10)));
                            }
                            cVar.g(T15);
                            return;
                        case 10:
                            InterfaceC0168f interfaceC0168f12 = interfaceC0168f;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list13 = (List) obj;
                            List list14 = (List) list13.get(0);
                            Object obj24 = list13.get(1);
                            q5.h.c(obj24, "null cannot be cast to non-null type io.flutter.plugins.sharedpreferences.SharedPreferencesPigeonOptions");
                            try {
                                T16 = android.support.v4.media.session.a.z(interfaceC0168f12.t(list14, (h) obj24));
                            } catch (Throwable th11) {
                                T16 = h5.e.T(th11.getClass().getSimpleName(), th11.toString(), AbstractC0034i.k("Cause: ", th11.getCause(), ", Stacktrace: ", Log.getStackTraceString(th11)));
                            }
                            cVar.g(T16);
                            return;
                        case 11:
                            InterfaceC0168f interfaceC0168f13 = interfaceC0168f;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list15 = (List) obj;
                            List list16 = (List) list15.get(0);
                            Object obj25 = list15.get(1);
                            q5.h.c(obj25, "null cannot be cast to non-null type io.flutter.plugins.sharedpreferences.SharedPreferencesPigeonOptions");
                            try {
                                T17 = android.support.v4.media.session.a.z(interfaceC0168f13.f(list16, (h) obj25));
                            } catch (Throwable th12) {
                                T17 = h5.e.T(th12.getClass().getSimpleName(), th12.toString(), AbstractC0034i.k("Cause: ", th12.getCause(), ", Stacktrace: ", Log.getStackTraceString(th12)));
                            }
                            cVar.g(T17);
                            return;
                        case 12:
                            InterfaceC0168f interfaceC0168f14 = interfaceC0168f;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list17 = (List) obj;
                            Object obj26 = list17.get(0);
                            q5.h.c(obj26, "null cannot be cast to non-null type kotlin.String");
                            String str13 = (String) obj26;
                            Object obj27 = list17.get(1);
                            q5.h.c(obj27, "null cannot be cast to non-null type kotlin.String");
                            String str14 = (String) obj27;
                            Object obj28 = list17.get(2);
                            q5.h.c(obj28, "null cannot be cast to non-null type io.flutter.plugins.sharedpreferences.SharedPreferencesPigeonOptions");
                            try {
                                interfaceC0168f14.g(str13, str14, (h) obj28);
                                T18 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th13) {
                                T18 = h5.e.T(th13.getClass().getSimpleName(), th13.toString(), AbstractC0034i.k("Cause: ", th13.getCause(), ", Stacktrace: ", Log.getStackTraceString(th13)));
                            }
                            cVar.g(T18);
                            return;
                        case 13:
                            InterfaceC0168f interfaceC0168f15 = interfaceC0168f;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list18 = (List) obj;
                            Object obj29 = list18.get(0);
                            q5.h.c(obj29, "null cannot be cast to non-null type kotlin.String");
                            String str15 = (String) obj29;
                            Object obj30 = list18.get(1);
                            q5.h.c(obj30, "null cannot be cast to non-null type kotlin.Long");
                            long longValue = ((Long) obj30).longValue();
                            Object obj31 = list18.get(2);
                            q5.h.c(obj31, "null cannot be cast to non-null type io.flutter.plugins.sharedpreferences.SharedPreferencesPigeonOptions");
                            try {
                                interfaceC0168f15.u(str15, longValue, (h) obj31);
                                T19 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th14) {
                                T19 = h5.e.T(th14.getClass().getSimpleName(), th14.toString(), AbstractC0034i.k("Cause: ", th14.getCause(), ", Stacktrace: ", Log.getStackTraceString(th14)));
                            }
                            cVar.g(T19);
                            return;
                        default:
                            InterfaceC0168f interfaceC0168f16 = interfaceC0168f;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list19 = (List) obj;
                            Object obj32 = list19.get(0);
                            q5.h.c(obj32, "null cannot be cast to non-null type kotlin.String");
                            String str16 = (String) obj32;
                            Object obj33 = list19.get(1);
                            q5.h.c(obj33, "null cannot be cast to non-null type kotlin.Double");
                            double doubleValue = ((Double) obj33).doubleValue();
                            Object obj34 = list19.get(2);
                            q5.h.c(obj34, "null cannot be cast to non-null type io.flutter.plugins.sharedpreferences.SharedPreferencesPigeonOptions");
                            try {
                                interfaceC0168f16.o(str16, doubleValue, (h) obj34);
                                T20 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th15) {
                                T20 = h5.e.T(th15.getClass().getSimpleName(), th15.toString(), AbstractC0034i.k("Cause: ", th15.getCause(), ", Stacktrace: ", Log.getStackTraceString(th15)));
                            }
                            cVar.g(T20);
                            return;
                    }
                }
            });
        } else {
            uVar7.y(null);
        }
        v3.u uVar8 = new v3.u(fVar, AbstractC0034i.j("dev.flutter.pigeon.shared_preferences_android.SharedPreferencesAsyncApi.getBool", str2), a(), c6);
        if (interfaceC0168f != null) {
            final int i13 = 3;
            uVar8.y(new M4.b() { // from class: X4.d
                @Override // M4.b
                public final void e(Object obj, A.c cVar) {
                    List T6;
                    List T7;
                    List T8;
                    List T9;
                    List T10;
                    List T11;
                    List T12;
                    List T13;
                    List T14;
                    List T15;
                    List T16;
                    List T17;
                    List T18;
                    List T19;
                    List T20;
                    switch (i13) {
                        case 0:
                            InterfaceC0168f interfaceC0168f2 = interfaceC0168f;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list = (List) obj;
                            Object obj2 = list.get(0);
                            q5.h.c(obj2, "null cannot be cast to non-null type kotlin.String");
                            String str3 = (String) obj2;
                            Object obj3 = list.get(1);
                            q5.h.c(obj3, "null cannot be cast to non-null type kotlin.String");
                            String str4 = (String) obj3;
                            Object obj4 = list.get(2);
                            q5.h.c(obj4, "null cannot be cast to non-null type io.flutter.plugins.sharedpreferences.SharedPreferencesPigeonOptions");
                            try {
                                interfaceC0168f2.p(str3, str4, (h) obj4);
                                T6 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th) {
                                T6 = h5.e.T(th.getClass().getSimpleName(), th.toString(), AbstractC0034i.k("Cause: ", th.getCause(), ", Stacktrace: ", Log.getStackTraceString(th)));
                            }
                            cVar.g(T6);
                            return;
                        case 1:
                            InterfaceC0168f interfaceC0168f3 = interfaceC0168f;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list2 = (List) obj;
                            Object obj5 = list2.get(0);
                            q5.h.c(obj5, "null cannot be cast to non-null type kotlin.String");
                            String str5 = (String) obj5;
                            Object obj6 = list2.get(1);
                            q5.h.c(obj6, "null cannot be cast to non-null type kotlin.collections.List<kotlin.String>");
                            List list3 = (List) obj6;
                            Object obj7 = list2.get(2);
                            q5.h.c(obj7, "null cannot be cast to non-null type io.flutter.plugins.sharedpreferences.SharedPreferencesPigeonOptions");
                            try {
                                interfaceC0168f3.n(str5, list3, (h) obj7);
                                T7 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th2) {
                                T7 = h5.e.T(th2.getClass().getSimpleName(), th2.toString(), AbstractC0034i.k("Cause: ", th2.getCause(), ", Stacktrace: ", Log.getStackTraceString(th2)));
                            }
                            cVar.g(T7);
                            return;
                        case 2:
                            InterfaceC0168f interfaceC0168f4 = interfaceC0168f;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list4 = (List) obj;
                            Object obj8 = list4.get(0);
                            q5.h.c(obj8, "null cannot be cast to non-null type kotlin.String");
                            String str6 = (String) obj8;
                            Object obj9 = list4.get(1);
                            q5.h.c(obj9, "null cannot be cast to non-null type io.flutter.plugins.sharedpreferences.SharedPreferencesPigeonOptions");
                            try {
                                T8 = android.support.v4.media.session.a.z(interfaceC0168f4.j(str6, (h) obj9));
                            } catch (Throwable th3) {
                                T8 = h5.e.T(th3.getClass().getSimpleName(), th3.toString(), AbstractC0034i.k("Cause: ", th3.getCause(), ", Stacktrace: ", Log.getStackTraceString(th3)));
                            }
                            cVar.g(T8);
                            return;
                        case 3:
                            InterfaceC0168f interfaceC0168f5 = interfaceC0168f;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list5 = (List) obj;
                            Object obj10 = list5.get(0);
                            q5.h.c(obj10, "null cannot be cast to non-null type kotlin.String");
                            String str7 = (String) obj10;
                            Object obj11 = list5.get(1);
                            q5.h.c(obj11, "null cannot be cast to non-null type io.flutter.plugins.sharedpreferences.SharedPreferencesPigeonOptions");
                            try {
                                T9 = android.support.v4.media.session.a.z(interfaceC0168f5.h(str7, (h) obj11));
                            } catch (Throwable th4) {
                                T9 = h5.e.T(th4.getClass().getSimpleName(), th4.toString(), AbstractC0034i.k("Cause: ", th4.getCause(), ", Stacktrace: ", Log.getStackTraceString(th4)));
                            }
                            cVar.g(T9);
                            return;
                        case 4:
                            InterfaceC0168f interfaceC0168f6 = interfaceC0168f;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list6 = (List) obj;
                            Object obj12 = list6.get(0);
                            q5.h.c(obj12, "null cannot be cast to non-null type kotlin.String");
                            String str8 = (String) obj12;
                            Object obj13 = list6.get(1);
                            q5.h.c(obj13, "null cannot be cast to non-null type io.flutter.plugins.sharedpreferences.SharedPreferencesPigeonOptions");
                            try {
                                T10 = android.support.v4.media.session.a.z(interfaceC0168f6.d(str8, (h) obj13));
                            } catch (Throwable th5) {
                                T10 = h5.e.T(th5.getClass().getSimpleName(), th5.toString(), AbstractC0034i.k("Cause: ", th5.getCause(), ", Stacktrace: ", Log.getStackTraceString(th5)));
                            }
                            cVar.g(T10);
                            return;
                        case 5:
                            InterfaceC0168f interfaceC0168f7 = interfaceC0168f;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list7 = (List) obj;
                            Object obj14 = list7.get(0);
                            q5.h.c(obj14, "null cannot be cast to non-null type kotlin.String");
                            String str9 = (String) obj14;
                            Object obj15 = list7.get(1);
                            q5.h.c(obj15, "null cannot be cast to non-null type io.flutter.plugins.sharedpreferences.SharedPreferencesPigeonOptions");
                            try {
                                T11 = android.support.v4.media.session.a.z(interfaceC0168f7.m(str9, (h) obj15));
                            } catch (Throwable th6) {
                                T11 = h5.e.T(th6.getClass().getSimpleName(), th6.toString(), AbstractC0034i.k("Cause: ", th6.getCause(), ", Stacktrace: ", Log.getStackTraceString(th6)));
                            }
                            cVar.g(T11);
                            return;
                        case 6:
                            InterfaceC0168f interfaceC0168f8 = interfaceC0168f;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list8 = (List) obj;
                            Object obj16 = list8.get(0);
                            q5.h.c(obj16, "null cannot be cast to non-null type kotlin.String");
                            String str10 = (String) obj16;
                            Object obj17 = list8.get(1);
                            q5.h.c(obj17, "null cannot be cast to non-null type kotlin.Boolean");
                            boolean booleanValue = ((Boolean) obj17).booleanValue();
                            Object obj18 = list8.get(2);
                            q5.h.c(obj18, "null cannot be cast to non-null type io.flutter.plugins.sharedpreferences.SharedPreferencesPigeonOptions");
                            try {
                                interfaceC0168f8.i(str10, booleanValue, (h) obj18);
                                T12 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th7) {
                                T12 = h5.e.T(th7.getClass().getSimpleName(), th7.toString(), AbstractC0034i.k("Cause: ", th7.getCause(), ", Stacktrace: ", Log.getStackTraceString(th7)));
                            }
                            cVar.g(T12);
                            return;
                        case 7:
                            InterfaceC0168f interfaceC0168f9 = interfaceC0168f;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list9 = (List) obj;
                            Object obj19 = list9.get(0);
                            q5.h.c(obj19, "null cannot be cast to non-null type kotlin.String");
                            String str11 = (String) obj19;
                            Object obj20 = list9.get(1);
                            q5.h.c(obj20, "null cannot be cast to non-null type io.flutter.plugins.sharedpreferences.SharedPreferencesPigeonOptions");
                            try {
                                T13 = android.support.v4.media.session.a.z(interfaceC0168f9.l(str11, (h) obj20));
                            } catch (Throwable th8) {
                                T13 = h5.e.T(th8.getClass().getSimpleName(), th8.toString(), AbstractC0034i.k("Cause: ", th8.getCause(), ", Stacktrace: ", Log.getStackTraceString(th8)));
                            }
                            cVar.g(T13);
                            return;
                        case 8:
                            InterfaceC0168f interfaceC0168f10 = interfaceC0168f;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list10 = (List) obj;
                            Object obj21 = list10.get(0);
                            q5.h.c(obj21, "null cannot be cast to non-null type kotlin.String");
                            String str12 = (String) obj21;
                            Object obj22 = list10.get(1);
                            q5.h.c(obj22, "null cannot be cast to non-null type io.flutter.plugins.sharedpreferences.SharedPreferencesPigeonOptions");
                            try {
                                T14 = android.support.v4.media.session.a.z(interfaceC0168f10.r(str12, (h) obj22));
                            } catch (Throwable th9) {
                                T14 = h5.e.T(th9.getClass().getSimpleName(), th9.toString(), AbstractC0034i.k("Cause: ", th9.getCause(), ", Stacktrace: ", Log.getStackTraceString(th9)));
                            }
                            cVar.g(T14);
                            return;
                        case ContentHandlerProxy.PROCESSING_INSTRUCTION /* 9 */:
                            InterfaceC0168f interfaceC0168f11 = interfaceC0168f;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list11 = (List) obj;
                            List list12 = (List) list11.get(0);
                            Object obj23 = list11.get(1);
                            q5.h.c(obj23, "null cannot be cast to non-null type io.flutter.plugins.sharedpreferences.SharedPreferencesPigeonOptions");
                            try {
                                interfaceC0168f11.s(list12, (h) obj23);
                                T15 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th10) {
                                T15 = h5.e.T(th10.getClass().getSimpleName(), th10.toString(), AbstractC0034i.k("Cause: ", th10.getCause(), ", Stacktrace: ", Log.getStackTraceString(th10)));
                            }
                            cVar.g(T15);
                            return;
                        case 10:
                            InterfaceC0168f interfaceC0168f12 = interfaceC0168f;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list13 = (List) obj;
                            List list14 = (List) list13.get(0);
                            Object obj24 = list13.get(1);
                            q5.h.c(obj24, "null cannot be cast to non-null type io.flutter.plugins.sharedpreferences.SharedPreferencesPigeonOptions");
                            try {
                                T16 = android.support.v4.media.session.a.z(interfaceC0168f12.t(list14, (h) obj24));
                            } catch (Throwable th11) {
                                T16 = h5.e.T(th11.getClass().getSimpleName(), th11.toString(), AbstractC0034i.k("Cause: ", th11.getCause(), ", Stacktrace: ", Log.getStackTraceString(th11)));
                            }
                            cVar.g(T16);
                            return;
                        case 11:
                            InterfaceC0168f interfaceC0168f13 = interfaceC0168f;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list15 = (List) obj;
                            List list16 = (List) list15.get(0);
                            Object obj25 = list15.get(1);
                            q5.h.c(obj25, "null cannot be cast to non-null type io.flutter.plugins.sharedpreferences.SharedPreferencesPigeonOptions");
                            try {
                                T17 = android.support.v4.media.session.a.z(interfaceC0168f13.f(list16, (h) obj25));
                            } catch (Throwable th12) {
                                T17 = h5.e.T(th12.getClass().getSimpleName(), th12.toString(), AbstractC0034i.k("Cause: ", th12.getCause(), ", Stacktrace: ", Log.getStackTraceString(th12)));
                            }
                            cVar.g(T17);
                            return;
                        case 12:
                            InterfaceC0168f interfaceC0168f14 = interfaceC0168f;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list17 = (List) obj;
                            Object obj26 = list17.get(0);
                            q5.h.c(obj26, "null cannot be cast to non-null type kotlin.String");
                            String str13 = (String) obj26;
                            Object obj27 = list17.get(1);
                            q5.h.c(obj27, "null cannot be cast to non-null type kotlin.String");
                            String str14 = (String) obj27;
                            Object obj28 = list17.get(2);
                            q5.h.c(obj28, "null cannot be cast to non-null type io.flutter.plugins.sharedpreferences.SharedPreferencesPigeonOptions");
                            try {
                                interfaceC0168f14.g(str13, str14, (h) obj28);
                                T18 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th13) {
                                T18 = h5.e.T(th13.getClass().getSimpleName(), th13.toString(), AbstractC0034i.k("Cause: ", th13.getCause(), ", Stacktrace: ", Log.getStackTraceString(th13)));
                            }
                            cVar.g(T18);
                            return;
                        case 13:
                            InterfaceC0168f interfaceC0168f15 = interfaceC0168f;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list18 = (List) obj;
                            Object obj29 = list18.get(0);
                            q5.h.c(obj29, "null cannot be cast to non-null type kotlin.String");
                            String str15 = (String) obj29;
                            Object obj30 = list18.get(1);
                            q5.h.c(obj30, "null cannot be cast to non-null type kotlin.Long");
                            long longValue = ((Long) obj30).longValue();
                            Object obj31 = list18.get(2);
                            q5.h.c(obj31, "null cannot be cast to non-null type io.flutter.plugins.sharedpreferences.SharedPreferencesPigeonOptions");
                            try {
                                interfaceC0168f15.u(str15, longValue, (h) obj31);
                                T19 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th14) {
                                T19 = h5.e.T(th14.getClass().getSimpleName(), th14.toString(), AbstractC0034i.k("Cause: ", th14.getCause(), ", Stacktrace: ", Log.getStackTraceString(th14)));
                            }
                            cVar.g(T19);
                            return;
                        default:
                            InterfaceC0168f interfaceC0168f16 = interfaceC0168f;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list19 = (List) obj;
                            Object obj32 = list19.get(0);
                            q5.h.c(obj32, "null cannot be cast to non-null type kotlin.String");
                            String str16 = (String) obj32;
                            Object obj33 = list19.get(1);
                            q5.h.c(obj33, "null cannot be cast to non-null type kotlin.Double");
                            double doubleValue = ((Double) obj33).doubleValue();
                            Object obj34 = list19.get(2);
                            q5.h.c(obj34, "null cannot be cast to non-null type io.flutter.plugins.sharedpreferences.SharedPreferencesPigeonOptions");
                            try {
                                interfaceC0168f16.o(str16, doubleValue, (h) obj34);
                                T20 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th15) {
                                T20 = h5.e.T(th15.getClass().getSimpleName(), th15.toString(), AbstractC0034i.k("Cause: ", th15.getCause(), ", Stacktrace: ", Log.getStackTraceString(th15)));
                            }
                            cVar.g(T20);
                            return;
                    }
                }
            });
        } else {
            uVar8.y(null);
        }
        v3.u uVar9 = new v3.u(fVar, AbstractC0034i.j("dev.flutter.pigeon.shared_preferences_android.SharedPreferencesAsyncApi.getDouble", str2), a(), c6);
        if (interfaceC0168f != null) {
            final int i14 = 4;
            uVar9.y(new M4.b() { // from class: X4.d
                @Override // M4.b
                public final void e(Object obj, A.c cVar) {
                    List T6;
                    List T7;
                    List T8;
                    List T9;
                    List T10;
                    List T11;
                    List T12;
                    List T13;
                    List T14;
                    List T15;
                    List T16;
                    List T17;
                    List T18;
                    List T19;
                    List T20;
                    switch (i14) {
                        case 0:
                            InterfaceC0168f interfaceC0168f2 = interfaceC0168f;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list = (List) obj;
                            Object obj2 = list.get(0);
                            q5.h.c(obj2, "null cannot be cast to non-null type kotlin.String");
                            String str3 = (String) obj2;
                            Object obj3 = list.get(1);
                            q5.h.c(obj3, "null cannot be cast to non-null type kotlin.String");
                            String str4 = (String) obj3;
                            Object obj4 = list.get(2);
                            q5.h.c(obj4, "null cannot be cast to non-null type io.flutter.plugins.sharedpreferences.SharedPreferencesPigeonOptions");
                            try {
                                interfaceC0168f2.p(str3, str4, (h) obj4);
                                T6 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th) {
                                T6 = h5.e.T(th.getClass().getSimpleName(), th.toString(), AbstractC0034i.k("Cause: ", th.getCause(), ", Stacktrace: ", Log.getStackTraceString(th)));
                            }
                            cVar.g(T6);
                            return;
                        case 1:
                            InterfaceC0168f interfaceC0168f3 = interfaceC0168f;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list2 = (List) obj;
                            Object obj5 = list2.get(0);
                            q5.h.c(obj5, "null cannot be cast to non-null type kotlin.String");
                            String str5 = (String) obj5;
                            Object obj6 = list2.get(1);
                            q5.h.c(obj6, "null cannot be cast to non-null type kotlin.collections.List<kotlin.String>");
                            List list3 = (List) obj6;
                            Object obj7 = list2.get(2);
                            q5.h.c(obj7, "null cannot be cast to non-null type io.flutter.plugins.sharedpreferences.SharedPreferencesPigeonOptions");
                            try {
                                interfaceC0168f3.n(str5, list3, (h) obj7);
                                T7 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th2) {
                                T7 = h5.e.T(th2.getClass().getSimpleName(), th2.toString(), AbstractC0034i.k("Cause: ", th2.getCause(), ", Stacktrace: ", Log.getStackTraceString(th2)));
                            }
                            cVar.g(T7);
                            return;
                        case 2:
                            InterfaceC0168f interfaceC0168f4 = interfaceC0168f;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list4 = (List) obj;
                            Object obj8 = list4.get(0);
                            q5.h.c(obj8, "null cannot be cast to non-null type kotlin.String");
                            String str6 = (String) obj8;
                            Object obj9 = list4.get(1);
                            q5.h.c(obj9, "null cannot be cast to non-null type io.flutter.plugins.sharedpreferences.SharedPreferencesPigeonOptions");
                            try {
                                T8 = android.support.v4.media.session.a.z(interfaceC0168f4.j(str6, (h) obj9));
                            } catch (Throwable th3) {
                                T8 = h5.e.T(th3.getClass().getSimpleName(), th3.toString(), AbstractC0034i.k("Cause: ", th3.getCause(), ", Stacktrace: ", Log.getStackTraceString(th3)));
                            }
                            cVar.g(T8);
                            return;
                        case 3:
                            InterfaceC0168f interfaceC0168f5 = interfaceC0168f;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list5 = (List) obj;
                            Object obj10 = list5.get(0);
                            q5.h.c(obj10, "null cannot be cast to non-null type kotlin.String");
                            String str7 = (String) obj10;
                            Object obj11 = list5.get(1);
                            q5.h.c(obj11, "null cannot be cast to non-null type io.flutter.plugins.sharedpreferences.SharedPreferencesPigeonOptions");
                            try {
                                T9 = android.support.v4.media.session.a.z(interfaceC0168f5.h(str7, (h) obj11));
                            } catch (Throwable th4) {
                                T9 = h5.e.T(th4.getClass().getSimpleName(), th4.toString(), AbstractC0034i.k("Cause: ", th4.getCause(), ", Stacktrace: ", Log.getStackTraceString(th4)));
                            }
                            cVar.g(T9);
                            return;
                        case 4:
                            InterfaceC0168f interfaceC0168f6 = interfaceC0168f;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list6 = (List) obj;
                            Object obj12 = list6.get(0);
                            q5.h.c(obj12, "null cannot be cast to non-null type kotlin.String");
                            String str8 = (String) obj12;
                            Object obj13 = list6.get(1);
                            q5.h.c(obj13, "null cannot be cast to non-null type io.flutter.plugins.sharedpreferences.SharedPreferencesPigeonOptions");
                            try {
                                T10 = android.support.v4.media.session.a.z(interfaceC0168f6.d(str8, (h) obj13));
                            } catch (Throwable th5) {
                                T10 = h5.e.T(th5.getClass().getSimpleName(), th5.toString(), AbstractC0034i.k("Cause: ", th5.getCause(), ", Stacktrace: ", Log.getStackTraceString(th5)));
                            }
                            cVar.g(T10);
                            return;
                        case 5:
                            InterfaceC0168f interfaceC0168f7 = interfaceC0168f;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list7 = (List) obj;
                            Object obj14 = list7.get(0);
                            q5.h.c(obj14, "null cannot be cast to non-null type kotlin.String");
                            String str9 = (String) obj14;
                            Object obj15 = list7.get(1);
                            q5.h.c(obj15, "null cannot be cast to non-null type io.flutter.plugins.sharedpreferences.SharedPreferencesPigeonOptions");
                            try {
                                T11 = android.support.v4.media.session.a.z(interfaceC0168f7.m(str9, (h) obj15));
                            } catch (Throwable th6) {
                                T11 = h5.e.T(th6.getClass().getSimpleName(), th6.toString(), AbstractC0034i.k("Cause: ", th6.getCause(), ", Stacktrace: ", Log.getStackTraceString(th6)));
                            }
                            cVar.g(T11);
                            return;
                        case 6:
                            InterfaceC0168f interfaceC0168f8 = interfaceC0168f;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list8 = (List) obj;
                            Object obj16 = list8.get(0);
                            q5.h.c(obj16, "null cannot be cast to non-null type kotlin.String");
                            String str10 = (String) obj16;
                            Object obj17 = list8.get(1);
                            q5.h.c(obj17, "null cannot be cast to non-null type kotlin.Boolean");
                            boolean booleanValue = ((Boolean) obj17).booleanValue();
                            Object obj18 = list8.get(2);
                            q5.h.c(obj18, "null cannot be cast to non-null type io.flutter.plugins.sharedpreferences.SharedPreferencesPigeonOptions");
                            try {
                                interfaceC0168f8.i(str10, booleanValue, (h) obj18);
                                T12 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th7) {
                                T12 = h5.e.T(th7.getClass().getSimpleName(), th7.toString(), AbstractC0034i.k("Cause: ", th7.getCause(), ", Stacktrace: ", Log.getStackTraceString(th7)));
                            }
                            cVar.g(T12);
                            return;
                        case 7:
                            InterfaceC0168f interfaceC0168f9 = interfaceC0168f;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list9 = (List) obj;
                            Object obj19 = list9.get(0);
                            q5.h.c(obj19, "null cannot be cast to non-null type kotlin.String");
                            String str11 = (String) obj19;
                            Object obj20 = list9.get(1);
                            q5.h.c(obj20, "null cannot be cast to non-null type io.flutter.plugins.sharedpreferences.SharedPreferencesPigeonOptions");
                            try {
                                T13 = android.support.v4.media.session.a.z(interfaceC0168f9.l(str11, (h) obj20));
                            } catch (Throwable th8) {
                                T13 = h5.e.T(th8.getClass().getSimpleName(), th8.toString(), AbstractC0034i.k("Cause: ", th8.getCause(), ", Stacktrace: ", Log.getStackTraceString(th8)));
                            }
                            cVar.g(T13);
                            return;
                        case 8:
                            InterfaceC0168f interfaceC0168f10 = interfaceC0168f;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list10 = (List) obj;
                            Object obj21 = list10.get(0);
                            q5.h.c(obj21, "null cannot be cast to non-null type kotlin.String");
                            String str12 = (String) obj21;
                            Object obj22 = list10.get(1);
                            q5.h.c(obj22, "null cannot be cast to non-null type io.flutter.plugins.sharedpreferences.SharedPreferencesPigeonOptions");
                            try {
                                T14 = android.support.v4.media.session.a.z(interfaceC0168f10.r(str12, (h) obj22));
                            } catch (Throwable th9) {
                                T14 = h5.e.T(th9.getClass().getSimpleName(), th9.toString(), AbstractC0034i.k("Cause: ", th9.getCause(), ", Stacktrace: ", Log.getStackTraceString(th9)));
                            }
                            cVar.g(T14);
                            return;
                        case ContentHandlerProxy.PROCESSING_INSTRUCTION /* 9 */:
                            InterfaceC0168f interfaceC0168f11 = interfaceC0168f;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list11 = (List) obj;
                            List list12 = (List) list11.get(0);
                            Object obj23 = list11.get(1);
                            q5.h.c(obj23, "null cannot be cast to non-null type io.flutter.plugins.sharedpreferences.SharedPreferencesPigeonOptions");
                            try {
                                interfaceC0168f11.s(list12, (h) obj23);
                                T15 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th10) {
                                T15 = h5.e.T(th10.getClass().getSimpleName(), th10.toString(), AbstractC0034i.k("Cause: ", th10.getCause(), ", Stacktrace: ", Log.getStackTraceString(th10)));
                            }
                            cVar.g(T15);
                            return;
                        case 10:
                            InterfaceC0168f interfaceC0168f12 = interfaceC0168f;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list13 = (List) obj;
                            List list14 = (List) list13.get(0);
                            Object obj24 = list13.get(1);
                            q5.h.c(obj24, "null cannot be cast to non-null type io.flutter.plugins.sharedpreferences.SharedPreferencesPigeonOptions");
                            try {
                                T16 = android.support.v4.media.session.a.z(interfaceC0168f12.t(list14, (h) obj24));
                            } catch (Throwable th11) {
                                T16 = h5.e.T(th11.getClass().getSimpleName(), th11.toString(), AbstractC0034i.k("Cause: ", th11.getCause(), ", Stacktrace: ", Log.getStackTraceString(th11)));
                            }
                            cVar.g(T16);
                            return;
                        case 11:
                            InterfaceC0168f interfaceC0168f13 = interfaceC0168f;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list15 = (List) obj;
                            List list16 = (List) list15.get(0);
                            Object obj25 = list15.get(1);
                            q5.h.c(obj25, "null cannot be cast to non-null type io.flutter.plugins.sharedpreferences.SharedPreferencesPigeonOptions");
                            try {
                                T17 = android.support.v4.media.session.a.z(interfaceC0168f13.f(list16, (h) obj25));
                            } catch (Throwable th12) {
                                T17 = h5.e.T(th12.getClass().getSimpleName(), th12.toString(), AbstractC0034i.k("Cause: ", th12.getCause(), ", Stacktrace: ", Log.getStackTraceString(th12)));
                            }
                            cVar.g(T17);
                            return;
                        case 12:
                            InterfaceC0168f interfaceC0168f14 = interfaceC0168f;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list17 = (List) obj;
                            Object obj26 = list17.get(0);
                            q5.h.c(obj26, "null cannot be cast to non-null type kotlin.String");
                            String str13 = (String) obj26;
                            Object obj27 = list17.get(1);
                            q5.h.c(obj27, "null cannot be cast to non-null type kotlin.String");
                            String str14 = (String) obj27;
                            Object obj28 = list17.get(2);
                            q5.h.c(obj28, "null cannot be cast to non-null type io.flutter.plugins.sharedpreferences.SharedPreferencesPigeonOptions");
                            try {
                                interfaceC0168f14.g(str13, str14, (h) obj28);
                                T18 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th13) {
                                T18 = h5.e.T(th13.getClass().getSimpleName(), th13.toString(), AbstractC0034i.k("Cause: ", th13.getCause(), ", Stacktrace: ", Log.getStackTraceString(th13)));
                            }
                            cVar.g(T18);
                            return;
                        case 13:
                            InterfaceC0168f interfaceC0168f15 = interfaceC0168f;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list18 = (List) obj;
                            Object obj29 = list18.get(0);
                            q5.h.c(obj29, "null cannot be cast to non-null type kotlin.String");
                            String str15 = (String) obj29;
                            Object obj30 = list18.get(1);
                            q5.h.c(obj30, "null cannot be cast to non-null type kotlin.Long");
                            long longValue = ((Long) obj30).longValue();
                            Object obj31 = list18.get(2);
                            q5.h.c(obj31, "null cannot be cast to non-null type io.flutter.plugins.sharedpreferences.SharedPreferencesPigeonOptions");
                            try {
                                interfaceC0168f15.u(str15, longValue, (h) obj31);
                                T19 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th14) {
                                T19 = h5.e.T(th14.getClass().getSimpleName(), th14.toString(), AbstractC0034i.k("Cause: ", th14.getCause(), ", Stacktrace: ", Log.getStackTraceString(th14)));
                            }
                            cVar.g(T19);
                            return;
                        default:
                            InterfaceC0168f interfaceC0168f16 = interfaceC0168f;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list19 = (List) obj;
                            Object obj32 = list19.get(0);
                            q5.h.c(obj32, "null cannot be cast to non-null type kotlin.String");
                            String str16 = (String) obj32;
                            Object obj33 = list19.get(1);
                            q5.h.c(obj33, "null cannot be cast to non-null type kotlin.Double");
                            double doubleValue = ((Double) obj33).doubleValue();
                            Object obj34 = list19.get(2);
                            q5.h.c(obj34, "null cannot be cast to non-null type io.flutter.plugins.sharedpreferences.SharedPreferencesPigeonOptions");
                            try {
                                interfaceC0168f16.o(str16, doubleValue, (h) obj34);
                                T20 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th15) {
                                T20 = h5.e.T(th15.getClass().getSimpleName(), th15.toString(), AbstractC0034i.k("Cause: ", th15.getCause(), ", Stacktrace: ", Log.getStackTraceString(th15)));
                            }
                            cVar.g(T20);
                            return;
                    }
                }
            });
        } else {
            uVar9.y(null);
        }
        v3.u uVar10 = new v3.u(fVar, AbstractC0034i.j("dev.flutter.pigeon.shared_preferences_android.SharedPreferencesAsyncApi.getInt", str2), a(), c6);
        if (interfaceC0168f != null) {
            final int i15 = 5;
            uVar10.y(new M4.b() { // from class: X4.d
                @Override // M4.b
                public final void e(Object obj, A.c cVar) {
                    List T6;
                    List T7;
                    List T8;
                    List T9;
                    List T10;
                    List T11;
                    List T12;
                    List T13;
                    List T14;
                    List T15;
                    List T16;
                    List T17;
                    List T18;
                    List T19;
                    List T20;
                    switch (i15) {
                        case 0:
                            InterfaceC0168f interfaceC0168f2 = interfaceC0168f;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list = (List) obj;
                            Object obj2 = list.get(0);
                            q5.h.c(obj2, "null cannot be cast to non-null type kotlin.String");
                            String str3 = (String) obj2;
                            Object obj3 = list.get(1);
                            q5.h.c(obj3, "null cannot be cast to non-null type kotlin.String");
                            String str4 = (String) obj3;
                            Object obj4 = list.get(2);
                            q5.h.c(obj4, "null cannot be cast to non-null type io.flutter.plugins.sharedpreferences.SharedPreferencesPigeonOptions");
                            try {
                                interfaceC0168f2.p(str3, str4, (h) obj4);
                                T6 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th) {
                                T6 = h5.e.T(th.getClass().getSimpleName(), th.toString(), AbstractC0034i.k("Cause: ", th.getCause(), ", Stacktrace: ", Log.getStackTraceString(th)));
                            }
                            cVar.g(T6);
                            return;
                        case 1:
                            InterfaceC0168f interfaceC0168f3 = interfaceC0168f;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list2 = (List) obj;
                            Object obj5 = list2.get(0);
                            q5.h.c(obj5, "null cannot be cast to non-null type kotlin.String");
                            String str5 = (String) obj5;
                            Object obj6 = list2.get(1);
                            q5.h.c(obj6, "null cannot be cast to non-null type kotlin.collections.List<kotlin.String>");
                            List list3 = (List) obj6;
                            Object obj7 = list2.get(2);
                            q5.h.c(obj7, "null cannot be cast to non-null type io.flutter.plugins.sharedpreferences.SharedPreferencesPigeonOptions");
                            try {
                                interfaceC0168f3.n(str5, list3, (h) obj7);
                                T7 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th2) {
                                T7 = h5.e.T(th2.getClass().getSimpleName(), th2.toString(), AbstractC0034i.k("Cause: ", th2.getCause(), ", Stacktrace: ", Log.getStackTraceString(th2)));
                            }
                            cVar.g(T7);
                            return;
                        case 2:
                            InterfaceC0168f interfaceC0168f4 = interfaceC0168f;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list4 = (List) obj;
                            Object obj8 = list4.get(0);
                            q5.h.c(obj8, "null cannot be cast to non-null type kotlin.String");
                            String str6 = (String) obj8;
                            Object obj9 = list4.get(1);
                            q5.h.c(obj9, "null cannot be cast to non-null type io.flutter.plugins.sharedpreferences.SharedPreferencesPigeonOptions");
                            try {
                                T8 = android.support.v4.media.session.a.z(interfaceC0168f4.j(str6, (h) obj9));
                            } catch (Throwable th3) {
                                T8 = h5.e.T(th3.getClass().getSimpleName(), th3.toString(), AbstractC0034i.k("Cause: ", th3.getCause(), ", Stacktrace: ", Log.getStackTraceString(th3)));
                            }
                            cVar.g(T8);
                            return;
                        case 3:
                            InterfaceC0168f interfaceC0168f5 = interfaceC0168f;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list5 = (List) obj;
                            Object obj10 = list5.get(0);
                            q5.h.c(obj10, "null cannot be cast to non-null type kotlin.String");
                            String str7 = (String) obj10;
                            Object obj11 = list5.get(1);
                            q5.h.c(obj11, "null cannot be cast to non-null type io.flutter.plugins.sharedpreferences.SharedPreferencesPigeonOptions");
                            try {
                                T9 = android.support.v4.media.session.a.z(interfaceC0168f5.h(str7, (h) obj11));
                            } catch (Throwable th4) {
                                T9 = h5.e.T(th4.getClass().getSimpleName(), th4.toString(), AbstractC0034i.k("Cause: ", th4.getCause(), ", Stacktrace: ", Log.getStackTraceString(th4)));
                            }
                            cVar.g(T9);
                            return;
                        case 4:
                            InterfaceC0168f interfaceC0168f6 = interfaceC0168f;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list6 = (List) obj;
                            Object obj12 = list6.get(0);
                            q5.h.c(obj12, "null cannot be cast to non-null type kotlin.String");
                            String str8 = (String) obj12;
                            Object obj13 = list6.get(1);
                            q5.h.c(obj13, "null cannot be cast to non-null type io.flutter.plugins.sharedpreferences.SharedPreferencesPigeonOptions");
                            try {
                                T10 = android.support.v4.media.session.a.z(interfaceC0168f6.d(str8, (h) obj13));
                            } catch (Throwable th5) {
                                T10 = h5.e.T(th5.getClass().getSimpleName(), th5.toString(), AbstractC0034i.k("Cause: ", th5.getCause(), ", Stacktrace: ", Log.getStackTraceString(th5)));
                            }
                            cVar.g(T10);
                            return;
                        case 5:
                            InterfaceC0168f interfaceC0168f7 = interfaceC0168f;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list7 = (List) obj;
                            Object obj14 = list7.get(0);
                            q5.h.c(obj14, "null cannot be cast to non-null type kotlin.String");
                            String str9 = (String) obj14;
                            Object obj15 = list7.get(1);
                            q5.h.c(obj15, "null cannot be cast to non-null type io.flutter.plugins.sharedpreferences.SharedPreferencesPigeonOptions");
                            try {
                                T11 = android.support.v4.media.session.a.z(interfaceC0168f7.m(str9, (h) obj15));
                            } catch (Throwable th6) {
                                T11 = h5.e.T(th6.getClass().getSimpleName(), th6.toString(), AbstractC0034i.k("Cause: ", th6.getCause(), ", Stacktrace: ", Log.getStackTraceString(th6)));
                            }
                            cVar.g(T11);
                            return;
                        case 6:
                            InterfaceC0168f interfaceC0168f8 = interfaceC0168f;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list8 = (List) obj;
                            Object obj16 = list8.get(0);
                            q5.h.c(obj16, "null cannot be cast to non-null type kotlin.String");
                            String str10 = (String) obj16;
                            Object obj17 = list8.get(1);
                            q5.h.c(obj17, "null cannot be cast to non-null type kotlin.Boolean");
                            boolean booleanValue = ((Boolean) obj17).booleanValue();
                            Object obj18 = list8.get(2);
                            q5.h.c(obj18, "null cannot be cast to non-null type io.flutter.plugins.sharedpreferences.SharedPreferencesPigeonOptions");
                            try {
                                interfaceC0168f8.i(str10, booleanValue, (h) obj18);
                                T12 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th7) {
                                T12 = h5.e.T(th7.getClass().getSimpleName(), th7.toString(), AbstractC0034i.k("Cause: ", th7.getCause(), ", Stacktrace: ", Log.getStackTraceString(th7)));
                            }
                            cVar.g(T12);
                            return;
                        case 7:
                            InterfaceC0168f interfaceC0168f9 = interfaceC0168f;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list9 = (List) obj;
                            Object obj19 = list9.get(0);
                            q5.h.c(obj19, "null cannot be cast to non-null type kotlin.String");
                            String str11 = (String) obj19;
                            Object obj20 = list9.get(1);
                            q5.h.c(obj20, "null cannot be cast to non-null type io.flutter.plugins.sharedpreferences.SharedPreferencesPigeonOptions");
                            try {
                                T13 = android.support.v4.media.session.a.z(interfaceC0168f9.l(str11, (h) obj20));
                            } catch (Throwable th8) {
                                T13 = h5.e.T(th8.getClass().getSimpleName(), th8.toString(), AbstractC0034i.k("Cause: ", th8.getCause(), ", Stacktrace: ", Log.getStackTraceString(th8)));
                            }
                            cVar.g(T13);
                            return;
                        case 8:
                            InterfaceC0168f interfaceC0168f10 = interfaceC0168f;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list10 = (List) obj;
                            Object obj21 = list10.get(0);
                            q5.h.c(obj21, "null cannot be cast to non-null type kotlin.String");
                            String str12 = (String) obj21;
                            Object obj22 = list10.get(1);
                            q5.h.c(obj22, "null cannot be cast to non-null type io.flutter.plugins.sharedpreferences.SharedPreferencesPigeonOptions");
                            try {
                                T14 = android.support.v4.media.session.a.z(interfaceC0168f10.r(str12, (h) obj22));
                            } catch (Throwable th9) {
                                T14 = h5.e.T(th9.getClass().getSimpleName(), th9.toString(), AbstractC0034i.k("Cause: ", th9.getCause(), ", Stacktrace: ", Log.getStackTraceString(th9)));
                            }
                            cVar.g(T14);
                            return;
                        case ContentHandlerProxy.PROCESSING_INSTRUCTION /* 9 */:
                            InterfaceC0168f interfaceC0168f11 = interfaceC0168f;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list11 = (List) obj;
                            List list12 = (List) list11.get(0);
                            Object obj23 = list11.get(1);
                            q5.h.c(obj23, "null cannot be cast to non-null type io.flutter.plugins.sharedpreferences.SharedPreferencesPigeonOptions");
                            try {
                                interfaceC0168f11.s(list12, (h) obj23);
                                T15 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th10) {
                                T15 = h5.e.T(th10.getClass().getSimpleName(), th10.toString(), AbstractC0034i.k("Cause: ", th10.getCause(), ", Stacktrace: ", Log.getStackTraceString(th10)));
                            }
                            cVar.g(T15);
                            return;
                        case 10:
                            InterfaceC0168f interfaceC0168f12 = interfaceC0168f;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list13 = (List) obj;
                            List list14 = (List) list13.get(0);
                            Object obj24 = list13.get(1);
                            q5.h.c(obj24, "null cannot be cast to non-null type io.flutter.plugins.sharedpreferences.SharedPreferencesPigeonOptions");
                            try {
                                T16 = android.support.v4.media.session.a.z(interfaceC0168f12.t(list14, (h) obj24));
                            } catch (Throwable th11) {
                                T16 = h5.e.T(th11.getClass().getSimpleName(), th11.toString(), AbstractC0034i.k("Cause: ", th11.getCause(), ", Stacktrace: ", Log.getStackTraceString(th11)));
                            }
                            cVar.g(T16);
                            return;
                        case 11:
                            InterfaceC0168f interfaceC0168f13 = interfaceC0168f;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list15 = (List) obj;
                            List list16 = (List) list15.get(0);
                            Object obj25 = list15.get(1);
                            q5.h.c(obj25, "null cannot be cast to non-null type io.flutter.plugins.sharedpreferences.SharedPreferencesPigeonOptions");
                            try {
                                T17 = android.support.v4.media.session.a.z(interfaceC0168f13.f(list16, (h) obj25));
                            } catch (Throwable th12) {
                                T17 = h5.e.T(th12.getClass().getSimpleName(), th12.toString(), AbstractC0034i.k("Cause: ", th12.getCause(), ", Stacktrace: ", Log.getStackTraceString(th12)));
                            }
                            cVar.g(T17);
                            return;
                        case 12:
                            InterfaceC0168f interfaceC0168f14 = interfaceC0168f;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list17 = (List) obj;
                            Object obj26 = list17.get(0);
                            q5.h.c(obj26, "null cannot be cast to non-null type kotlin.String");
                            String str13 = (String) obj26;
                            Object obj27 = list17.get(1);
                            q5.h.c(obj27, "null cannot be cast to non-null type kotlin.String");
                            String str14 = (String) obj27;
                            Object obj28 = list17.get(2);
                            q5.h.c(obj28, "null cannot be cast to non-null type io.flutter.plugins.sharedpreferences.SharedPreferencesPigeonOptions");
                            try {
                                interfaceC0168f14.g(str13, str14, (h) obj28);
                                T18 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th13) {
                                T18 = h5.e.T(th13.getClass().getSimpleName(), th13.toString(), AbstractC0034i.k("Cause: ", th13.getCause(), ", Stacktrace: ", Log.getStackTraceString(th13)));
                            }
                            cVar.g(T18);
                            return;
                        case 13:
                            InterfaceC0168f interfaceC0168f15 = interfaceC0168f;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list18 = (List) obj;
                            Object obj29 = list18.get(0);
                            q5.h.c(obj29, "null cannot be cast to non-null type kotlin.String");
                            String str15 = (String) obj29;
                            Object obj30 = list18.get(1);
                            q5.h.c(obj30, "null cannot be cast to non-null type kotlin.Long");
                            long longValue = ((Long) obj30).longValue();
                            Object obj31 = list18.get(2);
                            q5.h.c(obj31, "null cannot be cast to non-null type io.flutter.plugins.sharedpreferences.SharedPreferencesPigeonOptions");
                            try {
                                interfaceC0168f15.u(str15, longValue, (h) obj31);
                                T19 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th14) {
                                T19 = h5.e.T(th14.getClass().getSimpleName(), th14.toString(), AbstractC0034i.k("Cause: ", th14.getCause(), ", Stacktrace: ", Log.getStackTraceString(th14)));
                            }
                            cVar.g(T19);
                            return;
                        default:
                            InterfaceC0168f interfaceC0168f16 = interfaceC0168f;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list19 = (List) obj;
                            Object obj32 = list19.get(0);
                            q5.h.c(obj32, "null cannot be cast to non-null type kotlin.String");
                            String str16 = (String) obj32;
                            Object obj33 = list19.get(1);
                            q5.h.c(obj33, "null cannot be cast to non-null type kotlin.Double");
                            double doubleValue = ((Double) obj33).doubleValue();
                            Object obj34 = list19.get(2);
                            q5.h.c(obj34, "null cannot be cast to non-null type io.flutter.plugins.sharedpreferences.SharedPreferencesPigeonOptions");
                            try {
                                interfaceC0168f16.o(str16, doubleValue, (h) obj34);
                                T20 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th15) {
                                T20 = h5.e.T(th15.getClass().getSimpleName(), th15.toString(), AbstractC0034i.k("Cause: ", th15.getCause(), ", Stacktrace: ", Log.getStackTraceString(th15)));
                            }
                            cVar.g(T20);
                            return;
                    }
                }
            });
        } else {
            uVar10.y(null);
        }
        v3.u uVar11 = new v3.u(fVar, AbstractC0034i.j("dev.flutter.pigeon.shared_preferences_android.SharedPreferencesAsyncApi.getPlatformEncodedStringList", str2), a(), c6);
        if (interfaceC0168f != null) {
            final int i16 = 7;
            uVar11.y(new M4.b() { // from class: X4.d
                @Override // M4.b
                public final void e(Object obj, A.c cVar) {
                    List T6;
                    List T7;
                    List T8;
                    List T9;
                    List T10;
                    List T11;
                    List T12;
                    List T13;
                    List T14;
                    List T15;
                    List T16;
                    List T17;
                    List T18;
                    List T19;
                    List T20;
                    switch (i16) {
                        case 0:
                            InterfaceC0168f interfaceC0168f2 = interfaceC0168f;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list = (List) obj;
                            Object obj2 = list.get(0);
                            q5.h.c(obj2, "null cannot be cast to non-null type kotlin.String");
                            String str3 = (String) obj2;
                            Object obj3 = list.get(1);
                            q5.h.c(obj3, "null cannot be cast to non-null type kotlin.String");
                            String str4 = (String) obj3;
                            Object obj4 = list.get(2);
                            q5.h.c(obj4, "null cannot be cast to non-null type io.flutter.plugins.sharedpreferences.SharedPreferencesPigeonOptions");
                            try {
                                interfaceC0168f2.p(str3, str4, (h) obj4);
                                T6 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th) {
                                T6 = h5.e.T(th.getClass().getSimpleName(), th.toString(), AbstractC0034i.k("Cause: ", th.getCause(), ", Stacktrace: ", Log.getStackTraceString(th)));
                            }
                            cVar.g(T6);
                            return;
                        case 1:
                            InterfaceC0168f interfaceC0168f3 = interfaceC0168f;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list2 = (List) obj;
                            Object obj5 = list2.get(0);
                            q5.h.c(obj5, "null cannot be cast to non-null type kotlin.String");
                            String str5 = (String) obj5;
                            Object obj6 = list2.get(1);
                            q5.h.c(obj6, "null cannot be cast to non-null type kotlin.collections.List<kotlin.String>");
                            List list3 = (List) obj6;
                            Object obj7 = list2.get(2);
                            q5.h.c(obj7, "null cannot be cast to non-null type io.flutter.plugins.sharedpreferences.SharedPreferencesPigeonOptions");
                            try {
                                interfaceC0168f3.n(str5, list3, (h) obj7);
                                T7 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th2) {
                                T7 = h5.e.T(th2.getClass().getSimpleName(), th2.toString(), AbstractC0034i.k("Cause: ", th2.getCause(), ", Stacktrace: ", Log.getStackTraceString(th2)));
                            }
                            cVar.g(T7);
                            return;
                        case 2:
                            InterfaceC0168f interfaceC0168f4 = interfaceC0168f;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list4 = (List) obj;
                            Object obj8 = list4.get(0);
                            q5.h.c(obj8, "null cannot be cast to non-null type kotlin.String");
                            String str6 = (String) obj8;
                            Object obj9 = list4.get(1);
                            q5.h.c(obj9, "null cannot be cast to non-null type io.flutter.plugins.sharedpreferences.SharedPreferencesPigeonOptions");
                            try {
                                T8 = android.support.v4.media.session.a.z(interfaceC0168f4.j(str6, (h) obj9));
                            } catch (Throwable th3) {
                                T8 = h5.e.T(th3.getClass().getSimpleName(), th3.toString(), AbstractC0034i.k("Cause: ", th3.getCause(), ", Stacktrace: ", Log.getStackTraceString(th3)));
                            }
                            cVar.g(T8);
                            return;
                        case 3:
                            InterfaceC0168f interfaceC0168f5 = interfaceC0168f;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list5 = (List) obj;
                            Object obj10 = list5.get(0);
                            q5.h.c(obj10, "null cannot be cast to non-null type kotlin.String");
                            String str7 = (String) obj10;
                            Object obj11 = list5.get(1);
                            q5.h.c(obj11, "null cannot be cast to non-null type io.flutter.plugins.sharedpreferences.SharedPreferencesPigeonOptions");
                            try {
                                T9 = android.support.v4.media.session.a.z(interfaceC0168f5.h(str7, (h) obj11));
                            } catch (Throwable th4) {
                                T9 = h5.e.T(th4.getClass().getSimpleName(), th4.toString(), AbstractC0034i.k("Cause: ", th4.getCause(), ", Stacktrace: ", Log.getStackTraceString(th4)));
                            }
                            cVar.g(T9);
                            return;
                        case 4:
                            InterfaceC0168f interfaceC0168f6 = interfaceC0168f;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list6 = (List) obj;
                            Object obj12 = list6.get(0);
                            q5.h.c(obj12, "null cannot be cast to non-null type kotlin.String");
                            String str8 = (String) obj12;
                            Object obj13 = list6.get(1);
                            q5.h.c(obj13, "null cannot be cast to non-null type io.flutter.plugins.sharedpreferences.SharedPreferencesPigeonOptions");
                            try {
                                T10 = android.support.v4.media.session.a.z(interfaceC0168f6.d(str8, (h) obj13));
                            } catch (Throwable th5) {
                                T10 = h5.e.T(th5.getClass().getSimpleName(), th5.toString(), AbstractC0034i.k("Cause: ", th5.getCause(), ", Stacktrace: ", Log.getStackTraceString(th5)));
                            }
                            cVar.g(T10);
                            return;
                        case 5:
                            InterfaceC0168f interfaceC0168f7 = interfaceC0168f;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list7 = (List) obj;
                            Object obj14 = list7.get(0);
                            q5.h.c(obj14, "null cannot be cast to non-null type kotlin.String");
                            String str9 = (String) obj14;
                            Object obj15 = list7.get(1);
                            q5.h.c(obj15, "null cannot be cast to non-null type io.flutter.plugins.sharedpreferences.SharedPreferencesPigeonOptions");
                            try {
                                T11 = android.support.v4.media.session.a.z(interfaceC0168f7.m(str9, (h) obj15));
                            } catch (Throwable th6) {
                                T11 = h5.e.T(th6.getClass().getSimpleName(), th6.toString(), AbstractC0034i.k("Cause: ", th6.getCause(), ", Stacktrace: ", Log.getStackTraceString(th6)));
                            }
                            cVar.g(T11);
                            return;
                        case 6:
                            InterfaceC0168f interfaceC0168f8 = interfaceC0168f;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list8 = (List) obj;
                            Object obj16 = list8.get(0);
                            q5.h.c(obj16, "null cannot be cast to non-null type kotlin.String");
                            String str10 = (String) obj16;
                            Object obj17 = list8.get(1);
                            q5.h.c(obj17, "null cannot be cast to non-null type kotlin.Boolean");
                            boolean booleanValue = ((Boolean) obj17).booleanValue();
                            Object obj18 = list8.get(2);
                            q5.h.c(obj18, "null cannot be cast to non-null type io.flutter.plugins.sharedpreferences.SharedPreferencesPigeonOptions");
                            try {
                                interfaceC0168f8.i(str10, booleanValue, (h) obj18);
                                T12 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th7) {
                                T12 = h5.e.T(th7.getClass().getSimpleName(), th7.toString(), AbstractC0034i.k("Cause: ", th7.getCause(), ", Stacktrace: ", Log.getStackTraceString(th7)));
                            }
                            cVar.g(T12);
                            return;
                        case 7:
                            InterfaceC0168f interfaceC0168f9 = interfaceC0168f;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list9 = (List) obj;
                            Object obj19 = list9.get(0);
                            q5.h.c(obj19, "null cannot be cast to non-null type kotlin.String");
                            String str11 = (String) obj19;
                            Object obj20 = list9.get(1);
                            q5.h.c(obj20, "null cannot be cast to non-null type io.flutter.plugins.sharedpreferences.SharedPreferencesPigeonOptions");
                            try {
                                T13 = android.support.v4.media.session.a.z(interfaceC0168f9.l(str11, (h) obj20));
                            } catch (Throwable th8) {
                                T13 = h5.e.T(th8.getClass().getSimpleName(), th8.toString(), AbstractC0034i.k("Cause: ", th8.getCause(), ", Stacktrace: ", Log.getStackTraceString(th8)));
                            }
                            cVar.g(T13);
                            return;
                        case 8:
                            InterfaceC0168f interfaceC0168f10 = interfaceC0168f;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list10 = (List) obj;
                            Object obj21 = list10.get(0);
                            q5.h.c(obj21, "null cannot be cast to non-null type kotlin.String");
                            String str12 = (String) obj21;
                            Object obj22 = list10.get(1);
                            q5.h.c(obj22, "null cannot be cast to non-null type io.flutter.plugins.sharedpreferences.SharedPreferencesPigeonOptions");
                            try {
                                T14 = android.support.v4.media.session.a.z(interfaceC0168f10.r(str12, (h) obj22));
                            } catch (Throwable th9) {
                                T14 = h5.e.T(th9.getClass().getSimpleName(), th9.toString(), AbstractC0034i.k("Cause: ", th9.getCause(), ", Stacktrace: ", Log.getStackTraceString(th9)));
                            }
                            cVar.g(T14);
                            return;
                        case ContentHandlerProxy.PROCESSING_INSTRUCTION /* 9 */:
                            InterfaceC0168f interfaceC0168f11 = interfaceC0168f;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list11 = (List) obj;
                            List list12 = (List) list11.get(0);
                            Object obj23 = list11.get(1);
                            q5.h.c(obj23, "null cannot be cast to non-null type io.flutter.plugins.sharedpreferences.SharedPreferencesPigeonOptions");
                            try {
                                interfaceC0168f11.s(list12, (h) obj23);
                                T15 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th10) {
                                T15 = h5.e.T(th10.getClass().getSimpleName(), th10.toString(), AbstractC0034i.k("Cause: ", th10.getCause(), ", Stacktrace: ", Log.getStackTraceString(th10)));
                            }
                            cVar.g(T15);
                            return;
                        case 10:
                            InterfaceC0168f interfaceC0168f12 = interfaceC0168f;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list13 = (List) obj;
                            List list14 = (List) list13.get(0);
                            Object obj24 = list13.get(1);
                            q5.h.c(obj24, "null cannot be cast to non-null type io.flutter.plugins.sharedpreferences.SharedPreferencesPigeonOptions");
                            try {
                                T16 = android.support.v4.media.session.a.z(interfaceC0168f12.t(list14, (h) obj24));
                            } catch (Throwable th11) {
                                T16 = h5.e.T(th11.getClass().getSimpleName(), th11.toString(), AbstractC0034i.k("Cause: ", th11.getCause(), ", Stacktrace: ", Log.getStackTraceString(th11)));
                            }
                            cVar.g(T16);
                            return;
                        case 11:
                            InterfaceC0168f interfaceC0168f13 = interfaceC0168f;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list15 = (List) obj;
                            List list16 = (List) list15.get(0);
                            Object obj25 = list15.get(1);
                            q5.h.c(obj25, "null cannot be cast to non-null type io.flutter.plugins.sharedpreferences.SharedPreferencesPigeonOptions");
                            try {
                                T17 = android.support.v4.media.session.a.z(interfaceC0168f13.f(list16, (h) obj25));
                            } catch (Throwable th12) {
                                T17 = h5.e.T(th12.getClass().getSimpleName(), th12.toString(), AbstractC0034i.k("Cause: ", th12.getCause(), ", Stacktrace: ", Log.getStackTraceString(th12)));
                            }
                            cVar.g(T17);
                            return;
                        case 12:
                            InterfaceC0168f interfaceC0168f14 = interfaceC0168f;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list17 = (List) obj;
                            Object obj26 = list17.get(0);
                            q5.h.c(obj26, "null cannot be cast to non-null type kotlin.String");
                            String str13 = (String) obj26;
                            Object obj27 = list17.get(1);
                            q5.h.c(obj27, "null cannot be cast to non-null type kotlin.String");
                            String str14 = (String) obj27;
                            Object obj28 = list17.get(2);
                            q5.h.c(obj28, "null cannot be cast to non-null type io.flutter.plugins.sharedpreferences.SharedPreferencesPigeonOptions");
                            try {
                                interfaceC0168f14.g(str13, str14, (h) obj28);
                                T18 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th13) {
                                T18 = h5.e.T(th13.getClass().getSimpleName(), th13.toString(), AbstractC0034i.k("Cause: ", th13.getCause(), ", Stacktrace: ", Log.getStackTraceString(th13)));
                            }
                            cVar.g(T18);
                            return;
                        case 13:
                            InterfaceC0168f interfaceC0168f15 = interfaceC0168f;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list18 = (List) obj;
                            Object obj29 = list18.get(0);
                            q5.h.c(obj29, "null cannot be cast to non-null type kotlin.String");
                            String str15 = (String) obj29;
                            Object obj30 = list18.get(1);
                            q5.h.c(obj30, "null cannot be cast to non-null type kotlin.Long");
                            long longValue = ((Long) obj30).longValue();
                            Object obj31 = list18.get(2);
                            q5.h.c(obj31, "null cannot be cast to non-null type io.flutter.plugins.sharedpreferences.SharedPreferencesPigeonOptions");
                            try {
                                interfaceC0168f15.u(str15, longValue, (h) obj31);
                                T19 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th14) {
                                T19 = h5.e.T(th14.getClass().getSimpleName(), th14.toString(), AbstractC0034i.k("Cause: ", th14.getCause(), ", Stacktrace: ", Log.getStackTraceString(th14)));
                            }
                            cVar.g(T19);
                            return;
                        default:
                            InterfaceC0168f interfaceC0168f16 = interfaceC0168f;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list19 = (List) obj;
                            Object obj32 = list19.get(0);
                            q5.h.c(obj32, "null cannot be cast to non-null type kotlin.String");
                            String str16 = (String) obj32;
                            Object obj33 = list19.get(1);
                            q5.h.c(obj33, "null cannot be cast to non-null type kotlin.Double");
                            double doubleValue = ((Double) obj33).doubleValue();
                            Object obj34 = list19.get(2);
                            q5.h.c(obj34, "null cannot be cast to non-null type io.flutter.plugins.sharedpreferences.SharedPreferencesPigeonOptions");
                            try {
                                interfaceC0168f16.o(str16, doubleValue, (h) obj34);
                                T20 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th15) {
                                T20 = h5.e.T(th15.getClass().getSimpleName(), th15.toString(), AbstractC0034i.k("Cause: ", th15.getCause(), ", Stacktrace: ", Log.getStackTraceString(th15)));
                            }
                            cVar.g(T20);
                            return;
                    }
                }
            });
        } else {
            uVar11.y(null);
        }
        v3.u uVar12 = new v3.u(fVar, AbstractC0034i.j("dev.flutter.pigeon.shared_preferences_android.SharedPreferencesAsyncApi.getStringList", str2), a(), c6);
        if (interfaceC0168f != null) {
            final int i17 = 8;
            uVar12.y(new M4.b() { // from class: X4.d
                @Override // M4.b
                public final void e(Object obj, A.c cVar) {
                    List T6;
                    List T7;
                    List T8;
                    List T9;
                    List T10;
                    List T11;
                    List T12;
                    List T13;
                    List T14;
                    List T15;
                    List T16;
                    List T17;
                    List T18;
                    List T19;
                    List T20;
                    switch (i17) {
                        case 0:
                            InterfaceC0168f interfaceC0168f2 = interfaceC0168f;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list = (List) obj;
                            Object obj2 = list.get(0);
                            q5.h.c(obj2, "null cannot be cast to non-null type kotlin.String");
                            String str3 = (String) obj2;
                            Object obj3 = list.get(1);
                            q5.h.c(obj3, "null cannot be cast to non-null type kotlin.String");
                            String str4 = (String) obj3;
                            Object obj4 = list.get(2);
                            q5.h.c(obj4, "null cannot be cast to non-null type io.flutter.plugins.sharedpreferences.SharedPreferencesPigeonOptions");
                            try {
                                interfaceC0168f2.p(str3, str4, (h) obj4);
                                T6 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th) {
                                T6 = h5.e.T(th.getClass().getSimpleName(), th.toString(), AbstractC0034i.k("Cause: ", th.getCause(), ", Stacktrace: ", Log.getStackTraceString(th)));
                            }
                            cVar.g(T6);
                            return;
                        case 1:
                            InterfaceC0168f interfaceC0168f3 = interfaceC0168f;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list2 = (List) obj;
                            Object obj5 = list2.get(0);
                            q5.h.c(obj5, "null cannot be cast to non-null type kotlin.String");
                            String str5 = (String) obj5;
                            Object obj6 = list2.get(1);
                            q5.h.c(obj6, "null cannot be cast to non-null type kotlin.collections.List<kotlin.String>");
                            List list3 = (List) obj6;
                            Object obj7 = list2.get(2);
                            q5.h.c(obj7, "null cannot be cast to non-null type io.flutter.plugins.sharedpreferences.SharedPreferencesPigeonOptions");
                            try {
                                interfaceC0168f3.n(str5, list3, (h) obj7);
                                T7 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th2) {
                                T7 = h5.e.T(th2.getClass().getSimpleName(), th2.toString(), AbstractC0034i.k("Cause: ", th2.getCause(), ", Stacktrace: ", Log.getStackTraceString(th2)));
                            }
                            cVar.g(T7);
                            return;
                        case 2:
                            InterfaceC0168f interfaceC0168f4 = interfaceC0168f;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list4 = (List) obj;
                            Object obj8 = list4.get(0);
                            q5.h.c(obj8, "null cannot be cast to non-null type kotlin.String");
                            String str6 = (String) obj8;
                            Object obj9 = list4.get(1);
                            q5.h.c(obj9, "null cannot be cast to non-null type io.flutter.plugins.sharedpreferences.SharedPreferencesPigeonOptions");
                            try {
                                T8 = android.support.v4.media.session.a.z(interfaceC0168f4.j(str6, (h) obj9));
                            } catch (Throwable th3) {
                                T8 = h5.e.T(th3.getClass().getSimpleName(), th3.toString(), AbstractC0034i.k("Cause: ", th3.getCause(), ", Stacktrace: ", Log.getStackTraceString(th3)));
                            }
                            cVar.g(T8);
                            return;
                        case 3:
                            InterfaceC0168f interfaceC0168f5 = interfaceC0168f;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list5 = (List) obj;
                            Object obj10 = list5.get(0);
                            q5.h.c(obj10, "null cannot be cast to non-null type kotlin.String");
                            String str7 = (String) obj10;
                            Object obj11 = list5.get(1);
                            q5.h.c(obj11, "null cannot be cast to non-null type io.flutter.plugins.sharedpreferences.SharedPreferencesPigeonOptions");
                            try {
                                T9 = android.support.v4.media.session.a.z(interfaceC0168f5.h(str7, (h) obj11));
                            } catch (Throwable th4) {
                                T9 = h5.e.T(th4.getClass().getSimpleName(), th4.toString(), AbstractC0034i.k("Cause: ", th4.getCause(), ", Stacktrace: ", Log.getStackTraceString(th4)));
                            }
                            cVar.g(T9);
                            return;
                        case 4:
                            InterfaceC0168f interfaceC0168f6 = interfaceC0168f;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list6 = (List) obj;
                            Object obj12 = list6.get(0);
                            q5.h.c(obj12, "null cannot be cast to non-null type kotlin.String");
                            String str8 = (String) obj12;
                            Object obj13 = list6.get(1);
                            q5.h.c(obj13, "null cannot be cast to non-null type io.flutter.plugins.sharedpreferences.SharedPreferencesPigeonOptions");
                            try {
                                T10 = android.support.v4.media.session.a.z(interfaceC0168f6.d(str8, (h) obj13));
                            } catch (Throwable th5) {
                                T10 = h5.e.T(th5.getClass().getSimpleName(), th5.toString(), AbstractC0034i.k("Cause: ", th5.getCause(), ", Stacktrace: ", Log.getStackTraceString(th5)));
                            }
                            cVar.g(T10);
                            return;
                        case 5:
                            InterfaceC0168f interfaceC0168f7 = interfaceC0168f;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list7 = (List) obj;
                            Object obj14 = list7.get(0);
                            q5.h.c(obj14, "null cannot be cast to non-null type kotlin.String");
                            String str9 = (String) obj14;
                            Object obj15 = list7.get(1);
                            q5.h.c(obj15, "null cannot be cast to non-null type io.flutter.plugins.sharedpreferences.SharedPreferencesPigeonOptions");
                            try {
                                T11 = android.support.v4.media.session.a.z(interfaceC0168f7.m(str9, (h) obj15));
                            } catch (Throwable th6) {
                                T11 = h5.e.T(th6.getClass().getSimpleName(), th6.toString(), AbstractC0034i.k("Cause: ", th6.getCause(), ", Stacktrace: ", Log.getStackTraceString(th6)));
                            }
                            cVar.g(T11);
                            return;
                        case 6:
                            InterfaceC0168f interfaceC0168f8 = interfaceC0168f;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list8 = (List) obj;
                            Object obj16 = list8.get(0);
                            q5.h.c(obj16, "null cannot be cast to non-null type kotlin.String");
                            String str10 = (String) obj16;
                            Object obj17 = list8.get(1);
                            q5.h.c(obj17, "null cannot be cast to non-null type kotlin.Boolean");
                            boolean booleanValue = ((Boolean) obj17).booleanValue();
                            Object obj18 = list8.get(2);
                            q5.h.c(obj18, "null cannot be cast to non-null type io.flutter.plugins.sharedpreferences.SharedPreferencesPigeonOptions");
                            try {
                                interfaceC0168f8.i(str10, booleanValue, (h) obj18);
                                T12 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th7) {
                                T12 = h5.e.T(th7.getClass().getSimpleName(), th7.toString(), AbstractC0034i.k("Cause: ", th7.getCause(), ", Stacktrace: ", Log.getStackTraceString(th7)));
                            }
                            cVar.g(T12);
                            return;
                        case 7:
                            InterfaceC0168f interfaceC0168f9 = interfaceC0168f;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list9 = (List) obj;
                            Object obj19 = list9.get(0);
                            q5.h.c(obj19, "null cannot be cast to non-null type kotlin.String");
                            String str11 = (String) obj19;
                            Object obj20 = list9.get(1);
                            q5.h.c(obj20, "null cannot be cast to non-null type io.flutter.plugins.sharedpreferences.SharedPreferencesPigeonOptions");
                            try {
                                T13 = android.support.v4.media.session.a.z(interfaceC0168f9.l(str11, (h) obj20));
                            } catch (Throwable th8) {
                                T13 = h5.e.T(th8.getClass().getSimpleName(), th8.toString(), AbstractC0034i.k("Cause: ", th8.getCause(), ", Stacktrace: ", Log.getStackTraceString(th8)));
                            }
                            cVar.g(T13);
                            return;
                        case 8:
                            InterfaceC0168f interfaceC0168f10 = interfaceC0168f;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list10 = (List) obj;
                            Object obj21 = list10.get(0);
                            q5.h.c(obj21, "null cannot be cast to non-null type kotlin.String");
                            String str12 = (String) obj21;
                            Object obj22 = list10.get(1);
                            q5.h.c(obj22, "null cannot be cast to non-null type io.flutter.plugins.sharedpreferences.SharedPreferencesPigeonOptions");
                            try {
                                T14 = android.support.v4.media.session.a.z(interfaceC0168f10.r(str12, (h) obj22));
                            } catch (Throwable th9) {
                                T14 = h5.e.T(th9.getClass().getSimpleName(), th9.toString(), AbstractC0034i.k("Cause: ", th9.getCause(), ", Stacktrace: ", Log.getStackTraceString(th9)));
                            }
                            cVar.g(T14);
                            return;
                        case ContentHandlerProxy.PROCESSING_INSTRUCTION /* 9 */:
                            InterfaceC0168f interfaceC0168f11 = interfaceC0168f;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list11 = (List) obj;
                            List list12 = (List) list11.get(0);
                            Object obj23 = list11.get(1);
                            q5.h.c(obj23, "null cannot be cast to non-null type io.flutter.plugins.sharedpreferences.SharedPreferencesPigeonOptions");
                            try {
                                interfaceC0168f11.s(list12, (h) obj23);
                                T15 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th10) {
                                T15 = h5.e.T(th10.getClass().getSimpleName(), th10.toString(), AbstractC0034i.k("Cause: ", th10.getCause(), ", Stacktrace: ", Log.getStackTraceString(th10)));
                            }
                            cVar.g(T15);
                            return;
                        case 10:
                            InterfaceC0168f interfaceC0168f12 = interfaceC0168f;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list13 = (List) obj;
                            List list14 = (List) list13.get(0);
                            Object obj24 = list13.get(1);
                            q5.h.c(obj24, "null cannot be cast to non-null type io.flutter.plugins.sharedpreferences.SharedPreferencesPigeonOptions");
                            try {
                                T16 = android.support.v4.media.session.a.z(interfaceC0168f12.t(list14, (h) obj24));
                            } catch (Throwable th11) {
                                T16 = h5.e.T(th11.getClass().getSimpleName(), th11.toString(), AbstractC0034i.k("Cause: ", th11.getCause(), ", Stacktrace: ", Log.getStackTraceString(th11)));
                            }
                            cVar.g(T16);
                            return;
                        case 11:
                            InterfaceC0168f interfaceC0168f13 = interfaceC0168f;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list15 = (List) obj;
                            List list16 = (List) list15.get(0);
                            Object obj25 = list15.get(1);
                            q5.h.c(obj25, "null cannot be cast to non-null type io.flutter.plugins.sharedpreferences.SharedPreferencesPigeonOptions");
                            try {
                                T17 = android.support.v4.media.session.a.z(interfaceC0168f13.f(list16, (h) obj25));
                            } catch (Throwable th12) {
                                T17 = h5.e.T(th12.getClass().getSimpleName(), th12.toString(), AbstractC0034i.k("Cause: ", th12.getCause(), ", Stacktrace: ", Log.getStackTraceString(th12)));
                            }
                            cVar.g(T17);
                            return;
                        case 12:
                            InterfaceC0168f interfaceC0168f14 = interfaceC0168f;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list17 = (List) obj;
                            Object obj26 = list17.get(0);
                            q5.h.c(obj26, "null cannot be cast to non-null type kotlin.String");
                            String str13 = (String) obj26;
                            Object obj27 = list17.get(1);
                            q5.h.c(obj27, "null cannot be cast to non-null type kotlin.String");
                            String str14 = (String) obj27;
                            Object obj28 = list17.get(2);
                            q5.h.c(obj28, "null cannot be cast to non-null type io.flutter.plugins.sharedpreferences.SharedPreferencesPigeonOptions");
                            try {
                                interfaceC0168f14.g(str13, str14, (h) obj28);
                                T18 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th13) {
                                T18 = h5.e.T(th13.getClass().getSimpleName(), th13.toString(), AbstractC0034i.k("Cause: ", th13.getCause(), ", Stacktrace: ", Log.getStackTraceString(th13)));
                            }
                            cVar.g(T18);
                            return;
                        case 13:
                            InterfaceC0168f interfaceC0168f15 = interfaceC0168f;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list18 = (List) obj;
                            Object obj29 = list18.get(0);
                            q5.h.c(obj29, "null cannot be cast to non-null type kotlin.String");
                            String str15 = (String) obj29;
                            Object obj30 = list18.get(1);
                            q5.h.c(obj30, "null cannot be cast to non-null type kotlin.Long");
                            long longValue = ((Long) obj30).longValue();
                            Object obj31 = list18.get(2);
                            q5.h.c(obj31, "null cannot be cast to non-null type io.flutter.plugins.sharedpreferences.SharedPreferencesPigeonOptions");
                            try {
                                interfaceC0168f15.u(str15, longValue, (h) obj31);
                                T19 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th14) {
                                T19 = h5.e.T(th14.getClass().getSimpleName(), th14.toString(), AbstractC0034i.k("Cause: ", th14.getCause(), ", Stacktrace: ", Log.getStackTraceString(th14)));
                            }
                            cVar.g(T19);
                            return;
                        default:
                            InterfaceC0168f interfaceC0168f16 = interfaceC0168f;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list19 = (List) obj;
                            Object obj32 = list19.get(0);
                            q5.h.c(obj32, "null cannot be cast to non-null type kotlin.String");
                            String str16 = (String) obj32;
                            Object obj33 = list19.get(1);
                            q5.h.c(obj33, "null cannot be cast to non-null type kotlin.Double");
                            double doubleValue = ((Double) obj33).doubleValue();
                            Object obj34 = list19.get(2);
                            q5.h.c(obj34, "null cannot be cast to non-null type io.flutter.plugins.sharedpreferences.SharedPreferencesPigeonOptions");
                            try {
                                interfaceC0168f16.o(str16, doubleValue, (h) obj34);
                                T20 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th15) {
                                T20 = h5.e.T(th15.getClass().getSimpleName(), th15.toString(), AbstractC0034i.k("Cause: ", th15.getCause(), ", Stacktrace: ", Log.getStackTraceString(th15)));
                            }
                            cVar.g(T20);
                            return;
                    }
                }
            });
        } else {
            uVar12.y(null);
        }
        v3.u uVar13 = new v3.u(fVar, AbstractC0034i.j("dev.flutter.pigeon.shared_preferences_android.SharedPreferencesAsyncApi.clear", str2), a(), c6);
        if (interfaceC0168f != null) {
            final int i18 = 9;
            uVar13.y(new M4.b() { // from class: X4.d
                @Override // M4.b
                public final void e(Object obj, A.c cVar) {
                    List T6;
                    List T7;
                    List T8;
                    List T9;
                    List T10;
                    List T11;
                    List T12;
                    List T13;
                    List T14;
                    List T15;
                    List T16;
                    List T17;
                    List T18;
                    List T19;
                    List T20;
                    switch (i18) {
                        case 0:
                            InterfaceC0168f interfaceC0168f2 = interfaceC0168f;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list = (List) obj;
                            Object obj2 = list.get(0);
                            q5.h.c(obj2, "null cannot be cast to non-null type kotlin.String");
                            String str3 = (String) obj2;
                            Object obj3 = list.get(1);
                            q5.h.c(obj3, "null cannot be cast to non-null type kotlin.String");
                            String str4 = (String) obj3;
                            Object obj4 = list.get(2);
                            q5.h.c(obj4, "null cannot be cast to non-null type io.flutter.plugins.sharedpreferences.SharedPreferencesPigeonOptions");
                            try {
                                interfaceC0168f2.p(str3, str4, (h) obj4);
                                T6 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th) {
                                T6 = h5.e.T(th.getClass().getSimpleName(), th.toString(), AbstractC0034i.k("Cause: ", th.getCause(), ", Stacktrace: ", Log.getStackTraceString(th)));
                            }
                            cVar.g(T6);
                            return;
                        case 1:
                            InterfaceC0168f interfaceC0168f3 = interfaceC0168f;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list2 = (List) obj;
                            Object obj5 = list2.get(0);
                            q5.h.c(obj5, "null cannot be cast to non-null type kotlin.String");
                            String str5 = (String) obj5;
                            Object obj6 = list2.get(1);
                            q5.h.c(obj6, "null cannot be cast to non-null type kotlin.collections.List<kotlin.String>");
                            List list3 = (List) obj6;
                            Object obj7 = list2.get(2);
                            q5.h.c(obj7, "null cannot be cast to non-null type io.flutter.plugins.sharedpreferences.SharedPreferencesPigeonOptions");
                            try {
                                interfaceC0168f3.n(str5, list3, (h) obj7);
                                T7 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th2) {
                                T7 = h5.e.T(th2.getClass().getSimpleName(), th2.toString(), AbstractC0034i.k("Cause: ", th2.getCause(), ", Stacktrace: ", Log.getStackTraceString(th2)));
                            }
                            cVar.g(T7);
                            return;
                        case 2:
                            InterfaceC0168f interfaceC0168f4 = interfaceC0168f;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list4 = (List) obj;
                            Object obj8 = list4.get(0);
                            q5.h.c(obj8, "null cannot be cast to non-null type kotlin.String");
                            String str6 = (String) obj8;
                            Object obj9 = list4.get(1);
                            q5.h.c(obj9, "null cannot be cast to non-null type io.flutter.plugins.sharedpreferences.SharedPreferencesPigeonOptions");
                            try {
                                T8 = android.support.v4.media.session.a.z(interfaceC0168f4.j(str6, (h) obj9));
                            } catch (Throwable th3) {
                                T8 = h5.e.T(th3.getClass().getSimpleName(), th3.toString(), AbstractC0034i.k("Cause: ", th3.getCause(), ", Stacktrace: ", Log.getStackTraceString(th3)));
                            }
                            cVar.g(T8);
                            return;
                        case 3:
                            InterfaceC0168f interfaceC0168f5 = interfaceC0168f;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list5 = (List) obj;
                            Object obj10 = list5.get(0);
                            q5.h.c(obj10, "null cannot be cast to non-null type kotlin.String");
                            String str7 = (String) obj10;
                            Object obj11 = list5.get(1);
                            q5.h.c(obj11, "null cannot be cast to non-null type io.flutter.plugins.sharedpreferences.SharedPreferencesPigeonOptions");
                            try {
                                T9 = android.support.v4.media.session.a.z(interfaceC0168f5.h(str7, (h) obj11));
                            } catch (Throwable th4) {
                                T9 = h5.e.T(th4.getClass().getSimpleName(), th4.toString(), AbstractC0034i.k("Cause: ", th4.getCause(), ", Stacktrace: ", Log.getStackTraceString(th4)));
                            }
                            cVar.g(T9);
                            return;
                        case 4:
                            InterfaceC0168f interfaceC0168f6 = interfaceC0168f;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list6 = (List) obj;
                            Object obj12 = list6.get(0);
                            q5.h.c(obj12, "null cannot be cast to non-null type kotlin.String");
                            String str8 = (String) obj12;
                            Object obj13 = list6.get(1);
                            q5.h.c(obj13, "null cannot be cast to non-null type io.flutter.plugins.sharedpreferences.SharedPreferencesPigeonOptions");
                            try {
                                T10 = android.support.v4.media.session.a.z(interfaceC0168f6.d(str8, (h) obj13));
                            } catch (Throwable th5) {
                                T10 = h5.e.T(th5.getClass().getSimpleName(), th5.toString(), AbstractC0034i.k("Cause: ", th5.getCause(), ", Stacktrace: ", Log.getStackTraceString(th5)));
                            }
                            cVar.g(T10);
                            return;
                        case 5:
                            InterfaceC0168f interfaceC0168f7 = interfaceC0168f;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list7 = (List) obj;
                            Object obj14 = list7.get(0);
                            q5.h.c(obj14, "null cannot be cast to non-null type kotlin.String");
                            String str9 = (String) obj14;
                            Object obj15 = list7.get(1);
                            q5.h.c(obj15, "null cannot be cast to non-null type io.flutter.plugins.sharedpreferences.SharedPreferencesPigeonOptions");
                            try {
                                T11 = android.support.v4.media.session.a.z(interfaceC0168f7.m(str9, (h) obj15));
                            } catch (Throwable th6) {
                                T11 = h5.e.T(th6.getClass().getSimpleName(), th6.toString(), AbstractC0034i.k("Cause: ", th6.getCause(), ", Stacktrace: ", Log.getStackTraceString(th6)));
                            }
                            cVar.g(T11);
                            return;
                        case 6:
                            InterfaceC0168f interfaceC0168f8 = interfaceC0168f;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list8 = (List) obj;
                            Object obj16 = list8.get(0);
                            q5.h.c(obj16, "null cannot be cast to non-null type kotlin.String");
                            String str10 = (String) obj16;
                            Object obj17 = list8.get(1);
                            q5.h.c(obj17, "null cannot be cast to non-null type kotlin.Boolean");
                            boolean booleanValue = ((Boolean) obj17).booleanValue();
                            Object obj18 = list8.get(2);
                            q5.h.c(obj18, "null cannot be cast to non-null type io.flutter.plugins.sharedpreferences.SharedPreferencesPigeonOptions");
                            try {
                                interfaceC0168f8.i(str10, booleanValue, (h) obj18);
                                T12 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th7) {
                                T12 = h5.e.T(th7.getClass().getSimpleName(), th7.toString(), AbstractC0034i.k("Cause: ", th7.getCause(), ", Stacktrace: ", Log.getStackTraceString(th7)));
                            }
                            cVar.g(T12);
                            return;
                        case 7:
                            InterfaceC0168f interfaceC0168f9 = interfaceC0168f;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list9 = (List) obj;
                            Object obj19 = list9.get(0);
                            q5.h.c(obj19, "null cannot be cast to non-null type kotlin.String");
                            String str11 = (String) obj19;
                            Object obj20 = list9.get(1);
                            q5.h.c(obj20, "null cannot be cast to non-null type io.flutter.plugins.sharedpreferences.SharedPreferencesPigeonOptions");
                            try {
                                T13 = android.support.v4.media.session.a.z(interfaceC0168f9.l(str11, (h) obj20));
                            } catch (Throwable th8) {
                                T13 = h5.e.T(th8.getClass().getSimpleName(), th8.toString(), AbstractC0034i.k("Cause: ", th8.getCause(), ", Stacktrace: ", Log.getStackTraceString(th8)));
                            }
                            cVar.g(T13);
                            return;
                        case 8:
                            InterfaceC0168f interfaceC0168f10 = interfaceC0168f;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list10 = (List) obj;
                            Object obj21 = list10.get(0);
                            q5.h.c(obj21, "null cannot be cast to non-null type kotlin.String");
                            String str12 = (String) obj21;
                            Object obj22 = list10.get(1);
                            q5.h.c(obj22, "null cannot be cast to non-null type io.flutter.plugins.sharedpreferences.SharedPreferencesPigeonOptions");
                            try {
                                T14 = android.support.v4.media.session.a.z(interfaceC0168f10.r(str12, (h) obj22));
                            } catch (Throwable th9) {
                                T14 = h5.e.T(th9.getClass().getSimpleName(), th9.toString(), AbstractC0034i.k("Cause: ", th9.getCause(), ", Stacktrace: ", Log.getStackTraceString(th9)));
                            }
                            cVar.g(T14);
                            return;
                        case ContentHandlerProxy.PROCESSING_INSTRUCTION /* 9 */:
                            InterfaceC0168f interfaceC0168f11 = interfaceC0168f;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list11 = (List) obj;
                            List list12 = (List) list11.get(0);
                            Object obj23 = list11.get(1);
                            q5.h.c(obj23, "null cannot be cast to non-null type io.flutter.plugins.sharedpreferences.SharedPreferencesPigeonOptions");
                            try {
                                interfaceC0168f11.s(list12, (h) obj23);
                                T15 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th10) {
                                T15 = h5.e.T(th10.getClass().getSimpleName(), th10.toString(), AbstractC0034i.k("Cause: ", th10.getCause(), ", Stacktrace: ", Log.getStackTraceString(th10)));
                            }
                            cVar.g(T15);
                            return;
                        case 10:
                            InterfaceC0168f interfaceC0168f12 = interfaceC0168f;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list13 = (List) obj;
                            List list14 = (List) list13.get(0);
                            Object obj24 = list13.get(1);
                            q5.h.c(obj24, "null cannot be cast to non-null type io.flutter.plugins.sharedpreferences.SharedPreferencesPigeonOptions");
                            try {
                                T16 = android.support.v4.media.session.a.z(interfaceC0168f12.t(list14, (h) obj24));
                            } catch (Throwable th11) {
                                T16 = h5.e.T(th11.getClass().getSimpleName(), th11.toString(), AbstractC0034i.k("Cause: ", th11.getCause(), ", Stacktrace: ", Log.getStackTraceString(th11)));
                            }
                            cVar.g(T16);
                            return;
                        case 11:
                            InterfaceC0168f interfaceC0168f13 = interfaceC0168f;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list15 = (List) obj;
                            List list16 = (List) list15.get(0);
                            Object obj25 = list15.get(1);
                            q5.h.c(obj25, "null cannot be cast to non-null type io.flutter.plugins.sharedpreferences.SharedPreferencesPigeonOptions");
                            try {
                                T17 = android.support.v4.media.session.a.z(interfaceC0168f13.f(list16, (h) obj25));
                            } catch (Throwable th12) {
                                T17 = h5.e.T(th12.getClass().getSimpleName(), th12.toString(), AbstractC0034i.k("Cause: ", th12.getCause(), ", Stacktrace: ", Log.getStackTraceString(th12)));
                            }
                            cVar.g(T17);
                            return;
                        case 12:
                            InterfaceC0168f interfaceC0168f14 = interfaceC0168f;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list17 = (List) obj;
                            Object obj26 = list17.get(0);
                            q5.h.c(obj26, "null cannot be cast to non-null type kotlin.String");
                            String str13 = (String) obj26;
                            Object obj27 = list17.get(1);
                            q5.h.c(obj27, "null cannot be cast to non-null type kotlin.String");
                            String str14 = (String) obj27;
                            Object obj28 = list17.get(2);
                            q5.h.c(obj28, "null cannot be cast to non-null type io.flutter.plugins.sharedpreferences.SharedPreferencesPigeonOptions");
                            try {
                                interfaceC0168f14.g(str13, str14, (h) obj28);
                                T18 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th13) {
                                T18 = h5.e.T(th13.getClass().getSimpleName(), th13.toString(), AbstractC0034i.k("Cause: ", th13.getCause(), ", Stacktrace: ", Log.getStackTraceString(th13)));
                            }
                            cVar.g(T18);
                            return;
                        case 13:
                            InterfaceC0168f interfaceC0168f15 = interfaceC0168f;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list18 = (List) obj;
                            Object obj29 = list18.get(0);
                            q5.h.c(obj29, "null cannot be cast to non-null type kotlin.String");
                            String str15 = (String) obj29;
                            Object obj30 = list18.get(1);
                            q5.h.c(obj30, "null cannot be cast to non-null type kotlin.Long");
                            long longValue = ((Long) obj30).longValue();
                            Object obj31 = list18.get(2);
                            q5.h.c(obj31, "null cannot be cast to non-null type io.flutter.plugins.sharedpreferences.SharedPreferencesPigeonOptions");
                            try {
                                interfaceC0168f15.u(str15, longValue, (h) obj31);
                                T19 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th14) {
                                T19 = h5.e.T(th14.getClass().getSimpleName(), th14.toString(), AbstractC0034i.k("Cause: ", th14.getCause(), ", Stacktrace: ", Log.getStackTraceString(th14)));
                            }
                            cVar.g(T19);
                            return;
                        default:
                            InterfaceC0168f interfaceC0168f16 = interfaceC0168f;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list19 = (List) obj;
                            Object obj32 = list19.get(0);
                            q5.h.c(obj32, "null cannot be cast to non-null type kotlin.String");
                            String str16 = (String) obj32;
                            Object obj33 = list19.get(1);
                            q5.h.c(obj33, "null cannot be cast to non-null type kotlin.Double");
                            double doubleValue = ((Double) obj33).doubleValue();
                            Object obj34 = list19.get(2);
                            q5.h.c(obj34, "null cannot be cast to non-null type io.flutter.plugins.sharedpreferences.SharedPreferencesPigeonOptions");
                            try {
                                interfaceC0168f16.o(str16, doubleValue, (h) obj34);
                                T20 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th15) {
                                T20 = h5.e.T(th15.getClass().getSimpleName(), th15.toString(), AbstractC0034i.k("Cause: ", th15.getCause(), ", Stacktrace: ", Log.getStackTraceString(th15)));
                            }
                            cVar.g(T20);
                            return;
                    }
                }
            });
        } else {
            uVar13.y(null);
        }
        v3.u uVar14 = new v3.u(fVar, AbstractC0034i.j("dev.flutter.pigeon.shared_preferences_android.SharedPreferencesAsyncApi.getAll", str2), a(), c6);
        if (interfaceC0168f != null) {
            final int i19 = 10;
            uVar14.y(new M4.b() { // from class: X4.d
                @Override // M4.b
                public final void e(Object obj, A.c cVar) {
                    List T6;
                    List T7;
                    List T8;
                    List T9;
                    List T10;
                    List T11;
                    List T12;
                    List T13;
                    List T14;
                    List T15;
                    List T16;
                    List T17;
                    List T18;
                    List T19;
                    List T20;
                    switch (i19) {
                        case 0:
                            InterfaceC0168f interfaceC0168f2 = interfaceC0168f;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list = (List) obj;
                            Object obj2 = list.get(0);
                            q5.h.c(obj2, "null cannot be cast to non-null type kotlin.String");
                            String str3 = (String) obj2;
                            Object obj3 = list.get(1);
                            q5.h.c(obj3, "null cannot be cast to non-null type kotlin.String");
                            String str4 = (String) obj3;
                            Object obj4 = list.get(2);
                            q5.h.c(obj4, "null cannot be cast to non-null type io.flutter.plugins.sharedpreferences.SharedPreferencesPigeonOptions");
                            try {
                                interfaceC0168f2.p(str3, str4, (h) obj4);
                                T6 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th) {
                                T6 = h5.e.T(th.getClass().getSimpleName(), th.toString(), AbstractC0034i.k("Cause: ", th.getCause(), ", Stacktrace: ", Log.getStackTraceString(th)));
                            }
                            cVar.g(T6);
                            return;
                        case 1:
                            InterfaceC0168f interfaceC0168f3 = interfaceC0168f;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list2 = (List) obj;
                            Object obj5 = list2.get(0);
                            q5.h.c(obj5, "null cannot be cast to non-null type kotlin.String");
                            String str5 = (String) obj5;
                            Object obj6 = list2.get(1);
                            q5.h.c(obj6, "null cannot be cast to non-null type kotlin.collections.List<kotlin.String>");
                            List list3 = (List) obj6;
                            Object obj7 = list2.get(2);
                            q5.h.c(obj7, "null cannot be cast to non-null type io.flutter.plugins.sharedpreferences.SharedPreferencesPigeonOptions");
                            try {
                                interfaceC0168f3.n(str5, list3, (h) obj7);
                                T7 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th2) {
                                T7 = h5.e.T(th2.getClass().getSimpleName(), th2.toString(), AbstractC0034i.k("Cause: ", th2.getCause(), ", Stacktrace: ", Log.getStackTraceString(th2)));
                            }
                            cVar.g(T7);
                            return;
                        case 2:
                            InterfaceC0168f interfaceC0168f4 = interfaceC0168f;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list4 = (List) obj;
                            Object obj8 = list4.get(0);
                            q5.h.c(obj8, "null cannot be cast to non-null type kotlin.String");
                            String str6 = (String) obj8;
                            Object obj9 = list4.get(1);
                            q5.h.c(obj9, "null cannot be cast to non-null type io.flutter.plugins.sharedpreferences.SharedPreferencesPigeonOptions");
                            try {
                                T8 = android.support.v4.media.session.a.z(interfaceC0168f4.j(str6, (h) obj9));
                            } catch (Throwable th3) {
                                T8 = h5.e.T(th3.getClass().getSimpleName(), th3.toString(), AbstractC0034i.k("Cause: ", th3.getCause(), ", Stacktrace: ", Log.getStackTraceString(th3)));
                            }
                            cVar.g(T8);
                            return;
                        case 3:
                            InterfaceC0168f interfaceC0168f5 = interfaceC0168f;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list5 = (List) obj;
                            Object obj10 = list5.get(0);
                            q5.h.c(obj10, "null cannot be cast to non-null type kotlin.String");
                            String str7 = (String) obj10;
                            Object obj11 = list5.get(1);
                            q5.h.c(obj11, "null cannot be cast to non-null type io.flutter.plugins.sharedpreferences.SharedPreferencesPigeonOptions");
                            try {
                                T9 = android.support.v4.media.session.a.z(interfaceC0168f5.h(str7, (h) obj11));
                            } catch (Throwable th4) {
                                T9 = h5.e.T(th4.getClass().getSimpleName(), th4.toString(), AbstractC0034i.k("Cause: ", th4.getCause(), ", Stacktrace: ", Log.getStackTraceString(th4)));
                            }
                            cVar.g(T9);
                            return;
                        case 4:
                            InterfaceC0168f interfaceC0168f6 = interfaceC0168f;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list6 = (List) obj;
                            Object obj12 = list6.get(0);
                            q5.h.c(obj12, "null cannot be cast to non-null type kotlin.String");
                            String str8 = (String) obj12;
                            Object obj13 = list6.get(1);
                            q5.h.c(obj13, "null cannot be cast to non-null type io.flutter.plugins.sharedpreferences.SharedPreferencesPigeonOptions");
                            try {
                                T10 = android.support.v4.media.session.a.z(interfaceC0168f6.d(str8, (h) obj13));
                            } catch (Throwable th5) {
                                T10 = h5.e.T(th5.getClass().getSimpleName(), th5.toString(), AbstractC0034i.k("Cause: ", th5.getCause(), ", Stacktrace: ", Log.getStackTraceString(th5)));
                            }
                            cVar.g(T10);
                            return;
                        case 5:
                            InterfaceC0168f interfaceC0168f7 = interfaceC0168f;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list7 = (List) obj;
                            Object obj14 = list7.get(0);
                            q5.h.c(obj14, "null cannot be cast to non-null type kotlin.String");
                            String str9 = (String) obj14;
                            Object obj15 = list7.get(1);
                            q5.h.c(obj15, "null cannot be cast to non-null type io.flutter.plugins.sharedpreferences.SharedPreferencesPigeonOptions");
                            try {
                                T11 = android.support.v4.media.session.a.z(interfaceC0168f7.m(str9, (h) obj15));
                            } catch (Throwable th6) {
                                T11 = h5.e.T(th6.getClass().getSimpleName(), th6.toString(), AbstractC0034i.k("Cause: ", th6.getCause(), ", Stacktrace: ", Log.getStackTraceString(th6)));
                            }
                            cVar.g(T11);
                            return;
                        case 6:
                            InterfaceC0168f interfaceC0168f8 = interfaceC0168f;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list8 = (List) obj;
                            Object obj16 = list8.get(0);
                            q5.h.c(obj16, "null cannot be cast to non-null type kotlin.String");
                            String str10 = (String) obj16;
                            Object obj17 = list8.get(1);
                            q5.h.c(obj17, "null cannot be cast to non-null type kotlin.Boolean");
                            boolean booleanValue = ((Boolean) obj17).booleanValue();
                            Object obj18 = list8.get(2);
                            q5.h.c(obj18, "null cannot be cast to non-null type io.flutter.plugins.sharedpreferences.SharedPreferencesPigeonOptions");
                            try {
                                interfaceC0168f8.i(str10, booleanValue, (h) obj18);
                                T12 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th7) {
                                T12 = h5.e.T(th7.getClass().getSimpleName(), th7.toString(), AbstractC0034i.k("Cause: ", th7.getCause(), ", Stacktrace: ", Log.getStackTraceString(th7)));
                            }
                            cVar.g(T12);
                            return;
                        case 7:
                            InterfaceC0168f interfaceC0168f9 = interfaceC0168f;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list9 = (List) obj;
                            Object obj19 = list9.get(0);
                            q5.h.c(obj19, "null cannot be cast to non-null type kotlin.String");
                            String str11 = (String) obj19;
                            Object obj20 = list9.get(1);
                            q5.h.c(obj20, "null cannot be cast to non-null type io.flutter.plugins.sharedpreferences.SharedPreferencesPigeonOptions");
                            try {
                                T13 = android.support.v4.media.session.a.z(interfaceC0168f9.l(str11, (h) obj20));
                            } catch (Throwable th8) {
                                T13 = h5.e.T(th8.getClass().getSimpleName(), th8.toString(), AbstractC0034i.k("Cause: ", th8.getCause(), ", Stacktrace: ", Log.getStackTraceString(th8)));
                            }
                            cVar.g(T13);
                            return;
                        case 8:
                            InterfaceC0168f interfaceC0168f10 = interfaceC0168f;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list10 = (List) obj;
                            Object obj21 = list10.get(0);
                            q5.h.c(obj21, "null cannot be cast to non-null type kotlin.String");
                            String str12 = (String) obj21;
                            Object obj22 = list10.get(1);
                            q5.h.c(obj22, "null cannot be cast to non-null type io.flutter.plugins.sharedpreferences.SharedPreferencesPigeonOptions");
                            try {
                                T14 = android.support.v4.media.session.a.z(interfaceC0168f10.r(str12, (h) obj22));
                            } catch (Throwable th9) {
                                T14 = h5.e.T(th9.getClass().getSimpleName(), th9.toString(), AbstractC0034i.k("Cause: ", th9.getCause(), ", Stacktrace: ", Log.getStackTraceString(th9)));
                            }
                            cVar.g(T14);
                            return;
                        case ContentHandlerProxy.PROCESSING_INSTRUCTION /* 9 */:
                            InterfaceC0168f interfaceC0168f11 = interfaceC0168f;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list11 = (List) obj;
                            List list12 = (List) list11.get(0);
                            Object obj23 = list11.get(1);
                            q5.h.c(obj23, "null cannot be cast to non-null type io.flutter.plugins.sharedpreferences.SharedPreferencesPigeonOptions");
                            try {
                                interfaceC0168f11.s(list12, (h) obj23);
                                T15 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th10) {
                                T15 = h5.e.T(th10.getClass().getSimpleName(), th10.toString(), AbstractC0034i.k("Cause: ", th10.getCause(), ", Stacktrace: ", Log.getStackTraceString(th10)));
                            }
                            cVar.g(T15);
                            return;
                        case 10:
                            InterfaceC0168f interfaceC0168f12 = interfaceC0168f;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list13 = (List) obj;
                            List list14 = (List) list13.get(0);
                            Object obj24 = list13.get(1);
                            q5.h.c(obj24, "null cannot be cast to non-null type io.flutter.plugins.sharedpreferences.SharedPreferencesPigeonOptions");
                            try {
                                T16 = android.support.v4.media.session.a.z(interfaceC0168f12.t(list14, (h) obj24));
                            } catch (Throwable th11) {
                                T16 = h5.e.T(th11.getClass().getSimpleName(), th11.toString(), AbstractC0034i.k("Cause: ", th11.getCause(), ", Stacktrace: ", Log.getStackTraceString(th11)));
                            }
                            cVar.g(T16);
                            return;
                        case 11:
                            InterfaceC0168f interfaceC0168f13 = interfaceC0168f;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list15 = (List) obj;
                            List list16 = (List) list15.get(0);
                            Object obj25 = list15.get(1);
                            q5.h.c(obj25, "null cannot be cast to non-null type io.flutter.plugins.sharedpreferences.SharedPreferencesPigeonOptions");
                            try {
                                T17 = android.support.v4.media.session.a.z(interfaceC0168f13.f(list16, (h) obj25));
                            } catch (Throwable th12) {
                                T17 = h5.e.T(th12.getClass().getSimpleName(), th12.toString(), AbstractC0034i.k("Cause: ", th12.getCause(), ", Stacktrace: ", Log.getStackTraceString(th12)));
                            }
                            cVar.g(T17);
                            return;
                        case 12:
                            InterfaceC0168f interfaceC0168f14 = interfaceC0168f;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list17 = (List) obj;
                            Object obj26 = list17.get(0);
                            q5.h.c(obj26, "null cannot be cast to non-null type kotlin.String");
                            String str13 = (String) obj26;
                            Object obj27 = list17.get(1);
                            q5.h.c(obj27, "null cannot be cast to non-null type kotlin.String");
                            String str14 = (String) obj27;
                            Object obj28 = list17.get(2);
                            q5.h.c(obj28, "null cannot be cast to non-null type io.flutter.plugins.sharedpreferences.SharedPreferencesPigeonOptions");
                            try {
                                interfaceC0168f14.g(str13, str14, (h) obj28);
                                T18 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th13) {
                                T18 = h5.e.T(th13.getClass().getSimpleName(), th13.toString(), AbstractC0034i.k("Cause: ", th13.getCause(), ", Stacktrace: ", Log.getStackTraceString(th13)));
                            }
                            cVar.g(T18);
                            return;
                        case 13:
                            InterfaceC0168f interfaceC0168f15 = interfaceC0168f;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list18 = (List) obj;
                            Object obj29 = list18.get(0);
                            q5.h.c(obj29, "null cannot be cast to non-null type kotlin.String");
                            String str15 = (String) obj29;
                            Object obj30 = list18.get(1);
                            q5.h.c(obj30, "null cannot be cast to non-null type kotlin.Long");
                            long longValue = ((Long) obj30).longValue();
                            Object obj31 = list18.get(2);
                            q5.h.c(obj31, "null cannot be cast to non-null type io.flutter.plugins.sharedpreferences.SharedPreferencesPigeonOptions");
                            try {
                                interfaceC0168f15.u(str15, longValue, (h) obj31);
                                T19 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th14) {
                                T19 = h5.e.T(th14.getClass().getSimpleName(), th14.toString(), AbstractC0034i.k("Cause: ", th14.getCause(), ", Stacktrace: ", Log.getStackTraceString(th14)));
                            }
                            cVar.g(T19);
                            return;
                        default:
                            InterfaceC0168f interfaceC0168f16 = interfaceC0168f;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list19 = (List) obj;
                            Object obj32 = list19.get(0);
                            q5.h.c(obj32, "null cannot be cast to non-null type kotlin.String");
                            String str16 = (String) obj32;
                            Object obj33 = list19.get(1);
                            q5.h.c(obj33, "null cannot be cast to non-null type kotlin.Double");
                            double doubleValue = ((Double) obj33).doubleValue();
                            Object obj34 = list19.get(2);
                            q5.h.c(obj34, "null cannot be cast to non-null type io.flutter.plugins.sharedpreferences.SharedPreferencesPigeonOptions");
                            try {
                                interfaceC0168f16.o(str16, doubleValue, (h) obj34);
                                T20 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th15) {
                                T20 = h5.e.T(th15.getClass().getSimpleName(), th15.toString(), AbstractC0034i.k("Cause: ", th15.getCause(), ", Stacktrace: ", Log.getStackTraceString(th15)));
                            }
                            cVar.g(T20);
                            return;
                    }
                }
            });
        } else {
            uVar14.y(null);
        }
        v3.u uVar15 = new v3.u(fVar, AbstractC0034i.j("dev.flutter.pigeon.shared_preferences_android.SharedPreferencesAsyncApi.getKeys", str2), a(), c6);
        if (interfaceC0168f != null) {
            final int i20 = 11;
            uVar15.y(new M4.b() { // from class: X4.d
                @Override // M4.b
                public final void e(Object obj, A.c cVar) {
                    List T6;
                    List T7;
                    List T8;
                    List T9;
                    List T10;
                    List T11;
                    List T12;
                    List T13;
                    List T14;
                    List T15;
                    List T16;
                    List T17;
                    List T18;
                    List T19;
                    List T20;
                    switch (i20) {
                        case 0:
                            InterfaceC0168f interfaceC0168f2 = interfaceC0168f;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list = (List) obj;
                            Object obj2 = list.get(0);
                            q5.h.c(obj2, "null cannot be cast to non-null type kotlin.String");
                            String str3 = (String) obj2;
                            Object obj3 = list.get(1);
                            q5.h.c(obj3, "null cannot be cast to non-null type kotlin.String");
                            String str4 = (String) obj3;
                            Object obj4 = list.get(2);
                            q5.h.c(obj4, "null cannot be cast to non-null type io.flutter.plugins.sharedpreferences.SharedPreferencesPigeonOptions");
                            try {
                                interfaceC0168f2.p(str3, str4, (h) obj4);
                                T6 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th) {
                                T6 = h5.e.T(th.getClass().getSimpleName(), th.toString(), AbstractC0034i.k("Cause: ", th.getCause(), ", Stacktrace: ", Log.getStackTraceString(th)));
                            }
                            cVar.g(T6);
                            return;
                        case 1:
                            InterfaceC0168f interfaceC0168f3 = interfaceC0168f;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list2 = (List) obj;
                            Object obj5 = list2.get(0);
                            q5.h.c(obj5, "null cannot be cast to non-null type kotlin.String");
                            String str5 = (String) obj5;
                            Object obj6 = list2.get(1);
                            q5.h.c(obj6, "null cannot be cast to non-null type kotlin.collections.List<kotlin.String>");
                            List list3 = (List) obj6;
                            Object obj7 = list2.get(2);
                            q5.h.c(obj7, "null cannot be cast to non-null type io.flutter.plugins.sharedpreferences.SharedPreferencesPigeonOptions");
                            try {
                                interfaceC0168f3.n(str5, list3, (h) obj7);
                                T7 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th2) {
                                T7 = h5.e.T(th2.getClass().getSimpleName(), th2.toString(), AbstractC0034i.k("Cause: ", th2.getCause(), ", Stacktrace: ", Log.getStackTraceString(th2)));
                            }
                            cVar.g(T7);
                            return;
                        case 2:
                            InterfaceC0168f interfaceC0168f4 = interfaceC0168f;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list4 = (List) obj;
                            Object obj8 = list4.get(0);
                            q5.h.c(obj8, "null cannot be cast to non-null type kotlin.String");
                            String str6 = (String) obj8;
                            Object obj9 = list4.get(1);
                            q5.h.c(obj9, "null cannot be cast to non-null type io.flutter.plugins.sharedpreferences.SharedPreferencesPigeonOptions");
                            try {
                                T8 = android.support.v4.media.session.a.z(interfaceC0168f4.j(str6, (h) obj9));
                            } catch (Throwable th3) {
                                T8 = h5.e.T(th3.getClass().getSimpleName(), th3.toString(), AbstractC0034i.k("Cause: ", th3.getCause(), ", Stacktrace: ", Log.getStackTraceString(th3)));
                            }
                            cVar.g(T8);
                            return;
                        case 3:
                            InterfaceC0168f interfaceC0168f5 = interfaceC0168f;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list5 = (List) obj;
                            Object obj10 = list5.get(0);
                            q5.h.c(obj10, "null cannot be cast to non-null type kotlin.String");
                            String str7 = (String) obj10;
                            Object obj11 = list5.get(1);
                            q5.h.c(obj11, "null cannot be cast to non-null type io.flutter.plugins.sharedpreferences.SharedPreferencesPigeonOptions");
                            try {
                                T9 = android.support.v4.media.session.a.z(interfaceC0168f5.h(str7, (h) obj11));
                            } catch (Throwable th4) {
                                T9 = h5.e.T(th4.getClass().getSimpleName(), th4.toString(), AbstractC0034i.k("Cause: ", th4.getCause(), ", Stacktrace: ", Log.getStackTraceString(th4)));
                            }
                            cVar.g(T9);
                            return;
                        case 4:
                            InterfaceC0168f interfaceC0168f6 = interfaceC0168f;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list6 = (List) obj;
                            Object obj12 = list6.get(0);
                            q5.h.c(obj12, "null cannot be cast to non-null type kotlin.String");
                            String str8 = (String) obj12;
                            Object obj13 = list6.get(1);
                            q5.h.c(obj13, "null cannot be cast to non-null type io.flutter.plugins.sharedpreferences.SharedPreferencesPigeonOptions");
                            try {
                                T10 = android.support.v4.media.session.a.z(interfaceC0168f6.d(str8, (h) obj13));
                            } catch (Throwable th5) {
                                T10 = h5.e.T(th5.getClass().getSimpleName(), th5.toString(), AbstractC0034i.k("Cause: ", th5.getCause(), ", Stacktrace: ", Log.getStackTraceString(th5)));
                            }
                            cVar.g(T10);
                            return;
                        case 5:
                            InterfaceC0168f interfaceC0168f7 = interfaceC0168f;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list7 = (List) obj;
                            Object obj14 = list7.get(0);
                            q5.h.c(obj14, "null cannot be cast to non-null type kotlin.String");
                            String str9 = (String) obj14;
                            Object obj15 = list7.get(1);
                            q5.h.c(obj15, "null cannot be cast to non-null type io.flutter.plugins.sharedpreferences.SharedPreferencesPigeonOptions");
                            try {
                                T11 = android.support.v4.media.session.a.z(interfaceC0168f7.m(str9, (h) obj15));
                            } catch (Throwable th6) {
                                T11 = h5.e.T(th6.getClass().getSimpleName(), th6.toString(), AbstractC0034i.k("Cause: ", th6.getCause(), ", Stacktrace: ", Log.getStackTraceString(th6)));
                            }
                            cVar.g(T11);
                            return;
                        case 6:
                            InterfaceC0168f interfaceC0168f8 = interfaceC0168f;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list8 = (List) obj;
                            Object obj16 = list8.get(0);
                            q5.h.c(obj16, "null cannot be cast to non-null type kotlin.String");
                            String str10 = (String) obj16;
                            Object obj17 = list8.get(1);
                            q5.h.c(obj17, "null cannot be cast to non-null type kotlin.Boolean");
                            boolean booleanValue = ((Boolean) obj17).booleanValue();
                            Object obj18 = list8.get(2);
                            q5.h.c(obj18, "null cannot be cast to non-null type io.flutter.plugins.sharedpreferences.SharedPreferencesPigeonOptions");
                            try {
                                interfaceC0168f8.i(str10, booleanValue, (h) obj18);
                                T12 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th7) {
                                T12 = h5.e.T(th7.getClass().getSimpleName(), th7.toString(), AbstractC0034i.k("Cause: ", th7.getCause(), ", Stacktrace: ", Log.getStackTraceString(th7)));
                            }
                            cVar.g(T12);
                            return;
                        case 7:
                            InterfaceC0168f interfaceC0168f9 = interfaceC0168f;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list9 = (List) obj;
                            Object obj19 = list9.get(0);
                            q5.h.c(obj19, "null cannot be cast to non-null type kotlin.String");
                            String str11 = (String) obj19;
                            Object obj20 = list9.get(1);
                            q5.h.c(obj20, "null cannot be cast to non-null type io.flutter.plugins.sharedpreferences.SharedPreferencesPigeonOptions");
                            try {
                                T13 = android.support.v4.media.session.a.z(interfaceC0168f9.l(str11, (h) obj20));
                            } catch (Throwable th8) {
                                T13 = h5.e.T(th8.getClass().getSimpleName(), th8.toString(), AbstractC0034i.k("Cause: ", th8.getCause(), ", Stacktrace: ", Log.getStackTraceString(th8)));
                            }
                            cVar.g(T13);
                            return;
                        case 8:
                            InterfaceC0168f interfaceC0168f10 = interfaceC0168f;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list10 = (List) obj;
                            Object obj21 = list10.get(0);
                            q5.h.c(obj21, "null cannot be cast to non-null type kotlin.String");
                            String str12 = (String) obj21;
                            Object obj22 = list10.get(1);
                            q5.h.c(obj22, "null cannot be cast to non-null type io.flutter.plugins.sharedpreferences.SharedPreferencesPigeonOptions");
                            try {
                                T14 = android.support.v4.media.session.a.z(interfaceC0168f10.r(str12, (h) obj22));
                            } catch (Throwable th9) {
                                T14 = h5.e.T(th9.getClass().getSimpleName(), th9.toString(), AbstractC0034i.k("Cause: ", th9.getCause(), ", Stacktrace: ", Log.getStackTraceString(th9)));
                            }
                            cVar.g(T14);
                            return;
                        case ContentHandlerProxy.PROCESSING_INSTRUCTION /* 9 */:
                            InterfaceC0168f interfaceC0168f11 = interfaceC0168f;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list11 = (List) obj;
                            List list12 = (List) list11.get(0);
                            Object obj23 = list11.get(1);
                            q5.h.c(obj23, "null cannot be cast to non-null type io.flutter.plugins.sharedpreferences.SharedPreferencesPigeonOptions");
                            try {
                                interfaceC0168f11.s(list12, (h) obj23);
                                T15 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th10) {
                                T15 = h5.e.T(th10.getClass().getSimpleName(), th10.toString(), AbstractC0034i.k("Cause: ", th10.getCause(), ", Stacktrace: ", Log.getStackTraceString(th10)));
                            }
                            cVar.g(T15);
                            return;
                        case 10:
                            InterfaceC0168f interfaceC0168f12 = interfaceC0168f;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list13 = (List) obj;
                            List list14 = (List) list13.get(0);
                            Object obj24 = list13.get(1);
                            q5.h.c(obj24, "null cannot be cast to non-null type io.flutter.plugins.sharedpreferences.SharedPreferencesPigeonOptions");
                            try {
                                T16 = android.support.v4.media.session.a.z(interfaceC0168f12.t(list14, (h) obj24));
                            } catch (Throwable th11) {
                                T16 = h5.e.T(th11.getClass().getSimpleName(), th11.toString(), AbstractC0034i.k("Cause: ", th11.getCause(), ", Stacktrace: ", Log.getStackTraceString(th11)));
                            }
                            cVar.g(T16);
                            return;
                        case 11:
                            InterfaceC0168f interfaceC0168f13 = interfaceC0168f;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list15 = (List) obj;
                            List list16 = (List) list15.get(0);
                            Object obj25 = list15.get(1);
                            q5.h.c(obj25, "null cannot be cast to non-null type io.flutter.plugins.sharedpreferences.SharedPreferencesPigeonOptions");
                            try {
                                T17 = android.support.v4.media.session.a.z(interfaceC0168f13.f(list16, (h) obj25));
                            } catch (Throwable th12) {
                                T17 = h5.e.T(th12.getClass().getSimpleName(), th12.toString(), AbstractC0034i.k("Cause: ", th12.getCause(), ", Stacktrace: ", Log.getStackTraceString(th12)));
                            }
                            cVar.g(T17);
                            return;
                        case 12:
                            InterfaceC0168f interfaceC0168f14 = interfaceC0168f;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list17 = (List) obj;
                            Object obj26 = list17.get(0);
                            q5.h.c(obj26, "null cannot be cast to non-null type kotlin.String");
                            String str13 = (String) obj26;
                            Object obj27 = list17.get(1);
                            q5.h.c(obj27, "null cannot be cast to non-null type kotlin.String");
                            String str14 = (String) obj27;
                            Object obj28 = list17.get(2);
                            q5.h.c(obj28, "null cannot be cast to non-null type io.flutter.plugins.sharedpreferences.SharedPreferencesPigeonOptions");
                            try {
                                interfaceC0168f14.g(str13, str14, (h) obj28);
                                T18 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th13) {
                                T18 = h5.e.T(th13.getClass().getSimpleName(), th13.toString(), AbstractC0034i.k("Cause: ", th13.getCause(), ", Stacktrace: ", Log.getStackTraceString(th13)));
                            }
                            cVar.g(T18);
                            return;
                        case 13:
                            InterfaceC0168f interfaceC0168f15 = interfaceC0168f;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list18 = (List) obj;
                            Object obj29 = list18.get(0);
                            q5.h.c(obj29, "null cannot be cast to non-null type kotlin.String");
                            String str15 = (String) obj29;
                            Object obj30 = list18.get(1);
                            q5.h.c(obj30, "null cannot be cast to non-null type kotlin.Long");
                            long longValue = ((Long) obj30).longValue();
                            Object obj31 = list18.get(2);
                            q5.h.c(obj31, "null cannot be cast to non-null type io.flutter.plugins.sharedpreferences.SharedPreferencesPigeonOptions");
                            try {
                                interfaceC0168f15.u(str15, longValue, (h) obj31);
                                T19 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th14) {
                                T19 = h5.e.T(th14.getClass().getSimpleName(), th14.toString(), AbstractC0034i.k("Cause: ", th14.getCause(), ", Stacktrace: ", Log.getStackTraceString(th14)));
                            }
                            cVar.g(T19);
                            return;
                        default:
                            InterfaceC0168f interfaceC0168f16 = interfaceC0168f;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list19 = (List) obj;
                            Object obj32 = list19.get(0);
                            q5.h.c(obj32, "null cannot be cast to non-null type kotlin.String");
                            String str16 = (String) obj32;
                            Object obj33 = list19.get(1);
                            q5.h.c(obj33, "null cannot be cast to non-null type kotlin.Double");
                            double doubleValue = ((Double) obj33).doubleValue();
                            Object obj34 = list19.get(2);
                            q5.h.c(obj34, "null cannot be cast to non-null type io.flutter.plugins.sharedpreferences.SharedPreferencesPigeonOptions");
                            try {
                                interfaceC0168f16.o(str16, doubleValue, (h) obj34);
                                T20 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th15) {
                                T20 = h5.e.T(th15.getClass().getSimpleName(), th15.toString(), AbstractC0034i.k("Cause: ", th15.getCause(), ", Stacktrace: ", Log.getStackTraceString(th15)));
                            }
                            cVar.g(T20);
                            return;
                    }
                }
            });
        } else {
            uVar15.y(null);
        }
    }
}
