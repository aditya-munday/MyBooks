package X4;

import k5.AbstractC0562c;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* loaded from: classes.dex */
public final class r extends AbstractC0562c {

    /* renamed from: r, reason: collision with root package name */
    public /* synthetic */ Object f3693r;

    /* renamed from: s, reason: collision with root package name */
    public int f3694s;

    /* renamed from: t, reason: collision with root package name */
    public final /* synthetic */ l f3695t;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public r(l lVar, i5.d dVar) {
        super(dVar);
        this.f3695t = lVar;
    }

    @Override // k5.AbstractC0560a
    public final Object p(Object obj) {
        this.f3693r = obj;
        this.f3694s |= Integer.MIN_VALUE;
        return this.f3695t.l(null, this);
    }
}
