package X4;

import D.AbstractC0048m;
import E2.G;
import E2.I;
import E2.Z;
import S.C0122o;
import S.C0123p;
import V.AbstractC0133a;
import a.AbstractC0194a;
import android.app.Activity;
import android.app.ActivityManager;
import android.app.ActivityOptions;
import android.app.KeyguardManager;
import android.app.NotificationManager;
import android.app.job.JobInfo;
import android.app.job.JobScheduler;
import android.content.ActivityNotFoundException;
import android.content.ComponentName;
import android.content.ContentResolver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.FeatureInfo;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.content.res.ColorStateList;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.media.AudioDeviceInfo;
import android.media.AudioRouting;
import android.media.AudioTrack;
import android.media.MediaCodec;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.LocaleList;
import android.os.Looper;
import android.os.PersistableBundle;
import android.os.Process;
import android.os.StatFs;
import android.provider.Settings;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.util.Base64;
import android.util.Log;
import android.util.TypedValue;
import android.view.View;
import androidx.core.graphics.drawable.IconCompat;
import androidx.recyclerview.widget.RecyclerView;
import b0.C0253e;
import b2.C0259b;
import b2.C0260c;
import c2.C0294h;
import c2.InterfaceC0290d;
import c5.C0346j;
import c5.C0351o;
import com.google.android.datatransport.runtime.scheduling.jobscheduling.JobInfoSchedulerService;
import com.google.firebase.messaging.FirebaseMessagingService;
import e1.InterfaceC0407A;
import f1.C0437a;
import f2.AbstractC0438a;
import f3.C0440b;
import f5.InterfaceC0446a;
import h.AbstractC0458a;
import h4.C0466b;
import h5.AbstractC0470d;
import i2.C0476b;
import io.flutter.plugins.urllauncher.WebViewActivity;
import j2.C0508g;
import j5.EnumC0522a;
import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.EOFException;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.nio.ByteBuffer;
import java.nio.charset.Charset;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.NoSuchElementException;
import java.util.Set;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.ScheduledFuture;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;
import java.util.zip.Adler32;
import k1.AbstractC0536a;
import org.apache.tika.mime.MimeTypesReaderMetKeys;
import org.apache.tika.utils.StringUtils;
import org.xmlpull.v1.XmlPullParserException;
import p0.Q;
import t.AbstractC0764B;
import t.C0780i;
import v.AbstractC0822e;
import v.InterfaceC0818a;
import v3.AbstractC0848e;
import w.AbstractC0858d;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* loaded from: classes.dex */
public final class g implements InterfaceC0168f, A5.d, X1.b, U0.d, InterfaceC0407A, C2.d, M4.n {
    public final /* synthetic */ int o;

    /* renamed from: p, reason: collision with root package name */
    public Object f3655p;

    /* renamed from: q, reason: collision with root package name */
    public Object f3656q;

    /* renamed from: r, reason: collision with root package name */
    public Object f3657r;

    public /* synthetic */ g() {
        this.o = 18;
    }

    public static Bundle C(Map map) {
        Bundle bundle = new Bundle();
        for (String str : map.keySet()) {
            bundle.putString(str, (String) map.get(str));
        }
        return bundle;
    }

    public static g P(Context context, AttributeSet attributeSet, int[] iArr, int i6) {
        return new g(context, context.obtainStyledAttributes(attributeSet, iArr, i6, 0), 17);
    }

    public static void U(M4.f fVar, final g gVar) {
        Y4.c cVar = Y4.c.f3878d;
        v3.u uVar = new v3.u(fVar, "dev.flutter.pigeon.url_launcher_android.UrlLauncherApi.canLaunchUrl", cVar, (C0508g) null);
        if (gVar != null) {
            final int i6 = 0;
            uVar.y(new M4.b(gVar) { // from class: Y4.d

                /* renamed from: p, reason: collision with root package name */
                public final /* synthetic */ X4.g f3879p;

                {
                    this.f3879p = gVar;
                }

                @Override // M4.b
                public final void e(Object obj, A.c cVar2) {
                    switch (i6) {
                        case 0:
                            X4.g gVar2 = this.f3879p;
                            ArrayList arrayList = new ArrayList();
                            try {
                                arrayList.add(0, gVar2.z((String) ((ArrayList) obj).get(0)));
                            } catch (Throwable th) {
                                arrayList = AbstractC0194a.n0(th);
                            }
                            cVar2.g(arrayList);
                            return;
                        case 1:
                            X4.g gVar3 = this.f3879p;
                            ArrayList arrayList2 = new ArrayList();
                            ArrayList arrayList3 = (ArrayList) obj;
                            try {
                                arrayList2.add(0, gVar3.N((String) arrayList3.get(0), (Map) arrayList3.get(1), (Boolean) arrayList3.get(2)));
                            } catch (Throwable th2) {
                                arrayList2 = AbstractC0194a.n0(th2);
                            }
                            cVar2.g(arrayList2);
                            return;
                        case 2:
                            X4.g gVar4 = this.f3879p;
                            ArrayList arrayList4 = new ArrayList();
                            ArrayList arrayList5 = (ArrayList) obj;
                            try {
                                arrayList4.add(0, gVar4.Q((String) arrayList5.get(0), (Boolean) arrayList5.get(1), (e) arrayList5.get(2), (a) arrayList5.get(3)));
                            } catch (Throwable th3) {
                                arrayList4 = AbstractC0194a.n0(th3);
                            }
                            cVar2.g(arrayList4);
                            return;
                        case 3:
                            X4.g gVar5 = this.f3879p;
                            ArrayList arrayList6 = new ArrayList();
                            try {
                                arrayList6.add(0, gVar5.V());
                            } catch (Throwable th4) {
                                arrayList6 = AbstractC0194a.n0(th4);
                            }
                            cVar2.g(arrayList6);
                            return;
                        default:
                            X4.g gVar6 = this.f3879p;
                            ArrayList arrayList7 = new ArrayList();
                            try {
                                ((Context) gVar6.f3656q).sendBroadcast(new Intent("close action"));
                                arrayList7.add(0, null);
                            } catch (Throwable th5) {
                                arrayList7 = AbstractC0194a.n0(th5);
                            }
                            cVar2.g(arrayList7);
                            return;
                    }
                }
            });
        } else {
            uVar.y(null);
        }
        v3.u uVar2 = new v3.u(fVar, "dev.flutter.pigeon.url_launcher_android.UrlLauncherApi.launchUrl", cVar, (C0508g) null);
        if (gVar != null) {
            final int i7 = 1;
            uVar2.y(new M4.b(gVar) { // from class: Y4.d

                /* renamed from: p, reason: collision with root package name */
                public final /* synthetic */ X4.g f3879p;

                {
                    this.f3879p = gVar;
                }

                @Override // M4.b
                public final void e(Object obj, A.c cVar2) {
                    switch (i7) {
                        case 0:
                            X4.g gVar2 = this.f3879p;
                            ArrayList arrayList = new ArrayList();
                            try {
                                arrayList.add(0, gVar2.z((String) ((ArrayList) obj).get(0)));
                            } catch (Throwable th) {
                                arrayList = AbstractC0194a.n0(th);
                            }
                            cVar2.g(arrayList);
                            return;
                        case 1:
                            X4.g gVar3 = this.f3879p;
                            ArrayList arrayList2 = new ArrayList();
                            ArrayList arrayList3 = (ArrayList) obj;
                            try {
                                arrayList2.add(0, gVar3.N((String) arrayList3.get(0), (Map) arrayList3.get(1), (Boolean) arrayList3.get(2)));
                            } catch (Throwable th2) {
                                arrayList2 = AbstractC0194a.n0(th2);
                            }
                            cVar2.g(arrayList2);
                            return;
                        case 2:
                            X4.g gVar4 = this.f3879p;
                            ArrayList arrayList4 = new ArrayList();
                            ArrayList arrayList5 = (ArrayList) obj;
                            try {
                                arrayList4.add(0, gVar4.Q((String) arrayList5.get(0), (Boolean) arrayList5.get(1), (e) arrayList5.get(2), (a) arrayList5.get(3)));
                            } catch (Throwable th3) {
                                arrayList4 = AbstractC0194a.n0(th3);
                            }
                            cVar2.g(arrayList4);
                            return;
                        case 3:
                            X4.g gVar5 = this.f3879p;
                            ArrayList arrayList6 = new ArrayList();
                            try {
                                arrayList6.add(0, gVar5.V());
                            } catch (Throwable th4) {
                                arrayList6 = AbstractC0194a.n0(th4);
                            }
                            cVar2.g(arrayList6);
                            return;
                        default:
                            X4.g gVar6 = this.f3879p;
                            ArrayList arrayList7 = new ArrayList();
                            try {
                                ((Context) gVar6.f3656q).sendBroadcast(new Intent("close action"));
                                arrayList7.add(0, null);
                            } catch (Throwable th5) {
                                arrayList7 = AbstractC0194a.n0(th5);
                            }
                            cVar2.g(arrayList7);
                            return;
                    }
                }
            });
        } else {
            uVar2.y(null);
        }
        v3.u uVar3 = new v3.u(fVar, "dev.flutter.pigeon.url_launcher_android.UrlLauncherApi.openUrlInApp", cVar, (C0508g) null);
        if (gVar != null) {
            final int i8 = 2;
            uVar3.y(new M4.b(gVar) { // from class: Y4.d

                /* renamed from: p, reason: collision with root package name */
                public final /* synthetic */ X4.g f3879p;

                {
                    this.f3879p = gVar;
                }

                @Override // M4.b
                public final void e(Object obj, A.c cVar2) {
                    switch (i8) {
                        case 0:
                            X4.g gVar2 = this.f3879p;
                            ArrayList arrayList = new ArrayList();
                            try {
                                arrayList.add(0, gVar2.z((String) ((ArrayList) obj).get(0)));
                            } catch (Throwable th) {
                                arrayList = AbstractC0194a.n0(th);
                            }
                            cVar2.g(arrayList);
                            return;
                        case 1:
                            X4.g gVar3 = this.f3879p;
                            ArrayList arrayList2 = new ArrayList();
                            ArrayList arrayList3 = (ArrayList) obj;
                            try {
                                arrayList2.add(0, gVar3.N((String) arrayList3.get(0), (Map) arrayList3.get(1), (Boolean) arrayList3.get(2)));
                            } catch (Throwable th2) {
                                arrayList2 = AbstractC0194a.n0(th2);
                            }
                            cVar2.g(arrayList2);
                            return;
                        case 2:
                            X4.g gVar4 = this.f3879p;
                            ArrayList arrayList4 = new ArrayList();
                            ArrayList arrayList5 = (ArrayList) obj;
                            try {
                                arrayList4.add(0, gVar4.Q((String) arrayList5.get(0), (Boolean) arrayList5.get(1), (e) arrayList5.get(2), (a) arrayList5.get(3)));
                            } catch (Throwable th3) {
                                arrayList4 = AbstractC0194a.n0(th3);
                            }
                            cVar2.g(arrayList4);
                            return;
                        case 3:
                            X4.g gVar5 = this.f3879p;
                            ArrayList arrayList6 = new ArrayList();
                            try {
                                arrayList6.add(0, gVar5.V());
                            } catch (Throwable th4) {
                                arrayList6 = AbstractC0194a.n0(th4);
                            }
                            cVar2.g(arrayList6);
                            return;
                        default:
                            X4.g gVar6 = this.f3879p;
                            ArrayList arrayList7 = new ArrayList();
                            try {
                                ((Context) gVar6.f3656q).sendBroadcast(new Intent("close action"));
                                arrayList7.add(0, null);
                            } catch (Throwable th5) {
                                arrayList7 = AbstractC0194a.n0(th5);
                            }
                            cVar2.g(arrayList7);
                            return;
                    }
                }
            });
        } else {
            uVar3.y(null);
        }
        v3.u uVar4 = new v3.u(fVar, "dev.flutter.pigeon.url_launcher_android.UrlLauncherApi.supportsCustomTabs", cVar, (C0508g) null);
        if (gVar != null) {
            final int i9 = 3;
            uVar4.y(new M4.b(gVar) { // from class: Y4.d

                /* renamed from: p, reason: collision with root package name */
                public final /* synthetic */ X4.g f3879p;

                {
                    this.f3879p = gVar;
                }

                @Override // M4.b
                public final void e(Object obj, A.c cVar2) {
                    switch (i9) {
                        case 0:
                            X4.g gVar2 = this.f3879p;
                            ArrayList arrayList = new ArrayList();
                            try {
                                arrayList.add(0, gVar2.z((String) ((ArrayList) obj).get(0)));
                            } catch (Throwable th) {
                                arrayList = AbstractC0194a.n0(th);
                            }
                            cVar2.g(arrayList);
                            return;
                        case 1:
                            X4.g gVar3 = this.f3879p;
                            ArrayList arrayList2 = new ArrayList();
                            ArrayList arrayList3 = (ArrayList) obj;
                            try {
                                arrayList2.add(0, gVar3.N((String) arrayList3.get(0), (Map) arrayList3.get(1), (Boolean) arrayList3.get(2)));
                            } catch (Throwable th2) {
                                arrayList2 = AbstractC0194a.n0(th2);
                            }
                            cVar2.g(arrayList2);
                            return;
                        case 2:
                            X4.g gVar4 = this.f3879p;
                            ArrayList arrayList4 = new ArrayList();
                            ArrayList arrayList5 = (ArrayList) obj;
                            try {
                                arrayList4.add(0, gVar4.Q((String) arrayList5.get(0), (Boolean) arrayList5.get(1), (e) arrayList5.get(2), (a) arrayList5.get(3)));
                            } catch (Throwable th3) {
                                arrayList4 = AbstractC0194a.n0(th3);
                            }
                            cVar2.g(arrayList4);
                            return;
                        case 3:
                            X4.g gVar5 = this.f3879p;
                            ArrayList arrayList6 = new ArrayList();
                            try {
                                arrayList6.add(0, gVar5.V());
                            } catch (Throwable th4) {
                                arrayList6 = AbstractC0194a.n0(th4);
                            }
                            cVar2.g(arrayList6);
                            return;
                        default:
                            X4.g gVar6 = this.f3879p;
                            ArrayList arrayList7 = new ArrayList();
                            try {
                                ((Context) gVar6.f3656q).sendBroadcast(new Intent("close action"));
                                arrayList7.add(0, null);
                            } catch (Throwable th5) {
                                arrayList7 = AbstractC0194a.n0(th5);
                            }
                            cVar2.g(arrayList7);
                            return;
                    }
                }
            });
        } else {
            uVar4.y(null);
        }
        v3.u uVar5 = new v3.u(fVar, "dev.flutter.pigeon.url_launcher_android.UrlLauncherApi.closeWebView", cVar, (C0508g) null);
        if (gVar != null) {
            final int i10 = 4;
            uVar5.y(new M4.b(gVar) { // from class: Y4.d

                /* renamed from: p, reason: collision with root package name */
                public final /* synthetic */ X4.g f3879p;

                {
                    this.f3879p = gVar;
                }

                @Override // M4.b
                public final void e(Object obj, A.c cVar2) {
                    switch (i10) {
                        case 0:
                            X4.g gVar2 = this.f3879p;
                            ArrayList arrayList = new ArrayList();
                            try {
                                arrayList.add(0, gVar2.z((String) ((ArrayList) obj).get(0)));
                            } catch (Throwable th) {
                                arrayList = AbstractC0194a.n0(th);
                            }
                            cVar2.g(arrayList);
                            return;
                        case 1:
                            X4.g gVar3 = this.f3879p;
                            ArrayList arrayList2 = new ArrayList();
                            ArrayList arrayList3 = (ArrayList) obj;
                            try {
                                arrayList2.add(0, gVar3.N((String) arrayList3.get(0), (Map) arrayList3.get(1), (Boolean) arrayList3.get(2)));
                            } catch (Throwable th2) {
                                arrayList2 = AbstractC0194a.n0(th2);
                            }
                            cVar2.g(arrayList2);
                            return;
                        case 2:
                            X4.g gVar4 = this.f3879p;
                            ArrayList arrayList4 = new ArrayList();
                            ArrayList arrayList5 = (ArrayList) obj;
                            try {
                                arrayList4.add(0, gVar4.Q((String) arrayList5.get(0), (Boolean) arrayList5.get(1), (e) arrayList5.get(2), (a) arrayList5.get(3)));
                            } catch (Throwable th3) {
                                arrayList4 = AbstractC0194a.n0(th3);
                            }
                            cVar2.g(arrayList4);
                            return;
                        case 3:
                            X4.g gVar5 = this.f3879p;
                            ArrayList arrayList6 = new ArrayList();
                            try {
                                arrayList6.add(0, gVar5.V());
                            } catch (Throwable th4) {
                                arrayList6 = AbstractC0194a.n0(th4);
                            }
                            cVar2.g(arrayList6);
                            return;
                        default:
                            X4.g gVar6 = this.f3879p;
                            ArrayList arrayList7 = new ArrayList();
                            try {
                                ((Context) gVar6.f3656q).sendBroadcast(new Intent("close action"));
                                arrayList7.add(0, null);
                            } catch (Throwable th5) {
                                arrayList7 = AbstractC0194a.n0(th5);
                            }
                            cVar2.g(arrayList7);
                            return;
                    }
                }
            });
        } else {
            uVar5.y(null);
        }
    }

    public SharedPreferences A(h hVar) {
        Context context = (Context) this.f3656q;
        String str = hVar.f3658a;
        if (str == null) {
            SharedPreferences sharedPreferences = context.getSharedPreferences(context.getPackageName() + "_preferences", 0);
            q5.h.b(sharedPreferences);
            return sharedPreferences;
        }
        SharedPreferences sharedPreferences2 = context.getSharedPreferences(str, 0);
        q5.h.b(sharedPreferences2);
        return sharedPreferences2;
    }

    public void B(Object obj, ByteArrayOutputStream byteArrayOutputStream) {
        HashMap hashMap = (HashMap) this.f3655p;
        k3.f fVar = new k3.f(byteArrayOutputStream, hashMap, (HashMap) this.f3656q, (h3.d) this.f3657r);
        h3.d dVar = (h3.d) hashMap.get(obj.getClass());
        if (dVar != null) {
            dVar.a(obj, fVar);
        } else {
            throw new RuntimeException("No encoder for " + obj.getClass());
        }
    }

    public int D(int i6, int i7) {
        ArrayList arrayList = (ArrayList) this.f3657r;
        int size = arrayList.size();
        while (i7 < size) {
            ((AbstractC0536a) arrayList.get(i7)).getClass();
            i7++;
        }
        return i6;
    }

    public ColorStateList E(int i6) {
        int resourceId;
        TypedArray typedArray = (TypedArray) this.f3655p;
        if (typedArray.hasValue(i6) && (resourceId = typedArray.getResourceId(i6, 0)) != 0) {
            Context context = (Context) this.f3656q;
            Object obj = AbstractC0458a.f6801a;
            ColorStateList colorStateList = context.getColorStateList(resourceId);
            if (colorStateList != null) {
                return colorStateList;
            }
        }
        return typedArray.getColorStateList(i6);
    }

    public long F() {
        x0.l lVar = (x0.l) this.f3657r;
        if (lVar != null) {
            return lVar.f10195r;
        }
        return -1L;
    }

    public Drawable G(int i6) {
        int resourceId;
        TypedArray typedArray = (TypedArray) this.f3655p;
        if (typedArray.hasValue(i6) && (resourceId = typedArray.getResourceId(i6, 0)) != 0) {
            return AbstractC0458a.a((Context) this.f3656q, resourceId);
        }
        return typedArray.getDrawable(i6);
    }

    public Typeface H(int i6, int i7, l.r rVar) {
        l.r rVar2;
        XmlPullParserException xmlPullParserException;
        IOException iOException;
        int resourceId = ((TypedArray) this.f3655p).getResourceId(i6, 0);
        if (resourceId != 0) {
            if (((TypedValue) this.f3657r) == null) {
                this.f3657r = new TypedValue();
            }
            Context context = (Context) this.f3656q;
            TypedValue typedValue = (TypedValue) this.f3657r;
            Object obj = AbstractC0822e.f9787a;
            if (!context.isRestricted()) {
                Resources resources = context.getResources();
                resources.getValue(resourceId, typedValue, true);
                CharSequence charSequence = typedValue.string;
                if (charSequence != null) {
                    String charSequence2 = charSequence.toString();
                    if (!charSequence2.startsWith("res/")) {
                        rVar.a();
                        return null;
                    }
                    int i8 = typedValue.assetCookie;
                    p.i iVar = AbstractC0858d.f10057b;
                    Typeface typeface = (Typeface) iVar.a(AbstractC0858d.b(resources, resourceId, charSequence2, i8, i7));
                    int i9 = 3;
                    if (typeface != null) {
                        new Handler(Looper.getMainLooper()).post(new org.apache.tika.pipes.async.b(rVar, typeface, i9));
                        return typeface;
                    }
                    try {
                        if (charSequence2.toLowerCase().endsWith(".xml")) {
                            InterfaceC0818a l6 = s4.d.l(resources.getXml(resourceId), resources);
                            if (l6 == null) {
                                try {
                                    Log.e("ResourcesCompat", "Failed to find font-family tag");
                                    rVar.a();
                                    return null;
                                } catch (IOException e) {
                                    iOException = e;
                                    rVar2 = rVar;
                                    Log.e("ResourcesCompat", "Failed to read xml resource ".concat(charSequence2), iOException);
                                    rVar2.a();
                                    return null;
                                } catch (XmlPullParserException e6) {
                                    xmlPullParserException = e6;
                                    rVar2 = rVar;
                                    Log.e("ResourcesCompat", "Failed to parse xml resource ".concat(charSequence2), xmlPullParserException);
                                    rVar2.a();
                                    return null;
                                }
                            }
                            try {
                                return AbstractC0858d.a(context, l6, resources, resourceId, charSequence2, typedValue.assetCookie, i7, rVar);
                            } catch (IOException e7) {
                                e = e7;
                                rVar2 = rVar;
                                iOException = e;
                                Log.e("ResourcesCompat", "Failed to read xml resource ".concat(charSequence2), iOException);
                                rVar2.a();
                                return null;
                            } catch (XmlPullParserException e8) {
                                e = e8;
                                rVar2 = rVar;
                                xmlPullParserException = e;
                                Log.e("ResourcesCompat", "Failed to parse xml resource ".concat(charSequence2), xmlPullParserException);
                                rVar2.a();
                                return null;
                            }
                        }
                        rVar2 = rVar;
                        try {
                            int i10 = typedValue.assetCookie;
                            Typeface f6 = AbstractC0858d.f10056a.f(context, resources, resourceId, charSequence2, i7);
                            if (f6 != null) {
                                iVar.b(AbstractC0858d.b(resources, resourceId, charSequence2, i10, i7), f6);
                            }
                            if (f6 != null) {
                                new Handler(Looper.getMainLooper()).post(new org.apache.tika.pipes.async.b(rVar2, f6, i9));
                            } else {
                                rVar2.a();
                            }
                            return f6;
                        } catch (IOException e9) {
                            e = e9;
                            iOException = e;
                            Log.e("ResourcesCompat", "Failed to read xml resource ".concat(charSequence2), iOException);
                            rVar2.a();
                            return null;
                        } catch (XmlPullParserException e10) {
                            e = e10;
                            xmlPullParserException = e;
                            Log.e("ResourcesCompat", "Failed to parse xml resource ".concat(charSequence2), xmlPullParserException);
                            rVar2.a();
                            return null;
                        }
                    } catch (IOException e11) {
                        e = e11;
                        rVar2 = rVar;
                    } catch (XmlPullParserException e12) {
                        e = e12;
                        rVar2 = rVar;
                    }
                } else {
                    throw new Resources.NotFoundException("Resource \"" + resources.getResourceName(resourceId) + "\" (" + Integer.toHexString(resourceId) + ") is not a Font: " + typedValue);
                }
            }
        }
        return null;
    }

    public View I(int i6) {
        return ((RecyclerView) ((X2.b) this.f3655p).o).getChildAt(i6);
    }

    public int J() {
        return ((RecyclerView) ((X2.b) this.f3655p).o).getChildCount();
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Removed duplicated region for block: B:24:0x0083  */
    /* JADX WARN: Removed duplicated region for block: B:29:0x0110  */
    /* JADX WARN: Removed duplicated region for block: B:32:0x00b0 A[EXC_TOP_SPLITTER, SYNTHETIC] */
    /* JADX WARN: Type inference failed for: r8v2, types: [t.B, t.f] */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public boolean K() {
        v3.o oVar;
        IconCompat d6;
        if (((C0440b) this.f3657r).a("gcm.n.noui")) {
            return true;
        }
        FirebaseMessagingService firebaseMessagingService = (FirebaseMessagingService) this.f3656q;
        if (!((KeyguardManager) firebaseMessagingService.getSystemService("keyguard")).inKeyguardRestrictedInputMode()) {
            int myPid = Process.myPid();
            List<ActivityManager.RunningAppProcessInfo> runningAppProcesses = ((ActivityManager) firebaseMessagingService.getSystemService("activity")).getRunningAppProcesses();
            if (runningAppProcesses != null) {
                Iterator<ActivityManager.RunningAppProcessInfo> it = runningAppProcesses.iterator();
                while (true) {
                    if (!it.hasNext()) {
                        break;
                    }
                    ActivityManager.RunningAppProcessInfo next = it.next();
                    if (next.pid == myPid) {
                        if (next.importance == 100) {
                            return false;
                        }
                    }
                }
            }
        }
        String i6 = ((C0440b) this.f3657r).i("gcm.n.image");
        if (!TextUtils.isEmpty(i6)) {
            try {
                oVar = new v3.o(new URL(i6));
            } catch (MalformedURLException unused) {
                Log.w("FirebaseMessaging", "Not downloading image, bad URL: " + i6);
            }
            if (oVar != null) {
                ExecutorService executorService = (ExecutorService) this.f3655p;
                C2.j jVar = new C2.j();
                oVar.f10001p = executorService.submit(new org.apache.tika.pipes.async.b(oVar, jVar, 9));
                oVar.f10002q = jVar.f267a;
            }
            v3.i a6 = AbstractC0848e.a((FirebaseMessagingService) this.f3656q, (C0440b) this.f3657r);
            C0780i c0780i = (C0780i) a6.f9994a;
            if (oVar != null) {
                try {
                    C2.r rVar = oVar.f10002q;
                    m2.s.e(rVar);
                    TimeUnit timeUnit = TimeUnit.SECONDS;
                    Bitmap bitmap = (Bitmap) AbstractC0194a.d(rVar, 5L);
                    c0780i.d(bitmap);
                    ?? abstractC0764B = new AbstractC0764B();
                    if (bitmap == null) {
                        d6 = null;
                    } else {
                        d6 = IconCompat.d(bitmap);
                    }
                    abstractC0764B.e = d6;
                    abstractC0764B.f9557f = null;
                    abstractC0764B.f9558g = true;
                    c0780i.f(abstractC0764B);
                } catch (InterruptedException unused2) {
                    Log.w("FirebaseMessaging", "Interrupted while downloading image, showing notification without it");
                    oVar.close();
                    Thread.currentThread().interrupt();
                } catch (ExecutionException e) {
                    Log.w("FirebaseMessaging", "Failed to download image: " + e.getCause());
                } catch (TimeoutException unused3) {
                    Log.w("FirebaseMessaging", "Failed to download image in time, showing notification without it");
                    oVar.close();
                }
            }
            if (Log.isLoggable("FirebaseMessaging", 3)) {
                Log.d("FirebaseMessaging", "Showing notification");
            }
            ((NotificationManager) ((FirebaseMessagingService) this.f3656q).getSystemService("notification")).notify((String) a6.f9995b, 0, ((C0780i) a6.f9994a).a());
            return true;
        }
        oVar = null;
        if (oVar != null) {
        }
        v3.i a62 = AbstractC0848e.a((FirebaseMessagingService) this.f3656q, (C0440b) this.f3657r);
        C0780i c0780i2 = (C0780i) a62.f9994a;
        if (oVar != null) {
        }
        if (Log.isLoggable("FirebaseMessaging", 3)) {
        }
        ((NotificationManager) ((FirebaseMessagingService) this.f3656q).getSystemService("notification")).notify((String) a62.f9995b, 0, ((C0780i) a62.f9994a).a());
        return true;
    }

    public boolean L() {
        String trim;
        ArrayDeque arrayDeque = (ArrayDeque) this.f3656q;
        if (((String) this.f3657r) == null) {
            if (!arrayDeque.isEmpty()) {
                String str = (String) arrayDeque.poll();
                str.getClass();
                this.f3657r = str;
                return true;
            }
            do {
                String readLine = ((BufferedReader) this.f3655p).readLine();
                this.f3657r = readLine;
                if (readLine != null) {
                    trim = readLine.trim();
                    this.f3657r = trim;
                } else {
                    return false;
                }
            } while (trim.isEmpty());
        }
        return true;
    }

    /* JADX WARN: Code restructure failed: missing block: B:28:0x0056, code lost:
    
        if (r1.f10195r != r11) goto L23;
     */
    /* JADX WARN: Code restructure failed: missing block: B:29:0x0059, code lost:
    
        r0 = false;
     */
    /* JADX WARN: Code restructure failed: missing block: B:36:0x0080, code lost:
    
        if (r1.f10195r != r11) goto L23;
     */
    /* JADX WARN: Type inference failed for: r11v3, types: [E2.C, E2.F] */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public void M(X.h hVar, Uri uri, Map map, long j6, long j7, Q q6) {
        x0.l lVar = new x0.l(hVar, j6, j7);
        this.f3657r = lVar;
        if (((x0.o) this.f3656q) != null) {
            return;
        }
        x0.o[] f6 = ((x0.r) this.f3655p).f(uri, map);
        int length = f6.length;
        G g2 = I.f699p;
        E2.r.d(length, "expectedSize");
        ?? c6 = new E2.C(length);
        boolean z6 = true;
        if (f6.length == 1) {
            this.f3656q = f6[0];
        } else {
            int length2 = f6.length;
            int i6 = 0;
            while (true) {
                if (i6 >= length2) {
                    break;
                }
                x0.o oVar = f6[i6];
                try {
                } catch (EOFException unused) {
                    if (((x0.o) this.f3656q) == null) {
                    }
                } catch (Throwable th) {
                    if (((x0.o) this.f3656q) == null && lVar.f10195r != j6) {
                        z6 = false;
                    }
                    AbstractC0133a.i(z6);
                    lVar.f10197t = 0;
                    throw th;
                }
                if (oVar.f(lVar)) {
                    this.f3656q = oVar;
                    lVar.f10197t = 0;
                    break;
                }
                c6.c(oVar.e());
                if (((x0.o) this.f3656q) == null) {
                }
                boolean z7 = true;
                AbstractC0133a.i(z7);
                lVar.f10197t = 0;
                i6++;
            }
            if (((x0.o) this.f3656q) == null) {
                String str = "None of the available extractors (" + new D2.e(", ", 0).b(E2.r.u(I.v(f6), new C0437a(23))) + ") could read the stream.";
                uri.getClass();
                Z f7 = c6.f();
                S.G g3 = new S.G(str, null, false, 1);
                I.u(f7);
                throw g3;
            }
        }
        ((x0.o) this.f3656q).k(q6);
    }

    public Boolean N(String str, Map map, Boolean bool) {
        if (((Activity) this.f3657r) != null) {
            Intent putExtra = new Intent("android.intent.action.VIEW").setData(Uri.parse(str)).putExtra("com.android.browser.headers", C(map));
            if (bool.booleanValue() && Build.VERSION.SDK_INT >= 30) {
                putExtra.addFlags(1024);
            }
            try {
                ((Activity) this.f3657r).startActivity(putExtra);
                return Boolean.TRUE;
            } catch (ActivityNotFoundException unused) {
                return Boolean.FALSE;
            }
        }
        throw new Y4.b();
    }

    public String O() {
        if (L()) {
            String str = (String) this.f3657r;
            this.f3657r = null;
            return str;
        }
        throw new NoSuchElementException();
    }

    /* JADX WARN: Failed to find 'out' block for switch in B:12:0x0068. Please report as an issue. */
    public Boolean Q(String str, Boolean bool, Y4.e eVar, Y4.a aVar) {
        String str2;
        ActivityOptions activityOptions;
        Bundle bundle;
        if (((Activity) this.f3657r) != null) {
            Bundle C6 = C(eVar.f3882c);
            if (bool.booleanValue()) {
                Iterator it = eVar.f3882c.keySet().iterator();
                while (true) {
                    char c6 = 1;
                    if (it.hasNext()) {
                        String lowerCase = ((String) it.next()).toLowerCase(Locale.US);
                        lowerCase.getClass();
                        switch (lowerCase.hashCode()) {
                            case -1423461112:
                                if (lowerCase.equals("accept")) {
                                    c6 = 0;
                                    break;
                                }
                                break;
                            case -1229727188:
                                if (lowerCase.equals("content-language")) {
                                    break;
                                }
                                break;
                            case 785670158:
                                if (lowerCase.equals("content-type")) {
                                    c6 = 2;
                                    break;
                                }
                                break;
                            case 802785917:
                                if (lowerCase.equals("accept-language")) {
                                    c6 = 3;
                                    break;
                                }
                                break;
                        }
                        c6 = 65535;
                        switch (c6) {
                        }
                    } else {
                        Uri parse = Uri.parse(str);
                        Activity activity = (Activity) this.f3657r;
                        Intent intent = new Intent("android.intent.action.VIEW");
                        intent.putExtra("android.support.customtabs.extra.TITLE_VISIBILITY", aVar.f3877a.booleanValue() ? 1 : 0);
                        Bundle bundle2 = null;
                        if (!intent.hasExtra("android.support.customtabs.extra.SESSION")) {
                            Bundle bundle3 = new Bundle();
                            bundle3.putBinder("android.support.customtabs.extra.SESSION", null);
                            intent.putExtras(bundle3);
                        }
                        intent.putExtra("android.support.customtabs.extra.EXTRA_ENABLE_INSTANT_APPS", true);
                        intent.putExtras(new Bundle());
                        intent.putExtra("androidx.browser.customtabs.extra.SHARE_STATE", 0);
                        int i6 = Build.VERSION.SDK_INT;
                        LocaleList adjustedDefault = LocaleList.getAdjustedDefault();
                        if (adjustedDefault.size() > 0) {
                            str2 = adjustedDefault.get(0).toLanguageTag();
                        } else {
                            str2 = null;
                        }
                        if (!TextUtils.isEmpty(str2)) {
                            if (intent.hasExtra("com.android.browser.headers")) {
                                bundle = intent.getBundleExtra("com.android.browser.headers");
                            } else {
                                bundle = new Bundle();
                            }
                            if (!bundle.containsKey("Accept-Language")) {
                                bundle.putString("Accept-Language", str2);
                                intent.putExtra("com.android.browser.headers", bundle);
                            }
                        }
                        if (i6 >= 34) {
                            activityOptions = ActivityOptions.makeBasic();
                            AbstractC0048m.h(activityOptions);
                        } else {
                            activityOptions = null;
                        }
                        if (i6 >= 36) {
                            if (activityOptions == null) {
                                activityOptions = ActivityOptions.makeBasic();
                            }
                            E.e.e(activityOptions, !intent.getBooleanExtra("androidx.browser.customtabs.extra.DISABLE_BACKGROUND_INTERACTION", false));
                        }
                        if (activityOptions != null) {
                            bundle2 = activityOptions.toBundle();
                        }
                        intent.putExtra("com.android.browser.headers", C6);
                        try {
                            intent.setData(parse);
                            activity.startActivity(intent, bundle2);
                            return Boolean.TRUE;
                        } catch (ActivityNotFoundException unused) {
                        }
                    }
                }
            }
            Activity activity2 = (Activity) this.f3657r;
            boolean booleanValue = eVar.f3880a.booleanValue();
            boolean booleanValue2 = eVar.f3881b.booleanValue();
            int i7 = WebViewActivity.f7275s;
            try {
                ((Activity) this.f3657r).startActivity(new Intent(activity2, (Class<?>) WebViewActivity.class).putExtra("url", str).putExtra("enableJavaScript", booleanValue).putExtra("enableDomStorage", booleanValue2).putExtra("com.android.browser.headers", C6));
                return Boolean.TRUE;
            } catch (ActivityNotFoundException unused2) {
                return Boolean.FALSE;
            }
        }
        throw new Y4.b();
    }

    public void R() {
        ((TypedArray) this.f3655p).recycle();
    }

    public void S(ArrayList arrayList) {
        int size = arrayList.size();
        for (int i6 = 0; i6 < size; i6++) {
            AbstractC0536a abstractC0536a = (AbstractC0536a) arrayList.get(i6);
            abstractC0536a.getClass();
            C.b bVar = (C.b) this.f3655p;
            Object[] objArr = (Object[]) bVar.f247p;
            q5.h.e(abstractC0536a, "instance");
            int i7 = bVar.o;
            for (int i8 = 0; i8 < i7; i8++) {
                if (objArr[i8] == abstractC0536a) {
                    throw new IllegalStateException("Already in the pool!");
                }
            }
            int i9 = bVar.o;
            if (i9 < objArr.length) {
                objArr[i9] = abstractC0536a;
                bVar.o = i9 + 1;
            }
        }
        arrayList.clear();
    }

    public void T(V1.i iVar, int i6, boolean z6) {
        Long l6;
        C0259b c0259b = (C0259b) this.f3657r;
        Context context = (Context) this.f3656q;
        ComponentName componentName = new ComponentName(context, (Class<?>) JobInfoSchedulerService.class);
        JobScheduler jobScheduler = (JobScheduler) context.getSystemService("jobscheduler");
        Adler32 adler32 = new Adler32();
        adler32.update(context.getPackageName().getBytes(Charset.forName("UTF-8")));
        String str = iVar.f3234a;
        String str2 = iVar.f3234a;
        adler32.update(str.getBytes(Charset.forName("UTF-8")));
        ByteBuffer allocate = ByteBuffer.allocate(4);
        S1.d dVar = iVar.f3236c;
        adler32.update(allocate.putInt(AbstractC0438a.a(dVar)).array());
        byte[] bArr = iVar.f3235b;
        if (bArr != null) {
            adler32.update(bArr);
        }
        int value = (int) adler32.getValue();
        if (!z6) {
            Iterator<JobInfo> it = jobScheduler.getAllPendingJobs().iterator();
            while (true) {
                if (!it.hasNext()) {
                    break;
                }
                JobInfo next = it.next();
                int i7 = next.getExtras().getInt("attemptNumber");
                if (next.getId() == value) {
                    if (i7 >= i6) {
                        android.support.v4.media.session.a.d("JobInfoScheduler", "Upload for context %s is already scheduled. Returning...", iVar);
                        return;
                    }
                }
            }
        }
        Cursor rawQuery = ((C0294h) ((InterfaceC0290d) this.f3655p)).a().rawQuery("SELECT next_request_ms FROM transport_contexts WHERE backend_name = ? and priority = ?", new String[]{str2, String.valueOf(AbstractC0438a.a(dVar))});
        try {
            if (rawQuery.moveToNext()) {
                l6 = Long.valueOf(rawQuery.getLong(0));
            } else {
                l6 = 0L;
            }
            rawQuery.close();
            long longValue = l6.longValue();
            JobInfo.Builder builder = new JobInfo.Builder(value, componentName);
            builder.setMinimumLatency(c0259b.a(dVar, longValue, i6));
            Set set = ((C0260c) c0259b.f5282b.get(dVar)).f5285c;
            if (set.contains(b2.d.o)) {
                builder.setRequiredNetworkType(2);
            } else {
                builder.setRequiredNetworkType(1);
            }
            if (set.contains(b2.d.f5287q)) {
                builder.setRequiresCharging(true);
            }
            if (set.contains(b2.d.f5286p)) {
                builder.setRequiresDeviceIdle(true);
            }
            PersistableBundle persistableBundle = new PersistableBundle();
            persistableBundle.putInt("attemptNumber", i6);
            persistableBundle.putString("backendName", str2);
            persistableBundle.putInt(MimeTypesReaderMetKeys.MAGIC_PRIORITY_ATTR, AbstractC0438a.a(dVar));
            if (bArr != null) {
                persistableBundle.putString("extras", Base64.encodeToString(bArr, 0));
            }
            builder.setExtras(persistableBundle);
            Object[] objArr = {iVar, Integer.valueOf(value), Long.valueOf(c0259b.a(dVar, longValue, i6)), l6, Integer.valueOf(i6)};
            String t6 = android.support.v4.media.session.a.t("JobInfoScheduler");
            if (Log.isLoggable(t6, 3)) {
                Log.d(t6, String.format("Scheduling upload for context %s with jobId=%d in %dms(Backend next call timestamp %d). Attempt %d", objArr));
            }
            jobScheduler.schedule(builder.build());
        } catch (Throwable th) {
            rawQuery.close();
            throw th;
        }
    }

    public Boolean V() {
        List list;
        String str;
        Context context = (Context) this.f3656q;
        List list2 = Collections.EMPTY_LIST;
        PackageManager packageManager = context.getPackageManager();
        if (list2 == null) {
            list = new ArrayList();
        } else {
            list = list2;
        }
        boolean z6 = false;
        ResolveInfo resolveActivity = packageManager.resolveActivity(new Intent("android.intent.action.VIEW", Uri.parse("http://")), 0);
        if (resolveActivity != null) {
            String str2 = resolveActivity.activityInfo.packageName;
            ArrayList arrayList = new ArrayList(list.size() + 1);
            arrayList.add(str2);
            if (list2 != null) {
                arrayList.addAll(list2);
            }
            list = arrayList;
        }
        Intent intent = new Intent("android.support.customtabs.action.CustomTabsService");
        Iterator it = list.iterator();
        while (true) {
            if (it.hasNext()) {
                str = (String) it.next();
                intent.setPackage(str);
                if (packageManager.resolveService(intent, 0) != null) {
                    break;
                }
            } else {
                if (Build.VERSION.SDK_INT >= 30) {
                    Log.w("CustomTabsClient", "Unable to find any Custom Tabs packages, you may need to add a <queries> element to your manifest. See the docs for CustomTabsClient#getPackageName.");
                }
                str = null;
            }
        }
        if (str != null) {
            z6 = true;
        }
        return Boolean.valueOf(z6);
    }

    @Override // U0.d
    public int a(long j6) {
        long[] jArr = (long[]) this.f3657r;
        int a6 = V.C.a(jArr, j6, false);
        if (a6 < jArr.length) {
            return a6;
        }
        return -1;
    }

    @Override // e1.InterfaceC0407A
    public void b(V.v vVar) {
        long d6;
        long j6;
        long j7;
        AbstractC0133a.j((V.A) this.f3656q);
        String str = V.C.f3053a;
        V.A a6 = (V.A) this.f3656q;
        synchronized (a6) {
            try {
                long j8 = a6.f3050c;
                if (j8 != -9223372036854775807L) {
                    d6 = j8 + a6.f3049b;
                } else {
                    d6 = a6.d();
                }
                j6 = d6;
            } finally {
            }
        }
        V.A a7 = (V.A) this.f3656q;
        synchronized (a7) {
            j7 = a7.f3049b;
        }
        if (j6 != -9223372036854775807L && j7 != -9223372036854775807L) {
            C0123p c0123p = (C0123p) this.f3655p;
            if (j7 != c0123p.f2630s) {
                C0122o a8 = c0123p.a();
                a8.f2591r = j7;
                C0123p c0123p2 = new C0123p(a8);
                this.f3655p = c0123p2;
                ((x0.G) this.f3657r).b(c0123p2);
            }
            int a9 = vVar.a();
            ((x0.G) this.f3657r).d(vVar, a9, 0);
            ((x0.G) this.f3657r).c(j6, 1, a9, 0, null);
        }
    }

    @Override // e1.InterfaceC0407A
    public void c(V.A a6, x0.q qVar, e1.F f6) {
        this.f3656q = a6;
        f6.a();
        f6.c();
        x0.G w6 = qVar.w(f6.f6054c, 5);
        this.f3657r = w6;
        w6.b((C0123p) this.f3655p);
    }

    @Override // X4.InterfaceC0168f
    public Double d(String str, h hVar) {
        SharedPreferences A6 = A(hVar);
        if (A6.contains(str)) {
            Object c6 = C.c(A6.getString(str, StringUtils.EMPTY), (m3.e) this.f3657r);
            q5.h.c(c6, "null cannot be cast to non-null type kotlin.Double");
            return (Double) c6;
        }
        return null;
    }

    @Override // U0.d
    public long e(int i6) {
        boolean z6;
        long[] jArr = (long[]) this.f3657r;
        boolean z7 = false;
        if (i6 >= 0) {
            z6 = true;
        } else {
            z6 = false;
        }
        AbstractC0133a.c(z6);
        if (i6 < jArr.length) {
            z7 = true;
        }
        AbstractC0133a.c(z7);
        return jArr[i6];
    }

    @Override // X4.InterfaceC0168f
    public List f(List list, h hVar) {
        Set set;
        Map<String, ?> all = A(hVar).getAll();
        q5.h.d(all, "getAll(...)");
        LinkedHashMap linkedHashMap = new LinkedHashMap();
        for (Map.Entry<String, ?> entry : all.entrySet()) {
            String key = entry.getKey();
            q5.h.d(key, "<get-key>(...)");
            String str = key;
            Object value = entry.getValue();
            if (list != null) {
                set = AbstractC0470d.f0(list);
            } else {
                set = null;
            }
            if (C.b(str, value, set)) {
                linkedHashMap.put(entry.getKey(), entry.getValue());
            }
        }
        return AbstractC0470d.d0(linkedHashMap.keySet());
    }

    @Override // X4.InterfaceC0168f
    public void g(String str, String str2, h hVar) {
        A(hVar).edit().putString(str, str2).apply();
    }

    @Override // f5.InterfaceC0446a
    public Object get() {
        return new g((Context) ((InterfaceC0446a) this.f3655p).get(), (InterfaceC0290d) ((InterfaceC0446a) this.f3656q).get(), (C0259b) ((m3.e) this.f3657r).get());
    }

    @Override // X4.InterfaceC0168f
    public Boolean h(String str, h hVar) {
        SharedPreferences A6 = A(hVar);
        if (A6.contains(str)) {
            return Boolean.valueOf(A6.getBoolean(str, true));
        }
        return null;
    }

    @Override // X4.InterfaceC0168f
    public void i(String str, boolean z6, h hVar) {
        A(hVar).edit().putBoolean(str, z6).apply();
    }

    @Override // X4.InterfaceC0168f
    public String j(String str, h hVar) {
        SharedPreferences A6 = A(hVar);
        if (A6.contains(str)) {
            return A6.getString(str, StringUtils.EMPTY);
        }
        return null;
    }

    @Override // A5.d
    public Object k(A5.e eVar, i5.d dVar) {
        Object k6 = ((A5.d) this.f3655p).k(new A5.l(eVar, (M.d) this.f3656q, (B) this.f3657r), dVar);
        if (k6 == EnumC0522a.o) {
            return k6;
        }
        return g5.h.f6800a;
    }

    @Override // X4.InterfaceC0168f
    public ArrayList l(String str, h hVar) {
        List list;
        SharedPreferences A6 = A(hVar);
        if (A6.contains(str)) {
            String string = A6.getString(str, StringUtils.EMPTY);
            q5.h.b(string);
            if (string.startsWith("VGhpcyBpcyB0aGUgcHJlZml4IGZvciBhIGxpc3Qu") && !string.startsWith("VGhpcyBpcyB0aGUgcHJlZml4IGZvciBhIGxpc3Qu!") && (list = (List) C.c(A6.getString(str, StringUtils.EMPTY), (m3.e) this.f3657r)) != null) {
                ArrayList arrayList = new ArrayList();
                for (Object obj : list) {
                    if (obj instanceof String) {
                        arrayList.add(obj);
                    }
                }
                return arrayList;
            }
            return null;
        }
        return null;
    }

    @Override // X4.InterfaceC0168f
    public Long m(String str, h hVar) {
        long j6;
        SharedPreferences A6 = A(hVar);
        if (A6.contains(str)) {
            try {
                j6 = A6.getLong(str, 0L);
            } catch (ClassCastException unused) {
                j6 = A6.getInt(str, 0);
            }
            return Long.valueOf(j6);
        }
        return null;
    }

    @Override // X4.InterfaceC0168f
    public void n(String str, List list, h hVar) {
        A(hVar).edit().putString(str, "VGhpcyBpcyB0aGUgcHJlZml4IGZvciBhIGxpc3Qu".concat(((m3.e) this.f3657r).m(list))).apply();
    }

    @Override // X4.InterfaceC0168f
    public void o(String str, double d6, h hVar) {
        A(hVar).edit().putString(str, "VGhpcyBpcyB0aGUgcHJlZml4IGZvciBEb3VibGUu" + d6).apply();
    }

    /* JADX WARN: Code restructure failed: missing block: B:12:0x00d7, code lost:
    
        if (r1.startsWith("generic") == false) goto L14;
     */
    /* JADX WARN: Removed duplicated region for block: B:16:0x0174  */
    /* JADX WARN: Removed duplicated region for block: B:25:0x0190 A[LOOP:1: B:24:0x018e->B:25:0x0190, LOOP_END] */
    @Override // M4.n
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public void onMethodCall(M4.m mVar, M4.o oVar) {
        boolean z6;
        int size;
        q5.h.e(mVar, "call");
        if (mVar.f1733a.equals("getDeviceInfo")) {
            HashMap hashMap = new HashMap();
            hashMap.put("board", Build.BOARD);
            hashMap.put("bootloader", Build.BOOTLOADER);
            String str = Build.BRAND;
            hashMap.put("brand", str);
            String str2 = Build.DEVICE;
            hashMap.put("device", str2);
            hashMap.put("display", Build.DISPLAY);
            String str3 = Build.FINGERPRINT;
            hashMap.put("fingerprint", str3);
            String str4 = Build.HARDWARE;
            hashMap.put("hardware", str4);
            hashMap.put("host", Build.HOST);
            hashMap.put("id", Build.ID);
            String str5 = Build.MANUFACTURER;
            hashMap.put("manufacturer", str5);
            String str6 = Build.MODEL;
            hashMap.put("model", str6);
            String str7 = Build.PRODUCT;
            hashMap.put("product", str7);
            if (Build.VERSION.SDK_INT >= 25) {
                String string = Settings.Global.getString((ContentResolver) this.f3657r, "device_name");
                if (string == null) {
                    string = StringUtils.EMPTY;
                }
                hashMap.put("name", string);
            }
            String[] strArr = Build.SUPPORTED_32_BIT_ABIS;
            hashMap.put("supported32BitAbis", h5.e.T(Arrays.copyOf(strArr, strArr.length)));
            String[] strArr2 = Build.SUPPORTED_64_BIT_ABIS;
            hashMap.put("supported64BitAbis", h5.e.T(Arrays.copyOf(strArr2, strArr2.length)));
            String[] strArr3 = Build.SUPPORTED_ABIS;
            hashMap.put("supportedAbis", h5.e.T(Arrays.copyOf(strArr3, strArr3.length)));
            hashMap.put("tags", Build.TAGS);
            hashMap.put("type", Build.TYPE);
            q5.h.d(str, "BRAND");
            int i6 = 0;
            if (str.startsWith("generic")) {
                q5.h.d(str2, "DEVICE");
            }
            q5.h.d(str3, "FINGERPRINT");
            if (!str3.startsWith("generic") && !str3.startsWith("unknown")) {
                q5.h.d(str4, "HARDWARE");
                if (!w5.j.d(str4, "goldfish") && !w5.j.d(str4, "ranchu")) {
                    q5.h.d(str6, "MODEL");
                    if (!w5.j.d(str6, "google_sdk") && !w5.j.d(str6, "Emulator") && !w5.j.d(str6, "Android SDK built for x86")) {
                        q5.h.d(str5, "MANUFACTURER");
                        if (!w5.j.d(str5, "Genymotion")) {
                            q5.h.d(str7, "PRODUCT");
                            if (!w5.j.d(str7, "sdk") && !w5.j.d(str7, "vbox86p") && !w5.j.d(str7, "emulator") && !w5.j.d(str7, "simulator")) {
                                z6 = false;
                                hashMap.put("isPhysicalDevice", Boolean.valueOf(!z6));
                                FeatureInfo[] systemAvailableFeatures = ((PackageManager) this.f3655p).getSystemAvailableFeatures();
                                q5.h.d(systemAvailableFeatures, "getSystemAvailableFeatures(...)");
                                ArrayList arrayList = new ArrayList();
                                for (FeatureInfo featureInfo : systemAvailableFeatures) {
                                    if (featureInfo.name != null) {
                                        arrayList.add(featureInfo);
                                    }
                                }
                                ArrayList arrayList2 = new ArrayList(h5.f.V(arrayList));
                                size = arrayList.size();
                                while (i6 < size) {
                                    Object obj = arrayList.get(i6);
                                    i6++;
                                    arrayList2.add(((FeatureInfo) obj).name);
                                }
                                hashMap.put("systemFeatures", arrayList2);
                                StatFs statFs = new StatFs(Environment.getDataDirectory().getPath());
                                hashMap.put("freeDiskSize", Long.valueOf(statFs.getFreeBytes()));
                                hashMap.put("totalDiskSize", Long.valueOf(statFs.getTotalBytes()));
                                HashMap hashMap2 = new HashMap();
                                int i7 = Build.VERSION.SDK_INT;
                                hashMap2.put("baseOS", Build.VERSION.BASE_OS);
                                hashMap2.put("previewSdkInt", Integer.valueOf(Build.VERSION.PREVIEW_SDK_INT));
                                hashMap2.put("securityPatch", Build.VERSION.SECURITY_PATCH);
                                hashMap2.put("codename", Build.VERSION.CODENAME);
                                hashMap2.put("incremental", Build.VERSION.INCREMENTAL);
                                hashMap2.put("release", Build.VERSION.RELEASE);
                                hashMap2.put("sdkInt", Integer.valueOf(i7));
                                hashMap.put("version", hashMap2);
                                ActivityManager.MemoryInfo memoryInfo = new ActivityManager.MemoryInfo();
                                ((ActivityManager) this.f3656q).getMemoryInfo(memoryInfo);
                                hashMap.put("isLowRamDevice", Boolean.valueOf(memoryInfo.lowMemory));
                                hashMap.put("physicalRamSize", Long.valueOf(memoryInfo.totalMem / 1048576));
                                hashMap.put("availableRamSize", Long.valueOf(memoryInfo.availMem / 1048576));
                                ((L4.j) oVar).b(hashMap);
                                return;
                            }
                        }
                    }
                }
            }
            z6 = true;
            hashMap.put("isPhysicalDevice", Boolean.valueOf(!z6));
            FeatureInfo[] systemAvailableFeatures2 = ((PackageManager) this.f3655p).getSystemAvailableFeatures();
            q5.h.d(systemAvailableFeatures2, "getSystemAvailableFeatures(...)");
            ArrayList arrayList3 = new ArrayList();
            while (r3 < r2) {
            }
            ArrayList arrayList22 = new ArrayList(h5.f.V(arrayList3));
            size = arrayList3.size();
            while (i6 < size) {
            }
            hashMap.put("systemFeatures", arrayList22);
            StatFs statFs2 = new StatFs(Environment.getDataDirectory().getPath());
            hashMap.put("freeDiskSize", Long.valueOf(statFs2.getFreeBytes()));
            hashMap.put("totalDiskSize", Long.valueOf(statFs2.getTotalBytes()));
            HashMap hashMap22 = new HashMap();
            int i72 = Build.VERSION.SDK_INT;
            hashMap22.put("baseOS", Build.VERSION.BASE_OS);
            hashMap22.put("previewSdkInt", Integer.valueOf(Build.VERSION.PREVIEW_SDK_INT));
            hashMap22.put("securityPatch", Build.VERSION.SECURITY_PATCH);
            hashMap22.put("codename", Build.VERSION.CODENAME);
            hashMap22.put("incremental", Build.VERSION.INCREMENTAL);
            hashMap22.put("release", Build.VERSION.RELEASE);
            hashMap22.put("sdkInt", Integer.valueOf(i72));
            hashMap.put("version", hashMap22);
            ActivityManager.MemoryInfo memoryInfo2 = new ActivityManager.MemoryInfo();
            ((ActivityManager) this.f3656q).getMemoryInfo(memoryInfo2);
            hashMap.put("isLowRamDevice", Boolean.valueOf(memoryInfo2.lowMemory));
            hashMap.put("physicalRamSize", Long.valueOf(memoryInfo2.totalMem / 1048576));
            hashMap.put("availableRamSize", Long.valueOf(memoryInfo2.availMem / 1048576));
            ((L4.j) oVar).b(hashMap);
            return;
        }
        ((L4.j) oVar).c();
    }

    @Override // X4.InterfaceC0168f
    public void p(String str, String str2, h hVar) {
        A(hVar).edit().putString(str, str2).apply();
    }

    @Override // U0.d
    public List q(long j6) {
        List list = (List) this.f3655p;
        ArrayList arrayList = new ArrayList();
        ArrayList arrayList2 = new ArrayList();
        for (int i6 = 0; i6 < list.size(); i6++) {
            long[] jArr = (long[]) this.f3656q;
            int i7 = i6 * 2;
            if (jArr[i7] <= j6 && j6 < jArr[i7 + 1]) {
                d1.d dVar = (d1.d) list.get(i6);
                U.b bVar = dVar.f5980a;
                if (bVar.e == -3.4028235E38f) {
                    arrayList2.add(dVar);
                } else {
                    arrayList.add(bVar);
                }
            }
        }
        Collections.sort(arrayList2, new A.d(5));
        for (int i8 = 0; i8 < arrayList2.size(); i8++) {
            U.b bVar2 = ((d1.d) arrayList2.get(i8)).f5980a;
            arrayList.add(new U.b(bVar2.f2905a, bVar2.f2906b, bVar2.f2907c, bVar2.f2908d, (-1) - i8, 1, bVar2.f2910g, bVar2.f2911h, bVar2.f2912i, bVar2.f2917n, bVar2.o, bVar2.f2913j, bVar2.f2914k, bVar2.f2915l, bVar2.f2916m, bVar2.f2918p, bVar2.f2919q, bVar2.f2920r));
        }
        return arrayList;
    }

    @Override // X4.InterfaceC0168f
    public F r(String str, h hVar) {
        SharedPreferences A6 = A(hVar);
        if (!A6.contains(str)) {
            return null;
        }
        String string = A6.getString(str, StringUtils.EMPTY);
        q5.h.b(string);
        if (string.startsWith("VGhpcyBpcyB0aGUgcHJlZml4IGZvciBhIGxpc3Qu!")) {
            return new F(string, D.f3644r);
        }
        if (string.startsWith("VGhpcyBpcyB0aGUgcHJlZml4IGZvciBhIGxpc3Qu")) {
            return new F(null, D.f3643q);
        }
        return new F(null, D.f3645s);
    }

    @Override // X4.InterfaceC0168f
    public void s(List list, h hVar) {
        Set set;
        SharedPreferences A6 = A(hVar);
        SharedPreferences.Editor edit = A6.edit();
        q5.h.d(edit, "edit(...)");
        Map<String, ?> all = A6.getAll();
        q5.h.d(all, "getAll(...)");
        ArrayList arrayList = new ArrayList();
        for (String str : all.keySet()) {
            Object obj = all.get(str);
            if (list != null) {
                set = AbstractC0470d.f0(list);
            } else {
                set = null;
            }
            if (C.b(str, obj, set)) {
                arrayList.add(str);
            }
        }
        Iterator it = arrayList.iterator();
        q5.h.d(it, "iterator(...)");
        while (it.hasNext()) {
            Object next = it.next();
            q5.h.d(next, "next(...)");
            edit.remove((String) next);
        }
        edit.apply();
    }

    @Override // X4.InterfaceC0168f
    public Map t(List list, h hVar) {
        Set set;
        Object value;
        Map<String, ?> all = A(hVar).getAll();
        q5.h.d(all, "getAll(...)");
        HashMap hashMap = new HashMap();
        for (Map.Entry<String, ?> entry : all.entrySet()) {
            String key = entry.getKey();
            Object value2 = entry.getValue();
            if (list != null) {
                set = AbstractC0470d.f0(list);
            } else {
                set = null;
            }
            if (C.b(key, value2, set) && (value = entry.getValue()) != null) {
                String key2 = entry.getKey();
                Object c6 = C.c(value, (m3.e) this.f3657r);
                q5.h.c(c6, "null cannot be cast to non-null type kotlin.Any");
                hashMap.put(key2, c6);
            }
        }
        return hashMap;
    }

    public String toString() {
        switch (this.o) {
            case 15:
                return ((F0.c) this.f3656q).toString() + ", hidden list:" + ((ArrayList) this.f3657r).size();
            default:
                return super.toString();
        }
    }

    @Override // X4.InterfaceC0168f
    public void u(String str, long j6, h hVar) {
        A(hVar).edit().putLong(str, j6).apply();
    }

    @Override // C2.d
    public void v(C2.i iVar) {
        C0476b c0476b = (C0476b) this.f3655p;
        String str = (String) this.f3656q;
        ScheduledFuture scheduledFuture = (ScheduledFuture) this.f3657r;
        synchronized (c0476b.f7020a) {
            c0476b.f7020a.remove(str);
        }
        scheduledFuture.cancel(false);
    }

    @Override // U0.d
    public int w() {
        return ((long[]) this.f3657r).length;
    }

    public C2.r x(int i6) {
        Bundle bundle = (Bundle) this.f3656q;
        if (bundle.getString("apiKey") != null) {
            bundle.putInt("suffix", i6);
            f3.k kVar = (f3.k) this.f3655p;
            f3.k.b(bundle);
            return kVar.f6578a.b(1, new f3.h(bundle));
        }
        throw new IllegalArgumentException("Missing API key. Set with setApiKey().");
    }

    public String y(String str, long j6, int i6, long j7) {
        ArrayList arrayList = (ArrayList) this.f3655p;
        ArrayList arrayList2 = (ArrayList) this.f3657r;
        ArrayList arrayList3 = (ArrayList) this.f3656q;
        StringBuilder sb = new StringBuilder();
        for (int i7 = 0; i7 < arrayList3.size(); i7++) {
            sb.append((String) arrayList.get(i7));
            if (((Integer) arrayList3.get(i7)).intValue() == 1) {
                sb.append(str);
            } else if (((Integer) arrayList3.get(i7)).intValue() == 2) {
                sb.append(String.format(Locale.US, (String) arrayList2.get(i7), Long.valueOf(j6)));
            } else if (((Integer) arrayList3.get(i7)).intValue() == 3) {
                sb.append(String.format(Locale.US, (String) arrayList2.get(i7), Integer.valueOf(i6)));
            } else if (((Integer) arrayList3.get(i7)).intValue() == 4) {
                sb.append(String.format(Locale.US, (String) arrayList2.get(i7), Long.valueOf(j7)));
            }
        }
        sb.append((String) arrayList.get(arrayList3.size()));
        return sb.toString();
    }

    public Boolean z(String str) {
        String shortString;
        Intent intent = new Intent("android.intent.action.VIEW");
        intent.setData(Uri.parse(str));
        ComponentName resolveActivity = intent.resolveActivity(((Context) ((B3.h) this.f3655p).f184p).getPackageManager());
        if (resolveActivity == null) {
            shortString = null;
        } else {
            shortString = resolveActivity.toShortString();
        }
        if (shortString == null) {
            return Boolean.FALSE;
        }
        return Boolean.valueOf(!"{com.android.fallback/com.android.fallback.Fallback}".equals(shortString));
    }

    public /* synthetic */ g(Object obj, Object obj2, int i6) {
        this.o = i6;
        this.f3656q = obj;
        this.f3655p = obj2;
    }

    public /* synthetic */ g(Object obj, Object obj2, Object obj3, int i6) {
        this.o = i6;
        this.f3655p = obj;
        this.f3656q = obj2;
        this.f3657r = obj3;
    }

    public g(C0466b c0466b, Y3.i iVar) {
        this.o = 9;
        this.f3655p = c0466b;
        this.f3656q = iVar;
        this.f3657r = new MediaCodec.BufferInfo();
    }

    public g(ArrayList arrayList) {
        this.o = 8;
        this.f3655p = Collections.unmodifiableList(new ArrayList(arrayList));
        this.f3656q = new long[arrayList.size() * 2];
        for (int i6 = 0; i6 < arrayList.size(); i6++) {
            d1.d dVar = (d1.d) arrayList.get(i6);
            int i7 = i6 * 2;
            long[] jArr = (long[]) this.f3656q;
            jArr[i7] = dVar.f5981b;
            jArr[i7 + 1] = dVar.f5982c;
        }
        long[] jArr2 = (long[]) this.f3656q;
        long[] copyOf = Arrays.copyOf(jArr2, jArr2.length);
        this.f3657r = copyOf;
        Arrays.sort(copyOf);
    }

    public g(X2.b bVar) {
        this.o = 15;
        this.f3655p = bVar;
        this.f3656q = new F0.c();
        this.f3657r = new ArrayList();
    }

    public g(String str) {
        this.o = 10;
        C0122o c0122o = new C0122o();
        c0122o.f2586l = S.F.n("video/mp2t");
        c0122o.f2587m = S.F.n(str);
        this.f3655p = new C0123p(c0122o);
    }

    public g(FirebaseMessagingService firebaseMessagingService, C0440b c0440b, ExecutorService executorService) {
        this.o = 20;
        this.f3655p = executorService;
        this.f3656q = firebaseMessagingService;
        this.f3657r = c0440b;
    }

    public g(Context context) {
        this.o = 2;
        B3.h hVar = new B3.h(context, 12);
        this.f3656q = context;
        this.f3655p = hVar;
    }

    public g(Context context, InterfaceC0290d interfaceC0290d, C0259b c0259b) {
        this.o = 6;
        this.f3656q = context;
        this.f3655p = interfaceC0290d;
        this.f3657r = c0259b;
    }

    public g(x0.r rVar) {
        this.o = 19;
        this.f3655p = rVar;
    }

    public g(C0351o c0351o) {
        this.o = 14;
        this.f3655p = new C.b(30, 0);
        this.f3656q = new ArrayList();
        this.f3657r = new ArrayList();
        new C0346j(this, 14);
    }

    public g(f3.k kVar) {
        this.o = 11;
        this.f3655p = kVar;
        Bundle bundle = new Bundle();
        this.f3656q = bundle;
        Y2.g gVar = kVar.f6580c;
        gVar.a();
        bundle.putString("apiKey", gVar.f3823c.f3830a);
        Bundle bundle2 = new Bundle();
        this.f3657r = bundle2;
        bundle.putBundle("parameters", bundle2);
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r1v0, types: [T.m, java.lang.Object] */
    public g(T.j[] jVarArr) {
        this.o = 4;
        b0.F f6 = new b0.F();
        ?? obj = new Object();
        obj.f2773c = 1.0f;
        obj.f2774d = 1.0f;
        T.h hVar = T.h.e;
        obj.e = hVar;
        obj.f2775f = hVar;
        obj.f2776g = hVar;
        obj.f2777h = hVar;
        ByteBuffer byteBuffer = T.j.f2744a;
        obj.f2780k = byteBuffer;
        obj.f2781l = byteBuffer.asShortBuffer();
        obj.f2782m = byteBuffer;
        obj.f2772b = -1;
        T.j[] jVarArr2 = new T.j[jVarArr.length + 2];
        this.f3655p = jVarArr2;
        System.arraycopy(jVarArr, 0, jVarArr2, 0, jVarArr.length);
        this.f3656q = f6;
        this.f3657r = obj;
        jVarArr2[jVarArr.length] = f6;
        jVarArr2[jVarArr.length + 1] = obj;
    }

    public g(M4.f fVar, Context context, m3.e eVar) {
        this.o = 0;
        q5.h.e(fVar, "messenger");
        q5.h.e(context, "context");
        this.f3655p = fVar;
        this.f3656q = context;
        this.f3657r = eVar;
        try {
            InterfaceC0168f.e.getClass();
            C0167e.b(fVar, this, "shared_preferences");
        } catch (Exception e) {
            Log.e("SharedPreferencesPlugin", "Received exception while setting up SharedPreferencesBackend", e);
        }
    }

    public g(AudioTrack audioTrack, C0253e c0253e) {
        this.o = 5;
        this.f3655p = audioTrack;
        this.f3656q = c0253e;
        this.f3657r = new AudioRouting.OnRoutingChangedListener() { // from class: b0.v
            @Override // android.media.AudioRouting.OnRoutingChangedListener
            public final void onRoutingChanged(AudioRouting audioRouting) {
                AudioDeviceInfo routedDevice;
                X4.g gVar = X4.g.this;
                if (((v) gVar.f3657r) != null && (routedDevice = audioRouting.getRoutedDevice()) != null) {
                    ((C0253e) gVar.f3656q).b(routedDevice);
                }
            }
        };
        audioTrack.addOnRoutingChangedListener((b0.v) this.f3657r, new Handler(Looper.myLooper()));
    }
}
