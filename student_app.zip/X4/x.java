package X4;

import k5.AbstractC0567h;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* loaded from: classes.dex */
public final class x extends AbstractC0567h implements p5.p {

    /* renamed from: s, reason: collision with root package name */
    public /* synthetic */ Object f3714s;

    /* renamed from: t, reason: collision with root package name */
    public final /* synthetic */ M.d f3715t;

    /* renamed from: u, reason: collision with root package name */
    public final /* synthetic */ double f3716u;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public x(M.d dVar, double d6, i5.d dVar2) {
        super(2, dVar2);
        this.f3715t = dVar;
        this.f3716u = d6;
    }

    @Override // p5.p
    public final Object h(Object obj, Object obj2) {
        x xVar = (x) m((i5.d) obj2, (M.b) obj);
        g5.h hVar = g5.h.f6800a;
        xVar.p(hVar);
        return hVar;
    }

    @Override // k5.AbstractC0560a
    public final i5.d m(i5.d dVar, Object obj) {
        x xVar = new x(this.f3715t, this.f3716u, dVar);
        xVar.f3714s = obj;
        return xVar;
    }

    @Override // k5.AbstractC0560a
    public final Object p(Object obj) {
        M.b bVar = (M.b) this.f3714s;
        Q5.a.K(obj);
        bVar.d(this.f3715t, new Double(this.f3716u));
        return g5.h.f6800a;
    }
}
