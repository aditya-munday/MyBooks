package X4;

import j5.EnumC0522a;
import k5.AbstractC0567h;
import x5.InterfaceC0913u;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* loaded from: classes.dex */
public final class w extends AbstractC0567h implements p5.p {

    /* renamed from: s, reason: collision with root package name */
    public final /* synthetic */ int f3709s;

    /* renamed from: t, reason: collision with root package name */
    public int f3710t;

    /* renamed from: u, reason: collision with root package name */
    public final /* synthetic */ B f3711u;

    /* renamed from: v, reason: collision with root package name */
    public final /* synthetic */ String f3712v;

    /* renamed from: w, reason: collision with root package name */
    public final /* synthetic */ String f3713w;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public /* synthetic */ w(B b6, String str, String str2, i5.d dVar, int i6) {
        super(2, dVar);
        this.f3709s = i6;
        this.f3711u = b6;
        this.f3712v = str;
        this.f3713w = str2;
    }

    @Override // p5.p
    public final Object h(Object obj, Object obj2) {
        InterfaceC0913u interfaceC0913u = (InterfaceC0913u) obj;
        i5.d dVar = (i5.d) obj2;
        switch (this.f3709s) {
            case 0:
                return ((w) m(dVar, interfaceC0913u)).p(g5.h.f6800a);
            case 1:
                return ((w) m(dVar, interfaceC0913u)).p(g5.h.f6800a);
            default:
                return ((w) m(dVar, interfaceC0913u)).p(g5.h.f6800a);
        }
    }

    @Override // k5.AbstractC0560a
    public final i5.d m(i5.d dVar, Object obj) {
        switch (this.f3709s) {
            case 0:
                return new w(this.f3711u, this.f3712v, this.f3713w, dVar, 0);
            case 1:
                return new w(this.f3711u, this.f3712v, this.f3713w, dVar, 1);
            default:
                return new w(this.f3711u, this.f3712v, this.f3713w, dVar, 2);
        }
    }

    @Override // k5.AbstractC0560a
    public final Object p(Object obj) {
        switch (this.f3709s) {
            case 0:
                int i6 = this.f3710t;
                if (i6 != 0) {
                    if (i6 == 1) {
                        Q5.a.K(obj);
                    } else {
                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                    }
                } else {
                    Q5.a.K(obj);
                    this.f3710t = 1;
                    Object a6 = B.a(this.f3711u, this.f3712v, this.f3713w, this);
                    EnumC0522a enumC0522a = EnumC0522a.o;
                    if (a6 == enumC0522a) {
                        return enumC0522a;
                    }
                }
                return g5.h.f6800a;
            case 1:
                int i7 = this.f3710t;
                if (i7 != 0) {
                    if (i7 == 1) {
                        Q5.a.K(obj);
                    } else {
                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                    }
                } else {
                    Q5.a.K(obj);
                    this.f3710t = 1;
                    Object a7 = B.a(this.f3711u, this.f3712v, this.f3713w, this);
                    EnumC0522a enumC0522a2 = EnumC0522a.o;
                    if (a7 == enumC0522a2) {
                        return enumC0522a2;
                    }
                }
                return g5.h.f6800a;
            default:
                int i8 = this.f3710t;
                if (i8 != 0) {
                    if (i8 == 1) {
                        Q5.a.K(obj);
                    } else {
                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                    }
                } else {
                    Q5.a.K(obj);
                    this.f3710t = 1;
                    Object a8 = B.a(this.f3711u, this.f3712v, this.f3713w, this);
                    EnumC0522a enumC0522a3 = EnumC0522a.o;
                    if (a8 == enumC0522a3) {
                        return enumC0522a3;
                    }
                }
                return g5.h.f6800a;
        }
    }
}
