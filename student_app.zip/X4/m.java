package X4;

import j5.EnumC0522a;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* loaded from: classes.dex */
public final class m implements A5.d {
    public final /* synthetic */ int o;

    /* renamed from: p, reason: collision with root package name */
    public final /* synthetic */ A5.d f3672p;

    /* renamed from: q, reason: collision with root package name */
    public final /* synthetic */ M.d f3673q;

    public /* synthetic */ m(A5.d dVar, M.d dVar2, int i6) {
        this.o = i6;
        this.f3672p = dVar;
        this.f3673q = dVar2;
    }

    @Override // A5.d
    public final Object k(A5.e eVar, i5.d dVar) {
        switch (this.o) {
            case 0:
                Object k6 = this.f3672p.k(new l(eVar, this.f3673q, 0), dVar);
                if (k6 != EnumC0522a.o) {
                    return g5.h.f6800a;
                }
                return k6;
            case 1:
                Object k7 = this.f3672p.k(new l(eVar, this.f3673q, 1), dVar);
                if (k7 != EnumC0522a.o) {
                    return g5.h.f6800a;
                }
                return k7;
            case 2:
                Object k8 = this.f3672p.k(new l(eVar, this.f3673q, 2), dVar);
                if (k8 != EnumC0522a.o) {
                    return g5.h.f6800a;
                }
                return k8;
            default:
                Object k9 = this.f3672p.k(new l(eVar, this.f3673q, 3), dVar);
                if (k9 != EnumC0522a.o) {
                    return g5.h.f6800a;
                }
                return k9;
        }
    }
}
