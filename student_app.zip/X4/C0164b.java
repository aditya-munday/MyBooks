package X4;

import java.nio.ByteBuffer;
import java.util.List;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* renamed from: X4.b, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0164b extends M4.v {
    public static final C0164b e = new C0164b(0);

    /* renamed from: d, reason: collision with root package name */
    public final /* synthetic */ int f3650d;

    public /* synthetic */ C0164b(int i6) {
        this.f3650d = i6;
    }

    @Override // M4.v
    public Object f(byte b6, ByteBuffer byteBuffer) {
        List list;
        List list2;
        switch (this.f3650d) {
            case 1:
                q5.h.e(byteBuffer, "buffer");
                if (b6 == -127) {
                    Long l6 = (Long) e(byteBuffer);
                    if (l6 == null) {
                        return null;
                    }
                    int longValue = (int) l6.longValue();
                    D.f3642p.getClass();
                    for (D d6 : D.values()) {
                        if (d6.o == longValue) {
                            return d6;
                        }
                    }
                    return null;
                }
                if (b6 == -126) {
                    Object e6 = e(byteBuffer);
                    if (e6 instanceof List) {
                        list2 = (List) e6;
                    } else {
                        list2 = null;
                    }
                    if (list2 == null) {
                        return null;
                    }
                    String str = (String) list2.get(0);
                    Object obj = list2.get(1);
                    q5.h.c(obj, "null cannot be cast to non-null type kotlin.Boolean");
                    return new h(str, ((Boolean) obj).booleanValue());
                }
                if (b6 == -125) {
                    Object e7 = e(byteBuffer);
                    if (e7 instanceof List) {
                        list = (List) e7;
                    } else {
                        list = null;
                    }
                    if (list == null) {
                        return null;
                    }
                    String str2 = (String) list.get(0);
                    Object obj2 = list.get(1);
                    q5.h.c(obj2, "null cannot be cast to non-null type io.flutter.plugins.sharedpreferences.StringListLookupResultType");
                    return new F(str2, (D) obj2);
                }
                return super.f(b6, byteBuffer);
            default:
                return super.f(b6, byteBuffer);
        }
    }

    @Override // M4.v
    public void k(M4.u uVar, Object obj) {
        switch (this.f3650d) {
            case 1:
                if (obj instanceof D) {
                    uVar.write(129);
                    k(uVar, Long.valueOf(((D) obj).o));
                    return;
                } else if (obj instanceof h) {
                    uVar.write(130);
                    k(uVar, ((h) obj).a());
                    return;
                } else {
                    if (obj instanceof F) {
                        uVar.write(131);
                        F f6 = (F) obj;
                        k(uVar, h5.e.T(f6.f3647a, f6.f3648b));
                        return;
                    }
                    super.k(uVar, obj);
                    return;
                }
            default:
                super.k(uVar, obj);
                return;
        }
    }
}
