package X4;

import android.content.SharedPreferences;
import android.util.Base64;
import android.util.Log;
import j2.C0508g;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* renamed from: X4.a, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public class C0163a implements I4.b {
    public SharedPreferences o;

    /* renamed from: p, reason: collision with root package name */
    public final C0508g f3649p = new C0508g(24, false);

    public static void d(M4.f fVar, final C0163a c0163a) {
        C0508g c6 = fVar.c();
        C0164b c0164b = C0164b.e;
        v3.u uVar = new v3.u(fVar, "dev.flutter.pigeon.shared_preferences_android.SharedPreferencesApi.remove", c0164b, c6);
        if (c0163a != null) {
            final int i6 = 0;
            uVar.y(new M4.b(c0163a) { // from class: X4.c

                /* renamed from: p, reason: collision with root package name */
                public final /* synthetic */ C0163a f3651p;

                {
                    this.f3651p = c0163a;
                }

                @Override // M4.b
                public final void e(Object obj, A.c cVar) {
                    switch (i6) {
                        case 0:
                            C0163a c0163a2 = this.f3651p;
                            ArrayList arrayList = new ArrayList();
                            try {
                                arrayList.add(0, Boolean.valueOf(c0163a2.o.edit().remove((String) ((ArrayList) obj).get(0)).commit()));
                            } catch (Throwable th) {
                                arrayList = Q5.a.T(th);
                            }
                            cVar.g(arrayList);
                            return;
                        case 1:
                            C0163a c0163a3 = this.f3651p;
                            ArrayList arrayList2 = new ArrayList();
                            ArrayList arrayList3 = (ArrayList) obj;
                            try {
                                arrayList2.add(0, Boolean.valueOf(c0163a3.o.edit().putBoolean((String) arrayList3.get(0), ((Boolean) arrayList3.get(1)).booleanValue()).commit()));
                            } catch (Throwable th2) {
                                arrayList2 = Q5.a.T(th2);
                            }
                            cVar.g(arrayList2);
                            return;
                        case 2:
                            C0163a c0163a4 = this.f3651p;
                            ArrayList arrayList4 = new ArrayList();
                            ArrayList arrayList5 = (ArrayList) obj;
                            try {
                                arrayList4.add(0, c0163a4.c((String) arrayList5.get(0), (String) arrayList5.get(1)));
                            } catch (Throwable th3) {
                                arrayList4 = Q5.a.T(th3);
                            }
                            cVar.g(arrayList4);
                            return;
                        case 3:
                            C0163a c0163a5 = this.f3651p;
                            ArrayList arrayList6 = new ArrayList();
                            ArrayList arrayList7 = (ArrayList) obj;
                            try {
                                arrayList6.add(0, Boolean.valueOf(c0163a5.o.edit().putLong((String) arrayList7.get(0), ((Long) arrayList7.get(1)).longValue()).commit()));
                            } catch (Throwable th4) {
                                arrayList6 = Q5.a.T(th4);
                            }
                            cVar.g(arrayList6);
                            return;
                        case 4:
                            C0163a c0163a6 = this.f3651p;
                            ArrayList arrayList8 = new ArrayList();
                            ArrayList arrayList9 = (ArrayList) obj;
                            String str = (String) arrayList9.get(0);
                            Double d6 = (Double) arrayList9.get(1);
                            try {
                                c0163a6.getClass();
                                String d7 = Double.toString(d6.doubleValue());
                                arrayList8.add(0, Boolean.valueOf(c0163a6.o.edit().putString(str, "VGhpcyBpcyB0aGUgcHJlZml4IGZvciBEb3VibGUu" + d7).commit()));
                            } catch (Throwable th5) {
                                arrayList8 = Q5.a.T(th5);
                            }
                            cVar.g(arrayList8);
                            return;
                        case 5:
                            C0163a c0163a7 = this.f3651p;
                            ArrayList arrayList10 = new ArrayList();
                            ArrayList arrayList11 = (ArrayList) obj;
                            try {
                                arrayList10.add(0, Boolean.valueOf(c0163a7.o.edit().putString((String) arrayList11.get(0), (String) arrayList11.get(1)).commit()));
                            } catch (Throwable th6) {
                                arrayList10 = Q5.a.T(th6);
                            }
                            cVar.g(arrayList10);
                            return;
                        case 6:
                            C0163a c0163a8 = this.f3651p;
                            ArrayList arrayList12 = new ArrayList();
                            ArrayList arrayList13 = (ArrayList) obj;
                            String str2 = (String) arrayList13.get(0);
                            List list = (List) arrayList13.get(1);
                            try {
                                arrayList12.add(0, Boolean.valueOf(c0163a8.o.edit().putString(str2, "VGhpcyBpcyB0aGUgcHJlZml4IGZvciBhIGxpc3Qu" + c0163a8.f3649p.f(list)).commit()));
                            } catch (Throwable th7) {
                                arrayList12 = Q5.a.T(th7);
                            }
                            cVar.g(arrayList12);
                            return;
                        case 7:
                            C0163a c0163a9 = this.f3651p;
                            ArrayList arrayList14 = new ArrayList();
                            ArrayList arrayList15 = (ArrayList) obj;
                            try {
                                arrayList14.add(0, c0163a9.a((String) arrayList15.get(0), (List) arrayList15.get(1)));
                            } catch (Throwable th8) {
                                arrayList14 = Q5.a.T(th8);
                            }
                            cVar.g(arrayList14);
                            return;
                        default:
                            C0163a c0163a10 = this.f3651p;
                            ArrayList arrayList16 = new ArrayList();
                            ArrayList arrayList17 = (ArrayList) obj;
                            try {
                                arrayList16.add(0, c0163a10.b((String) arrayList17.get(0), (List) arrayList17.get(1)));
                            } catch (Throwable th9) {
                                arrayList16 = Q5.a.T(th9);
                            }
                            cVar.g(arrayList16);
                            return;
                    }
                }
            });
        } else {
            uVar.y(null);
        }
        v3.u uVar2 = new v3.u(fVar, "dev.flutter.pigeon.shared_preferences_android.SharedPreferencesApi.setBool", c0164b, c6);
        if (c0163a != null) {
            final int i7 = 1;
            uVar2.y(new M4.b(c0163a) { // from class: X4.c

                /* renamed from: p, reason: collision with root package name */
                public final /* synthetic */ C0163a f3651p;

                {
                    this.f3651p = c0163a;
                }

                @Override // M4.b
                public final void e(Object obj, A.c cVar) {
                    switch (i7) {
                        case 0:
                            C0163a c0163a2 = this.f3651p;
                            ArrayList arrayList = new ArrayList();
                            try {
                                arrayList.add(0, Boolean.valueOf(c0163a2.o.edit().remove((String) ((ArrayList) obj).get(0)).commit()));
                            } catch (Throwable th) {
                                arrayList = Q5.a.T(th);
                            }
                            cVar.g(arrayList);
                            return;
                        case 1:
                            C0163a c0163a3 = this.f3651p;
                            ArrayList arrayList2 = new ArrayList();
                            ArrayList arrayList3 = (ArrayList) obj;
                            try {
                                arrayList2.add(0, Boolean.valueOf(c0163a3.o.edit().putBoolean((String) arrayList3.get(0), ((Boolean) arrayList3.get(1)).booleanValue()).commit()));
                            } catch (Throwable th2) {
                                arrayList2 = Q5.a.T(th2);
                            }
                            cVar.g(arrayList2);
                            return;
                        case 2:
                            C0163a c0163a4 = this.f3651p;
                            ArrayList arrayList4 = new ArrayList();
                            ArrayList arrayList5 = (ArrayList) obj;
                            try {
                                arrayList4.add(0, c0163a4.c((String) arrayList5.get(0), (String) arrayList5.get(1)));
                            } catch (Throwable th3) {
                                arrayList4 = Q5.a.T(th3);
                            }
                            cVar.g(arrayList4);
                            return;
                        case 3:
                            C0163a c0163a5 = this.f3651p;
                            ArrayList arrayList6 = new ArrayList();
                            ArrayList arrayList7 = (ArrayList) obj;
                            try {
                                arrayList6.add(0, Boolean.valueOf(c0163a5.o.edit().putLong((String) arrayList7.get(0), ((Long) arrayList7.get(1)).longValue()).commit()));
                            } catch (Throwable th4) {
                                arrayList6 = Q5.a.T(th4);
                            }
                            cVar.g(arrayList6);
                            return;
                        case 4:
                            C0163a c0163a6 = this.f3651p;
                            ArrayList arrayList8 = new ArrayList();
                            ArrayList arrayList9 = (ArrayList) obj;
                            String str = (String) arrayList9.get(0);
                            Double d6 = (Double) arrayList9.get(1);
                            try {
                                c0163a6.getClass();
                                String d7 = Double.toString(d6.doubleValue());
                                arrayList8.add(0, Boolean.valueOf(c0163a6.o.edit().putString(str, "VGhpcyBpcyB0aGUgcHJlZml4IGZvciBEb3VibGUu" + d7).commit()));
                            } catch (Throwable th5) {
                                arrayList8 = Q5.a.T(th5);
                            }
                            cVar.g(arrayList8);
                            return;
                        case 5:
                            C0163a c0163a7 = this.f3651p;
                            ArrayList arrayList10 = new ArrayList();
                            ArrayList arrayList11 = (ArrayList) obj;
                            try {
                                arrayList10.add(0, Boolean.valueOf(c0163a7.o.edit().putString((String) arrayList11.get(0), (String) arrayList11.get(1)).commit()));
                            } catch (Throwable th6) {
                                arrayList10 = Q5.a.T(th6);
                            }
                            cVar.g(arrayList10);
                            return;
                        case 6:
                            C0163a c0163a8 = this.f3651p;
                            ArrayList arrayList12 = new ArrayList();
                            ArrayList arrayList13 = (ArrayList) obj;
                            String str2 = (String) arrayList13.get(0);
                            List list = (List) arrayList13.get(1);
                            try {
                                arrayList12.add(0, Boolean.valueOf(c0163a8.o.edit().putString(str2, "VGhpcyBpcyB0aGUgcHJlZml4IGZvciBhIGxpc3Qu" + c0163a8.f3649p.f(list)).commit()));
                            } catch (Throwable th7) {
                                arrayList12 = Q5.a.T(th7);
                            }
                            cVar.g(arrayList12);
                            return;
                        case 7:
                            C0163a c0163a9 = this.f3651p;
                            ArrayList arrayList14 = new ArrayList();
                            ArrayList arrayList15 = (ArrayList) obj;
                            try {
                                arrayList14.add(0, c0163a9.a((String) arrayList15.get(0), (List) arrayList15.get(1)));
                            } catch (Throwable th8) {
                                arrayList14 = Q5.a.T(th8);
                            }
                            cVar.g(arrayList14);
                            return;
                        default:
                            C0163a c0163a10 = this.f3651p;
                            ArrayList arrayList16 = new ArrayList();
                            ArrayList arrayList17 = (ArrayList) obj;
                            try {
                                arrayList16.add(0, c0163a10.b((String) arrayList17.get(0), (List) arrayList17.get(1)));
                            } catch (Throwable th9) {
                                arrayList16 = Q5.a.T(th9);
                            }
                            cVar.g(arrayList16);
                            return;
                    }
                }
            });
        } else {
            uVar2.y(null);
        }
        v3.u uVar3 = new v3.u(fVar, "dev.flutter.pigeon.shared_preferences_android.SharedPreferencesApi.setString", c0164b, c6);
        if (c0163a != null) {
            final int i8 = 2;
            uVar3.y(new M4.b(c0163a) { // from class: X4.c

                /* renamed from: p, reason: collision with root package name */
                public final /* synthetic */ C0163a f3651p;

                {
                    this.f3651p = c0163a;
                }

                @Override // M4.b
                public final void e(Object obj, A.c cVar) {
                    switch (i8) {
                        case 0:
                            C0163a c0163a2 = this.f3651p;
                            ArrayList arrayList = new ArrayList();
                            try {
                                arrayList.add(0, Boolean.valueOf(c0163a2.o.edit().remove((String) ((ArrayList) obj).get(0)).commit()));
                            } catch (Throwable th) {
                                arrayList = Q5.a.T(th);
                            }
                            cVar.g(arrayList);
                            return;
                        case 1:
                            C0163a c0163a3 = this.f3651p;
                            ArrayList arrayList2 = new ArrayList();
                            ArrayList arrayList3 = (ArrayList) obj;
                            try {
                                arrayList2.add(0, Boolean.valueOf(c0163a3.o.edit().putBoolean((String) arrayList3.get(0), ((Boolean) arrayList3.get(1)).booleanValue()).commit()));
                            } catch (Throwable th2) {
                                arrayList2 = Q5.a.T(th2);
                            }
                            cVar.g(arrayList2);
                            return;
                        case 2:
                            C0163a c0163a4 = this.f3651p;
                            ArrayList arrayList4 = new ArrayList();
                            ArrayList arrayList5 = (ArrayList) obj;
                            try {
                                arrayList4.add(0, c0163a4.c((String) arrayList5.get(0), (String) arrayList5.get(1)));
                            } catch (Throwable th3) {
                                arrayList4 = Q5.a.T(th3);
                            }
                            cVar.g(arrayList4);
                            return;
                        case 3:
                            C0163a c0163a5 = this.f3651p;
                            ArrayList arrayList6 = new ArrayList();
                            ArrayList arrayList7 = (ArrayList) obj;
                            try {
                                arrayList6.add(0, Boolean.valueOf(c0163a5.o.edit().putLong((String) arrayList7.get(0), ((Long) arrayList7.get(1)).longValue()).commit()));
                            } catch (Throwable th4) {
                                arrayList6 = Q5.a.T(th4);
                            }
                            cVar.g(arrayList6);
                            return;
                        case 4:
                            C0163a c0163a6 = this.f3651p;
                            ArrayList arrayList8 = new ArrayList();
                            ArrayList arrayList9 = (ArrayList) obj;
                            String str = (String) arrayList9.get(0);
                            Double d6 = (Double) arrayList9.get(1);
                            try {
                                c0163a6.getClass();
                                String d7 = Double.toString(d6.doubleValue());
                                arrayList8.add(0, Boolean.valueOf(c0163a6.o.edit().putString(str, "VGhpcyBpcyB0aGUgcHJlZml4IGZvciBEb3VibGUu" + d7).commit()));
                            } catch (Throwable th5) {
                                arrayList8 = Q5.a.T(th5);
                            }
                            cVar.g(arrayList8);
                            return;
                        case 5:
                            C0163a c0163a7 = this.f3651p;
                            ArrayList arrayList10 = new ArrayList();
                            ArrayList arrayList11 = (ArrayList) obj;
                            try {
                                arrayList10.add(0, Boolean.valueOf(c0163a7.o.edit().putString((String) arrayList11.get(0), (String) arrayList11.get(1)).commit()));
                            } catch (Throwable th6) {
                                arrayList10 = Q5.a.T(th6);
                            }
                            cVar.g(arrayList10);
                            return;
                        case 6:
                            C0163a c0163a8 = this.f3651p;
                            ArrayList arrayList12 = new ArrayList();
                            ArrayList arrayList13 = (ArrayList) obj;
                            String str2 = (String) arrayList13.get(0);
                            List list = (List) arrayList13.get(1);
                            try {
                                arrayList12.add(0, Boolean.valueOf(c0163a8.o.edit().putString(str2, "VGhpcyBpcyB0aGUgcHJlZml4IGZvciBhIGxpc3Qu" + c0163a8.f3649p.f(list)).commit()));
                            } catch (Throwable th7) {
                                arrayList12 = Q5.a.T(th7);
                            }
                            cVar.g(arrayList12);
                            return;
                        case 7:
                            C0163a c0163a9 = this.f3651p;
                            ArrayList arrayList14 = new ArrayList();
                            ArrayList arrayList15 = (ArrayList) obj;
                            try {
                                arrayList14.add(0, c0163a9.a((String) arrayList15.get(0), (List) arrayList15.get(1)));
                            } catch (Throwable th8) {
                                arrayList14 = Q5.a.T(th8);
                            }
                            cVar.g(arrayList14);
                            return;
                        default:
                            C0163a c0163a10 = this.f3651p;
                            ArrayList arrayList16 = new ArrayList();
                            ArrayList arrayList17 = (ArrayList) obj;
                            try {
                                arrayList16.add(0, c0163a10.b((String) arrayList17.get(0), (List) arrayList17.get(1)));
                            } catch (Throwable th9) {
                                arrayList16 = Q5.a.T(th9);
                            }
                            cVar.g(arrayList16);
                            return;
                    }
                }
            });
        } else {
            uVar3.y(null);
        }
        v3.u uVar4 = new v3.u(fVar, "dev.flutter.pigeon.shared_preferences_android.SharedPreferencesApi.setInt", c0164b, c6);
        if (c0163a != null) {
            final int i9 = 3;
            uVar4.y(new M4.b(c0163a) { // from class: X4.c

                /* renamed from: p, reason: collision with root package name */
                public final /* synthetic */ C0163a f3651p;

                {
                    this.f3651p = c0163a;
                }

                @Override // M4.b
                public final void e(Object obj, A.c cVar) {
                    switch (i9) {
                        case 0:
                            C0163a c0163a2 = this.f3651p;
                            ArrayList arrayList = new ArrayList();
                            try {
                                arrayList.add(0, Boolean.valueOf(c0163a2.o.edit().remove((String) ((ArrayList) obj).get(0)).commit()));
                            } catch (Throwable th) {
                                arrayList = Q5.a.T(th);
                            }
                            cVar.g(arrayList);
                            return;
                        case 1:
                            C0163a c0163a3 = this.f3651p;
                            ArrayList arrayList2 = new ArrayList();
                            ArrayList arrayList3 = (ArrayList) obj;
                            try {
                                arrayList2.add(0, Boolean.valueOf(c0163a3.o.edit().putBoolean((String) arrayList3.get(0), ((Boolean) arrayList3.get(1)).booleanValue()).commit()));
                            } catch (Throwable th2) {
                                arrayList2 = Q5.a.T(th2);
                            }
                            cVar.g(arrayList2);
                            return;
                        case 2:
                            C0163a c0163a4 = this.f3651p;
                            ArrayList arrayList4 = new ArrayList();
                            ArrayList arrayList5 = (ArrayList) obj;
                            try {
                                arrayList4.add(0, c0163a4.c((String) arrayList5.get(0), (String) arrayList5.get(1)));
                            } catch (Throwable th3) {
                                arrayList4 = Q5.a.T(th3);
                            }
                            cVar.g(arrayList4);
                            return;
                        case 3:
                            C0163a c0163a5 = this.f3651p;
                            ArrayList arrayList6 = new ArrayList();
                            ArrayList arrayList7 = (ArrayList) obj;
                            try {
                                arrayList6.add(0, Boolean.valueOf(c0163a5.o.edit().putLong((String) arrayList7.get(0), ((Long) arrayList7.get(1)).longValue()).commit()));
                            } catch (Throwable th4) {
                                arrayList6 = Q5.a.T(th4);
                            }
                            cVar.g(arrayList6);
                            return;
                        case 4:
                            C0163a c0163a6 = this.f3651p;
                            ArrayList arrayList8 = new ArrayList();
                            ArrayList arrayList9 = (ArrayList) obj;
                            String str = (String) arrayList9.get(0);
                            Double d6 = (Double) arrayList9.get(1);
                            try {
                                c0163a6.getClass();
                                String d7 = Double.toString(d6.doubleValue());
                                arrayList8.add(0, Boolean.valueOf(c0163a6.o.edit().putString(str, "VGhpcyBpcyB0aGUgcHJlZml4IGZvciBEb3VibGUu" + d7).commit()));
                            } catch (Throwable th5) {
                                arrayList8 = Q5.a.T(th5);
                            }
                            cVar.g(arrayList8);
                            return;
                        case 5:
                            C0163a c0163a7 = this.f3651p;
                            ArrayList arrayList10 = new ArrayList();
                            ArrayList arrayList11 = (ArrayList) obj;
                            try {
                                arrayList10.add(0, Boolean.valueOf(c0163a7.o.edit().putString((String) arrayList11.get(0), (String) arrayList11.get(1)).commit()));
                            } catch (Throwable th6) {
                                arrayList10 = Q5.a.T(th6);
                            }
                            cVar.g(arrayList10);
                            return;
                        case 6:
                            C0163a c0163a8 = this.f3651p;
                            ArrayList arrayList12 = new ArrayList();
                            ArrayList arrayList13 = (ArrayList) obj;
                            String str2 = (String) arrayList13.get(0);
                            List list = (List) arrayList13.get(1);
                            try {
                                arrayList12.add(0, Boolean.valueOf(c0163a8.o.edit().putString(str2, "VGhpcyBpcyB0aGUgcHJlZml4IGZvciBhIGxpc3Qu" + c0163a8.f3649p.f(list)).commit()));
                            } catch (Throwable th7) {
                                arrayList12 = Q5.a.T(th7);
                            }
                            cVar.g(arrayList12);
                            return;
                        case 7:
                            C0163a c0163a9 = this.f3651p;
                            ArrayList arrayList14 = new ArrayList();
                            ArrayList arrayList15 = (ArrayList) obj;
                            try {
                                arrayList14.add(0, c0163a9.a((String) arrayList15.get(0), (List) arrayList15.get(1)));
                            } catch (Throwable th8) {
                                arrayList14 = Q5.a.T(th8);
                            }
                            cVar.g(arrayList14);
                            return;
                        default:
                            C0163a c0163a10 = this.f3651p;
                            ArrayList arrayList16 = new ArrayList();
                            ArrayList arrayList17 = (ArrayList) obj;
                            try {
                                arrayList16.add(0, c0163a10.b((String) arrayList17.get(0), (List) arrayList17.get(1)));
                            } catch (Throwable th9) {
                                arrayList16 = Q5.a.T(th9);
                            }
                            cVar.g(arrayList16);
                            return;
                    }
                }
            });
        } else {
            uVar4.y(null);
        }
        v3.u uVar5 = new v3.u(fVar, "dev.flutter.pigeon.shared_preferences_android.SharedPreferencesApi.setDouble", c0164b, c6);
        if (c0163a != null) {
            final int i10 = 4;
            uVar5.y(new M4.b(c0163a) { // from class: X4.c

                /* renamed from: p, reason: collision with root package name */
                public final /* synthetic */ C0163a f3651p;

                {
                    this.f3651p = c0163a;
                }

                @Override // M4.b
                public final void e(Object obj, A.c cVar) {
                    switch (i10) {
                        case 0:
                            C0163a c0163a2 = this.f3651p;
                            ArrayList arrayList = new ArrayList();
                            try {
                                arrayList.add(0, Boolean.valueOf(c0163a2.o.edit().remove((String) ((ArrayList) obj).get(0)).commit()));
                            } catch (Throwable th) {
                                arrayList = Q5.a.T(th);
                            }
                            cVar.g(arrayList);
                            return;
                        case 1:
                            C0163a c0163a3 = this.f3651p;
                            ArrayList arrayList2 = new ArrayList();
                            ArrayList arrayList3 = (ArrayList) obj;
                            try {
                                arrayList2.add(0, Boolean.valueOf(c0163a3.o.edit().putBoolean((String) arrayList3.get(0), ((Boolean) arrayList3.get(1)).booleanValue()).commit()));
                            } catch (Throwable th2) {
                                arrayList2 = Q5.a.T(th2);
                            }
                            cVar.g(arrayList2);
                            return;
                        case 2:
                            C0163a c0163a4 = this.f3651p;
                            ArrayList arrayList4 = new ArrayList();
                            ArrayList arrayList5 = (ArrayList) obj;
                            try {
                                arrayList4.add(0, c0163a4.c((String) arrayList5.get(0), (String) arrayList5.get(1)));
                            } catch (Throwable th3) {
                                arrayList4 = Q5.a.T(th3);
                            }
                            cVar.g(arrayList4);
                            return;
                        case 3:
                            C0163a c0163a5 = this.f3651p;
                            ArrayList arrayList6 = new ArrayList();
                            ArrayList arrayList7 = (ArrayList) obj;
                            try {
                                arrayList6.add(0, Boolean.valueOf(c0163a5.o.edit().putLong((String) arrayList7.get(0), ((Long) arrayList7.get(1)).longValue()).commit()));
                            } catch (Throwable th4) {
                                arrayList6 = Q5.a.T(th4);
                            }
                            cVar.g(arrayList6);
                            return;
                        case 4:
                            C0163a c0163a6 = this.f3651p;
                            ArrayList arrayList8 = new ArrayList();
                            ArrayList arrayList9 = (ArrayList) obj;
                            String str = (String) arrayList9.get(0);
                            Double d6 = (Double) arrayList9.get(1);
                            try {
                                c0163a6.getClass();
                                String d7 = Double.toString(d6.doubleValue());
                                arrayList8.add(0, Boolean.valueOf(c0163a6.o.edit().putString(str, "VGhpcyBpcyB0aGUgcHJlZml4IGZvciBEb3VibGUu" + d7).commit()));
                            } catch (Throwable th5) {
                                arrayList8 = Q5.a.T(th5);
                            }
                            cVar.g(arrayList8);
                            return;
                        case 5:
                            C0163a c0163a7 = this.f3651p;
                            ArrayList arrayList10 = new ArrayList();
                            ArrayList arrayList11 = (ArrayList) obj;
                            try {
                                arrayList10.add(0, Boolean.valueOf(c0163a7.o.edit().putString((String) arrayList11.get(0), (String) arrayList11.get(1)).commit()));
                            } catch (Throwable th6) {
                                arrayList10 = Q5.a.T(th6);
                            }
                            cVar.g(arrayList10);
                            return;
                        case 6:
                            C0163a c0163a8 = this.f3651p;
                            ArrayList arrayList12 = new ArrayList();
                            ArrayList arrayList13 = (ArrayList) obj;
                            String str2 = (String) arrayList13.get(0);
                            List list = (List) arrayList13.get(1);
                            try {
                                arrayList12.add(0, Boolean.valueOf(c0163a8.o.edit().putString(str2, "VGhpcyBpcyB0aGUgcHJlZml4IGZvciBhIGxpc3Qu" + c0163a8.f3649p.f(list)).commit()));
                            } catch (Throwable th7) {
                                arrayList12 = Q5.a.T(th7);
                            }
                            cVar.g(arrayList12);
                            return;
                        case 7:
                            C0163a c0163a9 = this.f3651p;
                            ArrayList arrayList14 = new ArrayList();
                            ArrayList arrayList15 = (ArrayList) obj;
                            try {
                                arrayList14.add(0, c0163a9.a((String) arrayList15.get(0), (List) arrayList15.get(1)));
                            } catch (Throwable th8) {
                                arrayList14 = Q5.a.T(th8);
                            }
                            cVar.g(arrayList14);
                            return;
                        default:
                            C0163a c0163a10 = this.f3651p;
                            ArrayList arrayList16 = new ArrayList();
                            ArrayList arrayList17 = (ArrayList) obj;
                            try {
                                arrayList16.add(0, c0163a10.b((String) arrayList17.get(0), (List) arrayList17.get(1)));
                            } catch (Throwable th9) {
                                arrayList16 = Q5.a.T(th9);
                            }
                            cVar.g(arrayList16);
                            return;
                    }
                }
            });
        } else {
            uVar5.y(null);
        }
        v3.u uVar6 = new v3.u(fVar, "dev.flutter.pigeon.shared_preferences_android.SharedPreferencesApi.setEncodedStringList", c0164b, c6);
        if (c0163a != null) {
            final int i11 = 5;
            uVar6.y(new M4.b(c0163a) { // from class: X4.c

                /* renamed from: p, reason: collision with root package name */
                public final /* synthetic */ C0163a f3651p;

                {
                    this.f3651p = c0163a;
                }

                @Override // M4.b
                public final void e(Object obj, A.c cVar) {
                    switch (i11) {
                        case 0:
                            C0163a c0163a2 = this.f3651p;
                            ArrayList arrayList = new ArrayList();
                            try {
                                arrayList.add(0, Boolean.valueOf(c0163a2.o.edit().remove((String) ((ArrayList) obj).get(0)).commit()));
                            } catch (Throwable th) {
                                arrayList = Q5.a.T(th);
                            }
                            cVar.g(arrayList);
                            return;
                        case 1:
                            C0163a c0163a3 = this.f3651p;
                            ArrayList arrayList2 = new ArrayList();
                            ArrayList arrayList3 = (ArrayList) obj;
                            try {
                                arrayList2.add(0, Boolean.valueOf(c0163a3.o.edit().putBoolean((String) arrayList3.get(0), ((Boolean) arrayList3.get(1)).booleanValue()).commit()));
                            } catch (Throwable th2) {
                                arrayList2 = Q5.a.T(th2);
                            }
                            cVar.g(arrayList2);
                            return;
                        case 2:
                            C0163a c0163a4 = this.f3651p;
                            ArrayList arrayList4 = new ArrayList();
                            ArrayList arrayList5 = (ArrayList) obj;
                            try {
                                arrayList4.add(0, c0163a4.c((String) arrayList5.get(0), (String) arrayList5.get(1)));
                            } catch (Throwable th3) {
                                arrayList4 = Q5.a.T(th3);
                            }
                            cVar.g(arrayList4);
                            return;
                        case 3:
                            C0163a c0163a5 = this.f3651p;
                            ArrayList arrayList6 = new ArrayList();
                            ArrayList arrayList7 = (ArrayList) obj;
                            try {
                                arrayList6.add(0, Boolean.valueOf(c0163a5.o.edit().putLong((String) arrayList7.get(0), ((Long) arrayList7.get(1)).longValue()).commit()));
                            } catch (Throwable th4) {
                                arrayList6 = Q5.a.T(th4);
                            }
                            cVar.g(arrayList6);
                            return;
                        case 4:
                            C0163a c0163a6 = this.f3651p;
                            ArrayList arrayList8 = new ArrayList();
                            ArrayList arrayList9 = (ArrayList) obj;
                            String str = (String) arrayList9.get(0);
                            Double d6 = (Double) arrayList9.get(1);
                            try {
                                c0163a6.getClass();
                                String d7 = Double.toString(d6.doubleValue());
                                arrayList8.add(0, Boolean.valueOf(c0163a6.o.edit().putString(str, "VGhpcyBpcyB0aGUgcHJlZml4IGZvciBEb3VibGUu" + d7).commit()));
                            } catch (Throwable th5) {
                                arrayList8 = Q5.a.T(th5);
                            }
                            cVar.g(arrayList8);
                            return;
                        case 5:
                            C0163a c0163a7 = this.f3651p;
                            ArrayList arrayList10 = new ArrayList();
                            ArrayList arrayList11 = (ArrayList) obj;
                            try {
                                arrayList10.add(0, Boolean.valueOf(c0163a7.o.edit().putString((String) arrayList11.get(0), (String) arrayList11.get(1)).commit()));
                            } catch (Throwable th6) {
                                arrayList10 = Q5.a.T(th6);
                            }
                            cVar.g(arrayList10);
                            return;
                        case 6:
                            C0163a c0163a8 = this.f3651p;
                            ArrayList arrayList12 = new ArrayList();
                            ArrayList arrayList13 = (ArrayList) obj;
                            String str2 = (String) arrayList13.get(0);
                            List list = (List) arrayList13.get(1);
                            try {
                                arrayList12.add(0, Boolean.valueOf(c0163a8.o.edit().putString(str2, "VGhpcyBpcyB0aGUgcHJlZml4IGZvciBhIGxpc3Qu" + c0163a8.f3649p.f(list)).commit()));
                            } catch (Throwable th7) {
                                arrayList12 = Q5.a.T(th7);
                            }
                            cVar.g(arrayList12);
                            return;
                        case 7:
                            C0163a c0163a9 = this.f3651p;
                            ArrayList arrayList14 = new ArrayList();
                            ArrayList arrayList15 = (ArrayList) obj;
                            try {
                                arrayList14.add(0, c0163a9.a((String) arrayList15.get(0), (List) arrayList15.get(1)));
                            } catch (Throwable th8) {
                                arrayList14 = Q5.a.T(th8);
                            }
                            cVar.g(arrayList14);
                            return;
                        default:
                            C0163a c0163a10 = this.f3651p;
                            ArrayList arrayList16 = new ArrayList();
                            ArrayList arrayList17 = (ArrayList) obj;
                            try {
                                arrayList16.add(0, c0163a10.b((String) arrayList17.get(0), (List) arrayList17.get(1)));
                            } catch (Throwable th9) {
                                arrayList16 = Q5.a.T(th9);
                            }
                            cVar.g(arrayList16);
                            return;
                    }
                }
            });
        } else {
            uVar6.y(null);
        }
        v3.u uVar7 = new v3.u(fVar, "dev.flutter.pigeon.shared_preferences_android.SharedPreferencesApi.setDeprecatedStringList", c0164b, c6);
        if (c0163a != null) {
            final int i12 = 6;
            uVar7.y(new M4.b(c0163a) { // from class: X4.c

                /* renamed from: p, reason: collision with root package name */
                public final /* synthetic */ C0163a f3651p;

                {
                    this.f3651p = c0163a;
                }

                @Override // M4.b
                public final void e(Object obj, A.c cVar) {
                    switch (i12) {
                        case 0:
                            C0163a c0163a2 = this.f3651p;
                            ArrayList arrayList = new ArrayList();
                            try {
                                arrayList.add(0, Boolean.valueOf(c0163a2.o.edit().remove((String) ((ArrayList) obj).get(0)).commit()));
                            } catch (Throwable th) {
                                arrayList = Q5.a.T(th);
                            }
                            cVar.g(arrayList);
                            return;
                        case 1:
                            C0163a c0163a3 = this.f3651p;
                            ArrayList arrayList2 = new ArrayList();
                            ArrayList arrayList3 = (ArrayList) obj;
                            try {
                                arrayList2.add(0, Boolean.valueOf(c0163a3.o.edit().putBoolean((String) arrayList3.get(0), ((Boolean) arrayList3.get(1)).booleanValue()).commit()));
                            } catch (Throwable th2) {
                                arrayList2 = Q5.a.T(th2);
                            }
                            cVar.g(arrayList2);
                            return;
                        case 2:
                            C0163a c0163a4 = this.f3651p;
                            ArrayList arrayList4 = new ArrayList();
                            ArrayList arrayList5 = (ArrayList) obj;
                            try {
                                arrayList4.add(0, c0163a4.c((String) arrayList5.get(0), (String) arrayList5.get(1)));
                            } catch (Throwable th3) {
                                arrayList4 = Q5.a.T(th3);
                            }
                            cVar.g(arrayList4);
                            return;
                        case 3:
                            C0163a c0163a5 = this.f3651p;
                            ArrayList arrayList6 = new ArrayList();
                            ArrayList arrayList7 = (ArrayList) obj;
                            try {
                                arrayList6.add(0, Boolean.valueOf(c0163a5.o.edit().putLong((String) arrayList7.get(0), ((Long) arrayList7.get(1)).longValue()).commit()));
                            } catch (Throwable th4) {
                                arrayList6 = Q5.a.T(th4);
                            }
                            cVar.g(arrayList6);
                            return;
                        case 4:
                            C0163a c0163a6 = this.f3651p;
                            ArrayList arrayList8 = new ArrayList();
                            ArrayList arrayList9 = (ArrayList) obj;
                            String str = (String) arrayList9.get(0);
                            Double d6 = (Double) arrayList9.get(1);
                            try {
                                c0163a6.getClass();
                                String d7 = Double.toString(d6.doubleValue());
                                arrayList8.add(0, Boolean.valueOf(c0163a6.o.edit().putString(str, "VGhpcyBpcyB0aGUgcHJlZml4IGZvciBEb3VibGUu" + d7).commit()));
                            } catch (Throwable th5) {
                                arrayList8 = Q5.a.T(th5);
                            }
                            cVar.g(arrayList8);
                            return;
                        case 5:
                            C0163a c0163a7 = this.f3651p;
                            ArrayList arrayList10 = new ArrayList();
                            ArrayList arrayList11 = (ArrayList) obj;
                            try {
                                arrayList10.add(0, Boolean.valueOf(c0163a7.o.edit().putString((String) arrayList11.get(0), (String) arrayList11.get(1)).commit()));
                            } catch (Throwable th6) {
                                arrayList10 = Q5.a.T(th6);
                            }
                            cVar.g(arrayList10);
                            return;
                        case 6:
                            C0163a c0163a8 = this.f3651p;
                            ArrayList arrayList12 = new ArrayList();
                            ArrayList arrayList13 = (ArrayList) obj;
                            String str2 = (String) arrayList13.get(0);
                            List list = (List) arrayList13.get(1);
                            try {
                                arrayList12.add(0, Boolean.valueOf(c0163a8.o.edit().putString(str2, "VGhpcyBpcyB0aGUgcHJlZml4IGZvciBhIGxpc3Qu" + c0163a8.f3649p.f(list)).commit()));
                            } catch (Throwable th7) {
                                arrayList12 = Q5.a.T(th7);
                            }
                            cVar.g(arrayList12);
                            return;
                        case 7:
                            C0163a c0163a9 = this.f3651p;
                            ArrayList arrayList14 = new ArrayList();
                            ArrayList arrayList15 = (ArrayList) obj;
                            try {
                                arrayList14.add(0, c0163a9.a((String) arrayList15.get(0), (List) arrayList15.get(1)));
                            } catch (Throwable th8) {
                                arrayList14 = Q5.a.T(th8);
                            }
                            cVar.g(arrayList14);
                            return;
                        default:
                            C0163a c0163a10 = this.f3651p;
                            ArrayList arrayList16 = new ArrayList();
                            ArrayList arrayList17 = (ArrayList) obj;
                            try {
                                arrayList16.add(0, c0163a10.b((String) arrayList17.get(0), (List) arrayList17.get(1)));
                            } catch (Throwable th9) {
                                arrayList16 = Q5.a.T(th9);
                            }
                            cVar.g(arrayList16);
                            return;
                    }
                }
            });
        } else {
            uVar7.y(null);
        }
        v3.u uVar8 = new v3.u(fVar, "dev.flutter.pigeon.shared_preferences_android.SharedPreferencesApi.clear", c0164b, c6);
        if (c0163a != null) {
            final int i13 = 7;
            uVar8.y(new M4.b(c0163a) { // from class: X4.c

                /* renamed from: p, reason: collision with root package name */
                public final /* synthetic */ C0163a f3651p;

                {
                    this.f3651p = c0163a;
                }

                @Override // M4.b
                public final void e(Object obj, A.c cVar) {
                    switch (i13) {
                        case 0:
                            C0163a c0163a2 = this.f3651p;
                            ArrayList arrayList = new ArrayList();
                            try {
                                arrayList.add(0, Boolean.valueOf(c0163a2.o.edit().remove((String) ((ArrayList) obj).get(0)).commit()));
                            } catch (Throwable th) {
                                arrayList = Q5.a.T(th);
                            }
                            cVar.g(arrayList);
                            return;
                        case 1:
                            C0163a c0163a3 = this.f3651p;
                            ArrayList arrayList2 = new ArrayList();
                            ArrayList arrayList3 = (ArrayList) obj;
                            try {
                                arrayList2.add(0, Boolean.valueOf(c0163a3.o.edit().putBoolean((String) arrayList3.get(0), ((Boolean) arrayList3.get(1)).booleanValue()).commit()));
                            } catch (Throwable th2) {
                                arrayList2 = Q5.a.T(th2);
                            }
                            cVar.g(arrayList2);
                            return;
                        case 2:
                            C0163a c0163a4 = this.f3651p;
                            ArrayList arrayList4 = new ArrayList();
                            ArrayList arrayList5 = (ArrayList) obj;
                            try {
                                arrayList4.add(0, c0163a4.c((String) arrayList5.get(0), (String) arrayList5.get(1)));
                            } catch (Throwable th3) {
                                arrayList4 = Q5.a.T(th3);
                            }
                            cVar.g(arrayList4);
                            return;
                        case 3:
                            C0163a c0163a5 = this.f3651p;
                            ArrayList arrayList6 = new ArrayList();
                            ArrayList arrayList7 = (ArrayList) obj;
                            try {
                                arrayList6.add(0, Boolean.valueOf(c0163a5.o.edit().putLong((String) arrayList7.get(0), ((Long) arrayList7.get(1)).longValue()).commit()));
                            } catch (Throwable th4) {
                                arrayList6 = Q5.a.T(th4);
                            }
                            cVar.g(arrayList6);
                            return;
                        case 4:
                            C0163a c0163a6 = this.f3651p;
                            ArrayList arrayList8 = new ArrayList();
                            ArrayList arrayList9 = (ArrayList) obj;
                            String str = (String) arrayList9.get(0);
                            Double d6 = (Double) arrayList9.get(1);
                            try {
                                c0163a6.getClass();
                                String d7 = Double.toString(d6.doubleValue());
                                arrayList8.add(0, Boolean.valueOf(c0163a6.o.edit().putString(str, "VGhpcyBpcyB0aGUgcHJlZml4IGZvciBEb3VibGUu" + d7).commit()));
                            } catch (Throwable th5) {
                                arrayList8 = Q5.a.T(th5);
                            }
                            cVar.g(arrayList8);
                            return;
                        case 5:
                            C0163a c0163a7 = this.f3651p;
                            ArrayList arrayList10 = new ArrayList();
                            ArrayList arrayList11 = (ArrayList) obj;
                            try {
                                arrayList10.add(0, Boolean.valueOf(c0163a7.o.edit().putString((String) arrayList11.get(0), (String) arrayList11.get(1)).commit()));
                            } catch (Throwable th6) {
                                arrayList10 = Q5.a.T(th6);
                            }
                            cVar.g(arrayList10);
                            return;
                        case 6:
                            C0163a c0163a8 = this.f3651p;
                            ArrayList arrayList12 = new ArrayList();
                            ArrayList arrayList13 = (ArrayList) obj;
                            String str2 = (String) arrayList13.get(0);
                            List list = (List) arrayList13.get(1);
                            try {
                                arrayList12.add(0, Boolean.valueOf(c0163a8.o.edit().putString(str2, "VGhpcyBpcyB0aGUgcHJlZml4IGZvciBhIGxpc3Qu" + c0163a8.f3649p.f(list)).commit()));
                            } catch (Throwable th7) {
                                arrayList12 = Q5.a.T(th7);
                            }
                            cVar.g(arrayList12);
                            return;
                        case 7:
                            C0163a c0163a9 = this.f3651p;
                            ArrayList arrayList14 = new ArrayList();
                            ArrayList arrayList15 = (ArrayList) obj;
                            try {
                                arrayList14.add(0, c0163a9.a((String) arrayList15.get(0), (List) arrayList15.get(1)));
                            } catch (Throwable th8) {
                                arrayList14 = Q5.a.T(th8);
                            }
                            cVar.g(arrayList14);
                            return;
                        default:
                            C0163a c0163a10 = this.f3651p;
                            ArrayList arrayList16 = new ArrayList();
                            ArrayList arrayList17 = (ArrayList) obj;
                            try {
                                arrayList16.add(0, c0163a10.b((String) arrayList17.get(0), (List) arrayList17.get(1)));
                            } catch (Throwable th9) {
                                arrayList16 = Q5.a.T(th9);
                            }
                            cVar.g(arrayList16);
                            return;
                    }
                }
            });
        } else {
            uVar8.y(null);
        }
        v3.u uVar9 = new v3.u(fVar, "dev.flutter.pigeon.shared_preferences_android.SharedPreferencesApi.getAll", c0164b, c6);
        if (c0163a != null) {
            final int i14 = 8;
            uVar9.y(new M4.b(c0163a) { // from class: X4.c

                /* renamed from: p, reason: collision with root package name */
                public final /* synthetic */ C0163a f3651p;

                {
                    this.f3651p = c0163a;
                }

                @Override // M4.b
                public final void e(Object obj, A.c cVar) {
                    switch (i14) {
                        case 0:
                            C0163a c0163a2 = this.f3651p;
                            ArrayList arrayList = new ArrayList();
                            try {
                                arrayList.add(0, Boolean.valueOf(c0163a2.o.edit().remove((String) ((ArrayList) obj).get(0)).commit()));
                            } catch (Throwable th) {
                                arrayList = Q5.a.T(th);
                            }
                            cVar.g(arrayList);
                            return;
                        case 1:
                            C0163a c0163a3 = this.f3651p;
                            ArrayList arrayList2 = new ArrayList();
                            ArrayList arrayList3 = (ArrayList) obj;
                            try {
                                arrayList2.add(0, Boolean.valueOf(c0163a3.o.edit().putBoolean((String) arrayList3.get(0), ((Boolean) arrayList3.get(1)).booleanValue()).commit()));
                            } catch (Throwable th2) {
                                arrayList2 = Q5.a.T(th2);
                            }
                            cVar.g(arrayList2);
                            return;
                        case 2:
                            C0163a c0163a4 = this.f3651p;
                            ArrayList arrayList4 = new ArrayList();
                            ArrayList arrayList5 = (ArrayList) obj;
                            try {
                                arrayList4.add(0, c0163a4.c((String) arrayList5.get(0), (String) arrayList5.get(1)));
                            } catch (Throwable th3) {
                                arrayList4 = Q5.a.T(th3);
                            }
                            cVar.g(arrayList4);
                            return;
                        case 3:
                            C0163a c0163a5 = this.f3651p;
                            ArrayList arrayList6 = new ArrayList();
                            ArrayList arrayList7 = (ArrayList) obj;
                            try {
                                arrayList6.add(0, Boolean.valueOf(c0163a5.o.edit().putLong((String) arrayList7.get(0), ((Long) arrayList7.get(1)).longValue()).commit()));
                            } catch (Throwable th4) {
                                arrayList6 = Q5.a.T(th4);
                            }
                            cVar.g(arrayList6);
                            return;
                        case 4:
                            C0163a c0163a6 = this.f3651p;
                            ArrayList arrayList8 = new ArrayList();
                            ArrayList arrayList9 = (ArrayList) obj;
                            String str = (String) arrayList9.get(0);
                            Double d6 = (Double) arrayList9.get(1);
                            try {
                                c0163a6.getClass();
                                String d7 = Double.toString(d6.doubleValue());
                                arrayList8.add(0, Boolean.valueOf(c0163a6.o.edit().putString(str, "VGhpcyBpcyB0aGUgcHJlZml4IGZvciBEb3VibGUu" + d7).commit()));
                            } catch (Throwable th5) {
                                arrayList8 = Q5.a.T(th5);
                            }
                            cVar.g(arrayList8);
                            return;
                        case 5:
                            C0163a c0163a7 = this.f3651p;
                            ArrayList arrayList10 = new ArrayList();
                            ArrayList arrayList11 = (ArrayList) obj;
                            try {
                                arrayList10.add(0, Boolean.valueOf(c0163a7.o.edit().putString((String) arrayList11.get(0), (String) arrayList11.get(1)).commit()));
                            } catch (Throwable th6) {
                                arrayList10 = Q5.a.T(th6);
                            }
                            cVar.g(arrayList10);
                            return;
                        case 6:
                            C0163a c0163a8 = this.f3651p;
                            ArrayList arrayList12 = new ArrayList();
                            ArrayList arrayList13 = (ArrayList) obj;
                            String str2 = (String) arrayList13.get(0);
                            List list = (List) arrayList13.get(1);
                            try {
                                arrayList12.add(0, Boolean.valueOf(c0163a8.o.edit().putString(str2, "VGhpcyBpcyB0aGUgcHJlZml4IGZvciBhIGxpc3Qu" + c0163a8.f3649p.f(list)).commit()));
                            } catch (Throwable th7) {
                                arrayList12 = Q5.a.T(th7);
                            }
                            cVar.g(arrayList12);
                            return;
                        case 7:
                            C0163a c0163a9 = this.f3651p;
                            ArrayList arrayList14 = new ArrayList();
                            ArrayList arrayList15 = (ArrayList) obj;
                            try {
                                arrayList14.add(0, c0163a9.a((String) arrayList15.get(0), (List) arrayList15.get(1)));
                            } catch (Throwable th8) {
                                arrayList14 = Q5.a.T(th8);
                            }
                            cVar.g(arrayList14);
                            return;
                        default:
                            C0163a c0163a10 = this.f3651p;
                            ArrayList arrayList16 = new ArrayList();
                            ArrayList arrayList17 = (ArrayList) obj;
                            try {
                                arrayList16.add(0, c0163a10.b((String) arrayList17.get(0), (List) arrayList17.get(1)));
                            } catch (Throwable th9) {
                                arrayList16 = Q5.a.T(th9);
                            }
                            cVar.g(arrayList16);
                            return;
                    }
                }
            });
        } else {
            uVar9.y(null);
        }
    }

    public final Boolean a(String str, List list) {
        SharedPreferences.Editor edit = this.o.edit();
        Map<String, ?> all = this.o.getAll();
        ArrayList arrayList = new ArrayList();
        for (String str2 : all.keySet()) {
            if (str2.startsWith(str) && (list == null || list.contains(str2))) {
                arrayList.add(str2);
            }
        }
        int size = arrayList.size();
        int i6 = 0;
        while (i6 < size) {
            Object obj = arrayList.get(i6);
            i6++;
            edit.remove((String) obj);
        }
        return Boolean.valueOf(edit.commit());
    }

    public final HashMap b(String str, List list) {
        Set hashSet;
        Object obj;
        if (list == null) {
            hashSet = null;
        } else {
            hashSet = new HashSet(list);
        }
        Map<String, ?> all = this.o.getAll();
        HashMap hashMap = new HashMap();
        for (String str2 : all.keySet()) {
            if (str2.startsWith(str) && (hashSet == null || hashSet.contains(str2))) {
                Object obj2 = all.get(str2);
                Objects.requireNonNull(obj2);
                boolean z6 = obj2 instanceof String;
                C0508g c0508g = this.f3649p;
                if (z6) {
                    String str3 = (String) obj2;
                    if (str3.startsWith("VGhpcyBpcyB0aGUgcHJlZml4IGZvciBhIGxpc3Qu")) {
                        if (!str3.startsWith("VGhpcyBpcyB0aGUgcHJlZml4IGZvciBhIGxpc3Qu!")) {
                            String substring = str3.substring(40);
                            c0508g.getClass();
                            try {
                                obj2 = (List) new ObjectInputStream(new ByteArrayInputStream(Base64.decode(substring, 0))).readObject();
                            } catch (IOException | ClassNotFoundException e) {
                                throw new RuntimeException(e);
                            }
                        }
                    } else if (str3.startsWith("VGhpcyBpcyB0aGUgcHJlZml4IGZvciBCaWdJbnRlZ2Vy")) {
                        obj = new BigInteger(str3.substring(44), 36);
                        obj2 = obj;
                    } else if (str3.startsWith("VGhpcyBpcyB0aGUgcHJlZml4IGZvciBEb3VibGUu")) {
                        obj2 = Double.valueOf(str3.substring(40));
                    }
                    hashMap.put(str2, obj2);
                } else {
                    if (obj2 instanceof Set) {
                        ArrayList arrayList = new ArrayList((Set) obj2);
                        this.o.edit().remove(str2).putString(str2, "VGhpcyBpcyB0aGUgcHJlZml4IGZvciBhIGxpc3Qu" + c0508g.f(arrayList)).apply();
                        obj = arrayList;
                        obj2 = obj;
                    }
                    hashMap.put(str2, obj2);
                }
            }
        }
        return hashMap;
    }

    public final Boolean c(String str, String str2) {
        if (!str2.startsWith("VGhpcyBpcyB0aGUgcHJlZml4IGZvciBhIGxpc3Qu") && !str2.startsWith("VGhpcyBpcyB0aGUgcHJlZml4IGZvciBCaWdJbnRlZ2Vy") && !str2.startsWith("VGhpcyBpcyB0aGUgcHJlZml4IGZvciBEb3VibGUu")) {
            return Boolean.valueOf(this.o.edit().putString(str, str2).commit());
        }
        throw new RuntimeException("StorageError: This string cannot be stored as it clashes with special identifier prefixes");
    }

    @Override // I4.b
    public final void onAttachedToEngine(I4.a aVar) {
        M4.f fVar = aVar.f1091b;
        this.o = aVar.f1090a.getSharedPreferences("FlutterSharedPreferences", 0);
        try {
            d(fVar, this);
        } catch (Exception e) {
            Log.e("SharedPreferencesPlugin", "Received exception while setting up SharedPreferencesPlugin", e);
        }
    }

    @Override // I4.b
    public final void onDetachedFromEngine(I4.a aVar) {
        d(aVar.f1091b, null);
    }
}
