package X4;

import java.util.List;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* loaded from: classes.dex */
public final class h {

    /* renamed from: a, reason: collision with root package name */
    public final String f3658a;

    /* renamed from: b, reason: collision with root package name */
    public final boolean f3659b;

    public h(String str, boolean z6) {
        this.f3658a = str;
        this.f3659b = z6;
    }

    public final List a() {
        return h5.e.T(this.f3658a, Boolean.valueOf(this.f3659b));
    }

    public final boolean equals(Object obj) {
        if (!(obj instanceof h)) {
            return false;
        }
        if (this == obj) {
            return true;
        }
        return T5.h.l(a(), ((h) obj).a());
    }

    public final int hashCode() {
        return a().hashCode();
    }

    public final String toString() {
        return "SharedPreferencesPigeonOptions(fileName=" + this.f3658a + ", useDataStore=" + this.f3659b + ")";
    }
}
