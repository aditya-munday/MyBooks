package B3;

import java.io.Serializable;
import java.util.AbstractMap;
import java.util.Comparator;
import java.util.Set;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* loaded from: classes.dex */
public final class q extends AbstractMap implements Serializable {

    /* renamed from: w, reason: collision with root package name */
    public static final m f206w = new m(0);

    /* renamed from: p, reason: collision with root package name */
    public final boolean f207p;

    /* renamed from: q, reason: collision with root package name */
    public p f208q;

    /* renamed from: t, reason: collision with root package name */
    public final p f211t;

    /* renamed from: u, reason: collision with root package name */
    public o f212u;

    /* renamed from: v, reason: collision with root package name */
    public o f213v;

    /* renamed from: r, reason: collision with root package name */
    public int f209r = 0;

    /* renamed from: s, reason: collision with root package name */
    public int f210s = 0;
    public final Comparator o = f206w;

    public q(boolean z6) {
        this.f207p = z6;
        this.f211t = new p(z6);
    }

    public final p a(Object obj, boolean z6) {
        int i6;
        p pVar;
        Comparable comparable;
        p pVar2;
        p pVar3 = this.f208q;
        m mVar = f206w;
        Comparator comparator = this.o;
        if (pVar3 != null) {
            if (comparator == mVar) {
                comparable = (Comparable) obj;
            } else {
                comparable = null;
            }
            while (true) {
                Object obj2 = pVar3.f202t;
                if (comparable != null) {
                    i6 = comparable.compareTo(obj2);
                } else {
                    i6 = comparator.compare(obj, obj2);
                }
                if (i6 == 0) {
                    return pVar3;
                }
                if (i6 < 0) {
                    pVar2 = pVar3.f198p;
                } else {
                    pVar2 = pVar3.f199q;
                }
                if (pVar2 == null) {
                    break;
                }
                pVar3 = pVar2;
            }
        } else {
            i6 = 0;
        }
        p pVar4 = pVar3;
        if (!z6) {
            return null;
        }
        p pVar5 = this.f211t;
        if (pVar4 == null) {
            if (comparator == mVar && !(obj instanceof Comparable)) {
                throw new ClassCastException(obj.getClass().getName().concat(" is not Comparable"));
            }
            pVar = new p(this.f207p, pVar4, obj, pVar5, pVar5.f201s);
            this.f208q = pVar;
        } else {
            pVar = new p(this.f207p, pVar4, obj, pVar5, pVar5.f201s);
            if (i6 < 0) {
                pVar4.f198p = pVar;
            } else {
                pVar4.f199q = pVar;
            }
            b(pVar4, true);
        }
        this.f209r++;
        this.f210s++;
        return pVar;
    }

    public final void b(p pVar, boolean z6) {
        int i6;
        int i7;
        int i8;
        int i9;
        while (pVar != null) {
            p pVar2 = pVar.f198p;
            p pVar3 = pVar.f199q;
            int i10 = 0;
            if (pVar2 != null) {
                i6 = pVar2.f205w;
            } else {
                i6 = 0;
            }
            if (pVar3 != null) {
                i7 = pVar3.f205w;
            } else {
                i7 = 0;
            }
            int i11 = i6 - i7;
            if (i11 == -2) {
                p pVar4 = pVar3.f198p;
                p pVar5 = pVar3.f199q;
                if (pVar5 != null) {
                    i9 = pVar5.f205w;
                } else {
                    i9 = 0;
                }
                if (pVar4 != null) {
                    i10 = pVar4.f205w;
                }
                int i12 = i10 - i9;
                if (i12 != -1 && (i12 != 0 || z6)) {
                    f(pVar3);
                    e(pVar);
                } else {
                    e(pVar);
                }
                if (z6) {
                    return;
                }
            } else if (i11 == 2) {
                p pVar6 = pVar2.f198p;
                p pVar7 = pVar2.f199q;
                if (pVar7 != null) {
                    i8 = pVar7.f205w;
                } else {
                    i8 = 0;
                }
                if (pVar6 != null) {
                    i10 = pVar6.f205w;
                }
                int i13 = i10 - i8;
                if (i13 != 1 && (i13 != 0 || z6)) {
                    e(pVar2);
                    f(pVar);
                } else {
                    f(pVar);
                }
                if (z6) {
                    return;
                }
            } else if (i11 == 0) {
                pVar.f205w = i6 + 1;
                if (z6) {
                    return;
                }
            } else {
                pVar.f205w = Math.max(i6, i7) + 1;
                if (!z6) {
                    return;
                }
            }
            pVar = pVar.o;
        }
    }

    public final void c(p pVar, boolean z6) {
        p pVar2;
        p pVar3;
        int i6;
        if (z6) {
            p pVar4 = pVar.f201s;
            pVar4.f200r = pVar.f200r;
            pVar.f200r.f201s = pVar4;
        }
        p pVar5 = pVar.f198p;
        p pVar6 = pVar.f199q;
        p pVar7 = pVar.o;
        int i7 = 0;
        if (pVar5 != null && pVar6 != null) {
            if (pVar5.f205w > pVar6.f205w) {
                p pVar8 = pVar5.f199q;
                while (true) {
                    p pVar9 = pVar8;
                    pVar3 = pVar5;
                    pVar5 = pVar9;
                    if (pVar5 == null) {
                        break;
                    } else {
                        pVar8 = pVar5.f199q;
                    }
                }
            } else {
                p pVar10 = pVar6.f198p;
                while (true) {
                    pVar2 = pVar6;
                    pVar6 = pVar10;
                    if (pVar6 == null) {
                        break;
                    } else {
                        pVar10 = pVar6.f198p;
                    }
                }
                pVar3 = pVar2;
            }
            c(pVar3, false);
            p pVar11 = pVar.f198p;
            if (pVar11 != null) {
                i6 = pVar11.f205w;
                pVar3.f198p = pVar11;
                pVar11.o = pVar3;
                pVar.f198p = null;
            } else {
                i6 = 0;
            }
            p pVar12 = pVar.f199q;
            if (pVar12 != null) {
                i7 = pVar12.f205w;
                pVar3.f199q = pVar12;
                pVar12.o = pVar3;
                pVar.f199q = null;
            }
            pVar3.f205w = Math.max(i6, i7) + 1;
            d(pVar, pVar3);
            return;
        }
        if (pVar5 != null) {
            d(pVar, pVar5);
            pVar.f198p = null;
        } else if (pVar6 != null) {
            d(pVar, pVar6);
            pVar.f199q = null;
        } else {
            d(pVar, null);
        }
        b(pVar7, false);
        this.f209r--;
        this.f210s++;
    }

    @Override // java.util.AbstractMap, java.util.Map
    public final void clear() {
        this.f208q = null;
        this.f209r = 0;
        this.f210s++;
        p pVar = this.f211t;
        pVar.f201s = pVar;
        pVar.f200r = pVar;
    }

    @Override // java.util.AbstractMap, java.util.Map
    public final boolean containsKey(Object obj) {
        p pVar = null;
        if (obj != null) {
            try {
                pVar = a(obj, false);
            } catch (ClassCastException unused) {
            }
        }
        if (pVar == null) {
            return false;
        }
        return true;
    }

    public final void d(p pVar, p pVar2) {
        p pVar3 = pVar.o;
        pVar.o = null;
        if (pVar2 != null) {
            pVar2.o = pVar3;
        }
        if (pVar3 != null) {
            if (pVar3.f198p == pVar) {
                pVar3.f198p = pVar2;
                return;
            } else {
                pVar3.f199q = pVar2;
                return;
            }
        }
        this.f208q = pVar2;
    }

    public final void e(p pVar) {
        int i6;
        int i7;
        p pVar2 = pVar.f198p;
        p pVar3 = pVar.f199q;
        p pVar4 = pVar3.f198p;
        p pVar5 = pVar3.f199q;
        pVar.f199q = pVar4;
        if (pVar4 != null) {
            pVar4.o = pVar;
        }
        d(pVar, pVar3);
        pVar3.f198p = pVar;
        pVar.o = pVar3;
        int i8 = 0;
        if (pVar2 != null) {
            i6 = pVar2.f205w;
        } else {
            i6 = 0;
        }
        if (pVar4 != null) {
            i7 = pVar4.f205w;
        } else {
            i7 = 0;
        }
        int max = Math.max(i6, i7) + 1;
        pVar.f205w = max;
        if (pVar5 != null) {
            i8 = pVar5.f205w;
        }
        pVar3.f205w = Math.max(max, i8) + 1;
    }

    @Override // java.util.AbstractMap, java.util.Map
    public final Set entrySet() {
        o oVar = this.f212u;
        if (oVar != null) {
            return oVar;
        }
        o oVar2 = new o(this, 0);
        this.f212u = oVar2;
        return oVar2;
    }

    public final void f(p pVar) {
        int i6;
        int i7;
        p pVar2 = pVar.f198p;
        p pVar3 = pVar.f199q;
        p pVar4 = pVar2.f198p;
        p pVar5 = pVar2.f199q;
        pVar.f198p = pVar5;
        if (pVar5 != null) {
            pVar5.o = pVar;
        }
        d(pVar, pVar2);
        pVar2.f199q = pVar;
        pVar.o = pVar2;
        int i8 = 0;
        if (pVar3 != null) {
            i6 = pVar3.f205w;
        } else {
            i6 = 0;
        }
        if (pVar5 != null) {
            i7 = pVar5.f205w;
        } else {
            i7 = 0;
        }
        int max = Math.max(i6, i7) + 1;
        pVar.f205w = max;
        if (pVar4 != null) {
            i8 = pVar4.f205w;
        }
        pVar2.f205w = Math.max(max, i8) + 1;
    }

    /* JADX WARN: Removed duplicated region for block: B:10:0x000f A[RETURN] */
    /* JADX WARN: Removed duplicated region for block: B:7:0x000c  */
    @Override // java.util.AbstractMap, java.util.Map
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final Object get(Object obj) {
        p pVar;
        if (obj != null) {
            try {
                pVar = a(obj, false);
            } catch (ClassCastException unused) {
            }
            if (pVar != null) {
                return null;
            }
            return pVar.f204v;
        }
        pVar = null;
        if (pVar != null) {
        }
    }

    @Override // java.util.AbstractMap, java.util.Map
    public final Set keySet() {
        o oVar = this.f213v;
        if (oVar != null) {
            return oVar;
        }
        o oVar2 = new o(this, 1);
        this.f213v = oVar2;
        return oVar2;
    }

    @Override // java.util.AbstractMap, java.util.Map
    public final Object put(Object obj, Object obj2) {
        if (obj != null) {
            if (obj2 == null && !this.f207p) {
                throw new NullPointerException("value == null");
            }
            p a6 = a(obj, true);
            Object obj3 = a6.f204v;
            a6.f204v = obj2;
            return obj3;
        }
        throw new NullPointerException("key == null");
    }

    /* JADX WARN: Removed duplicated region for block: B:12:0x0015 A[RETURN] */
    /* JADX WARN: Removed duplicated region for block: B:7:0x000c  */
    /* JADX WARN: Removed duplicated region for block: B:9:0x0012  */
    @Override // java.util.AbstractMap, java.util.Map
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final Object remove(Object obj) {
        p pVar;
        if (obj != null) {
            try {
                pVar = a(obj, false);
            } catch (ClassCastException unused) {
            }
            if (pVar != null) {
                c(pVar, true);
            }
            if (pVar != null) {
                return null;
            }
            return pVar.f204v;
        }
        pVar = null;
        if (pVar != null) {
        }
        if (pVar != null) {
        }
    }

    @Override // java.util.AbstractMap, java.util.Map
    public final int size() {
        return this.f209r;
    }
}
