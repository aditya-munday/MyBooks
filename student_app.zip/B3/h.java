package B3;

import C4.y;
import E2.F;
import S.C;
import S.C0112e;
import S.E;
import S.H;
import S.K;
import Z.B;
import Z.C0174f;
import a0.C0195a;
import a2.C0203a;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.util.Log;
import c2.C0294h;
import c2.InterfaceC0289c;
import c2.InterfaceC0290d;
import c5.C0337a;
import c5.C0344h;
import d2.InterfaceC0399b;
import h3.C0463b;
import j3.C0519d;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.net.ConnectException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.zip.GZIPInputStream;
import java.util.zip.GZIPOutputStream;
import org.apache.tika.fork.ContentHandlerProxy;
import org.apache.tika.metadata.HttpHeaders;
import org.apache.tika.pipes.PipesServer;
import org.apache.tika.utils.StringUtils;
import org.apache.tika.utils.XMLReaderUtils;
import org.json.JSONException;
import org.json.JSONObject;
import p0.C0700s;
import x0.InterfaceC0886h;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* loaded from: classes.dex */
public final /* synthetic */ class h implements r, InterfaceC0886h, J5.b, M4.c, C2.d, V.g, V.l, InterfaceC0399b {
    public final /* synthetic */ int o;

    /* renamed from: p, reason: collision with root package name */
    public final /* synthetic */ Object f184p;

    public /* synthetic */ h(C0195a c0195a, Object obj, int i6) {
        this.o = i6;
        this.f184p = obj;
    }

    @Override // V.l
    public void a(Object obj) {
        switch (this.o) {
            case 13:
                ((K) obj).u((C) this.f184p);
                return;
            case 14:
                ((K) obj).x((C0112e) this.f184p);
                return;
            case 15:
                ((K) obj).v((U.c) this.f184p);
                return;
            case 16:
                ((K) obj).u(((B) this.f184p).f3885a.f3901N);
                return;
            case PipesServer.TIMEOUT_EXIT_CODE /* 17 */:
                ((K) obj).y((E) this.f184p);
                return;
            case 18:
                ((K) obj).k((List) this.f184p);
                return;
            case 19:
            case XMLReaderUtils.DEFAULT_MAX_ENTITY_EXPANSIONS /* 20 */:
            default:
                m0.g gVar = (m0.g) this.f184p;
                a0.i iVar = (a0.i) ((a0.b) obj);
                iVar.getClass();
                iVar.f4384w = gVar.o;
                return;
            case 21:
                ((a0.i) ((a0.b) obj)).o = (H) this.f184p;
                return;
            case 22:
                C0174f c0174f = (C0174f) this.f184p;
                a0.i iVar2 = (a0.i) ((a0.b) obj);
                iVar2.y += c0174f.f4134g;
                iVar2.f4386z += c0174f.e;
                return;
        }
    }

    @Override // V.g
    public void accept(Object obj) {
        switch (this.o) {
            case ContentHandlerProxy.PROCESSING_INSTRUCTION /* 9 */:
                U0.h hVar = (U0.h) this.f184p;
                U0.a aVar = (U0.a) obj;
                U0.g gVar = new U0.g(aVar.f2939b, m3.e.n(aVar.f2940c, aVar.f2938a));
                hVar.f2951c.add(gVar);
                long j6 = hVar.f2957j;
                if (j6 == -9223372036854775807L || aVar.f2941d >= j6) {
                    hVar.b(gVar);
                    return;
                }
                return;
            default:
                ((F) this.f184p).a((U0.a) obj);
                return;
        }
    }

    @Override // J5.b
    public Object b(L5.b bVar) {
        return (L5.c) this.f184p;
    }

    @Override // d2.InterfaceC0399b
    public Object c() {
        SQLiteDatabase a6;
        int i6 = this.o;
        boolean z6 = false;
        Object obj = this.f184p;
        switch (i6) {
            case 25:
                C0294h c0294h = (C0294h) ((InterfaceC0289c) obj);
                c0294h.getClass();
                int i7 = Y1.a.e;
                v3.u uVar = new v3.u(14, z6);
                uVar.f10029q = null;
                uVar.f10030r = new ArrayList();
                uVar.f10031s = null;
                uVar.f10028p = StringUtils.EMPTY;
                HashMap hashMap = new HashMap();
                a6 = c0294h.a();
                a6.beginTransaction();
                try {
                    Y1.a aVar = (Y1.a) C0294h.h(a6.rawQuery("SELECT log_source, reason, events_dropped_count FROM log_event_dropped", new String[0]), new C0203a(c0294h, hashMap, uVar, 3));
                    a6.setTransactionSuccessful();
                    return aVar;
                } finally {
                }
            case 26:
                C0294h c0294h2 = (C0294h) ((InterfaceC0290d) obj);
                long h6 = c0294h2.f5493p.h() - c0294h2.f5495r.f5485d;
                a6 = c0294h2.a();
                a6.beginTransaction();
                try {
                    String[] strArr = {String.valueOf(h6)};
                    Cursor rawQuery = a6.rawQuery("SELECT COUNT(*), transport_name FROM events WHERE timestamp_ms < ? GROUP BY transport_name", strArr);
                    while (rawQuery.moveToNext()) {
                        try {
                            c0294h2.e(rawQuery.getInt(0), Y1.c.f3789q, rawQuery.getString(1));
                        } catch (Throwable th) {
                            rawQuery.close();
                            throw th;
                        }
                    }
                    rawQuery.close();
                    int delete = a6.delete("events", "timestamp_ms < ?", strArr);
                    a6.setTransactionSuccessful();
                    a6.endTransaction();
                    return Integer.valueOf(delete);
                } finally {
                }
            case 27:
                C0294h c0294h3 = (C0294h) ((InterfaceC0289c) ((I3.a) obj).f1077i);
                a6 = c0294h3.a();
                a6.beginTransaction();
                try {
                    a6.compileStatement("DELETE FROM log_event_dropped").execute();
                    a6.compileStatement("UPDATE global_log_event_state SET last_metrics_upload_ms=" + c0294h3.f5493p.h()).execute();
                    a6.setTransactionSuccessful();
                    return null;
                } finally {
                }
            default:
                v3.u uVar2 = (v3.u) obj;
                Iterator it = ((Iterable) ((C0294h) ((InterfaceC0290d) uVar2.f10029q)).c(new a0.e(7))).iterator();
                while (it.hasNext()) {
                    ((X4.g) uVar2.f10030r).T((V1.i) it.next(), 1, false);
                }
                return null;
        }
    }

    @Override // B3.r
    public Object d() {
        int i6 = this.o;
        Object obj = this.f184p;
        switch (i6) {
            case 0:
                Constructor constructor = (Constructor) obj;
                try {
                    return constructor.newInstance(null);
                } catch (IllegalAccessException e) {
                    android.support.v4.media.session.a aVar = E3.c.f799a;
                    throw new RuntimeException("Unexpected IllegalAccessException occurred (Gson 2.12.0). Certain ReflectionAccessFilter features require Java >= 9 to work correctly. If you are not using ReflectionAccessFilter, report this to the Gson maintainers.", e);
                } catch (InstantiationException e6) {
                    throw new RuntimeException("Failed to invoke constructor '" + E3.c.b(constructor) + "' with no args", e6);
                } catch (InvocationTargetException e7) {
                    throw new RuntimeException("Failed to invoke constructor '" + E3.c.b(constructor) + "' with no args", e7.getCause());
                }
            default:
                Class cls = (Class) obj;
                try {
                    return w.f219a.a(cls);
                } catch (Exception e8) {
                    throw new RuntimeException("Unable to create instance of " + cls + ". Registering an InstanceCreator or a TypeAdapter for this type, or adding a no-args constructor may fix this problem.", e8);
                }
        }
    }

    @Override // x0.InterfaceC0886h
    public long e(long j6) {
        return V.C.j((j6 * r0.e) / 1000000, 0L, ((x0.t) this.f184p).f10218j - 1);
    }

    public T1.b f(A1.i iVar) {
        InputStream inputStream;
        T1.c cVar = (T1.c) this.f184p;
        URL url = (URL) iVar.f50p;
        String t6 = android.support.v4.media.session.a.t("CctTransportBackend");
        if (Log.isLoggable(t6, 4)) {
            Log.i(t6, String.format("Making request to: %s", url));
        }
        HttpURLConnection httpURLConnection = (HttpURLConnection) url.openConnection();
        httpURLConnection.setConnectTimeout(30000);
        httpURLConnection.setReadTimeout(cVar.f2798g);
        httpURLConnection.setDoOutput(true);
        httpURLConnection.setInstanceFollowRedirects(false);
        httpURLConnection.setRequestMethod("POST");
        httpURLConnection.setRequestProperty("User-Agent", "datatransport/3.1.9 android/");
        httpURLConnection.setRequestProperty(HttpHeaders.CONTENT_ENCODING, "gzip");
        httpURLConnection.setRequestProperty(HttpHeaders.CONTENT_TYPE, "application/json");
        httpURLConnection.setRequestProperty("Accept-Encoding", "gzip");
        String str = (String) iVar.f52r;
        if (str != null) {
            httpURLConnection.setRequestProperty("X-Goog-Api-Key", str);
        }
        try {
            OutputStream outputStream = httpURLConnection.getOutputStream();
            try {
                GZIPOutputStream gZIPOutputStream = new GZIPOutputStream(outputStream);
                try {
                    Z4.s sVar = cVar.f2793a;
                    U1.i iVar2 = (U1.i) iVar.f51q;
                    BufferedWriter bufferedWriter = new BufferedWriter(new OutputStreamWriter(gZIPOutputStream));
                    C0519d c0519d = (C0519d) sVar.o;
                    j3.e eVar = new j3.e(bufferedWriter, c0519d.f7736a, c0519d.f7737b, c0519d.f7738c, c0519d.f7739d);
                    eVar.f(iVar2);
                    eVar.h();
                    eVar.f7741b.flush();
                    gZIPOutputStream.close();
                    if (outputStream != null) {
                        outputStream.close();
                    }
                    int responseCode = httpURLConnection.getResponseCode();
                    Integer valueOf = Integer.valueOf(responseCode);
                    String t7 = android.support.v4.media.session.a.t("CctTransportBackend");
                    if (Log.isLoggable(t7, 4)) {
                        Log.i(t7, String.format("Status Code: %d", valueOf));
                    }
                    android.support.v4.media.session.a.d("CctTransportBackend", "Content-Type: %s", httpURLConnection.getHeaderField(HttpHeaders.CONTENT_TYPE));
                    android.support.v4.media.session.a.d("CctTransportBackend", "Content-Encoding: %s", httpURLConnection.getHeaderField(HttpHeaders.CONTENT_ENCODING));
                    if (responseCode != 302 && responseCode != 301 && responseCode != 307) {
                        if (responseCode != 200) {
                            return new T1.b(responseCode, null, 0L);
                        }
                        InputStream inputStream2 = httpURLConnection.getInputStream();
                        try {
                            if ("gzip".equals(httpURLConnection.getHeaderField(HttpHeaders.CONTENT_ENCODING))) {
                                inputStream = new GZIPInputStream(inputStream2);
                            } else {
                                inputStream = inputStream2;
                            }
                            try {
                                T1.b bVar = new T1.b(responseCode, null, U1.m.a(new BufferedReader(new InputStreamReader(inputStream))).f3034a);
                                if (inputStream != null) {
                                    inputStream.close();
                                }
                                if (inputStream2 != null) {
                                    inputStream2.close();
                                }
                                return bVar;
                            } finally {
                            }
                        } finally {
                        }
                    } else {
                        return new T1.b(responseCode, new URL(httpURLConnection.getHeaderField(HttpHeaders.LOCATION)), 0L);
                    }
                } finally {
                }
            } finally {
            }
        } catch (C0463b e) {
            e = e;
            android.support.v4.media.session.a.g("CctTransportBackend", "Couldn't encode request, returning with 400", e);
            return new T1.b(400, null, 0L);
        } catch (ConnectException e6) {
            e = e6;
            android.support.v4.media.session.a.g("CctTransportBackend", "Couldn't open connection, returning with 500", e);
            return new T1.b(500, null, 0L);
        } catch (UnknownHostException e7) {
            e = e7;
            android.support.v4.media.session.a.g("CctTransportBackend", "Couldn't open connection, returning with 500", e);
            return new T1.b(500, null, 0L);
        } catch (IOException e8) {
            e = e8;
            android.support.v4.media.session.a.g("CctTransportBackend", "Couldn't encode request, returning with 400", e);
            return new T1.b(400, null, 0L);
        }
    }

    @Override // M4.c
    public void g(Object obj) {
        switch (this.o) {
            case 5:
                h hVar = (h) this.f184p;
                boolean z6 = false;
                if (obj != null) {
                    try {
                        z6 = ((JSONObject) obj).getBoolean("handled");
                    } catch (JSONException e) {
                        Log.e("KeyEventChannel", "Unable to unpack JSON message: " + e);
                    }
                }
                ((y) hVar.f184p).c(z6);
                return;
            default:
                long j6 = ((C0344h) this.f184p).o;
                if (obj instanceof List) {
                    List list = (List) obj;
                    if (list.size() > 1) {
                        Object obj2 = list.get(0);
                        q5.h.c(obj2, "null cannot be cast to non-null type kotlin.String");
                        Object obj3 = list.get(1);
                        q5.h.c(obj3, "null cannot be cast to non-null type kotlin.String");
                        Q5.a.l(new C0337a((String) obj2, (String) obj3, (String) list.get(2)));
                        Log.e("PigeonProxyApiRegistrar", "Failed to remove Dart strong reference with identifier: " + j6);
                        return;
                    }
                    return;
                }
                Q5.a.l(new C0337a("channel-error", "Unable to establish connection on channel: 'dev.flutter.pigeon.webview_flutter_android.PigeonInternalInstanceManager.removeStrongReference'.", StringUtils.EMPTY));
                Log.e("PigeonProxyApiRegistrar", "Failed to remove Dart strong reference with identifier: " + j6);
                return;
        }
    }

    @Override // C2.d
    public void v(C2.i iVar) {
        int i6 = this.o;
        R4.i iVar2 = (R4.i) this.f184p;
        switch (i6) {
            case 6:
                HashMap hashMap = R4.d.f2350q;
                if (iVar.f()) {
                    switch (iVar2.f2371a) {
                        case 0:
                            ArrayList arrayList = iVar2.f2372b;
                            arrayList.add(0, null);
                            iVar2.f2373c.g(arrayList);
                            return;
                        case 1:
                            ArrayList arrayList2 = iVar2.f2372b;
                            arrayList2.add(0, null);
                            iVar2.f2373c.g(arrayList2);
                            return;
                        default:
                            ArrayList arrayList3 = iVar2.f2372b;
                            arrayList3.add(0, null);
                            iVar2.f2373c.g(arrayList3);
                            return;
                    }
                }
                iVar2.b(iVar.c());
                return;
            default:
                HashMap hashMap2 = R4.d.f2350q;
                if (iVar.f()) {
                    Object d6 = iVar.d();
                    switch (iVar2.f2371a) {
                        case 3:
                            ArrayList arrayList4 = iVar2.f2372b;
                            arrayList4.add(0, (R4.g) d6);
                            iVar2.f2373c.g(arrayList4);
                            return;
                        case 4:
                            ArrayList arrayList5 = iVar2.f2372b;
                            arrayList5.add(0, (List) d6);
                            iVar2.f2373c.g(arrayList5);
                            return;
                        default:
                            ArrayList arrayList6 = iVar2.f2372b;
                            arrayList6.add(0, (R4.f) d6);
                            iVar2.f2373c.g(arrayList6);
                            return;
                    }
                }
                iVar2.b(iVar.c());
                return;
        }
    }

    public /* synthetic */ h(C0195a c0195a, C0700s c0700s, m0.g gVar, IOException iOException, boolean z6) {
        this.o = 23;
        this.f184p = gVar;
    }

    public /* synthetic */ h(Object obj, int i6) {
        this.o = i6;
        this.f184p = obj;
    }
}
