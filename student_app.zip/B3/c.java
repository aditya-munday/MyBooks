package B3;

import java.io.Serializable;
import java.lang.reflect.Type;
import java.lang.reflect.WildcardType;
import java.util.Objects;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* loaded from: classes.dex */
public final class c implements WildcardType, Serializable {
    public final Type o;

    /* renamed from: p, reason: collision with root package name */
    public final Type f180p;

    public c(Type[] typeArr, Type[] typeArr2) {
        boolean z6;
        boolean z7;
        if (typeArr2.length <= 1) {
            z6 = true;
        } else {
            z6 = false;
        }
        d.b(z6);
        if (typeArr.length == 1) {
            z7 = true;
        } else {
            z7 = false;
        }
        d.b(z7);
        if (typeArr2.length == 1) {
            Objects.requireNonNull(typeArr2[0]);
            d.c(typeArr2[0]);
            d.b(typeArr[0] == Object.class);
            this.f180p = d.a(typeArr2[0]);
            this.o = Object.class;
            return;
        }
        Objects.requireNonNull(typeArr[0]);
        d.c(typeArr[0]);
        this.f180p = null;
        this.o = d.a(typeArr[0]);
    }

    public final boolean equals(Object obj) {
        if ((obj instanceof WildcardType) && d.e(this, (WildcardType) obj)) {
            return true;
        }
        return false;
    }

    @Override // java.lang.reflect.WildcardType
    public final Type[] getLowerBounds() {
        Type type = this.f180p;
        if (type != null) {
            return new Type[]{type};
        }
        return d.f181a;
    }

    @Override // java.lang.reflect.WildcardType
    public final Type[] getUpperBounds() {
        return new Type[]{this.o};
    }

    public final int hashCode() {
        int i6;
        Type type = this.f180p;
        if (type != null) {
            i6 = type.hashCode() + 31;
        } else {
            i6 = 1;
        }
        return i6 ^ (this.o.hashCode() + 31);
    }

    public final String toString() {
        Type type = this.f180p;
        if (type != null) {
            return "? super " + d.l(type);
        }
        Type type2 = this.o;
        if (type2 == Object.class) {
            return "?";
        }
        return "? extends " + d.l(type2);
    }
}
