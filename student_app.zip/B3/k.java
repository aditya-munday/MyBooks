package B3;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* loaded from: classes.dex */
public abstract class k {

    /* renamed from: a, reason: collision with root package name */
    public static final int f192a;

    static {
        int i6;
        String property = System.getProperty("java.version");
        try {
            String[] split = property.split("[._]", 3);
            i6 = Integer.parseInt(split[0]);
            if (i6 == 1 && split.length > 1) {
                i6 = Integer.parseInt(split[1]);
            }
        } catch (NumberFormatException unused) {
            i6 = -1;
        }
        if (i6 == -1) {
            try {
                StringBuilder sb = new StringBuilder();
                for (int i7 = 0; i7 < property.length(); i7++) {
                    char charAt = property.charAt(i7);
                    if (!Character.isDigit(charAt)) {
                        break;
                    }
                    sb.append(charAt);
                }
                i6 = Integer.parseInt(sb.toString());
            } catch (NumberFormatException unused2) {
                i6 = -1;
            }
        }
        if (i6 == -1) {
            i6 = 6;
        }
        f192a = i6;
    }
}
