package B3;

import java.util.ConcurrentModificationException;
import java.util.Iterator;
import java.util.NoSuchElementException;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* loaded from: classes.dex */
public final class n implements Iterator {
    public p o;

    /* renamed from: p, reason: collision with root package name */
    public p f193p = null;

    /* renamed from: q, reason: collision with root package name */
    public int f194q;

    /* renamed from: r, reason: collision with root package name */
    public final /* synthetic */ q f195r;

    /* renamed from: s, reason: collision with root package name */
    public final /* synthetic */ int f196s;

    public n(q qVar, int i6) {
        this.f196s = i6;
        this.f195r = qVar;
        this.o = qVar.f211t.f200r;
        this.f194q = qVar.f210s;
    }

    public final Object a() {
        return b();
    }

    public final p b() {
        p pVar = this.o;
        q qVar = this.f195r;
        if (pVar != qVar.f211t) {
            if (qVar.f210s == this.f194q) {
                this.o = pVar.f200r;
                this.f193p = pVar;
                return pVar;
            }
            throw new ConcurrentModificationException();
        }
        throw new NoSuchElementException();
    }

    @Override // java.util.Iterator
    public final boolean hasNext() {
        if (this.o != this.f195r.f211t) {
            return true;
        }
        return false;
    }

    @Override // java.util.Iterator
    public Object next() {
        switch (this.f196s) {
            case 1:
                return b().f202t;
            default:
                return a();
        }
    }

    @Override // java.util.Iterator
    public final void remove() {
        p pVar = this.f193p;
        if (pVar != null) {
            q qVar = this.f195r;
            qVar.c(pVar, true);
            this.f193p = null;
            this.f194q = qVar.f210s;
            return;
        }
        throw new IllegalStateException();
    }
}
