package B3;

import java.lang.reflect.Method;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* loaded from: classes.dex */
public final class t extends w {

    /* renamed from: b, reason: collision with root package name */
    public final /* synthetic */ Method f216b;

    /* renamed from: c, reason: collision with root package name */
    public final /* synthetic */ int f217c;

    public t(int i6, Method method) {
        this.f216b = method;
        this.f217c = i6;
    }

    @Override // B3.w
    public final Object a(Class cls) {
        String i6 = A.c.i(cls);
        if (i6 == null) {
            return this.f216b.invoke(null, cls, Integer.valueOf(this.f217c));
        }
        throw new AssertionError("UnsafeAllocator is used for non-instantiable type: ".concat(i6));
    }
}
