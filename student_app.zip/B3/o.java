package B3;

import java.util.AbstractSet;
import java.util.Iterator;
import java.util.Map;
import java.util.Objects;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* loaded from: classes.dex */
public final class o extends AbstractSet {
    public final /* synthetic */ int o;

    /* renamed from: p, reason: collision with root package name */
    public final /* synthetic */ q f197p;

    public /* synthetic */ o(q qVar, int i6) {
        this.o = i6;
        this.f197p = qVar;
    }

    @Override // java.util.AbstractCollection, java.util.Collection, java.util.Set
    public final void clear() {
        switch (this.o) {
            case 0:
                this.f197p.clear();
                return;
            default:
                this.f197p.clear();
                return;
        }
    }

    /* JADX WARN: Removed duplicated region for block: B:16:0x0033 A[ORIG_RETURN, RETURN] */
    /* JADX WARN: Removed duplicated region for block: B:17:? A[RETURN, SYNTHETIC] */
    @Override // java.util.AbstractCollection, java.util.Collection, java.util.Set
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final boolean contains(Object obj) {
        p a6;
        switch (this.o) {
            case 0:
                if (!(obj instanceof Map.Entry)) {
                    return false;
                }
                q qVar = this.f197p;
                Map.Entry entry = (Map.Entry) obj;
                Object key = entry.getKey();
                p pVar = null;
                if (key != null) {
                    try {
                        a6 = qVar.a(key, false);
                    } catch (ClassCastException unused) {
                    }
                    if (a6 != null && Objects.equals(a6.f204v, entry.getValue())) {
                        pVar = a6;
                    }
                    if (pVar != null) {
                        return false;
                    }
                    return true;
                }
                a6 = null;
                if (a6 != null) {
                    pVar = a6;
                }
                if (pVar != null) {
                }
            default:
                return this.f197p.containsKey(obj);
        }
    }

    @Override // java.util.AbstractCollection, java.util.Collection, java.lang.Iterable, java.util.Set
    public final Iterator iterator() {
        switch (this.o) {
            case 0:
                return new n(this.f197p, 0);
            default:
                return new n(this.f197p, 1);
        }
    }

    /* JADX WARN: Removed duplicated region for block: B:27:0x0042  */
    /* JADX WARN: Removed duplicated region for block: B:29:? A[RETURN, SYNTHETIC] */
    @Override // java.util.AbstractCollection, java.util.Collection, java.util.Set
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final boolean remove(Object obj) {
        p a6;
        switch (this.o) {
            case 0:
                if (!(obj instanceof Map.Entry)) {
                    return false;
                }
                Map.Entry entry = (Map.Entry) obj;
                Object key = entry.getKey();
                q qVar = this.f197p;
                p pVar = null;
                if (key != null) {
                    try {
                        a6 = qVar.a(key, false);
                    } catch (ClassCastException unused) {
                    }
                    if (a6 != null && Objects.equals(a6.f204v, entry.getValue())) {
                        pVar = a6;
                    }
                    if (pVar != null) {
                        return false;
                    }
                    qVar.c(pVar, true);
                    return true;
                }
                a6 = null;
                if (a6 != null) {
                    pVar = a6;
                }
                if (pVar != null) {
                }
            default:
                q qVar2 = this.f197p;
                p pVar2 = null;
                if (obj != null) {
                    try {
                        pVar2 = qVar2.a(obj, false);
                    } catch (ClassCastException unused2) {
                    }
                }
                if (pVar2 != null) {
                    qVar2.c(pVar2, true);
                }
                if (pVar2 == null) {
                    return false;
                }
                return true;
        }
    }

    @Override // java.util.AbstractCollection, java.util.Collection, java.util.Set
    public final int size() {
        switch (this.o) {
            case 0:
                return this.f197p.f209r;
            default:
                return this.f197p.f209r;
        }
    }
}
