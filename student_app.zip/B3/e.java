package B3;

import com.google.firebase.messaging.FirebaseMessaging;
import v3.C0837A;
import v3.x;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* loaded from: classes.dex */
public final /* synthetic */ class e implements r, C2.h {
    public final /* synthetic */ int o;

    /* renamed from: p, reason: collision with root package name */
    public final /* synthetic */ String f182p;

    public /* synthetic */ e(String str, int i6) {
        this.o = i6;
        this.f182p = str;
    }

    @Override // C2.h
    public C2.r a(Object obj) {
        int i6 = this.o;
        String str = this.f182p;
        C0837A c0837a = (C0837A) obj;
        switch (i6) {
            case 2:
                T4.g gVar = FirebaseMessaging.f5808l;
                c0837a.getClass();
                C2.r d6 = c0837a.d(new x("S", str));
                c0837a.f();
                return d6;
            default:
                T4.g gVar2 = FirebaseMessaging.f5808l;
                c0837a.getClass();
                C2.r d7 = c0837a.d(new x("U", str));
                c0837a.f();
                return d7;
        }
    }

    @Override // B3.r
    public Object d() {
        switch (this.o) {
            case 0:
                throw new RuntimeException(this.f182p);
            default:
                throw new RuntimeException(this.f182p);
        }
    }
}
