package B3;

import java.io.Serializable;
import java.lang.reflect.GenericArrayType;
import java.lang.reflect.Type;
import java.util.Objects;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* loaded from: classes.dex */
public final class a implements GenericArrayType, Serializable {
    public final Type o;

    public a(Type type) {
        Objects.requireNonNull(type);
        this.o = d.a(type);
    }

    public final boolean equals(Object obj) {
        if ((obj instanceof GenericArrayType) && d.e(this, (GenericArrayType) obj)) {
            return true;
        }
        return false;
    }

    @Override // java.lang.reflect.GenericArrayType
    public final Type getGenericComponentType() {
        return this.o;
    }

    public final int hashCode() {
        return this.o.hashCode();
    }

    public final String toString() {
        return d.l(this.o) + "[]";
    }
}
