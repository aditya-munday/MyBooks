package B3;

import java.lang.reflect.Method;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* loaded from: classes.dex */
public final class u extends w {

    /* renamed from: b, reason: collision with root package name */
    public final /* synthetic */ Method f218b;

    public u(Method method) {
        this.f218b = method;
    }

    @Override // B3.w
    public final Object a(Class cls) {
        String i6 = A.c.i(cls);
        if (i6 == null) {
            return this.f218b.invoke(null, cls, Object.class);
        }
        throw new AssertionError("UnsafeAllocator is used for non-instantiable type: ".concat(i6));
    }
}
