package B3;

import java.lang.reflect.Method;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* loaded from: classes.dex */
public final class s extends w {

    /* renamed from: b, reason: collision with root package name */
    public final /* synthetic */ Method f214b;

    /* renamed from: c, reason: collision with root package name */
    public final /* synthetic */ Object f215c;

    public s(Method method, Object obj) {
        this.f214b = method;
        this.f215c = obj;
    }

    @Override // B3.w
    public final Object a(Class cls) {
        String i6 = A.c.i(cls);
        if (i6 == null) {
            return this.f214b.invoke(this.f215c, cls);
        }
        throw new AssertionError("UnsafeAllocator is used for non-instantiable type: ".concat(i6));
    }
}
