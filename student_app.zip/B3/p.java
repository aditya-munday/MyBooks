package B3;

import java.util.Map;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* loaded from: classes.dex */
public final class p implements Map.Entry {
    public p o;

    /* renamed from: p, reason: collision with root package name */
    public p f198p;

    /* renamed from: q, reason: collision with root package name */
    public p f199q;

    /* renamed from: r, reason: collision with root package name */
    public p f200r;

    /* renamed from: s, reason: collision with root package name */
    public p f201s;

    /* renamed from: t, reason: collision with root package name */
    public final Object f202t;

    /* renamed from: u, reason: collision with root package name */
    public final boolean f203u;

    /* renamed from: v, reason: collision with root package name */
    public Object f204v;

    /* renamed from: w, reason: collision with root package name */
    public int f205w;

    public p(boolean z6) {
        this.f202t = null;
        this.f203u = z6;
        this.f201s = this;
        this.f200r = this;
    }

    @Override // java.util.Map.Entry
    public final boolean equals(Object obj) {
        if (obj instanceof Map.Entry) {
            Map.Entry entry = (Map.Entry) obj;
            Object obj2 = this.f202t;
            if (obj2 != null ? obj2.equals(entry.getKey()) : entry.getKey() == null) {
                Object obj3 = this.f204v;
                if (obj3 == null) {
                    if (entry.getValue() == null) {
                        return true;
                    }
                } else if (obj3.equals(entry.getValue())) {
                    return true;
                }
            }
        }
        return false;
    }

    @Override // java.util.Map.Entry
    public final Object getKey() {
        return this.f202t;
    }

    @Override // java.util.Map.Entry
    public final Object getValue() {
        return this.f204v;
    }

    @Override // java.util.Map.Entry
    public final int hashCode() {
        int hashCode;
        int i6 = 0;
        Object obj = this.f202t;
        if (obj == null) {
            hashCode = 0;
        } else {
            hashCode = obj.hashCode();
        }
        Object obj2 = this.f204v;
        if (obj2 != null) {
            i6 = obj2.hashCode();
        }
        return i6 ^ hashCode;
    }

    @Override // java.util.Map.Entry
    public final Object setValue(Object obj) {
        if (obj == null && !this.f203u) {
            throw new NullPointerException("value == null");
        }
        Object obj2 = this.f204v;
        this.f204v = obj;
        return obj2;
    }

    public final String toString() {
        return this.f202t + "=" + this.f204v;
    }

    public p(boolean z6, p pVar, Object obj, p pVar2, p pVar3) {
        this.o = pVar;
        this.f202t = obj;
        this.f203u = z6;
        this.f205w = 1;
        this.f200r = pVar2;
        this.f201s = pVar3;
        pVar3.f200r = this;
        pVar2.f201s = this;
    }
}
