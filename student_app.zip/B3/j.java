package B3;

import java.lang.reflect.Modifier;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import z3.C0931d;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* loaded from: classes.dex */
public final class j implements z3.s, Cloneable {

    /* renamed from: q, reason: collision with root package name */
    public static final j f190q = new j();
    public final List o;

    /* renamed from: p, reason: collision with root package name */
    public final List f191p;

    public j() {
        List list = Collections.EMPTY_LIST;
        this.o = list;
        this.f191p = list;
    }

    public final boolean a(Class cls, boolean z6) {
        List list;
        if (!z6 && !Enum.class.isAssignableFrom(cls)) {
            android.support.v4.media.session.a aVar = E3.c.f799a;
            if (!Modifier.isStatic(cls.getModifiers()) && (cls.isAnonymousClass() || cls.isLocalClass())) {
                return true;
            }
        }
        if (z6) {
            list = this.o;
        } else {
            list = this.f191p;
        }
        Iterator it = list.iterator();
        if (!it.hasNext()) {
            return false;
        }
        it.next().getClass();
        throw new ClassCastException();
    }

    public final Object clone() {
        try {
            return (j) super.clone();
        } catch (CloneNotSupportedException e) {
            throw new AssertionError(e);
        }
    }

    @Override // z3.s
    public final z3.r create(C0931d c0931d, G3.a aVar) {
        Class cls = aVar.f965a;
        boolean a6 = a(cls, true);
        boolean a7 = a(cls, false);
        if (!a6 && !a7) {
            return null;
        }
        return new i(this, a7, a6, c0931d, aVar);
    }
}
