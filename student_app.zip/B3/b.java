package B3;

import java.io.Serializable;
import java.lang.reflect.Modifier;
import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;
import java.util.Arrays;
import java.util.Objects;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* loaded from: classes.dex */
public final class b implements ParameterizedType, Serializable {
    public final Type o;

    /* renamed from: p, reason: collision with root package name */
    public final Type f178p;

    /* renamed from: q, reason: collision with root package name */
    public final Type[] f179q;

    public b(Type type, Class cls, Type... typeArr) {
        Type a6;
        Objects.requireNonNull(cls);
        if (type == null && !Modifier.isStatic(cls.getModifiers()) && cls.getDeclaringClass() != null) {
            throw new IllegalArgumentException("Must specify owner type for " + cls);
        }
        if (type == null) {
            a6 = null;
        } else {
            a6 = d.a(type);
        }
        this.o = a6;
        this.f178p = d.a(cls);
        Type[] typeArr2 = (Type[]) typeArr.clone();
        this.f179q = typeArr2;
        int length = typeArr2.length;
        for (int i6 = 0; i6 < length; i6++) {
            Objects.requireNonNull(this.f179q[i6]);
            d.c(this.f179q[i6]);
            Type[] typeArr3 = this.f179q;
            typeArr3[i6] = d.a(typeArr3[i6]);
        }
    }

    public final boolean equals(Object obj) {
        if ((obj instanceof ParameterizedType) && d.e(this, (ParameterizedType) obj)) {
            return true;
        }
        return false;
    }

    @Override // java.lang.reflect.ParameterizedType
    public final Type[] getActualTypeArguments() {
        return (Type[]) this.f179q.clone();
    }

    @Override // java.lang.reflect.ParameterizedType
    public final Type getOwnerType() {
        return this.o;
    }

    @Override // java.lang.reflect.ParameterizedType
    public final Type getRawType() {
        return this.f178p;
    }

    public final int hashCode() {
        int i6;
        int hashCode = Arrays.hashCode(this.f179q) ^ this.f178p.hashCode();
        Type type = this.o;
        if (type != null) {
            i6 = type.hashCode();
        } else {
            i6 = 0;
        }
        return hashCode ^ i6;
    }

    public final String toString() {
        Type[] typeArr = this.f179q;
        int length = typeArr.length;
        Type type = this.f178p;
        if (length == 0) {
            return d.l(type);
        }
        StringBuilder sb = new StringBuilder((length + 1) * 30);
        sb.append(d.l(type));
        sb.append("<");
        sb.append(d.l(typeArr[0]));
        for (int i6 = 1; i6 < length; i6++) {
            sb.append(", ");
            sb.append(d.l(typeArr[i6]));
        }
        sb.append(">");
        return sb.toString();
    }
}
