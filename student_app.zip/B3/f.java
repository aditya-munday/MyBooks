package B3;

import android.graphics.ColorSpace;
import android.view.WindowInsets;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.TreeMap;
import java.util.TreeSet;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentSkipListMap;
import org.apache.tika.fork.ContentHandlerProxy;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* loaded from: classes.dex */
public final /* synthetic */ class f implements r, x0.r {
    public final /* synthetic */ int o;

    public /* synthetic */ f(int i6) {
        this.o = i6;
    }

    public static /* bridge */ /* synthetic */ ColorSpace.Named a() {
        return ColorSpace.Named.SRGB;
    }

    public static /* bridge */ /* synthetic */ WindowInsets b() {
        return WindowInsets.CONSUMED;
    }

    @Override // x0.r
    public x0.o[] c() {
        switch (this.o) {
            case ContentHandlerProxy.PROCESSING_INSTRUCTION /* 9 */:
                return new x0.o[]{new C0.c()};
            default:
                return new x0.o[]{new D0.b()};
        }
    }

    @Override // B3.r
    public Object d() {
        switch (this.o) {
            case 0:
                return new q(true);
            case 1:
                return new TreeSet();
            case 2:
                return new LinkedHashSet();
            case 3:
                return new ArrayDeque();
            case 4:
                return new ArrayList();
            case 5:
                return new ConcurrentSkipListMap();
            case 6:
                return new ConcurrentHashMap();
            case 7:
                return new TreeMap();
            default:
                return new LinkedHashMap();
        }
    }
}
