package B3;

import z3.C0931d;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* loaded from: classes.dex */
public final class i extends z3.r {

    /* renamed from: a, reason: collision with root package name */
    public volatile z3.r f185a;

    /* renamed from: b, reason: collision with root package name */
    public final /* synthetic */ boolean f186b;

    /* renamed from: c, reason: collision with root package name */
    public final /* synthetic */ boolean f187c;

    /* renamed from: d, reason: collision with root package name */
    public final /* synthetic */ C0931d f188d;
    public final /* synthetic */ G3.a e;

    /* renamed from: f, reason: collision with root package name */
    public final /* synthetic */ j f189f;

    public i(j jVar, boolean z6, boolean z7, C0931d c0931d, G3.a aVar) {
        this.f189f = jVar;
        this.f186b = z6;
        this.f187c = z7;
        this.f188d = c0931d;
        this.e = aVar;
    }

    @Override // z3.r
    public final Object b(H3.a aVar) {
        if (this.f186b) {
            aVar.D();
            return null;
        }
        z3.r rVar = this.f185a;
        if (rVar == null) {
            rVar = this.f188d.d(this.f189f, this.e);
            this.f185a = rVar;
        }
        return rVar.b(aVar);
    }

    @Override // z3.r
    public final void c(H3.b bVar, Object obj) {
        if (this.f187c) {
            bVar.i();
            return;
        }
        z3.r rVar = this.f185a;
        if (rVar == null) {
            rVar = this.f188d.d(this.f189f, this.e);
            this.f185a = rVar;
        }
        rVar.c(bVar, obj);
    }
}
