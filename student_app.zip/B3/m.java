package B3;

import androidx.recyclerview.widget.RecyclerView;
import java.util.Comparator;
import k1.C0542g;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* loaded from: classes.dex */
public final class m implements Comparator {
    public final /* synthetic */ int o;

    public /* synthetic */ m(int i6) {
        this.o = i6;
    }

    /* JADX WARN: Code restructure failed: missing block: B:10:0x001b, code lost:
    
        if (r0 == null) goto L19;
     */
    /* JADX WARN: Code restructure failed: missing block: B:11:0x0026, code lost:
    
        return -1;
     */
    /* JADX WARN: Code restructure failed: missing block: B:14:?, code lost:
    
        return 1;
     */
    /* JADX WARN: Code restructure failed: missing block: B:17:0x0024, code lost:
    
        if (r0 != false) goto L18;
     */
    @Override // java.util.Comparator
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final int compare(Object obj, Object obj2) {
        boolean z6;
        boolean z7;
        switch (this.o) {
            case 0:
                return ((Comparable) obj).compareTo((Comparable) obj2);
            case 1:
                int i6 = ((O1.b) obj).e;
                int i7 = ((O1.b) obj2).e;
                if (i6 == i7) {
                    return 0;
                }
                if (i6 > i7) {
                    return 1;
                }
                return -1;
            default:
                C0542g c0542g = (C0542g) obj;
                C0542g c0542g2 = (C0542g) obj2;
                RecyclerView recyclerView = c0542g.f7941d;
                if (recyclerView == null) {
                    z6 = true;
                } else {
                    z6 = false;
                }
                if (c0542g2.f7941d == null) {
                    z7 = true;
                } else {
                    z7 = false;
                }
                if (z6 == z7) {
                    boolean z8 = c0542g.f7938a;
                    if (z8 == c0542g2.f7938a) {
                        int i8 = c0542g2.f7939b - c0542g.f7939b;
                        if (i8 != 0) {
                            return i8;
                        }
                        int i9 = c0542g.f7940c - c0542g2.f7940c;
                        if (i9 == 0) {
                            return 0;
                        }
                        return i9;
                    }
                }
                break;
        }
    }
}
