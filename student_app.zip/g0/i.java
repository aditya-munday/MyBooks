package g0;

import E2.G;
import E2.I;
import E2.Z;
import S.C0120m;
import java.util.List;
import org.apache.tika.utils.StringUtils;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* loaded from: classes.dex */
public final class i extends j {

    /* renamed from: A, reason: collision with root package name */
    public final I f6670A;

    /* renamed from: z, reason: collision with root package name */
    public final String f6671z;

    /* JADX WARN: 'this' call moved to the top of the method (can break code semantics) */
    public i(String str, long j6, long j7, String str2, String str3) {
        this(str, null, StringUtils.EMPTY, 0L, -1, -9223372036854775807L, null, str2, str3, j6, j7, false, Z.f721s);
        G g2 = I.f699p;
    }

    public i(String str, i iVar, String str2, long j6, int i6, long j7, C0120m c0120m, String str3, String str4, long j8, long j9, boolean z6, List list) {
        super(str, iVar, j6, i6, j7, c0120m, str3, str4, j8, j9, z6);
        this.f6671z = str2;
        this.f6670A = I.u(list);
    }
}
