package g0;

import E2.I;
import S.G;
import V.AbstractC0133a;
import V.C;
import X.u;
import android.net.Uri;
import android.os.SystemClock;
import c5.C0351o;
import java.io.IOException;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CopyOnWriteArrayList;
import p0.C0700s;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* loaded from: classes.dex */
public final class b implements t0.j {
    public final Uri o;

    /* renamed from: p, reason: collision with root package name */
    public final t0.o f6608p = new t0.o("DefaultHlsPlaylistTracker:MediaPlaylist");

    /* renamed from: q, reason: collision with root package name */
    public final X.h f6609q;

    /* renamed from: r, reason: collision with root package name */
    public l f6610r;

    /* renamed from: s, reason: collision with root package name */
    public long f6611s;

    /* renamed from: t, reason: collision with root package name */
    public long f6612t;

    /* renamed from: u, reason: collision with root package name */
    public long f6613u;

    /* renamed from: v, reason: collision with root package name */
    public long f6614v;

    /* renamed from: w, reason: collision with root package name */
    public boolean f6615w;

    /* renamed from: x, reason: collision with root package name */
    public IOException f6616x;
    public boolean y;

    /* renamed from: z, reason: collision with root package name */
    public final /* synthetic */ c f6617z;

    public b(c cVar, Uri uri) {
        this.f6617z = cVar;
        this.o = uri;
        this.f6609q = ((X.g) cVar.o.o).b();
    }

    public static boolean a(b bVar, long j6) {
        bVar.f6614v = SystemClock.elapsedRealtime() + j6;
        Uri uri = bVar.o;
        c cVar = bVar.f6617z;
        if (!uri.equals(cVar.y)) {
            return false;
        }
        List list = cVar.f6629x.e;
        int size = list.size();
        long elapsedRealtime = SystemClock.elapsedRealtime();
        for (int i6 = 0; i6 < size; i6++) {
            b bVar2 = (b) cVar.f6623r.get(((n) list.get(i6)).f6706a);
            bVar2.getClass();
            if (elapsedRealtime > bVar2.f6614v) {
                Uri uri2 = bVar2.o;
                cVar.y = uri2;
                bVar2.e(cVar.b(uri2));
                return false;
            }
        }
        return true;
    }

    public final Uri b() {
        String str;
        l lVar = this.f6610r;
        Uri uri = this.o;
        if (lVar != null) {
            k kVar = lVar.f6701v;
            if (kVar.f6681a != -9223372036854775807L || kVar.e) {
                Uri.Builder buildUpon = uri.buildUpon();
                l lVar2 = this.f6610r;
                if (lVar2.f6701v.e) {
                    buildUpon.appendQueryParameter("_HLS_msn", String.valueOf(lVar2.f6691k + lVar2.f6697r.size()));
                    l lVar3 = this.f6610r;
                    if (lVar3.f6694n != -9223372036854775807L) {
                        I i6 = lVar3.f6698s;
                        int size = i6.size();
                        if (!i6.isEmpty() && ((g) E2.r.j(i6)).f6665A) {
                            size--;
                        }
                        buildUpon.appendQueryParameter("_HLS_part", String.valueOf(size));
                    }
                }
                k kVar2 = this.f6610r.f6701v;
                if (kVar2.f6681a != -9223372036854775807L) {
                    if (kVar2.f6682b) {
                        str = "v2";
                    } else {
                        str = "YES";
                    }
                    buildUpon.appendQueryParameter("_HLS_skip", str);
                }
                return buildUpon.build();
            }
        }
        return uri;
    }

    public final void c(boolean z6) {
        Uri uri;
        if (z6) {
            uri = b();
        } else {
            uri = this.o;
        }
        e(uri);
    }

    public final void d(Uri uri) {
        c cVar = this.f6617z;
        t0.q n6 = cVar.f6621p.n(cVar.f6629x, this.f6610r);
        Map map = Collections.EMPTY_MAP;
        AbstractC0133a.k(uri, "The uri must be set.");
        t0.r rVar = new t0.r(this.f6609q, new X.k(uri, 1, null, map, 0L, -1L, null, 1), 4, n6);
        this.f6608p.f(rVar, this, cVar.f6622q.p(rVar.f9670q));
    }

    public final void e(Uri uri) {
        this.f6614v = 0L;
        if (!this.f6615w) {
            t0.o oVar = this.f6608p;
            if (!oVar.d() && !oVar.c()) {
                long elapsedRealtime = SystemClock.elapsedRealtime();
                long j6 = this.f6613u;
                if (elapsedRealtime < j6) {
                    this.f6615w = true;
                    this.f6617z.f6627v.postDelayed(new I3.b(this, uri, 24), j6 - elapsedRealtime);
                } else {
                    d(uri);
                }
            }
        }
    }

    @Override // t0.j
    public final void f(t0.l lVar, long j6, long j7) {
        t0.r rVar = (t0.r) lVar;
        p pVar = (p) rVar.f9673t;
        Uri uri = rVar.f9671r.f3622q;
        C0700s c0700s = new C0700s(j7);
        if (pVar instanceof l) {
            g((l) pVar, c0700s);
            this.f6617z.f6625t.d(c0700s, 4);
        } else {
            G b6 = G.b("Loaded playlist has unexpected type.", null);
            this.f6616x = b6;
            this.f6617z.f6625t.g(c0700s, 4, b6, true);
        }
        this.f6617z.f6622q.getClass();
    }

    /* JADX WARN: Removed duplicated region for block: B:16:0x01b9  */
    /* JADX WARN: Removed duplicated region for block: B:29:0x0252  */
    /* JADX WARN: Removed duplicated region for block: B:33:0x027e  */
    /* JADX WARN: Removed duplicated region for block: B:41:? A[RETURN, SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:43:0x0259  */
    /* JADX WARN: Removed duplicated region for block: B:48:0x01ee  */
    /* JADX WARN: Removed duplicated region for block: B:67:0x00d0  */
    /* JADX WARN: Removed duplicated region for block: B:73:0x011d  */
    /* JADX WARN: Removed duplicated region for block: B:75:0x0125  */
    /* JADX WARN: Removed duplicated region for block: B:9:0x0057  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final void g(l lVar, C0700s c0700s) {
        boolean z6;
        CopyOnWriteArrayList copyOnWriteArrayList;
        boolean z7;
        long j6;
        long j7;
        i iVar;
        long j8;
        int i6;
        i iVar2;
        int i7;
        I i8;
        l lVar2;
        IOException iOException;
        long j9;
        IOException iOException2;
        boolean z8;
        k kVar;
        int size;
        int size2;
        int size3;
        l lVar3 = this.f6610r;
        long elapsedRealtime = SystemClock.elapsedRealtime();
        this.f6611s = elapsedRealtime;
        c cVar = this.f6617z;
        CopyOnWriteArrayList copyOnWriteArrayList2 = cVar.f6624s;
        if (lVar3 != null) {
            long j10 = lVar.f6691k;
            long j11 = lVar3.f6691k;
            if (j10 <= j11 && (j10 < j11 || ((size = lVar.f6697r.size() - lVar3.f6697r.size()) == 0 ? !((size2 = lVar.f6698s.size()) > (size3 = lVar3.f6698s.size()) || (size2 == size3 && lVar.o && !lVar3.o)) : size <= 0))) {
                z6 = false;
                I i9 = lVar.f6697r;
                long j12 = lVar.f6691k;
                long j13 = 0;
                if (z6) {
                    if (lVar.o) {
                        if (lVar3.o) {
                            lVar2 = lVar3;
                            copyOnWriteArrayList = copyOnWriteArrayList2;
                            j9 = j12;
                            iOException = null;
                            z7 = true;
                        } else {
                            z7 = true;
                            copyOnWriteArrayList = copyOnWriteArrayList2;
                            j9 = j12;
                            lVar2 = new l(lVar3.f6685d, lVar3.f6719a, lVar3.f6720b, lVar3.e, lVar3.f6687g, lVar3.f6688h, lVar3.f6689i, lVar3.f6690j, lVar3.f6691k, lVar3.f6692l, lVar3.f6693m, lVar3.f6694n, lVar3.f6721c, true, lVar3.f6695p, lVar3.f6696q, lVar3.f6697r, lVar3.f6698s, lVar3.f6701v, lVar3.f6699t, lVar3.f6702w);
                        }
                    } else {
                        copyOnWriteArrayList = copyOnWriteArrayList2;
                        z7 = true;
                        lVar2 = lVar3;
                        j9 = j12;
                    }
                    iOException = null;
                } else {
                    copyOnWriteArrayList = copyOnWriteArrayList2;
                    z7 = true;
                    if (lVar.f6695p) {
                        j6 = lVar.f6688h;
                    } else {
                        l lVar4 = cVar.f6630z;
                        if (lVar4 != null) {
                            j6 = lVar4.f6688h;
                        } else {
                            j6 = 0;
                        }
                        if (lVar3 != null) {
                            long j14 = lVar3.f6688h;
                            long j15 = lVar3.f6691k;
                            I i10 = lVar3.f6697r;
                            j7 = j6;
                            int size4 = i10.size();
                            int i11 = (int) (j12 - j15);
                            if (i11 < i10.size()) {
                                iVar = (i) i10.get(i11);
                            } else {
                                iVar = null;
                            }
                            if (iVar != null) {
                                j8 = iVar.f6675s;
                            } else {
                                if (size4 == j12 - j15) {
                                    j8 = lVar3.f6700u;
                                }
                                if (!lVar.f6689i) {
                                    i7 = lVar.f6690j;
                                    i8 = i9;
                                } else {
                                    l lVar5 = cVar.f6630z;
                                    if (lVar5 != null) {
                                        i6 = lVar5.f6690j;
                                    } else {
                                        i6 = 0;
                                    }
                                    if (lVar3 != null) {
                                        int i12 = (int) (j12 - lVar3.f6691k);
                                        I i13 = lVar3.f6697r;
                                        if (i12 < i13.size()) {
                                            iVar2 = (i) i13.get(i12);
                                        } else {
                                            iVar2 = null;
                                        }
                                        if (iVar2 != null) {
                                            i6 = (lVar3.f6690j + iVar2.f6674r) - ((i) i9.get(0)).f6674r;
                                            i7 = i6;
                                            i8 = i9;
                                        }
                                    }
                                    i7 = i6;
                                    i8 = i9;
                                }
                                iOException = null;
                                j9 = j12;
                                lVar2 = new l(lVar.f6685d, lVar.f6719a, lVar.f6720b, lVar.e, lVar.f6687g, j7, true, i7, lVar.f6691k, lVar.f6692l, lVar.f6693m, lVar.f6694n, lVar.f6721c, lVar.o, lVar.f6695p, lVar.f6696q, i8, lVar.f6698s, lVar.f6701v, lVar.f6699t, lVar.f6702w);
                            }
                            j6 = j14 + j8;
                        }
                    }
                    j7 = j6;
                    if (!lVar.f6689i) {
                    }
                    iOException = null;
                    j9 = j12;
                    lVar2 = new l(lVar.f6685d, lVar.f6719a, lVar.f6720b, lVar.e, lVar.f6687g, j7, true, i7, lVar.f6691k, lVar.f6692l, lVar.f6693m, lVar.f6694n, lVar.f6721c, lVar.o, lVar.f6695p, lVar.f6696q, i8, lVar.f6698s, lVar.f6701v, lVar.f6699t, lVar.f6702w);
                }
                this.f6610r = lVar2;
                Uri uri = this.o;
                if (lVar2 == lVar3) {
                    this.f6616x = iOException;
                    this.f6612t = elapsedRealtime;
                    if (uri.equals(cVar.y)) {
                        if (cVar.f6630z == null) {
                            cVar.f6619A = !lVar2.o;
                            cVar.f6620B = lVar2.f6688h;
                        }
                        cVar.f6630z = lVar2;
                        cVar.f6628w.y(lVar2);
                    }
                    Iterator it = copyOnWriteArrayList.iterator();
                    while (it.hasNext()) {
                        ((t) it.next()).a();
                    }
                } else if (!lVar2.o) {
                    if (j9 + lVar.f6697r.size() < this.f6610r.f6691k) {
                        iOException2 = new IOException();
                        z8 = z7;
                    } else {
                        if (elapsedRealtime - this.f6612t > C.Z(r1.f6693m) * 3.5d) {
                            iOException2 = new IOException();
                        } else {
                            iOException2 = iOException;
                        }
                        z8 = false;
                    }
                    if (iOException2 != null) {
                        this.f6616x = iOException2;
                        C.b bVar = new C.b(iOException2, z7 ? 1 : 0);
                        Iterator it2 = copyOnWriteArrayList.iterator();
                        while (it2.hasNext()) {
                            ((t) it2.next()).f(uri, bVar, z8);
                        }
                    }
                }
                l lVar6 = this.f6610r;
                kVar = lVar6.f6701v;
                long j16 = lVar6.f6693m;
                if (kVar.e) {
                    if (lVar6 == lVar3) {
                        j16 /= 2;
                    }
                } else {
                    if (lVar6 == lVar3) {
                        long j17 = lVar6.f6694n;
                        if (j17 != -9223372036854775807L) {
                            j13 = j17 / 2;
                        } else {
                            j16 /= 2;
                        }
                    }
                    this.f6613u = (C.Z(j13) + elapsedRealtime) - c0700s.f9121a;
                    if (!this.f6610r.o) {
                        if (uri.equals(cVar.y) || this.y) {
                            e(b());
                            return;
                        }
                        return;
                    }
                    return;
                }
                j13 = j16;
                this.f6613u = (C.Z(j13) + elapsedRealtime) - c0700s.f9121a;
                if (!this.f6610r.o) {
                }
            }
        } else {
            lVar.getClass();
        }
        z6 = true;
        I i92 = lVar.f6697r;
        long j122 = lVar.f6691k;
        long j132 = 0;
        if (z6) {
        }
        this.f6610r = lVar2;
        Uri uri2 = this.o;
        if (lVar2 == lVar3) {
        }
        l lVar62 = this.f6610r;
        kVar = lVar62.f6701v;
        long j162 = lVar62.f6693m;
        if (kVar.e) {
        }
        j132 = j162;
        this.f6613u = (C.Z(j132) + elapsedRealtime) - c0700s.f9121a;
        if (!this.f6610r.o) {
        }
    }

    @Override // t0.j
    public final void i(t0.l lVar, long j6, long j7, boolean z6) {
        t0.r rVar = (t0.r) lVar;
        long j8 = rVar.o;
        Uri uri = rVar.f9671r.f3622q;
        C0700s c0700s = new C0700s(j7);
        c cVar = this.f6617z;
        cVar.f6622q.getClass();
        cVar.f6625t.c(c0700s, 4, -1, null, 0, null, -9223372036854775807L, -9223372036854775807L);
    }

    @Override // t0.j
    public final void j(t0.l lVar, long j6, long j7, int i6) {
        C0700s c0700s;
        t0.r rVar = (t0.r) lVar;
        if (i6 == 0) {
            long j8 = rVar.o;
            c0700s = new C0700s(rVar.f9669p);
        } else {
            long j9 = rVar.o;
            Uri uri = rVar.f9671r.f3622q;
            c0700s = new C0700s(j7);
        }
        this.f6617z.f6625t.h(c0700s, rVar.f9670q, -1, null, 0, null, -9223372036854775807L, -9223372036854775807L, i6);
    }

    @Override // t0.j
    public final f1.f r(t0.l lVar, long j6, long j7, IOException iOException, int i6) {
        boolean z6;
        int i7;
        f1.f fVar;
        t0.r rVar = (t0.r) lVar;
        long j8 = rVar.o;
        int i8 = rVar.f9670q;
        Uri uri = rVar.f9671r.f3622q;
        C0700s c0700s = new C0700s(j7);
        if (uri.getQueryParameter("_HLS_msn") != null) {
            z6 = true;
        } else {
            z6 = false;
        }
        boolean z7 = iOException instanceof q;
        f1.f fVar2 = t0.o.f9665s;
        c cVar = this.f6617z;
        if (z6 || z7) {
            if (iOException instanceof u) {
                i7 = ((u) iOException).f3612r;
            } else {
                i7 = Integer.MAX_VALUE;
            }
            if (z7 || i7 == 400 || i7 == 503) {
                this.f6613u = SystemClock.elapsedRealtime();
                c(false);
                e0.e eVar = cVar.f6625t;
                String str = C.f3053a;
                eVar.g(c0700s, i8, iOException, true);
                return fVar2;
            }
        }
        C.b bVar = new C.b(iOException, i6);
        Iterator it = cVar.f6624s.iterator();
        boolean z8 = false;
        while (it.hasNext()) {
            z8 |= !((t) it.next()).f(this.o, bVar, false);
        }
        C0351o c0351o = cVar.f6622q;
        if (z8) {
            c0351o.getClass();
            long q6 = C0351o.q(bVar);
            if (q6 != -9223372036854775807L) {
                fVar = new f1.f(0, q6, false);
            } else {
                fVar = t0.o.f9666t;
            }
            fVar2 = fVar;
        }
        boolean a6 = fVar2.a();
        cVar.f6625t.g(c0700s, i8, iOException, !a6);
        if (!a6) {
            c0351o.getClass();
        }
        return fVar2;
    }
}
