package g0;

import android.net.Uri;
import java.util.ArrayList;
import java.util.HashMap;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* loaded from: classes.dex */
public final class e {

    /* renamed from: a, reason: collision with root package name */
    public final String f6635a;

    /* renamed from: c, reason: collision with root package name */
    public Uri f6637c;

    /* renamed from: d, reason: collision with root package name */
    public Uri f6638d;

    /* renamed from: j, reason: collision with root package name */
    public boolean f6643j;
    public Boolean o;

    /* renamed from: p, reason: collision with root package name */
    public String f6648p;

    /* renamed from: q, reason: collision with root package name */
    public String f6649q;

    /* renamed from: b, reason: collision with root package name */
    public final HashMap f6636b = new HashMap();
    public long e = -9223372036854775807L;

    /* renamed from: f, reason: collision with root package name */
    public long f6639f = -9223372036854775807L;

    /* renamed from: g, reason: collision with root package name */
    public long f6640g = -9223372036854775807L;

    /* renamed from: h, reason: collision with root package name */
    public long f6641h = -9223372036854775807L;

    /* renamed from: i, reason: collision with root package name */
    public ArrayList f6642i = new ArrayList();

    /* renamed from: k, reason: collision with root package name */
    public long f6644k = -9223372036854775807L;

    /* renamed from: l, reason: collision with root package name */
    public long f6645l = -9223372036854775807L;

    /* renamed from: m, reason: collision with root package name */
    public ArrayList f6646m = new ArrayList();

    /* renamed from: n, reason: collision with root package name */
    public ArrayList f6647n = new ArrayList();

    public e(String str) {
        this.f6635a = str;
    }
}
