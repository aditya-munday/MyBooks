package g0;

import V.AbstractC0133a;
import java.util.Objects;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* loaded from: classes.dex */
public final class d {

    /* renamed from: a, reason: collision with root package name */
    public final String f6631a;

    /* renamed from: b, reason: collision with root package name */
    public final int f6632b;

    /* renamed from: c, reason: collision with root package name */
    public final double f6633c;

    /* renamed from: d, reason: collision with root package name */
    public final String f6634d;

    public d(String str, double d6) {
        this.f6631a = str;
        this.f6632b = 2;
        this.f6633c = d6;
        this.f6634d = null;
    }

    public final boolean equals(Object obj) {
        if (this != obj) {
            if (obj instanceof d) {
                d dVar = (d) obj;
                if (this.f6632b == dVar.f6632b && Double.compare(this.f6633c, dVar.f6633c) == 0 && Objects.equals(this.f6631a, dVar.f6631a) && Objects.equals(this.f6634d, dVar.f6634d)) {
                    return true;
                }
                return false;
            }
            return false;
        }
        return true;
    }

    public final int hashCode() {
        return Objects.hash(this.f6631a, Integer.valueOf(this.f6632b), Double.valueOf(this.f6633c), this.f6634d);
    }

    public d(String str, int i6, String str2) {
        boolean z6 = true;
        if (i6 == 1 && !str2.startsWith("0x") && !str2.startsWith("0X")) {
            z6 = false;
        }
        AbstractC0133a.i(z6);
        this.f6631a = str;
        this.f6632b = i6;
        this.f6634d = str2;
        this.f6633c = 0.0d;
    }
}
