package g0;

import S.C0122o;
import S.C0123p;
import S.F;
import S.G;
import V.C;
import android.net.Uri;
import android.os.Handler;
import android.os.SystemClock;
import c5.C0351o;
import f1.C0437a;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;
import org.apache.tika.pipes.pipesiterator.PipesIterator;
import org.apache.tika.utils.StringUtils;
import p0.C0700s;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* loaded from: classes.dex */
public final class c implements t0.j {

    /* renamed from: C, reason: collision with root package name */
    public static final C0437a f6618C = new C0437a(2);

    /* renamed from: A, reason: collision with root package name */
    public boolean f6619A;
    public final Z4.s o;

    /* renamed from: p, reason: collision with root package name */
    public final s f6621p;

    /* renamed from: q, reason: collision with root package name */
    public final C0351o f6622q;

    /* renamed from: t, reason: collision with root package name */
    public e0.e f6625t;

    /* renamed from: u, reason: collision with root package name */
    public t0.o f6626u;

    /* renamed from: v, reason: collision with root package name */
    public Handler f6627v;

    /* renamed from: w, reason: collision with root package name */
    public f0.l f6628w;

    /* renamed from: x, reason: collision with root package name */
    public o f6629x;
    public Uri y;

    /* renamed from: z, reason: collision with root package name */
    public l f6630z;

    /* renamed from: s, reason: collision with root package name */
    public final CopyOnWriteArrayList f6624s = new CopyOnWriteArrayList();

    /* renamed from: r, reason: collision with root package name */
    public final HashMap f6623r = new HashMap();

    /* renamed from: B, reason: collision with root package name */
    public long f6620B = -9223372036854775807L;

    public c(Z4.s sVar, C0351o c0351o, s sVar2) {
        this.o = sVar;
        this.f6621p = sVar2;
        this.f6622q = c0351o;
    }

    public final l a(boolean z6, Uri uri) {
        HashMap hashMap = this.f6623r;
        l lVar = ((b) hashMap.get(uri)).f6610r;
        if (lVar != null && z6) {
            if (!uri.equals(this.y)) {
                List list = this.f6629x.e;
                int i6 = 0;
                while (true) {
                    if (i6 >= list.size()) {
                        break;
                    }
                    if (uri.equals(((n) list.get(i6)).f6706a)) {
                        l lVar2 = this.f6630z;
                        if (lVar2 == null || !lVar2.o) {
                            this.y = uri;
                            b bVar = (b) hashMap.get(uri);
                            l lVar3 = bVar.f6610r;
                            if (lVar3 != null && lVar3.o) {
                                this.f6630z = lVar3;
                                this.f6628w.y(lVar3);
                            } else {
                                bVar.e(b(uri));
                            }
                        }
                    } else {
                        i6++;
                    }
                }
            }
            b bVar2 = (b) hashMap.get(uri);
            l lVar4 = bVar2.f6610r;
            if (!bVar2.y) {
                bVar2.y = true;
                if (lVar4 != null && !lVar4.o) {
                    bVar2.c(true);
                }
            }
        }
        return lVar;
    }

    public final Uri b(Uri uri) {
        h hVar;
        l lVar = this.f6630z;
        if (lVar != null && lVar.f6701v.e && (hVar = (h) lVar.f6699t.get(uri)) != null) {
            Uri.Builder buildUpon = uri.buildUpon();
            buildUpon.appendQueryParameter("_HLS_msn", String.valueOf(hVar.f6668b));
            int i6 = hVar.f6669c;
            if (i6 != -1) {
                buildUpon.appendQueryParameter("_HLS_part", String.valueOf(i6));
            }
            return buildUpon.build();
        }
        return uri;
    }

    public final boolean c(Uri uri) {
        int i6;
        b bVar = (b) this.f6623r.get(uri);
        if (bVar.f6610r != null) {
            long elapsedRealtime = SystemClock.elapsedRealtime();
            long max = Math.max(30000L, C.Z(bVar.f6610r.f6700u));
            l lVar = bVar.f6610r;
            if (lVar.o || (i6 = lVar.f6685d) == 2 || i6 == 1 || bVar.f6611s + max > elapsedRealtime) {
                return true;
            }
            return false;
        }
        return false;
    }

    @Override // t0.j
    public final void f(t0.l lVar, long j6, long j7) {
        o oVar;
        t0.r rVar = (t0.r) lVar;
        p pVar = (p) rVar.f9673t;
        boolean z6 = pVar instanceof l;
        if (z6) {
            String str = pVar.f6719a;
            o oVar2 = o.f6711l;
            Uri parse = Uri.parse(str);
            C0122o c0122o = new C0122o();
            c0122o.f2576a = "0";
            c0122o.f2586l = F.n("application/x-mpegURL");
            List singletonList = Collections.singletonList(new n(parse, new C0123p(c0122o), null, null, null, null));
            List list = Collections.EMPTY_LIST;
            oVar = new o(StringUtils.EMPTY, list, singletonList, list, list, list, list, null, null, false, Collections.EMPTY_MAP, list);
        } else {
            oVar = (o) pVar;
        }
        this.f6629x = oVar;
        this.y = ((n) oVar.e.get(0)).f6706a;
        this.f6624s.add(new C0448a(this));
        List list2 = oVar.f6712d;
        int size = list2.size();
        for (int i6 = 0; i6 < size; i6++) {
            Uri uri = (Uri) list2.get(i6);
            this.f6623r.put(uri, new b(this, uri));
        }
        Uri uri2 = rVar.f9671r.f3622q;
        C0700s c0700s = new C0700s(j7);
        b bVar = (b) this.f6623r.get(this.y);
        if (z6) {
            bVar.g((l) pVar, c0700s);
        } else {
            bVar.c(false);
        }
        this.f6622q.getClass();
        this.f6625t.d(c0700s, 4);
    }

    @Override // t0.j
    public final void i(t0.l lVar, long j6, long j7, boolean z6) {
        t0.r rVar = (t0.r) lVar;
        long j8 = rVar.o;
        Uri uri = rVar.f9671r.f3622q;
        C0700s c0700s = new C0700s(j7);
        this.f6622q.getClass();
        this.f6625t.c(c0700s, 4, -1, null, 0, null, -9223372036854775807L, -9223372036854775807L);
    }

    @Override // t0.j
    public final void j(t0.l lVar, long j6, long j7, int i6) {
        C0700s c0700s;
        t0.r rVar = (t0.r) lVar;
        if (i6 == 0) {
            long j8 = rVar.o;
            c0700s = new C0700s(rVar.f9669p);
        } else {
            long j9 = rVar.o;
            Uri uri = rVar.f9671r.f3622q;
            c0700s = new C0700s(j7);
        }
        this.f6625t.h(c0700s, rVar.f9670q, -1, null, 0, null, -9223372036854775807L, -9223372036854775807L, i6);
    }

    /* JADX WARN: Removed duplicated region for block: B:23:0x0054  */
    /* JADX WARN: Removed duplicated region for block: B:26:0x005c  */
    /* JADX WARN: Removed duplicated region for block: B:29:0x005f  */
    @Override // t0.j
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final f1.f r(t0.l lVar, long j6, long j7, IOException iOException, int i6) {
        long j8;
        t0.r rVar = (t0.r) lVar;
        long j9 = rVar.o;
        Uri uri = rVar.f9671r.f3622q;
        C0700s c0700s = new C0700s(j7);
        int i7 = rVar.f9670q;
        this.f6622q.getClass();
        boolean z6 = true;
        if (!(iOException instanceof G) && !(iOException instanceof FileNotFoundException) && !(iOException instanceof X.r) && !(iOException instanceof t0.n)) {
            int i8 = X.i.f3573p;
            for (Throwable th = iOException; th != null; th = th.getCause()) {
                if (!(th instanceof X.i) || ((X.i) th).o != 2008) {
                }
            }
            j8 = Math.min((i6 - 1) * PipesIterator.DEFAULT_QUEUE_SIZE, 5000);
            if (j8 != -9223372036854775807L) {
                z6 = false;
            }
            this.f6625t.g(c0700s, i7, iOException, z6);
            if (!z6) {
                return t0.o.f9666t;
            }
            return new f1.f(0, j8, false);
        }
        j8 = -9223372036854775807L;
        if (j8 != -9223372036854775807L) {
        }
        this.f6625t.g(c0700s, i7, iOException, z6);
        if (!z6) {
        }
    }
}
