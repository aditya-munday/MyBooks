package g0;

import java.util.Collections;
import java.util.List;
import k0.InterfaceC0525a;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* loaded from: classes.dex */
public abstract class p implements InterfaceC0525a {

    /* renamed from: a, reason: collision with root package name */
    public final String f6719a;

    /* renamed from: b, reason: collision with root package name */
    public final List f6720b;

    /* renamed from: c, reason: collision with root package name */
    public final boolean f6721c;

    public p(String str, List list, boolean z6) {
        this.f6719a = str;
        this.f6720b = Collections.unmodifiableList(list);
        this.f6721c = z6;
    }
}
