package g0;

import V.C;
import android.net.Uri;
import android.os.SystemClock;
import c5.C0351o;
import java.util.HashMap;
import java.util.List;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* renamed from: g0.a, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0448a implements t {
    public final /* synthetic */ c o;

    public C0448a(c cVar) {
        this.o = cVar;
    }

    @Override // g0.t
    public final void a() {
        this.o.f6624s.remove(this);
    }

    @Override // g0.t
    public final boolean f(Uri uri, C.b bVar, boolean z6) {
        b bVar2;
        c cVar = this.o;
        HashMap hashMap = cVar.f6623r;
        if (cVar.f6630z == null) {
            long elapsedRealtime = SystemClock.elapsedRealtime();
            o oVar = cVar.f6629x;
            String str = C.f3053a;
            List list = oVar.e;
            int i6 = 0;
            for (int i7 = 0; i7 < list.size(); i7++) {
                b bVar3 = (b) hashMap.get(((n) list.get(i7)).f6706a);
                if (bVar3 != null && elapsedRealtime < bVar3.f6614v) {
                    i6++;
                }
            }
            t0.i iVar = new t0.i(1, 0, cVar.f6629x.e.size(), i6);
            cVar.f6622q.getClass();
            f1.f j6 = C0351o.j(iVar, bVar);
            if (j6 != null && j6.f6555a == 2 && (bVar2 = (b) hashMap.get(uri)) != null) {
                b.a(bVar2, j6.f6556b);
            }
        }
        return false;
    }
}
