package g0;

import E2.I;
import S.AbstractC0114g;
import S.C0119l;
import S.C0120m;
import S.C0122o;
import S.C0123p;
import S.E;
import S.F;
import S.G;
import V.AbstractC0133a;
import V.C;
import android.net.Uri;
import android.text.TextUtils;
import android.util.Base64;
import androidx.datastore.preferences.protobuf.AbstractC0227o;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.math.BigDecimal;
import java.nio.charset.StandardCharsets;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;
import java.util.UUID;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import org.apache.tika.metadata.TikaCoreProperties;
import org.apache.tika.utils.StringUtils;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* loaded from: classes.dex */
public final class r implements t0.q {
    public final o o;

    /* renamed from: p, reason: collision with root package name */
    public final l f6791p;

    /* renamed from: q, reason: collision with root package name */
    public static final Pattern f6772q = Pattern.compile("AVERAGE-BANDWIDTH=(\\d+)\\b");

    /* renamed from: r, reason: collision with root package name */
    public static final Pattern f6774r = Pattern.compile("VIDEO=\"((?:.|\f)+?)\"");

    /* renamed from: s, reason: collision with root package name */
    public static final Pattern f6776s = Pattern.compile("AUDIO=\"((?:.|\f)+?)\"");

    /* renamed from: t, reason: collision with root package name */
    public static final Pattern f6778t = Pattern.compile("SUBTITLES=\"((?:.|\f)+?)\"");

    /* renamed from: u, reason: collision with root package name */
    public static final Pattern f6780u = Pattern.compile("CLOSED-CAPTIONS=\"((?:.|\f)+?)\"");

    /* renamed from: v, reason: collision with root package name */
    public static final Pattern f6782v = Pattern.compile("[^-]BANDWIDTH=(\\d+)\\b");

    /* renamed from: w, reason: collision with root package name */
    public static final Pattern f6784w = Pattern.compile("CHANNELS=\"((?:.|\f)+?)\"");

    /* renamed from: x, reason: collision with root package name */
    public static final Pattern f6786x = Pattern.compile("VIDEO-RANGE=(SDR|PQ|HLG)");
    public static final Pattern y = Pattern.compile("CODECS=\"((?:.|\f)+?)\"");

    /* renamed from: z, reason: collision with root package name */
    public static final Pattern f6789z = Pattern.compile("SUPPLEMENTAL-CODECS=\"((?:.|\f)+?)\"");

    /* renamed from: A, reason: collision with root package name */
    public static final Pattern f6722A = Pattern.compile("RESOLUTION=(\\d+x\\d+)");

    /* renamed from: B, reason: collision with root package name */
    public static final Pattern f6724B = Pattern.compile("FRAME-RATE=([\\d\\.]+)\\b");

    /* renamed from: C, reason: collision with root package name */
    public static final Pattern f6726C = Pattern.compile("#EXT-X-TARGETDURATION:(\\d+)\\b");

    /* renamed from: D, reason: collision with root package name */
    public static final Pattern f6728D = Pattern.compile("DURATION=([\\d\\.]+)\\b");

    /* renamed from: E, reason: collision with root package name */
    public static final Pattern f6730E = Pattern.compile("[:,]DURATION=([\\d\\.]+)\\b");

    /* renamed from: F, reason: collision with root package name */
    public static final Pattern f6731F = Pattern.compile("PART-TARGET=([\\d\\.]+)\\b");

    /* renamed from: G, reason: collision with root package name */
    public static final Pattern f6733G = Pattern.compile("#EXT-X-VERSION:(\\d+)\\b");

    /* renamed from: H, reason: collision with root package name */
    public static final Pattern f6735H = Pattern.compile("#EXT-X-PLAYLIST-TYPE:(.+)\\b");

    /* renamed from: I, reason: collision with root package name */
    public static final Pattern f6737I = Pattern.compile("CAN-SKIP-UNTIL=([\\d\\.]+)\\b");

    /* renamed from: J, reason: collision with root package name */
    public static final Pattern f6739J = a("CAN-SKIP-DATERANGES");
    public static final Pattern K = Pattern.compile("SKIPPED-SEGMENTS=(\\d+)\\b");

    /* renamed from: L, reason: collision with root package name */
    public static final Pattern f6741L = Pattern.compile("[:|,]HOLD-BACK=([\\d\\.]+)\\b");

    /* renamed from: M, reason: collision with root package name */
    public static final Pattern f6742M = Pattern.compile("PART-HOLD-BACK=([\\d\\.]+)\\b");

    /* renamed from: N, reason: collision with root package name */
    public static final Pattern f6743N = a("CAN-BLOCK-RELOAD");

    /* renamed from: O, reason: collision with root package name */
    public static final Pattern f6744O = Pattern.compile("#EXT-X-MEDIA-SEQUENCE:(\\d+)\\b");

    /* renamed from: P, reason: collision with root package name */
    public static final Pattern f6745P = Pattern.compile("#EXTINF:([\\d\\.]+)\\b");

    /* renamed from: Q, reason: collision with root package name */
    public static final Pattern f6746Q = Pattern.compile("#EXTINF:[\\d\\.]+\\b,(.+)");

    /* renamed from: R, reason: collision with root package name */
    public static final Pattern f6747R = Pattern.compile("LAST-MSN=(\\d+)\\b");

    /* renamed from: S, reason: collision with root package name */
    public static final Pattern f6748S = Pattern.compile("LAST-PART=(\\d+)\\b");

    /* renamed from: T, reason: collision with root package name */
    public static final Pattern f6749T = Pattern.compile("TIME-OFFSET=(-?[\\d\\.]+)\\b");

    /* renamed from: U, reason: collision with root package name */
    public static final Pattern f6750U = Pattern.compile("#EXT-X-BYTERANGE:(\\d+(?:@\\d+)?)\\b");

    /* renamed from: V, reason: collision with root package name */
    public static final Pattern f6751V = Pattern.compile("BYTERANGE=\"(\\d+(?:@\\d+)?)\\b\"");

    /* renamed from: W, reason: collision with root package name */
    public static final Pattern f6752W = Pattern.compile("BYTERANGE-START=(\\d+)\\b");

    /* renamed from: X, reason: collision with root package name */
    public static final Pattern f6753X = Pattern.compile("BYTERANGE-LENGTH=(\\d+)\\b");

    /* renamed from: Y, reason: collision with root package name */
    public static final Pattern f6754Y = Pattern.compile("METHOD=(NONE|AES-128|SAMPLE-AES|SAMPLE-AES-CENC|SAMPLE-AES-CTR)\\s*(?:,|$)");

    /* renamed from: Z, reason: collision with root package name */
    public static final Pattern f6755Z = Pattern.compile("KEYFORMAT=\"((?:.|\f)+?)\"");

    /* renamed from: a0, reason: collision with root package name */
    public static final Pattern f6756a0 = Pattern.compile("KEYFORMATVERSIONS=\"((?:.|\f)+?)\"");

    /* renamed from: b0, reason: collision with root package name */
    public static final Pattern f6757b0 = Pattern.compile("URI=\"((?:.|\f)+?)\"");

    /* renamed from: c0, reason: collision with root package name */
    public static final Pattern f6758c0 = Pattern.compile("IV=([^,.*]+)");

    /* renamed from: d0, reason: collision with root package name */
    public static final Pattern f6759d0 = Pattern.compile("TYPE=(AUDIO|VIDEO|SUBTITLES|CLOSED-CAPTIONS)");

    /* renamed from: e0, reason: collision with root package name */
    public static final Pattern f6760e0 = Pattern.compile("TYPE=(PART|MAP)");

    /* renamed from: f0, reason: collision with root package name */
    public static final Pattern f6761f0 = Pattern.compile("LANGUAGE=\"((?:.|\f)+?)\"");

    /* renamed from: g0, reason: collision with root package name */
    public static final Pattern f6762g0 = Pattern.compile("NAME=\"((?:.|\f)+?)\"");

    /* renamed from: h0, reason: collision with root package name */
    public static final Pattern f6763h0 = Pattern.compile("GROUP-ID=\"((?:.|\f)+?)\"");

    /* renamed from: i0, reason: collision with root package name */
    public static final Pattern f6764i0 = Pattern.compile("CHARACTERISTICS=\"((?:.|\f)+?)\"");

    /* renamed from: j0, reason: collision with root package name */
    public static final Pattern f6765j0 = Pattern.compile("INSTREAM-ID=\"((?:CC|SERVICE)\\d+)\"");

    /* renamed from: k0, reason: collision with root package name */
    public static final Pattern f6766k0 = a("AUTOSELECT");

    /* renamed from: l0, reason: collision with root package name */
    public static final Pattern f6767l0 = a("DEFAULT");

    /* renamed from: m0, reason: collision with root package name */
    public static final Pattern f6768m0 = a("FORCED");

    /* renamed from: n0, reason: collision with root package name */
    public static final Pattern f6769n0 = a("INDEPENDENT");

    /* renamed from: o0, reason: collision with root package name */
    public static final Pattern f6770o0 = a("GAP");

    /* renamed from: p0, reason: collision with root package name */
    public static final Pattern f6771p0 = a("PRECISE");

    /* renamed from: q0, reason: collision with root package name */
    public static final Pattern f6773q0 = Pattern.compile("VALUE=\"((?:.|\f)+?)\"");

    /* renamed from: r0, reason: collision with root package name */
    public static final Pattern f6775r0 = Pattern.compile("IMPORT=\"((?:.|\f)+?)\"");

    /* renamed from: s0, reason: collision with root package name */
    public static final Pattern f6777s0 = Pattern.compile("[:,]ID=\"((?:.|\f)+?)\"");

    /* renamed from: t0, reason: collision with root package name */
    public static final Pattern f6779t0 = Pattern.compile("CLASS=\"((?:.|\f)+?)\"");

    /* renamed from: u0, reason: collision with root package name */
    public static final Pattern f6781u0 = Pattern.compile("START-DATE=\"((?:.|\f)+?)\"");

    /* renamed from: v0, reason: collision with root package name */
    public static final Pattern f6783v0 = Pattern.compile("CUE=\"((?:.|\f)+?)\"");

    /* renamed from: w0, reason: collision with root package name */
    public static final Pattern f6785w0 = Pattern.compile("END-DATE=\"((?:.|\f)+?)\"");

    /* renamed from: x0, reason: collision with root package name */
    public static final Pattern f6787x0 = Pattern.compile("PLANNED-DURATION=([\\d\\.]+)\\b");

    /* renamed from: y0, reason: collision with root package name */
    public static final Pattern f6788y0 = a("END-ON-NEXT");

    /* renamed from: z0, reason: collision with root package name */
    public static final Pattern f6790z0 = Pattern.compile("X-ASSET-URI=\"((?:.|\f)+?)\"");

    /* renamed from: A0, reason: collision with root package name */
    public static final Pattern f6723A0 = Pattern.compile("X-ASSET-LIST=\"((?:.|\f)+?)\"");

    /* renamed from: B0, reason: collision with root package name */
    public static final Pattern f6725B0 = Pattern.compile("X-RESUME-OFFSET=(-?[\\d\\.]+)\\b");

    /* renamed from: C0, reason: collision with root package name */
    public static final Pattern f6727C0 = Pattern.compile("X-PLAYOUT-LIMIT=([\\d\\.]+)\\b");

    /* renamed from: D0, reason: collision with root package name */
    public static final Pattern f6729D0 = Pattern.compile("X-SNAP=\"((?:.|\f)+?)\"");
    public static final Pattern E0 = Pattern.compile("X-RESTRICT=\"((?:.|\f)+?)\"");

    /* renamed from: F0, reason: collision with root package name */
    public static final Pattern f6732F0 = Pattern.compile("X-CONTENT-MAY-VARY=\"((?:.|\f)+?)\"");

    /* renamed from: G0, reason: collision with root package name */
    public static final Pattern f6734G0 = Pattern.compile("X-TIMELINE-OCCUPIES=\"((?:.|\f)+?)\"");

    /* renamed from: H0, reason: collision with root package name */
    public static final Pattern f6736H0 = Pattern.compile("X-TIMELINE-STYLE=\"((?:.|\f)+?)\"");

    /* renamed from: I0, reason: collision with root package name */
    public static final Pattern f6738I0 = Pattern.compile("\\{\\$([a-zA-Z0-9\\-_]+)\\}");

    /* renamed from: J0, reason: collision with root package name */
    public static final Pattern f6740J0 = Pattern.compile("\\b(X-[A-Z0-9-]+)=");

    public r(o oVar, l lVar) {
        this.o = oVar;
        this.f6791p = lVar;
    }

    public static Pattern a(String str) {
        return Pattern.compile(str.concat("=(NO|YES)"));
    }

    public static C0120m b(String str, C0119l[] c0119lArr) {
        C0119l[] c0119lArr2 = new C0119l[c0119lArr.length];
        for (int i6 = 0; i6 < c0119lArr.length; i6++) {
            C0119l c0119l = c0119lArr[i6];
            c0119lArr2[i6] = new C0119l(c0119l.f2555p, c0119l.f2556q, c0119l.f2557r, null);
        }
        return new C0120m(str, true, c0119lArr2);
    }

    public static C0119l c(String str, String str2, HashMap hashMap) {
        String i6 = i(str, f6756a0, "1", hashMap);
        boolean equals = "urn:uuid:edef8ba9-79d6-4ace-a3c8-27dcd51d21ed".equals(str2);
        Pattern pattern = f6757b0;
        if (equals) {
            String j6 = j(str, pattern, hashMap);
            return new C0119l(AbstractC0114g.f2543d, null, "video/mp4", Base64.decode(j6.substring(j6.indexOf(44)), 0));
        }
        if ("com.widevine".equals(str2)) {
            UUID uuid = AbstractC0114g.f2543d;
            String str3 = C.f3053a;
            return new C0119l(uuid, null, "hls", str.getBytes(StandardCharsets.UTF_8));
        }
        if (!"com.microsoft.playready".equals(str2) || !"1".equals(i6)) {
            return null;
        }
        String j7 = j(str, pattern, hashMap);
        byte[] decode = Base64.decode(j7.substring(j7.indexOf(44)), 0);
        UUID uuid2 = AbstractC0114g.e;
        return new C0119l(uuid2, null, "video/mp4", R0.t.a(uuid2, null, decode));
    }

    /* JADX WARN: Code restructure failed: missing block: B:181:0x08f3, code lost:
    
        if (r7.equals(r15) != false) goto L343;
     */
    /* JADX WARN: Code restructure failed: missing block: B:187:0x0911, code lost:
    
        if (r7.equals(r5) != false) goto L352;
     */
    /* JADX WARN: Multi-variable type inference failed. Error: jadx.core.utils.exceptions.JadxOverflowException: Type inference error: updates count limit reached
    	at jadx.core.dex.visitors.typeinference.TypeUpdateInfo.requestUpdate(TypeUpdateInfo.java:35)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.requestUpdate(TypeUpdate.java:210)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeForSsaVar(TypeUpdate.java:188)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeChecked(TypeUpdate.java:112)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.moveListener(TypeUpdate.java:447)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.runListeners(TypeUpdate.java:232)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.requestUpdate(TypeUpdate.java:212)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeForSsaVar(TypeUpdate.java:183)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeChecked(TypeUpdate.java:112)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.allSameListener(TypeUpdate.java:473)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.runListeners(TypeUpdate.java:232)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.requestUpdate(TypeUpdate.java:212)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeForSsaVar(TypeUpdate.java:183)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeChecked(TypeUpdate.java:112)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.allSameListener(TypeUpdate.java:466)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.runListeners(TypeUpdate.java:232)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.requestUpdate(TypeUpdate.java:212)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeForSsaVar(TypeUpdate.java:188)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeChecked(TypeUpdate.java:112)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.allSameListener(TypeUpdate.java:473)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.runListeners(TypeUpdate.java:232)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.requestUpdate(TypeUpdate.java:212)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeForSsaVar(TypeUpdate.java:183)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeChecked(TypeUpdate.java:112)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.moveListener(TypeUpdate.java:447)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.runListeners(TypeUpdate.java:232)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.requestUpdate(TypeUpdate.java:212)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeForSsaVar(TypeUpdate.java:183)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeChecked(TypeUpdate.java:112)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.allSameListener(TypeUpdate.java:473)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.runListeners(TypeUpdate.java:232)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.requestUpdate(TypeUpdate.java:212)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeForSsaVar(TypeUpdate.java:183)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeChecked(TypeUpdate.java:112)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.moveListener(TypeUpdate.java:447)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.runListeners(TypeUpdate.java:232)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.requestUpdate(TypeUpdate.java:212)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeForSsaVar(TypeUpdate.java:183)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeChecked(TypeUpdate.java:112)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.allSameListener(TypeUpdate.java:473)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.runListeners(TypeUpdate.java:232)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.requestUpdate(TypeUpdate.java:212)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeForSsaVar(TypeUpdate.java:183)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeChecked(TypeUpdate.java:112)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.allSameListener(TypeUpdate.java:466)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.runListeners(TypeUpdate.java:232)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.requestUpdate(TypeUpdate.java:212)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeForSsaVar(TypeUpdate.java:188)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeChecked(TypeUpdate.java:112)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.allSameListener(TypeUpdate.java:473)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.runListeners(TypeUpdate.java:232)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.requestUpdate(TypeUpdate.java:212)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeForSsaVar(TypeUpdate.java:183)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeChecked(TypeUpdate.java:112)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.allSameListener(TypeUpdate.java:466)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.runListeners(TypeUpdate.java:232)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.requestUpdate(TypeUpdate.java:212)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeForSsaVar(TypeUpdate.java:188)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeChecked(TypeUpdate.java:112)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.allSameListener(TypeUpdate.java:473)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.runListeners(TypeUpdate.java:232)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.requestUpdate(TypeUpdate.java:212)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeForSsaVar(TypeUpdate.java:183)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeChecked(TypeUpdate.java:112)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.allSameListener(TypeUpdate.java:466)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.runListeners(TypeUpdate.java:232)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.requestUpdate(TypeUpdate.java:212)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeForSsaVar(TypeUpdate.java:188)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeChecked(TypeUpdate.java:112)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.allSameListener(TypeUpdate.java:473)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.runListeners(TypeUpdate.java:232)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.requestUpdate(TypeUpdate.java:212)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeForSsaVar(TypeUpdate.java:183)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeChecked(TypeUpdate.java:112)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.allSameListener(TypeUpdate.java:466)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.runListeners(TypeUpdate.java:232)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.requestUpdate(TypeUpdate.java:212)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeForSsaVar(TypeUpdate.java:188)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeChecked(TypeUpdate.java:112)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.allSameListener(TypeUpdate.java:473)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.runListeners(TypeUpdate.java:232)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.requestUpdate(TypeUpdate.java:212)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeForSsaVar(TypeUpdate.java:183)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeChecked(TypeUpdate.java:112)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.allSameListener(TypeUpdate.java:466)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.runListeners(TypeUpdate.java:232)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.requestUpdate(TypeUpdate.java:212)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeForSsaVar(TypeUpdate.java:188)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeChecked(TypeUpdate.java:112)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.allSameListener(TypeUpdate.java:473)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.runListeners(TypeUpdate.java:232)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.requestUpdate(TypeUpdate.java:212)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeForSsaVar(TypeUpdate.java:183)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeChecked(TypeUpdate.java:112)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.allSameListener(TypeUpdate.java:466)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.runListeners(TypeUpdate.java:232)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.requestUpdate(TypeUpdate.java:212)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeForSsaVar(TypeUpdate.java:188)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeChecked(TypeUpdate.java:112)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.allSameListener(TypeUpdate.java:473)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.runListeners(TypeUpdate.java:232)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.requestUpdate(TypeUpdate.java:212)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeForSsaVar(TypeUpdate.java:183)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeChecked(TypeUpdate.java:112)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.allSameListener(TypeUpdate.java:466)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.runListeners(TypeUpdate.java:232)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.requestUpdate(TypeUpdate.java:212)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeForSsaVar(TypeUpdate.java:188)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeChecked(TypeUpdate.java:112)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.allSameListener(TypeUpdate.java:473)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.runListeners(TypeUpdate.java:232)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.requestUpdate(TypeUpdate.java:212)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeForSsaVar(TypeUpdate.java:183)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeChecked(TypeUpdate.java:112)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.allSameListener(TypeUpdate.java:466)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.runListeners(TypeUpdate.java:232)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.requestUpdate(TypeUpdate.java:212)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeForSsaVar(TypeUpdate.java:188)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeChecked(TypeUpdate.java:112)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.allSameListener(TypeUpdate.java:473)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.runListeners(TypeUpdate.java:232)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.requestUpdate(TypeUpdate.java:212)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeForSsaVar(TypeUpdate.java:183)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeChecked(TypeUpdate.java:112)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.allSameListener(TypeUpdate.java:466)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.runListeners(TypeUpdate.java:232)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.requestUpdate(TypeUpdate.java:212)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeForSsaVar(TypeUpdate.java:188)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeChecked(TypeUpdate.java:112)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.allSameListener(TypeUpdate.java:473)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.runListeners(TypeUpdate.java:232)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.requestUpdate(TypeUpdate.java:212)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeForSsaVar(TypeUpdate.java:183)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeChecked(TypeUpdate.java:112)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.allSameListener(TypeUpdate.java:466)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.runListeners(TypeUpdate.java:232)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.requestUpdate(TypeUpdate.java:212)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeForSsaVar(TypeUpdate.java:188)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeChecked(TypeUpdate.java:112)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.allSameListener(TypeUpdate.java:473)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.runListeners(TypeUpdate.java:232)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.requestUpdate(TypeUpdate.java:212)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeForSsaVar(TypeUpdate.java:183)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeChecked(TypeUpdate.java:112)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.allSameListener(TypeUpdate.java:466)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.runListeners(TypeUpdate.java:232)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.requestUpdate(TypeUpdate.java:212)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeForSsaVar(TypeUpdate.java:188)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeChecked(TypeUpdate.java:112)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.allSameListener(TypeUpdate.java:473)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.runListeners(TypeUpdate.java:232)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.requestUpdate(TypeUpdate.java:212)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeForSsaVar(TypeUpdate.java:183)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeChecked(TypeUpdate.java:112)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.allSameListener(TypeUpdate.java:466)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.runListeners(TypeUpdate.java:232)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.requestUpdate(TypeUpdate.java:212)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeForSsaVar(TypeUpdate.java:188)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeChecked(TypeUpdate.java:112)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.allSameListener(TypeUpdate.java:473)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.runListeners(TypeUpdate.java:232)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.requestUpdate(TypeUpdate.java:212)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeForSsaVar(TypeUpdate.java:183)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeChecked(TypeUpdate.java:112)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.allSameListener(TypeUpdate.java:466)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.runListeners(TypeUpdate.java:232)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.requestUpdate(TypeUpdate.java:212)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeForSsaVar(TypeUpdate.java:188)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeChecked(TypeUpdate.java:112)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.allSameListener(TypeUpdate.java:473)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.runListeners(TypeUpdate.java:232)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.requestUpdate(TypeUpdate.java:212)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeForSsaVar(TypeUpdate.java:183)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeChecked(TypeUpdate.java:112)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.allSameListener(TypeUpdate.java:466)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.runListeners(TypeUpdate.java:232)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.requestUpdate(TypeUpdate.java:212)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeForSsaVar(TypeUpdate.java:188)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeChecked(TypeUpdate.java:112)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.allSameListener(TypeUpdate.java:473)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.runListeners(TypeUpdate.java:232)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.requestUpdate(TypeUpdate.java:212)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeForSsaVar(TypeUpdate.java:183)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeChecked(TypeUpdate.java:112)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.allSameListener(TypeUpdate.java:466)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.runListeners(TypeUpdate.java:232)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.requestUpdate(TypeUpdate.java:212)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeForSsaVar(TypeUpdate.java:188)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeChecked(TypeUpdate.java:112)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.allSameListener(TypeUpdate.java:473)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.runListeners(TypeUpdate.java:232)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.requestUpdate(TypeUpdate.java:212)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeForSsaVar(TypeUpdate.java:183)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeChecked(TypeUpdate.java:112)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.allSameListener(TypeUpdate.java:466)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.runListeners(TypeUpdate.java:232)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.requestUpdate(TypeUpdate.java:212)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeForSsaVar(TypeUpdate.java:188)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeChecked(TypeUpdate.java:112)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.allSameListener(TypeUpdate.java:473)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.runListeners(TypeUpdate.java:232)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.requestUpdate(TypeUpdate.java:212)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeForSsaVar(TypeUpdate.java:183)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeChecked(TypeUpdate.java:112)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.allSameListener(TypeUpdate.java:466)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.runListeners(TypeUpdate.java:232)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.requestUpdate(TypeUpdate.java:212)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeForSsaVar(TypeUpdate.java:188)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeChecked(TypeUpdate.java:112)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.allSameListener(TypeUpdate.java:473)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.runListeners(TypeUpdate.java:232)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.requestUpdate(TypeUpdate.java:212)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeForSsaVar(TypeUpdate.java:183)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeChecked(TypeUpdate.java:112)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.allSameListener(TypeUpdate.java:466)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.runListeners(TypeUpdate.java:232)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.requestUpdate(TypeUpdate.java:212)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeForSsaVar(TypeUpdate.java:188)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeChecked(TypeUpdate.java:112)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.allSameListener(TypeUpdate.java:473)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.runListeners(TypeUpdate.java:232)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.requestUpdate(TypeUpdate.java:212)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeForSsaVar(TypeUpdate.java:183)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeChecked(TypeUpdate.java:112)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.allSameListener(TypeUpdate.java:466)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.runListeners(TypeUpdate.java:232)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.requestUpdate(TypeUpdate.java:212)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeForSsaVar(TypeUpdate.java:188)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeChecked(TypeUpdate.java:112)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.allSameListener(TypeUpdate.java:473)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.runListeners(TypeUpdate.java:232)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.requestUpdate(TypeUpdate.java:212)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeForSsaVar(TypeUpdate.java:183)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeChecked(TypeUpdate.java:112)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.allSameListener(TypeUpdate.java:466)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.runListeners(TypeUpdate.java:232)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.requestUpdate(TypeUpdate.java:212)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeForSsaVar(TypeUpdate.java:188)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeChecked(TypeUpdate.java:112)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.allSameListener(TypeUpdate.java:473)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.runListeners(TypeUpdate.java:232)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.requestUpdate(TypeUpdate.java:212)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeForSsaVar(TypeUpdate.java:183)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeChecked(TypeUpdate.java:112)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.allSameListener(TypeUpdate.java:466)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.runListeners(TypeUpdate.java:232)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.requestUpdate(TypeUpdate.java:212)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeForSsaVar(TypeUpdate.java:188)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeChecked(TypeUpdate.java:112)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.allSameListener(TypeUpdate.java:473)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.runListeners(TypeUpdate.java:232)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.requestUpdate(TypeUpdate.java:212)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeForSsaVar(TypeUpdate.java:183)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeChecked(TypeUpdate.java:112)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.allSameListener(TypeUpdate.java:466)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.runListeners(TypeUpdate.java:232)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.requestUpdate(TypeUpdate.java:212)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeForSsaVar(TypeUpdate.java:188)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeChecked(TypeUpdate.java:112)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.allSameListener(TypeUpdate.java:473)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.runListeners(TypeUpdate.java:232)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.requestUpdate(TypeUpdate.java:212)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeForSsaVar(TypeUpdate.java:183)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeChecked(TypeUpdate.java:112)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.allSameListener(TypeUpdate.java:466)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.runListeners(TypeUpdate.java:232)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.requestUpdate(TypeUpdate.java:212)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeForSsaVar(TypeUpdate.java:188)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeChecked(TypeUpdate.java:112)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.allSameListener(TypeUpdate.java:473)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.runListeners(TypeUpdate.java:232)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.requestUpdate(TypeUpdate.java:212)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeForSsaVar(TypeUpdate.java:183)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeChecked(TypeUpdate.java:112)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.allSameListener(TypeUpdate.java:466)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.runListeners(TypeUpdate.java:232)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.requestUpdate(TypeUpdate.java:212)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeForSsaVar(TypeUpdate.java:188)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeChecked(TypeUpdate.java:112)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.allSameListener(TypeUpdate.java:473)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.runListeners(TypeUpdate.java:232)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.requestUpdate(TypeUpdate.java:212)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeForSsaVar(TypeUpdate.java:183)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeChecked(TypeUpdate.java:112)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.allSameListener(TypeUpdate.java:466)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.runListeners(TypeUpdate.java:232)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.requestUpdate(TypeUpdate.java:212)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeForSsaVar(TypeUpdate.java:188)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeChecked(TypeUpdate.java:112)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.allSameListener(TypeUpdate.java:473)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.runListeners(TypeUpdate.java:232)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.requestUpdate(TypeUpdate.java:212)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeForSsaVar(TypeUpdate.java:183)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeChecked(TypeUpdate.java:112)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.allSameListener(TypeUpdate.java:466)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.runListeners(TypeUpdate.java:232)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.requestUpdate(TypeUpdate.java:212)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeForSsaVar(TypeUpdate.java:188)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeChecked(TypeUpdate.java:112)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.allSameListener(TypeUpdate.java:473)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.runListeners(TypeUpdate.java:232)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.requestUpdate(TypeUpdate.java:212)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeForSsaVar(TypeUpdate.java:183)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeChecked(TypeUpdate.java:112)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.allSameListener(TypeUpdate.java:466)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.runListeners(TypeUpdate.java:232)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.requestUpdate(TypeUpdate.java:212)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeForSsaVar(TypeUpdate.java:188)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeChecked(TypeUpdate.java:112)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.allSameListener(TypeUpdate.java:473)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.runListeners(TypeUpdate.java:232)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.requestUpdate(TypeUpdate.java:212)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeForSsaVar(TypeUpdate.java:183)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeChecked(TypeUpdate.java:112)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.allSameListener(TypeUpdate.java:466)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.runListeners(TypeUpdate.java:232)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.requestUpdate(TypeUpdate.java:212)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeForSsaVar(TypeUpdate.java:188)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeChecked(TypeUpdate.java:112)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.allSameListener(TypeUpdate.java:473)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.runListeners(TypeUpdate.java:232)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.requestUpdate(TypeUpdate.java:212)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeForSsaVar(TypeUpdate.java:183)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeChecked(TypeUpdate.java:112)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.allSameListener(TypeUpdate.java:466)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.runListeners(TypeUpdate.java:232)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.requestUpdate(TypeUpdate.java:212)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeForSsaVar(TypeUpdate.java:188)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeChecked(TypeUpdate.java:112)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.allSameListener(TypeUpdate.java:473)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.runListeners(TypeUpdate.java:232)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.requestUpdate(TypeUpdate.java:212)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeForSsaVar(TypeUpdate.java:183)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeChecked(TypeUpdate.java:112)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.allSameListener(TypeUpdate.java:466)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.runListeners(TypeUpdate.java:232)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.requestUpdate(TypeUpdate.java:212)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeForSsaVar(TypeUpdate.java:188)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeChecked(TypeUpdate.java:112)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.allSameListener(TypeUpdate.java:473)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.runListeners(TypeUpdate.java:232)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.requestUpdate(TypeUpdate.java:212)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeForSsaVar(TypeUpdate.java:183)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeChecked(TypeUpdate.java:112)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.allSameListener(TypeUpdate.java:466)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.runListeners(TypeUpdate.java:232)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.requestUpdate(TypeUpdate.java:212)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeForSsaVar(TypeUpdate.java:188)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeChecked(TypeUpdate.java:112)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.allSameListener(TypeUpdate.java:473)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.runListeners(TypeUpdate.java:232)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.requestUpdate(TypeUpdate.java:212)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeForSsaVar(TypeUpdate.java:183)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeChecked(TypeUpdate.java:112)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.allSameListener(TypeUpdate.java:466)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.runListeners(TypeUpdate.java:232)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.requestUpdate(TypeUpdate.java:212)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeForSsaVar(TypeUpdate.java:188)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeChecked(TypeUpdate.java:112)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.allSameListener(TypeUpdate.java:473)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.runListeners(TypeUpdate.java:232)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.requestUpdate(TypeUpdate.java:212)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeForSsaVar(TypeUpdate.java:183)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeChecked(TypeUpdate.java:112)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.allSameListener(TypeUpdate.java:466)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.runListeners(TypeUpdate.java:232)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.requestUpdate(TypeUpdate.java:212)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeForSsaVar(TypeUpdate.java:188)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeChecked(TypeUpdate.java:112)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.allSameListener(TypeUpdate.java:473)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.runListeners(TypeUpdate.java:232)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.requestUpdate(TypeUpdate.java:212)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeForSsaVar(TypeUpdate.java:183)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeChecked(TypeUpdate.java:112)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.allSameListener(TypeUpdate.java:466)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.runListeners(TypeUpdate.java:232)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.requestUpdate(TypeUpdate.java:212)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeForSsaVar(TypeUpdate.java:188)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeChecked(TypeUpdate.java:112)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.allSameListener(TypeUpdate.java:473)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.runListeners(TypeUpdate.java:232)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.requestUpdate(TypeUpdate.java:212)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeForSsaVar(TypeUpdate.java:183)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeChecked(TypeUpdate.java:112)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.allSameListener(TypeUpdate.java:466)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.runListeners(TypeUpdate.java:232)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.requestUpdate(TypeUpdate.java:212)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeForSsaVar(TypeUpdate.java:188)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeChecked(TypeUpdate.java:112)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.allSameListener(TypeUpdate.java:473)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.runListeners(TypeUpdate.java:232)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.requestUpdate(TypeUpdate.java:212)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeForSsaVar(TypeUpdate.java:183)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeChecked(TypeUpdate.java:112)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.allSameListener(TypeUpdate.java:466)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.runListeners(TypeUpdate.java:232)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.requestUpdate(TypeUpdate.java:212)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeForSsaVar(TypeUpdate.java:188)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeChecked(TypeUpdate.java:112)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.allSameListener(TypeUpdate.java:473)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.runListeners(TypeUpdate.java:232)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.requestUpdate(TypeUpdate.java:212)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeForSsaVar(TypeUpdate.java:183)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeChecked(TypeUpdate.java:112)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.allSameListener(TypeUpdate.java:466)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.runListeners(TypeUpdate.java:232)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.requestUpdate(TypeUpdate.java:212)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeForSsaVar(TypeUpdate.java:188)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeChecked(TypeUpdate.java:112)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.allSameListener(TypeUpdate.java:473)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.runListeners(TypeUpdate.java:232)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.requestUpdate(TypeUpdate.java:212)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeForSsaVar(TypeUpdate.java:183)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeChecked(TypeUpdate.java:112)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.allSameListener(TypeUpdate.java:466)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.runListeners(TypeUpdate.java:232)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.requestUpdate(TypeUpdate.java:212)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeForSsaVar(TypeUpdate.java:188)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeChecked(TypeUpdate.java:112)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.allSameListener(TypeUpdate.java:473)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.runListeners(TypeUpdate.java:232)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.requestUpdate(TypeUpdate.java:212)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeForSsaVar(TypeUpdate.java:183)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeChecked(TypeUpdate.java:112)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.allSameListener(TypeUpdate.java:466)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.runListeners(TypeUpdate.java:232)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.requestUpdate(TypeUpdate.java:212)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeForSsaVar(TypeUpdate.java:188)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeChecked(TypeUpdate.java:112)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.allSameListener(TypeUpdate.java:473)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.runListeners(TypeUpdate.java:232)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.requestUpdate(TypeUpdate.java:212)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeForSsaVar(TypeUpdate.java:183)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeChecked(TypeUpdate.java:112)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.allSameListener(TypeUpdate.java:466)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.runListeners(TypeUpdate.java:232)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.requestUpdate(TypeUpdate.java:212)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeForSsaVar(TypeUpdate.java:188)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeChecked(TypeUpdate.java:112)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.allSameListener(TypeUpdate.java:473)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.runListeners(TypeUpdate.java:232)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.requestUpdate(TypeUpdate.java:212)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeForSsaVar(TypeUpdate.java:183)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeChecked(TypeUpdate.java:112)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.allSameListener(TypeUpdate.java:466)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.runListeners(TypeUpdate.java:232)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.requestUpdate(TypeUpdate.java:212)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeForSsaVar(TypeUpdate.java:188)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeChecked(TypeUpdate.java:112)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.allSameListener(TypeUpdate.java:473)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.runListeners(TypeUpdate.java:232)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.requestUpdate(TypeUpdate.java:212)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeForSsaVar(TypeUpdate.java:183)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeChecked(TypeUpdate.java:112)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.allSameListener(TypeUpdate.java:466)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.runListeners(TypeUpdate.java:232)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.requestUpdate(TypeUpdate.java:212)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeForSsaVar(TypeUpdate.java:188)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeChecked(TypeUpdate.java:112)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.allSameListener(TypeUpdate.java:473)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.runListeners(TypeUpdate.java:232)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.requestUpdate(TypeUpdate.java:212)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeForSsaVar(TypeUpdate.java:183)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeChecked(TypeUpdate.java:112)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.allSameListener(TypeUpdate.java:466)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.runListeners(TypeUpdate.java:232)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.requestUpdate(TypeUpdate.java:212)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeForSsaVar(TypeUpdate.java:188)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeChecked(TypeUpdate.java:112)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.allSameListener(TypeUpdate.java:473)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.runListeners(TypeUpdate.java:232)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.requestUpdate(TypeUpdate.java:212)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeForSsaVar(TypeUpdate.java:183)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeChecked(TypeUpdate.java:112)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.allSameListener(TypeUpdate.java:466)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.runListeners(TypeUpdate.java:232)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.requestUpdate(TypeUpdate.java:212)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeForSsaVar(TypeUpdate.java:188)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeChecked(TypeUpdate.java:112)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.allSameListener(TypeUpdate.java:473)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.runListeners(TypeUpdate.java:232)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.requestUpdate(TypeUpdate.java:212)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeForSsaVar(TypeUpdate.java:183)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeChecked(TypeUpdate.java:112)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.allSameListener(TypeUpdate.java:466)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.runListeners(TypeUpdate.java:232)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.requestUpdate(TypeUpdate.java:212)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeForSsaVar(TypeUpdate.java:188)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeChecked(TypeUpdate.java:112)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.allSameListener(TypeUpdate.java:473)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.runListeners(TypeUpdate.java:232)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.requestUpdate(TypeUpdate.java:212)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeForSsaVar(TypeUpdate.java:183)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeChecked(TypeUpdate.java:112)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.allSameListener(TypeUpdate.java:466)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.runListeners(TypeUpdate.java:232)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.requestUpdate(TypeUpdate.java:212)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeForSsaVar(TypeUpdate.java:188)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeChecked(TypeUpdate.java:112)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.allSameListener(TypeUpdate.java:473)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.runListeners(TypeUpdate.java:232)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.requestUpdate(TypeUpdate.java:212)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeForSsaVar(TypeUpdate.java:183)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeChecked(TypeUpdate.java:112)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.allSameListener(TypeUpdate.java:466)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.runListeners(TypeUpdate.java:232)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.requestUpdate(TypeUpdate.java:212)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeForSsaVar(TypeUpdate.java:188)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeChecked(TypeUpdate.java:112)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.allSameListener(TypeUpdate.java:473)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.runListeners(TypeUpdate.java:232)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.requestUpdate(TypeUpdate.java:212)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeForSsaVar(TypeUpdate.java:183)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeChecked(TypeUpdate.java:112)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.allSameListener(TypeUpdate.java:466)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.runListeners(TypeUpdate.java:232)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.requestUpdate(TypeUpdate.java:212)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeForSsaVar(TypeUpdate.java:188)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeChecked(TypeUpdate.java:112)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.allSameListener(TypeUpdate.java:473)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.runListeners(TypeUpdate.java:232)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.requestUpdate(TypeUpdate.java:212)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeForSsaVar(TypeUpdate.java:183)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeChecked(TypeUpdate.java:112)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.allSameListener(TypeUpdate.java:466)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.runListeners(TypeUpdate.java:232)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.requestUpdate(TypeUpdate.java:212)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeForSsaVar(TypeUpdate.java:188)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeChecked(TypeUpdate.java:112)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.allSameListener(TypeUpdate.java:473)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.runListeners(TypeUpdate.java:232)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.requestUpdate(TypeUpdate.java:212)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeForSsaVar(TypeUpdate.java:183)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeChecked(TypeUpdate.java:112)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.allSameListener(TypeUpdate.java:466)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.runListeners(TypeUpdate.java:232)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.requestUpdate(TypeUpdate.java:212)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeForSsaVar(TypeUpdate.java:188)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeChecked(TypeUpdate.java:112)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.allSameListener(TypeUpdate.java:473)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.runListeners(TypeUpdate.java:232)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.requestUpdate(TypeUpdate.java:212)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeForSsaVar(TypeUpdate.java:183)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeChecked(TypeUpdate.java:112)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.allSameListener(TypeUpdate.java:466)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.runListeners(TypeUpdate.java:232)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.requestUpdate(TypeUpdate.java:212)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeForSsaVar(TypeUpdate.java:188)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeChecked(TypeUpdate.java:112)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.allSameListener(TypeUpdate.java:473)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.runListeners(TypeUpdate.java:232)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.requestUpdate(TypeUpdate.java:212)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeForSsaVar(TypeUpdate.java:183)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeChecked(TypeUpdate.java:112)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.allSameListener(TypeUpdate.java:466)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.runListeners(TypeUpdate.java:232)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.requestUpdate(TypeUpdate.java:212)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeForSsaVar(TypeUpdate.java:188)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeChecked(TypeUpdate.java:112)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.allSameListener(TypeUpdate.java:473)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.runListeners(TypeUpdate.java:232)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.requestUpdate(TypeUpdate.java:212)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeForSsaVar(TypeUpdate.java:183)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeChecked(TypeUpdate.java:112)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.allSameListener(TypeUpdate.java:466)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.runListeners(TypeUpdate.java:232)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.requestUpdate(TypeUpdate.java:212)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeForSsaVar(TypeUpdate.java:188)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeChecked(TypeUpdate.java:112)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.allSameListener(TypeUpdate.java:473)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.runListeners(TypeUpdate.java:232)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.requestUpdate(TypeUpdate.java:212)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeForSsaVar(TypeUpdate.java:183)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeChecked(TypeUpdate.java:112)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.allSameListener(TypeUpdate.java:466)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.runListeners(TypeUpdate.java:232)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.requestUpdate(TypeUpdate.java:212)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeForSsaVar(TypeUpdate.java:188)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeChecked(TypeUpdate.java:112)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.allSameListener(TypeUpdate.java:473)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.runListeners(TypeUpdate.java:232)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.requestUpdate(TypeUpdate.java:212)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeForSsaVar(TypeUpdate.java:183)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeChecked(TypeUpdate.java:112)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.allSameListener(TypeUpdate.java:466)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.runListeners(TypeUpdate.java:232)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.requestUpdate(TypeUpdate.java:212)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeForSsaVar(TypeUpdate.java:188)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeChecked(TypeUpdate.java:112)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.allSameListener(TypeUpdate.java:473)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.runListeners(TypeUpdate.java:232)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.requestUpdate(TypeUpdate.java:212)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeForSsaVar(TypeUpdate.java:183)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeChecked(TypeUpdate.java:112)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.allSameListener(TypeUpdate.java:466)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.runListeners(TypeUpdate.java:232)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.requestUpdate(TypeUpdate.java:212)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeForSsaVar(TypeUpdate.java:188)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeChecked(TypeUpdate.java:112)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.allSameListener(TypeUpdate.java:473)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.runListeners(TypeUpdate.java:232)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.requestUpdate(TypeUpdate.java:212)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeForSsaVar(TypeUpdate.java:183)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeChecked(TypeUpdate.java:112)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.allSameListener(TypeUpdate.java:466)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.runListeners(TypeUpdate.java:232)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.requestUpdate(TypeUpdate.java:212)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeForSsaVar(TypeUpdate.java:188)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeChecked(TypeUpdate.java:112)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.allSameListener(TypeUpdate.java:473)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.runListeners(TypeUpdate.java:232)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.requestUpdate(TypeUpdate.java:212)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeForSsaVar(TypeUpdate.java:183)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeChecked(TypeUpdate.java:112)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.allSameListener(TypeUpdate.java:466)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.runListeners(TypeUpdate.java:232)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.requestUpdate(TypeUpdate.java:212)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeForSsaVar(TypeUpdate.java:188)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeChecked(TypeUpdate.java:112)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.allSameListener(TypeUpdate.java:473)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.runListeners(TypeUpdate.java:232)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.requestUpdate(TypeUpdate.java:212)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeForSsaVar(TypeUpdate.java:183)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeChecked(TypeUpdate.java:112)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.allSameListener(TypeUpdate.java:466)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.runListeners(TypeUpdate.java:232)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.requestUpdate(TypeUpdate.java:212)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeForSsaVar(TypeUpdate.java:188)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeChecked(TypeUpdate.java:112)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.allSameListener(TypeUpdate.java:473)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.runListeners(TypeUpdate.java:232)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.requestUpdate(TypeUpdate.java:212)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeForSsaVar(TypeUpdate.java:183)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeChecked(TypeUpdate.java:112)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.allSameListener(TypeUpdate.java:466)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.runListeners(TypeUpdate.java:232)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.requestUpdate(TypeUpdate.java:212)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeForSsaVar(TypeUpdate.java:188)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeChecked(TypeUpdate.java:112)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.allSameListener(TypeUpdate.java:473)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.runListeners(TypeUpdate.java:232)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.requestUpdate(TypeUpdate.java:212)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeForSsaVar(TypeUpdate.java:183)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeChecked(TypeUpdate.java:112)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.allSameListener(TypeUpdate.java:466)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.runListeners(TypeUpdate.java:232)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.requestUpdate(TypeUpdate.java:212)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeForSsaVar(TypeUpdate.java:188)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeChecked(TypeUpdate.java:112)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.allSameListener(TypeUpdate.java:473)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.runListeners(TypeUpdate.java:232)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.requestUpdate(TypeUpdate.java:212)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeForSsaVar(TypeUpdate.java:183)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeChecked(TypeUpdate.java:112)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.allSameListener(TypeUpdate.java:466)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.runListeners(TypeUpdate.java:232)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.requestUpdate(TypeUpdate.java:212)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeForSsaVar(TypeUpdate.java:188)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeChecked(TypeUpdate.java:112)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.allSameListener(TypeUpdate.java:473)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.runListeners(TypeUpdate.java:232)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.requestUpdate(TypeUpdate.java:212)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeForSsaVar(TypeUpdate.java:183)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeChecked(TypeUpdate.java:112)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.allSameListener(TypeUpdate.java:466)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.runListeners(TypeUpdate.java:232)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.requestUpdate(TypeUpdate.java:212)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeForSsaVar(TypeUpdate.java:188)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeChecked(TypeUpdate.java:112)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.allSameListener(TypeUpdate.java:473)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.runListeners(TypeUpdate.java:232)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.requestUpdate(TypeUpdate.java:212)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeForSsaVar(TypeUpdate.java:183)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeChecked(TypeUpdate.java:112)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.allSameListener(TypeUpdate.java:466)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.runListeners(TypeUpdate.java:232)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.requestUpdate(TypeUpdate.java:212)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeForSsaVar(TypeUpdate.java:188)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeChecked(TypeUpdate.java:112)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.allSameListener(TypeUpdate.java:473)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.runListeners(TypeUpdate.java:232)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.requestUpdate(TypeUpdate.java:212)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeForSsaVar(TypeUpdate.java:183)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeChecked(TypeUpdate.java:112)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.allSameListener(TypeUpdate.java:466)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.runListeners(TypeUpdate.java:232)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.requestUpdate(TypeUpdate.java:212)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeForSsaVar(TypeUpdate.java:188)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeChecked(TypeUpdate.java:112)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.allSameListener(TypeUpdate.java:473)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.runListeners(TypeUpdate.java:232)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.requestUpdate(TypeUpdate.java:212)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeForSsaVar(TypeUpdate.java:183)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeChecked(TypeUpdate.java:112)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.allSameListener(TypeUpdate.java:466)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.runListeners(TypeUpdate.java:232)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.requestUpdate(TypeUpdate.java:212)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeForSsaVar(TypeUpdate.java:188)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeChecked(TypeUpdate.java:112)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.allSameListener(TypeUpdate.java:473)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.runListeners(TypeUpdate.java:232)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.requestUpdate(TypeUpdate.java:212)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeForSsaVar(TypeUpdate.java:183)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeChecked(TypeUpdate.java:112)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.allSameListener(TypeUpdate.java:466)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.runListeners(TypeUpdate.java:232)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.requestUpdate(TypeUpdate.java:212)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeForSsaVar(TypeUpdate.java:188)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeChecked(TypeUpdate.java:112)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.allSameListener(TypeUpdate.java:473)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.runListeners(TypeUpdate.java:232)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.requestUpdate(TypeUpdate.java:212)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeForSsaVar(TypeUpdate.java:183)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeChecked(TypeUpdate.java:112)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.allSameListener(TypeUpdate.java:466)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.runListeners(TypeUpdate.java:232)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.requestUpdate(TypeUpdate.java:212)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeForSsaVar(TypeUpdate.java:188)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeChecked(TypeUpdate.java:112)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.allSameListener(TypeUpdate.java:473)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.runListeners(TypeUpdate.java:232)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.requestUpdate(TypeUpdate.java:212)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeForSsaVar(TypeUpdate.java:183)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeChecked(TypeUpdate.java:112)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.allSameListener(TypeUpdate.java:466)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.runListeners(TypeUpdate.java:232)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.requestUpdate(TypeUpdate.java:212)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeForSsaVar(TypeUpdate.java:188)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeChecked(TypeUpdate.java:112)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.allSameListener(TypeUpdate.java:473)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.runListeners(TypeUpdate.java:232)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.requestUpdate(TypeUpdate.java:212)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeForSsaVar(TypeUpdate.java:183)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeChecked(TypeUpdate.java:112)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.allSameListener(TypeUpdate.java:466)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.runListeners(TypeUpdate.java:232)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.requestUpdate(TypeUpdate.java:212)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeForSsaVar(TypeUpdate.java:188)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeChecked(TypeUpdate.java:112)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.allSameListener(TypeUpdate.java:473)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.runListeners(TypeUpdate.java:232)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.requestUpdate(TypeUpdate.java:212)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeForSsaVar(TypeUpdate.java:183)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeChecked(TypeUpdate.java:112)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.allSameListener(TypeUpdate.java:466)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.runListeners(TypeUpdate.java:232)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.requestUpdate(TypeUpdate.java:212)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeForSsaVar(TypeUpdate.java:188)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeChecked(TypeUpdate.java:112)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.allSameListener(TypeUpdate.java:473)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.runListeners(TypeUpdate.java:232)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.requestUpdate(TypeUpdate.java:212)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeForSsaVar(TypeUpdate.java:183)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeChecked(TypeUpdate.java:112)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.allSameListener(TypeUpdate.java:466)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.runListeners(TypeUpdate.java:232)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.requestUpdate(TypeUpdate.java:212)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeForSsaVar(TypeUpdate.java:188)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeChecked(TypeUpdate.java:112)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.allSameListener(TypeUpdate.java:473)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.runListeners(TypeUpdate.java:232)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.requestUpdate(TypeUpdate.java:212)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeForSsaVar(TypeUpdate.java:183)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeChecked(TypeUpdate.java:112)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.allSameListener(TypeUpdate.java:466)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.runListeners(TypeUpdate.java:232)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.requestUpdate(TypeUpdate.java:212)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeForSsaVar(TypeUpdate.java:188)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeChecked(TypeUpdate.java:112)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.allSameListener(TypeUpdate.java:473)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.runListeners(TypeUpdate.java:232)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.requestUpdate(TypeUpdate.java:212)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeForSsaVar(TypeUpdate.java:183)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeChecked(TypeUpdate.java:112)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.allSameListener(TypeUpdate.java:466)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.runListeners(TypeUpdate.java:232)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.requestUpdate(TypeUpdate.java:212)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeForSsaVar(TypeUpdate.java:188)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeChecked(TypeUpdate.java:112)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.allSameListener(TypeUpdate.java:473)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.runListeners(TypeUpdate.java:232)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.requestUpdate(TypeUpdate.java:212)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeForSsaVar(TypeUpdate.java:183)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeChecked(TypeUpdate.java:112)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.allSameListener(TypeUpdate.java:466)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.runListeners(TypeUpdate.java:232)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.requestUpdate(TypeUpdate.java:212)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeForSsaVar(TypeUpdate.java:188)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeChecked(TypeUpdate.java:112)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.allSameListener(TypeUpdate.java:473)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.runListeners(TypeUpdate.java:232)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.requestUpdate(TypeUpdate.java:212)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeForSsaVar(TypeUpdate.java:183)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeChecked(TypeUpdate.java:112)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.allSameListener(TypeUpdate.java:466)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.runListeners(TypeUpdate.java:232)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.requestUpdate(TypeUpdate.java:212)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeForSsaVar(TypeUpdate.java:188)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeChecked(TypeUpdate.java:112)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.allSameListener(TypeUpdate.java:473)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.runListeners(TypeUpdate.java:232)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.requestUpdate(TypeUpdate.java:212)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeForSsaVar(TypeUpdate.java:183)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeChecked(TypeUpdate.java:112)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.allSameListener(TypeUpdate.java:466)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.runListeners(TypeUpdate.java:232)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.requestUpdate(TypeUpdate.java:212)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeForSsaVar(TypeUpdate.java:188)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeChecked(TypeUpdate.java:112)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.allSameListener(TypeUpdate.java:473)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.runListeners(TypeUpdate.java:232)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.requestUpdate(TypeUpdate.java:212)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeForSsaVar(TypeUpdate.java:183)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeChecked(TypeUpdate.java:112)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.allSameListener(TypeUpdate.java:466)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.runListeners(TypeUpdate.java:232)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.requestUpdate(TypeUpdate.java:212)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeForSsaVar(TypeUpdate.java:188)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeChecked(TypeUpdate.java:112)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.allSameListener(TypeUpdate.java:473)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.runListeners(TypeUpdate.java:232)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.requestUpdate(TypeUpdate.java:212)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeForSsaVar(TypeUpdate.java:183)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeChecked(TypeUpdate.java:112)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.allSameListener(TypeUpdate.java:466)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.runListeners(TypeUpdate.java:232)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.requestUpdate(TypeUpdate.java:212)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeForSsaVar(TypeUpdate.java:188)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeChecked(TypeUpdate.java:112)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.allSameListener(TypeUpdate.java:473)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.runListeners(TypeUpdate.java:232)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.requestUpdate(TypeUpdate.java:212)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeForSsaVar(TypeUpdate.java:183)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeChecked(TypeUpdate.java:112)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.allSameListener(TypeUpdate.java:466)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.runListeners(TypeUpdate.java:232)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.requestUpdate(TypeUpdate.java:212)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeForSsaVar(TypeUpdate.java:188)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeChecked(TypeUpdate.java:112)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.allSameListener(TypeUpdate.java:473)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.runListeners(TypeUpdate.java:232)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.requestUpdate(TypeUpdate.java:212)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeForSsaVar(TypeUpdate.java:183)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeChecked(TypeUpdate.java:112)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.allSameListener(TypeUpdate.java:466)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.runListeners(TypeUpdate.java:232)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.requestUpdate(TypeUpdate.java:212)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeForSsaVar(TypeUpdate.java:188)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeChecked(TypeUpdate.java:112)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.allSameListener(TypeUpdate.java:473)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.runListeners(TypeUpdate.java:232)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.requestUpdate(TypeUpdate.java:212)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeForSsaVar(TypeUpdate.java:183)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeChecked(TypeUpdate.java:112)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.allSameListener(TypeUpdate.java:466)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.runListeners(TypeUpdate.java:232)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.requestUpdate(TypeUpdate.java:212)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeForSsaVar(TypeUpdate.java:188)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeChecked(TypeUpdate.java:112)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.allSameListener(TypeUpdate.java:473)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.runListeners(TypeUpdate.java:232)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.requestUpdate(TypeUpdate.java:212)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeForSsaVar(TypeUpdate.java:183)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeChecked(TypeUpdate.java:112)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.allSameListener(TypeUpdate.java:466)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.runListeners(TypeUpdate.java:232)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.requestUpdate(TypeUpdate.java:212)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeForSsaVar(TypeUpdate.java:188)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeChecked(TypeUpdate.java:112)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.allSameListener(TypeUpdate.java:473)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.runListeners(TypeUpdate.java:232)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.requestUpdate(TypeUpdate.java:212)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeForSsaVar(TypeUpdate.java:183)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeChecked(TypeUpdate.java:112)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.allSameListener(TypeUpdate.java:466)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.runListeners(TypeUpdate.java:232)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.requestUpdate(TypeUpdate.java:212)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeForSsaVar(TypeUpdate.java:188)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeChecked(TypeUpdate.java:112)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.allSameListener(TypeUpdate.java:473)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.runListeners(TypeUpdate.java:232)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.requestUpdate(TypeUpdate.java:212)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeForSsaVar(TypeUpdate.java:183)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeChecked(TypeUpdate.java:112)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.allSameListener(TypeUpdate.java:466)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.runListeners(TypeUpdate.java:232)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.requestUpdate(TypeUpdate.java:212)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeForSsaVar(TypeUpdate.java:188)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeChecked(TypeUpdate.java:112)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.allSameListener(TypeUpdate.java:473)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.runListeners(TypeUpdate.java:232)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.requestUpdate(TypeUpdate.java:212)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeForSsaVar(TypeUpdate.java:183)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeChecked(TypeUpdate.java:112)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.allSameListener(TypeUpdate.java:466)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.runListeners(TypeUpdate.java:232)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.requestUpdate(TypeUpdate.java:212)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeForSsaVar(TypeUpdate.java:188)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeChecked(TypeUpdate.java:112)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.allSameListener(TypeUpdate.java:473)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.runListeners(TypeUpdate.java:232)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.requestUpdate(TypeUpdate.java:212)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeForSsaVar(TypeUpdate.java:183)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeChecked(TypeUpdate.java:112)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.allSameListener(TypeUpdate.java:466)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.runListeners(TypeUpdate.java:232)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.requestUpdate(TypeUpdate.java:212)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeForSsaVar(TypeUpdate.java:188)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeChecked(TypeUpdate.java:112)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.allSameListener(TypeUpdate.java:473)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.runListeners(TypeUpdate.java:232)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.requestUpdate(TypeUpdate.java:212)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeForSsaVar(TypeUpdate.java:183)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeChecked(TypeUpdate.java:112)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.allSameListener(TypeUpdate.java:466)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.runListeners(TypeUpdate.java:232)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.requestUpdate(TypeUpdate.java:212)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeForSsaVar(TypeUpdate.java:188)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeChecked(TypeUpdate.java:112)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.allSameListener(TypeUpdate.java:473)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.runListeners(TypeUpdate.java:232)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.requestUpdate(TypeUpdate.java:212)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeForSsaVar(TypeUpdate.java:183)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeChecked(TypeUpdate.java:112)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.allSameListener(TypeUpdate.java:466)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.runListeners(TypeUpdate.java:232)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.requestUpdate(TypeUpdate.java:212)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeForSsaVar(TypeUpdate.java:188)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeChecked(TypeUpdate.java:112)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.allSameListener(TypeUpdate.java:473)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.runListeners(TypeUpdate.java:232)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.requestUpdate(TypeUpdate.java:212)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeForSsaVar(TypeUpdate.java:183)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeChecked(TypeUpdate.java:112)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.allSameListener(TypeUpdate.java:466)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.runListeners(TypeUpdate.java:232)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.requestUpdate(TypeUpdate.java:212)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeForSsaVar(TypeUpdate.java:188)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeChecked(TypeUpdate.java:112)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.allSameListener(TypeUpdate.java:473)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.runListeners(TypeUpdate.java:232)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.requestUpdate(TypeUpdate.java:212)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeForSsaVar(TypeUpdate.java:183)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeChecked(TypeUpdate.java:112)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.allSameListener(TypeUpdate.java:466)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.runListeners(TypeUpdate.java:232)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.requestUpdate(TypeUpdate.java:212)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeForSsaVar(TypeUpdate.java:188)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeChecked(TypeUpdate.java:112)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.allSameListener(TypeUpdate.java:473)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.runListeners(TypeUpdate.java:232)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.requestUpdate(TypeUpdate.java:212)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeForSsaVar(TypeUpdate.java:183)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeChecked(TypeUpdate.java:112)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.allSameListener(TypeUpdate.java:466)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.runListeners(TypeUpdate.java:232)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.requestUpdate(TypeUpdate.java:212)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeForSsaVar(TypeUpdate.java:188)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeChecked(TypeUpdate.java:112)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.allSameListener(TypeUpdate.java:473)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.runListeners(TypeUpdate.java:232)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.requestUpdate(TypeUpdate.java:212)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeForSsaVar(TypeUpdate.java:183)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeChecked(TypeUpdate.java:112)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.allSameListener(TypeUpdate.java:466)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.runListeners(TypeUpdate.java:232)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.requestUpdate(TypeUpdate.java:212)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeForSsaVar(TypeUpdate.java:188)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeChecked(TypeUpdate.java:112)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.allSameListener(TypeUpdate.java:473)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.runListeners(TypeUpdate.java:232)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.requestUpdate(TypeUpdate.java:212)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeForSsaVar(TypeUpdate.java:183)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeChecked(TypeUpdate.java:112)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.allSameListener(TypeUpdate.java:466)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.runListeners(TypeUpdate.java:232)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.requestUpdate(TypeUpdate.java:212)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeForSsaVar(TypeUpdate.java:188)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeChecked(TypeUpdate.java:112)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.allSameListener(TypeUpdate.java:473)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.runListeners(TypeUpdate.java:232)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.requestUpdate(TypeUpdate.java:212)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeForSsaVar(TypeUpdate.java:183)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeChecked(TypeUpdate.java:112)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.allSameListener(TypeUpdate.java:466)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.runListeners(TypeUpdate.java:232)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.requestUpdate(TypeUpdate.java:212)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeForSsaVar(TypeUpdate.java:188)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeChecked(TypeUpdate.java:112)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.allSameListener(TypeUpdate.java:473)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.runListeners(TypeUpdate.java:232)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.requestUpdate(TypeUpdate.java:212)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeForSsaVar(TypeUpdate.java:183)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeChecked(TypeUpdate.java:112)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.allSameListener(TypeUpdate.java:466)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.runListeners(TypeUpdate.java:232)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.requestUpdate(TypeUpdate.java:212)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeForSsaVar(TypeUpdate.java:188)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeChecked(TypeUpdate.java:112)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.allSameListener(TypeUpdate.java:473)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.runListeners(TypeUpdate.java:232)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.requestUpdate(TypeUpdate.java:212)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeForSsaVar(TypeUpdate.java:183)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeChecked(TypeUpdate.java:112)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.allSameListener(TypeUpdate.java:466)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.runListeners(TypeUpdate.java:232)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.requestUpdate(TypeUpdate.java:212)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeForSsaVar(TypeUpdate.java:188)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeChecked(TypeUpdate.java:112)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.allSameListener(TypeUpdate.java:473)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.runListeners(TypeUpdate.java:232)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.requestUpdate(TypeUpdate.java:212)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeForSsaVar(TypeUpdate.java:183)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeChecked(TypeUpdate.java:112)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.allSameListener(TypeUpdate.java:466)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.runListeners(TypeUpdate.java:232)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.requestUpdate(TypeUpdate.java:212)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeForSsaVar(TypeUpdate.java:188)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeChecked(TypeUpdate.java:112)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.allSameListener(TypeUpdate.java:473)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.runListeners(TypeUpdate.java:232)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.requestUpdate(TypeUpdate.java:212)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.updateTypeForSsaVar(TypeUpdate.java:183)
     */
    /* JADX WARN: Removed duplicated region for block: B:184:0x0902  */
    /* JADX WARN: Removed duplicated region for block: B:191:0x092e  */
    /* JADX WARN: Removed duplicated region for block: B:245:0x0a9a  */
    /* JADX WARN: Removed duplicated region for block: B:248:0x0aaa  */
    /* JADX WARN: Removed duplicated region for block: B:250:0x0ad4  */
    /* JADX WARN: Removed duplicated region for block: B:259:0x0b2c  */
    /* JADX WARN: Removed duplicated region for block: B:269:0x0b59  */
    /* JADX WARN: Removed duplicated region for block: B:280:0x0b8b  */
    /* JADX WARN: Removed duplicated region for block: B:291:0x0bc2  */
    /* JADX WARN: Removed duplicated region for block: B:308:0x0c3a  */
    /* JADX WARN: Removed duplicated region for block: B:311:0x0c42  */
    /* JADX WARN: Removed duplicated region for block: B:322:0x0c74  */
    /* JADX WARN: Removed duplicated region for block: B:333:0x0ca9  */
    /* JADX WARN: Removed duplicated region for block: B:351:0x0d29  */
    /* JADX WARN: Removed duplicated region for block: B:370:0x0dac  */
    /* JADX WARN: Removed duplicated region for block: B:381:0x0dfe  */
    /* JADX WARN: Removed duplicated region for block: B:386:0x0e26  */
    /* JADX WARN: Removed duplicated region for block: B:391:0x0e4e  */
    /* JADX WARN: Removed duplicated region for block: B:399:0x0afe  */
    /* JADX WARN: Removed duplicated region for block: B:407:0x0aae  */
    /* JADX WARN: Removed duplicated region for block: B:411:0x0aa1  */
    /* JADX WARN: Removed duplicated region for block: B:439:0x0f23  */
    /* JADX WARN: Removed duplicated region for block: B:443:0x0f54  */
    /* JADX WARN: Removed duplicated region for block: B:447:0x0f57  */
    /* JADX WARN: Removed duplicated region for block: B:448:0x0f3c  */
    /* JADX WARN: Removed duplicated region for block: B:711:0x10bb  */
    /* JADX WARN: Removed duplicated region for block: B:714:0x10be A[SYNTHETIC] */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public static l d(o oVar, l lVar, X4.g gVar, String str) {
        ArrayList arrayList;
        ArrayList arrayList2;
        f fVar;
        ArrayList arrayList3;
        ArrayList arrayList4;
        ArrayList arrayList5;
        TreeMap treeMap;
        String str2;
        long j6;
        i iVar;
        int i6;
        int i7;
        long j7;
        String str3;
        HashMap hashMap;
        LinkedHashMap linkedHashMap;
        long j8;
        int i8;
        int i9;
        String hexString;
        C0120m c0120m;
        String hexString2;
        long j9;
        C0120m c0120m2;
        int i10;
        ArrayList arrayList6;
        ArrayList arrayList7;
        String str4;
        String hexString3;
        i iVar2;
        int i11;
        long j10;
        C0120m c0120m3;
        long j11;
        String str5;
        String i12;
        String str6;
        ArrayList arrayList8;
        String str7;
        Matcher matcher;
        Boolean bool;
        ArrayList arrayList9;
        long j12;
        String str8;
        e eVar;
        long j13;
        ArrayList arrayList10;
        long j14;
        long j15;
        long j16;
        long j17;
        String str9;
        char c6;
        Boolean bool2;
        ArrayList arrayList11;
        long j18;
        d dVar;
        int i13;
        char c7;
        o oVar2 = oVar;
        l lVar2 = lVar;
        boolean z6 = oVar2.f6721c;
        HashMap hashMap2 = new HashMap();
        HashMap hashMap3 = new HashMap();
        ArrayList arrayList12 = new ArrayList();
        ArrayList arrayList13 = new ArrayList();
        ArrayList arrayList14 = new ArrayList();
        ArrayList arrayList15 = new ArrayList();
        LinkedHashMap linkedHashMap2 = new LinkedHashMap();
        k kVar = new k(-9223372036854775807L, false, -9223372036854775807L, -9223372036854775807L, false);
        TreeMap treeMap2 = new TreeMap();
        String str10 = StringUtils.EMPTY;
        boolean z7 = z6;
        String str11 = StringUtils.EMPTY;
        long j19 = -9223372036854775807L;
        long j20 = 0;
        long j21 = 0;
        long j22 = 0;
        long j23 = 0;
        long j24 = 0;
        long j25 = 0;
        long j26 = 0;
        long j27 = -1;
        g gVar2 = null;
        String str12 = null;
        C0120m c0120m4 = null;
        String str13 = null;
        C0120m c0120m5 = null;
        int i14 = 0;
        int i15 = 1;
        boolean z8 = false;
        boolean z9 = false;
        int i16 = 0;
        i iVar3 = null;
        int i17 = 0;
        String str14 = null;
        int i18 = 0;
        boolean z10 = false;
        int i19 = 0;
        long j28 = -9223372036854775807L;
        long j29 = -9223372036854775807L;
        long j30 = 0;
        boolean z11 = false;
        while (true) {
            k kVar2 = kVar;
            if (gVar.L()) {
                String O5 = gVar.O();
                g gVar3 = gVar2;
                if (O5.startsWith("#EXT")) {
                    arrayList15.add(O5);
                }
                if (O5.startsWith("#EXT-X-PLAYLIST-TYPE")) {
                    String j31 = j(O5, f6735H, hashMap2);
                    if ("VOD".equals(j31)) {
                        i14 = 1;
                    } else if ("EVENT".equals(j31)) {
                        i14 = 2;
                    }
                } else if (O5.equals("#EXT-X-I-FRAMES-ONLY")) {
                    kVar = kVar2;
                    gVar2 = gVar3;
                    z10 = true;
                } else if (O5.startsWith("#EXT-X-START")) {
                    long parseDouble = (long) (Double.parseDouble(j(O5, f6749T, Collections.EMPTY_MAP)) * 1000000.0d);
                    z11 = f(O5, f6771p0);
                    j19 = parseDouble;
                } else if (O5.startsWith("#EXT-X-SERVER-CONTROL")) {
                    double g2 = g(O5, f6737I, -9.223372036854776E18d);
                    long j32 = g2 == -9.223372036854776E18d ? -9223372036854775807L : (long) (g2 * 1000000.0d);
                    boolean f6 = f(O5, f6739J);
                    double g3 = g(O5, f6741L, -9.223372036854776E18d);
                    long j33 = g3 == -9.223372036854776E18d ? -9223372036854775807L : (long) (g3 * 1000000.0d);
                    double g6 = g(O5, f6742M, -9.223372036854776E18d);
                    gVar2 = gVar3;
                    kVar = new k(j32, f6, j33, g6 == -9.223372036854776E18d ? -9223372036854775807L : (long) (g6 * 1000000.0d), f(O5, f6743N));
                } else if (O5.startsWith("#EXT-X-PART-INF")) {
                    j29 = (long) (Double.parseDouble(j(O5, f6731F, Collections.EMPTY_MAP)) * 1000000.0d);
                } else {
                    boolean startsWith = O5.startsWith("#EXT-X-MAP");
                    Pattern pattern = f6751V;
                    ArrayList arrayList16 = arrayList15;
                    HashMap hashMap4 = hashMap3;
                    Pattern pattern2 = f6757b0;
                    if (startsWith) {
                        String j34 = j(O5, pattern2, hashMap2);
                        String i20 = i(O5, pattern, null, hashMap2);
                        if (i20 != null) {
                            String str15 = C.f3053a;
                            String[] split = i20.split("@", -1);
                            j27 = Long.parseLong(split[i18]);
                            if (split.length > 1) {
                                j20 = Long.parseLong(split[1]);
                            }
                        }
                        long j35 = j27;
                        long j36 = j35 == -1 ? 0L : j20;
                        if (str14 != null && str13 == null) {
                            throw G.b("The encryption IV attribute must be present when an initialization segment is encrypted with METHOD=AES-128.", null);
                        }
                        i iVar4 = new i(j34, j36, j35, str14, str13);
                        String str16 = str13;
                        if (j35 != -1) {
                            j36 += j35;
                        }
                        j20 = j36;
                        iVar3 = iVar4;
                        j27 = -1;
                        kVar = kVar2;
                        gVar2 = gVar3;
                        arrayList15 = arrayList16;
                        hashMap3 = hashMap4;
                        str13 = str16;
                    } else {
                        LinkedHashMap linkedHashMap3 = linkedHashMap2;
                        String str17 = str13;
                        if (O5.startsWith("#EXT-X-TARGETDURATION")) {
                            j28 = Integer.parseInt(j(O5, f6726C, Collections.EMPTY_MAP)) * 1000000;
                        } else if (O5.startsWith("#EXT-X-MEDIA-SEQUENCE")) {
                            j22 = Long.parseLong(j(O5, f6744O, Collections.EMPTY_MAP));
                            j30 = j22;
                        } else if (O5.startsWith("#EXT-X-VERSION")) {
                            i15 = Integer.parseInt(j(O5, f6733G, Collections.EMPTY_MAP));
                        } else {
                            if (O5.startsWith("#EXT-X-DEFINE")) {
                                String i21 = i(O5, f6775r0, null, hashMap2);
                                if (i21 != null) {
                                    String str18 = (String) oVar2.f6717j.get(i21);
                                    if (str18 != null) {
                                        hashMap2.put(i21, str18);
                                    }
                                } else {
                                    hashMap2.put(j(O5, f6762g0, hashMap2), j(O5, f6773q0, hashMap2));
                                }
                            } else if (O5.startsWith("#EXTINF")) {
                                j25 = new BigDecimal(j(O5, f6745P, Collections.EMPTY_MAP)).multiply(new BigDecimal(1000000L)).longValue();
                                str11 = i(O5, f6746Q, str10, hashMap2);
                            } else {
                                if (O5.startsWith("#EXT-X-SKIP")) {
                                    int parseInt = Integer.parseInt(j(O5, K, Collections.EMPTY_MAP));
                                    AbstractC0133a.i((lVar2 == null || !arrayList12.isEmpty()) ? i18 : 1);
                                    String str19 = C.f3053a;
                                    long j37 = lVar2.f6691k;
                                    I i22 = lVar2.f6697r;
                                    int i23 = (int) (j30 - j37);
                                    int i24 = parseInt + i23;
                                    if (i23 >= 0 && i24 <= i22.size()) {
                                        long j38 = j24;
                                        str13 = str17;
                                        long j39 = j21;
                                        while (i23 < i24) {
                                            i iVar5 = (i) i22.get(i23);
                                            if (j30 != lVar2.f6691k) {
                                                int i25 = (lVar2.f6690j - i16) + iVar5.f6674r;
                                                I i26 = iVar5.f6670A;
                                                ArrayList arrayList17 = new ArrayList();
                                                long j40 = j39;
                                                int i27 = i18;
                                                while (i27 < i26.size()) {
                                                    g gVar4 = (g) i26.get(i27);
                                                    arrayList17.add(new g(gVar4.o, gVar4.f6672p, gVar4.f6673q, i25, j40, gVar4.f6676t, gVar4.f6677u, gVar4.f6678v, gVar4.f6679w, gVar4.f6680x, gVar4.y, gVar4.f6666z, gVar4.f6665A));
                                                    j40 += gVar4.f6673q;
                                                    i27++;
                                                    i24 = i24;
                                                }
                                                i8 = i24;
                                                iVar5 = new i(iVar5.o, iVar5.f6672p, iVar5.f6671z, iVar5.f6673q, i25, j39, iVar5.f6676t, iVar5.f6677u, iVar5.f6678v, iVar5.f6679w, iVar5.f6680x, iVar5.y, arrayList17);
                                            } else {
                                                i8 = i24;
                                            }
                                            arrayList12.add(iVar5);
                                            long j41 = iVar5.f6673q;
                                            String str20 = iVar5.f6678v;
                                            long j42 = j39 + j41;
                                            long j43 = iVar5.f6680x;
                                            if (j43 != -1) {
                                                j20 = iVar5.f6679w + j43;
                                            }
                                            int i28 = iVar5.f6674r;
                                            i iVar6 = iVar5.f6672p;
                                            C0120m c0120m6 = iVar5.f6676t;
                                            String str21 = iVar5.f6677u;
                                            if (str20 == null || !str20.equals(Long.toHexString(j22))) {
                                                str13 = str20;
                                            }
                                            j22++;
                                            i23++;
                                            i17 = i28;
                                            iVar3 = iVar6;
                                            str14 = str21;
                                            c0120m5 = c0120m6;
                                            i24 = i8;
                                            j38 = j42;
                                            j39 = j38;
                                            lVar2 = lVar;
                                        }
                                        oVar2 = oVar;
                                        lVar2 = lVar;
                                        j21 = j39;
                                        gVar2 = gVar3;
                                        arrayList15 = arrayList16;
                                        hashMap3 = hashMap4;
                                        j24 = j38;
                                        kVar = kVar2;
                                    }
                                } else if (O5.startsWith("#EXT-X-KEY")) {
                                    String j44 = j(O5, f6754Y, hashMap2);
                                    String i29 = i(O5, f6755Z, "identity", hashMap2);
                                    if ("NONE".equals(j44)) {
                                        treeMap2.clear();
                                        str13 = null;
                                    } else {
                                        String i30 = i(O5, f6758c0, null, hashMap2);
                                        if ("identity".equals(i29)) {
                                            if ("AES-128".equals(j44)) {
                                                str14 = j(O5, pattern2, hashMap2);
                                                str13 = i30;
                                                oVar2 = oVar;
                                                lVar2 = lVar;
                                                kVar = kVar2;
                                                gVar2 = gVar3;
                                                arrayList15 = arrayList16;
                                                hashMap3 = hashMap4;
                                            }
                                        } else {
                                            if (str12 == null) {
                                                str12 = ("SAMPLE-AES-CENC".equals(j44) || "SAMPLE-AES-CTR".equals(j44)) ? "cenc" : "cbcs";
                                            }
                                            C0119l c8 = c(O5, i29, hashMap2);
                                            if (c8 != null) {
                                                treeMap2.put(i29, c8);
                                                str13 = i30;
                                            }
                                        }
                                        str13 = i30;
                                        str14 = null;
                                        oVar2 = oVar;
                                        lVar2 = lVar;
                                        kVar = kVar2;
                                        gVar2 = gVar3;
                                        arrayList15 = arrayList16;
                                        hashMap3 = hashMap4;
                                    }
                                    c0120m5 = null;
                                    str14 = null;
                                    oVar2 = oVar;
                                    lVar2 = lVar;
                                    kVar = kVar2;
                                    gVar2 = gVar3;
                                    arrayList15 = arrayList16;
                                    hashMap3 = hashMap4;
                                } else {
                                    if (O5.startsWith("#EXT-X-BYTERANGE")) {
                                        String j45 = j(O5, f6750U, hashMap2);
                                        String str22 = C.f3053a;
                                        String[] split2 = j45.split("@", -1);
                                        j27 = Long.parseLong(split2[i18]);
                                        if (split2.length > 1) {
                                            j20 = Long.parseLong(split2[1]);
                                        }
                                    } else if (O5.startsWith("#EXT-X-DISCONTINUITY-SEQUENCE")) {
                                        i16 = Integer.parseInt(O5.substring(O5.indexOf(58) + 1));
                                        oVar2 = oVar;
                                        lVar2 = lVar;
                                        kVar = kVar2;
                                        gVar2 = gVar3;
                                        arrayList15 = arrayList16;
                                        hashMap3 = hashMap4;
                                        str13 = str17;
                                        linkedHashMap2 = linkedHashMap3;
                                        z9 = true;
                                    } else if (O5.equals("#EXT-X-DISCONTINUITY")) {
                                        i17++;
                                    } else if (O5.startsWith("#EXT-X-PROGRAM-DATE-TIME")) {
                                        if (j23 == 0) {
                                            j23 = C.N(C.Q(O5.substring(O5.indexOf(58) + 1))) - j21;
                                        }
                                    } else if (O5.equals("#EXT-X-GAP")) {
                                        oVar2 = oVar;
                                        lVar2 = lVar;
                                        kVar = kVar2;
                                        gVar2 = gVar3;
                                        arrayList15 = arrayList16;
                                        hashMap3 = hashMap4;
                                        str13 = str17;
                                        linkedHashMap2 = linkedHashMap3;
                                        i19 = 1;
                                    } else if (O5.equals("#EXT-X-INDEPENDENT-SEGMENTS")) {
                                        oVar2 = oVar;
                                        lVar2 = lVar;
                                        kVar = kVar2;
                                        gVar2 = gVar3;
                                        arrayList15 = arrayList16;
                                        hashMap3 = hashMap4;
                                        str13 = str17;
                                        linkedHashMap2 = linkedHashMap3;
                                        z7 = true;
                                    } else if (O5.equals("#EXT-X-ENDLIST")) {
                                        oVar2 = oVar;
                                        lVar2 = lVar;
                                        kVar = kVar2;
                                        gVar2 = gVar3;
                                        arrayList15 = arrayList16;
                                        hashMap3 = hashMap4;
                                        str13 = str17;
                                        linkedHashMap2 = linkedHashMap3;
                                        z8 = true;
                                    } else if (O5.startsWith("#EXT-X-RENDITION-REPORT")) {
                                        long h6 = h(O5, f6747R);
                                        Matcher matcher2 = f6748S.matcher(O5);
                                        if (matcher2.find()) {
                                            String group = matcher2.group(1);
                                            group.getClass();
                                            i9 = Integer.parseInt(group);
                                        } else {
                                            i9 = -1;
                                        }
                                        arrayList14.add(new h(i9, h6, Uri.parse(AbstractC0133a.x(str, j(O5, pattern2, hashMap2)))));
                                    } else if (O5.startsWith("#EXT-X-PRELOAD-HINT")) {
                                        if (gVar3 == null && "PART".equals(j(O5, f6760e0, hashMap2))) {
                                            String j46 = j(O5, pattern2, hashMap2);
                                            long h7 = h(O5, f6752W);
                                            long h8 = h(O5, f6753X);
                                            if (str14 == null) {
                                                hexString = null;
                                            } else {
                                                hexString = str17 != null ? str17 : Long.toHexString(j22);
                                            }
                                            if (c0120m5 != null || treeMap2.isEmpty()) {
                                                c0120m = c0120m5;
                                            } else {
                                                C0119l[] c0119lArr = (C0119l[]) treeMap2.values().toArray(new C0119l[i18]);
                                                C0120m c0120m7 = new C0120m(str12, true, c0119lArr);
                                                if (c0120m4 == null) {
                                                    c0120m4 = b(str12, c0119lArr);
                                                }
                                                c0120m = c0120m7;
                                            }
                                            if (h7 == -1 || h8 != -1) {
                                                gVar2 = new g(j46, iVar3, 0L, i17, j24, c0120m, str14, hexString, h7 != -1 ? h7 : 0L, h8, false, false, true);
                                            } else {
                                                gVar2 = gVar3;
                                            }
                                            oVar2 = oVar;
                                            lVar2 = lVar;
                                            c0120m5 = c0120m;
                                            kVar = kVar2;
                                            arrayList15 = arrayList16;
                                            hashMap3 = hashMap4;
                                            str13 = str17;
                                            linkedHashMap2 = linkedHashMap3;
                                            i18 = 0;
                                        }
                                    } else {
                                        if (O5.startsWith("#EXT-X-PART")) {
                                            if (str14 == null) {
                                                hexString2 = null;
                                            } else {
                                                hexString2 = str17 != null ? str17 : Long.toHexString(j22);
                                            }
                                            String j47 = j(O5, pattern2, hashMap2);
                                            long parseDouble2 = (long) (Double.parseDouble(j(O5, f6728D, Collections.EMPTY_MAP)) * 1000000.0d);
                                            boolean f7 = f(O5, f6769n0) | (z7 && arrayList13.isEmpty());
                                            boolean f8 = f(O5, f6770o0);
                                            String i31 = i(O5, pattern, null, hashMap2);
                                            if (i31 != null) {
                                                String str23 = C.f3053a;
                                                String[] split3 = i31.split("@", -1);
                                                long parseLong = Long.parseLong(split3[0]);
                                                if (split3.length > 1) {
                                                    j26 = Long.parseLong(split3[1]);
                                                }
                                                j9 = parseLong;
                                            } else {
                                                j9 = -1;
                                            }
                                            long j48 = j9 == -1 ? 0L : j26;
                                            if (c0120m5 != null || treeMap2.isEmpty()) {
                                                c0120m2 = c0120m5;
                                            } else {
                                                C0119l[] c0119lArr2 = (C0119l[]) treeMap2.values().toArray(new C0119l[0]);
                                                C0120m c0120m8 = new C0120m(str12, true, c0119lArr2);
                                                if (c0120m4 == null) {
                                                    c0120m4 = b(str12, c0119lArr2);
                                                }
                                                c0120m2 = c0120m8;
                                            }
                                            g gVar5 = new g(j47, iVar3, parseDouble2, i17, j24, c0120m2, str14, hexString2, j48, j9, f8, f7, false);
                                            i iVar7 = iVar3;
                                            int i32 = i17;
                                            arrayList13.add(gVar5);
                                            j24 += parseDouble2;
                                            if (j9 != -1) {
                                                j48 += j9;
                                            }
                                            j26 = j48;
                                            lVar2 = lVar;
                                            i17 = i32;
                                            iVar3 = iVar7;
                                            c0120m5 = c0120m2;
                                            kVar = kVar2;
                                            gVar2 = gVar3;
                                            arrayList15 = arrayList16;
                                            hashMap3 = hashMap4;
                                            str13 = str17;
                                            linkedHashMap2 = linkedHashMap3;
                                            i18 = 0;
                                        } else {
                                            i iVar8 = iVar3;
                                            int i33 = i17;
                                            if (O5.startsWith("#EXT-X-DATERANGE") && i(O5, f6779t0, str10, hashMap2).equals("com.apple.hls.interstitial")) {
                                                String j49 = j(O5, f6777s0, hashMap2);
                                                String i34 = i(O5, f6790z0, null, hashMap2);
                                                Uri parse = i34 != null ? Uri.parse(i34) : null;
                                                String i35 = i(O5, f6723A0, null, hashMap2);
                                                Uri parse2 = i35 != null ? Uri.parse(i35) : null;
                                                String i36 = i(O5, f6781u0, null, hashMap2);
                                                if (i36 != null) {
                                                    iVar = iVar8;
                                                    j11 = C.N(C.Q(i36));
                                                } else {
                                                    iVar = iVar8;
                                                    j11 = -9223372036854775807L;
                                                }
                                                i10 = i33;
                                                String i37 = i(O5, f6785w0, null, hashMap2);
                                                long N5 = i37 != null ? C.N(C.Q(i37)) : -9223372036854775807L;
                                                ArrayList arrayList18 = new ArrayList();
                                                arrayList7 = arrayList13;
                                                String i38 = i(O5, f6783v0, null, hashMap2);
                                                if (i38 != null) {
                                                    String str24 = C.f3053a;
                                                    String[] split4 = i38.split(",", -1);
                                                    int length = split4.length;
                                                    int i39 = 0;
                                                    while (i39 < length) {
                                                        int i40 = i39;
                                                        String trim = split4[i39].trim();
                                                        trim.getClass();
                                                        switch (trim.hashCode()) {
                                                            case 79491:
                                                                i13 = length;
                                                                if (trim.equals("PRE")) {
                                                                    c7 = 0;
                                                                    break;
                                                                }
                                                                break;
                                                            case 2430593:
                                                                i13 = length;
                                                                if (trim.equals("ONCE")) {
                                                                    c7 = 1;
                                                                    break;
                                                                }
                                                                break;
                                                            case 2461856:
                                                                i13 = length;
                                                                if (trim.equals("POST")) {
                                                                    c7 = 2;
                                                                    break;
                                                                }
                                                                break;
                                                            default:
                                                                i13 = length;
                                                                break;
                                                        }
                                                        c7 = 65535;
                                                        switch (c7) {
                                                            case 0:
                                                            case 1:
                                                            case 2:
                                                                arrayList18.add(trim);
                                                                break;
                                                        }
                                                        i39 = i40 + 1;
                                                        length = i13;
                                                    }
                                                }
                                                TreeMap treeMap3 = treeMap2;
                                                str4 = str12;
                                                double g7 = g(O5, f6730E, -1.0d);
                                                long j50 = g7 >= 0.0d ? (long) (g7 * 1000000.0d) : -9223372036854775807L;
                                                double g8 = g(O5, f6787x0, -1.0d);
                                                long j51 = g8 >= 0.0d ? (long) (g8 * 1000000.0d) : -9223372036854775807L;
                                                boolean f9 = f(O5, f6788y0);
                                                long j52 = j51;
                                                double g9 = g(O5, f6725B0, Double.MIN_VALUE);
                                                long j53 = g9 != Double.MIN_VALUE ? (long) (g9 * 1000000.0d) : -9223372036854775807L;
                                                double g10 = g(O5, f6727C0, -1.0d);
                                                long j54 = g10 >= 0.0d ? (long) (g10 * 1000000.0d) : -9223372036854775807L;
                                                ArrayList arrayList19 = new ArrayList();
                                                treeMap = treeMap3;
                                                str2 = str10;
                                                String i41 = i(O5, f6729D0, null, hashMap2);
                                                if (i41 != null) {
                                                    String str25 = C.f3053a;
                                                    String[] split5 = i41.split(",", -1);
                                                    int length2 = split5.length;
                                                    int i42 = 0;
                                                    while (i42 < length2) {
                                                        int i43 = i42;
                                                        String trim2 = split5[i42].trim();
                                                        trim2.getClass();
                                                        int i44 = length2;
                                                        if (trim2.equals("IN") || trim2.equals("OUT")) {
                                                            arrayList19.add(trim2);
                                                        }
                                                        i42 = i43 + 1;
                                                        length2 = i44;
                                                    }
                                                }
                                                ArrayList arrayList20 = new ArrayList();
                                                arrayList5 = arrayList14;
                                                String i45 = i(O5, E0, null, hashMap2);
                                                if (i45 != null) {
                                                    String str26 = C.f3053a;
                                                    String[] split6 = i45.split(",", -1);
                                                    int length3 = split6.length;
                                                    int i46 = 0;
                                                    while (i46 < length3) {
                                                        String[] strArr = split6;
                                                        String trim3 = split6[i46].trim();
                                                        trim3.getClass();
                                                        int i47 = length3;
                                                        if (trim3.equals("JUMP") || trim3.equals("SKIP")) {
                                                            arrayList20.add(trim3);
                                                        }
                                                        i46++;
                                                        length3 = i47;
                                                        split6 = strArr;
                                                    }
                                                }
                                                Boolean valueOf = i(O5, f6732F0, null, hashMap2) != null ? Boolean.valueOf(!r4.equals("NO")) : null;
                                                String i48 = i(O5, f6734G0, null, hashMap2);
                                                if (i48 != null) {
                                                    str5 = "RANGE";
                                                    if (!i48.equals("RANGE")) {
                                                        str5 = "POINT";
                                                    }
                                                    arrayList6 = arrayList12;
                                                    i12 = i(O5, f6736H0, null, hashMap2);
                                                    if (i12 != null) {
                                                        str6 = "PRIMARY";
                                                        if (!i12.equals("PRIMARY")) {
                                                            str6 = "HIGHLIGHT";
                                                        }
                                                        arrayList8 = new ArrayList();
                                                        str7 = str6;
                                                        String substring = O5.substring(17);
                                                        matcher = f6740J0.matcher(substring);
                                                        while (matcher.find()) {
                                                            Matcher matcher3 = matcher;
                                                            String group2 = matcher3.group();
                                                            group2.getClass();
                                                            switch (group2.hashCode()) {
                                                                case -2136701954:
                                                                    str9 = str5;
                                                                    if (group2.equals("X-SNAP=")) {
                                                                        c6 = 0;
                                                                        break;
                                                                    }
                                                                    break;
                                                                case -1843050726:
                                                                    str9 = str5;
                                                                    if (group2.equals("X-CONTENT-MAY-VARY=")) {
                                                                        c6 = 1;
                                                                        break;
                                                                    }
                                                                    break;
                                                                case -148960310:
                                                                    str9 = str5;
                                                                    if (group2.equals("X-PLAYOUT-LIMIT=")) {
                                                                        c6 = 2;
                                                                        break;
                                                                    }
                                                                    break;
                                                                case -36345757:
                                                                    str9 = str5;
                                                                    if (group2.equals("X-TIMELINE-STYLE=")) {
                                                                        c6 = 3;
                                                                        break;
                                                                    }
                                                                    break;
                                                                case 397239341:
                                                                    str9 = str5;
                                                                    if (group2.equals("X-ASSET-LIST=")) {
                                                                        c6 = 4;
                                                                        break;
                                                                    }
                                                                    break;
                                                                case 850193465:
                                                                    str9 = str5;
                                                                    if (group2.equals("X-TIMELINE-OCCUPIES=")) {
                                                                        c6 = 5;
                                                                        break;
                                                                    }
                                                                    break;
                                                                case 1472528844:
                                                                    str9 = str5;
                                                                    if (group2.equals("X-RESTRICT=")) {
                                                                        c6 = 6;
                                                                        break;
                                                                    }
                                                                    break;
                                                                case 1748487807:
                                                                    str9 = str5;
                                                                    if (group2.equals("X-RESUME-OFFSET=")) {
                                                                        c6 = 7;
                                                                        break;
                                                                    }
                                                                    break;
                                                                case 1814205923:
                                                                    str9 = str5;
                                                                    if (group2.equals("X-ASSET-URI=")) {
                                                                        c6 = '\b';
                                                                        break;
                                                                    }
                                                                    break;
                                                                default:
                                                                    str9 = str5;
                                                                    break;
                                                            }
                                                            c6 = 65535;
                                                            switch (c6) {
                                                                case 0:
                                                                case 1:
                                                                case 2:
                                                                case 3:
                                                                case 4:
                                                                case 5:
                                                                case 6:
                                                                case 7:
                                                                case '\b':
                                                                    bool2 = valueOf;
                                                                    arrayList11 = arrayList20;
                                                                    j18 = j54;
                                                                    break;
                                                                default:
                                                                    bool2 = valueOf;
                                                                    String substring2 = group2.substring(0, group2.length() - 1);
                                                                    String f10 = AbstractC0227o.f(substring2, "=");
                                                                    int length4 = f10.length() + substring.indexOf(f10);
                                                                    arrayList11 = arrayList20;
                                                                    String substring3 = substring.substring(length4, (substring.length() == length4 + 1 ? 1 : 2) + length4);
                                                                    if (substring3.startsWith("\"")) {
                                                                        dVar = new d(substring2, 0, j(substring, Pattern.compile(substring2 + "=\"((?:.|\f)+?)\""), hashMap2));
                                                                        j18 = j54;
                                                                    } else if (!substring3.equals("0x") && !substring3.equals("0X")) {
                                                                        j18 = j54;
                                                                        dVar = new d(substring2, Double.parseDouble(j(substring, Pattern.compile(substring2 + "=([\\d\\.]+)\\b"), Collections.EMPTY_MAP)));
                                                                    } else {
                                                                        j18 = j54;
                                                                        dVar = new d(substring2, 1, j(substring, Pattern.compile(substring2 + "=(0[xX][A-F0-9]+)"), hashMap2));
                                                                    }
                                                                    arrayList8.add(dVar);
                                                                    break;
                                                            }
                                                            matcher = matcher3;
                                                            str5 = str9;
                                                            valueOf = bool2;
                                                            arrayList20 = arrayList11;
                                                            j54 = j18;
                                                        }
                                                        bool = valueOf;
                                                        arrayList9 = arrayList20;
                                                        j12 = j54;
                                                        str8 = str5;
                                                        linkedHashMap = linkedHashMap3;
                                                        if (linkedHashMap.containsKey(j49)) {
                                                            eVar = (e) linkedHashMap.get(j49);
                                                        } else {
                                                            eVar = new e(j49);
                                                        }
                                                        if (parse == null) {
                                                            eVar.getClass();
                                                        } else {
                                                            Uri uri = eVar.f6637c;
                                                            if (uri != null) {
                                                                AbstractC0133a.b("Can't change assetUri from " + eVar.f6637c + " to " + parse, uri.equals(parse));
                                                            }
                                                            eVar.f6637c = parse;
                                                        }
                                                        if (parse2 != null) {
                                                            Uri uri2 = eVar.f6638d;
                                                            if (uri2 != null) {
                                                                AbstractC0133a.b("Can't change assetListUri from " + eVar.f6638d + " to " + parse2, uri2.equals(parse2));
                                                            }
                                                            eVar.f6638d = parse2;
                                                        }
                                                        if (j11 != -9223372036854775807L) {
                                                            long j55 = eVar.e;
                                                            if (j55 != -9223372036854775807L) {
                                                                AbstractC0133a.b("Can't change startDateUnixUs from " + eVar.e + " to " + j11, j55 == j11);
                                                            }
                                                            eVar.e = j11;
                                                        }
                                                        j13 = N5;
                                                        if (j13 != -9223372036854775807L) {
                                                            long j56 = eVar.f6639f;
                                                            if (j56 != -9223372036854775807L) {
                                                                AbstractC0133a.b("Can't change endDateUnixUs from " + eVar.f6639f + " to " + j13, j56 == j13);
                                                            }
                                                            eVar.f6639f = j13;
                                                        }
                                                        if (j50 != -9223372036854775807L) {
                                                            long j57 = eVar.f6640g;
                                                            if (j57 != -9223372036854775807L) {
                                                                boolean z12 = j57 == j50;
                                                                StringBuilder sb = new StringBuilder("Can't change durationUs from ");
                                                                sb.append(eVar.f6640g);
                                                                sb.append(" to ");
                                                                j17 = j50;
                                                                sb.append(j17);
                                                                AbstractC0133a.b(sb.toString(), z12);
                                                            } else {
                                                                j17 = j50;
                                                            }
                                                            eVar.f6640g = j17;
                                                        }
                                                        if (j52 != -9223372036854775807L) {
                                                            long j58 = eVar.f6641h;
                                                            if (j58 != -9223372036854775807L) {
                                                                boolean z13 = j58 == j52;
                                                                StringBuilder sb2 = new StringBuilder("Can't change plannedDurationUs from ");
                                                                sb2.append(eVar.f6641h);
                                                                sb2.append(" to ");
                                                                j16 = j52;
                                                                sb2.append(j16);
                                                                AbstractC0133a.b(sb2.toString(), z13);
                                                            } else {
                                                                j16 = j52;
                                                            }
                                                            eVar.f6641h = j16;
                                                        }
                                                        if (!arrayList18.isEmpty()) {
                                                            if (!eVar.f6642i.isEmpty()) {
                                                                boolean equals = eVar.f6642i.equals(arrayList18);
                                                                StringBuilder sb3 = new StringBuilder("Can't change cue from ");
                                                                ArrayList arrayList21 = eVar.f6642i;
                                                                StringBuilder sb4 = new StringBuilder();
                                                                Iterator it = arrayList21.iterator();
                                                                if (it.hasNext()) {
                                                                    while (true) {
                                                                        sb4.append((CharSequence) it.next());
                                                                        if (it.hasNext()) {
                                                                            sb4.append((CharSequence) ", ");
                                                                        }
                                                                    }
                                                                }
                                                                sb3.append(sb4.toString());
                                                                sb3.append(" to ");
                                                                StringBuilder sb5 = new StringBuilder();
                                                                Iterator it2 = arrayList18.iterator();
                                                                if (it2.hasNext()) {
                                                                    while (true) {
                                                                        sb5.append((CharSequence) it2.next());
                                                                        if (it2.hasNext()) {
                                                                            sb5.append((CharSequence) ", ");
                                                                        }
                                                                    }
                                                                }
                                                                sb3.append(sb5.toString());
                                                                AbstractC0133a.b(sb3.toString(), equals);
                                                            }
                                                            eVar.f6642i = arrayList18;
                                                        }
                                                        if (f9) {
                                                            eVar.f6643j = true;
                                                        }
                                                        if (j53 != -9223372036854775807L) {
                                                            long j59 = eVar.f6644k;
                                                            if (j59 != -9223372036854775807L) {
                                                                boolean z14 = j59 == j53;
                                                                StringBuilder sb6 = new StringBuilder("Can't change resumeOffsetUs from ");
                                                                sb6.append(eVar.f6644k);
                                                                sb6.append(" to ");
                                                                j15 = j53;
                                                                sb6.append(j15);
                                                                AbstractC0133a.b(sb6.toString(), z14);
                                                            } else {
                                                                j15 = j53;
                                                            }
                                                            eVar.f6644k = j15;
                                                        }
                                                        if (j12 != -9223372036854775807L) {
                                                            long j60 = eVar.f6645l;
                                                            if (j60 != -9223372036854775807L) {
                                                                boolean z15 = j60 == j12;
                                                                StringBuilder sb7 = new StringBuilder("Can't change playoutLimitUs from ");
                                                                sb7.append(eVar.f6645l);
                                                                sb7.append(" to ");
                                                                j14 = j12;
                                                                sb7.append(j14);
                                                                AbstractC0133a.b(sb7.toString(), z15);
                                                            } else {
                                                                j14 = j12;
                                                            }
                                                            eVar.f6645l = j14;
                                                        }
                                                        if (!arrayList19.isEmpty()) {
                                                            if (!eVar.f6646m.isEmpty()) {
                                                                boolean equals2 = eVar.f6646m.equals(arrayList19);
                                                                StringBuilder sb8 = new StringBuilder("Can't change snapTypes from ");
                                                                ArrayList arrayList22 = eVar.f6646m;
                                                                StringBuilder sb9 = new StringBuilder();
                                                                Iterator it3 = arrayList22.iterator();
                                                                if (it3.hasNext()) {
                                                                    while (true) {
                                                                        sb9.append((CharSequence) it3.next());
                                                                        if (it3.hasNext()) {
                                                                            sb9.append((CharSequence) ", ");
                                                                        }
                                                                    }
                                                                }
                                                                sb8.append(sb9.toString());
                                                                sb8.append(" to ");
                                                                StringBuilder sb10 = new StringBuilder();
                                                                Iterator it4 = arrayList19.iterator();
                                                                if (it4.hasNext()) {
                                                                    while (true) {
                                                                        sb10.append((CharSequence) it4.next());
                                                                        if (it4.hasNext()) {
                                                                            sb10.append((CharSequence) ", ");
                                                                        }
                                                                    }
                                                                }
                                                                sb8.append(sb10.toString());
                                                                AbstractC0133a.b(sb8.toString(), equals2);
                                                            }
                                                            eVar.f6646m = arrayList19;
                                                        }
                                                        eVar.getClass();
                                                        if (!arrayList9.isEmpty()) {
                                                            if (eVar.f6647n.isEmpty()) {
                                                                arrayList10 = arrayList9;
                                                            } else {
                                                                arrayList10 = arrayList9;
                                                                boolean equals3 = eVar.f6647n.equals(arrayList10);
                                                                StringBuilder sb11 = new StringBuilder("Can't change restrictions from ");
                                                                ArrayList arrayList23 = eVar.f6647n;
                                                                StringBuilder sb12 = new StringBuilder();
                                                                Iterator it5 = arrayList23.iterator();
                                                                if (it5.hasNext()) {
                                                                    while (true) {
                                                                        sb12.append((CharSequence) it5.next());
                                                                        if (it5.hasNext()) {
                                                                            sb12.append((CharSequence) ", ");
                                                                        }
                                                                    }
                                                                }
                                                                sb11.append(sb12.toString());
                                                                sb11.append(" to ");
                                                                StringBuilder sb13 = new StringBuilder();
                                                                Iterator it6 = arrayList10.iterator();
                                                                if (it6.hasNext()) {
                                                                    while (true) {
                                                                        sb13.append((CharSequence) it6.next());
                                                                        if (it6.hasNext()) {
                                                                            sb13.append((CharSequence) ", ");
                                                                        }
                                                                    }
                                                                }
                                                                sb11.append(sb13.toString());
                                                                AbstractC0133a.b(sb11.toString(), equals3);
                                                            }
                                                            eVar.f6647n = arrayList10;
                                                        }
                                                        HashMap hashMap5 = eVar.f6636b;
                                                        if (!arrayList8.isEmpty()) {
                                                            for (int i49 = 0; i49 < arrayList8.size(); i49++) {
                                                                d dVar2 = (d) arrayList8.get(i49);
                                                                String str27 = dVar2.f6631a;
                                                                d dVar3 = (d) hashMap5.get(str27);
                                                                if (dVar3 != null) {
                                                                    boolean equals4 = dVar3.equals(dVar2);
                                                                    StringBuilder j61 = AbstractC0227o.j("Can't change ", str27, " from ");
                                                                    j61.append(dVar3.f6634d);
                                                                    j61.append(StringUtils.SPACE);
                                                                    j61.append(dVar3.f6633c);
                                                                    j61.append(" to ");
                                                                    j61.append(dVar2.f6634d);
                                                                    j61.append(StringUtils.SPACE);
                                                                    j61.append(dVar2.f6633c);
                                                                    AbstractC0133a.b(j61.toString(), equals4);
                                                                }
                                                                hashMap5.put(str27, dVar2);
                                                            }
                                                        }
                                                        if (bool != null) {
                                                            Boolean bool3 = eVar.o;
                                                            if (bool3 != null) {
                                                                AbstractC0133a.b("Can't change contentMayVary from " + eVar.o + " to " + bool, bool3.equals(bool));
                                                            }
                                                            eVar.o = bool;
                                                        }
                                                        if (str8 != null) {
                                                            String str28 = eVar.f6648p;
                                                            if (str28 != null) {
                                                                AbstractC0133a.b("Can't change timelineOccupies from " + eVar.f6648p + " to " + str8, str28.equals(str8));
                                                            }
                                                            eVar.f6648p = str8;
                                                        }
                                                        if (str7 != null) {
                                                            String str29 = eVar.f6649q;
                                                            if (str29 != null) {
                                                                AbstractC0133a.b("Can't change timelineStyle from " + eVar.f6649q + " to " + str7, str29.equals(str7));
                                                            }
                                                            eVar.f6649q = str7;
                                                        }
                                                        linkedHashMap.put(j49, eVar);
                                                    }
                                                    str6 = null;
                                                    arrayList8 = new ArrayList();
                                                    str7 = str6;
                                                    String substring4 = O5.substring(17);
                                                    matcher = f6740J0.matcher(substring4);
                                                    while (matcher.find()) {
                                                    }
                                                    bool = valueOf;
                                                    arrayList9 = arrayList20;
                                                    j12 = j54;
                                                    str8 = str5;
                                                    linkedHashMap = linkedHashMap3;
                                                    if (linkedHashMap.containsKey(j49)) {
                                                    }
                                                    if (parse == null) {
                                                    }
                                                    if (parse2 != null) {
                                                    }
                                                    if (j11 != -9223372036854775807L) {
                                                    }
                                                    j13 = N5;
                                                    if (j13 != -9223372036854775807L) {
                                                    }
                                                    if (j50 != -9223372036854775807L) {
                                                    }
                                                    if (j52 != -9223372036854775807L) {
                                                    }
                                                    if (!arrayList18.isEmpty()) {
                                                    }
                                                    if (f9) {
                                                    }
                                                    if (j53 != -9223372036854775807L) {
                                                    }
                                                    if (j12 != -9223372036854775807L) {
                                                    }
                                                    if (!arrayList19.isEmpty()) {
                                                    }
                                                    eVar.getClass();
                                                    if (!arrayList9.isEmpty()) {
                                                    }
                                                    HashMap hashMap52 = eVar.f6636b;
                                                    if (!arrayList8.isEmpty()) {
                                                    }
                                                    if (bool != null) {
                                                    }
                                                    if (str8 != null) {
                                                    }
                                                    if (str7 != null) {
                                                    }
                                                    linkedHashMap.put(j49, eVar);
                                                }
                                                str5 = null;
                                                arrayList6 = arrayList12;
                                                i12 = i(O5, f6736H0, null, hashMap2);
                                                if (i12 != null) {
                                                }
                                                str6 = null;
                                                arrayList8 = new ArrayList();
                                                str7 = str6;
                                                String substring42 = O5.substring(17);
                                                matcher = f6740J0.matcher(substring42);
                                                while (matcher.find()) {
                                                }
                                                bool = valueOf;
                                                arrayList9 = arrayList20;
                                                j12 = j54;
                                                str8 = str5;
                                                linkedHashMap = linkedHashMap3;
                                                if (linkedHashMap.containsKey(j49)) {
                                                }
                                                if (parse == null) {
                                                }
                                                if (parse2 != null) {
                                                }
                                                if (j11 != -9223372036854775807L) {
                                                }
                                                j13 = N5;
                                                if (j13 != -9223372036854775807L) {
                                                }
                                                if (j50 != -9223372036854775807L) {
                                                }
                                                if (j52 != -9223372036854775807L) {
                                                }
                                                if (!arrayList18.isEmpty()) {
                                                }
                                                if (f9) {
                                                }
                                                if (j53 != -9223372036854775807L) {
                                                }
                                                if (j12 != -9223372036854775807L) {
                                                }
                                                if (!arrayList19.isEmpty()) {
                                                }
                                                eVar.getClass();
                                                if (!arrayList9.isEmpty()) {
                                                }
                                                HashMap hashMap522 = eVar.f6636b;
                                                if (!arrayList8.isEmpty()) {
                                                }
                                                if (bool != null) {
                                                }
                                                if (str8 != null) {
                                                }
                                                if (str7 != null) {
                                                }
                                                linkedHashMap.put(j49, eVar);
                                            } else {
                                                i10 = i33;
                                                arrayList6 = arrayList12;
                                                arrayList7 = arrayList13;
                                                arrayList5 = arrayList14;
                                                treeMap = treeMap2;
                                                str4 = str12;
                                                iVar = iVar8;
                                                str2 = str10;
                                                linkedHashMap = linkedHashMap3;
                                                if (!O5.startsWith("#")) {
                                                    if (str14 == null) {
                                                        hexString3 = null;
                                                    } else {
                                                        hexString3 = str17 != null ? str17 : Long.toHexString(j22);
                                                    }
                                                    long j62 = j22 + 1;
                                                    String k6 = k(O5, hashMap2);
                                                    i iVar9 = (i) hashMap4.get(k6);
                                                    if (j27 == -1) {
                                                        iVar2 = iVar9;
                                                        j20 = 0;
                                                    } else if (z10 && iVar == null && iVar9 == null) {
                                                        i iVar10 = new i(k6, 0L, j20, null, null);
                                                        hashMap4.put(k6, iVar10);
                                                        iVar2 = iVar10;
                                                    } else {
                                                        iVar2 = iVar9;
                                                        j20 = j20;
                                                    }
                                                    if (c0120m5 != null || treeMap.isEmpty()) {
                                                        str12 = str4;
                                                        i11 = 0;
                                                    } else {
                                                        i11 = 0;
                                                        C0119l[] c0119lArr3 = (C0119l[]) treeMap.values().toArray(new C0119l[0]);
                                                        str12 = str4;
                                                        C0120m c0120m9 = new C0120m(str12, true, c0119lArr3);
                                                        if (c0120m4 == null) {
                                                            c0120m3 = b(str12, c0119lArr3);
                                                            c0120m5 = c0120m9;
                                                            j10 = j20;
                                                            long j63 = j21;
                                                            C0120m c0120m10 = c0120m5;
                                                            long j64 = j10;
                                                            String str30 = str14;
                                                            long j65 = j25;
                                                            str14 = str30;
                                                            arrayList6.add(new i(k6, iVar == null ? iVar : iVar2, str11, j65, i10, j63, c0120m10, str30, hexString3, j64, j27, i19, arrayList7));
                                                            j24 = j63 + j65;
                                                            ArrayList arrayList24 = new ArrayList();
                                                            j20 = j27 == -1 ? j64 + j27 : j64;
                                                            j22 = j62;
                                                            c0120m4 = c0120m3;
                                                            i18 = i11;
                                                            i19 = i18;
                                                            i17 = i10;
                                                            c0120m5 = c0120m10;
                                                            j21 = j24;
                                                            iVar3 = iVar;
                                                            treeMap2 = treeMap;
                                                            str10 = str2;
                                                            str11 = str10;
                                                            j25 = 0;
                                                            j27 = -1;
                                                            kVar = kVar2;
                                                            gVar2 = gVar3;
                                                            arrayList15 = arrayList16;
                                                            str13 = str17;
                                                            arrayList14 = arrayList5;
                                                            lVar2 = lVar;
                                                            linkedHashMap2 = linkedHashMap;
                                                            hashMap3 = hashMap4;
                                                            arrayList13 = arrayList24;
                                                            arrayList12 = arrayList6;
                                                        } else {
                                                            c0120m5 = c0120m9;
                                                        }
                                                    }
                                                    j10 = j20;
                                                    c0120m3 = c0120m4;
                                                    long j632 = j21;
                                                    C0120m c0120m102 = c0120m5;
                                                    long j642 = j10;
                                                    String str302 = str14;
                                                    long j652 = j25;
                                                    str14 = str302;
                                                    arrayList6.add(new i(k6, iVar == null ? iVar : iVar2, str11, j652, i10, j632, c0120m102, str302, hexString3, j642, j27, i19, arrayList7));
                                                    j24 = j632 + j652;
                                                    ArrayList arrayList242 = new ArrayList();
                                                    if (j27 == -1) {
                                                    }
                                                    j22 = j62;
                                                    c0120m4 = c0120m3;
                                                    i18 = i11;
                                                    i19 = i18;
                                                    i17 = i10;
                                                    c0120m5 = c0120m102;
                                                    j21 = j24;
                                                    iVar3 = iVar;
                                                    treeMap2 = treeMap;
                                                    str10 = str2;
                                                    str11 = str10;
                                                    j25 = 0;
                                                    j27 = -1;
                                                    kVar = kVar2;
                                                    gVar2 = gVar3;
                                                    arrayList15 = arrayList16;
                                                    str13 = str17;
                                                    arrayList14 = arrayList5;
                                                    lVar2 = lVar;
                                                    linkedHashMap2 = linkedHashMap;
                                                    hashMap3 = hashMap4;
                                                    arrayList13 = arrayList242;
                                                    arrayList12 = arrayList6;
                                                }
                                            }
                                            j8 = j20;
                                            i6 = i10;
                                            arrayList4 = arrayList7;
                                            j6 = j21;
                                            str12 = str4;
                                            j7 = j25;
                                            str3 = str11;
                                            hashMap = hashMap4;
                                            arrayList3 = arrayList6;
                                            i7 = 0;
                                            arrayList12 = arrayList3;
                                            i18 = i7;
                                            str11 = str3;
                                            j25 = j7;
                                            j21 = j6;
                                            j20 = j8;
                                            iVar3 = iVar;
                                            treeMap2 = treeMap;
                                            str10 = str2;
                                            kVar = kVar2;
                                            gVar2 = gVar3;
                                            arrayList15 = arrayList16;
                                            str13 = str17;
                                            arrayList14 = arrayList5;
                                            oVar2 = oVar;
                                            linkedHashMap2 = linkedHashMap;
                                            hashMap3 = hashMap;
                                            i17 = i6;
                                            arrayList13 = arrayList4;
                                            lVar2 = lVar;
                                        }
                                        oVar2 = oVar;
                                    }
                                    oVar2 = oVar;
                                    lVar2 = lVar;
                                }
                                linkedHashMap2 = linkedHashMap3;
                            }
                            arrayList3 = arrayList12;
                            arrayList4 = arrayList13;
                            arrayList5 = arrayList14;
                            treeMap = treeMap2;
                            str2 = str10;
                            j6 = j21;
                            iVar = iVar3;
                            i6 = i17;
                            i7 = i18;
                            j7 = j25;
                            str3 = str11;
                            hashMap = hashMap4;
                            linkedHashMap = linkedHashMap3;
                            j8 = j20;
                            arrayList12 = arrayList3;
                            i18 = i7;
                            str11 = str3;
                            j25 = j7;
                            j21 = j6;
                            j20 = j8;
                            iVar3 = iVar;
                            treeMap2 = treeMap;
                            str10 = str2;
                            kVar = kVar2;
                            gVar2 = gVar3;
                            arrayList15 = arrayList16;
                            str13 = str17;
                            arrayList14 = arrayList5;
                            oVar2 = oVar;
                            linkedHashMap2 = linkedHashMap;
                            hashMap3 = hashMap;
                            i17 = i6;
                            arrayList13 = arrayList4;
                            lVar2 = lVar;
                        }
                        kVar = kVar2;
                        gVar2 = gVar3;
                        arrayList15 = arrayList16;
                        hashMap3 = hashMap4;
                        str13 = str17;
                        linkedHashMap2 = linkedHashMap3;
                    }
                }
                kVar = kVar2;
                gVar2 = gVar3;
            } else {
                g gVar6 = gVar2;
                ArrayList arrayList25 = arrayList12;
                ArrayList arrayList26 = arrayList13;
                ArrayList arrayList27 = arrayList14;
                ArrayList arrayList28 = arrayList15;
                LinkedHashMap linkedHashMap4 = linkedHashMap2;
                HashMap hashMap6 = new HashMap();
                int i50 = i18;
                while (i50 < arrayList27.size()) {
                    ArrayList arrayList29 = arrayList27;
                    h hVar = (h) arrayList29.get(i50);
                    long j66 = hVar.f6668b;
                    if (j66 == -1) {
                        j66 = (j30 + arrayList25.size()) - (arrayList26.isEmpty() ? 1L : 0L);
                    }
                    int i51 = hVar.f6669c;
                    if (i51 == -1 && j29 != -9223372036854775807L) {
                        i51 = (arrayList26.isEmpty() ? ((i) E2.r.j(arrayList25)).f6670A : arrayList26).size() - 1;
                    }
                    Uri uri3 = hVar.f6667a;
                    hashMap6.put(uri3, new h(i51, j66, uri3));
                    i50++;
                    arrayList27 = arrayList29;
                }
                if (gVar6 != null) {
                    arrayList26.add(gVar6);
                }
                ArrayList arrayList30 = new ArrayList();
                for (e eVar2 : linkedHashMap4.values()) {
                    Uri uri4 = eVar2.f6638d;
                    if ((uri4 == null && eVar2.f6637c != null) || (uri4 != null && eVar2.f6637c == null)) {
                        long j67 = eVar2.e;
                        if (j67 != -9223372036854775807L) {
                            String str31 = eVar2.f6635a;
                            Uri uri5 = eVar2.f6637c;
                            long j68 = eVar2.f6639f;
                            long j69 = eVar2.f6640g;
                            arrayList = arrayList25;
                            arrayList2 = arrayList26;
                            long j70 = eVar2.f6641h;
                            ArrayList arrayList31 = eVar2.f6642i;
                            boolean z16 = eVar2.f6643j;
                            long j71 = eVar2.f6644k;
                            long j72 = eVar2.f6645l;
                            ArrayList arrayList32 = eVar2.f6646m;
                            ArrayList arrayList33 = eVar2.f6647n;
                            ArrayList arrayList34 = new ArrayList(eVar2.f6636b.values());
                            Boolean bool4 = eVar2.o;
                            boolean z17 = bool4 == null || bool4.booleanValue();
                            String str32 = eVar2.f6648p;
                            String str33 = str32 != null ? str32 : "POINT";
                            String str34 = eVar2.f6649q;
                            fVar = new f(str31, uri5, uri4, j67, j68, j69, j70, arrayList31, z16, j71, j72, arrayList32, arrayList33, arrayList34, z17, str33, str34 != null ? str34 : "HIGHLIGHT");
                            if (fVar == null) {
                                arrayList30.add(fVar);
                            }
                            arrayList26 = arrayList2;
                            arrayList25 = arrayList;
                        }
                    }
                    arrayList = arrayList25;
                    arrayList2 = arrayList26;
                    fVar = null;
                    if (fVar == null) {
                    }
                    arrayList26 = arrayList2;
                    arrayList25 = arrayList;
                }
                return new l(i14, str, arrayList28, j19, z11, j23, z9, i16, j30, i15, j28, j29, z7, z8, j23 != 0, c0120m4, arrayList25, arrayList26, kVar2, hashMap6, arrayList30);
            }
        }
        throw new IOException();
    }

    /* JADX WARN: Can't fix incorrect switch cases order, some code will duplicate */
    /* JADX WARN: Code restructure failed: missing block: B:91:0x023f, code lost:
    
        if (r3 > 0) goto L100;
     */
    /* JADX WARN: Failed to find 'out' block for switch in B:151:0x0499. Please report as an issue. */
    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Removed duplicated region for block: B:101:0x02d1  */
    /* JADX WARN: Removed duplicated region for block: B:103:0x0278  */
    /* JADX WARN: Removed duplicated region for block: B:110:0x0251  */
    /* JADX WARN: Removed duplicated region for block: B:65:0x01c6  */
    /* JADX WARN: Removed duplicated region for block: B:70:0x020a  */
    /* JADX WARN: Removed duplicated region for block: B:71:0x021e  */
    /* JADX WARN: Removed duplicated region for block: B:72:0x01d0  */
    /* JADX WARN: Removed duplicated region for block: B:89:0x0228  */
    /* JADX WARN: Removed duplicated region for block: B:94:0x024c  */
    /* JADX WARN: Removed duplicated region for block: B:97:0x026d  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public static o e(X4.g gVar, String str) {
        int i6;
        Uri y2;
        char c6;
        ArrayList arrayList;
        n nVar;
        String str2;
        ArrayList arrayList2;
        int parseInt;
        String str3;
        n nVar2;
        String str4;
        n nVar3;
        HashMap hashMap;
        boolean z6;
        int i7;
        ArrayList arrayList3;
        boolean z7;
        int i8;
        ArrayList arrayList4;
        ArrayList arrayList5;
        ArrayList arrayList6;
        ArrayList arrayList7;
        int i9;
        String str5;
        String str6;
        String w6;
        String i10;
        int i11;
        int i12;
        String i13;
        float f6;
        Uri y3;
        ArrayList arrayList8;
        String[] X5;
        String sb;
        String str7;
        String str8 = str;
        HashMap hashMap2 = new HashMap();
        HashMap hashMap3 = new HashMap();
        ArrayList arrayList9 = new ArrayList();
        ArrayList arrayList10 = new ArrayList();
        ArrayList arrayList11 = new ArrayList();
        ArrayList arrayList12 = new ArrayList();
        ArrayList arrayList13 = new ArrayList();
        ArrayList arrayList14 = new ArrayList();
        ArrayList arrayList15 = new ArrayList();
        ArrayList arrayList16 = new ArrayList();
        boolean z8 = false;
        boolean z9 = false;
        while (true) {
            boolean L6 = gVar.L();
            Pattern pattern = f6757b0;
            ArrayList arrayList17 = arrayList13;
            boolean z10 = z8;
            Pattern pattern2 = f6762g0;
            boolean z11 = z9;
            if (L6) {
                String O5 = gVar.O();
                if (O5.startsWith("#EXT")) {
                    arrayList16.add(O5);
                }
                boolean startsWith = O5.startsWith("#EXT-X-I-FRAME-STREAM-INF");
                ArrayList arrayList18 = arrayList16;
                if (O5.startsWith("#EXT-X-DEFINE")) {
                    hashMap3.put(j(O5, pattern2, hashMap3), j(O5, f6773q0, hashMap3));
                } else if (O5.equals("#EXT-X-INDEPENDENT-SEGMENTS")) {
                    arrayList7 = arrayList14;
                    arrayList6 = arrayList10;
                    arrayList5 = arrayList11;
                    arrayList4 = arrayList12;
                    arrayList3 = arrayList15;
                    z8 = z10;
                    z9 = true;
                    arrayList13 = arrayList17;
                    arrayList16 = arrayList18;
                    arrayList15 = arrayList3;
                    arrayList12 = arrayList4;
                    arrayList11 = arrayList5;
                    arrayList10 = arrayList6;
                    arrayList14 = arrayList7;
                } else if (O5.startsWith("#EXT-X-MEDIA")) {
                    arrayList14.add(O5);
                } else if (O5.startsWith("#EXT-X-SESSION-KEY")) {
                    C0119l c7 = c(O5, i(O5, f6755Z, "identity", hashMap3), hashMap3);
                    if (c7 != null) {
                        String j6 = j(O5, f6754Y, hashMap3);
                        if (!"SAMPLE-AES-CENC".equals(j6) && !"SAMPLE-AES-CTR".equals(j6)) {
                            str7 = "cbcs";
                        } else {
                            str7 = "cenc";
                        }
                        arrayList15.add(new C0120m(str7, true, c7));
                    }
                } else if (O5.startsWith("#EXT-X-STREAM-INF") || startsWith) {
                    boolean contains = z10 | O5.contains("CLOSED-CAPTIONS=NONE");
                    if (startsWith) {
                        i7 = 16384;
                    } else {
                        i7 = 0;
                    }
                    z10 = contains;
                    arrayList3 = arrayList15;
                    int parseInt2 = Integer.parseInt(j(O5, f6782v, Collections.EMPTY_MAP));
                    Matcher matcher = f6772q.matcher(O5);
                    if (matcher.find()) {
                        z7 = startsWith;
                        String group = matcher.group(1);
                        group.getClass();
                        i8 = Integer.parseInt(group);
                    } else {
                        z7 = startsWith;
                        i8 = -1;
                    }
                    arrayList4 = arrayList12;
                    String i14 = i(O5, f6786x, null, hashMap3);
                    arrayList5 = arrayList11;
                    String i15 = i(O5, y, null, hashMap3);
                    arrayList6 = arrayList10;
                    String i16 = i(O5, f6789z, null, hashMap3);
                    if (i16 != null) {
                        String str9 = C.f3053a;
                        String[] split = i16.split(",", 2)[0].split("/", -1);
                        str5 = split[0];
                        if (split.length > 1) {
                            str6 = split[1];
                            arrayList7 = arrayList14;
                            i9 = 2;
                            w6 = C.w(i9, i15);
                            if (F.j(w6, str5) && (str5 == null || (i14 != null && str6 != null && ((!i14.equals("PQ") || str6.equals("db1p")) && ((!i14.equals("SDR") || str6.equals("db2g")) && (!i14.equals("HLG") || str6.startsWith("db4"))))))) {
                                if (str5 == null) {
                                    str5 = w6;
                                }
                                X5 = C.X(i15);
                                if (X5.length != 0) {
                                    StringBuilder sb2 = new StringBuilder();
                                    int length = X5.length;
                                    int i17 = 0;
                                    while (i17 < length) {
                                        String str10 = X5[i17];
                                        String[] strArr = X5;
                                        int i18 = length;
                                        if (2 != F.h(F.d(str10))) {
                                            if (sb2.length() > 0) {
                                                sb2.append(",");
                                            }
                                            sb2.append(str10);
                                        }
                                        i17++;
                                        length = i18;
                                        X5 = strArr;
                                    }
                                    if (sb2.length() > 0) {
                                        sb = sb2.toString();
                                        if (sb != null) {
                                            i15 = str5 + "," + sb;
                                        } else {
                                            i15 = str5;
                                        }
                                    }
                                }
                                sb = null;
                                if (sb != null) {
                                }
                            }
                            i10 = i(O5, f6722A, null, hashMap3);
                            if (i10 != null) {
                                String[] split2 = i10.split("x", -1);
                                i12 = Integer.parseInt(split2[0]);
                                i11 = Integer.parseInt(split2[1]);
                                if (i12 > 0) {
                                }
                            }
                            i11 = -1;
                            i12 = -1;
                            i13 = i(O5, f6724B, null, hashMap3);
                            if (i13 == null) {
                                f6 = Float.parseFloat(i13);
                            } else {
                                f6 = -1.0f;
                            }
                            String i19 = i(O5, f6774r, null, hashMap3);
                            String i20 = i(O5, f6776s, null, hashMap3);
                            String i21 = i(O5, f6778t, null, hashMap3);
                            String i22 = i(O5, f6780u, null, hashMap3);
                            if (!z7) {
                                y3 = AbstractC0133a.y(str8, j(O5, pattern, hashMap3));
                            } else if (gVar.L()) {
                                y3 = AbstractC0133a.y(str8, k(gVar.O(), hashMap3));
                            } else {
                                throw G.b("#EXT-X-STREAM-INF must be followed by another line", null);
                            }
                            Uri uri = y3;
                            C0122o c0122o = new C0122o();
                            c0122o.f2576a = Integer.toString(arrayList9.size());
                            c0122o.f2586l = F.n("application/x-mpegURL");
                            c0122o.f2584j = i15;
                            c0122o.f2582h = i8;
                            c0122o.f2583i = parseInt2;
                            c0122o.f2593t = i12;
                            c0122o.f2594u = i11;
                            c0122o.f2597x = f6;
                            c0122o.f2580f = i7;
                            arrayList9.add(new n(uri, new C0123p(c0122o), i19, i20, i21, i22));
                            arrayList8 = (ArrayList) hashMap2.get(uri);
                            if (arrayList8 == null) {
                                arrayList8 = new ArrayList();
                                hashMap2.put(uri, arrayList8);
                            }
                            arrayList8.add(new f0.r(i8, parseInt2, i19, i20, i21, i22));
                            z8 = z10;
                            z9 = z11;
                            arrayList13 = arrayList17;
                            arrayList16 = arrayList18;
                            arrayList15 = arrayList3;
                            arrayList12 = arrayList4;
                            arrayList11 = arrayList5;
                            arrayList10 = arrayList6;
                            arrayList14 = arrayList7;
                        } else {
                            arrayList7 = arrayList14;
                            i9 = 2;
                        }
                    } else {
                        arrayList7 = arrayList14;
                        i9 = 2;
                        str5 = null;
                    }
                    str6 = null;
                    w6 = C.w(i9, i15);
                    if (F.j(w6, str5)) {
                        if (str5 == null) {
                        }
                        X5 = C.X(i15);
                        if (X5.length != 0) {
                        }
                        sb = null;
                        if (sb != null) {
                        }
                    }
                    i10 = i(O5, f6722A, null, hashMap3);
                    if (i10 != null) {
                    }
                    i11 = -1;
                    i12 = -1;
                    i13 = i(O5, f6724B, null, hashMap3);
                    if (i13 == null) {
                    }
                    String i192 = i(O5, f6774r, null, hashMap3);
                    String i202 = i(O5, f6776s, null, hashMap3);
                    String i212 = i(O5, f6778t, null, hashMap3);
                    String i222 = i(O5, f6780u, null, hashMap3);
                    if (!z7) {
                    }
                    Uri uri2 = y3;
                    C0122o c0122o2 = new C0122o();
                    c0122o2.f2576a = Integer.toString(arrayList9.size());
                    c0122o2.f2586l = F.n("application/x-mpegURL");
                    c0122o2.f2584j = i15;
                    c0122o2.f2582h = i8;
                    c0122o2.f2583i = parseInt2;
                    c0122o2.f2593t = i12;
                    c0122o2.f2594u = i11;
                    c0122o2.f2597x = f6;
                    c0122o2.f2580f = i7;
                    arrayList9.add(new n(uri2, new C0123p(c0122o2), i192, i202, i212, i222));
                    arrayList8 = (ArrayList) hashMap2.get(uri2);
                    if (arrayList8 == null) {
                    }
                    arrayList8.add(new f0.r(i8, parseInt2, i192, i202, i212, i222));
                    z8 = z10;
                    z9 = z11;
                    arrayList13 = arrayList17;
                    arrayList16 = arrayList18;
                    arrayList15 = arrayList3;
                    arrayList12 = arrayList4;
                    arrayList11 = arrayList5;
                    arrayList10 = arrayList6;
                    arrayList14 = arrayList7;
                }
                arrayList7 = arrayList14;
                arrayList6 = arrayList10;
                arrayList5 = arrayList11;
                arrayList4 = arrayList12;
                arrayList3 = arrayList15;
                z8 = z10;
                z9 = z11;
                arrayList13 = arrayList17;
                arrayList16 = arrayList18;
                arrayList15 = arrayList3;
                arrayList12 = arrayList4;
                arrayList11 = arrayList5;
                arrayList10 = arrayList6;
                arrayList14 = arrayList7;
            } else {
                ArrayList arrayList19 = arrayList14;
                ArrayList arrayList20 = arrayList10;
                ArrayList arrayList21 = arrayList11;
                ArrayList arrayList22 = arrayList12;
                ArrayList arrayList23 = arrayList16;
                ArrayList arrayList24 = arrayList15;
                ArrayList arrayList25 = new ArrayList();
                HashSet hashSet = new HashSet();
                int i23 = 0;
                HashMap hashMap4 = hashMap2;
                while (i23 < arrayList9.size()) {
                    n nVar4 = (n) arrayList9.get(i23);
                    Uri uri3 = nVar4.f6706a;
                    C0123p c0123p = nVar4.f6707b;
                    if (hashSet.add(uri3)) {
                        if (c0123p.f2624l == null) {
                            z6 = true;
                        } else {
                            z6 = false;
                        }
                        AbstractC0133a.i(z6);
                        ArrayList arrayList26 = (ArrayList) hashMap4.get(nVar4.f6706a);
                        arrayList26.getClass();
                        hashMap = hashMap4;
                        E e = new E(new f0.s(null, arrayList26, null));
                        C0122o a6 = c0123p.a();
                        a6.f2585k = e;
                        arrayList25.add(new n(nVar4.f6706a, new C0123p(a6), nVar4.f6708c, nVar4.f6709d, nVar4.e, nVar4.f6710f));
                    } else {
                        hashMap = hashMap4;
                    }
                    i23++;
                    hashMap4 = hashMap;
                }
                int i24 = 0;
                List list = null;
                C0123p c0123p2 = null;
                while (i24 < arrayList19.size()) {
                    ArrayList arrayList27 = arrayList19;
                    String str11 = (String) arrayList27.get(i24);
                    String j7 = j(str11, f6763h0, hashMap3);
                    String j8 = j(str11, pattern2, hashMap3);
                    C0122o c0122o3 = new C0122o();
                    int i25 = i24;
                    StringBuilder sb3 = new StringBuilder();
                    sb3.append(j7);
                    ArrayList arrayList28 = arrayList25;
                    sb3.append(TikaCoreProperties.NAMESPACE_PREFIX_DELIMITER);
                    sb3.append(j8);
                    c0122o3.f2576a = sb3.toString();
                    c0122o3.f2577b = j8;
                    c0122o3.f2586l = F.n("application/x-mpegURL");
                    boolean f7 = f(str11, f6767l0);
                    boolean z12 = f7;
                    if (f(str11, f6768m0)) {
                        z12 = (f7 ? 1 : 0) | 2;
                    }
                    int i26 = z12;
                    if (f(str11, f6766k0)) {
                        i26 = (z12 ? 1 : 0) | 4;
                    }
                    c0122o3.e = i26;
                    String i27 = i(str11, f6764i0, null, hashMap3);
                    if (TextUtils.isEmpty(i27)) {
                        arrayList19 = arrayList27;
                        i6 = 0;
                    } else {
                        String str12 = C.f3053a;
                        String[] split3 = i27.split(",", -1);
                        if (C.l(split3, "public.accessibility.describes-video")) {
                            i6 = 512;
                        } else {
                            i6 = 0;
                        }
                        arrayList19 = arrayList27;
                        if (C.l(split3, "public.accessibility.transcribes-spoken-dialog")) {
                            i6 |= 4096;
                        }
                        if (C.l(split3, "public.accessibility.describes-music-and-sound")) {
                            i6 |= 1024;
                        }
                        if (C.l(split3, "public.easy-to-read")) {
                            i6 |= 8192;
                        }
                    }
                    c0122o3.f2580f = i6;
                    c0122o3.f2579d = i(str11, f6761f0, null, hashMap3);
                    String i28 = i(str11, pattern, null, hashMap3);
                    if (i28 == null) {
                        y2 = null;
                    } else {
                        y2 = AbstractC0133a.y(str8, i28);
                    }
                    E e6 = new E(new f0.s(j7, Collections.EMPTY_LIST, j8));
                    String j9 = j(str11, f6759d0, hashMap3);
                    switch (j9.hashCode()) {
                        case -959297733:
                            if (j9.equals("SUBTITLES")) {
                                c6 = 0;
                                break;
                            }
                            break;
                        case -333210994:
                            if (j9.equals("CLOSED-CAPTIONS")) {
                                c6 = 1;
                                break;
                            }
                            break;
                        case 62628790:
                            if (j9.equals("AUDIO")) {
                                c6 = 2;
                                break;
                            }
                            break;
                        case 81665115:
                            if (j9.equals("VIDEO")) {
                                c6 = 3;
                                break;
                            }
                            break;
                    }
                    c6 = 65535;
                    switch (c6) {
                        case 0:
                            int i29 = 0;
                            while (true) {
                                if (i29 < arrayList9.size()) {
                                    nVar = (n) arrayList9.get(i29);
                                    if (!j7.equals(nVar.e)) {
                                        i29++;
                                    }
                                } else {
                                    nVar = null;
                                }
                            }
                            if (nVar != null) {
                                String w7 = C.w(3, nVar.f6707b.f2623k);
                                c0122o3.f2584j = w7;
                                str2 = F.d(w7);
                            } else {
                                str2 = null;
                            }
                            if (str2 == null) {
                                str2 = "text/vtt";
                            }
                            c0122o3.f2587m = F.n(str2);
                            c0122o3.f2585k = e6;
                            if (y2 != null) {
                                m mVar = new m(y2, new C0123p(c0122o3), j8);
                                arrayList = arrayList22;
                                arrayList.add(mVar);
                                break;
                            } else {
                                arrayList = arrayList22;
                                AbstractC0133a.A("HlsPlaylistParser", "EXT-X-MEDIA tag with missing mandatory URI attribute: skipping");
                                break;
                            }
                        case 1:
                            arrayList2 = arrayList21;
                            String j10 = j(str11, f6765j0, hashMap3);
                            if (j10.startsWith("CC")) {
                                parseInt = Integer.parseInt(j10.substring(2));
                                str3 = "application/cea-608";
                            } else {
                                parseInt = Integer.parseInt(j10.substring(7));
                                str3 = "application/cea-708";
                            }
                            if (list == null) {
                                list = new ArrayList();
                            }
                            c0122o3.f2587m = F.n(str3);
                            c0122o3.f2572J = parseInt;
                            list.add(new C0123p(c0122o3));
                            arrayList21 = arrayList2;
                            arrayList = arrayList22;
                            break;
                        case 2:
                            int i30 = 0;
                            while (true) {
                                if (i30 < arrayList9.size()) {
                                    nVar2 = (n) arrayList9.get(i30);
                                    int i31 = i30;
                                    if (!j7.equals(nVar2.f6709d)) {
                                        i30 = i31 + 1;
                                    }
                                } else {
                                    nVar2 = null;
                                }
                            }
                            if (nVar2 != null) {
                                String w8 = C.w(1, nVar2.f6707b.f2623k);
                                c0122o3.f2584j = w8;
                                str4 = F.d(w8);
                            } else {
                                str4 = null;
                            }
                            n nVar5 = nVar2;
                            String i32 = i(str11, f6784w, null, hashMap3);
                            if (i32 != null) {
                                String str13 = C.f3053a;
                                c0122o3.f2567E = Integer.parseInt(i32.split("/", 2)[0]);
                                if ("audio/eac3".equals(str4) && i32.endsWith("/JOC")) {
                                    c0122o3.f2584j = "ec+3";
                                    str4 = "audio/eac3-joc";
                                }
                            }
                            c0122o3.f2587m = F.n(str4);
                            if (y2 != null) {
                                c0122o3.f2585k = e6;
                                arrayList21.add(new m(y2, new C0123p(c0122o3), j8));
                            } else {
                                arrayList2 = arrayList21;
                                if (nVar5 != null) {
                                    arrayList21 = arrayList2;
                                    c0123p2 = new C0123p(c0122o3);
                                }
                                arrayList21 = arrayList2;
                            }
                            arrayList = arrayList22;
                            break;
                        case 3:
                            int i33 = 0;
                            while (true) {
                                if (i33 < arrayList9.size()) {
                                    nVar3 = (n) arrayList9.get(i33);
                                    if (!j7.equals(nVar3.f6708c)) {
                                        i33++;
                                    }
                                } else {
                                    nVar3 = null;
                                }
                            }
                            if (nVar3 != null) {
                                C0123p c0123p3 = nVar3.f6707b;
                                String w9 = C.w(2, c0123p3.f2623k);
                                c0122o3.f2584j = w9;
                                c0122o3.f2587m = F.n(F.d(w9));
                                c0122o3.f2593t = c0123p3.f2632u;
                                c0122o3.f2594u = c0123p3.f2633v;
                                c0122o3.f2597x = c0123p3.y;
                            }
                            if (y2 != null) {
                                c0122o3.f2585k = e6;
                                arrayList20.add(new m(y2, new C0123p(c0122o3), j8));
                            }
                            arrayList = arrayList22;
                            break;
                        default:
                            arrayList = arrayList22;
                            break;
                    }
                    arrayList25 = arrayList28;
                    arrayList22 = arrayList;
                    i24 = i25 + 1;
                    str8 = str;
                }
                ArrayList arrayList29 = arrayList25;
                ArrayList arrayList30 = arrayList22;
                if (z10) {
                    list = Collections.EMPTY_LIST;
                }
                return new o(str, arrayList23, arrayList29, arrayList20, arrayList21, arrayList30, arrayList17, c0123p2, list, z11, hashMap3, arrayList24);
            }
        }
    }

    public static boolean f(String str, Pattern pattern) {
        Matcher matcher = pattern.matcher(str);
        if (matcher.find()) {
            return "YES".equals(matcher.group(1));
        }
        return false;
    }

    public static double g(String str, Pattern pattern, double d6) {
        Matcher matcher = pattern.matcher(str);
        if (matcher.find()) {
            String group = matcher.group(1);
            group.getClass();
            return Double.parseDouble(group);
        }
        return d6;
    }

    public static long h(String str, Pattern pattern) {
        Matcher matcher = pattern.matcher(str);
        if (matcher.find()) {
            String group = matcher.group(1);
            group.getClass();
            return Long.parseLong(group);
        }
        return -1L;
    }

    public static String i(String str, Pattern pattern, String str2, Map map) {
        Matcher matcher = pattern.matcher(str);
        if (matcher.find()) {
            str2 = matcher.group(1);
            str2.getClass();
        }
        if (!map.isEmpty() && str2 != null) {
            return k(str2, map);
        }
        return str2;
    }

    public static String j(String str, Pattern pattern, Map map) {
        String i6 = i(str, pattern, null, map);
        if (i6 != null) {
            return i6;
        }
        throw G.b("Couldn't match " + pattern.pattern() + " in " + str, null);
    }

    public static String k(String str, Map map) {
        Matcher matcher = f6738I0.matcher(str);
        StringBuffer stringBuffer = new StringBuffer();
        while (matcher.find()) {
            String group = matcher.group(1);
            if (map.containsKey(group)) {
                matcher.appendReplacement(stringBuffer, Matcher.quoteReplacement((String) map.get(group)));
            }
        }
        matcher.appendTail(stringBuffer);
        return stringBuffer.toString();
    }

    /* JADX WARN: Removed duplicated region for block: B:13:0x0069 A[Catch: all -> 0x0098, LOOP:0: B:13:0x0069->B:38:0x0069, LOOP_START, TryCatch #0 {all -> 0x0098, blocks: (B:3:0x000f, B:5:0x0018, B:7:0x0020, B:10:0x0029, B:13:0x0069, B:15:0x006f, B:18:0x007a, B:53:0x0082, B:20:0x009a, B:22:0x00a2, B:24:0x00aa, B:26:0x00b2, B:28:0x00ba, B:30:0x00c2, B:32:0x00ca, B:34:0x00d2, B:36:0x00db, B:41:0x00df, B:62:0x0103, B:63:0x0109, B:67:0x0030, B:69:0x0036, B:74:0x003f, B:76:0x0048, B:81:0x0051, B:83:0x0057, B:85:0x005d, B:87:0x0062), top: B:2:0x000f }] */
    /* JADX WARN: Removed duplicated region for block: B:62:0x0103 A[Catch: all -> 0x0098, TRY_ENTER, TryCatch #0 {all -> 0x0098, blocks: (B:3:0x000f, B:5:0x0018, B:7:0x0020, B:10:0x0029, B:13:0x0069, B:15:0x006f, B:18:0x007a, B:53:0x0082, B:20:0x009a, B:22:0x00a2, B:24:0x00aa, B:26:0x00b2, B:28:0x00ba, B:30:0x00c2, B:32:0x00ca, B:34:0x00d2, B:36:0x00db, B:41:0x00df, B:62:0x0103, B:63:0x0109, B:67:0x0030, B:69:0x0036, B:74:0x003f, B:76:0x0048, B:81:0x0051, B:83:0x0057, B:85:0x005d, B:87:0x0062), top: B:2:0x000f }] */
    @Override // t0.q
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final Object p(Uri uri, X.j jVar) {
        String trim;
        BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(jVar));
        ArrayDeque arrayDeque = new ArrayDeque();
        try {
            int read = bufferedReader.read();
            boolean z6 = false;
            if (read == 239) {
                if (bufferedReader.read() == 187 && bufferedReader.read() == 191) {
                    read = bufferedReader.read();
                }
                if (!z6) {
                    while (true) {
                        String readLine = bufferedReader.readLine();
                        if (readLine != null) {
                            trim = readLine.trim();
                            if (!trim.isEmpty()) {
                                if (trim.startsWith("#EXT-X-STREAM-INF")) {
                                    arrayDeque.add(trim);
                                    return e(new X4.g(arrayDeque, bufferedReader, 12), uri.toString());
                                }
                                if (trim.startsWith("#EXT-X-TARGETDURATION") || trim.startsWith("#EXT-X-MEDIA-SEQUENCE") || trim.startsWith("#EXTINF") || trim.startsWith("#EXT-X-KEY") || trim.startsWith("#EXT-X-BYTERANGE") || trim.equals("#EXT-X-DISCONTINUITY") || trim.equals("#EXT-X-DISCONTINUITY-SEQUENCE") || trim.equals("#EXT-X-ENDLIST")) {
                                    break;
                                }
                                arrayDeque.add(trim);
                            }
                        } else {
                            C.g(bufferedReader);
                            throw G.b("Failed to parse the playlist, could not identify any tags.", null);
                        }
                    }
                    arrayDeque.add(trim);
                    return d(this.o, this.f6791p, new X4.g(arrayDeque, bufferedReader, 12), uri.toString());
                }
                throw G.b("Input does not start with the #EXTM3U header.", null);
            }
            while (read != -1 && Character.isWhitespace(read)) {
                read = bufferedReader.read();
            }
            int i6 = 0;
            while (true) {
                if (i6 < 7) {
                    if (read != "#EXTM3U".charAt(i6)) {
                        break;
                    }
                    read = bufferedReader.read();
                    i6++;
                } else {
                    while (read != -1 && Character.isWhitespace(read) && !C.K(read)) {
                        read = bufferedReader.read();
                    }
                    z6 = C.K(read);
                }
            }
            if (!z6) {
            }
        } finally {
            C.g(bufferedReader);
        }
    }
}
