package g0;

import S.C0120m;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* loaded from: classes.dex */
public abstract class j implements Comparable {
    public final String o;

    /* renamed from: p, reason: collision with root package name */
    public final i f6672p;

    /* renamed from: q, reason: collision with root package name */
    public final long f6673q;

    /* renamed from: r, reason: collision with root package name */
    public final int f6674r;

    /* renamed from: s, reason: collision with root package name */
    public final long f6675s;

    /* renamed from: t, reason: collision with root package name */
    public final C0120m f6676t;

    /* renamed from: u, reason: collision with root package name */
    public final String f6677u;

    /* renamed from: v, reason: collision with root package name */
    public final String f6678v;

    /* renamed from: w, reason: collision with root package name */
    public final long f6679w;

    /* renamed from: x, reason: collision with root package name */
    public final long f6680x;
    public final boolean y;

    public j(String str, i iVar, long j6, int i6, long j7, C0120m c0120m, String str2, String str3, long j8, long j9, boolean z6) {
        this.o = str;
        this.f6672p = iVar;
        this.f6673q = j6;
        this.f6674r = i6;
        this.f6675s = j7;
        this.f6676t = c0120m;
        this.f6677u = str2;
        this.f6678v = str3;
        this.f6679w = j8;
        this.f6680x = j9;
        this.y = z6;
    }

    @Override // java.lang.Comparable
    public final int compareTo(Object obj) {
        Long l6 = (Long) obj;
        long longValue = l6.longValue();
        long j6 = this.f6675s;
        if (j6 > longValue) {
            return 1;
        }
        if (j6 < l6.longValue()) {
            return -1;
        }
        return 0;
    }
}
