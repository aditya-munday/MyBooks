package g0;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* loaded from: classes.dex */
public final class k {

    /* renamed from: a, reason: collision with root package name */
    public final long f6681a;

    /* renamed from: b, reason: collision with root package name */
    public final boolean f6682b;

    /* renamed from: c, reason: collision with root package name */
    public final long f6683c;

    /* renamed from: d, reason: collision with root package name */
    public final long f6684d;
    public final boolean e;

    public k(long j6, boolean z6, long j7, long j8, boolean z7) {
        this.f6681a = j6;
        this.f6682b = z6;
        this.f6683c = j7;
        this.f6684d = j8;
        this.e = z7;
    }
}
