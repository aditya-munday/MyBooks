package g0;

import S.C0123p;
import android.net.Uri;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* loaded from: classes.dex */
public final class m {

    /* renamed from: a, reason: collision with root package name */
    public final Uri f6703a;

    /* renamed from: b, reason: collision with root package name */
    public final C0123p f6704b;

    /* renamed from: c, reason: collision with root package name */
    public final String f6705c;

    public m(Uri uri, C0123p c0123p, String str) {
        this.f6703a = uri;
        this.f6704b = c0123p;
        this.f6705c = str;
    }
}
