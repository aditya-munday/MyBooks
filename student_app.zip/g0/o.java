package g0;

import S.C0123p;
import S.N;
import android.net.Uri;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import org.apache.tika.utils.StringUtils;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* loaded from: classes.dex */
public final class o extends p {

    /* renamed from: l, reason: collision with root package name */
    public static final o f6711l;

    /* renamed from: d, reason: collision with root package name */
    public final List f6712d;
    public final List e;

    /* renamed from: f, reason: collision with root package name */
    public final List f6713f;

    /* renamed from: g, reason: collision with root package name */
    public final List f6714g;

    /* renamed from: h, reason: collision with root package name */
    public final C0123p f6715h;

    /* renamed from: i, reason: collision with root package name */
    public final List f6716i;

    /* renamed from: j, reason: collision with root package name */
    public final Map f6717j;

    /* renamed from: k, reason: collision with root package name */
    public final List f6718k;

    static {
        List list = Collections.EMPTY_LIST;
        f6711l = new o(StringUtils.EMPTY, list, list, list, list, list, list, null, list, false, Collections.EMPTY_MAP, list);
    }

    public o(String str, List list, List list2, List list3, List list4, List list5, List list6, C0123p c0123p, List list7, boolean z6, Map map, List list8) {
        super(str, list, z6);
        List list9;
        ArrayList arrayList = new ArrayList();
        for (int i6 = 0; i6 < list2.size(); i6++) {
            Uri uri = ((n) list2.get(i6)).f6706a;
            if (!arrayList.contains(uri)) {
                arrayList.add(uri);
            }
        }
        b(arrayList, list3);
        b(arrayList, list4);
        b(arrayList, list5);
        b(arrayList, list6);
        this.f6712d = Collections.unmodifiableList(arrayList);
        this.e = Collections.unmodifiableList(list2);
        Collections.unmodifiableList(list3);
        this.f6713f = Collections.unmodifiableList(list4);
        this.f6714g = Collections.unmodifiableList(list5);
        Collections.unmodifiableList(list6);
        this.f6715h = c0123p;
        if (list7 != null) {
            list9 = Collections.unmodifiableList(list7);
        } else {
            list9 = null;
        }
        this.f6716i = list9;
        this.f6717j = Collections.unmodifiableMap(map);
        this.f6718k = Collections.unmodifiableList(list8);
    }

    public static void b(ArrayList arrayList, List list) {
        for (int i6 = 0; i6 < list.size(); i6++) {
            Uri uri = ((m) list.get(i6)).f6703a;
            if (!arrayList.contains(uri)) {
                arrayList.add(uri);
            }
        }
    }

    public static ArrayList c(List list, int i6, List list2) {
        ArrayList arrayList = new ArrayList(list2.size());
        for (int i7 = 0; i7 < list.size(); i7++) {
            Object obj = list.get(i7);
            int i8 = 0;
            while (true) {
                if (i8 < list2.size()) {
                    N n6 = (N) list2.get(i8);
                    if (n6.f2451p == i6 && n6.f2452q == i7) {
                        arrayList.add(obj);
                        break;
                    }
                    i8++;
                }
            }
        }
        return arrayList;
    }

    @Override // k0.InterfaceC0525a
    public final Object a(List list) {
        ArrayList c6 = c(this.e, 0, list);
        List list2 = Collections.EMPTY_LIST;
        return new o(this.f6719a, this.f6720b, c6, list2, c(this.f6713f, 1, list), c(this.f6714g, 2, list), list2, this.f6715h, this.f6716i, this.f6721c, this.f6717j, this.f6718k);
    }
}
