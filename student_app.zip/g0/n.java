package g0;

import S.C0123p;
import android.net.Uri;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* loaded from: classes.dex */
public final class n {

    /* renamed from: a, reason: collision with root package name */
    public final Uri f6706a;

    /* renamed from: b, reason: collision with root package name */
    public final C0123p f6707b;

    /* renamed from: c, reason: collision with root package name */
    public final String f6708c;

    /* renamed from: d, reason: collision with root package name */
    public final String f6709d;
    public final String e;

    /* renamed from: f, reason: collision with root package name */
    public final String f6710f;

    public n(Uri uri, C0123p c0123p, String str, String str2, String str3, String str4) {
        this.f6706a = uri;
        this.f6707b = c0123p;
        this.f6708c = str;
        this.f6709d = str2;
        this.e = str3;
        this.f6710f = str4;
    }
}
