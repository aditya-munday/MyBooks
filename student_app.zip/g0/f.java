package g0;

import E2.I;
import E2.Z;
import V.AbstractC0133a;
import android.net.Uri;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* loaded from: classes.dex */
public final class f {

    /* renamed from: a, reason: collision with root package name */
    public final String f6650a;

    /* renamed from: b, reason: collision with root package name */
    public final Uri f6651b;

    /* renamed from: c, reason: collision with root package name */
    public final Uri f6652c;

    /* renamed from: d, reason: collision with root package name */
    public final long f6653d;
    public final long e;

    /* renamed from: f, reason: collision with root package name */
    public final long f6654f;

    /* renamed from: g, reason: collision with root package name */
    public final long f6655g;

    /* renamed from: h, reason: collision with root package name */
    public final List f6656h;

    /* renamed from: i, reason: collision with root package name */
    public final boolean f6657i;

    /* renamed from: j, reason: collision with root package name */
    public final long f6658j;

    /* renamed from: k, reason: collision with root package name */
    public final long f6659k;

    /* renamed from: l, reason: collision with root package name */
    public final I f6660l;

    /* renamed from: m, reason: collision with root package name */
    public final I f6661m;

    /* renamed from: n, reason: collision with root package name */
    public final Z f6662n;
    public final boolean o;

    /* renamed from: p, reason: collision with root package name */
    public final String f6663p;

    /* renamed from: q, reason: collision with root package name */
    public final String f6664q;

    public f(String str, Uri uri, Uri uri2, long j6, long j7, long j8, long j9, ArrayList arrayList, boolean z6, long j10, long j11, ArrayList arrayList2, ArrayList arrayList3, ArrayList arrayList4, boolean z7, String str2, String str3) {
        AbstractC0133a.c((uri == null || uri2 == null) && !(uri == null && uri2 == null));
        this.f6650a = str;
        this.f6651b = uri;
        this.f6652c = uri2;
        this.f6653d = j6;
        this.e = j7;
        this.f6654f = j8;
        this.f6655g = j9;
        this.f6656h = arrayList;
        this.f6657i = z6;
        this.f6658j = j10;
        this.f6659k = j11;
        this.f6660l = I.u(arrayList2);
        this.f6661m = I.u(arrayList3);
        this.f6662n = I.A(new A.d(6), arrayList4);
        this.o = z7;
        this.f6663p = str2;
        this.f6664q = str3;
    }

    public final boolean equals(Object obj) {
        if (this != obj) {
            if (obj instanceof f) {
                f fVar = (f) obj;
                if (this.f6653d == fVar.f6653d && this.e == fVar.e && this.f6654f == fVar.f6654f && this.f6655g == fVar.f6655g && this.f6657i == fVar.f6657i && this.f6658j == fVar.f6658j && this.f6659k == fVar.f6659k && this.o == fVar.o && Objects.equals(this.f6650a, fVar.f6650a) && Objects.equals(this.f6651b, fVar.f6651b) && Objects.equals(this.f6652c, fVar.f6652c) && Objects.equals(this.f6656h, fVar.f6656h) && Objects.equals(this.f6660l, fVar.f6660l) && Objects.equals(this.f6661m, fVar.f6661m) && Objects.equals(this.f6662n, fVar.f6662n) && Objects.equals(this.f6663p, fVar.f6663p) && Objects.equals(this.f6664q, fVar.f6664q)) {
                    return true;
                }
                return false;
            }
            return false;
        }
        return true;
    }

    public final int hashCode() {
        return Objects.hash(this.f6650a, this.f6651b, this.f6652c, Long.valueOf(this.f6653d), Long.valueOf(this.e), Long.valueOf(this.f6654f), Long.valueOf(this.f6655g), this.f6656h, Boolean.valueOf(this.f6657i), Long.valueOf(this.f6658j), Long.valueOf(this.f6659k), this.f6660l, this.f6661m, this.f6662n, Boolean.valueOf(this.o), this.f6663p, this.f6664q);
    }
}
