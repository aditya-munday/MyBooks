package g0;

import android.net.Uri;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* loaded from: classes.dex */
public interface t {
    void a();

    boolean f(Uri uri, C.b bVar, boolean z6);
}
