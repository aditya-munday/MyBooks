package g0;

import S.C0120m;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* loaded from: classes.dex */
public final class g extends j {

    /* renamed from: A, reason: collision with root package name */
    public final boolean f6665A;

    /* renamed from: z, reason: collision with root package name */
    public final boolean f6666z;

    public g(String str, i iVar, long j6, int i6, long j7, C0120m c0120m, String str2, String str3, long j8, long j9, boolean z6, boolean z7, boolean z8) {
        super(str, iVar, j6, i6, j7, c0120m, str2, str3, j8, j9, z6);
        this.f6666z = z7;
        this.f6665A = z8;
    }
}
