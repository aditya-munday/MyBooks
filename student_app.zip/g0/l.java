package g0;

import E2.I;
import E2.e0;
import S.C0120m;
import java.util.List;
import java.util.Map;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* loaded from: classes.dex */
public final class l extends p {

    /* renamed from: d, reason: collision with root package name */
    public final int f6685d;
    public final long e;

    /* renamed from: f, reason: collision with root package name */
    public final boolean f6686f;

    /* renamed from: g, reason: collision with root package name */
    public final boolean f6687g;

    /* renamed from: h, reason: collision with root package name */
    public final long f6688h;

    /* renamed from: i, reason: collision with root package name */
    public final boolean f6689i;

    /* renamed from: j, reason: collision with root package name */
    public final int f6690j;

    /* renamed from: k, reason: collision with root package name */
    public final long f6691k;

    /* renamed from: l, reason: collision with root package name */
    public final int f6692l;

    /* renamed from: m, reason: collision with root package name */
    public final long f6693m;

    /* renamed from: n, reason: collision with root package name */
    public final long f6694n;
    public final boolean o;

    /* renamed from: p, reason: collision with root package name */
    public final boolean f6695p;

    /* renamed from: q, reason: collision with root package name */
    public final C0120m f6696q;

    /* renamed from: r, reason: collision with root package name */
    public final I f6697r;

    /* renamed from: s, reason: collision with root package name */
    public final I f6698s;

    /* renamed from: t, reason: collision with root package name */
    public final e0 f6699t;

    /* renamed from: u, reason: collision with root package name */
    public final long f6700u;

    /* renamed from: v, reason: collision with root package name */
    public final k f6701v;

    /* renamed from: w, reason: collision with root package name */
    public final I f6702w;

    public l(int i6, String str, List list, long j6, boolean z6, long j7, boolean z7, int i7, long j8, int i8, long j9, long j10, boolean z8, boolean z9, boolean z10, C0120m c0120m, List list2, List list3, k kVar, Map map, List list4) {
        super(str, list, z8);
        this.f6685d = i6;
        this.f6688h = j7;
        this.f6687g = z6;
        this.f6689i = z7;
        this.f6690j = i7;
        this.f6691k = j8;
        this.f6692l = i8;
        this.f6693m = j9;
        this.f6694n = j10;
        this.o = z9;
        this.f6695p = z10;
        this.f6696q = c0120m;
        this.f6697r = I.u(list2);
        this.f6698s = I.u(list3);
        this.f6699t = e0.a(map);
        this.f6702w = I.u(list4);
        if (!list3.isEmpty()) {
            g gVar = (g) E2.r.j(list3);
            this.f6700u = gVar.f6675s + gVar.f6673q;
        } else if (!list2.isEmpty()) {
            i iVar = (i) E2.r.j(list2);
            this.f6700u = iVar.f6675s + iVar.f6673q;
        } else {
            this.f6700u = 0L;
        }
        long j11 = -9223372036854775807L;
        if (j6 != -9223372036854775807L) {
            if (j6 >= 0) {
                j11 = Math.min(this.f6700u, j6);
            } else {
                j11 = Math.max(0L, this.f6700u + j6);
            }
        }
        this.e = j11;
        this.f6686f = j6 >= 0;
        this.f6701v = kVar;
    }

    @Override // k0.InterfaceC0525a
    public final Object a(List list) {
        return this;
    }
}
