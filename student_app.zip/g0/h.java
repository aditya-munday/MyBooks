package g0;

import android.net.Uri;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* loaded from: classes.dex */
public final class h {

    /* renamed from: a, reason: collision with root package name */
    public final Uri f6667a;

    /* renamed from: b, reason: collision with root package name */
    public final long f6668b;

    /* renamed from: c, reason: collision with root package name */
    public final int f6669c;

    public h(int i6, long j6, Uri uri) {
        this.f6667a = uri;
        this.f6668b = j6;
        this.f6669c = i6;
    }
}
