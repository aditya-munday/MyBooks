package Q5;

import C4.AbstractC0034i;
import E2.e0;
import H2.c;
import J.C0084d;
import J.C0086f;
import J.C0090j;
import J2.k;
import M4.b;
import M4.f;
import M4.l;
import V.AbstractC0133a;
import V.u;
import V4.n;
import a.AbstractC0194a;
import android.net.Uri;
import android.net.http.SslCertificate;
import android.os.Build;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.webkit.ClientCertRequest;
import android.webkit.WebSettings;
import android.widget.EdgeEffect;
import androidx.datastore.preferences.protobuf.AbstractC0227o;
import androidx.datastore.preferences.protobuf.C0219g;
import androidx.datastore.preferences.protobuf.b0;
import b3.C0261a;
import b3.C0267g;
import b3.C0268h;
import b3.C0269i;
import b3.C0277q;
import c5.C0326O;
import c5.C0345i;
import com.google.crypto.tink.shaded.protobuf.AbstractC0370h;
import d0.C0391b;
import d0.m;
import defpackage.g;
import g5.C0455d;
import h5.AbstractC0469c;
import i5.d;
import i5.i;
import j2.C0508g;
import j5.EnumC0522a;
import java.io.Closeable;
import java.lang.reflect.Array;
import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Proxy;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.FloatBuffer;
import java.security.PrivateKey;
import java.security.cert.X509Certificate;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import k5.AbstractC0560a;
import k5.AbstractC0562c;
import org.apache.tika.fork.ContentHandlerProxy;
import org.apache.tika.fork.ForkServer;
import org.apache.tika.mime.MimeTypesReaderMetKeys;
import org.json.JSONArray;
import org.json.JSONObject;
import p.e;
import p.j;
import p5.p;
import q5.h;
import t5.C0797b;
import v3.s;
import v3.t;
import x5.AbstractC0894a;
import x5.AbstractC0911s;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* loaded from: classes.dex */
public abstract class a {
    public static int B(u uVar, int i6, int i7, int i8) {
        boolean z6;
        if (Math.max(Math.max(i6, i7), i8) <= 31) {
            z6 = true;
        } else {
            z6 = false;
        }
        AbstractC0133a.c(z6);
        int i9 = (1 << i6) - 1;
        int i10 = (1 << i7) - 1;
        i(i(i9, i10), 1 << i8);
        if (uVar.b() >= i6) {
            int i11 = uVar.i(i6);
            if (i11 == i9) {
                if (uVar.b() >= i7) {
                    int i12 = uVar.i(i7);
                    i11 += i12;
                    if (i12 == i10) {
                        if (uVar.b() < i8) {
                            return -1;
                        }
                        return uVar.i(i8) + i11;
                    }
                } else {
                    return -1;
                }
            }
            return i11;
        }
        return -1;
    }

    public static HashMap C(t tVar) {
        int parseInt;
        long parseLong;
        Uri uri;
        HashMap hashMap = new HashMap();
        HashMap hashMap2 = new HashMap();
        String string = tVar.o.getString("collapse_key");
        Bundle bundle = tVar.o;
        if (string != null) {
            hashMap.put("collapseKey", bundle.getString("collapse_key"));
        }
        if (bundle.getString("from") != null) {
            hashMap.put("from", bundle.getString("from"));
        }
        if (bundle.getString("google.to") != null) {
            hashMap.put("to", bundle.getString("google.to"));
        }
        if (tVar.b() != null) {
            hashMap.put("messageId", tVar.b());
        }
        if (bundle.getString("message_type") != null) {
            hashMap.put("messageType", bundle.getString("message_type"));
        }
        if (!((j) tVar.a()).isEmpty()) {
            for (Map.Entry entry : ((e) tVar.a()).entrySet()) {
                hashMap2.put((String) entry.getKey(), entry.getValue());
            }
        }
        hashMap.put("data", hashMap2);
        Object obj = bundle.get("google.ttl");
        if (obj instanceof Integer) {
            parseInt = ((Integer) obj).intValue();
        } else {
            if (obj instanceof String) {
                try {
                    parseInt = Integer.parseInt((String) obj);
                } catch (NumberFormatException unused) {
                    Log.w("FirebaseMessaging", "Invalid TTL: " + obj);
                }
            }
            parseInt = 0;
        }
        hashMap.put("ttl", Integer.valueOf(parseInt));
        Object obj2 = bundle.get("google.sent_time");
        if (obj2 instanceof Long) {
            parseLong = ((Long) obj2).longValue();
        } else {
            if (obj2 instanceof String) {
                try {
                    parseLong = Long.parseLong((String) obj2);
                } catch (NumberFormatException unused2) {
                    Log.w("FirebaseMessaging", "Invalid sent time: " + obj2);
                }
            }
            parseLong = 0;
        }
        hashMap.put("sentTime", Long.valueOf(parseLong));
        if (tVar.c() != null) {
            s c6 = tVar.c();
            HashMap hashMap3 = new HashMap();
            HashMap hashMap4 = new HashMap();
            String str = c6.f10009a;
            String str2 = c6.f10015h;
            if (str != null) {
                hashMap3.put("title", str);
            }
            String str3 = c6.f10010b;
            if (str3 != null) {
                hashMap3.put("titleLocKey", str3);
            }
            String[] strArr = c6.f10011c;
            if (strArr != null) {
                hashMap3.put("titleLocArgs", Arrays.asList(strArr));
            }
            String str4 = c6.f10012d;
            if (str4 != null) {
                hashMap3.put("body", str4);
            }
            String str5 = c6.e;
            if (str5 != null) {
                hashMap3.put("bodyLocKey", str5);
            }
            String[] strArr2 = c6.f10013f;
            if (strArr2 != null) {
                hashMap3.put("bodyLocArgs", Arrays.asList(strArr2));
            }
            String str6 = c6.f10020m;
            if (str6 != null) {
                hashMap4.put("channelId", str6);
            }
            String str7 = c6.f10019l;
            if (str7 != null) {
                hashMap4.put("clickAction", str7);
            }
            String str8 = c6.f10018k;
            if (str8 != null) {
                hashMap4.put("color", str8);
            }
            String str9 = c6.f10014g;
            if (str9 != null) {
                hashMap4.put("smallIcon", str9);
            }
            Uri uri2 = null;
            if (str2 != null) {
                uri = Uri.parse(str2);
            } else {
                uri = null;
            }
            if (uri != null) {
                if (str2 != null) {
                    uri2 = Uri.parse(str2);
                }
                hashMap4.put("imageUrl", uri2.toString());
            }
            Uri uri3 = c6.f10021n;
            if (uri3 != null) {
                hashMap4.put("link", uri3.toString());
            }
            Integer num = c6.f10024r;
            if (num != null) {
                hashMap4.put("count", num);
            }
            Integer num2 = c6.f10022p;
            if (num2 != null) {
                hashMap4.put(MimeTypesReaderMetKeys.MAGIC_PRIORITY_ATTR, num2);
            }
            String str10 = c6.f10016i;
            if (str10 != null) {
                hashMap4.put("sound", str10);
            }
            String str11 = c6.o;
            if (str11 != null) {
                hashMap4.put("ticker", str11);
            }
            Integer num3 = c6.f10023q;
            if (num3 != null) {
                hashMap4.put("visibility", num3);
            }
            String str12 = c6.f10017j;
            if (str12 != null) {
                hashMap4.put("tag", str12);
            }
            hashMap3.put("android", hashMap4);
            hashMap.put("notification", hashMap3);
        }
        return hashMap;
    }

    public static int D(long j6) {
        if (j6 > 2147483647L) {
            return Integer.MAX_VALUE;
        }
        if (j6 < -2147483648L) {
            return Integer.MIN_VALUE;
        }
        return (int) j6;
    }

    public static void E(f fVar, final C0345i c0345i) {
        l gVar;
        k kVar;
        h.e(fVar, "binaryMessenger");
        if (c0345i != null && (kVar = c0345i.f5619a) != null) {
            gVar = kVar.f();
        } else {
            gVar = new g(2);
        }
        v3.u uVar = new v3.u(fVar, "dev.flutter.pigeon.webview_flutter_android.ClientCertRequest.cancel", gVar, (C0508g) null);
        if (c0345i != null) {
            final int i6 = 0;
            uVar.y(new b() { // from class: c5.z
                @Override // M4.b
                public final void e(Object obj, A.c cVar) {
                    List T6;
                    List T7;
                    List T8;
                    switch (i6) {
                        case 0:
                            C0345i c0345i2 = c0345i;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            Object obj2 = ((List) obj).get(0);
                            q5.h.c(obj2, "null cannot be cast to non-null type android.webkit.ClientCertRequest");
                            ClientCertRequest clientCertRequest = (ClientCertRequest) obj2;
                            try {
                                c0345i2.getClass();
                                clientCertRequest.cancel();
                                T6 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th) {
                                if (th instanceof C0337a) {
                                    C0337a c0337a = th;
                                    T6 = h5.e.T(c0337a.o, c0337a.f5592p, c0337a.f5593q);
                                } else {
                                    T6 = h5.e.T(th.getClass().getSimpleName(), th.toString(), AbstractC0034i.k("Cause: ", th.getCause(), ", Stacktrace: ", Log.getStackTraceString(th)));
                                }
                            }
                            cVar.g(T6);
                            return;
                        case 1:
                            C0345i c0345i3 = c0345i;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            Object obj3 = ((List) obj).get(0);
                            q5.h.c(obj3, "null cannot be cast to non-null type android.webkit.ClientCertRequest");
                            ClientCertRequest clientCertRequest2 = (ClientCertRequest) obj3;
                            try {
                                c0345i3.getClass();
                                clientCertRequest2.ignore();
                                T7 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th2) {
                                if (th2 instanceof C0337a) {
                                    C0337a c0337a2 = th2;
                                    T7 = h5.e.T(c0337a2.o, c0337a2.f5592p, c0337a2.f5593q);
                                } else {
                                    T7 = h5.e.T(th2.getClass().getSimpleName(), th2.toString(), AbstractC0034i.k("Cause: ", th2.getCause(), ", Stacktrace: ", Log.getStackTraceString(th2)));
                                }
                            }
                            cVar.g(T7);
                            return;
                        default:
                            C0345i c0345i4 = c0345i;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list = (List) obj;
                            Object obj4 = list.get(0);
                            q5.h.c(obj4, "null cannot be cast to non-null type android.webkit.ClientCertRequest");
                            ClientCertRequest clientCertRequest3 = (ClientCertRequest) obj4;
                            Object obj5 = list.get(1);
                            q5.h.c(obj5, "null cannot be cast to non-null type java.security.PrivateKey");
                            PrivateKey privateKey = (PrivateKey) obj5;
                            Object obj6 = list.get(2);
                            q5.h.c(obj6, "null cannot be cast to non-null type kotlin.collections.List<java.security.cert.X509Certificate>");
                            List list2 = (List) obj6;
                            try {
                                c0345i4.getClass();
                                clientCertRequest3.proceed(privateKey, (X509Certificate[]) list2.toArray(new X509Certificate[0]));
                                T8 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th3) {
                                if (th3 instanceof C0337a) {
                                    C0337a c0337a3 = th3;
                                    T8 = h5.e.T(c0337a3.o, c0337a3.f5592p, c0337a3.f5593q);
                                } else {
                                    T8 = h5.e.T(th3.getClass().getSimpleName(), th3.toString(), AbstractC0034i.k("Cause: ", th3.getCause(), ", Stacktrace: ", Log.getStackTraceString(th3)));
                                }
                            }
                            cVar.g(T8);
                            return;
                    }
                }
            });
        } else {
            uVar.y(null);
        }
        v3.u uVar2 = new v3.u(fVar, "dev.flutter.pigeon.webview_flutter_android.ClientCertRequest.ignore", gVar, (C0508g) null);
        if (c0345i != null) {
            final int i7 = 1;
            uVar2.y(new b() { // from class: c5.z
                @Override // M4.b
                public final void e(Object obj, A.c cVar) {
                    List T6;
                    List T7;
                    List T8;
                    switch (i7) {
                        case 0:
                            C0345i c0345i2 = c0345i;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            Object obj2 = ((List) obj).get(0);
                            q5.h.c(obj2, "null cannot be cast to non-null type android.webkit.ClientCertRequest");
                            ClientCertRequest clientCertRequest = (ClientCertRequest) obj2;
                            try {
                                c0345i2.getClass();
                                clientCertRequest.cancel();
                                T6 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th) {
                                if (th instanceof C0337a) {
                                    C0337a c0337a = th;
                                    T6 = h5.e.T(c0337a.o, c0337a.f5592p, c0337a.f5593q);
                                } else {
                                    T6 = h5.e.T(th.getClass().getSimpleName(), th.toString(), AbstractC0034i.k("Cause: ", th.getCause(), ", Stacktrace: ", Log.getStackTraceString(th)));
                                }
                            }
                            cVar.g(T6);
                            return;
                        case 1:
                            C0345i c0345i3 = c0345i;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            Object obj3 = ((List) obj).get(0);
                            q5.h.c(obj3, "null cannot be cast to non-null type android.webkit.ClientCertRequest");
                            ClientCertRequest clientCertRequest2 = (ClientCertRequest) obj3;
                            try {
                                c0345i3.getClass();
                                clientCertRequest2.ignore();
                                T7 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th2) {
                                if (th2 instanceof C0337a) {
                                    C0337a c0337a2 = th2;
                                    T7 = h5.e.T(c0337a2.o, c0337a2.f5592p, c0337a2.f5593q);
                                } else {
                                    T7 = h5.e.T(th2.getClass().getSimpleName(), th2.toString(), AbstractC0034i.k("Cause: ", th2.getCause(), ", Stacktrace: ", Log.getStackTraceString(th2)));
                                }
                            }
                            cVar.g(T7);
                            return;
                        default:
                            C0345i c0345i4 = c0345i;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list = (List) obj;
                            Object obj4 = list.get(0);
                            q5.h.c(obj4, "null cannot be cast to non-null type android.webkit.ClientCertRequest");
                            ClientCertRequest clientCertRequest3 = (ClientCertRequest) obj4;
                            Object obj5 = list.get(1);
                            q5.h.c(obj5, "null cannot be cast to non-null type java.security.PrivateKey");
                            PrivateKey privateKey = (PrivateKey) obj5;
                            Object obj6 = list.get(2);
                            q5.h.c(obj6, "null cannot be cast to non-null type kotlin.collections.List<java.security.cert.X509Certificate>");
                            List list2 = (List) obj6;
                            try {
                                c0345i4.getClass();
                                clientCertRequest3.proceed(privateKey, (X509Certificate[]) list2.toArray(new X509Certificate[0]));
                                T8 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th3) {
                                if (th3 instanceof C0337a) {
                                    C0337a c0337a3 = th3;
                                    T8 = h5.e.T(c0337a3.o, c0337a3.f5592p, c0337a3.f5593q);
                                } else {
                                    T8 = h5.e.T(th3.getClass().getSimpleName(), th3.toString(), AbstractC0034i.k("Cause: ", th3.getCause(), ", Stacktrace: ", Log.getStackTraceString(th3)));
                                }
                            }
                            cVar.g(T8);
                            return;
                    }
                }
            });
        } else {
            uVar2.y(null);
        }
        v3.u uVar3 = new v3.u(fVar, "dev.flutter.pigeon.webview_flutter_android.ClientCertRequest.proceed", gVar, (C0508g) null);
        if (c0345i != null) {
            final int i8 = 2;
            uVar3.y(new b() { // from class: c5.z
                @Override // M4.b
                public final void e(Object obj, A.c cVar) {
                    List T6;
                    List T7;
                    List T8;
                    switch (i8) {
                        case 0:
                            C0345i c0345i2 = c0345i;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            Object obj2 = ((List) obj).get(0);
                            q5.h.c(obj2, "null cannot be cast to non-null type android.webkit.ClientCertRequest");
                            ClientCertRequest clientCertRequest = (ClientCertRequest) obj2;
                            try {
                                c0345i2.getClass();
                                clientCertRequest.cancel();
                                T6 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th) {
                                if (th instanceof C0337a) {
                                    C0337a c0337a = th;
                                    T6 = h5.e.T(c0337a.o, c0337a.f5592p, c0337a.f5593q);
                                } else {
                                    T6 = h5.e.T(th.getClass().getSimpleName(), th.toString(), AbstractC0034i.k("Cause: ", th.getCause(), ", Stacktrace: ", Log.getStackTraceString(th)));
                                }
                            }
                            cVar.g(T6);
                            return;
                        case 1:
                            C0345i c0345i3 = c0345i;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            Object obj3 = ((List) obj).get(0);
                            q5.h.c(obj3, "null cannot be cast to non-null type android.webkit.ClientCertRequest");
                            ClientCertRequest clientCertRequest2 = (ClientCertRequest) obj3;
                            try {
                                c0345i3.getClass();
                                clientCertRequest2.ignore();
                                T7 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th2) {
                                if (th2 instanceof C0337a) {
                                    C0337a c0337a2 = th2;
                                    T7 = h5.e.T(c0337a2.o, c0337a2.f5592p, c0337a2.f5593q);
                                } else {
                                    T7 = h5.e.T(th2.getClass().getSimpleName(), th2.toString(), AbstractC0034i.k("Cause: ", th2.getCause(), ", Stacktrace: ", Log.getStackTraceString(th2)));
                                }
                            }
                            cVar.g(T7);
                            return;
                        default:
                            C0345i c0345i4 = c0345i;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list = (List) obj;
                            Object obj4 = list.get(0);
                            q5.h.c(obj4, "null cannot be cast to non-null type android.webkit.ClientCertRequest");
                            ClientCertRequest clientCertRequest3 = (ClientCertRequest) obj4;
                            Object obj5 = list.get(1);
                            q5.h.c(obj5, "null cannot be cast to non-null type java.security.PrivateKey");
                            PrivateKey privateKey = (PrivateKey) obj5;
                            Object obj6 = list.get(2);
                            q5.h.c(obj6, "null cannot be cast to non-null type kotlin.collections.List<java.security.cert.X509Certificate>");
                            List list2 = (List) obj6;
                            try {
                                c0345i4.getClass();
                                clientCertRequest3.proceed(privateKey, (X509Certificate[]) list2.toArray(new X509Certificate[0]));
                                T8 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th3) {
                                if (th3 instanceof C0337a) {
                                    C0337a c0337a3 = th3;
                                    T8 = h5.e.T(c0337a3.o, c0337a3.f5592p, c0337a3.f5593q);
                                } else {
                                    T8 = h5.e.T(th3.getClass().getSimpleName(), th3.toString(), AbstractC0034i.k("Cause: ", th3.getCause(), ", Stacktrace: ", Log.getStackTraceString(th3)));
                                }
                            }
                            cVar.g(T8);
                            return;
                    }
                }
            });
        } else {
            uVar3.y(null);
        }
    }

    public static void F(f fVar, final C0326O c0326o) {
        l gVar;
        k kVar;
        h.e(fVar, "binaryMessenger");
        if (c0326o != null && (kVar = (k) c0326o.f604b) != null) {
            gVar = kVar.f();
        } else {
            gVar = new g(2);
        }
        v3.u uVar = new v3.u(fVar, "dev.flutter.pigeon.webview_flutter_android.SslCertificate.getIssuedBy", gVar, (C0508g) null);
        if (c0326o != null) {
            final int i6 = 0;
            uVar.y(new b() { // from class: c5.E
                @Override // M4.b
                public final void e(Object obj, A.c cVar) {
                    List T6;
                    List T7;
                    List T8;
                    Long l6;
                    List T9;
                    Long l7;
                    List T10;
                    switch (i6) {
                        case 0:
                            D0.e eVar = c0326o;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            Object obj2 = ((List) obj).get(0);
                            q5.h.c(obj2, "null cannot be cast to non-null type android.net.http.SslCertificate");
                            SslCertificate sslCertificate = (SslCertificate) obj2;
                            try {
                                ((C0326O) eVar).getClass();
                                T6 = android.support.v4.media.session.a.z(sslCertificate.getIssuedBy());
                            } catch (Throwable th) {
                                if (th instanceof C0337a) {
                                    C0337a c0337a = th;
                                    T6 = h5.e.T(c0337a.o, c0337a.f5592p, c0337a.f5593q);
                                } else {
                                    T6 = h5.e.T(th.getClass().getSimpleName(), th.toString(), AbstractC0034i.k("Cause: ", th.getCause(), ", Stacktrace: ", Log.getStackTraceString(th)));
                                }
                            }
                            cVar.g(T6);
                            return;
                        case 1:
                            D0.e eVar2 = c0326o;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            Object obj3 = ((List) obj).get(0);
                            q5.h.c(obj3, "null cannot be cast to non-null type android.net.http.SslCertificate");
                            SslCertificate sslCertificate2 = (SslCertificate) obj3;
                            try {
                                ((C0326O) eVar2).getClass();
                                T7 = android.support.v4.media.session.a.z(sslCertificate2.getIssuedTo());
                            } catch (Throwable th2) {
                                if (th2 instanceof C0337a) {
                                    C0337a c0337a2 = th2;
                                    T7 = h5.e.T(c0337a2.o, c0337a2.f5592p, c0337a2.f5593q);
                                } else {
                                    T7 = h5.e.T(th2.getClass().getSimpleName(), th2.toString(), AbstractC0034i.k("Cause: ", th2.getCause(), ", Stacktrace: ", Log.getStackTraceString(th2)));
                                }
                            }
                            cVar.g(T7);
                            return;
                        case 2:
                            D0.e eVar3 = c0326o;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            Object obj4 = ((List) obj).get(0);
                            q5.h.c(obj4, "null cannot be cast to non-null type android.net.http.SslCertificate");
                            SslCertificate sslCertificate3 = (SslCertificate) obj4;
                            try {
                                ((C0326O) eVar3).getClass();
                                Date validNotAfterDate = sslCertificate3.getValidNotAfterDate();
                                if (validNotAfterDate != null) {
                                    l6 = Long.valueOf(validNotAfterDate.getTime());
                                } else {
                                    l6 = null;
                                }
                                T8 = android.support.v4.media.session.a.z(l6);
                            } catch (Throwable th3) {
                                if (th3 instanceof C0337a) {
                                    C0337a c0337a3 = th3;
                                    T8 = h5.e.T(c0337a3.o, c0337a3.f5592p, c0337a3.f5593q);
                                } else {
                                    T8 = h5.e.T(th3.getClass().getSimpleName(), th3.toString(), AbstractC0034i.k("Cause: ", th3.getCause(), ", Stacktrace: ", Log.getStackTraceString(th3)));
                                }
                            }
                            cVar.g(T8);
                            return;
                        case 3:
                            D0.e eVar4 = c0326o;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            Object obj5 = ((List) obj).get(0);
                            q5.h.c(obj5, "null cannot be cast to non-null type android.net.http.SslCertificate");
                            SslCertificate sslCertificate4 = (SslCertificate) obj5;
                            try {
                                ((C0326O) eVar4).getClass();
                                Date validNotBeforeDate = sslCertificate4.getValidNotBeforeDate();
                                if (validNotBeforeDate != null) {
                                    l7 = Long.valueOf(validNotBeforeDate.getTime());
                                } else {
                                    l7 = null;
                                }
                                T9 = android.support.v4.media.session.a.z(l7);
                            } catch (Throwable th4) {
                                if (th4 instanceof C0337a) {
                                    C0337a c0337a4 = th4;
                                    T9 = h5.e.T(c0337a4.o, c0337a4.f5592p, c0337a4.f5593q);
                                } else {
                                    T9 = h5.e.T(th4.getClass().getSimpleName(), th4.toString(), AbstractC0034i.k("Cause: ", th4.getCause(), ", Stacktrace: ", Log.getStackTraceString(th4)));
                                }
                            }
                            cVar.g(T9);
                            return;
                        default:
                            D0.e eVar5 = c0326o;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            Object obj6 = ((List) obj).get(0);
                            q5.h.c(obj6, "null cannot be cast to non-null type android.net.http.SslCertificate");
                            try {
                                T10 = android.support.v4.media.session.a.z(eVar5.k((SslCertificate) obj6));
                            } catch (Throwable th5) {
                                if (th5 instanceof C0337a) {
                                    C0337a c0337a5 = th5;
                                    T10 = h5.e.T(c0337a5.o, c0337a5.f5592p, c0337a5.f5593q);
                                } else {
                                    T10 = h5.e.T(th5.getClass().getSimpleName(), th5.toString(), AbstractC0034i.k("Cause: ", th5.getCause(), ", Stacktrace: ", Log.getStackTraceString(th5)));
                                }
                            }
                            cVar.g(T10);
                            return;
                    }
                }
            });
        } else {
            uVar.y(null);
        }
        v3.u uVar2 = new v3.u(fVar, "dev.flutter.pigeon.webview_flutter_android.SslCertificate.getIssuedTo", gVar, (C0508g) null);
        if (c0326o != null) {
            final int i7 = 1;
            uVar2.y(new b() { // from class: c5.E
                @Override // M4.b
                public final void e(Object obj, A.c cVar) {
                    List T6;
                    List T7;
                    List T8;
                    Long l6;
                    List T9;
                    Long l7;
                    List T10;
                    switch (i7) {
                        case 0:
                            D0.e eVar = c0326o;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            Object obj2 = ((List) obj).get(0);
                            q5.h.c(obj2, "null cannot be cast to non-null type android.net.http.SslCertificate");
                            SslCertificate sslCertificate = (SslCertificate) obj2;
                            try {
                                ((C0326O) eVar).getClass();
                                T6 = android.support.v4.media.session.a.z(sslCertificate.getIssuedBy());
                            } catch (Throwable th) {
                                if (th instanceof C0337a) {
                                    C0337a c0337a = th;
                                    T6 = h5.e.T(c0337a.o, c0337a.f5592p, c0337a.f5593q);
                                } else {
                                    T6 = h5.e.T(th.getClass().getSimpleName(), th.toString(), AbstractC0034i.k("Cause: ", th.getCause(), ", Stacktrace: ", Log.getStackTraceString(th)));
                                }
                            }
                            cVar.g(T6);
                            return;
                        case 1:
                            D0.e eVar2 = c0326o;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            Object obj3 = ((List) obj).get(0);
                            q5.h.c(obj3, "null cannot be cast to non-null type android.net.http.SslCertificate");
                            SslCertificate sslCertificate2 = (SslCertificate) obj3;
                            try {
                                ((C0326O) eVar2).getClass();
                                T7 = android.support.v4.media.session.a.z(sslCertificate2.getIssuedTo());
                            } catch (Throwable th2) {
                                if (th2 instanceof C0337a) {
                                    C0337a c0337a2 = th2;
                                    T7 = h5.e.T(c0337a2.o, c0337a2.f5592p, c0337a2.f5593q);
                                } else {
                                    T7 = h5.e.T(th2.getClass().getSimpleName(), th2.toString(), AbstractC0034i.k("Cause: ", th2.getCause(), ", Stacktrace: ", Log.getStackTraceString(th2)));
                                }
                            }
                            cVar.g(T7);
                            return;
                        case 2:
                            D0.e eVar3 = c0326o;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            Object obj4 = ((List) obj).get(0);
                            q5.h.c(obj4, "null cannot be cast to non-null type android.net.http.SslCertificate");
                            SslCertificate sslCertificate3 = (SslCertificate) obj4;
                            try {
                                ((C0326O) eVar3).getClass();
                                Date validNotAfterDate = sslCertificate3.getValidNotAfterDate();
                                if (validNotAfterDate != null) {
                                    l6 = Long.valueOf(validNotAfterDate.getTime());
                                } else {
                                    l6 = null;
                                }
                                T8 = android.support.v4.media.session.a.z(l6);
                            } catch (Throwable th3) {
                                if (th3 instanceof C0337a) {
                                    C0337a c0337a3 = th3;
                                    T8 = h5.e.T(c0337a3.o, c0337a3.f5592p, c0337a3.f5593q);
                                } else {
                                    T8 = h5.e.T(th3.getClass().getSimpleName(), th3.toString(), AbstractC0034i.k("Cause: ", th3.getCause(), ", Stacktrace: ", Log.getStackTraceString(th3)));
                                }
                            }
                            cVar.g(T8);
                            return;
                        case 3:
                            D0.e eVar4 = c0326o;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            Object obj5 = ((List) obj).get(0);
                            q5.h.c(obj5, "null cannot be cast to non-null type android.net.http.SslCertificate");
                            SslCertificate sslCertificate4 = (SslCertificate) obj5;
                            try {
                                ((C0326O) eVar4).getClass();
                                Date validNotBeforeDate = sslCertificate4.getValidNotBeforeDate();
                                if (validNotBeforeDate != null) {
                                    l7 = Long.valueOf(validNotBeforeDate.getTime());
                                } else {
                                    l7 = null;
                                }
                                T9 = android.support.v4.media.session.a.z(l7);
                            } catch (Throwable th4) {
                                if (th4 instanceof C0337a) {
                                    C0337a c0337a4 = th4;
                                    T9 = h5.e.T(c0337a4.o, c0337a4.f5592p, c0337a4.f5593q);
                                } else {
                                    T9 = h5.e.T(th4.getClass().getSimpleName(), th4.toString(), AbstractC0034i.k("Cause: ", th4.getCause(), ", Stacktrace: ", Log.getStackTraceString(th4)));
                                }
                            }
                            cVar.g(T9);
                            return;
                        default:
                            D0.e eVar5 = c0326o;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            Object obj6 = ((List) obj).get(0);
                            q5.h.c(obj6, "null cannot be cast to non-null type android.net.http.SslCertificate");
                            try {
                                T10 = android.support.v4.media.session.a.z(eVar5.k((SslCertificate) obj6));
                            } catch (Throwable th5) {
                                if (th5 instanceof C0337a) {
                                    C0337a c0337a5 = th5;
                                    T10 = h5.e.T(c0337a5.o, c0337a5.f5592p, c0337a5.f5593q);
                                } else {
                                    T10 = h5.e.T(th5.getClass().getSimpleName(), th5.toString(), AbstractC0034i.k("Cause: ", th5.getCause(), ", Stacktrace: ", Log.getStackTraceString(th5)));
                                }
                            }
                            cVar.g(T10);
                            return;
                    }
                }
            });
        } else {
            uVar2.y(null);
        }
        v3.u uVar3 = new v3.u(fVar, "dev.flutter.pigeon.webview_flutter_android.SslCertificate.getValidNotAfterMsSinceEpoch", gVar, (C0508g) null);
        if (c0326o != null) {
            final int i8 = 2;
            uVar3.y(new b() { // from class: c5.E
                @Override // M4.b
                public final void e(Object obj, A.c cVar) {
                    List T6;
                    List T7;
                    List T8;
                    Long l6;
                    List T9;
                    Long l7;
                    List T10;
                    switch (i8) {
                        case 0:
                            D0.e eVar = c0326o;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            Object obj2 = ((List) obj).get(0);
                            q5.h.c(obj2, "null cannot be cast to non-null type android.net.http.SslCertificate");
                            SslCertificate sslCertificate = (SslCertificate) obj2;
                            try {
                                ((C0326O) eVar).getClass();
                                T6 = android.support.v4.media.session.a.z(sslCertificate.getIssuedBy());
                            } catch (Throwable th) {
                                if (th instanceof C0337a) {
                                    C0337a c0337a = th;
                                    T6 = h5.e.T(c0337a.o, c0337a.f5592p, c0337a.f5593q);
                                } else {
                                    T6 = h5.e.T(th.getClass().getSimpleName(), th.toString(), AbstractC0034i.k("Cause: ", th.getCause(), ", Stacktrace: ", Log.getStackTraceString(th)));
                                }
                            }
                            cVar.g(T6);
                            return;
                        case 1:
                            D0.e eVar2 = c0326o;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            Object obj3 = ((List) obj).get(0);
                            q5.h.c(obj3, "null cannot be cast to non-null type android.net.http.SslCertificate");
                            SslCertificate sslCertificate2 = (SslCertificate) obj3;
                            try {
                                ((C0326O) eVar2).getClass();
                                T7 = android.support.v4.media.session.a.z(sslCertificate2.getIssuedTo());
                            } catch (Throwable th2) {
                                if (th2 instanceof C0337a) {
                                    C0337a c0337a2 = th2;
                                    T7 = h5.e.T(c0337a2.o, c0337a2.f5592p, c0337a2.f5593q);
                                } else {
                                    T7 = h5.e.T(th2.getClass().getSimpleName(), th2.toString(), AbstractC0034i.k("Cause: ", th2.getCause(), ", Stacktrace: ", Log.getStackTraceString(th2)));
                                }
                            }
                            cVar.g(T7);
                            return;
                        case 2:
                            D0.e eVar3 = c0326o;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            Object obj4 = ((List) obj).get(0);
                            q5.h.c(obj4, "null cannot be cast to non-null type android.net.http.SslCertificate");
                            SslCertificate sslCertificate3 = (SslCertificate) obj4;
                            try {
                                ((C0326O) eVar3).getClass();
                                Date validNotAfterDate = sslCertificate3.getValidNotAfterDate();
                                if (validNotAfterDate != null) {
                                    l6 = Long.valueOf(validNotAfterDate.getTime());
                                } else {
                                    l6 = null;
                                }
                                T8 = android.support.v4.media.session.a.z(l6);
                            } catch (Throwable th3) {
                                if (th3 instanceof C0337a) {
                                    C0337a c0337a3 = th3;
                                    T8 = h5.e.T(c0337a3.o, c0337a3.f5592p, c0337a3.f5593q);
                                } else {
                                    T8 = h5.e.T(th3.getClass().getSimpleName(), th3.toString(), AbstractC0034i.k("Cause: ", th3.getCause(), ", Stacktrace: ", Log.getStackTraceString(th3)));
                                }
                            }
                            cVar.g(T8);
                            return;
                        case 3:
                            D0.e eVar4 = c0326o;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            Object obj5 = ((List) obj).get(0);
                            q5.h.c(obj5, "null cannot be cast to non-null type android.net.http.SslCertificate");
                            SslCertificate sslCertificate4 = (SslCertificate) obj5;
                            try {
                                ((C0326O) eVar4).getClass();
                                Date validNotBeforeDate = sslCertificate4.getValidNotBeforeDate();
                                if (validNotBeforeDate != null) {
                                    l7 = Long.valueOf(validNotBeforeDate.getTime());
                                } else {
                                    l7 = null;
                                }
                                T9 = android.support.v4.media.session.a.z(l7);
                            } catch (Throwable th4) {
                                if (th4 instanceof C0337a) {
                                    C0337a c0337a4 = th4;
                                    T9 = h5.e.T(c0337a4.o, c0337a4.f5592p, c0337a4.f5593q);
                                } else {
                                    T9 = h5.e.T(th4.getClass().getSimpleName(), th4.toString(), AbstractC0034i.k("Cause: ", th4.getCause(), ", Stacktrace: ", Log.getStackTraceString(th4)));
                                }
                            }
                            cVar.g(T9);
                            return;
                        default:
                            D0.e eVar5 = c0326o;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            Object obj6 = ((List) obj).get(0);
                            q5.h.c(obj6, "null cannot be cast to non-null type android.net.http.SslCertificate");
                            try {
                                T10 = android.support.v4.media.session.a.z(eVar5.k((SslCertificate) obj6));
                            } catch (Throwable th5) {
                                if (th5 instanceof C0337a) {
                                    C0337a c0337a5 = th5;
                                    T10 = h5.e.T(c0337a5.o, c0337a5.f5592p, c0337a5.f5593q);
                                } else {
                                    T10 = h5.e.T(th5.getClass().getSimpleName(), th5.toString(), AbstractC0034i.k("Cause: ", th5.getCause(), ", Stacktrace: ", Log.getStackTraceString(th5)));
                                }
                            }
                            cVar.g(T10);
                            return;
                    }
                }
            });
        } else {
            uVar3.y(null);
        }
        v3.u uVar4 = new v3.u(fVar, "dev.flutter.pigeon.webview_flutter_android.SslCertificate.getValidNotBeforeMsSinceEpoch", gVar, (C0508g) null);
        if (c0326o != null) {
            final int i9 = 3;
            uVar4.y(new b() { // from class: c5.E
                @Override // M4.b
                public final void e(Object obj, A.c cVar) {
                    List T6;
                    List T7;
                    List T8;
                    Long l6;
                    List T9;
                    Long l7;
                    List T10;
                    switch (i9) {
                        case 0:
                            D0.e eVar = c0326o;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            Object obj2 = ((List) obj).get(0);
                            q5.h.c(obj2, "null cannot be cast to non-null type android.net.http.SslCertificate");
                            SslCertificate sslCertificate = (SslCertificate) obj2;
                            try {
                                ((C0326O) eVar).getClass();
                                T6 = android.support.v4.media.session.a.z(sslCertificate.getIssuedBy());
                            } catch (Throwable th) {
                                if (th instanceof C0337a) {
                                    C0337a c0337a = th;
                                    T6 = h5.e.T(c0337a.o, c0337a.f5592p, c0337a.f5593q);
                                } else {
                                    T6 = h5.e.T(th.getClass().getSimpleName(), th.toString(), AbstractC0034i.k("Cause: ", th.getCause(), ", Stacktrace: ", Log.getStackTraceString(th)));
                                }
                            }
                            cVar.g(T6);
                            return;
                        case 1:
                            D0.e eVar2 = c0326o;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            Object obj3 = ((List) obj).get(0);
                            q5.h.c(obj3, "null cannot be cast to non-null type android.net.http.SslCertificate");
                            SslCertificate sslCertificate2 = (SslCertificate) obj3;
                            try {
                                ((C0326O) eVar2).getClass();
                                T7 = android.support.v4.media.session.a.z(sslCertificate2.getIssuedTo());
                            } catch (Throwable th2) {
                                if (th2 instanceof C0337a) {
                                    C0337a c0337a2 = th2;
                                    T7 = h5.e.T(c0337a2.o, c0337a2.f5592p, c0337a2.f5593q);
                                } else {
                                    T7 = h5.e.T(th2.getClass().getSimpleName(), th2.toString(), AbstractC0034i.k("Cause: ", th2.getCause(), ", Stacktrace: ", Log.getStackTraceString(th2)));
                                }
                            }
                            cVar.g(T7);
                            return;
                        case 2:
                            D0.e eVar3 = c0326o;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            Object obj4 = ((List) obj).get(0);
                            q5.h.c(obj4, "null cannot be cast to non-null type android.net.http.SslCertificate");
                            SslCertificate sslCertificate3 = (SslCertificate) obj4;
                            try {
                                ((C0326O) eVar3).getClass();
                                Date validNotAfterDate = sslCertificate3.getValidNotAfterDate();
                                if (validNotAfterDate != null) {
                                    l6 = Long.valueOf(validNotAfterDate.getTime());
                                } else {
                                    l6 = null;
                                }
                                T8 = android.support.v4.media.session.a.z(l6);
                            } catch (Throwable th3) {
                                if (th3 instanceof C0337a) {
                                    C0337a c0337a3 = th3;
                                    T8 = h5.e.T(c0337a3.o, c0337a3.f5592p, c0337a3.f5593q);
                                } else {
                                    T8 = h5.e.T(th3.getClass().getSimpleName(), th3.toString(), AbstractC0034i.k("Cause: ", th3.getCause(), ", Stacktrace: ", Log.getStackTraceString(th3)));
                                }
                            }
                            cVar.g(T8);
                            return;
                        case 3:
                            D0.e eVar4 = c0326o;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            Object obj5 = ((List) obj).get(0);
                            q5.h.c(obj5, "null cannot be cast to non-null type android.net.http.SslCertificate");
                            SslCertificate sslCertificate4 = (SslCertificate) obj5;
                            try {
                                ((C0326O) eVar4).getClass();
                                Date validNotBeforeDate = sslCertificate4.getValidNotBeforeDate();
                                if (validNotBeforeDate != null) {
                                    l7 = Long.valueOf(validNotBeforeDate.getTime());
                                } else {
                                    l7 = null;
                                }
                                T9 = android.support.v4.media.session.a.z(l7);
                            } catch (Throwable th4) {
                                if (th4 instanceof C0337a) {
                                    C0337a c0337a4 = th4;
                                    T9 = h5.e.T(c0337a4.o, c0337a4.f5592p, c0337a4.f5593q);
                                } else {
                                    T9 = h5.e.T(th4.getClass().getSimpleName(), th4.toString(), AbstractC0034i.k("Cause: ", th4.getCause(), ", Stacktrace: ", Log.getStackTraceString(th4)));
                                }
                            }
                            cVar.g(T9);
                            return;
                        default:
                            D0.e eVar5 = c0326o;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            Object obj6 = ((List) obj).get(0);
                            q5.h.c(obj6, "null cannot be cast to non-null type android.net.http.SslCertificate");
                            try {
                                T10 = android.support.v4.media.session.a.z(eVar5.k((SslCertificate) obj6));
                            } catch (Throwable th5) {
                                if (th5 instanceof C0337a) {
                                    C0337a c0337a5 = th5;
                                    T10 = h5.e.T(c0337a5.o, c0337a5.f5592p, c0337a5.f5593q);
                                } else {
                                    T10 = h5.e.T(th5.getClass().getSimpleName(), th5.toString(), AbstractC0034i.k("Cause: ", th5.getCause(), ", Stacktrace: ", Log.getStackTraceString(th5)));
                                }
                            }
                            cVar.g(T10);
                            return;
                    }
                }
            });
        } else {
            uVar4.y(null);
        }
        v3.u uVar5 = new v3.u(fVar, "dev.flutter.pigeon.webview_flutter_android.SslCertificate.getX509Certificate", gVar, (C0508g) null);
        if (c0326o != null) {
            final int i10 = 4;
            uVar5.y(new b() { // from class: c5.E
                @Override // M4.b
                public final void e(Object obj, A.c cVar) {
                    List T6;
                    List T7;
                    List T8;
                    Long l6;
                    List T9;
                    Long l7;
                    List T10;
                    switch (i10) {
                        case 0:
                            D0.e eVar = c0326o;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            Object obj2 = ((List) obj).get(0);
                            q5.h.c(obj2, "null cannot be cast to non-null type android.net.http.SslCertificate");
                            SslCertificate sslCertificate = (SslCertificate) obj2;
                            try {
                                ((C0326O) eVar).getClass();
                                T6 = android.support.v4.media.session.a.z(sslCertificate.getIssuedBy());
                            } catch (Throwable th) {
                                if (th instanceof C0337a) {
                                    C0337a c0337a = th;
                                    T6 = h5.e.T(c0337a.o, c0337a.f5592p, c0337a.f5593q);
                                } else {
                                    T6 = h5.e.T(th.getClass().getSimpleName(), th.toString(), AbstractC0034i.k("Cause: ", th.getCause(), ", Stacktrace: ", Log.getStackTraceString(th)));
                                }
                            }
                            cVar.g(T6);
                            return;
                        case 1:
                            D0.e eVar2 = c0326o;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            Object obj3 = ((List) obj).get(0);
                            q5.h.c(obj3, "null cannot be cast to non-null type android.net.http.SslCertificate");
                            SslCertificate sslCertificate2 = (SslCertificate) obj3;
                            try {
                                ((C0326O) eVar2).getClass();
                                T7 = android.support.v4.media.session.a.z(sslCertificate2.getIssuedTo());
                            } catch (Throwable th2) {
                                if (th2 instanceof C0337a) {
                                    C0337a c0337a2 = th2;
                                    T7 = h5.e.T(c0337a2.o, c0337a2.f5592p, c0337a2.f5593q);
                                } else {
                                    T7 = h5.e.T(th2.getClass().getSimpleName(), th2.toString(), AbstractC0034i.k("Cause: ", th2.getCause(), ", Stacktrace: ", Log.getStackTraceString(th2)));
                                }
                            }
                            cVar.g(T7);
                            return;
                        case 2:
                            D0.e eVar3 = c0326o;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            Object obj4 = ((List) obj).get(0);
                            q5.h.c(obj4, "null cannot be cast to non-null type android.net.http.SslCertificate");
                            SslCertificate sslCertificate3 = (SslCertificate) obj4;
                            try {
                                ((C0326O) eVar3).getClass();
                                Date validNotAfterDate = sslCertificate3.getValidNotAfterDate();
                                if (validNotAfterDate != null) {
                                    l6 = Long.valueOf(validNotAfterDate.getTime());
                                } else {
                                    l6 = null;
                                }
                                T8 = android.support.v4.media.session.a.z(l6);
                            } catch (Throwable th3) {
                                if (th3 instanceof C0337a) {
                                    C0337a c0337a3 = th3;
                                    T8 = h5.e.T(c0337a3.o, c0337a3.f5592p, c0337a3.f5593q);
                                } else {
                                    T8 = h5.e.T(th3.getClass().getSimpleName(), th3.toString(), AbstractC0034i.k("Cause: ", th3.getCause(), ", Stacktrace: ", Log.getStackTraceString(th3)));
                                }
                            }
                            cVar.g(T8);
                            return;
                        case 3:
                            D0.e eVar4 = c0326o;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            Object obj5 = ((List) obj).get(0);
                            q5.h.c(obj5, "null cannot be cast to non-null type android.net.http.SslCertificate");
                            SslCertificate sslCertificate4 = (SslCertificate) obj5;
                            try {
                                ((C0326O) eVar4).getClass();
                                Date validNotBeforeDate = sslCertificate4.getValidNotBeforeDate();
                                if (validNotBeforeDate != null) {
                                    l7 = Long.valueOf(validNotBeforeDate.getTime());
                                } else {
                                    l7 = null;
                                }
                                T9 = android.support.v4.media.session.a.z(l7);
                            } catch (Throwable th4) {
                                if (th4 instanceof C0337a) {
                                    C0337a c0337a4 = th4;
                                    T9 = h5.e.T(c0337a4.o, c0337a4.f5592p, c0337a4.f5593q);
                                } else {
                                    T9 = h5.e.T(th4.getClass().getSimpleName(), th4.toString(), AbstractC0034i.k("Cause: ", th4.getCause(), ", Stacktrace: ", Log.getStackTraceString(th4)));
                                }
                            }
                            cVar.g(T9);
                            return;
                        default:
                            D0.e eVar5 = c0326o;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            Object obj6 = ((List) obj).get(0);
                            q5.h.c(obj6, "null cannot be cast to non-null type android.net.http.SslCertificate");
                            try {
                                T10 = android.support.v4.media.session.a.z(eVar5.k((SslCertificate) obj6));
                            } catch (Throwable th5) {
                                if (th5 instanceof C0337a) {
                                    C0337a c0337a5 = th5;
                                    T10 = h5.e.T(c0337a5.o, c0337a5.f5592p, c0337a5.f5593q);
                                } else {
                                    T10 = h5.e.T(th5.getClass().getSimpleName(), th5.toString(), AbstractC0034i.k("Cause: ", th5.getCause(), ", Stacktrace: ", Log.getStackTraceString(th5)));
                                }
                            }
                            cVar.g(T10);
                            return;
                    }
                }
            });
        } else {
            uVar5.y(null);
        }
    }

    public static void G(f fVar, final C0345i c0345i) {
        l gVar;
        k kVar;
        h.e(fVar, "binaryMessenger");
        if (c0345i != null && (kVar = c0345i.f5619a) != null) {
            gVar = kVar.f();
        } else {
            gVar = new g(2);
        }
        v3.u uVar = new v3.u(fVar, "dev.flutter.pigeon.webview_flutter_android.WebSettings.setDomStorageEnabled", gVar, (C0508g) null);
        if (c0345i != null) {
            final int i6 = 0;
            uVar.y(new b() { // from class: c5.J
                @Override // M4.b
                public final void e(Object obj, A.c cVar) {
                    List T6;
                    List T7;
                    List T8;
                    List T9;
                    List T10;
                    List T11;
                    List T12;
                    List T13;
                    List T14;
                    List T15;
                    List T16;
                    List T17;
                    List T18;
                    List T19;
                    List T20;
                    List T21;
                    List T22;
                    switch (i6) {
                        case 0:
                            C0345i c0345i2 = c0345i;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list = (List) obj;
                            Object obj2 = list.get(0);
                            q5.h.c(obj2, "null cannot be cast to non-null type android.webkit.WebSettings");
                            WebSettings webSettings = (WebSettings) obj2;
                            Object obj3 = list.get(1);
                            q5.h.c(obj3, "null cannot be cast to non-null type kotlin.Boolean");
                            boolean booleanValue = ((Boolean) obj3).booleanValue();
                            try {
                                c0345i2.getClass();
                                webSettings.setDomStorageEnabled(booleanValue);
                                T6 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th) {
                                if (th instanceof C0337a) {
                                    C0337a c0337a = th;
                                    T6 = h5.e.T(c0337a.o, c0337a.f5592p, c0337a.f5593q);
                                } else {
                                    T6 = h5.e.T(th.getClass().getSimpleName(), th.toString(), AbstractC0034i.k("Cause: ", th.getCause(), ", Stacktrace: ", Log.getStackTraceString(th)));
                                }
                            }
                            cVar.g(T6);
                            return;
                        case 1:
                            C0345i c0345i3 = c0345i;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list2 = (List) obj;
                            Object obj4 = list2.get(0);
                            q5.h.c(obj4, "null cannot be cast to non-null type android.webkit.WebSettings");
                            WebSettings webSettings2 = (WebSettings) obj4;
                            Object obj5 = list2.get(1);
                            q5.h.c(obj5, "null cannot be cast to non-null type kotlin.Boolean");
                            boolean booleanValue2 = ((Boolean) obj5).booleanValue();
                            try {
                                c0345i3.getClass();
                                webSettings2.setJavaScriptEnabled(booleanValue2);
                                T7 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th2) {
                                if (th2 instanceof C0337a) {
                                    C0337a c0337a2 = th2;
                                    T7 = h5.e.T(c0337a2.o, c0337a2.f5592p, c0337a2.f5593q);
                                } else {
                                    T7 = h5.e.T(th2.getClass().getSimpleName(), th2.toString(), AbstractC0034i.k("Cause: ", th2.getCause(), ", Stacktrace: ", Log.getStackTraceString(th2)));
                                }
                            }
                            cVar.g(T7);
                            return;
                        case 2:
                            C0345i c0345i4 = c0345i;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list3 = (List) obj;
                            Object obj6 = list3.get(0);
                            q5.h.c(obj6, "null cannot be cast to non-null type android.webkit.WebSettings");
                            WebSettings webSettings3 = (WebSettings) obj6;
                            String str = (String) list3.get(1);
                            try {
                                c0345i4.getClass();
                                webSettings3.setUserAgentString(str);
                                T8 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th3) {
                                if (th3 instanceof C0337a) {
                                    C0337a c0337a3 = th3;
                                    T8 = h5.e.T(c0337a3.o, c0337a3.f5592p, c0337a3.f5593q);
                                } else {
                                    T8 = h5.e.T(th3.getClass().getSimpleName(), th3.toString(), AbstractC0034i.k("Cause: ", th3.getCause(), ", Stacktrace: ", Log.getStackTraceString(th3)));
                                }
                            }
                            cVar.g(T8);
                            return;
                        case 3:
                            C0345i c0345i5 = c0345i;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list4 = (List) obj;
                            Object obj7 = list4.get(0);
                            q5.h.c(obj7, "null cannot be cast to non-null type android.webkit.WebSettings");
                            WebSettings webSettings4 = (WebSettings) obj7;
                            Object obj8 = list4.get(1);
                            q5.h.c(obj8, "null cannot be cast to non-null type kotlin.Boolean");
                            boolean booleanValue3 = ((Boolean) obj8).booleanValue();
                            try {
                                c0345i5.getClass();
                                webSettings4.setMediaPlaybackRequiresUserGesture(booleanValue3);
                                T9 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th4) {
                                if (th4 instanceof C0337a) {
                                    C0337a c0337a4 = th4;
                                    T9 = h5.e.T(c0337a4.o, c0337a4.f5592p, c0337a4.f5593q);
                                } else {
                                    T9 = h5.e.T(th4.getClass().getSimpleName(), th4.toString(), AbstractC0034i.k("Cause: ", th4.getCause(), ", Stacktrace: ", Log.getStackTraceString(th4)));
                                }
                            }
                            cVar.g(T9);
                            return;
                        case 4:
                            C0345i c0345i6 = c0345i;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list5 = (List) obj;
                            Object obj9 = list5.get(0);
                            q5.h.c(obj9, "null cannot be cast to non-null type android.webkit.WebSettings");
                            WebSettings webSettings5 = (WebSettings) obj9;
                            Object obj10 = list5.get(1);
                            q5.h.c(obj10, "null cannot be cast to non-null type kotlin.Boolean");
                            boolean booleanValue4 = ((Boolean) obj10).booleanValue();
                            try {
                                c0345i6.getClass();
                                webSettings5.setSupportZoom(booleanValue4);
                                T10 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th5) {
                                if (th5 instanceof C0337a) {
                                    C0337a c0337a5 = th5;
                                    T10 = h5.e.T(c0337a5.o, c0337a5.f5592p, c0337a5.f5593q);
                                } else {
                                    T10 = h5.e.T(th5.getClass().getSimpleName(), th5.toString(), AbstractC0034i.k("Cause: ", th5.getCause(), ", Stacktrace: ", Log.getStackTraceString(th5)));
                                }
                            }
                            cVar.g(T10);
                            return;
                        case 5:
                            C0345i c0345i7 = c0345i;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list6 = (List) obj;
                            Object obj11 = list6.get(0);
                            q5.h.c(obj11, "null cannot be cast to non-null type android.webkit.WebSettings");
                            WebSettings webSettings6 = (WebSettings) obj11;
                            Object obj12 = list6.get(1);
                            q5.h.c(obj12, "null cannot be cast to non-null type kotlin.Boolean");
                            boolean booleanValue5 = ((Boolean) obj12).booleanValue();
                            try {
                                c0345i7.getClass();
                                webSettings6.setLoadWithOverviewMode(booleanValue5);
                                T11 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th6) {
                                if (th6 instanceof C0337a) {
                                    C0337a c0337a6 = th6;
                                    T11 = h5.e.T(c0337a6.o, c0337a6.f5592p, c0337a6.f5593q);
                                } else {
                                    T11 = h5.e.T(th6.getClass().getSimpleName(), th6.toString(), AbstractC0034i.k("Cause: ", th6.getCause(), ", Stacktrace: ", Log.getStackTraceString(th6)));
                                }
                            }
                            cVar.g(T11);
                            return;
                        case 6:
                            C0345i c0345i8 = c0345i;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list7 = (List) obj;
                            Object obj13 = list7.get(0);
                            q5.h.c(obj13, "null cannot be cast to non-null type android.webkit.WebSettings");
                            WebSettings webSettings7 = (WebSettings) obj13;
                            Object obj14 = list7.get(1);
                            q5.h.c(obj14, "null cannot be cast to non-null type kotlin.Boolean");
                            boolean booleanValue6 = ((Boolean) obj14).booleanValue();
                            try {
                                c0345i8.getClass();
                                webSettings7.setUseWideViewPort(booleanValue6);
                                T12 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th7) {
                                if (th7 instanceof C0337a) {
                                    C0337a c0337a7 = th7;
                                    T12 = h5.e.T(c0337a7.o, c0337a7.f5592p, c0337a7.f5593q);
                                } else {
                                    T12 = h5.e.T(th7.getClass().getSimpleName(), th7.toString(), AbstractC0034i.k("Cause: ", th7.getCause(), ", Stacktrace: ", Log.getStackTraceString(th7)));
                                }
                            }
                            cVar.g(T12);
                            return;
                        case 7:
                            C0345i c0345i9 = c0345i;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list8 = (List) obj;
                            Object obj15 = list8.get(0);
                            q5.h.c(obj15, "null cannot be cast to non-null type android.webkit.WebSettings");
                            WebSettings webSettings8 = (WebSettings) obj15;
                            Object obj16 = list8.get(1);
                            q5.h.c(obj16, "null cannot be cast to non-null type kotlin.Boolean");
                            boolean booleanValue7 = ((Boolean) obj16).booleanValue();
                            try {
                                c0345i9.getClass();
                                webSettings8.setDisplayZoomControls(booleanValue7);
                                T13 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th8) {
                                if (th8 instanceof C0337a) {
                                    C0337a c0337a8 = th8;
                                    T13 = h5.e.T(c0337a8.o, c0337a8.f5592p, c0337a8.f5593q);
                                } else {
                                    T13 = h5.e.T(th8.getClass().getSimpleName(), th8.toString(), AbstractC0034i.k("Cause: ", th8.getCause(), ", Stacktrace: ", Log.getStackTraceString(th8)));
                                }
                            }
                            cVar.g(T13);
                            return;
                        case 8:
                            C0345i c0345i10 = c0345i;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list9 = (List) obj;
                            Object obj17 = list9.get(0);
                            q5.h.c(obj17, "null cannot be cast to non-null type android.webkit.WebSettings");
                            WebSettings webSettings9 = (WebSettings) obj17;
                            Object obj18 = list9.get(1);
                            q5.h.c(obj18, "null cannot be cast to non-null type kotlin.Boolean");
                            boolean booleanValue8 = ((Boolean) obj18).booleanValue();
                            try {
                                c0345i10.getClass();
                                webSettings9.setBuiltInZoomControls(booleanValue8);
                                T14 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th9) {
                                if (th9 instanceof C0337a) {
                                    C0337a c0337a9 = th9;
                                    T14 = h5.e.T(c0337a9.o, c0337a9.f5592p, c0337a9.f5593q);
                                } else {
                                    T14 = h5.e.T(th9.getClass().getSimpleName(), th9.toString(), AbstractC0034i.k("Cause: ", th9.getCause(), ", Stacktrace: ", Log.getStackTraceString(th9)));
                                }
                            }
                            cVar.g(T14);
                            return;
                        case ContentHandlerProxy.PROCESSING_INSTRUCTION /* 9 */:
                            C0345i c0345i11 = c0345i;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list10 = (List) obj;
                            Object obj19 = list10.get(0);
                            q5.h.c(obj19, "null cannot be cast to non-null type android.webkit.WebSettings");
                            WebSettings webSettings10 = (WebSettings) obj19;
                            Object obj20 = list10.get(1);
                            q5.h.c(obj20, "null cannot be cast to non-null type kotlin.Boolean");
                            boolean booleanValue9 = ((Boolean) obj20).booleanValue();
                            try {
                                c0345i11.getClass();
                                webSettings10.setAllowFileAccess(booleanValue9);
                                T15 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th10) {
                                if (th10 instanceof C0337a) {
                                    C0337a c0337a10 = th10;
                                    T15 = h5.e.T(c0337a10.o, c0337a10.f5592p, c0337a10.f5593q);
                                } else {
                                    T15 = h5.e.T(th10.getClass().getSimpleName(), th10.toString(), AbstractC0034i.k("Cause: ", th10.getCause(), ", Stacktrace: ", Log.getStackTraceString(th10)));
                                }
                            }
                            cVar.g(T15);
                            return;
                        case 10:
                            C0345i c0345i12 = c0345i;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list11 = (List) obj;
                            Object obj21 = list11.get(0);
                            q5.h.c(obj21, "null cannot be cast to non-null type android.webkit.WebSettings");
                            WebSettings webSettings11 = (WebSettings) obj21;
                            Object obj22 = list11.get(1);
                            q5.h.c(obj22, "null cannot be cast to non-null type kotlin.Boolean");
                            boolean booleanValue10 = ((Boolean) obj22).booleanValue();
                            try {
                                c0345i12.getClass();
                                webSettings11.setAllowContentAccess(booleanValue10);
                                T16 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th11) {
                                if (th11 instanceof C0337a) {
                                    C0337a c0337a11 = th11;
                                    T16 = h5.e.T(c0337a11.o, c0337a11.f5592p, c0337a11.f5593q);
                                } else {
                                    T16 = h5.e.T(th11.getClass().getSimpleName(), th11.toString(), AbstractC0034i.k("Cause: ", th11.getCause(), ", Stacktrace: ", Log.getStackTraceString(th11)));
                                }
                            }
                            cVar.g(T16);
                            return;
                        case 11:
                            C0345i c0345i13 = c0345i;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list12 = (List) obj;
                            Object obj23 = list12.get(0);
                            q5.h.c(obj23, "null cannot be cast to non-null type android.webkit.WebSettings");
                            WebSettings webSettings12 = (WebSettings) obj23;
                            Object obj24 = list12.get(1);
                            q5.h.c(obj24, "null cannot be cast to non-null type kotlin.Boolean");
                            boolean booleanValue11 = ((Boolean) obj24).booleanValue();
                            try {
                                c0345i13.getClass();
                                webSettings12.setGeolocationEnabled(booleanValue11);
                                T17 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th12) {
                                if (th12 instanceof C0337a) {
                                    C0337a c0337a12 = th12;
                                    T17 = h5.e.T(c0337a12.o, c0337a12.f5592p, c0337a12.f5593q);
                                } else {
                                    T17 = h5.e.T(th12.getClass().getSimpleName(), th12.toString(), AbstractC0034i.k("Cause: ", th12.getCause(), ", Stacktrace: ", Log.getStackTraceString(th12)));
                                }
                            }
                            cVar.g(T17);
                            return;
                        case 12:
                            C0345i c0345i14 = c0345i;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list13 = (List) obj;
                            Object obj25 = list13.get(0);
                            q5.h.c(obj25, "null cannot be cast to non-null type android.webkit.WebSettings");
                            WebSettings webSettings13 = (WebSettings) obj25;
                            Object obj26 = list13.get(1);
                            q5.h.c(obj26, "null cannot be cast to non-null type kotlin.Long");
                            long longValue = ((Long) obj26).longValue();
                            try {
                                c0345i14.getClass();
                                webSettings13.setTextZoom((int) longValue);
                                T18 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th13) {
                                if (th13 instanceof C0337a) {
                                    C0337a c0337a13 = th13;
                                    T18 = h5.e.T(c0337a13.o, c0337a13.f5592p, c0337a13.f5593q);
                                } else {
                                    T18 = h5.e.T(th13.getClass().getSimpleName(), th13.toString(), AbstractC0034i.k("Cause: ", th13.getCause(), ", Stacktrace: ", Log.getStackTraceString(th13)));
                                }
                            }
                            cVar.g(T18);
                            return;
                        case 13:
                            C0345i c0345i15 = c0345i;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            Object obj27 = ((List) obj).get(0);
                            q5.h.c(obj27, "null cannot be cast to non-null type android.webkit.WebSettings");
                            WebSettings webSettings14 = (WebSettings) obj27;
                            try {
                                c0345i15.getClass();
                                T19 = android.support.v4.media.session.a.z(webSettings14.getUserAgentString());
                            } catch (Throwable th14) {
                                if (th14 instanceof C0337a) {
                                    C0337a c0337a14 = th14;
                                    T19 = h5.e.T(c0337a14.o, c0337a14.f5592p, c0337a14.f5593q);
                                } else {
                                    T19 = h5.e.T(th14.getClass().getSimpleName(), th14.toString(), AbstractC0034i.k("Cause: ", th14.getCause(), ", Stacktrace: ", Log.getStackTraceString(th14)));
                                }
                            }
                            cVar.g(T19);
                            return;
                        case 14:
                            C0345i c0345i16 = c0345i;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list14 = (List) obj;
                            Object obj28 = list14.get(0);
                            q5.h.c(obj28, "null cannot be cast to non-null type android.webkit.WebSettings");
                            WebSettings webSettings15 = (WebSettings) obj28;
                            Object obj29 = list14.get(1);
                            q5.h.c(obj29, "null cannot be cast to non-null type io.flutter.plugins.webviewflutter.MixedContentMode");
                            EnumC0359w enumC0359w = (EnumC0359w) obj29;
                            try {
                                c0345i16.getClass();
                                int ordinal = enumC0359w.ordinal();
                                if (ordinal != 0) {
                                    if (ordinal != 1) {
                                        if (ordinal == 2) {
                                            webSettings15.setMixedContentMode(1);
                                        }
                                    } else {
                                        webSettings15.setMixedContentMode(2);
                                    }
                                } else {
                                    webSettings15.setMixedContentMode(0);
                                }
                                T20 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th15) {
                                if (th15 instanceof C0337a) {
                                    C0337a c0337a15 = th15;
                                    T20 = h5.e.T(c0337a15.o, c0337a15.f5592p, c0337a15.f5593q);
                                } else {
                                    T20 = h5.e.T(th15.getClass().getSimpleName(), th15.toString(), AbstractC0034i.k("Cause: ", th15.getCause(), ", Stacktrace: ", Log.getStackTraceString(th15)));
                                }
                            }
                            cVar.g(T20);
                            return;
                        case 15:
                            C0345i c0345i17 = c0345i;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list15 = (List) obj;
                            Object obj30 = list15.get(0);
                            q5.h.c(obj30, "null cannot be cast to non-null type android.webkit.WebSettings");
                            WebSettings webSettings16 = (WebSettings) obj30;
                            Object obj31 = list15.get(1);
                            q5.h.c(obj31, "null cannot be cast to non-null type kotlin.Boolean");
                            boolean booleanValue12 = ((Boolean) obj31).booleanValue();
                            try {
                                c0345i17.getClass();
                                webSettings16.setJavaScriptCanOpenWindowsAutomatically(booleanValue12);
                                T21 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th16) {
                                if (th16 instanceof C0337a) {
                                    C0337a c0337a16 = th16;
                                    T21 = h5.e.T(c0337a16.o, c0337a16.f5592p, c0337a16.f5593q);
                                } else {
                                    T21 = h5.e.T(th16.getClass().getSimpleName(), th16.toString(), AbstractC0034i.k("Cause: ", th16.getCause(), ", Stacktrace: ", Log.getStackTraceString(th16)));
                                }
                            }
                            cVar.g(T21);
                            return;
                        default:
                            C0345i c0345i18 = c0345i;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list16 = (List) obj;
                            Object obj32 = list16.get(0);
                            q5.h.c(obj32, "null cannot be cast to non-null type android.webkit.WebSettings");
                            WebSettings webSettings17 = (WebSettings) obj32;
                            Object obj33 = list16.get(1);
                            q5.h.c(obj33, "null cannot be cast to non-null type kotlin.Boolean");
                            boolean booleanValue13 = ((Boolean) obj33).booleanValue();
                            try {
                                c0345i18.getClass();
                                webSettings17.setSupportMultipleWindows(booleanValue13);
                                T22 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th17) {
                                if (th17 instanceof C0337a) {
                                    C0337a c0337a17 = th17;
                                    T22 = h5.e.T(c0337a17.o, c0337a17.f5592p, c0337a17.f5593q);
                                } else {
                                    T22 = h5.e.T(th17.getClass().getSimpleName(), th17.toString(), AbstractC0034i.k("Cause: ", th17.getCause(), ", Stacktrace: ", Log.getStackTraceString(th17)));
                                }
                            }
                            cVar.g(T22);
                            return;
                    }
                }
            });
        } else {
            uVar.y(null);
        }
        v3.u uVar2 = new v3.u(fVar, "dev.flutter.pigeon.webview_flutter_android.WebSettings.setJavaScriptCanOpenWindowsAutomatically", gVar, (C0508g) null);
        if (c0345i != null) {
            final int i7 = 15;
            uVar2.y(new b() { // from class: c5.J
                @Override // M4.b
                public final void e(Object obj, A.c cVar) {
                    List T6;
                    List T7;
                    List T8;
                    List T9;
                    List T10;
                    List T11;
                    List T12;
                    List T13;
                    List T14;
                    List T15;
                    List T16;
                    List T17;
                    List T18;
                    List T19;
                    List T20;
                    List T21;
                    List T22;
                    switch (i7) {
                        case 0:
                            C0345i c0345i2 = c0345i;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list = (List) obj;
                            Object obj2 = list.get(0);
                            q5.h.c(obj2, "null cannot be cast to non-null type android.webkit.WebSettings");
                            WebSettings webSettings = (WebSettings) obj2;
                            Object obj3 = list.get(1);
                            q5.h.c(obj3, "null cannot be cast to non-null type kotlin.Boolean");
                            boolean booleanValue = ((Boolean) obj3).booleanValue();
                            try {
                                c0345i2.getClass();
                                webSettings.setDomStorageEnabled(booleanValue);
                                T6 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th) {
                                if (th instanceof C0337a) {
                                    C0337a c0337a = th;
                                    T6 = h5.e.T(c0337a.o, c0337a.f5592p, c0337a.f5593q);
                                } else {
                                    T6 = h5.e.T(th.getClass().getSimpleName(), th.toString(), AbstractC0034i.k("Cause: ", th.getCause(), ", Stacktrace: ", Log.getStackTraceString(th)));
                                }
                            }
                            cVar.g(T6);
                            return;
                        case 1:
                            C0345i c0345i3 = c0345i;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list2 = (List) obj;
                            Object obj4 = list2.get(0);
                            q5.h.c(obj4, "null cannot be cast to non-null type android.webkit.WebSettings");
                            WebSettings webSettings2 = (WebSettings) obj4;
                            Object obj5 = list2.get(1);
                            q5.h.c(obj5, "null cannot be cast to non-null type kotlin.Boolean");
                            boolean booleanValue2 = ((Boolean) obj5).booleanValue();
                            try {
                                c0345i3.getClass();
                                webSettings2.setJavaScriptEnabled(booleanValue2);
                                T7 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th2) {
                                if (th2 instanceof C0337a) {
                                    C0337a c0337a2 = th2;
                                    T7 = h5.e.T(c0337a2.o, c0337a2.f5592p, c0337a2.f5593q);
                                } else {
                                    T7 = h5.e.T(th2.getClass().getSimpleName(), th2.toString(), AbstractC0034i.k("Cause: ", th2.getCause(), ", Stacktrace: ", Log.getStackTraceString(th2)));
                                }
                            }
                            cVar.g(T7);
                            return;
                        case 2:
                            C0345i c0345i4 = c0345i;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list3 = (List) obj;
                            Object obj6 = list3.get(0);
                            q5.h.c(obj6, "null cannot be cast to non-null type android.webkit.WebSettings");
                            WebSettings webSettings3 = (WebSettings) obj6;
                            String str = (String) list3.get(1);
                            try {
                                c0345i4.getClass();
                                webSettings3.setUserAgentString(str);
                                T8 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th3) {
                                if (th3 instanceof C0337a) {
                                    C0337a c0337a3 = th3;
                                    T8 = h5.e.T(c0337a3.o, c0337a3.f5592p, c0337a3.f5593q);
                                } else {
                                    T8 = h5.e.T(th3.getClass().getSimpleName(), th3.toString(), AbstractC0034i.k("Cause: ", th3.getCause(), ", Stacktrace: ", Log.getStackTraceString(th3)));
                                }
                            }
                            cVar.g(T8);
                            return;
                        case 3:
                            C0345i c0345i5 = c0345i;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list4 = (List) obj;
                            Object obj7 = list4.get(0);
                            q5.h.c(obj7, "null cannot be cast to non-null type android.webkit.WebSettings");
                            WebSettings webSettings4 = (WebSettings) obj7;
                            Object obj8 = list4.get(1);
                            q5.h.c(obj8, "null cannot be cast to non-null type kotlin.Boolean");
                            boolean booleanValue3 = ((Boolean) obj8).booleanValue();
                            try {
                                c0345i5.getClass();
                                webSettings4.setMediaPlaybackRequiresUserGesture(booleanValue3);
                                T9 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th4) {
                                if (th4 instanceof C0337a) {
                                    C0337a c0337a4 = th4;
                                    T9 = h5.e.T(c0337a4.o, c0337a4.f5592p, c0337a4.f5593q);
                                } else {
                                    T9 = h5.e.T(th4.getClass().getSimpleName(), th4.toString(), AbstractC0034i.k("Cause: ", th4.getCause(), ", Stacktrace: ", Log.getStackTraceString(th4)));
                                }
                            }
                            cVar.g(T9);
                            return;
                        case 4:
                            C0345i c0345i6 = c0345i;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list5 = (List) obj;
                            Object obj9 = list5.get(0);
                            q5.h.c(obj9, "null cannot be cast to non-null type android.webkit.WebSettings");
                            WebSettings webSettings5 = (WebSettings) obj9;
                            Object obj10 = list5.get(1);
                            q5.h.c(obj10, "null cannot be cast to non-null type kotlin.Boolean");
                            boolean booleanValue4 = ((Boolean) obj10).booleanValue();
                            try {
                                c0345i6.getClass();
                                webSettings5.setSupportZoom(booleanValue4);
                                T10 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th5) {
                                if (th5 instanceof C0337a) {
                                    C0337a c0337a5 = th5;
                                    T10 = h5.e.T(c0337a5.o, c0337a5.f5592p, c0337a5.f5593q);
                                } else {
                                    T10 = h5.e.T(th5.getClass().getSimpleName(), th5.toString(), AbstractC0034i.k("Cause: ", th5.getCause(), ", Stacktrace: ", Log.getStackTraceString(th5)));
                                }
                            }
                            cVar.g(T10);
                            return;
                        case 5:
                            C0345i c0345i7 = c0345i;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list6 = (List) obj;
                            Object obj11 = list6.get(0);
                            q5.h.c(obj11, "null cannot be cast to non-null type android.webkit.WebSettings");
                            WebSettings webSettings6 = (WebSettings) obj11;
                            Object obj12 = list6.get(1);
                            q5.h.c(obj12, "null cannot be cast to non-null type kotlin.Boolean");
                            boolean booleanValue5 = ((Boolean) obj12).booleanValue();
                            try {
                                c0345i7.getClass();
                                webSettings6.setLoadWithOverviewMode(booleanValue5);
                                T11 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th6) {
                                if (th6 instanceof C0337a) {
                                    C0337a c0337a6 = th6;
                                    T11 = h5.e.T(c0337a6.o, c0337a6.f5592p, c0337a6.f5593q);
                                } else {
                                    T11 = h5.e.T(th6.getClass().getSimpleName(), th6.toString(), AbstractC0034i.k("Cause: ", th6.getCause(), ", Stacktrace: ", Log.getStackTraceString(th6)));
                                }
                            }
                            cVar.g(T11);
                            return;
                        case 6:
                            C0345i c0345i8 = c0345i;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list7 = (List) obj;
                            Object obj13 = list7.get(0);
                            q5.h.c(obj13, "null cannot be cast to non-null type android.webkit.WebSettings");
                            WebSettings webSettings7 = (WebSettings) obj13;
                            Object obj14 = list7.get(1);
                            q5.h.c(obj14, "null cannot be cast to non-null type kotlin.Boolean");
                            boolean booleanValue6 = ((Boolean) obj14).booleanValue();
                            try {
                                c0345i8.getClass();
                                webSettings7.setUseWideViewPort(booleanValue6);
                                T12 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th7) {
                                if (th7 instanceof C0337a) {
                                    C0337a c0337a7 = th7;
                                    T12 = h5.e.T(c0337a7.o, c0337a7.f5592p, c0337a7.f5593q);
                                } else {
                                    T12 = h5.e.T(th7.getClass().getSimpleName(), th7.toString(), AbstractC0034i.k("Cause: ", th7.getCause(), ", Stacktrace: ", Log.getStackTraceString(th7)));
                                }
                            }
                            cVar.g(T12);
                            return;
                        case 7:
                            C0345i c0345i9 = c0345i;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list8 = (List) obj;
                            Object obj15 = list8.get(0);
                            q5.h.c(obj15, "null cannot be cast to non-null type android.webkit.WebSettings");
                            WebSettings webSettings8 = (WebSettings) obj15;
                            Object obj16 = list8.get(1);
                            q5.h.c(obj16, "null cannot be cast to non-null type kotlin.Boolean");
                            boolean booleanValue7 = ((Boolean) obj16).booleanValue();
                            try {
                                c0345i9.getClass();
                                webSettings8.setDisplayZoomControls(booleanValue7);
                                T13 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th8) {
                                if (th8 instanceof C0337a) {
                                    C0337a c0337a8 = th8;
                                    T13 = h5.e.T(c0337a8.o, c0337a8.f5592p, c0337a8.f5593q);
                                } else {
                                    T13 = h5.e.T(th8.getClass().getSimpleName(), th8.toString(), AbstractC0034i.k("Cause: ", th8.getCause(), ", Stacktrace: ", Log.getStackTraceString(th8)));
                                }
                            }
                            cVar.g(T13);
                            return;
                        case 8:
                            C0345i c0345i10 = c0345i;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list9 = (List) obj;
                            Object obj17 = list9.get(0);
                            q5.h.c(obj17, "null cannot be cast to non-null type android.webkit.WebSettings");
                            WebSettings webSettings9 = (WebSettings) obj17;
                            Object obj18 = list9.get(1);
                            q5.h.c(obj18, "null cannot be cast to non-null type kotlin.Boolean");
                            boolean booleanValue8 = ((Boolean) obj18).booleanValue();
                            try {
                                c0345i10.getClass();
                                webSettings9.setBuiltInZoomControls(booleanValue8);
                                T14 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th9) {
                                if (th9 instanceof C0337a) {
                                    C0337a c0337a9 = th9;
                                    T14 = h5.e.T(c0337a9.o, c0337a9.f5592p, c0337a9.f5593q);
                                } else {
                                    T14 = h5.e.T(th9.getClass().getSimpleName(), th9.toString(), AbstractC0034i.k("Cause: ", th9.getCause(), ", Stacktrace: ", Log.getStackTraceString(th9)));
                                }
                            }
                            cVar.g(T14);
                            return;
                        case ContentHandlerProxy.PROCESSING_INSTRUCTION /* 9 */:
                            C0345i c0345i11 = c0345i;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list10 = (List) obj;
                            Object obj19 = list10.get(0);
                            q5.h.c(obj19, "null cannot be cast to non-null type android.webkit.WebSettings");
                            WebSettings webSettings10 = (WebSettings) obj19;
                            Object obj20 = list10.get(1);
                            q5.h.c(obj20, "null cannot be cast to non-null type kotlin.Boolean");
                            boolean booleanValue9 = ((Boolean) obj20).booleanValue();
                            try {
                                c0345i11.getClass();
                                webSettings10.setAllowFileAccess(booleanValue9);
                                T15 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th10) {
                                if (th10 instanceof C0337a) {
                                    C0337a c0337a10 = th10;
                                    T15 = h5.e.T(c0337a10.o, c0337a10.f5592p, c0337a10.f5593q);
                                } else {
                                    T15 = h5.e.T(th10.getClass().getSimpleName(), th10.toString(), AbstractC0034i.k("Cause: ", th10.getCause(), ", Stacktrace: ", Log.getStackTraceString(th10)));
                                }
                            }
                            cVar.g(T15);
                            return;
                        case 10:
                            C0345i c0345i12 = c0345i;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list11 = (List) obj;
                            Object obj21 = list11.get(0);
                            q5.h.c(obj21, "null cannot be cast to non-null type android.webkit.WebSettings");
                            WebSettings webSettings11 = (WebSettings) obj21;
                            Object obj22 = list11.get(1);
                            q5.h.c(obj22, "null cannot be cast to non-null type kotlin.Boolean");
                            boolean booleanValue10 = ((Boolean) obj22).booleanValue();
                            try {
                                c0345i12.getClass();
                                webSettings11.setAllowContentAccess(booleanValue10);
                                T16 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th11) {
                                if (th11 instanceof C0337a) {
                                    C0337a c0337a11 = th11;
                                    T16 = h5.e.T(c0337a11.o, c0337a11.f5592p, c0337a11.f5593q);
                                } else {
                                    T16 = h5.e.T(th11.getClass().getSimpleName(), th11.toString(), AbstractC0034i.k("Cause: ", th11.getCause(), ", Stacktrace: ", Log.getStackTraceString(th11)));
                                }
                            }
                            cVar.g(T16);
                            return;
                        case 11:
                            C0345i c0345i13 = c0345i;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list12 = (List) obj;
                            Object obj23 = list12.get(0);
                            q5.h.c(obj23, "null cannot be cast to non-null type android.webkit.WebSettings");
                            WebSettings webSettings12 = (WebSettings) obj23;
                            Object obj24 = list12.get(1);
                            q5.h.c(obj24, "null cannot be cast to non-null type kotlin.Boolean");
                            boolean booleanValue11 = ((Boolean) obj24).booleanValue();
                            try {
                                c0345i13.getClass();
                                webSettings12.setGeolocationEnabled(booleanValue11);
                                T17 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th12) {
                                if (th12 instanceof C0337a) {
                                    C0337a c0337a12 = th12;
                                    T17 = h5.e.T(c0337a12.o, c0337a12.f5592p, c0337a12.f5593q);
                                } else {
                                    T17 = h5.e.T(th12.getClass().getSimpleName(), th12.toString(), AbstractC0034i.k("Cause: ", th12.getCause(), ", Stacktrace: ", Log.getStackTraceString(th12)));
                                }
                            }
                            cVar.g(T17);
                            return;
                        case 12:
                            C0345i c0345i14 = c0345i;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list13 = (List) obj;
                            Object obj25 = list13.get(0);
                            q5.h.c(obj25, "null cannot be cast to non-null type android.webkit.WebSettings");
                            WebSettings webSettings13 = (WebSettings) obj25;
                            Object obj26 = list13.get(1);
                            q5.h.c(obj26, "null cannot be cast to non-null type kotlin.Long");
                            long longValue = ((Long) obj26).longValue();
                            try {
                                c0345i14.getClass();
                                webSettings13.setTextZoom((int) longValue);
                                T18 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th13) {
                                if (th13 instanceof C0337a) {
                                    C0337a c0337a13 = th13;
                                    T18 = h5.e.T(c0337a13.o, c0337a13.f5592p, c0337a13.f5593q);
                                } else {
                                    T18 = h5.e.T(th13.getClass().getSimpleName(), th13.toString(), AbstractC0034i.k("Cause: ", th13.getCause(), ", Stacktrace: ", Log.getStackTraceString(th13)));
                                }
                            }
                            cVar.g(T18);
                            return;
                        case 13:
                            C0345i c0345i15 = c0345i;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            Object obj27 = ((List) obj).get(0);
                            q5.h.c(obj27, "null cannot be cast to non-null type android.webkit.WebSettings");
                            WebSettings webSettings14 = (WebSettings) obj27;
                            try {
                                c0345i15.getClass();
                                T19 = android.support.v4.media.session.a.z(webSettings14.getUserAgentString());
                            } catch (Throwable th14) {
                                if (th14 instanceof C0337a) {
                                    C0337a c0337a14 = th14;
                                    T19 = h5.e.T(c0337a14.o, c0337a14.f5592p, c0337a14.f5593q);
                                } else {
                                    T19 = h5.e.T(th14.getClass().getSimpleName(), th14.toString(), AbstractC0034i.k("Cause: ", th14.getCause(), ", Stacktrace: ", Log.getStackTraceString(th14)));
                                }
                            }
                            cVar.g(T19);
                            return;
                        case 14:
                            C0345i c0345i16 = c0345i;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list14 = (List) obj;
                            Object obj28 = list14.get(0);
                            q5.h.c(obj28, "null cannot be cast to non-null type android.webkit.WebSettings");
                            WebSettings webSettings15 = (WebSettings) obj28;
                            Object obj29 = list14.get(1);
                            q5.h.c(obj29, "null cannot be cast to non-null type io.flutter.plugins.webviewflutter.MixedContentMode");
                            EnumC0359w enumC0359w = (EnumC0359w) obj29;
                            try {
                                c0345i16.getClass();
                                int ordinal = enumC0359w.ordinal();
                                if (ordinal != 0) {
                                    if (ordinal != 1) {
                                        if (ordinal == 2) {
                                            webSettings15.setMixedContentMode(1);
                                        }
                                    } else {
                                        webSettings15.setMixedContentMode(2);
                                    }
                                } else {
                                    webSettings15.setMixedContentMode(0);
                                }
                                T20 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th15) {
                                if (th15 instanceof C0337a) {
                                    C0337a c0337a15 = th15;
                                    T20 = h5.e.T(c0337a15.o, c0337a15.f5592p, c0337a15.f5593q);
                                } else {
                                    T20 = h5.e.T(th15.getClass().getSimpleName(), th15.toString(), AbstractC0034i.k("Cause: ", th15.getCause(), ", Stacktrace: ", Log.getStackTraceString(th15)));
                                }
                            }
                            cVar.g(T20);
                            return;
                        case 15:
                            C0345i c0345i17 = c0345i;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list15 = (List) obj;
                            Object obj30 = list15.get(0);
                            q5.h.c(obj30, "null cannot be cast to non-null type android.webkit.WebSettings");
                            WebSettings webSettings16 = (WebSettings) obj30;
                            Object obj31 = list15.get(1);
                            q5.h.c(obj31, "null cannot be cast to non-null type kotlin.Boolean");
                            boolean booleanValue12 = ((Boolean) obj31).booleanValue();
                            try {
                                c0345i17.getClass();
                                webSettings16.setJavaScriptCanOpenWindowsAutomatically(booleanValue12);
                                T21 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th16) {
                                if (th16 instanceof C0337a) {
                                    C0337a c0337a16 = th16;
                                    T21 = h5.e.T(c0337a16.o, c0337a16.f5592p, c0337a16.f5593q);
                                } else {
                                    T21 = h5.e.T(th16.getClass().getSimpleName(), th16.toString(), AbstractC0034i.k("Cause: ", th16.getCause(), ", Stacktrace: ", Log.getStackTraceString(th16)));
                                }
                            }
                            cVar.g(T21);
                            return;
                        default:
                            C0345i c0345i18 = c0345i;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list16 = (List) obj;
                            Object obj32 = list16.get(0);
                            q5.h.c(obj32, "null cannot be cast to non-null type android.webkit.WebSettings");
                            WebSettings webSettings17 = (WebSettings) obj32;
                            Object obj33 = list16.get(1);
                            q5.h.c(obj33, "null cannot be cast to non-null type kotlin.Boolean");
                            boolean booleanValue13 = ((Boolean) obj33).booleanValue();
                            try {
                                c0345i18.getClass();
                                webSettings17.setSupportMultipleWindows(booleanValue13);
                                T22 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th17) {
                                if (th17 instanceof C0337a) {
                                    C0337a c0337a17 = th17;
                                    T22 = h5.e.T(c0337a17.o, c0337a17.f5592p, c0337a17.f5593q);
                                } else {
                                    T22 = h5.e.T(th17.getClass().getSimpleName(), th17.toString(), AbstractC0034i.k("Cause: ", th17.getCause(), ", Stacktrace: ", Log.getStackTraceString(th17)));
                                }
                            }
                            cVar.g(T22);
                            return;
                    }
                }
            });
        } else {
            uVar2.y(null);
        }
        v3.u uVar3 = new v3.u(fVar, "dev.flutter.pigeon.webview_flutter_android.WebSettings.setSupportMultipleWindows", gVar, (C0508g) null);
        if (c0345i != null) {
            final int i8 = 16;
            uVar3.y(new b() { // from class: c5.J
                @Override // M4.b
                public final void e(Object obj, A.c cVar) {
                    List T6;
                    List T7;
                    List T8;
                    List T9;
                    List T10;
                    List T11;
                    List T12;
                    List T13;
                    List T14;
                    List T15;
                    List T16;
                    List T17;
                    List T18;
                    List T19;
                    List T20;
                    List T21;
                    List T22;
                    switch (i8) {
                        case 0:
                            C0345i c0345i2 = c0345i;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list = (List) obj;
                            Object obj2 = list.get(0);
                            q5.h.c(obj2, "null cannot be cast to non-null type android.webkit.WebSettings");
                            WebSettings webSettings = (WebSettings) obj2;
                            Object obj3 = list.get(1);
                            q5.h.c(obj3, "null cannot be cast to non-null type kotlin.Boolean");
                            boolean booleanValue = ((Boolean) obj3).booleanValue();
                            try {
                                c0345i2.getClass();
                                webSettings.setDomStorageEnabled(booleanValue);
                                T6 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th) {
                                if (th instanceof C0337a) {
                                    C0337a c0337a = th;
                                    T6 = h5.e.T(c0337a.o, c0337a.f5592p, c0337a.f5593q);
                                } else {
                                    T6 = h5.e.T(th.getClass().getSimpleName(), th.toString(), AbstractC0034i.k("Cause: ", th.getCause(), ", Stacktrace: ", Log.getStackTraceString(th)));
                                }
                            }
                            cVar.g(T6);
                            return;
                        case 1:
                            C0345i c0345i3 = c0345i;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list2 = (List) obj;
                            Object obj4 = list2.get(0);
                            q5.h.c(obj4, "null cannot be cast to non-null type android.webkit.WebSettings");
                            WebSettings webSettings2 = (WebSettings) obj4;
                            Object obj5 = list2.get(1);
                            q5.h.c(obj5, "null cannot be cast to non-null type kotlin.Boolean");
                            boolean booleanValue2 = ((Boolean) obj5).booleanValue();
                            try {
                                c0345i3.getClass();
                                webSettings2.setJavaScriptEnabled(booleanValue2);
                                T7 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th2) {
                                if (th2 instanceof C0337a) {
                                    C0337a c0337a2 = th2;
                                    T7 = h5.e.T(c0337a2.o, c0337a2.f5592p, c0337a2.f5593q);
                                } else {
                                    T7 = h5.e.T(th2.getClass().getSimpleName(), th2.toString(), AbstractC0034i.k("Cause: ", th2.getCause(), ", Stacktrace: ", Log.getStackTraceString(th2)));
                                }
                            }
                            cVar.g(T7);
                            return;
                        case 2:
                            C0345i c0345i4 = c0345i;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list3 = (List) obj;
                            Object obj6 = list3.get(0);
                            q5.h.c(obj6, "null cannot be cast to non-null type android.webkit.WebSettings");
                            WebSettings webSettings3 = (WebSettings) obj6;
                            String str = (String) list3.get(1);
                            try {
                                c0345i4.getClass();
                                webSettings3.setUserAgentString(str);
                                T8 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th3) {
                                if (th3 instanceof C0337a) {
                                    C0337a c0337a3 = th3;
                                    T8 = h5.e.T(c0337a3.o, c0337a3.f5592p, c0337a3.f5593q);
                                } else {
                                    T8 = h5.e.T(th3.getClass().getSimpleName(), th3.toString(), AbstractC0034i.k("Cause: ", th3.getCause(), ", Stacktrace: ", Log.getStackTraceString(th3)));
                                }
                            }
                            cVar.g(T8);
                            return;
                        case 3:
                            C0345i c0345i5 = c0345i;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list4 = (List) obj;
                            Object obj7 = list4.get(0);
                            q5.h.c(obj7, "null cannot be cast to non-null type android.webkit.WebSettings");
                            WebSettings webSettings4 = (WebSettings) obj7;
                            Object obj8 = list4.get(1);
                            q5.h.c(obj8, "null cannot be cast to non-null type kotlin.Boolean");
                            boolean booleanValue3 = ((Boolean) obj8).booleanValue();
                            try {
                                c0345i5.getClass();
                                webSettings4.setMediaPlaybackRequiresUserGesture(booleanValue3);
                                T9 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th4) {
                                if (th4 instanceof C0337a) {
                                    C0337a c0337a4 = th4;
                                    T9 = h5.e.T(c0337a4.o, c0337a4.f5592p, c0337a4.f5593q);
                                } else {
                                    T9 = h5.e.T(th4.getClass().getSimpleName(), th4.toString(), AbstractC0034i.k("Cause: ", th4.getCause(), ", Stacktrace: ", Log.getStackTraceString(th4)));
                                }
                            }
                            cVar.g(T9);
                            return;
                        case 4:
                            C0345i c0345i6 = c0345i;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list5 = (List) obj;
                            Object obj9 = list5.get(0);
                            q5.h.c(obj9, "null cannot be cast to non-null type android.webkit.WebSettings");
                            WebSettings webSettings5 = (WebSettings) obj9;
                            Object obj10 = list5.get(1);
                            q5.h.c(obj10, "null cannot be cast to non-null type kotlin.Boolean");
                            boolean booleanValue4 = ((Boolean) obj10).booleanValue();
                            try {
                                c0345i6.getClass();
                                webSettings5.setSupportZoom(booleanValue4);
                                T10 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th5) {
                                if (th5 instanceof C0337a) {
                                    C0337a c0337a5 = th5;
                                    T10 = h5.e.T(c0337a5.o, c0337a5.f5592p, c0337a5.f5593q);
                                } else {
                                    T10 = h5.e.T(th5.getClass().getSimpleName(), th5.toString(), AbstractC0034i.k("Cause: ", th5.getCause(), ", Stacktrace: ", Log.getStackTraceString(th5)));
                                }
                            }
                            cVar.g(T10);
                            return;
                        case 5:
                            C0345i c0345i7 = c0345i;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list6 = (List) obj;
                            Object obj11 = list6.get(0);
                            q5.h.c(obj11, "null cannot be cast to non-null type android.webkit.WebSettings");
                            WebSettings webSettings6 = (WebSettings) obj11;
                            Object obj12 = list6.get(1);
                            q5.h.c(obj12, "null cannot be cast to non-null type kotlin.Boolean");
                            boolean booleanValue5 = ((Boolean) obj12).booleanValue();
                            try {
                                c0345i7.getClass();
                                webSettings6.setLoadWithOverviewMode(booleanValue5);
                                T11 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th6) {
                                if (th6 instanceof C0337a) {
                                    C0337a c0337a6 = th6;
                                    T11 = h5.e.T(c0337a6.o, c0337a6.f5592p, c0337a6.f5593q);
                                } else {
                                    T11 = h5.e.T(th6.getClass().getSimpleName(), th6.toString(), AbstractC0034i.k("Cause: ", th6.getCause(), ", Stacktrace: ", Log.getStackTraceString(th6)));
                                }
                            }
                            cVar.g(T11);
                            return;
                        case 6:
                            C0345i c0345i8 = c0345i;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list7 = (List) obj;
                            Object obj13 = list7.get(0);
                            q5.h.c(obj13, "null cannot be cast to non-null type android.webkit.WebSettings");
                            WebSettings webSettings7 = (WebSettings) obj13;
                            Object obj14 = list7.get(1);
                            q5.h.c(obj14, "null cannot be cast to non-null type kotlin.Boolean");
                            boolean booleanValue6 = ((Boolean) obj14).booleanValue();
                            try {
                                c0345i8.getClass();
                                webSettings7.setUseWideViewPort(booleanValue6);
                                T12 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th7) {
                                if (th7 instanceof C0337a) {
                                    C0337a c0337a7 = th7;
                                    T12 = h5.e.T(c0337a7.o, c0337a7.f5592p, c0337a7.f5593q);
                                } else {
                                    T12 = h5.e.T(th7.getClass().getSimpleName(), th7.toString(), AbstractC0034i.k("Cause: ", th7.getCause(), ", Stacktrace: ", Log.getStackTraceString(th7)));
                                }
                            }
                            cVar.g(T12);
                            return;
                        case 7:
                            C0345i c0345i9 = c0345i;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list8 = (List) obj;
                            Object obj15 = list8.get(0);
                            q5.h.c(obj15, "null cannot be cast to non-null type android.webkit.WebSettings");
                            WebSettings webSettings8 = (WebSettings) obj15;
                            Object obj16 = list8.get(1);
                            q5.h.c(obj16, "null cannot be cast to non-null type kotlin.Boolean");
                            boolean booleanValue7 = ((Boolean) obj16).booleanValue();
                            try {
                                c0345i9.getClass();
                                webSettings8.setDisplayZoomControls(booleanValue7);
                                T13 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th8) {
                                if (th8 instanceof C0337a) {
                                    C0337a c0337a8 = th8;
                                    T13 = h5.e.T(c0337a8.o, c0337a8.f5592p, c0337a8.f5593q);
                                } else {
                                    T13 = h5.e.T(th8.getClass().getSimpleName(), th8.toString(), AbstractC0034i.k("Cause: ", th8.getCause(), ", Stacktrace: ", Log.getStackTraceString(th8)));
                                }
                            }
                            cVar.g(T13);
                            return;
                        case 8:
                            C0345i c0345i10 = c0345i;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list9 = (List) obj;
                            Object obj17 = list9.get(0);
                            q5.h.c(obj17, "null cannot be cast to non-null type android.webkit.WebSettings");
                            WebSettings webSettings9 = (WebSettings) obj17;
                            Object obj18 = list9.get(1);
                            q5.h.c(obj18, "null cannot be cast to non-null type kotlin.Boolean");
                            boolean booleanValue8 = ((Boolean) obj18).booleanValue();
                            try {
                                c0345i10.getClass();
                                webSettings9.setBuiltInZoomControls(booleanValue8);
                                T14 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th9) {
                                if (th9 instanceof C0337a) {
                                    C0337a c0337a9 = th9;
                                    T14 = h5.e.T(c0337a9.o, c0337a9.f5592p, c0337a9.f5593q);
                                } else {
                                    T14 = h5.e.T(th9.getClass().getSimpleName(), th9.toString(), AbstractC0034i.k("Cause: ", th9.getCause(), ", Stacktrace: ", Log.getStackTraceString(th9)));
                                }
                            }
                            cVar.g(T14);
                            return;
                        case ContentHandlerProxy.PROCESSING_INSTRUCTION /* 9 */:
                            C0345i c0345i11 = c0345i;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list10 = (List) obj;
                            Object obj19 = list10.get(0);
                            q5.h.c(obj19, "null cannot be cast to non-null type android.webkit.WebSettings");
                            WebSettings webSettings10 = (WebSettings) obj19;
                            Object obj20 = list10.get(1);
                            q5.h.c(obj20, "null cannot be cast to non-null type kotlin.Boolean");
                            boolean booleanValue9 = ((Boolean) obj20).booleanValue();
                            try {
                                c0345i11.getClass();
                                webSettings10.setAllowFileAccess(booleanValue9);
                                T15 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th10) {
                                if (th10 instanceof C0337a) {
                                    C0337a c0337a10 = th10;
                                    T15 = h5.e.T(c0337a10.o, c0337a10.f5592p, c0337a10.f5593q);
                                } else {
                                    T15 = h5.e.T(th10.getClass().getSimpleName(), th10.toString(), AbstractC0034i.k("Cause: ", th10.getCause(), ", Stacktrace: ", Log.getStackTraceString(th10)));
                                }
                            }
                            cVar.g(T15);
                            return;
                        case 10:
                            C0345i c0345i12 = c0345i;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list11 = (List) obj;
                            Object obj21 = list11.get(0);
                            q5.h.c(obj21, "null cannot be cast to non-null type android.webkit.WebSettings");
                            WebSettings webSettings11 = (WebSettings) obj21;
                            Object obj22 = list11.get(1);
                            q5.h.c(obj22, "null cannot be cast to non-null type kotlin.Boolean");
                            boolean booleanValue10 = ((Boolean) obj22).booleanValue();
                            try {
                                c0345i12.getClass();
                                webSettings11.setAllowContentAccess(booleanValue10);
                                T16 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th11) {
                                if (th11 instanceof C0337a) {
                                    C0337a c0337a11 = th11;
                                    T16 = h5.e.T(c0337a11.o, c0337a11.f5592p, c0337a11.f5593q);
                                } else {
                                    T16 = h5.e.T(th11.getClass().getSimpleName(), th11.toString(), AbstractC0034i.k("Cause: ", th11.getCause(), ", Stacktrace: ", Log.getStackTraceString(th11)));
                                }
                            }
                            cVar.g(T16);
                            return;
                        case 11:
                            C0345i c0345i13 = c0345i;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list12 = (List) obj;
                            Object obj23 = list12.get(0);
                            q5.h.c(obj23, "null cannot be cast to non-null type android.webkit.WebSettings");
                            WebSettings webSettings12 = (WebSettings) obj23;
                            Object obj24 = list12.get(1);
                            q5.h.c(obj24, "null cannot be cast to non-null type kotlin.Boolean");
                            boolean booleanValue11 = ((Boolean) obj24).booleanValue();
                            try {
                                c0345i13.getClass();
                                webSettings12.setGeolocationEnabled(booleanValue11);
                                T17 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th12) {
                                if (th12 instanceof C0337a) {
                                    C0337a c0337a12 = th12;
                                    T17 = h5.e.T(c0337a12.o, c0337a12.f5592p, c0337a12.f5593q);
                                } else {
                                    T17 = h5.e.T(th12.getClass().getSimpleName(), th12.toString(), AbstractC0034i.k("Cause: ", th12.getCause(), ", Stacktrace: ", Log.getStackTraceString(th12)));
                                }
                            }
                            cVar.g(T17);
                            return;
                        case 12:
                            C0345i c0345i14 = c0345i;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list13 = (List) obj;
                            Object obj25 = list13.get(0);
                            q5.h.c(obj25, "null cannot be cast to non-null type android.webkit.WebSettings");
                            WebSettings webSettings13 = (WebSettings) obj25;
                            Object obj26 = list13.get(1);
                            q5.h.c(obj26, "null cannot be cast to non-null type kotlin.Long");
                            long longValue = ((Long) obj26).longValue();
                            try {
                                c0345i14.getClass();
                                webSettings13.setTextZoom((int) longValue);
                                T18 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th13) {
                                if (th13 instanceof C0337a) {
                                    C0337a c0337a13 = th13;
                                    T18 = h5.e.T(c0337a13.o, c0337a13.f5592p, c0337a13.f5593q);
                                } else {
                                    T18 = h5.e.T(th13.getClass().getSimpleName(), th13.toString(), AbstractC0034i.k("Cause: ", th13.getCause(), ", Stacktrace: ", Log.getStackTraceString(th13)));
                                }
                            }
                            cVar.g(T18);
                            return;
                        case 13:
                            C0345i c0345i15 = c0345i;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            Object obj27 = ((List) obj).get(0);
                            q5.h.c(obj27, "null cannot be cast to non-null type android.webkit.WebSettings");
                            WebSettings webSettings14 = (WebSettings) obj27;
                            try {
                                c0345i15.getClass();
                                T19 = android.support.v4.media.session.a.z(webSettings14.getUserAgentString());
                            } catch (Throwable th14) {
                                if (th14 instanceof C0337a) {
                                    C0337a c0337a14 = th14;
                                    T19 = h5.e.T(c0337a14.o, c0337a14.f5592p, c0337a14.f5593q);
                                } else {
                                    T19 = h5.e.T(th14.getClass().getSimpleName(), th14.toString(), AbstractC0034i.k("Cause: ", th14.getCause(), ", Stacktrace: ", Log.getStackTraceString(th14)));
                                }
                            }
                            cVar.g(T19);
                            return;
                        case 14:
                            C0345i c0345i16 = c0345i;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list14 = (List) obj;
                            Object obj28 = list14.get(0);
                            q5.h.c(obj28, "null cannot be cast to non-null type android.webkit.WebSettings");
                            WebSettings webSettings15 = (WebSettings) obj28;
                            Object obj29 = list14.get(1);
                            q5.h.c(obj29, "null cannot be cast to non-null type io.flutter.plugins.webviewflutter.MixedContentMode");
                            EnumC0359w enumC0359w = (EnumC0359w) obj29;
                            try {
                                c0345i16.getClass();
                                int ordinal = enumC0359w.ordinal();
                                if (ordinal != 0) {
                                    if (ordinal != 1) {
                                        if (ordinal == 2) {
                                            webSettings15.setMixedContentMode(1);
                                        }
                                    } else {
                                        webSettings15.setMixedContentMode(2);
                                    }
                                } else {
                                    webSettings15.setMixedContentMode(0);
                                }
                                T20 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th15) {
                                if (th15 instanceof C0337a) {
                                    C0337a c0337a15 = th15;
                                    T20 = h5.e.T(c0337a15.o, c0337a15.f5592p, c0337a15.f5593q);
                                } else {
                                    T20 = h5.e.T(th15.getClass().getSimpleName(), th15.toString(), AbstractC0034i.k("Cause: ", th15.getCause(), ", Stacktrace: ", Log.getStackTraceString(th15)));
                                }
                            }
                            cVar.g(T20);
                            return;
                        case 15:
                            C0345i c0345i17 = c0345i;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list15 = (List) obj;
                            Object obj30 = list15.get(0);
                            q5.h.c(obj30, "null cannot be cast to non-null type android.webkit.WebSettings");
                            WebSettings webSettings16 = (WebSettings) obj30;
                            Object obj31 = list15.get(1);
                            q5.h.c(obj31, "null cannot be cast to non-null type kotlin.Boolean");
                            boolean booleanValue12 = ((Boolean) obj31).booleanValue();
                            try {
                                c0345i17.getClass();
                                webSettings16.setJavaScriptCanOpenWindowsAutomatically(booleanValue12);
                                T21 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th16) {
                                if (th16 instanceof C0337a) {
                                    C0337a c0337a16 = th16;
                                    T21 = h5.e.T(c0337a16.o, c0337a16.f5592p, c0337a16.f5593q);
                                } else {
                                    T21 = h5.e.T(th16.getClass().getSimpleName(), th16.toString(), AbstractC0034i.k("Cause: ", th16.getCause(), ", Stacktrace: ", Log.getStackTraceString(th16)));
                                }
                            }
                            cVar.g(T21);
                            return;
                        default:
                            C0345i c0345i18 = c0345i;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list16 = (List) obj;
                            Object obj32 = list16.get(0);
                            q5.h.c(obj32, "null cannot be cast to non-null type android.webkit.WebSettings");
                            WebSettings webSettings17 = (WebSettings) obj32;
                            Object obj33 = list16.get(1);
                            q5.h.c(obj33, "null cannot be cast to non-null type kotlin.Boolean");
                            boolean booleanValue13 = ((Boolean) obj33).booleanValue();
                            try {
                                c0345i18.getClass();
                                webSettings17.setSupportMultipleWindows(booleanValue13);
                                T22 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th17) {
                                if (th17 instanceof C0337a) {
                                    C0337a c0337a17 = th17;
                                    T22 = h5.e.T(c0337a17.o, c0337a17.f5592p, c0337a17.f5593q);
                                } else {
                                    T22 = h5.e.T(th17.getClass().getSimpleName(), th17.toString(), AbstractC0034i.k("Cause: ", th17.getCause(), ", Stacktrace: ", Log.getStackTraceString(th17)));
                                }
                            }
                            cVar.g(T22);
                            return;
                    }
                }
            });
        } else {
            uVar3.y(null);
        }
        v3.u uVar4 = new v3.u(fVar, "dev.flutter.pigeon.webview_flutter_android.WebSettings.setJavaScriptEnabled", gVar, (C0508g) null);
        if (c0345i != null) {
            final int i9 = 1;
            uVar4.y(new b() { // from class: c5.J
                @Override // M4.b
                public final void e(Object obj, A.c cVar) {
                    List T6;
                    List T7;
                    List T8;
                    List T9;
                    List T10;
                    List T11;
                    List T12;
                    List T13;
                    List T14;
                    List T15;
                    List T16;
                    List T17;
                    List T18;
                    List T19;
                    List T20;
                    List T21;
                    List T22;
                    switch (i9) {
                        case 0:
                            C0345i c0345i2 = c0345i;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list = (List) obj;
                            Object obj2 = list.get(0);
                            q5.h.c(obj2, "null cannot be cast to non-null type android.webkit.WebSettings");
                            WebSettings webSettings = (WebSettings) obj2;
                            Object obj3 = list.get(1);
                            q5.h.c(obj3, "null cannot be cast to non-null type kotlin.Boolean");
                            boolean booleanValue = ((Boolean) obj3).booleanValue();
                            try {
                                c0345i2.getClass();
                                webSettings.setDomStorageEnabled(booleanValue);
                                T6 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th) {
                                if (th instanceof C0337a) {
                                    C0337a c0337a = th;
                                    T6 = h5.e.T(c0337a.o, c0337a.f5592p, c0337a.f5593q);
                                } else {
                                    T6 = h5.e.T(th.getClass().getSimpleName(), th.toString(), AbstractC0034i.k("Cause: ", th.getCause(), ", Stacktrace: ", Log.getStackTraceString(th)));
                                }
                            }
                            cVar.g(T6);
                            return;
                        case 1:
                            C0345i c0345i3 = c0345i;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list2 = (List) obj;
                            Object obj4 = list2.get(0);
                            q5.h.c(obj4, "null cannot be cast to non-null type android.webkit.WebSettings");
                            WebSettings webSettings2 = (WebSettings) obj4;
                            Object obj5 = list2.get(1);
                            q5.h.c(obj5, "null cannot be cast to non-null type kotlin.Boolean");
                            boolean booleanValue2 = ((Boolean) obj5).booleanValue();
                            try {
                                c0345i3.getClass();
                                webSettings2.setJavaScriptEnabled(booleanValue2);
                                T7 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th2) {
                                if (th2 instanceof C0337a) {
                                    C0337a c0337a2 = th2;
                                    T7 = h5.e.T(c0337a2.o, c0337a2.f5592p, c0337a2.f5593q);
                                } else {
                                    T7 = h5.e.T(th2.getClass().getSimpleName(), th2.toString(), AbstractC0034i.k("Cause: ", th2.getCause(), ", Stacktrace: ", Log.getStackTraceString(th2)));
                                }
                            }
                            cVar.g(T7);
                            return;
                        case 2:
                            C0345i c0345i4 = c0345i;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list3 = (List) obj;
                            Object obj6 = list3.get(0);
                            q5.h.c(obj6, "null cannot be cast to non-null type android.webkit.WebSettings");
                            WebSettings webSettings3 = (WebSettings) obj6;
                            String str = (String) list3.get(1);
                            try {
                                c0345i4.getClass();
                                webSettings3.setUserAgentString(str);
                                T8 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th3) {
                                if (th3 instanceof C0337a) {
                                    C0337a c0337a3 = th3;
                                    T8 = h5.e.T(c0337a3.o, c0337a3.f5592p, c0337a3.f5593q);
                                } else {
                                    T8 = h5.e.T(th3.getClass().getSimpleName(), th3.toString(), AbstractC0034i.k("Cause: ", th3.getCause(), ", Stacktrace: ", Log.getStackTraceString(th3)));
                                }
                            }
                            cVar.g(T8);
                            return;
                        case 3:
                            C0345i c0345i5 = c0345i;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list4 = (List) obj;
                            Object obj7 = list4.get(0);
                            q5.h.c(obj7, "null cannot be cast to non-null type android.webkit.WebSettings");
                            WebSettings webSettings4 = (WebSettings) obj7;
                            Object obj8 = list4.get(1);
                            q5.h.c(obj8, "null cannot be cast to non-null type kotlin.Boolean");
                            boolean booleanValue3 = ((Boolean) obj8).booleanValue();
                            try {
                                c0345i5.getClass();
                                webSettings4.setMediaPlaybackRequiresUserGesture(booleanValue3);
                                T9 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th4) {
                                if (th4 instanceof C0337a) {
                                    C0337a c0337a4 = th4;
                                    T9 = h5.e.T(c0337a4.o, c0337a4.f5592p, c0337a4.f5593q);
                                } else {
                                    T9 = h5.e.T(th4.getClass().getSimpleName(), th4.toString(), AbstractC0034i.k("Cause: ", th4.getCause(), ", Stacktrace: ", Log.getStackTraceString(th4)));
                                }
                            }
                            cVar.g(T9);
                            return;
                        case 4:
                            C0345i c0345i6 = c0345i;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list5 = (List) obj;
                            Object obj9 = list5.get(0);
                            q5.h.c(obj9, "null cannot be cast to non-null type android.webkit.WebSettings");
                            WebSettings webSettings5 = (WebSettings) obj9;
                            Object obj10 = list5.get(1);
                            q5.h.c(obj10, "null cannot be cast to non-null type kotlin.Boolean");
                            boolean booleanValue4 = ((Boolean) obj10).booleanValue();
                            try {
                                c0345i6.getClass();
                                webSettings5.setSupportZoom(booleanValue4);
                                T10 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th5) {
                                if (th5 instanceof C0337a) {
                                    C0337a c0337a5 = th5;
                                    T10 = h5.e.T(c0337a5.o, c0337a5.f5592p, c0337a5.f5593q);
                                } else {
                                    T10 = h5.e.T(th5.getClass().getSimpleName(), th5.toString(), AbstractC0034i.k("Cause: ", th5.getCause(), ", Stacktrace: ", Log.getStackTraceString(th5)));
                                }
                            }
                            cVar.g(T10);
                            return;
                        case 5:
                            C0345i c0345i7 = c0345i;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list6 = (List) obj;
                            Object obj11 = list6.get(0);
                            q5.h.c(obj11, "null cannot be cast to non-null type android.webkit.WebSettings");
                            WebSettings webSettings6 = (WebSettings) obj11;
                            Object obj12 = list6.get(1);
                            q5.h.c(obj12, "null cannot be cast to non-null type kotlin.Boolean");
                            boolean booleanValue5 = ((Boolean) obj12).booleanValue();
                            try {
                                c0345i7.getClass();
                                webSettings6.setLoadWithOverviewMode(booleanValue5);
                                T11 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th6) {
                                if (th6 instanceof C0337a) {
                                    C0337a c0337a6 = th6;
                                    T11 = h5.e.T(c0337a6.o, c0337a6.f5592p, c0337a6.f5593q);
                                } else {
                                    T11 = h5.e.T(th6.getClass().getSimpleName(), th6.toString(), AbstractC0034i.k("Cause: ", th6.getCause(), ", Stacktrace: ", Log.getStackTraceString(th6)));
                                }
                            }
                            cVar.g(T11);
                            return;
                        case 6:
                            C0345i c0345i8 = c0345i;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list7 = (List) obj;
                            Object obj13 = list7.get(0);
                            q5.h.c(obj13, "null cannot be cast to non-null type android.webkit.WebSettings");
                            WebSettings webSettings7 = (WebSettings) obj13;
                            Object obj14 = list7.get(1);
                            q5.h.c(obj14, "null cannot be cast to non-null type kotlin.Boolean");
                            boolean booleanValue6 = ((Boolean) obj14).booleanValue();
                            try {
                                c0345i8.getClass();
                                webSettings7.setUseWideViewPort(booleanValue6);
                                T12 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th7) {
                                if (th7 instanceof C0337a) {
                                    C0337a c0337a7 = th7;
                                    T12 = h5.e.T(c0337a7.o, c0337a7.f5592p, c0337a7.f5593q);
                                } else {
                                    T12 = h5.e.T(th7.getClass().getSimpleName(), th7.toString(), AbstractC0034i.k("Cause: ", th7.getCause(), ", Stacktrace: ", Log.getStackTraceString(th7)));
                                }
                            }
                            cVar.g(T12);
                            return;
                        case 7:
                            C0345i c0345i9 = c0345i;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list8 = (List) obj;
                            Object obj15 = list8.get(0);
                            q5.h.c(obj15, "null cannot be cast to non-null type android.webkit.WebSettings");
                            WebSettings webSettings8 = (WebSettings) obj15;
                            Object obj16 = list8.get(1);
                            q5.h.c(obj16, "null cannot be cast to non-null type kotlin.Boolean");
                            boolean booleanValue7 = ((Boolean) obj16).booleanValue();
                            try {
                                c0345i9.getClass();
                                webSettings8.setDisplayZoomControls(booleanValue7);
                                T13 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th8) {
                                if (th8 instanceof C0337a) {
                                    C0337a c0337a8 = th8;
                                    T13 = h5.e.T(c0337a8.o, c0337a8.f5592p, c0337a8.f5593q);
                                } else {
                                    T13 = h5.e.T(th8.getClass().getSimpleName(), th8.toString(), AbstractC0034i.k("Cause: ", th8.getCause(), ", Stacktrace: ", Log.getStackTraceString(th8)));
                                }
                            }
                            cVar.g(T13);
                            return;
                        case 8:
                            C0345i c0345i10 = c0345i;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list9 = (List) obj;
                            Object obj17 = list9.get(0);
                            q5.h.c(obj17, "null cannot be cast to non-null type android.webkit.WebSettings");
                            WebSettings webSettings9 = (WebSettings) obj17;
                            Object obj18 = list9.get(1);
                            q5.h.c(obj18, "null cannot be cast to non-null type kotlin.Boolean");
                            boolean booleanValue8 = ((Boolean) obj18).booleanValue();
                            try {
                                c0345i10.getClass();
                                webSettings9.setBuiltInZoomControls(booleanValue8);
                                T14 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th9) {
                                if (th9 instanceof C0337a) {
                                    C0337a c0337a9 = th9;
                                    T14 = h5.e.T(c0337a9.o, c0337a9.f5592p, c0337a9.f5593q);
                                } else {
                                    T14 = h5.e.T(th9.getClass().getSimpleName(), th9.toString(), AbstractC0034i.k("Cause: ", th9.getCause(), ", Stacktrace: ", Log.getStackTraceString(th9)));
                                }
                            }
                            cVar.g(T14);
                            return;
                        case ContentHandlerProxy.PROCESSING_INSTRUCTION /* 9 */:
                            C0345i c0345i11 = c0345i;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list10 = (List) obj;
                            Object obj19 = list10.get(0);
                            q5.h.c(obj19, "null cannot be cast to non-null type android.webkit.WebSettings");
                            WebSettings webSettings10 = (WebSettings) obj19;
                            Object obj20 = list10.get(1);
                            q5.h.c(obj20, "null cannot be cast to non-null type kotlin.Boolean");
                            boolean booleanValue9 = ((Boolean) obj20).booleanValue();
                            try {
                                c0345i11.getClass();
                                webSettings10.setAllowFileAccess(booleanValue9);
                                T15 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th10) {
                                if (th10 instanceof C0337a) {
                                    C0337a c0337a10 = th10;
                                    T15 = h5.e.T(c0337a10.o, c0337a10.f5592p, c0337a10.f5593q);
                                } else {
                                    T15 = h5.e.T(th10.getClass().getSimpleName(), th10.toString(), AbstractC0034i.k("Cause: ", th10.getCause(), ", Stacktrace: ", Log.getStackTraceString(th10)));
                                }
                            }
                            cVar.g(T15);
                            return;
                        case 10:
                            C0345i c0345i12 = c0345i;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list11 = (List) obj;
                            Object obj21 = list11.get(0);
                            q5.h.c(obj21, "null cannot be cast to non-null type android.webkit.WebSettings");
                            WebSettings webSettings11 = (WebSettings) obj21;
                            Object obj22 = list11.get(1);
                            q5.h.c(obj22, "null cannot be cast to non-null type kotlin.Boolean");
                            boolean booleanValue10 = ((Boolean) obj22).booleanValue();
                            try {
                                c0345i12.getClass();
                                webSettings11.setAllowContentAccess(booleanValue10);
                                T16 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th11) {
                                if (th11 instanceof C0337a) {
                                    C0337a c0337a11 = th11;
                                    T16 = h5.e.T(c0337a11.o, c0337a11.f5592p, c0337a11.f5593q);
                                } else {
                                    T16 = h5.e.T(th11.getClass().getSimpleName(), th11.toString(), AbstractC0034i.k("Cause: ", th11.getCause(), ", Stacktrace: ", Log.getStackTraceString(th11)));
                                }
                            }
                            cVar.g(T16);
                            return;
                        case 11:
                            C0345i c0345i13 = c0345i;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list12 = (List) obj;
                            Object obj23 = list12.get(0);
                            q5.h.c(obj23, "null cannot be cast to non-null type android.webkit.WebSettings");
                            WebSettings webSettings12 = (WebSettings) obj23;
                            Object obj24 = list12.get(1);
                            q5.h.c(obj24, "null cannot be cast to non-null type kotlin.Boolean");
                            boolean booleanValue11 = ((Boolean) obj24).booleanValue();
                            try {
                                c0345i13.getClass();
                                webSettings12.setGeolocationEnabled(booleanValue11);
                                T17 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th12) {
                                if (th12 instanceof C0337a) {
                                    C0337a c0337a12 = th12;
                                    T17 = h5.e.T(c0337a12.o, c0337a12.f5592p, c0337a12.f5593q);
                                } else {
                                    T17 = h5.e.T(th12.getClass().getSimpleName(), th12.toString(), AbstractC0034i.k("Cause: ", th12.getCause(), ", Stacktrace: ", Log.getStackTraceString(th12)));
                                }
                            }
                            cVar.g(T17);
                            return;
                        case 12:
                            C0345i c0345i14 = c0345i;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list13 = (List) obj;
                            Object obj25 = list13.get(0);
                            q5.h.c(obj25, "null cannot be cast to non-null type android.webkit.WebSettings");
                            WebSettings webSettings13 = (WebSettings) obj25;
                            Object obj26 = list13.get(1);
                            q5.h.c(obj26, "null cannot be cast to non-null type kotlin.Long");
                            long longValue = ((Long) obj26).longValue();
                            try {
                                c0345i14.getClass();
                                webSettings13.setTextZoom((int) longValue);
                                T18 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th13) {
                                if (th13 instanceof C0337a) {
                                    C0337a c0337a13 = th13;
                                    T18 = h5.e.T(c0337a13.o, c0337a13.f5592p, c0337a13.f5593q);
                                } else {
                                    T18 = h5.e.T(th13.getClass().getSimpleName(), th13.toString(), AbstractC0034i.k("Cause: ", th13.getCause(), ", Stacktrace: ", Log.getStackTraceString(th13)));
                                }
                            }
                            cVar.g(T18);
                            return;
                        case 13:
                            C0345i c0345i15 = c0345i;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            Object obj27 = ((List) obj).get(0);
                            q5.h.c(obj27, "null cannot be cast to non-null type android.webkit.WebSettings");
                            WebSettings webSettings14 = (WebSettings) obj27;
                            try {
                                c0345i15.getClass();
                                T19 = android.support.v4.media.session.a.z(webSettings14.getUserAgentString());
                            } catch (Throwable th14) {
                                if (th14 instanceof C0337a) {
                                    C0337a c0337a14 = th14;
                                    T19 = h5.e.T(c0337a14.o, c0337a14.f5592p, c0337a14.f5593q);
                                } else {
                                    T19 = h5.e.T(th14.getClass().getSimpleName(), th14.toString(), AbstractC0034i.k("Cause: ", th14.getCause(), ", Stacktrace: ", Log.getStackTraceString(th14)));
                                }
                            }
                            cVar.g(T19);
                            return;
                        case 14:
                            C0345i c0345i16 = c0345i;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list14 = (List) obj;
                            Object obj28 = list14.get(0);
                            q5.h.c(obj28, "null cannot be cast to non-null type android.webkit.WebSettings");
                            WebSettings webSettings15 = (WebSettings) obj28;
                            Object obj29 = list14.get(1);
                            q5.h.c(obj29, "null cannot be cast to non-null type io.flutter.plugins.webviewflutter.MixedContentMode");
                            EnumC0359w enumC0359w = (EnumC0359w) obj29;
                            try {
                                c0345i16.getClass();
                                int ordinal = enumC0359w.ordinal();
                                if (ordinal != 0) {
                                    if (ordinal != 1) {
                                        if (ordinal == 2) {
                                            webSettings15.setMixedContentMode(1);
                                        }
                                    } else {
                                        webSettings15.setMixedContentMode(2);
                                    }
                                } else {
                                    webSettings15.setMixedContentMode(0);
                                }
                                T20 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th15) {
                                if (th15 instanceof C0337a) {
                                    C0337a c0337a15 = th15;
                                    T20 = h5.e.T(c0337a15.o, c0337a15.f5592p, c0337a15.f5593q);
                                } else {
                                    T20 = h5.e.T(th15.getClass().getSimpleName(), th15.toString(), AbstractC0034i.k("Cause: ", th15.getCause(), ", Stacktrace: ", Log.getStackTraceString(th15)));
                                }
                            }
                            cVar.g(T20);
                            return;
                        case 15:
                            C0345i c0345i17 = c0345i;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list15 = (List) obj;
                            Object obj30 = list15.get(0);
                            q5.h.c(obj30, "null cannot be cast to non-null type android.webkit.WebSettings");
                            WebSettings webSettings16 = (WebSettings) obj30;
                            Object obj31 = list15.get(1);
                            q5.h.c(obj31, "null cannot be cast to non-null type kotlin.Boolean");
                            boolean booleanValue12 = ((Boolean) obj31).booleanValue();
                            try {
                                c0345i17.getClass();
                                webSettings16.setJavaScriptCanOpenWindowsAutomatically(booleanValue12);
                                T21 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th16) {
                                if (th16 instanceof C0337a) {
                                    C0337a c0337a16 = th16;
                                    T21 = h5.e.T(c0337a16.o, c0337a16.f5592p, c0337a16.f5593q);
                                } else {
                                    T21 = h5.e.T(th16.getClass().getSimpleName(), th16.toString(), AbstractC0034i.k("Cause: ", th16.getCause(), ", Stacktrace: ", Log.getStackTraceString(th16)));
                                }
                            }
                            cVar.g(T21);
                            return;
                        default:
                            C0345i c0345i18 = c0345i;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list16 = (List) obj;
                            Object obj32 = list16.get(0);
                            q5.h.c(obj32, "null cannot be cast to non-null type android.webkit.WebSettings");
                            WebSettings webSettings17 = (WebSettings) obj32;
                            Object obj33 = list16.get(1);
                            q5.h.c(obj33, "null cannot be cast to non-null type kotlin.Boolean");
                            boolean booleanValue13 = ((Boolean) obj33).booleanValue();
                            try {
                                c0345i18.getClass();
                                webSettings17.setSupportMultipleWindows(booleanValue13);
                                T22 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th17) {
                                if (th17 instanceof C0337a) {
                                    C0337a c0337a17 = th17;
                                    T22 = h5.e.T(c0337a17.o, c0337a17.f5592p, c0337a17.f5593q);
                                } else {
                                    T22 = h5.e.T(th17.getClass().getSimpleName(), th17.toString(), AbstractC0034i.k("Cause: ", th17.getCause(), ", Stacktrace: ", Log.getStackTraceString(th17)));
                                }
                            }
                            cVar.g(T22);
                            return;
                    }
                }
            });
        } else {
            uVar4.y(null);
        }
        v3.u uVar5 = new v3.u(fVar, "dev.flutter.pigeon.webview_flutter_android.WebSettings.setUserAgentString", gVar, (C0508g) null);
        if (c0345i != null) {
            final int i10 = 2;
            uVar5.y(new b() { // from class: c5.J
                @Override // M4.b
                public final void e(Object obj, A.c cVar) {
                    List T6;
                    List T7;
                    List T8;
                    List T9;
                    List T10;
                    List T11;
                    List T12;
                    List T13;
                    List T14;
                    List T15;
                    List T16;
                    List T17;
                    List T18;
                    List T19;
                    List T20;
                    List T21;
                    List T22;
                    switch (i10) {
                        case 0:
                            C0345i c0345i2 = c0345i;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list = (List) obj;
                            Object obj2 = list.get(0);
                            q5.h.c(obj2, "null cannot be cast to non-null type android.webkit.WebSettings");
                            WebSettings webSettings = (WebSettings) obj2;
                            Object obj3 = list.get(1);
                            q5.h.c(obj3, "null cannot be cast to non-null type kotlin.Boolean");
                            boolean booleanValue = ((Boolean) obj3).booleanValue();
                            try {
                                c0345i2.getClass();
                                webSettings.setDomStorageEnabled(booleanValue);
                                T6 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th) {
                                if (th instanceof C0337a) {
                                    C0337a c0337a = th;
                                    T6 = h5.e.T(c0337a.o, c0337a.f5592p, c0337a.f5593q);
                                } else {
                                    T6 = h5.e.T(th.getClass().getSimpleName(), th.toString(), AbstractC0034i.k("Cause: ", th.getCause(), ", Stacktrace: ", Log.getStackTraceString(th)));
                                }
                            }
                            cVar.g(T6);
                            return;
                        case 1:
                            C0345i c0345i3 = c0345i;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list2 = (List) obj;
                            Object obj4 = list2.get(0);
                            q5.h.c(obj4, "null cannot be cast to non-null type android.webkit.WebSettings");
                            WebSettings webSettings2 = (WebSettings) obj4;
                            Object obj5 = list2.get(1);
                            q5.h.c(obj5, "null cannot be cast to non-null type kotlin.Boolean");
                            boolean booleanValue2 = ((Boolean) obj5).booleanValue();
                            try {
                                c0345i3.getClass();
                                webSettings2.setJavaScriptEnabled(booleanValue2);
                                T7 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th2) {
                                if (th2 instanceof C0337a) {
                                    C0337a c0337a2 = th2;
                                    T7 = h5.e.T(c0337a2.o, c0337a2.f5592p, c0337a2.f5593q);
                                } else {
                                    T7 = h5.e.T(th2.getClass().getSimpleName(), th2.toString(), AbstractC0034i.k("Cause: ", th2.getCause(), ", Stacktrace: ", Log.getStackTraceString(th2)));
                                }
                            }
                            cVar.g(T7);
                            return;
                        case 2:
                            C0345i c0345i4 = c0345i;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list3 = (List) obj;
                            Object obj6 = list3.get(0);
                            q5.h.c(obj6, "null cannot be cast to non-null type android.webkit.WebSettings");
                            WebSettings webSettings3 = (WebSettings) obj6;
                            String str = (String) list3.get(1);
                            try {
                                c0345i4.getClass();
                                webSettings3.setUserAgentString(str);
                                T8 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th3) {
                                if (th3 instanceof C0337a) {
                                    C0337a c0337a3 = th3;
                                    T8 = h5.e.T(c0337a3.o, c0337a3.f5592p, c0337a3.f5593q);
                                } else {
                                    T8 = h5.e.T(th3.getClass().getSimpleName(), th3.toString(), AbstractC0034i.k("Cause: ", th3.getCause(), ", Stacktrace: ", Log.getStackTraceString(th3)));
                                }
                            }
                            cVar.g(T8);
                            return;
                        case 3:
                            C0345i c0345i5 = c0345i;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list4 = (List) obj;
                            Object obj7 = list4.get(0);
                            q5.h.c(obj7, "null cannot be cast to non-null type android.webkit.WebSettings");
                            WebSettings webSettings4 = (WebSettings) obj7;
                            Object obj8 = list4.get(1);
                            q5.h.c(obj8, "null cannot be cast to non-null type kotlin.Boolean");
                            boolean booleanValue3 = ((Boolean) obj8).booleanValue();
                            try {
                                c0345i5.getClass();
                                webSettings4.setMediaPlaybackRequiresUserGesture(booleanValue3);
                                T9 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th4) {
                                if (th4 instanceof C0337a) {
                                    C0337a c0337a4 = th4;
                                    T9 = h5.e.T(c0337a4.o, c0337a4.f5592p, c0337a4.f5593q);
                                } else {
                                    T9 = h5.e.T(th4.getClass().getSimpleName(), th4.toString(), AbstractC0034i.k("Cause: ", th4.getCause(), ", Stacktrace: ", Log.getStackTraceString(th4)));
                                }
                            }
                            cVar.g(T9);
                            return;
                        case 4:
                            C0345i c0345i6 = c0345i;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list5 = (List) obj;
                            Object obj9 = list5.get(0);
                            q5.h.c(obj9, "null cannot be cast to non-null type android.webkit.WebSettings");
                            WebSettings webSettings5 = (WebSettings) obj9;
                            Object obj10 = list5.get(1);
                            q5.h.c(obj10, "null cannot be cast to non-null type kotlin.Boolean");
                            boolean booleanValue4 = ((Boolean) obj10).booleanValue();
                            try {
                                c0345i6.getClass();
                                webSettings5.setSupportZoom(booleanValue4);
                                T10 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th5) {
                                if (th5 instanceof C0337a) {
                                    C0337a c0337a5 = th5;
                                    T10 = h5.e.T(c0337a5.o, c0337a5.f5592p, c0337a5.f5593q);
                                } else {
                                    T10 = h5.e.T(th5.getClass().getSimpleName(), th5.toString(), AbstractC0034i.k("Cause: ", th5.getCause(), ", Stacktrace: ", Log.getStackTraceString(th5)));
                                }
                            }
                            cVar.g(T10);
                            return;
                        case 5:
                            C0345i c0345i7 = c0345i;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list6 = (List) obj;
                            Object obj11 = list6.get(0);
                            q5.h.c(obj11, "null cannot be cast to non-null type android.webkit.WebSettings");
                            WebSettings webSettings6 = (WebSettings) obj11;
                            Object obj12 = list6.get(1);
                            q5.h.c(obj12, "null cannot be cast to non-null type kotlin.Boolean");
                            boolean booleanValue5 = ((Boolean) obj12).booleanValue();
                            try {
                                c0345i7.getClass();
                                webSettings6.setLoadWithOverviewMode(booleanValue5);
                                T11 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th6) {
                                if (th6 instanceof C0337a) {
                                    C0337a c0337a6 = th6;
                                    T11 = h5.e.T(c0337a6.o, c0337a6.f5592p, c0337a6.f5593q);
                                } else {
                                    T11 = h5.e.T(th6.getClass().getSimpleName(), th6.toString(), AbstractC0034i.k("Cause: ", th6.getCause(), ", Stacktrace: ", Log.getStackTraceString(th6)));
                                }
                            }
                            cVar.g(T11);
                            return;
                        case 6:
                            C0345i c0345i8 = c0345i;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list7 = (List) obj;
                            Object obj13 = list7.get(0);
                            q5.h.c(obj13, "null cannot be cast to non-null type android.webkit.WebSettings");
                            WebSettings webSettings7 = (WebSettings) obj13;
                            Object obj14 = list7.get(1);
                            q5.h.c(obj14, "null cannot be cast to non-null type kotlin.Boolean");
                            boolean booleanValue6 = ((Boolean) obj14).booleanValue();
                            try {
                                c0345i8.getClass();
                                webSettings7.setUseWideViewPort(booleanValue6);
                                T12 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th7) {
                                if (th7 instanceof C0337a) {
                                    C0337a c0337a7 = th7;
                                    T12 = h5.e.T(c0337a7.o, c0337a7.f5592p, c0337a7.f5593q);
                                } else {
                                    T12 = h5.e.T(th7.getClass().getSimpleName(), th7.toString(), AbstractC0034i.k("Cause: ", th7.getCause(), ", Stacktrace: ", Log.getStackTraceString(th7)));
                                }
                            }
                            cVar.g(T12);
                            return;
                        case 7:
                            C0345i c0345i9 = c0345i;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list8 = (List) obj;
                            Object obj15 = list8.get(0);
                            q5.h.c(obj15, "null cannot be cast to non-null type android.webkit.WebSettings");
                            WebSettings webSettings8 = (WebSettings) obj15;
                            Object obj16 = list8.get(1);
                            q5.h.c(obj16, "null cannot be cast to non-null type kotlin.Boolean");
                            boolean booleanValue7 = ((Boolean) obj16).booleanValue();
                            try {
                                c0345i9.getClass();
                                webSettings8.setDisplayZoomControls(booleanValue7);
                                T13 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th8) {
                                if (th8 instanceof C0337a) {
                                    C0337a c0337a8 = th8;
                                    T13 = h5.e.T(c0337a8.o, c0337a8.f5592p, c0337a8.f5593q);
                                } else {
                                    T13 = h5.e.T(th8.getClass().getSimpleName(), th8.toString(), AbstractC0034i.k("Cause: ", th8.getCause(), ", Stacktrace: ", Log.getStackTraceString(th8)));
                                }
                            }
                            cVar.g(T13);
                            return;
                        case 8:
                            C0345i c0345i10 = c0345i;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list9 = (List) obj;
                            Object obj17 = list9.get(0);
                            q5.h.c(obj17, "null cannot be cast to non-null type android.webkit.WebSettings");
                            WebSettings webSettings9 = (WebSettings) obj17;
                            Object obj18 = list9.get(1);
                            q5.h.c(obj18, "null cannot be cast to non-null type kotlin.Boolean");
                            boolean booleanValue8 = ((Boolean) obj18).booleanValue();
                            try {
                                c0345i10.getClass();
                                webSettings9.setBuiltInZoomControls(booleanValue8);
                                T14 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th9) {
                                if (th9 instanceof C0337a) {
                                    C0337a c0337a9 = th9;
                                    T14 = h5.e.T(c0337a9.o, c0337a9.f5592p, c0337a9.f5593q);
                                } else {
                                    T14 = h5.e.T(th9.getClass().getSimpleName(), th9.toString(), AbstractC0034i.k("Cause: ", th9.getCause(), ", Stacktrace: ", Log.getStackTraceString(th9)));
                                }
                            }
                            cVar.g(T14);
                            return;
                        case ContentHandlerProxy.PROCESSING_INSTRUCTION /* 9 */:
                            C0345i c0345i11 = c0345i;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list10 = (List) obj;
                            Object obj19 = list10.get(0);
                            q5.h.c(obj19, "null cannot be cast to non-null type android.webkit.WebSettings");
                            WebSettings webSettings10 = (WebSettings) obj19;
                            Object obj20 = list10.get(1);
                            q5.h.c(obj20, "null cannot be cast to non-null type kotlin.Boolean");
                            boolean booleanValue9 = ((Boolean) obj20).booleanValue();
                            try {
                                c0345i11.getClass();
                                webSettings10.setAllowFileAccess(booleanValue9);
                                T15 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th10) {
                                if (th10 instanceof C0337a) {
                                    C0337a c0337a10 = th10;
                                    T15 = h5.e.T(c0337a10.o, c0337a10.f5592p, c0337a10.f5593q);
                                } else {
                                    T15 = h5.e.T(th10.getClass().getSimpleName(), th10.toString(), AbstractC0034i.k("Cause: ", th10.getCause(), ", Stacktrace: ", Log.getStackTraceString(th10)));
                                }
                            }
                            cVar.g(T15);
                            return;
                        case 10:
                            C0345i c0345i12 = c0345i;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list11 = (List) obj;
                            Object obj21 = list11.get(0);
                            q5.h.c(obj21, "null cannot be cast to non-null type android.webkit.WebSettings");
                            WebSettings webSettings11 = (WebSettings) obj21;
                            Object obj22 = list11.get(1);
                            q5.h.c(obj22, "null cannot be cast to non-null type kotlin.Boolean");
                            boolean booleanValue10 = ((Boolean) obj22).booleanValue();
                            try {
                                c0345i12.getClass();
                                webSettings11.setAllowContentAccess(booleanValue10);
                                T16 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th11) {
                                if (th11 instanceof C0337a) {
                                    C0337a c0337a11 = th11;
                                    T16 = h5.e.T(c0337a11.o, c0337a11.f5592p, c0337a11.f5593q);
                                } else {
                                    T16 = h5.e.T(th11.getClass().getSimpleName(), th11.toString(), AbstractC0034i.k("Cause: ", th11.getCause(), ", Stacktrace: ", Log.getStackTraceString(th11)));
                                }
                            }
                            cVar.g(T16);
                            return;
                        case 11:
                            C0345i c0345i13 = c0345i;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list12 = (List) obj;
                            Object obj23 = list12.get(0);
                            q5.h.c(obj23, "null cannot be cast to non-null type android.webkit.WebSettings");
                            WebSettings webSettings12 = (WebSettings) obj23;
                            Object obj24 = list12.get(1);
                            q5.h.c(obj24, "null cannot be cast to non-null type kotlin.Boolean");
                            boolean booleanValue11 = ((Boolean) obj24).booleanValue();
                            try {
                                c0345i13.getClass();
                                webSettings12.setGeolocationEnabled(booleanValue11);
                                T17 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th12) {
                                if (th12 instanceof C0337a) {
                                    C0337a c0337a12 = th12;
                                    T17 = h5.e.T(c0337a12.o, c0337a12.f5592p, c0337a12.f5593q);
                                } else {
                                    T17 = h5.e.T(th12.getClass().getSimpleName(), th12.toString(), AbstractC0034i.k("Cause: ", th12.getCause(), ", Stacktrace: ", Log.getStackTraceString(th12)));
                                }
                            }
                            cVar.g(T17);
                            return;
                        case 12:
                            C0345i c0345i14 = c0345i;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list13 = (List) obj;
                            Object obj25 = list13.get(0);
                            q5.h.c(obj25, "null cannot be cast to non-null type android.webkit.WebSettings");
                            WebSettings webSettings13 = (WebSettings) obj25;
                            Object obj26 = list13.get(1);
                            q5.h.c(obj26, "null cannot be cast to non-null type kotlin.Long");
                            long longValue = ((Long) obj26).longValue();
                            try {
                                c0345i14.getClass();
                                webSettings13.setTextZoom((int) longValue);
                                T18 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th13) {
                                if (th13 instanceof C0337a) {
                                    C0337a c0337a13 = th13;
                                    T18 = h5.e.T(c0337a13.o, c0337a13.f5592p, c0337a13.f5593q);
                                } else {
                                    T18 = h5.e.T(th13.getClass().getSimpleName(), th13.toString(), AbstractC0034i.k("Cause: ", th13.getCause(), ", Stacktrace: ", Log.getStackTraceString(th13)));
                                }
                            }
                            cVar.g(T18);
                            return;
                        case 13:
                            C0345i c0345i15 = c0345i;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            Object obj27 = ((List) obj).get(0);
                            q5.h.c(obj27, "null cannot be cast to non-null type android.webkit.WebSettings");
                            WebSettings webSettings14 = (WebSettings) obj27;
                            try {
                                c0345i15.getClass();
                                T19 = android.support.v4.media.session.a.z(webSettings14.getUserAgentString());
                            } catch (Throwable th14) {
                                if (th14 instanceof C0337a) {
                                    C0337a c0337a14 = th14;
                                    T19 = h5.e.T(c0337a14.o, c0337a14.f5592p, c0337a14.f5593q);
                                } else {
                                    T19 = h5.e.T(th14.getClass().getSimpleName(), th14.toString(), AbstractC0034i.k("Cause: ", th14.getCause(), ", Stacktrace: ", Log.getStackTraceString(th14)));
                                }
                            }
                            cVar.g(T19);
                            return;
                        case 14:
                            C0345i c0345i16 = c0345i;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list14 = (List) obj;
                            Object obj28 = list14.get(0);
                            q5.h.c(obj28, "null cannot be cast to non-null type android.webkit.WebSettings");
                            WebSettings webSettings15 = (WebSettings) obj28;
                            Object obj29 = list14.get(1);
                            q5.h.c(obj29, "null cannot be cast to non-null type io.flutter.plugins.webviewflutter.MixedContentMode");
                            EnumC0359w enumC0359w = (EnumC0359w) obj29;
                            try {
                                c0345i16.getClass();
                                int ordinal = enumC0359w.ordinal();
                                if (ordinal != 0) {
                                    if (ordinal != 1) {
                                        if (ordinal == 2) {
                                            webSettings15.setMixedContentMode(1);
                                        }
                                    } else {
                                        webSettings15.setMixedContentMode(2);
                                    }
                                } else {
                                    webSettings15.setMixedContentMode(0);
                                }
                                T20 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th15) {
                                if (th15 instanceof C0337a) {
                                    C0337a c0337a15 = th15;
                                    T20 = h5.e.T(c0337a15.o, c0337a15.f5592p, c0337a15.f5593q);
                                } else {
                                    T20 = h5.e.T(th15.getClass().getSimpleName(), th15.toString(), AbstractC0034i.k("Cause: ", th15.getCause(), ", Stacktrace: ", Log.getStackTraceString(th15)));
                                }
                            }
                            cVar.g(T20);
                            return;
                        case 15:
                            C0345i c0345i17 = c0345i;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list15 = (List) obj;
                            Object obj30 = list15.get(0);
                            q5.h.c(obj30, "null cannot be cast to non-null type android.webkit.WebSettings");
                            WebSettings webSettings16 = (WebSettings) obj30;
                            Object obj31 = list15.get(1);
                            q5.h.c(obj31, "null cannot be cast to non-null type kotlin.Boolean");
                            boolean booleanValue12 = ((Boolean) obj31).booleanValue();
                            try {
                                c0345i17.getClass();
                                webSettings16.setJavaScriptCanOpenWindowsAutomatically(booleanValue12);
                                T21 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th16) {
                                if (th16 instanceof C0337a) {
                                    C0337a c0337a16 = th16;
                                    T21 = h5.e.T(c0337a16.o, c0337a16.f5592p, c0337a16.f5593q);
                                } else {
                                    T21 = h5.e.T(th16.getClass().getSimpleName(), th16.toString(), AbstractC0034i.k("Cause: ", th16.getCause(), ", Stacktrace: ", Log.getStackTraceString(th16)));
                                }
                            }
                            cVar.g(T21);
                            return;
                        default:
                            C0345i c0345i18 = c0345i;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list16 = (List) obj;
                            Object obj32 = list16.get(0);
                            q5.h.c(obj32, "null cannot be cast to non-null type android.webkit.WebSettings");
                            WebSettings webSettings17 = (WebSettings) obj32;
                            Object obj33 = list16.get(1);
                            q5.h.c(obj33, "null cannot be cast to non-null type kotlin.Boolean");
                            boolean booleanValue13 = ((Boolean) obj33).booleanValue();
                            try {
                                c0345i18.getClass();
                                webSettings17.setSupportMultipleWindows(booleanValue13);
                                T22 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th17) {
                                if (th17 instanceof C0337a) {
                                    C0337a c0337a17 = th17;
                                    T22 = h5.e.T(c0337a17.o, c0337a17.f5592p, c0337a17.f5593q);
                                } else {
                                    T22 = h5.e.T(th17.getClass().getSimpleName(), th17.toString(), AbstractC0034i.k("Cause: ", th17.getCause(), ", Stacktrace: ", Log.getStackTraceString(th17)));
                                }
                            }
                            cVar.g(T22);
                            return;
                    }
                }
            });
        } else {
            uVar5.y(null);
        }
        v3.u uVar6 = new v3.u(fVar, "dev.flutter.pigeon.webview_flutter_android.WebSettings.setMediaPlaybackRequiresUserGesture", gVar, (C0508g) null);
        if (c0345i != null) {
            final int i11 = 3;
            uVar6.y(new b() { // from class: c5.J
                @Override // M4.b
                public final void e(Object obj, A.c cVar) {
                    List T6;
                    List T7;
                    List T8;
                    List T9;
                    List T10;
                    List T11;
                    List T12;
                    List T13;
                    List T14;
                    List T15;
                    List T16;
                    List T17;
                    List T18;
                    List T19;
                    List T20;
                    List T21;
                    List T22;
                    switch (i11) {
                        case 0:
                            C0345i c0345i2 = c0345i;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list = (List) obj;
                            Object obj2 = list.get(0);
                            q5.h.c(obj2, "null cannot be cast to non-null type android.webkit.WebSettings");
                            WebSettings webSettings = (WebSettings) obj2;
                            Object obj3 = list.get(1);
                            q5.h.c(obj3, "null cannot be cast to non-null type kotlin.Boolean");
                            boolean booleanValue = ((Boolean) obj3).booleanValue();
                            try {
                                c0345i2.getClass();
                                webSettings.setDomStorageEnabled(booleanValue);
                                T6 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th) {
                                if (th instanceof C0337a) {
                                    C0337a c0337a = th;
                                    T6 = h5.e.T(c0337a.o, c0337a.f5592p, c0337a.f5593q);
                                } else {
                                    T6 = h5.e.T(th.getClass().getSimpleName(), th.toString(), AbstractC0034i.k("Cause: ", th.getCause(), ", Stacktrace: ", Log.getStackTraceString(th)));
                                }
                            }
                            cVar.g(T6);
                            return;
                        case 1:
                            C0345i c0345i3 = c0345i;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list2 = (List) obj;
                            Object obj4 = list2.get(0);
                            q5.h.c(obj4, "null cannot be cast to non-null type android.webkit.WebSettings");
                            WebSettings webSettings2 = (WebSettings) obj4;
                            Object obj5 = list2.get(1);
                            q5.h.c(obj5, "null cannot be cast to non-null type kotlin.Boolean");
                            boolean booleanValue2 = ((Boolean) obj5).booleanValue();
                            try {
                                c0345i3.getClass();
                                webSettings2.setJavaScriptEnabled(booleanValue2);
                                T7 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th2) {
                                if (th2 instanceof C0337a) {
                                    C0337a c0337a2 = th2;
                                    T7 = h5.e.T(c0337a2.o, c0337a2.f5592p, c0337a2.f5593q);
                                } else {
                                    T7 = h5.e.T(th2.getClass().getSimpleName(), th2.toString(), AbstractC0034i.k("Cause: ", th2.getCause(), ", Stacktrace: ", Log.getStackTraceString(th2)));
                                }
                            }
                            cVar.g(T7);
                            return;
                        case 2:
                            C0345i c0345i4 = c0345i;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list3 = (List) obj;
                            Object obj6 = list3.get(0);
                            q5.h.c(obj6, "null cannot be cast to non-null type android.webkit.WebSettings");
                            WebSettings webSettings3 = (WebSettings) obj6;
                            String str = (String) list3.get(1);
                            try {
                                c0345i4.getClass();
                                webSettings3.setUserAgentString(str);
                                T8 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th3) {
                                if (th3 instanceof C0337a) {
                                    C0337a c0337a3 = th3;
                                    T8 = h5.e.T(c0337a3.o, c0337a3.f5592p, c0337a3.f5593q);
                                } else {
                                    T8 = h5.e.T(th3.getClass().getSimpleName(), th3.toString(), AbstractC0034i.k("Cause: ", th3.getCause(), ", Stacktrace: ", Log.getStackTraceString(th3)));
                                }
                            }
                            cVar.g(T8);
                            return;
                        case 3:
                            C0345i c0345i5 = c0345i;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list4 = (List) obj;
                            Object obj7 = list4.get(0);
                            q5.h.c(obj7, "null cannot be cast to non-null type android.webkit.WebSettings");
                            WebSettings webSettings4 = (WebSettings) obj7;
                            Object obj8 = list4.get(1);
                            q5.h.c(obj8, "null cannot be cast to non-null type kotlin.Boolean");
                            boolean booleanValue3 = ((Boolean) obj8).booleanValue();
                            try {
                                c0345i5.getClass();
                                webSettings4.setMediaPlaybackRequiresUserGesture(booleanValue3);
                                T9 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th4) {
                                if (th4 instanceof C0337a) {
                                    C0337a c0337a4 = th4;
                                    T9 = h5.e.T(c0337a4.o, c0337a4.f5592p, c0337a4.f5593q);
                                } else {
                                    T9 = h5.e.T(th4.getClass().getSimpleName(), th4.toString(), AbstractC0034i.k("Cause: ", th4.getCause(), ", Stacktrace: ", Log.getStackTraceString(th4)));
                                }
                            }
                            cVar.g(T9);
                            return;
                        case 4:
                            C0345i c0345i6 = c0345i;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list5 = (List) obj;
                            Object obj9 = list5.get(0);
                            q5.h.c(obj9, "null cannot be cast to non-null type android.webkit.WebSettings");
                            WebSettings webSettings5 = (WebSettings) obj9;
                            Object obj10 = list5.get(1);
                            q5.h.c(obj10, "null cannot be cast to non-null type kotlin.Boolean");
                            boolean booleanValue4 = ((Boolean) obj10).booleanValue();
                            try {
                                c0345i6.getClass();
                                webSettings5.setSupportZoom(booleanValue4);
                                T10 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th5) {
                                if (th5 instanceof C0337a) {
                                    C0337a c0337a5 = th5;
                                    T10 = h5.e.T(c0337a5.o, c0337a5.f5592p, c0337a5.f5593q);
                                } else {
                                    T10 = h5.e.T(th5.getClass().getSimpleName(), th5.toString(), AbstractC0034i.k("Cause: ", th5.getCause(), ", Stacktrace: ", Log.getStackTraceString(th5)));
                                }
                            }
                            cVar.g(T10);
                            return;
                        case 5:
                            C0345i c0345i7 = c0345i;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list6 = (List) obj;
                            Object obj11 = list6.get(0);
                            q5.h.c(obj11, "null cannot be cast to non-null type android.webkit.WebSettings");
                            WebSettings webSettings6 = (WebSettings) obj11;
                            Object obj12 = list6.get(1);
                            q5.h.c(obj12, "null cannot be cast to non-null type kotlin.Boolean");
                            boolean booleanValue5 = ((Boolean) obj12).booleanValue();
                            try {
                                c0345i7.getClass();
                                webSettings6.setLoadWithOverviewMode(booleanValue5);
                                T11 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th6) {
                                if (th6 instanceof C0337a) {
                                    C0337a c0337a6 = th6;
                                    T11 = h5.e.T(c0337a6.o, c0337a6.f5592p, c0337a6.f5593q);
                                } else {
                                    T11 = h5.e.T(th6.getClass().getSimpleName(), th6.toString(), AbstractC0034i.k("Cause: ", th6.getCause(), ", Stacktrace: ", Log.getStackTraceString(th6)));
                                }
                            }
                            cVar.g(T11);
                            return;
                        case 6:
                            C0345i c0345i8 = c0345i;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list7 = (List) obj;
                            Object obj13 = list7.get(0);
                            q5.h.c(obj13, "null cannot be cast to non-null type android.webkit.WebSettings");
                            WebSettings webSettings7 = (WebSettings) obj13;
                            Object obj14 = list7.get(1);
                            q5.h.c(obj14, "null cannot be cast to non-null type kotlin.Boolean");
                            boolean booleanValue6 = ((Boolean) obj14).booleanValue();
                            try {
                                c0345i8.getClass();
                                webSettings7.setUseWideViewPort(booleanValue6);
                                T12 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th7) {
                                if (th7 instanceof C0337a) {
                                    C0337a c0337a7 = th7;
                                    T12 = h5.e.T(c0337a7.o, c0337a7.f5592p, c0337a7.f5593q);
                                } else {
                                    T12 = h5.e.T(th7.getClass().getSimpleName(), th7.toString(), AbstractC0034i.k("Cause: ", th7.getCause(), ", Stacktrace: ", Log.getStackTraceString(th7)));
                                }
                            }
                            cVar.g(T12);
                            return;
                        case 7:
                            C0345i c0345i9 = c0345i;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list8 = (List) obj;
                            Object obj15 = list8.get(0);
                            q5.h.c(obj15, "null cannot be cast to non-null type android.webkit.WebSettings");
                            WebSettings webSettings8 = (WebSettings) obj15;
                            Object obj16 = list8.get(1);
                            q5.h.c(obj16, "null cannot be cast to non-null type kotlin.Boolean");
                            boolean booleanValue7 = ((Boolean) obj16).booleanValue();
                            try {
                                c0345i9.getClass();
                                webSettings8.setDisplayZoomControls(booleanValue7);
                                T13 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th8) {
                                if (th8 instanceof C0337a) {
                                    C0337a c0337a8 = th8;
                                    T13 = h5.e.T(c0337a8.o, c0337a8.f5592p, c0337a8.f5593q);
                                } else {
                                    T13 = h5.e.T(th8.getClass().getSimpleName(), th8.toString(), AbstractC0034i.k("Cause: ", th8.getCause(), ", Stacktrace: ", Log.getStackTraceString(th8)));
                                }
                            }
                            cVar.g(T13);
                            return;
                        case 8:
                            C0345i c0345i10 = c0345i;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list9 = (List) obj;
                            Object obj17 = list9.get(0);
                            q5.h.c(obj17, "null cannot be cast to non-null type android.webkit.WebSettings");
                            WebSettings webSettings9 = (WebSettings) obj17;
                            Object obj18 = list9.get(1);
                            q5.h.c(obj18, "null cannot be cast to non-null type kotlin.Boolean");
                            boolean booleanValue8 = ((Boolean) obj18).booleanValue();
                            try {
                                c0345i10.getClass();
                                webSettings9.setBuiltInZoomControls(booleanValue8);
                                T14 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th9) {
                                if (th9 instanceof C0337a) {
                                    C0337a c0337a9 = th9;
                                    T14 = h5.e.T(c0337a9.o, c0337a9.f5592p, c0337a9.f5593q);
                                } else {
                                    T14 = h5.e.T(th9.getClass().getSimpleName(), th9.toString(), AbstractC0034i.k("Cause: ", th9.getCause(), ", Stacktrace: ", Log.getStackTraceString(th9)));
                                }
                            }
                            cVar.g(T14);
                            return;
                        case ContentHandlerProxy.PROCESSING_INSTRUCTION /* 9 */:
                            C0345i c0345i11 = c0345i;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list10 = (List) obj;
                            Object obj19 = list10.get(0);
                            q5.h.c(obj19, "null cannot be cast to non-null type android.webkit.WebSettings");
                            WebSettings webSettings10 = (WebSettings) obj19;
                            Object obj20 = list10.get(1);
                            q5.h.c(obj20, "null cannot be cast to non-null type kotlin.Boolean");
                            boolean booleanValue9 = ((Boolean) obj20).booleanValue();
                            try {
                                c0345i11.getClass();
                                webSettings10.setAllowFileAccess(booleanValue9);
                                T15 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th10) {
                                if (th10 instanceof C0337a) {
                                    C0337a c0337a10 = th10;
                                    T15 = h5.e.T(c0337a10.o, c0337a10.f5592p, c0337a10.f5593q);
                                } else {
                                    T15 = h5.e.T(th10.getClass().getSimpleName(), th10.toString(), AbstractC0034i.k("Cause: ", th10.getCause(), ", Stacktrace: ", Log.getStackTraceString(th10)));
                                }
                            }
                            cVar.g(T15);
                            return;
                        case 10:
                            C0345i c0345i12 = c0345i;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list11 = (List) obj;
                            Object obj21 = list11.get(0);
                            q5.h.c(obj21, "null cannot be cast to non-null type android.webkit.WebSettings");
                            WebSettings webSettings11 = (WebSettings) obj21;
                            Object obj22 = list11.get(1);
                            q5.h.c(obj22, "null cannot be cast to non-null type kotlin.Boolean");
                            boolean booleanValue10 = ((Boolean) obj22).booleanValue();
                            try {
                                c0345i12.getClass();
                                webSettings11.setAllowContentAccess(booleanValue10);
                                T16 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th11) {
                                if (th11 instanceof C0337a) {
                                    C0337a c0337a11 = th11;
                                    T16 = h5.e.T(c0337a11.o, c0337a11.f5592p, c0337a11.f5593q);
                                } else {
                                    T16 = h5.e.T(th11.getClass().getSimpleName(), th11.toString(), AbstractC0034i.k("Cause: ", th11.getCause(), ", Stacktrace: ", Log.getStackTraceString(th11)));
                                }
                            }
                            cVar.g(T16);
                            return;
                        case 11:
                            C0345i c0345i13 = c0345i;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list12 = (List) obj;
                            Object obj23 = list12.get(0);
                            q5.h.c(obj23, "null cannot be cast to non-null type android.webkit.WebSettings");
                            WebSettings webSettings12 = (WebSettings) obj23;
                            Object obj24 = list12.get(1);
                            q5.h.c(obj24, "null cannot be cast to non-null type kotlin.Boolean");
                            boolean booleanValue11 = ((Boolean) obj24).booleanValue();
                            try {
                                c0345i13.getClass();
                                webSettings12.setGeolocationEnabled(booleanValue11);
                                T17 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th12) {
                                if (th12 instanceof C0337a) {
                                    C0337a c0337a12 = th12;
                                    T17 = h5.e.T(c0337a12.o, c0337a12.f5592p, c0337a12.f5593q);
                                } else {
                                    T17 = h5.e.T(th12.getClass().getSimpleName(), th12.toString(), AbstractC0034i.k("Cause: ", th12.getCause(), ", Stacktrace: ", Log.getStackTraceString(th12)));
                                }
                            }
                            cVar.g(T17);
                            return;
                        case 12:
                            C0345i c0345i14 = c0345i;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list13 = (List) obj;
                            Object obj25 = list13.get(0);
                            q5.h.c(obj25, "null cannot be cast to non-null type android.webkit.WebSettings");
                            WebSettings webSettings13 = (WebSettings) obj25;
                            Object obj26 = list13.get(1);
                            q5.h.c(obj26, "null cannot be cast to non-null type kotlin.Long");
                            long longValue = ((Long) obj26).longValue();
                            try {
                                c0345i14.getClass();
                                webSettings13.setTextZoom((int) longValue);
                                T18 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th13) {
                                if (th13 instanceof C0337a) {
                                    C0337a c0337a13 = th13;
                                    T18 = h5.e.T(c0337a13.o, c0337a13.f5592p, c0337a13.f5593q);
                                } else {
                                    T18 = h5.e.T(th13.getClass().getSimpleName(), th13.toString(), AbstractC0034i.k("Cause: ", th13.getCause(), ", Stacktrace: ", Log.getStackTraceString(th13)));
                                }
                            }
                            cVar.g(T18);
                            return;
                        case 13:
                            C0345i c0345i15 = c0345i;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            Object obj27 = ((List) obj).get(0);
                            q5.h.c(obj27, "null cannot be cast to non-null type android.webkit.WebSettings");
                            WebSettings webSettings14 = (WebSettings) obj27;
                            try {
                                c0345i15.getClass();
                                T19 = android.support.v4.media.session.a.z(webSettings14.getUserAgentString());
                            } catch (Throwable th14) {
                                if (th14 instanceof C0337a) {
                                    C0337a c0337a14 = th14;
                                    T19 = h5.e.T(c0337a14.o, c0337a14.f5592p, c0337a14.f5593q);
                                } else {
                                    T19 = h5.e.T(th14.getClass().getSimpleName(), th14.toString(), AbstractC0034i.k("Cause: ", th14.getCause(), ", Stacktrace: ", Log.getStackTraceString(th14)));
                                }
                            }
                            cVar.g(T19);
                            return;
                        case 14:
                            C0345i c0345i16 = c0345i;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list14 = (List) obj;
                            Object obj28 = list14.get(0);
                            q5.h.c(obj28, "null cannot be cast to non-null type android.webkit.WebSettings");
                            WebSettings webSettings15 = (WebSettings) obj28;
                            Object obj29 = list14.get(1);
                            q5.h.c(obj29, "null cannot be cast to non-null type io.flutter.plugins.webviewflutter.MixedContentMode");
                            EnumC0359w enumC0359w = (EnumC0359w) obj29;
                            try {
                                c0345i16.getClass();
                                int ordinal = enumC0359w.ordinal();
                                if (ordinal != 0) {
                                    if (ordinal != 1) {
                                        if (ordinal == 2) {
                                            webSettings15.setMixedContentMode(1);
                                        }
                                    } else {
                                        webSettings15.setMixedContentMode(2);
                                    }
                                } else {
                                    webSettings15.setMixedContentMode(0);
                                }
                                T20 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th15) {
                                if (th15 instanceof C0337a) {
                                    C0337a c0337a15 = th15;
                                    T20 = h5.e.T(c0337a15.o, c0337a15.f5592p, c0337a15.f5593q);
                                } else {
                                    T20 = h5.e.T(th15.getClass().getSimpleName(), th15.toString(), AbstractC0034i.k("Cause: ", th15.getCause(), ", Stacktrace: ", Log.getStackTraceString(th15)));
                                }
                            }
                            cVar.g(T20);
                            return;
                        case 15:
                            C0345i c0345i17 = c0345i;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list15 = (List) obj;
                            Object obj30 = list15.get(0);
                            q5.h.c(obj30, "null cannot be cast to non-null type android.webkit.WebSettings");
                            WebSettings webSettings16 = (WebSettings) obj30;
                            Object obj31 = list15.get(1);
                            q5.h.c(obj31, "null cannot be cast to non-null type kotlin.Boolean");
                            boolean booleanValue12 = ((Boolean) obj31).booleanValue();
                            try {
                                c0345i17.getClass();
                                webSettings16.setJavaScriptCanOpenWindowsAutomatically(booleanValue12);
                                T21 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th16) {
                                if (th16 instanceof C0337a) {
                                    C0337a c0337a16 = th16;
                                    T21 = h5.e.T(c0337a16.o, c0337a16.f5592p, c0337a16.f5593q);
                                } else {
                                    T21 = h5.e.T(th16.getClass().getSimpleName(), th16.toString(), AbstractC0034i.k("Cause: ", th16.getCause(), ", Stacktrace: ", Log.getStackTraceString(th16)));
                                }
                            }
                            cVar.g(T21);
                            return;
                        default:
                            C0345i c0345i18 = c0345i;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list16 = (List) obj;
                            Object obj32 = list16.get(0);
                            q5.h.c(obj32, "null cannot be cast to non-null type android.webkit.WebSettings");
                            WebSettings webSettings17 = (WebSettings) obj32;
                            Object obj33 = list16.get(1);
                            q5.h.c(obj33, "null cannot be cast to non-null type kotlin.Boolean");
                            boolean booleanValue13 = ((Boolean) obj33).booleanValue();
                            try {
                                c0345i18.getClass();
                                webSettings17.setSupportMultipleWindows(booleanValue13);
                                T22 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th17) {
                                if (th17 instanceof C0337a) {
                                    C0337a c0337a17 = th17;
                                    T22 = h5.e.T(c0337a17.o, c0337a17.f5592p, c0337a17.f5593q);
                                } else {
                                    T22 = h5.e.T(th17.getClass().getSimpleName(), th17.toString(), AbstractC0034i.k("Cause: ", th17.getCause(), ", Stacktrace: ", Log.getStackTraceString(th17)));
                                }
                            }
                            cVar.g(T22);
                            return;
                    }
                }
            });
        } else {
            uVar6.y(null);
        }
        v3.u uVar7 = new v3.u(fVar, "dev.flutter.pigeon.webview_flutter_android.WebSettings.setSupportZoom", gVar, (C0508g) null);
        if (c0345i != null) {
            final int i12 = 4;
            uVar7.y(new b() { // from class: c5.J
                @Override // M4.b
                public final void e(Object obj, A.c cVar) {
                    List T6;
                    List T7;
                    List T8;
                    List T9;
                    List T10;
                    List T11;
                    List T12;
                    List T13;
                    List T14;
                    List T15;
                    List T16;
                    List T17;
                    List T18;
                    List T19;
                    List T20;
                    List T21;
                    List T22;
                    switch (i12) {
                        case 0:
                            C0345i c0345i2 = c0345i;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list = (List) obj;
                            Object obj2 = list.get(0);
                            q5.h.c(obj2, "null cannot be cast to non-null type android.webkit.WebSettings");
                            WebSettings webSettings = (WebSettings) obj2;
                            Object obj3 = list.get(1);
                            q5.h.c(obj3, "null cannot be cast to non-null type kotlin.Boolean");
                            boolean booleanValue = ((Boolean) obj3).booleanValue();
                            try {
                                c0345i2.getClass();
                                webSettings.setDomStorageEnabled(booleanValue);
                                T6 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th) {
                                if (th instanceof C0337a) {
                                    C0337a c0337a = th;
                                    T6 = h5.e.T(c0337a.o, c0337a.f5592p, c0337a.f5593q);
                                } else {
                                    T6 = h5.e.T(th.getClass().getSimpleName(), th.toString(), AbstractC0034i.k("Cause: ", th.getCause(), ", Stacktrace: ", Log.getStackTraceString(th)));
                                }
                            }
                            cVar.g(T6);
                            return;
                        case 1:
                            C0345i c0345i3 = c0345i;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list2 = (List) obj;
                            Object obj4 = list2.get(0);
                            q5.h.c(obj4, "null cannot be cast to non-null type android.webkit.WebSettings");
                            WebSettings webSettings2 = (WebSettings) obj4;
                            Object obj5 = list2.get(1);
                            q5.h.c(obj5, "null cannot be cast to non-null type kotlin.Boolean");
                            boolean booleanValue2 = ((Boolean) obj5).booleanValue();
                            try {
                                c0345i3.getClass();
                                webSettings2.setJavaScriptEnabled(booleanValue2);
                                T7 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th2) {
                                if (th2 instanceof C0337a) {
                                    C0337a c0337a2 = th2;
                                    T7 = h5.e.T(c0337a2.o, c0337a2.f5592p, c0337a2.f5593q);
                                } else {
                                    T7 = h5.e.T(th2.getClass().getSimpleName(), th2.toString(), AbstractC0034i.k("Cause: ", th2.getCause(), ", Stacktrace: ", Log.getStackTraceString(th2)));
                                }
                            }
                            cVar.g(T7);
                            return;
                        case 2:
                            C0345i c0345i4 = c0345i;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list3 = (List) obj;
                            Object obj6 = list3.get(0);
                            q5.h.c(obj6, "null cannot be cast to non-null type android.webkit.WebSettings");
                            WebSettings webSettings3 = (WebSettings) obj6;
                            String str = (String) list3.get(1);
                            try {
                                c0345i4.getClass();
                                webSettings3.setUserAgentString(str);
                                T8 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th3) {
                                if (th3 instanceof C0337a) {
                                    C0337a c0337a3 = th3;
                                    T8 = h5.e.T(c0337a3.o, c0337a3.f5592p, c0337a3.f5593q);
                                } else {
                                    T8 = h5.e.T(th3.getClass().getSimpleName(), th3.toString(), AbstractC0034i.k("Cause: ", th3.getCause(), ", Stacktrace: ", Log.getStackTraceString(th3)));
                                }
                            }
                            cVar.g(T8);
                            return;
                        case 3:
                            C0345i c0345i5 = c0345i;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list4 = (List) obj;
                            Object obj7 = list4.get(0);
                            q5.h.c(obj7, "null cannot be cast to non-null type android.webkit.WebSettings");
                            WebSettings webSettings4 = (WebSettings) obj7;
                            Object obj8 = list4.get(1);
                            q5.h.c(obj8, "null cannot be cast to non-null type kotlin.Boolean");
                            boolean booleanValue3 = ((Boolean) obj8).booleanValue();
                            try {
                                c0345i5.getClass();
                                webSettings4.setMediaPlaybackRequiresUserGesture(booleanValue3);
                                T9 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th4) {
                                if (th4 instanceof C0337a) {
                                    C0337a c0337a4 = th4;
                                    T9 = h5.e.T(c0337a4.o, c0337a4.f5592p, c0337a4.f5593q);
                                } else {
                                    T9 = h5.e.T(th4.getClass().getSimpleName(), th4.toString(), AbstractC0034i.k("Cause: ", th4.getCause(), ", Stacktrace: ", Log.getStackTraceString(th4)));
                                }
                            }
                            cVar.g(T9);
                            return;
                        case 4:
                            C0345i c0345i6 = c0345i;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list5 = (List) obj;
                            Object obj9 = list5.get(0);
                            q5.h.c(obj9, "null cannot be cast to non-null type android.webkit.WebSettings");
                            WebSettings webSettings5 = (WebSettings) obj9;
                            Object obj10 = list5.get(1);
                            q5.h.c(obj10, "null cannot be cast to non-null type kotlin.Boolean");
                            boolean booleanValue4 = ((Boolean) obj10).booleanValue();
                            try {
                                c0345i6.getClass();
                                webSettings5.setSupportZoom(booleanValue4);
                                T10 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th5) {
                                if (th5 instanceof C0337a) {
                                    C0337a c0337a5 = th5;
                                    T10 = h5.e.T(c0337a5.o, c0337a5.f5592p, c0337a5.f5593q);
                                } else {
                                    T10 = h5.e.T(th5.getClass().getSimpleName(), th5.toString(), AbstractC0034i.k("Cause: ", th5.getCause(), ", Stacktrace: ", Log.getStackTraceString(th5)));
                                }
                            }
                            cVar.g(T10);
                            return;
                        case 5:
                            C0345i c0345i7 = c0345i;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list6 = (List) obj;
                            Object obj11 = list6.get(0);
                            q5.h.c(obj11, "null cannot be cast to non-null type android.webkit.WebSettings");
                            WebSettings webSettings6 = (WebSettings) obj11;
                            Object obj12 = list6.get(1);
                            q5.h.c(obj12, "null cannot be cast to non-null type kotlin.Boolean");
                            boolean booleanValue5 = ((Boolean) obj12).booleanValue();
                            try {
                                c0345i7.getClass();
                                webSettings6.setLoadWithOverviewMode(booleanValue5);
                                T11 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th6) {
                                if (th6 instanceof C0337a) {
                                    C0337a c0337a6 = th6;
                                    T11 = h5.e.T(c0337a6.o, c0337a6.f5592p, c0337a6.f5593q);
                                } else {
                                    T11 = h5.e.T(th6.getClass().getSimpleName(), th6.toString(), AbstractC0034i.k("Cause: ", th6.getCause(), ", Stacktrace: ", Log.getStackTraceString(th6)));
                                }
                            }
                            cVar.g(T11);
                            return;
                        case 6:
                            C0345i c0345i8 = c0345i;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list7 = (List) obj;
                            Object obj13 = list7.get(0);
                            q5.h.c(obj13, "null cannot be cast to non-null type android.webkit.WebSettings");
                            WebSettings webSettings7 = (WebSettings) obj13;
                            Object obj14 = list7.get(1);
                            q5.h.c(obj14, "null cannot be cast to non-null type kotlin.Boolean");
                            boolean booleanValue6 = ((Boolean) obj14).booleanValue();
                            try {
                                c0345i8.getClass();
                                webSettings7.setUseWideViewPort(booleanValue6);
                                T12 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th7) {
                                if (th7 instanceof C0337a) {
                                    C0337a c0337a7 = th7;
                                    T12 = h5.e.T(c0337a7.o, c0337a7.f5592p, c0337a7.f5593q);
                                } else {
                                    T12 = h5.e.T(th7.getClass().getSimpleName(), th7.toString(), AbstractC0034i.k("Cause: ", th7.getCause(), ", Stacktrace: ", Log.getStackTraceString(th7)));
                                }
                            }
                            cVar.g(T12);
                            return;
                        case 7:
                            C0345i c0345i9 = c0345i;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list8 = (List) obj;
                            Object obj15 = list8.get(0);
                            q5.h.c(obj15, "null cannot be cast to non-null type android.webkit.WebSettings");
                            WebSettings webSettings8 = (WebSettings) obj15;
                            Object obj16 = list8.get(1);
                            q5.h.c(obj16, "null cannot be cast to non-null type kotlin.Boolean");
                            boolean booleanValue7 = ((Boolean) obj16).booleanValue();
                            try {
                                c0345i9.getClass();
                                webSettings8.setDisplayZoomControls(booleanValue7);
                                T13 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th8) {
                                if (th8 instanceof C0337a) {
                                    C0337a c0337a8 = th8;
                                    T13 = h5.e.T(c0337a8.o, c0337a8.f5592p, c0337a8.f5593q);
                                } else {
                                    T13 = h5.e.T(th8.getClass().getSimpleName(), th8.toString(), AbstractC0034i.k("Cause: ", th8.getCause(), ", Stacktrace: ", Log.getStackTraceString(th8)));
                                }
                            }
                            cVar.g(T13);
                            return;
                        case 8:
                            C0345i c0345i10 = c0345i;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list9 = (List) obj;
                            Object obj17 = list9.get(0);
                            q5.h.c(obj17, "null cannot be cast to non-null type android.webkit.WebSettings");
                            WebSettings webSettings9 = (WebSettings) obj17;
                            Object obj18 = list9.get(1);
                            q5.h.c(obj18, "null cannot be cast to non-null type kotlin.Boolean");
                            boolean booleanValue8 = ((Boolean) obj18).booleanValue();
                            try {
                                c0345i10.getClass();
                                webSettings9.setBuiltInZoomControls(booleanValue8);
                                T14 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th9) {
                                if (th9 instanceof C0337a) {
                                    C0337a c0337a9 = th9;
                                    T14 = h5.e.T(c0337a9.o, c0337a9.f5592p, c0337a9.f5593q);
                                } else {
                                    T14 = h5.e.T(th9.getClass().getSimpleName(), th9.toString(), AbstractC0034i.k("Cause: ", th9.getCause(), ", Stacktrace: ", Log.getStackTraceString(th9)));
                                }
                            }
                            cVar.g(T14);
                            return;
                        case ContentHandlerProxy.PROCESSING_INSTRUCTION /* 9 */:
                            C0345i c0345i11 = c0345i;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list10 = (List) obj;
                            Object obj19 = list10.get(0);
                            q5.h.c(obj19, "null cannot be cast to non-null type android.webkit.WebSettings");
                            WebSettings webSettings10 = (WebSettings) obj19;
                            Object obj20 = list10.get(1);
                            q5.h.c(obj20, "null cannot be cast to non-null type kotlin.Boolean");
                            boolean booleanValue9 = ((Boolean) obj20).booleanValue();
                            try {
                                c0345i11.getClass();
                                webSettings10.setAllowFileAccess(booleanValue9);
                                T15 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th10) {
                                if (th10 instanceof C0337a) {
                                    C0337a c0337a10 = th10;
                                    T15 = h5.e.T(c0337a10.o, c0337a10.f5592p, c0337a10.f5593q);
                                } else {
                                    T15 = h5.e.T(th10.getClass().getSimpleName(), th10.toString(), AbstractC0034i.k("Cause: ", th10.getCause(), ", Stacktrace: ", Log.getStackTraceString(th10)));
                                }
                            }
                            cVar.g(T15);
                            return;
                        case 10:
                            C0345i c0345i12 = c0345i;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list11 = (List) obj;
                            Object obj21 = list11.get(0);
                            q5.h.c(obj21, "null cannot be cast to non-null type android.webkit.WebSettings");
                            WebSettings webSettings11 = (WebSettings) obj21;
                            Object obj22 = list11.get(1);
                            q5.h.c(obj22, "null cannot be cast to non-null type kotlin.Boolean");
                            boolean booleanValue10 = ((Boolean) obj22).booleanValue();
                            try {
                                c0345i12.getClass();
                                webSettings11.setAllowContentAccess(booleanValue10);
                                T16 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th11) {
                                if (th11 instanceof C0337a) {
                                    C0337a c0337a11 = th11;
                                    T16 = h5.e.T(c0337a11.o, c0337a11.f5592p, c0337a11.f5593q);
                                } else {
                                    T16 = h5.e.T(th11.getClass().getSimpleName(), th11.toString(), AbstractC0034i.k("Cause: ", th11.getCause(), ", Stacktrace: ", Log.getStackTraceString(th11)));
                                }
                            }
                            cVar.g(T16);
                            return;
                        case 11:
                            C0345i c0345i13 = c0345i;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list12 = (List) obj;
                            Object obj23 = list12.get(0);
                            q5.h.c(obj23, "null cannot be cast to non-null type android.webkit.WebSettings");
                            WebSettings webSettings12 = (WebSettings) obj23;
                            Object obj24 = list12.get(1);
                            q5.h.c(obj24, "null cannot be cast to non-null type kotlin.Boolean");
                            boolean booleanValue11 = ((Boolean) obj24).booleanValue();
                            try {
                                c0345i13.getClass();
                                webSettings12.setGeolocationEnabled(booleanValue11);
                                T17 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th12) {
                                if (th12 instanceof C0337a) {
                                    C0337a c0337a12 = th12;
                                    T17 = h5.e.T(c0337a12.o, c0337a12.f5592p, c0337a12.f5593q);
                                } else {
                                    T17 = h5.e.T(th12.getClass().getSimpleName(), th12.toString(), AbstractC0034i.k("Cause: ", th12.getCause(), ", Stacktrace: ", Log.getStackTraceString(th12)));
                                }
                            }
                            cVar.g(T17);
                            return;
                        case 12:
                            C0345i c0345i14 = c0345i;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list13 = (List) obj;
                            Object obj25 = list13.get(0);
                            q5.h.c(obj25, "null cannot be cast to non-null type android.webkit.WebSettings");
                            WebSettings webSettings13 = (WebSettings) obj25;
                            Object obj26 = list13.get(1);
                            q5.h.c(obj26, "null cannot be cast to non-null type kotlin.Long");
                            long longValue = ((Long) obj26).longValue();
                            try {
                                c0345i14.getClass();
                                webSettings13.setTextZoom((int) longValue);
                                T18 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th13) {
                                if (th13 instanceof C0337a) {
                                    C0337a c0337a13 = th13;
                                    T18 = h5.e.T(c0337a13.o, c0337a13.f5592p, c0337a13.f5593q);
                                } else {
                                    T18 = h5.e.T(th13.getClass().getSimpleName(), th13.toString(), AbstractC0034i.k("Cause: ", th13.getCause(), ", Stacktrace: ", Log.getStackTraceString(th13)));
                                }
                            }
                            cVar.g(T18);
                            return;
                        case 13:
                            C0345i c0345i15 = c0345i;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            Object obj27 = ((List) obj).get(0);
                            q5.h.c(obj27, "null cannot be cast to non-null type android.webkit.WebSettings");
                            WebSettings webSettings14 = (WebSettings) obj27;
                            try {
                                c0345i15.getClass();
                                T19 = android.support.v4.media.session.a.z(webSettings14.getUserAgentString());
                            } catch (Throwable th14) {
                                if (th14 instanceof C0337a) {
                                    C0337a c0337a14 = th14;
                                    T19 = h5.e.T(c0337a14.o, c0337a14.f5592p, c0337a14.f5593q);
                                } else {
                                    T19 = h5.e.T(th14.getClass().getSimpleName(), th14.toString(), AbstractC0034i.k("Cause: ", th14.getCause(), ", Stacktrace: ", Log.getStackTraceString(th14)));
                                }
                            }
                            cVar.g(T19);
                            return;
                        case 14:
                            C0345i c0345i16 = c0345i;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list14 = (List) obj;
                            Object obj28 = list14.get(0);
                            q5.h.c(obj28, "null cannot be cast to non-null type android.webkit.WebSettings");
                            WebSettings webSettings15 = (WebSettings) obj28;
                            Object obj29 = list14.get(1);
                            q5.h.c(obj29, "null cannot be cast to non-null type io.flutter.plugins.webviewflutter.MixedContentMode");
                            EnumC0359w enumC0359w = (EnumC0359w) obj29;
                            try {
                                c0345i16.getClass();
                                int ordinal = enumC0359w.ordinal();
                                if (ordinal != 0) {
                                    if (ordinal != 1) {
                                        if (ordinal == 2) {
                                            webSettings15.setMixedContentMode(1);
                                        }
                                    } else {
                                        webSettings15.setMixedContentMode(2);
                                    }
                                } else {
                                    webSettings15.setMixedContentMode(0);
                                }
                                T20 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th15) {
                                if (th15 instanceof C0337a) {
                                    C0337a c0337a15 = th15;
                                    T20 = h5.e.T(c0337a15.o, c0337a15.f5592p, c0337a15.f5593q);
                                } else {
                                    T20 = h5.e.T(th15.getClass().getSimpleName(), th15.toString(), AbstractC0034i.k("Cause: ", th15.getCause(), ", Stacktrace: ", Log.getStackTraceString(th15)));
                                }
                            }
                            cVar.g(T20);
                            return;
                        case 15:
                            C0345i c0345i17 = c0345i;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list15 = (List) obj;
                            Object obj30 = list15.get(0);
                            q5.h.c(obj30, "null cannot be cast to non-null type android.webkit.WebSettings");
                            WebSettings webSettings16 = (WebSettings) obj30;
                            Object obj31 = list15.get(1);
                            q5.h.c(obj31, "null cannot be cast to non-null type kotlin.Boolean");
                            boolean booleanValue12 = ((Boolean) obj31).booleanValue();
                            try {
                                c0345i17.getClass();
                                webSettings16.setJavaScriptCanOpenWindowsAutomatically(booleanValue12);
                                T21 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th16) {
                                if (th16 instanceof C0337a) {
                                    C0337a c0337a16 = th16;
                                    T21 = h5.e.T(c0337a16.o, c0337a16.f5592p, c0337a16.f5593q);
                                } else {
                                    T21 = h5.e.T(th16.getClass().getSimpleName(), th16.toString(), AbstractC0034i.k("Cause: ", th16.getCause(), ", Stacktrace: ", Log.getStackTraceString(th16)));
                                }
                            }
                            cVar.g(T21);
                            return;
                        default:
                            C0345i c0345i18 = c0345i;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list16 = (List) obj;
                            Object obj32 = list16.get(0);
                            q5.h.c(obj32, "null cannot be cast to non-null type android.webkit.WebSettings");
                            WebSettings webSettings17 = (WebSettings) obj32;
                            Object obj33 = list16.get(1);
                            q5.h.c(obj33, "null cannot be cast to non-null type kotlin.Boolean");
                            boolean booleanValue13 = ((Boolean) obj33).booleanValue();
                            try {
                                c0345i18.getClass();
                                webSettings17.setSupportMultipleWindows(booleanValue13);
                                T22 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th17) {
                                if (th17 instanceof C0337a) {
                                    C0337a c0337a17 = th17;
                                    T22 = h5.e.T(c0337a17.o, c0337a17.f5592p, c0337a17.f5593q);
                                } else {
                                    T22 = h5.e.T(th17.getClass().getSimpleName(), th17.toString(), AbstractC0034i.k("Cause: ", th17.getCause(), ", Stacktrace: ", Log.getStackTraceString(th17)));
                                }
                            }
                            cVar.g(T22);
                            return;
                    }
                }
            });
        } else {
            uVar7.y(null);
        }
        v3.u uVar8 = new v3.u(fVar, "dev.flutter.pigeon.webview_flutter_android.WebSettings.setLoadWithOverviewMode", gVar, (C0508g) null);
        if (c0345i != null) {
            final int i13 = 5;
            uVar8.y(new b() { // from class: c5.J
                @Override // M4.b
                public final void e(Object obj, A.c cVar) {
                    List T6;
                    List T7;
                    List T8;
                    List T9;
                    List T10;
                    List T11;
                    List T12;
                    List T13;
                    List T14;
                    List T15;
                    List T16;
                    List T17;
                    List T18;
                    List T19;
                    List T20;
                    List T21;
                    List T22;
                    switch (i13) {
                        case 0:
                            C0345i c0345i2 = c0345i;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list = (List) obj;
                            Object obj2 = list.get(0);
                            q5.h.c(obj2, "null cannot be cast to non-null type android.webkit.WebSettings");
                            WebSettings webSettings = (WebSettings) obj2;
                            Object obj3 = list.get(1);
                            q5.h.c(obj3, "null cannot be cast to non-null type kotlin.Boolean");
                            boolean booleanValue = ((Boolean) obj3).booleanValue();
                            try {
                                c0345i2.getClass();
                                webSettings.setDomStorageEnabled(booleanValue);
                                T6 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th) {
                                if (th instanceof C0337a) {
                                    C0337a c0337a = th;
                                    T6 = h5.e.T(c0337a.o, c0337a.f5592p, c0337a.f5593q);
                                } else {
                                    T6 = h5.e.T(th.getClass().getSimpleName(), th.toString(), AbstractC0034i.k("Cause: ", th.getCause(), ", Stacktrace: ", Log.getStackTraceString(th)));
                                }
                            }
                            cVar.g(T6);
                            return;
                        case 1:
                            C0345i c0345i3 = c0345i;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list2 = (List) obj;
                            Object obj4 = list2.get(0);
                            q5.h.c(obj4, "null cannot be cast to non-null type android.webkit.WebSettings");
                            WebSettings webSettings2 = (WebSettings) obj4;
                            Object obj5 = list2.get(1);
                            q5.h.c(obj5, "null cannot be cast to non-null type kotlin.Boolean");
                            boolean booleanValue2 = ((Boolean) obj5).booleanValue();
                            try {
                                c0345i3.getClass();
                                webSettings2.setJavaScriptEnabled(booleanValue2);
                                T7 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th2) {
                                if (th2 instanceof C0337a) {
                                    C0337a c0337a2 = th2;
                                    T7 = h5.e.T(c0337a2.o, c0337a2.f5592p, c0337a2.f5593q);
                                } else {
                                    T7 = h5.e.T(th2.getClass().getSimpleName(), th2.toString(), AbstractC0034i.k("Cause: ", th2.getCause(), ", Stacktrace: ", Log.getStackTraceString(th2)));
                                }
                            }
                            cVar.g(T7);
                            return;
                        case 2:
                            C0345i c0345i4 = c0345i;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list3 = (List) obj;
                            Object obj6 = list3.get(0);
                            q5.h.c(obj6, "null cannot be cast to non-null type android.webkit.WebSettings");
                            WebSettings webSettings3 = (WebSettings) obj6;
                            String str = (String) list3.get(1);
                            try {
                                c0345i4.getClass();
                                webSettings3.setUserAgentString(str);
                                T8 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th3) {
                                if (th3 instanceof C0337a) {
                                    C0337a c0337a3 = th3;
                                    T8 = h5.e.T(c0337a3.o, c0337a3.f5592p, c0337a3.f5593q);
                                } else {
                                    T8 = h5.e.T(th3.getClass().getSimpleName(), th3.toString(), AbstractC0034i.k("Cause: ", th3.getCause(), ", Stacktrace: ", Log.getStackTraceString(th3)));
                                }
                            }
                            cVar.g(T8);
                            return;
                        case 3:
                            C0345i c0345i5 = c0345i;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list4 = (List) obj;
                            Object obj7 = list4.get(0);
                            q5.h.c(obj7, "null cannot be cast to non-null type android.webkit.WebSettings");
                            WebSettings webSettings4 = (WebSettings) obj7;
                            Object obj8 = list4.get(1);
                            q5.h.c(obj8, "null cannot be cast to non-null type kotlin.Boolean");
                            boolean booleanValue3 = ((Boolean) obj8).booleanValue();
                            try {
                                c0345i5.getClass();
                                webSettings4.setMediaPlaybackRequiresUserGesture(booleanValue3);
                                T9 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th4) {
                                if (th4 instanceof C0337a) {
                                    C0337a c0337a4 = th4;
                                    T9 = h5.e.T(c0337a4.o, c0337a4.f5592p, c0337a4.f5593q);
                                } else {
                                    T9 = h5.e.T(th4.getClass().getSimpleName(), th4.toString(), AbstractC0034i.k("Cause: ", th4.getCause(), ", Stacktrace: ", Log.getStackTraceString(th4)));
                                }
                            }
                            cVar.g(T9);
                            return;
                        case 4:
                            C0345i c0345i6 = c0345i;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list5 = (List) obj;
                            Object obj9 = list5.get(0);
                            q5.h.c(obj9, "null cannot be cast to non-null type android.webkit.WebSettings");
                            WebSettings webSettings5 = (WebSettings) obj9;
                            Object obj10 = list5.get(1);
                            q5.h.c(obj10, "null cannot be cast to non-null type kotlin.Boolean");
                            boolean booleanValue4 = ((Boolean) obj10).booleanValue();
                            try {
                                c0345i6.getClass();
                                webSettings5.setSupportZoom(booleanValue4);
                                T10 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th5) {
                                if (th5 instanceof C0337a) {
                                    C0337a c0337a5 = th5;
                                    T10 = h5.e.T(c0337a5.o, c0337a5.f5592p, c0337a5.f5593q);
                                } else {
                                    T10 = h5.e.T(th5.getClass().getSimpleName(), th5.toString(), AbstractC0034i.k("Cause: ", th5.getCause(), ", Stacktrace: ", Log.getStackTraceString(th5)));
                                }
                            }
                            cVar.g(T10);
                            return;
                        case 5:
                            C0345i c0345i7 = c0345i;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list6 = (List) obj;
                            Object obj11 = list6.get(0);
                            q5.h.c(obj11, "null cannot be cast to non-null type android.webkit.WebSettings");
                            WebSettings webSettings6 = (WebSettings) obj11;
                            Object obj12 = list6.get(1);
                            q5.h.c(obj12, "null cannot be cast to non-null type kotlin.Boolean");
                            boolean booleanValue5 = ((Boolean) obj12).booleanValue();
                            try {
                                c0345i7.getClass();
                                webSettings6.setLoadWithOverviewMode(booleanValue5);
                                T11 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th6) {
                                if (th6 instanceof C0337a) {
                                    C0337a c0337a6 = th6;
                                    T11 = h5.e.T(c0337a6.o, c0337a6.f5592p, c0337a6.f5593q);
                                } else {
                                    T11 = h5.e.T(th6.getClass().getSimpleName(), th6.toString(), AbstractC0034i.k("Cause: ", th6.getCause(), ", Stacktrace: ", Log.getStackTraceString(th6)));
                                }
                            }
                            cVar.g(T11);
                            return;
                        case 6:
                            C0345i c0345i8 = c0345i;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list7 = (List) obj;
                            Object obj13 = list7.get(0);
                            q5.h.c(obj13, "null cannot be cast to non-null type android.webkit.WebSettings");
                            WebSettings webSettings7 = (WebSettings) obj13;
                            Object obj14 = list7.get(1);
                            q5.h.c(obj14, "null cannot be cast to non-null type kotlin.Boolean");
                            boolean booleanValue6 = ((Boolean) obj14).booleanValue();
                            try {
                                c0345i8.getClass();
                                webSettings7.setUseWideViewPort(booleanValue6);
                                T12 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th7) {
                                if (th7 instanceof C0337a) {
                                    C0337a c0337a7 = th7;
                                    T12 = h5.e.T(c0337a7.o, c0337a7.f5592p, c0337a7.f5593q);
                                } else {
                                    T12 = h5.e.T(th7.getClass().getSimpleName(), th7.toString(), AbstractC0034i.k("Cause: ", th7.getCause(), ", Stacktrace: ", Log.getStackTraceString(th7)));
                                }
                            }
                            cVar.g(T12);
                            return;
                        case 7:
                            C0345i c0345i9 = c0345i;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list8 = (List) obj;
                            Object obj15 = list8.get(0);
                            q5.h.c(obj15, "null cannot be cast to non-null type android.webkit.WebSettings");
                            WebSettings webSettings8 = (WebSettings) obj15;
                            Object obj16 = list8.get(1);
                            q5.h.c(obj16, "null cannot be cast to non-null type kotlin.Boolean");
                            boolean booleanValue7 = ((Boolean) obj16).booleanValue();
                            try {
                                c0345i9.getClass();
                                webSettings8.setDisplayZoomControls(booleanValue7);
                                T13 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th8) {
                                if (th8 instanceof C0337a) {
                                    C0337a c0337a8 = th8;
                                    T13 = h5.e.T(c0337a8.o, c0337a8.f5592p, c0337a8.f5593q);
                                } else {
                                    T13 = h5.e.T(th8.getClass().getSimpleName(), th8.toString(), AbstractC0034i.k("Cause: ", th8.getCause(), ", Stacktrace: ", Log.getStackTraceString(th8)));
                                }
                            }
                            cVar.g(T13);
                            return;
                        case 8:
                            C0345i c0345i10 = c0345i;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list9 = (List) obj;
                            Object obj17 = list9.get(0);
                            q5.h.c(obj17, "null cannot be cast to non-null type android.webkit.WebSettings");
                            WebSettings webSettings9 = (WebSettings) obj17;
                            Object obj18 = list9.get(1);
                            q5.h.c(obj18, "null cannot be cast to non-null type kotlin.Boolean");
                            boolean booleanValue8 = ((Boolean) obj18).booleanValue();
                            try {
                                c0345i10.getClass();
                                webSettings9.setBuiltInZoomControls(booleanValue8);
                                T14 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th9) {
                                if (th9 instanceof C0337a) {
                                    C0337a c0337a9 = th9;
                                    T14 = h5.e.T(c0337a9.o, c0337a9.f5592p, c0337a9.f5593q);
                                } else {
                                    T14 = h5.e.T(th9.getClass().getSimpleName(), th9.toString(), AbstractC0034i.k("Cause: ", th9.getCause(), ", Stacktrace: ", Log.getStackTraceString(th9)));
                                }
                            }
                            cVar.g(T14);
                            return;
                        case ContentHandlerProxy.PROCESSING_INSTRUCTION /* 9 */:
                            C0345i c0345i11 = c0345i;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list10 = (List) obj;
                            Object obj19 = list10.get(0);
                            q5.h.c(obj19, "null cannot be cast to non-null type android.webkit.WebSettings");
                            WebSettings webSettings10 = (WebSettings) obj19;
                            Object obj20 = list10.get(1);
                            q5.h.c(obj20, "null cannot be cast to non-null type kotlin.Boolean");
                            boolean booleanValue9 = ((Boolean) obj20).booleanValue();
                            try {
                                c0345i11.getClass();
                                webSettings10.setAllowFileAccess(booleanValue9);
                                T15 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th10) {
                                if (th10 instanceof C0337a) {
                                    C0337a c0337a10 = th10;
                                    T15 = h5.e.T(c0337a10.o, c0337a10.f5592p, c0337a10.f5593q);
                                } else {
                                    T15 = h5.e.T(th10.getClass().getSimpleName(), th10.toString(), AbstractC0034i.k("Cause: ", th10.getCause(), ", Stacktrace: ", Log.getStackTraceString(th10)));
                                }
                            }
                            cVar.g(T15);
                            return;
                        case 10:
                            C0345i c0345i12 = c0345i;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list11 = (List) obj;
                            Object obj21 = list11.get(0);
                            q5.h.c(obj21, "null cannot be cast to non-null type android.webkit.WebSettings");
                            WebSettings webSettings11 = (WebSettings) obj21;
                            Object obj22 = list11.get(1);
                            q5.h.c(obj22, "null cannot be cast to non-null type kotlin.Boolean");
                            boolean booleanValue10 = ((Boolean) obj22).booleanValue();
                            try {
                                c0345i12.getClass();
                                webSettings11.setAllowContentAccess(booleanValue10);
                                T16 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th11) {
                                if (th11 instanceof C0337a) {
                                    C0337a c0337a11 = th11;
                                    T16 = h5.e.T(c0337a11.o, c0337a11.f5592p, c0337a11.f5593q);
                                } else {
                                    T16 = h5.e.T(th11.getClass().getSimpleName(), th11.toString(), AbstractC0034i.k("Cause: ", th11.getCause(), ", Stacktrace: ", Log.getStackTraceString(th11)));
                                }
                            }
                            cVar.g(T16);
                            return;
                        case 11:
                            C0345i c0345i13 = c0345i;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list12 = (List) obj;
                            Object obj23 = list12.get(0);
                            q5.h.c(obj23, "null cannot be cast to non-null type android.webkit.WebSettings");
                            WebSettings webSettings12 = (WebSettings) obj23;
                            Object obj24 = list12.get(1);
                            q5.h.c(obj24, "null cannot be cast to non-null type kotlin.Boolean");
                            boolean booleanValue11 = ((Boolean) obj24).booleanValue();
                            try {
                                c0345i13.getClass();
                                webSettings12.setGeolocationEnabled(booleanValue11);
                                T17 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th12) {
                                if (th12 instanceof C0337a) {
                                    C0337a c0337a12 = th12;
                                    T17 = h5.e.T(c0337a12.o, c0337a12.f5592p, c0337a12.f5593q);
                                } else {
                                    T17 = h5.e.T(th12.getClass().getSimpleName(), th12.toString(), AbstractC0034i.k("Cause: ", th12.getCause(), ", Stacktrace: ", Log.getStackTraceString(th12)));
                                }
                            }
                            cVar.g(T17);
                            return;
                        case 12:
                            C0345i c0345i14 = c0345i;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list13 = (List) obj;
                            Object obj25 = list13.get(0);
                            q5.h.c(obj25, "null cannot be cast to non-null type android.webkit.WebSettings");
                            WebSettings webSettings13 = (WebSettings) obj25;
                            Object obj26 = list13.get(1);
                            q5.h.c(obj26, "null cannot be cast to non-null type kotlin.Long");
                            long longValue = ((Long) obj26).longValue();
                            try {
                                c0345i14.getClass();
                                webSettings13.setTextZoom((int) longValue);
                                T18 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th13) {
                                if (th13 instanceof C0337a) {
                                    C0337a c0337a13 = th13;
                                    T18 = h5.e.T(c0337a13.o, c0337a13.f5592p, c0337a13.f5593q);
                                } else {
                                    T18 = h5.e.T(th13.getClass().getSimpleName(), th13.toString(), AbstractC0034i.k("Cause: ", th13.getCause(), ", Stacktrace: ", Log.getStackTraceString(th13)));
                                }
                            }
                            cVar.g(T18);
                            return;
                        case 13:
                            C0345i c0345i15 = c0345i;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            Object obj27 = ((List) obj).get(0);
                            q5.h.c(obj27, "null cannot be cast to non-null type android.webkit.WebSettings");
                            WebSettings webSettings14 = (WebSettings) obj27;
                            try {
                                c0345i15.getClass();
                                T19 = android.support.v4.media.session.a.z(webSettings14.getUserAgentString());
                            } catch (Throwable th14) {
                                if (th14 instanceof C0337a) {
                                    C0337a c0337a14 = th14;
                                    T19 = h5.e.T(c0337a14.o, c0337a14.f5592p, c0337a14.f5593q);
                                } else {
                                    T19 = h5.e.T(th14.getClass().getSimpleName(), th14.toString(), AbstractC0034i.k("Cause: ", th14.getCause(), ", Stacktrace: ", Log.getStackTraceString(th14)));
                                }
                            }
                            cVar.g(T19);
                            return;
                        case 14:
                            C0345i c0345i16 = c0345i;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list14 = (List) obj;
                            Object obj28 = list14.get(0);
                            q5.h.c(obj28, "null cannot be cast to non-null type android.webkit.WebSettings");
                            WebSettings webSettings15 = (WebSettings) obj28;
                            Object obj29 = list14.get(1);
                            q5.h.c(obj29, "null cannot be cast to non-null type io.flutter.plugins.webviewflutter.MixedContentMode");
                            EnumC0359w enumC0359w = (EnumC0359w) obj29;
                            try {
                                c0345i16.getClass();
                                int ordinal = enumC0359w.ordinal();
                                if (ordinal != 0) {
                                    if (ordinal != 1) {
                                        if (ordinal == 2) {
                                            webSettings15.setMixedContentMode(1);
                                        }
                                    } else {
                                        webSettings15.setMixedContentMode(2);
                                    }
                                } else {
                                    webSettings15.setMixedContentMode(0);
                                }
                                T20 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th15) {
                                if (th15 instanceof C0337a) {
                                    C0337a c0337a15 = th15;
                                    T20 = h5.e.T(c0337a15.o, c0337a15.f5592p, c0337a15.f5593q);
                                } else {
                                    T20 = h5.e.T(th15.getClass().getSimpleName(), th15.toString(), AbstractC0034i.k("Cause: ", th15.getCause(), ", Stacktrace: ", Log.getStackTraceString(th15)));
                                }
                            }
                            cVar.g(T20);
                            return;
                        case 15:
                            C0345i c0345i17 = c0345i;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list15 = (List) obj;
                            Object obj30 = list15.get(0);
                            q5.h.c(obj30, "null cannot be cast to non-null type android.webkit.WebSettings");
                            WebSettings webSettings16 = (WebSettings) obj30;
                            Object obj31 = list15.get(1);
                            q5.h.c(obj31, "null cannot be cast to non-null type kotlin.Boolean");
                            boolean booleanValue12 = ((Boolean) obj31).booleanValue();
                            try {
                                c0345i17.getClass();
                                webSettings16.setJavaScriptCanOpenWindowsAutomatically(booleanValue12);
                                T21 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th16) {
                                if (th16 instanceof C0337a) {
                                    C0337a c0337a16 = th16;
                                    T21 = h5.e.T(c0337a16.o, c0337a16.f5592p, c0337a16.f5593q);
                                } else {
                                    T21 = h5.e.T(th16.getClass().getSimpleName(), th16.toString(), AbstractC0034i.k("Cause: ", th16.getCause(), ", Stacktrace: ", Log.getStackTraceString(th16)));
                                }
                            }
                            cVar.g(T21);
                            return;
                        default:
                            C0345i c0345i18 = c0345i;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list16 = (List) obj;
                            Object obj32 = list16.get(0);
                            q5.h.c(obj32, "null cannot be cast to non-null type android.webkit.WebSettings");
                            WebSettings webSettings17 = (WebSettings) obj32;
                            Object obj33 = list16.get(1);
                            q5.h.c(obj33, "null cannot be cast to non-null type kotlin.Boolean");
                            boolean booleanValue13 = ((Boolean) obj33).booleanValue();
                            try {
                                c0345i18.getClass();
                                webSettings17.setSupportMultipleWindows(booleanValue13);
                                T22 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th17) {
                                if (th17 instanceof C0337a) {
                                    C0337a c0337a17 = th17;
                                    T22 = h5.e.T(c0337a17.o, c0337a17.f5592p, c0337a17.f5593q);
                                } else {
                                    T22 = h5.e.T(th17.getClass().getSimpleName(), th17.toString(), AbstractC0034i.k("Cause: ", th17.getCause(), ", Stacktrace: ", Log.getStackTraceString(th17)));
                                }
                            }
                            cVar.g(T22);
                            return;
                    }
                }
            });
        } else {
            uVar8.y(null);
        }
        v3.u uVar9 = new v3.u(fVar, "dev.flutter.pigeon.webview_flutter_android.WebSettings.setUseWideViewPort", gVar, (C0508g) null);
        if (c0345i != null) {
            final int i14 = 6;
            uVar9.y(new b() { // from class: c5.J
                @Override // M4.b
                public final void e(Object obj, A.c cVar) {
                    List T6;
                    List T7;
                    List T8;
                    List T9;
                    List T10;
                    List T11;
                    List T12;
                    List T13;
                    List T14;
                    List T15;
                    List T16;
                    List T17;
                    List T18;
                    List T19;
                    List T20;
                    List T21;
                    List T22;
                    switch (i14) {
                        case 0:
                            C0345i c0345i2 = c0345i;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list = (List) obj;
                            Object obj2 = list.get(0);
                            q5.h.c(obj2, "null cannot be cast to non-null type android.webkit.WebSettings");
                            WebSettings webSettings = (WebSettings) obj2;
                            Object obj3 = list.get(1);
                            q5.h.c(obj3, "null cannot be cast to non-null type kotlin.Boolean");
                            boolean booleanValue = ((Boolean) obj3).booleanValue();
                            try {
                                c0345i2.getClass();
                                webSettings.setDomStorageEnabled(booleanValue);
                                T6 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th) {
                                if (th instanceof C0337a) {
                                    C0337a c0337a = th;
                                    T6 = h5.e.T(c0337a.o, c0337a.f5592p, c0337a.f5593q);
                                } else {
                                    T6 = h5.e.T(th.getClass().getSimpleName(), th.toString(), AbstractC0034i.k("Cause: ", th.getCause(), ", Stacktrace: ", Log.getStackTraceString(th)));
                                }
                            }
                            cVar.g(T6);
                            return;
                        case 1:
                            C0345i c0345i3 = c0345i;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list2 = (List) obj;
                            Object obj4 = list2.get(0);
                            q5.h.c(obj4, "null cannot be cast to non-null type android.webkit.WebSettings");
                            WebSettings webSettings2 = (WebSettings) obj4;
                            Object obj5 = list2.get(1);
                            q5.h.c(obj5, "null cannot be cast to non-null type kotlin.Boolean");
                            boolean booleanValue2 = ((Boolean) obj5).booleanValue();
                            try {
                                c0345i3.getClass();
                                webSettings2.setJavaScriptEnabled(booleanValue2);
                                T7 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th2) {
                                if (th2 instanceof C0337a) {
                                    C0337a c0337a2 = th2;
                                    T7 = h5.e.T(c0337a2.o, c0337a2.f5592p, c0337a2.f5593q);
                                } else {
                                    T7 = h5.e.T(th2.getClass().getSimpleName(), th2.toString(), AbstractC0034i.k("Cause: ", th2.getCause(), ", Stacktrace: ", Log.getStackTraceString(th2)));
                                }
                            }
                            cVar.g(T7);
                            return;
                        case 2:
                            C0345i c0345i4 = c0345i;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list3 = (List) obj;
                            Object obj6 = list3.get(0);
                            q5.h.c(obj6, "null cannot be cast to non-null type android.webkit.WebSettings");
                            WebSettings webSettings3 = (WebSettings) obj6;
                            String str = (String) list3.get(1);
                            try {
                                c0345i4.getClass();
                                webSettings3.setUserAgentString(str);
                                T8 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th3) {
                                if (th3 instanceof C0337a) {
                                    C0337a c0337a3 = th3;
                                    T8 = h5.e.T(c0337a3.o, c0337a3.f5592p, c0337a3.f5593q);
                                } else {
                                    T8 = h5.e.T(th3.getClass().getSimpleName(), th3.toString(), AbstractC0034i.k("Cause: ", th3.getCause(), ", Stacktrace: ", Log.getStackTraceString(th3)));
                                }
                            }
                            cVar.g(T8);
                            return;
                        case 3:
                            C0345i c0345i5 = c0345i;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list4 = (List) obj;
                            Object obj7 = list4.get(0);
                            q5.h.c(obj7, "null cannot be cast to non-null type android.webkit.WebSettings");
                            WebSettings webSettings4 = (WebSettings) obj7;
                            Object obj8 = list4.get(1);
                            q5.h.c(obj8, "null cannot be cast to non-null type kotlin.Boolean");
                            boolean booleanValue3 = ((Boolean) obj8).booleanValue();
                            try {
                                c0345i5.getClass();
                                webSettings4.setMediaPlaybackRequiresUserGesture(booleanValue3);
                                T9 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th4) {
                                if (th4 instanceof C0337a) {
                                    C0337a c0337a4 = th4;
                                    T9 = h5.e.T(c0337a4.o, c0337a4.f5592p, c0337a4.f5593q);
                                } else {
                                    T9 = h5.e.T(th4.getClass().getSimpleName(), th4.toString(), AbstractC0034i.k("Cause: ", th4.getCause(), ", Stacktrace: ", Log.getStackTraceString(th4)));
                                }
                            }
                            cVar.g(T9);
                            return;
                        case 4:
                            C0345i c0345i6 = c0345i;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list5 = (List) obj;
                            Object obj9 = list5.get(0);
                            q5.h.c(obj9, "null cannot be cast to non-null type android.webkit.WebSettings");
                            WebSettings webSettings5 = (WebSettings) obj9;
                            Object obj10 = list5.get(1);
                            q5.h.c(obj10, "null cannot be cast to non-null type kotlin.Boolean");
                            boolean booleanValue4 = ((Boolean) obj10).booleanValue();
                            try {
                                c0345i6.getClass();
                                webSettings5.setSupportZoom(booleanValue4);
                                T10 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th5) {
                                if (th5 instanceof C0337a) {
                                    C0337a c0337a5 = th5;
                                    T10 = h5.e.T(c0337a5.o, c0337a5.f5592p, c0337a5.f5593q);
                                } else {
                                    T10 = h5.e.T(th5.getClass().getSimpleName(), th5.toString(), AbstractC0034i.k("Cause: ", th5.getCause(), ", Stacktrace: ", Log.getStackTraceString(th5)));
                                }
                            }
                            cVar.g(T10);
                            return;
                        case 5:
                            C0345i c0345i7 = c0345i;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list6 = (List) obj;
                            Object obj11 = list6.get(0);
                            q5.h.c(obj11, "null cannot be cast to non-null type android.webkit.WebSettings");
                            WebSettings webSettings6 = (WebSettings) obj11;
                            Object obj12 = list6.get(1);
                            q5.h.c(obj12, "null cannot be cast to non-null type kotlin.Boolean");
                            boolean booleanValue5 = ((Boolean) obj12).booleanValue();
                            try {
                                c0345i7.getClass();
                                webSettings6.setLoadWithOverviewMode(booleanValue5);
                                T11 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th6) {
                                if (th6 instanceof C0337a) {
                                    C0337a c0337a6 = th6;
                                    T11 = h5.e.T(c0337a6.o, c0337a6.f5592p, c0337a6.f5593q);
                                } else {
                                    T11 = h5.e.T(th6.getClass().getSimpleName(), th6.toString(), AbstractC0034i.k("Cause: ", th6.getCause(), ", Stacktrace: ", Log.getStackTraceString(th6)));
                                }
                            }
                            cVar.g(T11);
                            return;
                        case 6:
                            C0345i c0345i8 = c0345i;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list7 = (List) obj;
                            Object obj13 = list7.get(0);
                            q5.h.c(obj13, "null cannot be cast to non-null type android.webkit.WebSettings");
                            WebSettings webSettings7 = (WebSettings) obj13;
                            Object obj14 = list7.get(1);
                            q5.h.c(obj14, "null cannot be cast to non-null type kotlin.Boolean");
                            boolean booleanValue6 = ((Boolean) obj14).booleanValue();
                            try {
                                c0345i8.getClass();
                                webSettings7.setUseWideViewPort(booleanValue6);
                                T12 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th7) {
                                if (th7 instanceof C0337a) {
                                    C0337a c0337a7 = th7;
                                    T12 = h5.e.T(c0337a7.o, c0337a7.f5592p, c0337a7.f5593q);
                                } else {
                                    T12 = h5.e.T(th7.getClass().getSimpleName(), th7.toString(), AbstractC0034i.k("Cause: ", th7.getCause(), ", Stacktrace: ", Log.getStackTraceString(th7)));
                                }
                            }
                            cVar.g(T12);
                            return;
                        case 7:
                            C0345i c0345i9 = c0345i;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list8 = (List) obj;
                            Object obj15 = list8.get(0);
                            q5.h.c(obj15, "null cannot be cast to non-null type android.webkit.WebSettings");
                            WebSettings webSettings8 = (WebSettings) obj15;
                            Object obj16 = list8.get(1);
                            q5.h.c(obj16, "null cannot be cast to non-null type kotlin.Boolean");
                            boolean booleanValue7 = ((Boolean) obj16).booleanValue();
                            try {
                                c0345i9.getClass();
                                webSettings8.setDisplayZoomControls(booleanValue7);
                                T13 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th8) {
                                if (th8 instanceof C0337a) {
                                    C0337a c0337a8 = th8;
                                    T13 = h5.e.T(c0337a8.o, c0337a8.f5592p, c0337a8.f5593q);
                                } else {
                                    T13 = h5.e.T(th8.getClass().getSimpleName(), th8.toString(), AbstractC0034i.k("Cause: ", th8.getCause(), ", Stacktrace: ", Log.getStackTraceString(th8)));
                                }
                            }
                            cVar.g(T13);
                            return;
                        case 8:
                            C0345i c0345i10 = c0345i;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list9 = (List) obj;
                            Object obj17 = list9.get(0);
                            q5.h.c(obj17, "null cannot be cast to non-null type android.webkit.WebSettings");
                            WebSettings webSettings9 = (WebSettings) obj17;
                            Object obj18 = list9.get(1);
                            q5.h.c(obj18, "null cannot be cast to non-null type kotlin.Boolean");
                            boolean booleanValue8 = ((Boolean) obj18).booleanValue();
                            try {
                                c0345i10.getClass();
                                webSettings9.setBuiltInZoomControls(booleanValue8);
                                T14 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th9) {
                                if (th9 instanceof C0337a) {
                                    C0337a c0337a9 = th9;
                                    T14 = h5.e.T(c0337a9.o, c0337a9.f5592p, c0337a9.f5593q);
                                } else {
                                    T14 = h5.e.T(th9.getClass().getSimpleName(), th9.toString(), AbstractC0034i.k("Cause: ", th9.getCause(), ", Stacktrace: ", Log.getStackTraceString(th9)));
                                }
                            }
                            cVar.g(T14);
                            return;
                        case ContentHandlerProxy.PROCESSING_INSTRUCTION /* 9 */:
                            C0345i c0345i11 = c0345i;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list10 = (List) obj;
                            Object obj19 = list10.get(0);
                            q5.h.c(obj19, "null cannot be cast to non-null type android.webkit.WebSettings");
                            WebSettings webSettings10 = (WebSettings) obj19;
                            Object obj20 = list10.get(1);
                            q5.h.c(obj20, "null cannot be cast to non-null type kotlin.Boolean");
                            boolean booleanValue9 = ((Boolean) obj20).booleanValue();
                            try {
                                c0345i11.getClass();
                                webSettings10.setAllowFileAccess(booleanValue9);
                                T15 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th10) {
                                if (th10 instanceof C0337a) {
                                    C0337a c0337a10 = th10;
                                    T15 = h5.e.T(c0337a10.o, c0337a10.f5592p, c0337a10.f5593q);
                                } else {
                                    T15 = h5.e.T(th10.getClass().getSimpleName(), th10.toString(), AbstractC0034i.k("Cause: ", th10.getCause(), ", Stacktrace: ", Log.getStackTraceString(th10)));
                                }
                            }
                            cVar.g(T15);
                            return;
                        case 10:
                            C0345i c0345i12 = c0345i;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list11 = (List) obj;
                            Object obj21 = list11.get(0);
                            q5.h.c(obj21, "null cannot be cast to non-null type android.webkit.WebSettings");
                            WebSettings webSettings11 = (WebSettings) obj21;
                            Object obj22 = list11.get(1);
                            q5.h.c(obj22, "null cannot be cast to non-null type kotlin.Boolean");
                            boolean booleanValue10 = ((Boolean) obj22).booleanValue();
                            try {
                                c0345i12.getClass();
                                webSettings11.setAllowContentAccess(booleanValue10);
                                T16 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th11) {
                                if (th11 instanceof C0337a) {
                                    C0337a c0337a11 = th11;
                                    T16 = h5.e.T(c0337a11.o, c0337a11.f5592p, c0337a11.f5593q);
                                } else {
                                    T16 = h5.e.T(th11.getClass().getSimpleName(), th11.toString(), AbstractC0034i.k("Cause: ", th11.getCause(), ", Stacktrace: ", Log.getStackTraceString(th11)));
                                }
                            }
                            cVar.g(T16);
                            return;
                        case 11:
                            C0345i c0345i13 = c0345i;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list12 = (List) obj;
                            Object obj23 = list12.get(0);
                            q5.h.c(obj23, "null cannot be cast to non-null type android.webkit.WebSettings");
                            WebSettings webSettings12 = (WebSettings) obj23;
                            Object obj24 = list12.get(1);
                            q5.h.c(obj24, "null cannot be cast to non-null type kotlin.Boolean");
                            boolean booleanValue11 = ((Boolean) obj24).booleanValue();
                            try {
                                c0345i13.getClass();
                                webSettings12.setGeolocationEnabled(booleanValue11);
                                T17 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th12) {
                                if (th12 instanceof C0337a) {
                                    C0337a c0337a12 = th12;
                                    T17 = h5.e.T(c0337a12.o, c0337a12.f5592p, c0337a12.f5593q);
                                } else {
                                    T17 = h5.e.T(th12.getClass().getSimpleName(), th12.toString(), AbstractC0034i.k("Cause: ", th12.getCause(), ", Stacktrace: ", Log.getStackTraceString(th12)));
                                }
                            }
                            cVar.g(T17);
                            return;
                        case 12:
                            C0345i c0345i14 = c0345i;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list13 = (List) obj;
                            Object obj25 = list13.get(0);
                            q5.h.c(obj25, "null cannot be cast to non-null type android.webkit.WebSettings");
                            WebSettings webSettings13 = (WebSettings) obj25;
                            Object obj26 = list13.get(1);
                            q5.h.c(obj26, "null cannot be cast to non-null type kotlin.Long");
                            long longValue = ((Long) obj26).longValue();
                            try {
                                c0345i14.getClass();
                                webSettings13.setTextZoom((int) longValue);
                                T18 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th13) {
                                if (th13 instanceof C0337a) {
                                    C0337a c0337a13 = th13;
                                    T18 = h5.e.T(c0337a13.o, c0337a13.f5592p, c0337a13.f5593q);
                                } else {
                                    T18 = h5.e.T(th13.getClass().getSimpleName(), th13.toString(), AbstractC0034i.k("Cause: ", th13.getCause(), ", Stacktrace: ", Log.getStackTraceString(th13)));
                                }
                            }
                            cVar.g(T18);
                            return;
                        case 13:
                            C0345i c0345i15 = c0345i;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            Object obj27 = ((List) obj).get(0);
                            q5.h.c(obj27, "null cannot be cast to non-null type android.webkit.WebSettings");
                            WebSettings webSettings14 = (WebSettings) obj27;
                            try {
                                c0345i15.getClass();
                                T19 = android.support.v4.media.session.a.z(webSettings14.getUserAgentString());
                            } catch (Throwable th14) {
                                if (th14 instanceof C0337a) {
                                    C0337a c0337a14 = th14;
                                    T19 = h5.e.T(c0337a14.o, c0337a14.f5592p, c0337a14.f5593q);
                                } else {
                                    T19 = h5.e.T(th14.getClass().getSimpleName(), th14.toString(), AbstractC0034i.k("Cause: ", th14.getCause(), ", Stacktrace: ", Log.getStackTraceString(th14)));
                                }
                            }
                            cVar.g(T19);
                            return;
                        case 14:
                            C0345i c0345i16 = c0345i;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list14 = (List) obj;
                            Object obj28 = list14.get(0);
                            q5.h.c(obj28, "null cannot be cast to non-null type android.webkit.WebSettings");
                            WebSettings webSettings15 = (WebSettings) obj28;
                            Object obj29 = list14.get(1);
                            q5.h.c(obj29, "null cannot be cast to non-null type io.flutter.plugins.webviewflutter.MixedContentMode");
                            EnumC0359w enumC0359w = (EnumC0359w) obj29;
                            try {
                                c0345i16.getClass();
                                int ordinal = enumC0359w.ordinal();
                                if (ordinal != 0) {
                                    if (ordinal != 1) {
                                        if (ordinal == 2) {
                                            webSettings15.setMixedContentMode(1);
                                        }
                                    } else {
                                        webSettings15.setMixedContentMode(2);
                                    }
                                } else {
                                    webSettings15.setMixedContentMode(0);
                                }
                                T20 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th15) {
                                if (th15 instanceof C0337a) {
                                    C0337a c0337a15 = th15;
                                    T20 = h5.e.T(c0337a15.o, c0337a15.f5592p, c0337a15.f5593q);
                                } else {
                                    T20 = h5.e.T(th15.getClass().getSimpleName(), th15.toString(), AbstractC0034i.k("Cause: ", th15.getCause(), ", Stacktrace: ", Log.getStackTraceString(th15)));
                                }
                            }
                            cVar.g(T20);
                            return;
                        case 15:
                            C0345i c0345i17 = c0345i;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list15 = (List) obj;
                            Object obj30 = list15.get(0);
                            q5.h.c(obj30, "null cannot be cast to non-null type android.webkit.WebSettings");
                            WebSettings webSettings16 = (WebSettings) obj30;
                            Object obj31 = list15.get(1);
                            q5.h.c(obj31, "null cannot be cast to non-null type kotlin.Boolean");
                            boolean booleanValue12 = ((Boolean) obj31).booleanValue();
                            try {
                                c0345i17.getClass();
                                webSettings16.setJavaScriptCanOpenWindowsAutomatically(booleanValue12);
                                T21 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th16) {
                                if (th16 instanceof C0337a) {
                                    C0337a c0337a16 = th16;
                                    T21 = h5.e.T(c0337a16.o, c0337a16.f5592p, c0337a16.f5593q);
                                } else {
                                    T21 = h5.e.T(th16.getClass().getSimpleName(), th16.toString(), AbstractC0034i.k("Cause: ", th16.getCause(), ", Stacktrace: ", Log.getStackTraceString(th16)));
                                }
                            }
                            cVar.g(T21);
                            return;
                        default:
                            C0345i c0345i18 = c0345i;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list16 = (List) obj;
                            Object obj32 = list16.get(0);
                            q5.h.c(obj32, "null cannot be cast to non-null type android.webkit.WebSettings");
                            WebSettings webSettings17 = (WebSettings) obj32;
                            Object obj33 = list16.get(1);
                            q5.h.c(obj33, "null cannot be cast to non-null type kotlin.Boolean");
                            boolean booleanValue13 = ((Boolean) obj33).booleanValue();
                            try {
                                c0345i18.getClass();
                                webSettings17.setSupportMultipleWindows(booleanValue13);
                                T22 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th17) {
                                if (th17 instanceof C0337a) {
                                    C0337a c0337a17 = th17;
                                    T22 = h5.e.T(c0337a17.o, c0337a17.f5592p, c0337a17.f5593q);
                                } else {
                                    T22 = h5.e.T(th17.getClass().getSimpleName(), th17.toString(), AbstractC0034i.k("Cause: ", th17.getCause(), ", Stacktrace: ", Log.getStackTraceString(th17)));
                                }
                            }
                            cVar.g(T22);
                            return;
                    }
                }
            });
        } else {
            uVar9.y(null);
        }
        v3.u uVar10 = new v3.u(fVar, "dev.flutter.pigeon.webview_flutter_android.WebSettings.setDisplayZoomControls", gVar, (C0508g) null);
        if (c0345i != null) {
            final int i15 = 7;
            uVar10.y(new b() { // from class: c5.J
                @Override // M4.b
                public final void e(Object obj, A.c cVar) {
                    List T6;
                    List T7;
                    List T8;
                    List T9;
                    List T10;
                    List T11;
                    List T12;
                    List T13;
                    List T14;
                    List T15;
                    List T16;
                    List T17;
                    List T18;
                    List T19;
                    List T20;
                    List T21;
                    List T22;
                    switch (i15) {
                        case 0:
                            C0345i c0345i2 = c0345i;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list = (List) obj;
                            Object obj2 = list.get(0);
                            q5.h.c(obj2, "null cannot be cast to non-null type android.webkit.WebSettings");
                            WebSettings webSettings = (WebSettings) obj2;
                            Object obj3 = list.get(1);
                            q5.h.c(obj3, "null cannot be cast to non-null type kotlin.Boolean");
                            boolean booleanValue = ((Boolean) obj3).booleanValue();
                            try {
                                c0345i2.getClass();
                                webSettings.setDomStorageEnabled(booleanValue);
                                T6 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th) {
                                if (th instanceof C0337a) {
                                    C0337a c0337a = th;
                                    T6 = h5.e.T(c0337a.o, c0337a.f5592p, c0337a.f5593q);
                                } else {
                                    T6 = h5.e.T(th.getClass().getSimpleName(), th.toString(), AbstractC0034i.k("Cause: ", th.getCause(), ", Stacktrace: ", Log.getStackTraceString(th)));
                                }
                            }
                            cVar.g(T6);
                            return;
                        case 1:
                            C0345i c0345i3 = c0345i;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list2 = (List) obj;
                            Object obj4 = list2.get(0);
                            q5.h.c(obj4, "null cannot be cast to non-null type android.webkit.WebSettings");
                            WebSettings webSettings2 = (WebSettings) obj4;
                            Object obj5 = list2.get(1);
                            q5.h.c(obj5, "null cannot be cast to non-null type kotlin.Boolean");
                            boolean booleanValue2 = ((Boolean) obj5).booleanValue();
                            try {
                                c0345i3.getClass();
                                webSettings2.setJavaScriptEnabled(booleanValue2);
                                T7 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th2) {
                                if (th2 instanceof C0337a) {
                                    C0337a c0337a2 = th2;
                                    T7 = h5.e.T(c0337a2.o, c0337a2.f5592p, c0337a2.f5593q);
                                } else {
                                    T7 = h5.e.T(th2.getClass().getSimpleName(), th2.toString(), AbstractC0034i.k("Cause: ", th2.getCause(), ", Stacktrace: ", Log.getStackTraceString(th2)));
                                }
                            }
                            cVar.g(T7);
                            return;
                        case 2:
                            C0345i c0345i4 = c0345i;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list3 = (List) obj;
                            Object obj6 = list3.get(0);
                            q5.h.c(obj6, "null cannot be cast to non-null type android.webkit.WebSettings");
                            WebSettings webSettings3 = (WebSettings) obj6;
                            String str = (String) list3.get(1);
                            try {
                                c0345i4.getClass();
                                webSettings3.setUserAgentString(str);
                                T8 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th3) {
                                if (th3 instanceof C0337a) {
                                    C0337a c0337a3 = th3;
                                    T8 = h5.e.T(c0337a3.o, c0337a3.f5592p, c0337a3.f5593q);
                                } else {
                                    T8 = h5.e.T(th3.getClass().getSimpleName(), th3.toString(), AbstractC0034i.k("Cause: ", th3.getCause(), ", Stacktrace: ", Log.getStackTraceString(th3)));
                                }
                            }
                            cVar.g(T8);
                            return;
                        case 3:
                            C0345i c0345i5 = c0345i;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list4 = (List) obj;
                            Object obj7 = list4.get(0);
                            q5.h.c(obj7, "null cannot be cast to non-null type android.webkit.WebSettings");
                            WebSettings webSettings4 = (WebSettings) obj7;
                            Object obj8 = list4.get(1);
                            q5.h.c(obj8, "null cannot be cast to non-null type kotlin.Boolean");
                            boolean booleanValue3 = ((Boolean) obj8).booleanValue();
                            try {
                                c0345i5.getClass();
                                webSettings4.setMediaPlaybackRequiresUserGesture(booleanValue3);
                                T9 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th4) {
                                if (th4 instanceof C0337a) {
                                    C0337a c0337a4 = th4;
                                    T9 = h5.e.T(c0337a4.o, c0337a4.f5592p, c0337a4.f5593q);
                                } else {
                                    T9 = h5.e.T(th4.getClass().getSimpleName(), th4.toString(), AbstractC0034i.k("Cause: ", th4.getCause(), ", Stacktrace: ", Log.getStackTraceString(th4)));
                                }
                            }
                            cVar.g(T9);
                            return;
                        case 4:
                            C0345i c0345i6 = c0345i;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list5 = (List) obj;
                            Object obj9 = list5.get(0);
                            q5.h.c(obj9, "null cannot be cast to non-null type android.webkit.WebSettings");
                            WebSettings webSettings5 = (WebSettings) obj9;
                            Object obj10 = list5.get(1);
                            q5.h.c(obj10, "null cannot be cast to non-null type kotlin.Boolean");
                            boolean booleanValue4 = ((Boolean) obj10).booleanValue();
                            try {
                                c0345i6.getClass();
                                webSettings5.setSupportZoom(booleanValue4);
                                T10 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th5) {
                                if (th5 instanceof C0337a) {
                                    C0337a c0337a5 = th5;
                                    T10 = h5.e.T(c0337a5.o, c0337a5.f5592p, c0337a5.f5593q);
                                } else {
                                    T10 = h5.e.T(th5.getClass().getSimpleName(), th5.toString(), AbstractC0034i.k("Cause: ", th5.getCause(), ", Stacktrace: ", Log.getStackTraceString(th5)));
                                }
                            }
                            cVar.g(T10);
                            return;
                        case 5:
                            C0345i c0345i7 = c0345i;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list6 = (List) obj;
                            Object obj11 = list6.get(0);
                            q5.h.c(obj11, "null cannot be cast to non-null type android.webkit.WebSettings");
                            WebSettings webSettings6 = (WebSettings) obj11;
                            Object obj12 = list6.get(1);
                            q5.h.c(obj12, "null cannot be cast to non-null type kotlin.Boolean");
                            boolean booleanValue5 = ((Boolean) obj12).booleanValue();
                            try {
                                c0345i7.getClass();
                                webSettings6.setLoadWithOverviewMode(booleanValue5);
                                T11 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th6) {
                                if (th6 instanceof C0337a) {
                                    C0337a c0337a6 = th6;
                                    T11 = h5.e.T(c0337a6.o, c0337a6.f5592p, c0337a6.f5593q);
                                } else {
                                    T11 = h5.e.T(th6.getClass().getSimpleName(), th6.toString(), AbstractC0034i.k("Cause: ", th6.getCause(), ", Stacktrace: ", Log.getStackTraceString(th6)));
                                }
                            }
                            cVar.g(T11);
                            return;
                        case 6:
                            C0345i c0345i8 = c0345i;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list7 = (List) obj;
                            Object obj13 = list7.get(0);
                            q5.h.c(obj13, "null cannot be cast to non-null type android.webkit.WebSettings");
                            WebSettings webSettings7 = (WebSettings) obj13;
                            Object obj14 = list7.get(1);
                            q5.h.c(obj14, "null cannot be cast to non-null type kotlin.Boolean");
                            boolean booleanValue6 = ((Boolean) obj14).booleanValue();
                            try {
                                c0345i8.getClass();
                                webSettings7.setUseWideViewPort(booleanValue6);
                                T12 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th7) {
                                if (th7 instanceof C0337a) {
                                    C0337a c0337a7 = th7;
                                    T12 = h5.e.T(c0337a7.o, c0337a7.f5592p, c0337a7.f5593q);
                                } else {
                                    T12 = h5.e.T(th7.getClass().getSimpleName(), th7.toString(), AbstractC0034i.k("Cause: ", th7.getCause(), ", Stacktrace: ", Log.getStackTraceString(th7)));
                                }
                            }
                            cVar.g(T12);
                            return;
                        case 7:
                            C0345i c0345i9 = c0345i;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list8 = (List) obj;
                            Object obj15 = list8.get(0);
                            q5.h.c(obj15, "null cannot be cast to non-null type android.webkit.WebSettings");
                            WebSettings webSettings8 = (WebSettings) obj15;
                            Object obj16 = list8.get(1);
                            q5.h.c(obj16, "null cannot be cast to non-null type kotlin.Boolean");
                            boolean booleanValue7 = ((Boolean) obj16).booleanValue();
                            try {
                                c0345i9.getClass();
                                webSettings8.setDisplayZoomControls(booleanValue7);
                                T13 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th8) {
                                if (th8 instanceof C0337a) {
                                    C0337a c0337a8 = th8;
                                    T13 = h5.e.T(c0337a8.o, c0337a8.f5592p, c0337a8.f5593q);
                                } else {
                                    T13 = h5.e.T(th8.getClass().getSimpleName(), th8.toString(), AbstractC0034i.k("Cause: ", th8.getCause(), ", Stacktrace: ", Log.getStackTraceString(th8)));
                                }
                            }
                            cVar.g(T13);
                            return;
                        case 8:
                            C0345i c0345i10 = c0345i;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list9 = (List) obj;
                            Object obj17 = list9.get(0);
                            q5.h.c(obj17, "null cannot be cast to non-null type android.webkit.WebSettings");
                            WebSettings webSettings9 = (WebSettings) obj17;
                            Object obj18 = list9.get(1);
                            q5.h.c(obj18, "null cannot be cast to non-null type kotlin.Boolean");
                            boolean booleanValue8 = ((Boolean) obj18).booleanValue();
                            try {
                                c0345i10.getClass();
                                webSettings9.setBuiltInZoomControls(booleanValue8);
                                T14 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th9) {
                                if (th9 instanceof C0337a) {
                                    C0337a c0337a9 = th9;
                                    T14 = h5.e.T(c0337a9.o, c0337a9.f5592p, c0337a9.f5593q);
                                } else {
                                    T14 = h5.e.T(th9.getClass().getSimpleName(), th9.toString(), AbstractC0034i.k("Cause: ", th9.getCause(), ", Stacktrace: ", Log.getStackTraceString(th9)));
                                }
                            }
                            cVar.g(T14);
                            return;
                        case ContentHandlerProxy.PROCESSING_INSTRUCTION /* 9 */:
                            C0345i c0345i11 = c0345i;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list10 = (List) obj;
                            Object obj19 = list10.get(0);
                            q5.h.c(obj19, "null cannot be cast to non-null type android.webkit.WebSettings");
                            WebSettings webSettings10 = (WebSettings) obj19;
                            Object obj20 = list10.get(1);
                            q5.h.c(obj20, "null cannot be cast to non-null type kotlin.Boolean");
                            boolean booleanValue9 = ((Boolean) obj20).booleanValue();
                            try {
                                c0345i11.getClass();
                                webSettings10.setAllowFileAccess(booleanValue9);
                                T15 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th10) {
                                if (th10 instanceof C0337a) {
                                    C0337a c0337a10 = th10;
                                    T15 = h5.e.T(c0337a10.o, c0337a10.f5592p, c0337a10.f5593q);
                                } else {
                                    T15 = h5.e.T(th10.getClass().getSimpleName(), th10.toString(), AbstractC0034i.k("Cause: ", th10.getCause(), ", Stacktrace: ", Log.getStackTraceString(th10)));
                                }
                            }
                            cVar.g(T15);
                            return;
                        case 10:
                            C0345i c0345i12 = c0345i;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list11 = (List) obj;
                            Object obj21 = list11.get(0);
                            q5.h.c(obj21, "null cannot be cast to non-null type android.webkit.WebSettings");
                            WebSettings webSettings11 = (WebSettings) obj21;
                            Object obj22 = list11.get(1);
                            q5.h.c(obj22, "null cannot be cast to non-null type kotlin.Boolean");
                            boolean booleanValue10 = ((Boolean) obj22).booleanValue();
                            try {
                                c0345i12.getClass();
                                webSettings11.setAllowContentAccess(booleanValue10);
                                T16 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th11) {
                                if (th11 instanceof C0337a) {
                                    C0337a c0337a11 = th11;
                                    T16 = h5.e.T(c0337a11.o, c0337a11.f5592p, c0337a11.f5593q);
                                } else {
                                    T16 = h5.e.T(th11.getClass().getSimpleName(), th11.toString(), AbstractC0034i.k("Cause: ", th11.getCause(), ", Stacktrace: ", Log.getStackTraceString(th11)));
                                }
                            }
                            cVar.g(T16);
                            return;
                        case 11:
                            C0345i c0345i13 = c0345i;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list12 = (List) obj;
                            Object obj23 = list12.get(0);
                            q5.h.c(obj23, "null cannot be cast to non-null type android.webkit.WebSettings");
                            WebSettings webSettings12 = (WebSettings) obj23;
                            Object obj24 = list12.get(1);
                            q5.h.c(obj24, "null cannot be cast to non-null type kotlin.Boolean");
                            boolean booleanValue11 = ((Boolean) obj24).booleanValue();
                            try {
                                c0345i13.getClass();
                                webSettings12.setGeolocationEnabled(booleanValue11);
                                T17 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th12) {
                                if (th12 instanceof C0337a) {
                                    C0337a c0337a12 = th12;
                                    T17 = h5.e.T(c0337a12.o, c0337a12.f5592p, c0337a12.f5593q);
                                } else {
                                    T17 = h5.e.T(th12.getClass().getSimpleName(), th12.toString(), AbstractC0034i.k("Cause: ", th12.getCause(), ", Stacktrace: ", Log.getStackTraceString(th12)));
                                }
                            }
                            cVar.g(T17);
                            return;
                        case 12:
                            C0345i c0345i14 = c0345i;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list13 = (List) obj;
                            Object obj25 = list13.get(0);
                            q5.h.c(obj25, "null cannot be cast to non-null type android.webkit.WebSettings");
                            WebSettings webSettings13 = (WebSettings) obj25;
                            Object obj26 = list13.get(1);
                            q5.h.c(obj26, "null cannot be cast to non-null type kotlin.Long");
                            long longValue = ((Long) obj26).longValue();
                            try {
                                c0345i14.getClass();
                                webSettings13.setTextZoom((int) longValue);
                                T18 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th13) {
                                if (th13 instanceof C0337a) {
                                    C0337a c0337a13 = th13;
                                    T18 = h5.e.T(c0337a13.o, c0337a13.f5592p, c0337a13.f5593q);
                                } else {
                                    T18 = h5.e.T(th13.getClass().getSimpleName(), th13.toString(), AbstractC0034i.k("Cause: ", th13.getCause(), ", Stacktrace: ", Log.getStackTraceString(th13)));
                                }
                            }
                            cVar.g(T18);
                            return;
                        case 13:
                            C0345i c0345i15 = c0345i;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            Object obj27 = ((List) obj).get(0);
                            q5.h.c(obj27, "null cannot be cast to non-null type android.webkit.WebSettings");
                            WebSettings webSettings14 = (WebSettings) obj27;
                            try {
                                c0345i15.getClass();
                                T19 = android.support.v4.media.session.a.z(webSettings14.getUserAgentString());
                            } catch (Throwable th14) {
                                if (th14 instanceof C0337a) {
                                    C0337a c0337a14 = th14;
                                    T19 = h5.e.T(c0337a14.o, c0337a14.f5592p, c0337a14.f5593q);
                                } else {
                                    T19 = h5.e.T(th14.getClass().getSimpleName(), th14.toString(), AbstractC0034i.k("Cause: ", th14.getCause(), ", Stacktrace: ", Log.getStackTraceString(th14)));
                                }
                            }
                            cVar.g(T19);
                            return;
                        case 14:
                            C0345i c0345i16 = c0345i;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list14 = (List) obj;
                            Object obj28 = list14.get(0);
                            q5.h.c(obj28, "null cannot be cast to non-null type android.webkit.WebSettings");
                            WebSettings webSettings15 = (WebSettings) obj28;
                            Object obj29 = list14.get(1);
                            q5.h.c(obj29, "null cannot be cast to non-null type io.flutter.plugins.webviewflutter.MixedContentMode");
                            EnumC0359w enumC0359w = (EnumC0359w) obj29;
                            try {
                                c0345i16.getClass();
                                int ordinal = enumC0359w.ordinal();
                                if (ordinal != 0) {
                                    if (ordinal != 1) {
                                        if (ordinal == 2) {
                                            webSettings15.setMixedContentMode(1);
                                        }
                                    } else {
                                        webSettings15.setMixedContentMode(2);
                                    }
                                } else {
                                    webSettings15.setMixedContentMode(0);
                                }
                                T20 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th15) {
                                if (th15 instanceof C0337a) {
                                    C0337a c0337a15 = th15;
                                    T20 = h5.e.T(c0337a15.o, c0337a15.f5592p, c0337a15.f5593q);
                                } else {
                                    T20 = h5.e.T(th15.getClass().getSimpleName(), th15.toString(), AbstractC0034i.k("Cause: ", th15.getCause(), ", Stacktrace: ", Log.getStackTraceString(th15)));
                                }
                            }
                            cVar.g(T20);
                            return;
                        case 15:
                            C0345i c0345i17 = c0345i;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list15 = (List) obj;
                            Object obj30 = list15.get(0);
                            q5.h.c(obj30, "null cannot be cast to non-null type android.webkit.WebSettings");
                            WebSettings webSettings16 = (WebSettings) obj30;
                            Object obj31 = list15.get(1);
                            q5.h.c(obj31, "null cannot be cast to non-null type kotlin.Boolean");
                            boolean booleanValue12 = ((Boolean) obj31).booleanValue();
                            try {
                                c0345i17.getClass();
                                webSettings16.setJavaScriptCanOpenWindowsAutomatically(booleanValue12);
                                T21 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th16) {
                                if (th16 instanceof C0337a) {
                                    C0337a c0337a16 = th16;
                                    T21 = h5.e.T(c0337a16.o, c0337a16.f5592p, c0337a16.f5593q);
                                } else {
                                    T21 = h5.e.T(th16.getClass().getSimpleName(), th16.toString(), AbstractC0034i.k("Cause: ", th16.getCause(), ", Stacktrace: ", Log.getStackTraceString(th16)));
                                }
                            }
                            cVar.g(T21);
                            return;
                        default:
                            C0345i c0345i18 = c0345i;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list16 = (List) obj;
                            Object obj32 = list16.get(0);
                            q5.h.c(obj32, "null cannot be cast to non-null type android.webkit.WebSettings");
                            WebSettings webSettings17 = (WebSettings) obj32;
                            Object obj33 = list16.get(1);
                            q5.h.c(obj33, "null cannot be cast to non-null type kotlin.Boolean");
                            boolean booleanValue13 = ((Boolean) obj33).booleanValue();
                            try {
                                c0345i18.getClass();
                                webSettings17.setSupportMultipleWindows(booleanValue13);
                                T22 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th17) {
                                if (th17 instanceof C0337a) {
                                    C0337a c0337a17 = th17;
                                    T22 = h5.e.T(c0337a17.o, c0337a17.f5592p, c0337a17.f5593q);
                                } else {
                                    T22 = h5.e.T(th17.getClass().getSimpleName(), th17.toString(), AbstractC0034i.k("Cause: ", th17.getCause(), ", Stacktrace: ", Log.getStackTraceString(th17)));
                                }
                            }
                            cVar.g(T22);
                            return;
                    }
                }
            });
        } else {
            uVar10.y(null);
        }
        v3.u uVar11 = new v3.u(fVar, "dev.flutter.pigeon.webview_flutter_android.WebSettings.setBuiltInZoomControls", gVar, (C0508g) null);
        if (c0345i != null) {
            final int i16 = 8;
            uVar11.y(new b() { // from class: c5.J
                @Override // M4.b
                public final void e(Object obj, A.c cVar) {
                    List T6;
                    List T7;
                    List T8;
                    List T9;
                    List T10;
                    List T11;
                    List T12;
                    List T13;
                    List T14;
                    List T15;
                    List T16;
                    List T17;
                    List T18;
                    List T19;
                    List T20;
                    List T21;
                    List T22;
                    switch (i16) {
                        case 0:
                            C0345i c0345i2 = c0345i;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list = (List) obj;
                            Object obj2 = list.get(0);
                            q5.h.c(obj2, "null cannot be cast to non-null type android.webkit.WebSettings");
                            WebSettings webSettings = (WebSettings) obj2;
                            Object obj3 = list.get(1);
                            q5.h.c(obj3, "null cannot be cast to non-null type kotlin.Boolean");
                            boolean booleanValue = ((Boolean) obj3).booleanValue();
                            try {
                                c0345i2.getClass();
                                webSettings.setDomStorageEnabled(booleanValue);
                                T6 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th) {
                                if (th instanceof C0337a) {
                                    C0337a c0337a = th;
                                    T6 = h5.e.T(c0337a.o, c0337a.f5592p, c0337a.f5593q);
                                } else {
                                    T6 = h5.e.T(th.getClass().getSimpleName(), th.toString(), AbstractC0034i.k("Cause: ", th.getCause(), ", Stacktrace: ", Log.getStackTraceString(th)));
                                }
                            }
                            cVar.g(T6);
                            return;
                        case 1:
                            C0345i c0345i3 = c0345i;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list2 = (List) obj;
                            Object obj4 = list2.get(0);
                            q5.h.c(obj4, "null cannot be cast to non-null type android.webkit.WebSettings");
                            WebSettings webSettings2 = (WebSettings) obj4;
                            Object obj5 = list2.get(1);
                            q5.h.c(obj5, "null cannot be cast to non-null type kotlin.Boolean");
                            boolean booleanValue2 = ((Boolean) obj5).booleanValue();
                            try {
                                c0345i3.getClass();
                                webSettings2.setJavaScriptEnabled(booleanValue2);
                                T7 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th2) {
                                if (th2 instanceof C0337a) {
                                    C0337a c0337a2 = th2;
                                    T7 = h5.e.T(c0337a2.o, c0337a2.f5592p, c0337a2.f5593q);
                                } else {
                                    T7 = h5.e.T(th2.getClass().getSimpleName(), th2.toString(), AbstractC0034i.k("Cause: ", th2.getCause(), ", Stacktrace: ", Log.getStackTraceString(th2)));
                                }
                            }
                            cVar.g(T7);
                            return;
                        case 2:
                            C0345i c0345i4 = c0345i;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list3 = (List) obj;
                            Object obj6 = list3.get(0);
                            q5.h.c(obj6, "null cannot be cast to non-null type android.webkit.WebSettings");
                            WebSettings webSettings3 = (WebSettings) obj6;
                            String str = (String) list3.get(1);
                            try {
                                c0345i4.getClass();
                                webSettings3.setUserAgentString(str);
                                T8 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th3) {
                                if (th3 instanceof C0337a) {
                                    C0337a c0337a3 = th3;
                                    T8 = h5.e.T(c0337a3.o, c0337a3.f5592p, c0337a3.f5593q);
                                } else {
                                    T8 = h5.e.T(th3.getClass().getSimpleName(), th3.toString(), AbstractC0034i.k("Cause: ", th3.getCause(), ", Stacktrace: ", Log.getStackTraceString(th3)));
                                }
                            }
                            cVar.g(T8);
                            return;
                        case 3:
                            C0345i c0345i5 = c0345i;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list4 = (List) obj;
                            Object obj7 = list4.get(0);
                            q5.h.c(obj7, "null cannot be cast to non-null type android.webkit.WebSettings");
                            WebSettings webSettings4 = (WebSettings) obj7;
                            Object obj8 = list4.get(1);
                            q5.h.c(obj8, "null cannot be cast to non-null type kotlin.Boolean");
                            boolean booleanValue3 = ((Boolean) obj8).booleanValue();
                            try {
                                c0345i5.getClass();
                                webSettings4.setMediaPlaybackRequiresUserGesture(booleanValue3);
                                T9 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th4) {
                                if (th4 instanceof C0337a) {
                                    C0337a c0337a4 = th4;
                                    T9 = h5.e.T(c0337a4.o, c0337a4.f5592p, c0337a4.f5593q);
                                } else {
                                    T9 = h5.e.T(th4.getClass().getSimpleName(), th4.toString(), AbstractC0034i.k("Cause: ", th4.getCause(), ", Stacktrace: ", Log.getStackTraceString(th4)));
                                }
                            }
                            cVar.g(T9);
                            return;
                        case 4:
                            C0345i c0345i6 = c0345i;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list5 = (List) obj;
                            Object obj9 = list5.get(0);
                            q5.h.c(obj9, "null cannot be cast to non-null type android.webkit.WebSettings");
                            WebSettings webSettings5 = (WebSettings) obj9;
                            Object obj10 = list5.get(1);
                            q5.h.c(obj10, "null cannot be cast to non-null type kotlin.Boolean");
                            boolean booleanValue4 = ((Boolean) obj10).booleanValue();
                            try {
                                c0345i6.getClass();
                                webSettings5.setSupportZoom(booleanValue4);
                                T10 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th5) {
                                if (th5 instanceof C0337a) {
                                    C0337a c0337a5 = th5;
                                    T10 = h5.e.T(c0337a5.o, c0337a5.f5592p, c0337a5.f5593q);
                                } else {
                                    T10 = h5.e.T(th5.getClass().getSimpleName(), th5.toString(), AbstractC0034i.k("Cause: ", th5.getCause(), ", Stacktrace: ", Log.getStackTraceString(th5)));
                                }
                            }
                            cVar.g(T10);
                            return;
                        case 5:
                            C0345i c0345i7 = c0345i;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list6 = (List) obj;
                            Object obj11 = list6.get(0);
                            q5.h.c(obj11, "null cannot be cast to non-null type android.webkit.WebSettings");
                            WebSettings webSettings6 = (WebSettings) obj11;
                            Object obj12 = list6.get(1);
                            q5.h.c(obj12, "null cannot be cast to non-null type kotlin.Boolean");
                            boolean booleanValue5 = ((Boolean) obj12).booleanValue();
                            try {
                                c0345i7.getClass();
                                webSettings6.setLoadWithOverviewMode(booleanValue5);
                                T11 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th6) {
                                if (th6 instanceof C0337a) {
                                    C0337a c0337a6 = th6;
                                    T11 = h5.e.T(c0337a6.o, c0337a6.f5592p, c0337a6.f5593q);
                                } else {
                                    T11 = h5.e.T(th6.getClass().getSimpleName(), th6.toString(), AbstractC0034i.k("Cause: ", th6.getCause(), ", Stacktrace: ", Log.getStackTraceString(th6)));
                                }
                            }
                            cVar.g(T11);
                            return;
                        case 6:
                            C0345i c0345i8 = c0345i;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list7 = (List) obj;
                            Object obj13 = list7.get(0);
                            q5.h.c(obj13, "null cannot be cast to non-null type android.webkit.WebSettings");
                            WebSettings webSettings7 = (WebSettings) obj13;
                            Object obj14 = list7.get(1);
                            q5.h.c(obj14, "null cannot be cast to non-null type kotlin.Boolean");
                            boolean booleanValue6 = ((Boolean) obj14).booleanValue();
                            try {
                                c0345i8.getClass();
                                webSettings7.setUseWideViewPort(booleanValue6);
                                T12 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th7) {
                                if (th7 instanceof C0337a) {
                                    C0337a c0337a7 = th7;
                                    T12 = h5.e.T(c0337a7.o, c0337a7.f5592p, c0337a7.f5593q);
                                } else {
                                    T12 = h5.e.T(th7.getClass().getSimpleName(), th7.toString(), AbstractC0034i.k("Cause: ", th7.getCause(), ", Stacktrace: ", Log.getStackTraceString(th7)));
                                }
                            }
                            cVar.g(T12);
                            return;
                        case 7:
                            C0345i c0345i9 = c0345i;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list8 = (List) obj;
                            Object obj15 = list8.get(0);
                            q5.h.c(obj15, "null cannot be cast to non-null type android.webkit.WebSettings");
                            WebSettings webSettings8 = (WebSettings) obj15;
                            Object obj16 = list8.get(1);
                            q5.h.c(obj16, "null cannot be cast to non-null type kotlin.Boolean");
                            boolean booleanValue7 = ((Boolean) obj16).booleanValue();
                            try {
                                c0345i9.getClass();
                                webSettings8.setDisplayZoomControls(booleanValue7);
                                T13 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th8) {
                                if (th8 instanceof C0337a) {
                                    C0337a c0337a8 = th8;
                                    T13 = h5.e.T(c0337a8.o, c0337a8.f5592p, c0337a8.f5593q);
                                } else {
                                    T13 = h5.e.T(th8.getClass().getSimpleName(), th8.toString(), AbstractC0034i.k("Cause: ", th8.getCause(), ", Stacktrace: ", Log.getStackTraceString(th8)));
                                }
                            }
                            cVar.g(T13);
                            return;
                        case 8:
                            C0345i c0345i10 = c0345i;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list9 = (List) obj;
                            Object obj17 = list9.get(0);
                            q5.h.c(obj17, "null cannot be cast to non-null type android.webkit.WebSettings");
                            WebSettings webSettings9 = (WebSettings) obj17;
                            Object obj18 = list9.get(1);
                            q5.h.c(obj18, "null cannot be cast to non-null type kotlin.Boolean");
                            boolean booleanValue8 = ((Boolean) obj18).booleanValue();
                            try {
                                c0345i10.getClass();
                                webSettings9.setBuiltInZoomControls(booleanValue8);
                                T14 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th9) {
                                if (th9 instanceof C0337a) {
                                    C0337a c0337a9 = th9;
                                    T14 = h5.e.T(c0337a9.o, c0337a9.f5592p, c0337a9.f5593q);
                                } else {
                                    T14 = h5.e.T(th9.getClass().getSimpleName(), th9.toString(), AbstractC0034i.k("Cause: ", th9.getCause(), ", Stacktrace: ", Log.getStackTraceString(th9)));
                                }
                            }
                            cVar.g(T14);
                            return;
                        case ContentHandlerProxy.PROCESSING_INSTRUCTION /* 9 */:
                            C0345i c0345i11 = c0345i;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list10 = (List) obj;
                            Object obj19 = list10.get(0);
                            q5.h.c(obj19, "null cannot be cast to non-null type android.webkit.WebSettings");
                            WebSettings webSettings10 = (WebSettings) obj19;
                            Object obj20 = list10.get(1);
                            q5.h.c(obj20, "null cannot be cast to non-null type kotlin.Boolean");
                            boolean booleanValue9 = ((Boolean) obj20).booleanValue();
                            try {
                                c0345i11.getClass();
                                webSettings10.setAllowFileAccess(booleanValue9);
                                T15 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th10) {
                                if (th10 instanceof C0337a) {
                                    C0337a c0337a10 = th10;
                                    T15 = h5.e.T(c0337a10.o, c0337a10.f5592p, c0337a10.f5593q);
                                } else {
                                    T15 = h5.e.T(th10.getClass().getSimpleName(), th10.toString(), AbstractC0034i.k("Cause: ", th10.getCause(), ", Stacktrace: ", Log.getStackTraceString(th10)));
                                }
                            }
                            cVar.g(T15);
                            return;
                        case 10:
                            C0345i c0345i12 = c0345i;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list11 = (List) obj;
                            Object obj21 = list11.get(0);
                            q5.h.c(obj21, "null cannot be cast to non-null type android.webkit.WebSettings");
                            WebSettings webSettings11 = (WebSettings) obj21;
                            Object obj22 = list11.get(1);
                            q5.h.c(obj22, "null cannot be cast to non-null type kotlin.Boolean");
                            boolean booleanValue10 = ((Boolean) obj22).booleanValue();
                            try {
                                c0345i12.getClass();
                                webSettings11.setAllowContentAccess(booleanValue10);
                                T16 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th11) {
                                if (th11 instanceof C0337a) {
                                    C0337a c0337a11 = th11;
                                    T16 = h5.e.T(c0337a11.o, c0337a11.f5592p, c0337a11.f5593q);
                                } else {
                                    T16 = h5.e.T(th11.getClass().getSimpleName(), th11.toString(), AbstractC0034i.k("Cause: ", th11.getCause(), ", Stacktrace: ", Log.getStackTraceString(th11)));
                                }
                            }
                            cVar.g(T16);
                            return;
                        case 11:
                            C0345i c0345i13 = c0345i;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list12 = (List) obj;
                            Object obj23 = list12.get(0);
                            q5.h.c(obj23, "null cannot be cast to non-null type android.webkit.WebSettings");
                            WebSettings webSettings12 = (WebSettings) obj23;
                            Object obj24 = list12.get(1);
                            q5.h.c(obj24, "null cannot be cast to non-null type kotlin.Boolean");
                            boolean booleanValue11 = ((Boolean) obj24).booleanValue();
                            try {
                                c0345i13.getClass();
                                webSettings12.setGeolocationEnabled(booleanValue11);
                                T17 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th12) {
                                if (th12 instanceof C0337a) {
                                    C0337a c0337a12 = th12;
                                    T17 = h5.e.T(c0337a12.o, c0337a12.f5592p, c0337a12.f5593q);
                                } else {
                                    T17 = h5.e.T(th12.getClass().getSimpleName(), th12.toString(), AbstractC0034i.k("Cause: ", th12.getCause(), ", Stacktrace: ", Log.getStackTraceString(th12)));
                                }
                            }
                            cVar.g(T17);
                            return;
                        case 12:
                            C0345i c0345i14 = c0345i;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list13 = (List) obj;
                            Object obj25 = list13.get(0);
                            q5.h.c(obj25, "null cannot be cast to non-null type android.webkit.WebSettings");
                            WebSettings webSettings13 = (WebSettings) obj25;
                            Object obj26 = list13.get(1);
                            q5.h.c(obj26, "null cannot be cast to non-null type kotlin.Long");
                            long longValue = ((Long) obj26).longValue();
                            try {
                                c0345i14.getClass();
                                webSettings13.setTextZoom((int) longValue);
                                T18 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th13) {
                                if (th13 instanceof C0337a) {
                                    C0337a c0337a13 = th13;
                                    T18 = h5.e.T(c0337a13.o, c0337a13.f5592p, c0337a13.f5593q);
                                } else {
                                    T18 = h5.e.T(th13.getClass().getSimpleName(), th13.toString(), AbstractC0034i.k("Cause: ", th13.getCause(), ", Stacktrace: ", Log.getStackTraceString(th13)));
                                }
                            }
                            cVar.g(T18);
                            return;
                        case 13:
                            C0345i c0345i15 = c0345i;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            Object obj27 = ((List) obj).get(0);
                            q5.h.c(obj27, "null cannot be cast to non-null type android.webkit.WebSettings");
                            WebSettings webSettings14 = (WebSettings) obj27;
                            try {
                                c0345i15.getClass();
                                T19 = android.support.v4.media.session.a.z(webSettings14.getUserAgentString());
                            } catch (Throwable th14) {
                                if (th14 instanceof C0337a) {
                                    C0337a c0337a14 = th14;
                                    T19 = h5.e.T(c0337a14.o, c0337a14.f5592p, c0337a14.f5593q);
                                } else {
                                    T19 = h5.e.T(th14.getClass().getSimpleName(), th14.toString(), AbstractC0034i.k("Cause: ", th14.getCause(), ", Stacktrace: ", Log.getStackTraceString(th14)));
                                }
                            }
                            cVar.g(T19);
                            return;
                        case 14:
                            C0345i c0345i16 = c0345i;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list14 = (List) obj;
                            Object obj28 = list14.get(0);
                            q5.h.c(obj28, "null cannot be cast to non-null type android.webkit.WebSettings");
                            WebSettings webSettings15 = (WebSettings) obj28;
                            Object obj29 = list14.get(1);
                            q5.h.c(obj29, "null cannot be cast to non-null type io.flutter.plugins.webviewflutter.MixedContentMode");
                            EnumC0359w enumC0359w = (EnumC0359w) obj29;
                            try {
                                c0345i16.getClass();
                                int ordinal = enumC0359w.ordinal();
                                if (ordinal != 0) {
                                    if (ordinal != 1) {
                                        if (ordinal == 2) {
                                            webSettings15.setMixedContentMode(1);
                                        }
                                    } else {
                                        webSettings15.setMixedContentMode(2);
                                    }
                                } else {
                                    webSettings15.setMixedContentMode(0);
                                }
                                T20 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th15) {
                                if (th15 instanceof C0337a) {
                                    C0337a c0337a15 = th15;
                                    T20 = h5.e.T(c0337a15.o, c0337a15.f5592p, c0337a15.f5593q);
                                } else {
                                    T20 = h5.e.T(th15.getClass().getSimpleName(), th15.toString(), AbstractC0034i.k("Cause: ", th15.getCause(), ", Stacktrace: ", Log.getStackTraceString(th15)));
                                }
                            }
                            cVar.g(T20);
                            return;
                        case 15:
                            C0345i c0345i17 = c0345i;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list15 = (List) obj;
                            Object obj30 = list15.get(0);
                            q5.h.c(obj30, "null cannot be cast to non-null type android.webkit.WebSettings");
                            WebSettings webSettings16 = (WebSettings) obj30;
                            Object obj31 = list15.get(1);
                            q5.h.c(obj31, "null cannot be cast to non-null type kotlin.Boolean");
                            boolean booleanValue12 = ((Boolean) obj31).booleanValue();
                            try {
                                c0345i17.getClass();
                                webSettings16.setJavaScriptCanOpenWindowsAutomatically(booleanValue12);
                                T21 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th16) {
                                if (th16 instanceof C0337a) {
                                    C0337a c0337a16 = th16;
                                    T21 = h5.e.T(c0337a16.o, c0337a16.f5592p, c0337a16.f5593q);
                                } else {
                                    T21 = h5.e.T(th16.getClass().getSimpleName(), th16.toString(), AbstractC0034i.k("Cause: ", th16.getCause(), ", Stacktrace: ", Log.getStackTraceString(th16)));
                                }
                            }
                            cVar.g(T21);
                            return;
                        default:
                            C0345i c0345i18 = c0345i;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list16 = (List) obj;
                            Object obj32 = list16.get(0);
                            q5.h.c(obj32, "null cannot be cast to non-null type android.webkit.WebSettings");
                            WebSettings webSettings17 = (WebSettings) obj32;
                            Object obj33 = list16.get(1);
                            q5.h.c(obj33, "null cannot be cast to non-null type kotlin.Boolean");
                            boolean booleanValue13 = ((Boolean) obj33).booleanValue();
                            try {
                                c0345i18.getClass();
                                webSettings17.setSupportMultipleWindows(booleanValue13);
                                T22 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th17) {
                                if (th17 instanceof C0337a) {
                                    C0337a c0337a17 = th17;
                                    T22 = h5.e.T(c0337a17.o, c0337a17.f5592p, c0337a17.f5593q);
                                } else {
                                    T22 = h5.e.T(th17.getClass().getSimpleName(), th17.toString(), AbstractC0034i.k("Cause: ", th17.getCause(), ", Stacktrace: ", Log.getStackTraceString(th17)));
                                }
                            }
                            cVar.g(T22);
                            return;
                    }
                }
            });
        } else {
            uVar11.y(null);
        }
        v3.u uVar12 = new v3.u(fVar, "dev.flutter.pigeon.webview_flutter_android.WebSettings.setAllowFileAccess", gVar, (C0508g) null);
        if (c0345i != null) {
            final int i17 = 9;
            uVar12.y(new b() { // from class: c5.J
                @Override // M4.b
                public final void e(Object obj, A.c cVar) {
                    List T6;
                    List T7;
                    List T8;
                    List T9;
                    List T10;
                    List T11;
                    List T12;
                    List T13;
                    List T14;
                    List T15;
                    List T16;
                    List T17;
                    List T18;
                    List T19;
                    List T20;
                    List T21;
                    List T22;
                    switch (i17) {
                        case 0:
                            C0345i c0345i2 = c0345i;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list = (List) obj;
                            Object obj2 = list.get(0);
                            q5.h.c(obj2, "null cannot be cast to non-null type android.webkit.WebSettings");
                            WebSettings webSettings = (WebSettings) obj2;
                            Object obj3 = list.get(1);
                            q5.h.c(obj3, "null cannot be cast to non-null type kotlin.Boolean");
                            boolean booleanValue = ((Boolean) obj3).booleanValue();
                            try {
                                c0345i2.getClass();
                                webSettings.setDomStorageEnabled(booleanValue);
                                T6 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th) {
                                if (th instanceof C0337a) {
                                    C0337a c0337a = th;
                                    T6 = h5.e.T(c0337a.o, c0337a.f5592p, c0337a.f5593q);
                                } else {
                                    T6 = h5.e.T(th.getClass().getSimpleName(), th.toString(), AbstractC0034i.k("Cause: ", th.getCause(), ", Stacktrace: ", Log.getStackTraceString(th)));
                                }
                            }
                            cVar.g(T6);
                            return;
                        case 1:
                            C0345i c0345i3 = c0345i;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list2 = (List) obj;
                            Object obj4 = list2.get(0);
                            q5.h.c(obj4, "null cannot be cast to non-null type android.webkit.WebSettings");
                            WebSettings webSettings2 = (WebSettings) obj4;
                            Object obj5 = list2.get(1);
                            q5.h.c(obj5, "null cannot be cast to non-null type kotlin.Boolean");
                            boolean booleanValue2 = ((Boolean) obj5).booleanValue();
                            try {
                                c0345i3.getClass();
                                webSettings2.setJavaScriptEnabled(booleanValue2);
                                T7 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th2) {
                                if (th2 instanceof C0337a) {
                                    C0337a c0337a2 = th2;
                                    T7 = h5.e.T(c0337a2.o, c0337a2.f5592p, c0337a2.f5593q);
                                } else {
                                    T7 = h5.e.T(th2.getClass().getSimpleName(), th2.toString(), AbstractC0034i.k("Cause: ", th2.getCause(), ", Stacktrace: ", Log.getStackTraceString(th2)));
                                }
                            }
                            cVar.g(T7);
                            return;
                        case 2:
                            C0345i c0345i4 = c0345i;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list3 = (List) obj;
                            Object obj6 = list3.get(0);
                            q5.h.c(obj6, "null cannot be cast to non-null type android.webkit.WebSettings");
                            WebSettings webSettings3 = (WebSettings) obj6;
                            String str = (String) list3.get(1);
                            try {
                                c0345i4.getClass();
                                webSettings3.setUserAgentString(str);
                                T8 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th3) {
                                if (th3 instanceof C0337a) {
                                    C0337a c0337a3 = th3;
                                    T8 = h5.e.T(c0337a3.o, c0337a3.f5592p, c0337a3.f5593q);
                                } else {
                                    T8 = h5.e.T(th3.getClass().getSimpleName(), th3.toString(), AbstractC0034i.k("Cause: ", th3.getCause(), ", Stacktrace: ", Log.getStackTraceString(th3)));
                                }
                            }
                            cVar.g(T8);
                            return;
                        case 3:
                            C0345i c0345i5 = c0345i;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list4 = (List) obj;
                            Object obj7 = list4.get(0);
                            q5.h.c(obj7, "null cannot be cast to non-null type android.webkit.WebSettings");
                            WebSettings webSettings4 = (WebSettings) obj7;
                            Object obj8 = list4.get(1);
                            q5.h.c(obj8, "null cannot be cast to non-null type kotlin.Boolean");
                            boolean booleanValue3 = ((Boolean) obj8).booleanValue();
                            try {
                                c0345i5.getClass();
                                webSettings4.setMediaPlaybackRequiresUserGesture(booleanValue3);
                                T9 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th4) {
                                if (th4 instanceof C0337a) {
                                    C0337a c0337a4 = th4;
                                    T9 = h5.e.T(c0337a4.o, c0337a4.f5592p, c0337a4.f5593q);
                                } else {
                                    T9 = h5.e.T(th4.getClass().getSimpleName(), th4.toString(), AbstractC0034i.k("Cause: ", th4.getCause(), ", Stacktrace: ", Log.getStackTraceString(th4)));
                                }
                            }
                            cVar.g(T9);
                            return;
                        case 4:
                            C0345i c0345i6 = c0345i;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list5 = (List) obj;
                            Object obj9 = list5.get(0);
                            q5.h.c(obj9, "null cannot be cast to non-null type android.webkit.WebSettings");
                            WebSettings webSettings5 = (WebSettings) obj9;
                            Object obj10 = list5.get(1);
                            q5.h.c(obj10, "null cannot be cast to non-null type kotlin.Boolean");
                            boolean booleanValue4 = ((Boolean) obj10).booleanValue();
                            try {
                                c0345i6.getClass();
                                webSettings5.setSupportZoom(booleanValue4);
                                T10 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th5) {
                                if (th5 instanceof C0337a) {
                                    C0337a c0337a5 = th5;
                                    T10 = h5.e.T(c0337a5.o, c0337a5.f5592p, c0337a5.f5593q);
                                } else {
                                    T10 = h5.e.T(th5.getClass().getSimpleName(), th5.toString(), AbstractC0034i.k("Cause: ", th5.getCause(), ", Stacktrace: ", Log.getStackTraceString(th5)));
                                }
                            }
                            cVar.g(T10);
                            return;
                        case 5:
                            C0345i c0345i7 = c0345i;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list6 = (List) obj;
                            Object obj11 = list6.get(0);
                            q5.h.c(obj11, "null cannot be cast to non-null type android.webkit.WebSettings");
                            WebSettings webSettings6 = (WebSettings) obj11;
                            Object obj12 = list6.get(1);
                            q5.h.c(obj12, "null cannot be cast to non-null type kotlin.Boolean");
                            boolean booleanValue5 = ((Boolean) obj12).booleanValue();
                            try {
                                c0345i7.getClass();
                                webSettings6.setLoadWithOverviewMode(booleanValue5);
                                T11 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th6) {
                                if (th6 instanceof C0337a) {
                                    C0337a c0337a6 = th6;
                                    T11 = h5.e.T(c0337a6.o, c0337a6.f5592p, c0337a6.f5593q);
                                } else {
                                    T11 = h5.e.T(th6.getClass().getSimpleName(), th6.toString(), AbstractC0034i.k("Cause: ", th6.getCause(), ", Stacktrace: ", Log.getStackTraceString(th6)));
                                }
                            }
                            cVar.g(T11);
                            return;
                        case 6:
                            C0345i c0345i8 = c0345i;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list7 = (List) obj;
                            Object obj13 = list7.get(0);
                            q5.h.c(obj13, "null cannot be cast to non-null type android.webkit.WebSettings");
                            WebSettings webSettings7 = (WebSettings) obj13;
                            Object obj14 = list7.get(1);
                            q5.h.c(obj14, "null cannot be cast to non-null type kotlin.Boolean");
                            boolean booleanValue6 = ((Boolean) obj14).booleanValue();
                            try {
                                c0345i8.getClass();
                                webSettings7.setUseWideViewPort(booleanValue6);
                                T12 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th7) {
                                if (th7 instanceof C0337a) {
                                    C0337a c0337a7 = th7;
                                    T12 = h5.e.T(c0337a7.o, c0337a7.f5592p, c0337a7.f5593q);
                                } else {
                                    T12 = h5.e.T(th7.getClass().getSimpleName(), th7.toString(), AbstractC0034i.k("Cause: ", th7.getCause(), ", Stacktrace: ", Log.getStackTraceString(th7)));
                                }
                            }
                            cVar.g(T12);
                            return;
                        case 7:
                            C0345i c0345i9 = c0345i;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list8 = (List) obj;
                            Object obj15 = list8.get(0);
                            q5.h.c(obj15, "null cannot be cast to non-null type android.webkit.WebSettings");
                            WebSettings webSettings8 = (WebSettings) obj15;
                            Object obj16 = list8.get(1);
                            q5.h.c(obj16, "null cannot be cast to non-null type kotlin.Boolean");
                            boolean booleanValue7 = ((Boolean) obj16).booleanValue();
                            try {
                                c0345i9.getClass();
                                webSettings8.setDisplayZoomControls(booleanValue7);
                                T13 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th8) {
                                if (th8 instanceof C0337a) {
                                    C0337a c0337a8 = th8;
                                    T13 = h5.e.T(c0337a8.o, c0337a8.f5592p, c0337a8.f5593q);
                                } else {
                                    T13 = h5.e.T(th8.getClass().getSimpleName(), th8.toString(), AbstractC0034i.k("Cause: ", th8.getCause(), ", Stacktrace: ", Log.getStackTraceString(th8)));
                                }
                            }
                            cVar.g(T13);
                            return;
                        case 8:
                            C0345i c0345i10 = c0345i;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list9 = (List) obj;
                            Object obj17 = list9.get(0);
                            q5.h.c(obj17, "null cannot be cast to non-null type android.webkit.WebSettings");
                            WebSettings webSettings9 = (WebSettings) obj17;
                            Object obj18 = list9.get(1);
                            q5.h.c(obj18, "null cannot be cast to non-null type kotlin.Boolean");
                            boolean booleanValue8 = ((Boolean) obj18).booleanValue();
                            try {
                                c0345i10.getClass();
                                webSettings9.setBuiltInZoomControls(booleanValue8);
                                T14 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th9) {
                                if (th9 instanceof C0337a) {
                                    C0337a c0337a9 = th9;
                                    T14 = h5.e.T(c0337a9.o, c0337a9.f5592p, c0337a9.f5593q);
                                } else {
                                    T14 = h5.e.T(th9.getClass().getSimpleName(), th9.toString(), AbstractC0034i.k("Cause: ", th9.getCause(), ", Stacktrace: ", Log.getStackTraceString(th9)));
                                }
                            }
                            cVar.g(T14);
                            return;
                        case ContentHandlerProxy.PROCESSING_INSTRUCTION /* 9 */:
                            C0345i c0345i11 = c0345i;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list10 = (List) obj;
                            Object obj19 = list10.get(0);
                            q5.h.c(obj19, "null cannot be cast to non-null type android.webkit.WebSettings");
                            WebSettings webSettings10 = (WebSettings) obj19;
                            Object obj20 = list10.get(1);
                            q5.h.c(obj20, "null cannot be cast to non-null type kotlin.Boolean");
                            boolean booleanValue9 = ((Boolean) obj20).booleanValue();
                            try {
                                c0345i11.getClass();
                                webSettings10.setAllowFileAccess(booleanValue9);
                                T15 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th10) {
                                if (th10 instanceof C0337a) {
                                    C0337a c0337a10 = th10;
                                    T15 = h5.e.T(c0337a10.o, c0337a10.f5592p, c0337a10.f5593q);
                                } else {
                                    T15 = h5.e.T(th10.getClass().getSimpleName(), th10.toString(), AbstractC0034i.k("Cause: ", th10.getCause(), ", Stacktrace: ", Log.getStackTraceString(th10)));
                                }
                            }
                            cVar.g(T15);
                            return;
                        case 10:
                            C0345i c0345i12 = c0345i;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list11 = (List) obj;
                            Object obj21 = list11.get(0);
                            q5.h.c(obj21, "null cannot be cast to non-null type android.webkit.WebSettings");
                            WebSettings webSettings11 = (WebSettings) obj21;
                            Object obj22 = list11.get(1);
                            q5.h.c(obj22, "null cannot be cast to non-null type kotlin.Boolean");
                            boolean booleanValue10 = ((Boolean) obj22).booleanValue();
                            try {
                                c0345i12.getClass();
                                webSettings11.setAllowContentAccess(booleanValue10);
                                T16 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th11) {
                                if (th11 instanceof C0337a) {
                                    C0337a c0337a11 = th11;
                                    T16 = h5.e.T(c0337a11.o, c0337a11.f5592p, c0337a11.f5593q);
                                } else {
                                    T16 = h5.e.T(th11.getClass().getSimpleName(), th11.toString(), AbstractC0034i.k("Cause: ", th11.getCause(), ", Stacktrace: ", Log.getStackTraceString(th11)));
                                }
                            }
                            cVar.g(T16);
                            return;
                        case 11:
                            C0345i c0345i13 = c0345i;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list12 = (List) obj;
                            Object obj23 = list12.get(0);
                            q5.h.c(obj23, "null cannot be cast to non-null type android.webkit.WebSettings");
                            WebSettings webSettings12 = (WebSettings) obj23;
                            Object obj24 = list12.get(1);
                            q5.h.c(obj24, "null cannot be cast to non-null type kotlin.Boolean");
                            boolean booleanValue11 = ((Boolean) obj24).booleanValue();
                            try {
                                c0345i13.getClass();
                                webSettings12.setGeolocationEnabled(booleanValue11);
                                T17 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th12) {
                                if (th12 instanceof C0337a) {
                                    C0337a c0337a12 = th12;
                                    T17 = h5.e.T(c0337a12.o, c0337a12.f5592p, c0337a12.f5593q);
                                } else {
                                    T17 = h5.e.T(th12.getClass().getSimpleName(), th12.toString(), AbstractC0034i.k("Cause: ", th12.getCause(), ", Stacktrace: ", Log.getStackTraceString(th12)));
                                }
                            }
                            cVar.g(T17);
                            return;
                        case 12:
                            C0345i c0345i14 = c0345i;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list13 = (List) obj;
                            Object obj25 = list13.get(0);
                            q5.h.c(obj25, "null cannot be cast to non-null type android.webkit.WebSettings");
                            WebSettings webSettings13 = (WebSettings) obj25;
                            Object obj26 = list13.get(1);
                            q5.h.c(obj26, "null cannot be cast to non-null type kotlin.Long");
                            long longValue = ((Long) obj26).longValue();
                            try {
                                c0345i14.getClass();
                                webSettings13.setTextZoom((int) longValue);
                                T18 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th13) {
                                if (th13 instanceof C0337a) {
                                    C0337a c0337a13 = th13;
                                    T18 = h5.e.T(c0337a13.o, c0337a13.f5592p, c0337a13.f5593q);
                                } else {
                                    T18 = h5.e.T(th13.getClass().getSimpleName(), th13.toString(), AbstractC0034i.k("Cause: ", th13.getCause(), ", Stacktrace: ", Log.getStackTraceString(th13)));
                                }
                            }
                            cVar.g(T18);
                            return;
                        case 13:
                            C0345i c0345i15 = c0345i;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            Object obj27 = ((List) obj).get(0);
                            q5.h.c(obj27, "null cannot be cast to non-null type android.webkit.WebSettings");
                            WebSettings webSettings14 = (WebSettings) obj27;
                            try {
                                c0345i15.getClass();
                                T19 = android.support.v4.media.session.a.z(webSettings14.getUserAgentString());
                            } catch (Throwable th14) {
                                if (th14 instanceof C0337a) {
                                    C0337a c0337a14 = th14;
                                    T19 = h5.e.T(c0337a14.o, c0337a14.f5592p, c0337a14.f5593q);
                                } else {
                                    T19 = h5.e.T(th14.getClass().getSimpleName(), th14.toString(), AbstractC0034i.k("Cause: ", th14.getCause(), ", Stacktrace: ", Log.getStackTraceString(th14)));
                                }
                            }
                            cVar.g(T19);
                            return;
                        case 14:
                            C0345i c0345i16 = c0345i;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list14 = (List) obj;
                            Object obj28 = list14.get(0);
                            q5.h.c(obj28, "null cannot be cast to non-null type android.webkit.WebSettings");
                            WebSettings webSettings15 = (WebSettings) obj28;
                            Object obj29 = list14.get(1);
                            q5.h.c(obj29, "null cannot be cast to non-null type io.flutter.plugins.webviewflutter.MixedContentMode");
                            EnumC0359w enumC0359w = (EnumC0359w) obj29;
                            try {
                                c0345i16.getClass();
                                int ordinal = enumC0359w.ordinal();
                                if (ordinal != 0) {
                                    if (ordinal != 1) {
                                        if (ordinal == 2) {
                                            webSettings15.setMixedContentMode(1);
                                        }
                                    } else {
                                        webSettings15.setMixedContentMode(2);
                                    }
                                } else {
                                    webSettings15.setMixedContentMode(0);
                                }
                                T20 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th15) {
                                if (th15 instanceof C0337a) {
                                    C0337a c0337a15 = th15;
                                    T20 = h5.e.T(c0337a15.o, c0337a15.f5592p, c0337a15.f5593q);
                                } else {
                                    T20 = h5.e.T(th15.getClass().getSimpleName(), th15.toString(), AbstractC0034i.k("Cause: ", th15.getCause(), ", Stacktrace: ", Log.getStackTraceString(th15)));
                                }
                            }
                            cVar.g(T20);
                            return;
                        case 15:
                            C0345i c0345i17 = c0345i;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list15 = (List) obj;
                            Object obj30 = list15.get(0);
                            q5.h.c(obj30, "null cannot be cast to non-null type android.webkit.WebSettings");
                            WebSettings webSettings16 = (WebSettings) obj30;
                            Object obj31 = list15.get(1);
                            q5.h.c(obj31, "null cannot be cast to non-null type kotlin.Boolean");
                            boolean booleanValue12 = ((Boolean) obj31).booleanValue();
                            try {
                                c0345i17.getClass();
                                webSettings16.setJavaScriptCanOpenWindowsAutomatically(booleanValue12);
                                T21 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th16) {
                                if (th16 instanceof C0337a) {
                                    C0337a c0337a16 = th16;
                                    T21 = h5.e.T(c0337a16.o, c0337a16.f5592p, c0337a16.f5593q);
                                } else {
                                    T21 = h5.e.T(th16.getClass().getSimpleName(), th16.toString(), AbstractC0034i.k("Cause: ", th16.getCause(), ", Stacktrace: ", Log.getStackTraceString(th16)));
                                }
                            }
                            cVar.g(T21);
                            return;
                        default:
                            C0345i c0345i18 = c0345i;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list16 = (List) obj;
                            Object obj32 = list16.get(0);
                            q5.h.c(obj32, "null cannot be cast to non-null type android.webkit.WebSettings");
                            WebSettings webSettings17 = (WebSettings) obj32;
                            Object obj33 = list16.get(1);
                            q5.h.c(obj33, "null cannot be cast to non-null type kotlin.Boolean");
                            boolean booleanValue13 = ((Boolean) obj33).booleanValue();
                            try {
                                c0345i18.getClass();
                                webSettings17.setSupportMultipleWindows(booleanValue13);
                                T22 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th17) {
                                if (th17 instanceof C0337a) {
                                    C0337a c0337a17 = th17;
                                    T22 = h5.e.T(c0337a17.o, c0337a17.f5592p, c0337a17.f5593q);
                                } else {
                                    T22 = h5.e.T(th17.getClass().getSimpleName(), th17.toString(), AbstractC0034i.k("Cause: ", th17.getCause(), ", Stacktrace: ", Log.getStackTraceString(th17)));
                                }
                            }
                            cVar.g(T22);
                            return;
                    }
                }
            });
        } else {
            uVar12.y(null);
        }
        v3.u uVar13 = new v3.u(fVar, "dev.flutter.pigeon.webview_flutter_android.WebSettings.setAllowContentAccess", gVar, (C0508g) null);
        if (c0345i != null) {
            final int i18 = 10;
            uVar13.y(new b() { // from class: c5.J
                @Override // M4.b
                public final void e(Object obj, A.c cVar) {
                    List T6;
                    List T7;
                    List T8;
                    List T9;
                    List T10;
                    List T11;
                    List T12;
                    List T13;
                    List T14;
                    List T15;
                    List T16;
                    List T17;
                    List T18;
                    List T19;
                    List T20;
                    List T21;
                    List T22;
                    switch (i18) {
                        case 0:
                            C0345i c0345i2 = c0345i;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list = (List) obj;
                            Object obj2 = list.get(0);
                            q5.h.c(obj2, "null cannot be cast to non-null type android.webkit.WebSettings");
                            WebSettings webSettings = (WebSettings) obj2;
                            Object obj3 = list.get(1);
                            q5.h.c(obj3, "null cannot be cast to non-null type kotlin.Boolean");
                            boolean booleanValue = ((Boolean) obj3).booleanValue();
                            try {
                                c0345i2.getClass();
                                webSettings.setDomStorageEnabled(booleanValue);
                                T6 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th) {
                                if (th instanceof C0337a) {
                                    C0337a c0337a = th;
                                    T6 = h5.e.T(c0337a.o, c0337a.f5592p, c0337a.f5593q);
                                } else {
                                    T6 = h5.e.T(th.getClass().getSimpleName(), th.toString(), AbstractC0034i.k("Cause: ", th.getCause(), ", Stacktrace: ", Log.getStackTraceString(th)));
                                }
                            }
                            cVar.g(T6);
                            return;
                        case 1:
                            C0345i c0345i3 = c0345i;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list2 = (List) obj;
                            Object obj4 = list2.get(0);
                            q5.h.c(obj4, "null cannot be cast to non-null type android.webkit.WebSettings");
                            WebSettings webSettings2 = (WebSettings) obj4;
                            Object obj5 = list2.get(1);
                            q5.h.c(obj5, "null cannot be cast to non-null type kotlin.Boolean");
                            boolean booleanValue2 = ((Boolean) obj5).booleanValue();
                            try {
                                c0345i3.getClass();
                                webSettings2.setJavaScriptEnabled(booleanValue2);
                                T7 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th2) {
                                if (th2 instanceof C0337a) {
                                    C0337a c0337a2 = th2;
                                    T7 = h5.e.T(c0337a2.o, c0337a2.f5592p, c0337a2.f5593q);
                                } else {
                                    T7 = h5.e.T(th2.getClass().getSimpleName(), th2.toString(), AbstractC0034i.k("Cause: ", th2.getCause(), ", Stacktrace: ", Log.getStackTraceString(th2)));
                                }
                            }
                            cVar.g(T7);
                            return;
                        case 2:
                            C0345i c0345i4 = c0345i;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list3 = (List) obj;
                            Object obj6 = list3.get(0);
                            q5.h.c(obj6, "null cannot be cast to non-null type android.webkit.WebSettings");
                            WebSettings webSettings3 = (WebSettings) obj6;
                            String str = (String) list3.get(1);
                            try {
                                c0345i4.getClass();
                                webSettings3.setUserAgentString(str);
                                T8 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th3) {
                                if (th3 instanceof C0337a) {
                                    C0337a c0337a3 = th3;
                                    T8 = h5.e.T(c0337a3.o, c0337a3.f5592p, c0337a3.f5593q);
                                } else {
                                    T8 = h5.e.T(th3.getClass().getSimpleName(), th3.toString(), AbstractC0034i.k("Cause: ", th3.getCause(), ", Stacktrace: ", Log.getStackTraceString(th3)));
                                }
                            }
                            cVar.g(T8);
                            return;
                        case 3:
                            C0345i c0345i5 = c0345i;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list4 = (List) obj;
                            Object obj7 = list4.get(0);
                            q5.h.c(obj7, "null cannot be cast to non-null type android.webkit.WebSettings");
                            WebSettings webSettings4 = (WebSettings) obj7;
                            Object obj8 = list4.get(1);
                            q5.h.c(obj8, "null cannot be cast to non-null type kotlin.Boolean");
                            boolean booleanValue3 = ((Boolean) obj8).booleanValue();
                            try {
                                c0345i5.getClass();
                                webSettings4.setMediaPlaybackRequiresUserGesture(booleanValue3);
                                T9 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th4) {
                                if (th4 instanceof C0337a) {
                                    C0337a c0337a4 = th4;
                                    T9 = h5.e.T(c0337a4.o, c0337a4.f5592p, c0337a4.f5593q);
                                } else {
                                    T9 = h5.e.T(th4.getClass().getSimpleName(), th4.toString(), AbstractC0034i.k("Cause: ", th4.getCause(), ", Stacktrace: ", Log.getStackTraceString(th4)));
                                }
                            }
                            cVar.g(T9);
                            return;
                        case 4:
                            C0345i c0345i6 = c0345i;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list5 = (List) obj;
                            Object obj9 = list5.get(0);
                            q5.h.c(obj9, "null cannot be cast to non-null type android.webkit.WebSettings");
                            WebSettings webSettings5 = (WebSettings) obj9;
                            Object obj10 = list5.get(1);
                            q5.h.c(obj10, "null cannot be cast to non-null type kotlin.Boolean");
                            boolean booleanValue4 = ((Boolean) obj10).booleanValue();
                            try {
                                c0345i6.getClass();
                                webSettings5.setSupportZoom(booleanValue4);
                                T10 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th5) {
                                if (th5 instanceof C0337a) {
                                    C0337a c0337a5 = th5;
                                    T10 = h5.e.T(c0337a5.o, c0337a5.f5592p, c0337a5.f5593q);
                                } else {
                                    T10 = h5.e.T(th5.getClass().getSimpleName(), th5.toString(), AbstractC0034i.k("Cause: ", th5.getCause(), ", Stacktrace: ", Log.getStackTraceString(th5)));
                                }
                            }
                            cVar.g(T10);
                            return;
                        case 5:
                            C0345i c0345i7 = c0345i;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list6 = (List) obj;
                            Object obj11 = list6.get(0);
                            q5.h.c(obj11, "null cannot be cast to non-null type android.webkit.WebSettings");
                            WebSettings webSettings6 = (WebSettings) obj11;
                            Object obj12 = list6.get(1);
                            q5.h.c(obj12, "null cannot be cast to non-null type kotlin.Boolean");
                            boolean booleanValue5 = ((Boolean) obj12).booleanValue();
                            try {
                                c0345i7.getClass();
                                webSettings6.setLoadWithOverviewMode(booleanValue5);
                                T11 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th6) {
                                if (th6 instanceof C0337a) {
                                    C0337a c0337a6 = th6;
                                    T11 = h5.e.T(c0337a6.o, c0337a6.f5592p, c0337a6.f5593q);
                                } else {
                                    T11 = h5.e.T(th6.getClass().getSimpleName(), th6.toString(), AbstractC0034i.k("Cause: ", th6.getCause(), ", Stacktrace: ", Log.getStackTraceString(th6)));
                                }
                            }
                            cVar.g(T11);
                            return;
                        case 6:
                            C0345i c0345i8 = c0345i;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list7 = (List) obj;
                            Object obj13 = list7.get(0);
                            q5.h.c(obj13, "null cannot be cast to non-null type android.webkit.WebSettings");
                            WebSettings webSettings7 = (WebSettings) obj13;
                            Object obj14 = list7.get(1);
                            q5.h.c(obj14, "null cannot be cast to non-null type kotlin.Boolean");
                            boolean booleanValue6 = ((Boolean) obj14).booleanValue();
                            try {
                                c0345i8.getClass();
                                webSettings7.setUseWideViewPort(booleanValue6);
                                T12 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th7) {
                                if (th7 instanceof C0337a) {
                                    C0337a c0337a7 = th7;
                                    T12 = h5.e.T(c0337a7.o, c0337a7.f5592p, c0337a7.f5593q);
                                } else {
                                    T12 = h5.e.T(th7.getClass().getSimpleName(), th7.toString(), AbstractC0034i.k("Cause: ", th7.getCause(), ", Stacktrace: ", Log.getStackTraceString(th7)));
                                }
                            }
                            cVar.g(T12);
                            return;
                        case 7:
                            C0345i c0345i9 = c0345i;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list8 = (List) obj;
                            Object obj15 = list8.get(0);
                            q5.h.c(obj15, "null cannot be cast to non-null type android.webkit.WebSettings");
                            WebSettings webSettings8 = (WebSettings) obj15;
                            Object obj16 = list8.get(1);
                            q5.h.c(obj16, "null cannot be cast to non-null type kotlin.Boolean");
                            boolean booleanValue7 = ((Boolean) obj16).booleanValue();
                            try {
                                c0345i9.getClass();
                                webSettings8.setDisplayZoomControls(booleanValue7);
                                T13 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th8) {
                                if (th8 instanceof C0337a) {
                                    C0337a c0337a8 = th8;
                                    T13 = h5.e.T(c0337a8.o, c0337a8.f5592p, c0337a8.f5593q);
                                } else {
                                    T13 = h5.e.T(th8.getClass().getSimpleName(), th8.toString(), AbstractC0034i.k("Cause: ", th8.getCause(), ", Stacktrace: ", Log.getStackTraceString(th8)));
                                }
                            }
                            cVar.g(T13);
                            return;
                        case 8:
                            C0345i c0345i10 = c0345i;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list9 = (List) obj;
                            Object obj17 = list9.get(0);
                            q5.h.c(obj17, "null cannot be cast to non-null type android.webkit.WebSettings");
                            WebSettings webSettings9 = (WebSettings) obj17;
                            Object obj18 = list9.get(1);
                            q5.h.c(obj18, "null cannot be cast to non-null type kotlin.Boolean");
                            boolean booleanValue8 = ((Boolean) obj18).booleanValue();
                            try {
                                c0345i10.getClass();
                                webSettings9.setBuiltInZoomControls(booleanValue8);
                                T14 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th9) {
                                if (th9 instanceof C0337a) {
                                    C0337a c0337a9 = th9;
                                    T14 = h5.e.T(c0337a9.o, c0337a9.f5592p, c0337a9.f5593q);
                                } else {
                                    T14 = h5.e.T(th9.getClass().getSimpleName(), th9.toString(), AbstractC0034i.k("Cause: ", th9.getCause(), ", Stacktrace: ", Log.getStackTraceString(th9)));
                                }
                            }
                            cVar.g(T14);
                            return;
                        case ContentHandlerProxy.PROCESSING_INSTRUCTION /* 9 */:
                            C0345i c0345i11 = c0345i;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list10 = (List) obj;
                            Object obj19 = list10.get(0);
                            q5.h.c(obj19, "null cannot be cast to non-null type android.webkit.WebSettings");
                            WebSettings webSettings10 = (WebSettings) obj19;
                            Object obj20 = list10.get(1);
                            q5.h.c(obj20, "null cannot be cast to non-null type kotlin.Boolean");
                            boolean booleanValue9 = ((Boolean) obj20).booleanValue();
                            try {
                                c0345i11.getClass();
                                webSettings10.setAllowFileAccess(booleanValue9);
                                T15 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th10) {
                                if (th10 instanceof C0337a) {
                                    C0337a c0337a10 = th10;
                                    T15 = h5.e.T(c0337a10.o, c0337a10.f5592p, c0337a10.f5593q);
                                } else {
                                    T15 = h5.e.T(th10.getClass().getSimpleName(), th10.toString(), AbstractC0034i.k("Cause: ", th10.getCause(), ", Stacktrace: ", Log.getStackTraceString(th10)));
                                }
                            }
                            cVar.g(T15);
                            return;
                        case 10:
                            C0345i c0345i12 = c0345i;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list11 = (List) obj;
                            Object obj21 = list11.get(0);
                            q5.h.c(obj21, "null cannot be cast to non-null type android.webkit.WebSettings");
                            WebSettings webSettings11 = (WebSettings) obj21;
                            Object obj22 = list11.get(1);
                            q5.h.c(obj22, "null cannot be cast to non-null type kotlin.Boolean");
                            boolean booleanValue10 = ((Boolean) obj22).booleanValue();
                            try {
                                c0345i12.getClass();
                                webSettings11.setAllowContentAccess(booleanValue10);
                                T16 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th11) {
                                if (th11 instanceof C0337a) {
                                    C0337a c0337a11 = th11;
                                    T16 = h5.e.T(c0337a11.o, c0337a11.f5592p, c0337a11.f5593q);
                                } else {
                                    T16 = h5.e.T(th11.getClass().getSimpleName(), th11.toString(), AbstractC0034i.k("Cause: ", th11.getCause(), ", Stacktrace: ", Log.getStackTraceString(th11)));
                                }
                            }
                            cVar.g(T16);
                            return;
                        case 11:
                            C0345i c0345i13 = c0345i;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list12 = (List) obj;
                            Object obj23 = list12.get(0);
                            q5.h.c(obj23, "null cannot be cast to non-null type android.webkit.WebSettings");
                            WebSettings webSettings12 = (WebSettings) obj23;
                            Object obj24 = list12.get(1);
                            q5.h.c(obj24, "null cannot be cast to non-null type kotlin.Boolean");
                            boolean booleanValue11 = ((Boolean) obj24).booleanValue();
                            try {
                                c0345i13.getClass();
                                webSettings12.setGeolocationEnabled(booleanValue11);
                                T17 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th12) {
                                if (th12 instanceof C0337a) {
                                    C0337a c0337a12 = th12;
                                    T17 = h5.e.T(c0337a12.o, c0337a12.f5592p, c0337a12.f5593q);
                                } else {
                                    T17 = h5.e.T(th12.getClass().getSimpleName(), th12.toString(), AbstractC0034i.k("Cause: ", th12.getCause(), ", Stacktrace: ", Log.getStackTraceString(th12)));
                                }
                            }
                            cVar.g(T17);
                            return;
                        case 12:
                            C0345i c0345i14 = c0345i;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list13 = (List) obj;
                            Object obj25 = list13.get(0);
                            q5.h.c(obj25, "null cannot be cast to non-null type android.webkit.WebSettings");
                            WebSettings webSettings13 = (WebSettings) obj25;
                            Object obj26 = list13.get(1);
                            q5.h.c(obj26, "null cannot be cast to non-null type kotlin.Long");
                            long longValue = ((Long) obj26).longValue();
                            try {
                                c0345i14.getClass();
                                webSettings13.setTextZoom((int) longValue);
                                T18 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th13) {
                                if (th13 instanceof C0337a) {
                                    C0337a c0337a13 = th13;
                                    T18 = h5.e.T(c0337a13.o, c0337a13.f5592p, c0337a13.f5593q);
                                } else {
                                    T18 = h5.e.T(th13.getClass().getSimpleName(), th13.toString(), AbstractC0034i.k("Cause: ", th13.getCause(), ", Stacktrace: ", Log.getStackTraceString(th13)));
                                }
                            }
                            cVar.g(T18);
                            return;
                        case 13:
                            C0345i c0345i15 = c0345i;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            Object obj27 = ((List) obj).get(0);
                            q5.h.c(obj27, "null cannot be cast to non-null type android.webkit.WebSettings");
                            WebSettings webSettings14 = (WebSettings) obj27;
                            try {
                                c0345i15.getClass();
                                T19 = android.support.v4.media.session.a.z(webSettings14.getUserAgentString());
                            } catch (Throwable th14) {
                                if (th14 instanceof C0337a) {
                                    C0337a c0337a14 = th14;
                                    T19 = h5.e.T(c0337a14.o, c0337a14.f5592p, c0337a14.f5593q);
                                } else {
                                    T19 = h5.e.T(th14.getClass().getSimpleName(), th14.toString(), AbstractC0034i.k("Cause: ", th14.getCause(), ", Stacktrace: ", Log.getStackTraceString(th14)));
                                }
                            }
                            cVar.g(T19);
                            return;
                        case 14:
                            C0345i c0345i16 = c0345i;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list14 = (List) obj;
                            Object obj28 = list14.get(0);
                            q5.h.c(obj28, "null cannot be cast to non-null type android.webkit.WebSettings");
                            WebSettings webSettings15 = (WebSettings) obj28;
                            Object obj29 = list14.get(1);
                            q5.h.c(obj29, "null cannot be cast to non-null type io.flutter.plugins.webviewflutter.MixedContentMode");
                            EnumC0359w enumC0359w = (EnumC0359w) obj29;
                            try {
                                c0345i16.getClass();
                                int ordinal = enumC0359w.ordinal();
                                if (ordinal != 0) {
                                    if (ordinal != 1) {
                                        if (ordinal == 2) {
                                            webSettings15.setMixedContentMode(1);
                                        }
                                    } else {
                                        webSettings15.setMixedContentMode(2);
                                    }
                                } else {
                                    webSettings15.setMixedContentMode(0);
                                }
                                T20 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th15) {
                                if (th15 instanceof C0337a) {
                                    C0337a c0337a15 = th15;
                                    T20 = h5.e.T(c0337a15.o, c0337a15.f5592p, c0337a15.f5593q);
                                } else {
                                    T20 = h5.e.T(th15.getClass().getSimpleName(), th15.toString(), AbstractC0034i.k("Cause: ", th15.getCause(), ", Stacktrace: ", Log.getStackTraceString(th15)));
                                }
                            }
                            cVar.g(T20);
                            return;
                        case 15:
                            C0345i c0345i17 = c0345i;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list15 = (List) obj;
                            Object obj30 = list15.get(0);
                            q5.h.c(obj30, "null cannot be cast to non-null type android.webkit.WebSettings");
                            WebSettings webSettings16 = (WebSettings) obj30;
                            Object obj31 = list15.get(1);
                            q5.h.c(obj31, "null cannot be cast to non-null type kotlin.Boolean");
                            boolean booleanValue12 = ((Boolean) obj31).booleanValue();
                            try {
                                c0345i17.getClass();
                                webSettings16.setJavaScriptCanOpenWindowsAutomatically(booleanValue12);
                                T21 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th16) {
                                if (th16 instanceof C0337a) {
                                    C0337a c0337a16 = th16;
                                    T21 = h5.e.T(c0337a16.o, c0337a16.f5592p, c0337a16.f5593q);
                                } else {
                                    T21 = h5.e.T(th16.getClass().getSimpleName(), th16.toString(), AbstractC0034i.k("Cause: ", th16.getCause(), ", Stacktrace: ", Log.getStackTraceString(th16)));
                                }
                            }
                            cVar.g(T21);
                            return;
                        default:
                            C0345i c0345i18 = c0345i;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list16 = (List) obj;
                            Object obj32 = list16.get(0);
                            q5.h.c(obj32, "null cannot be cast to non-null type android.webkit.WebSettings");
                            WebSettings webSettings17 = (WebSettings) obj32;
                            Object obj33 = list16.get(1);
                            q5.h.c(obj33, "null cannot be cast to non-null type kotlin.Boolean");
                            boolean booleanValue13 = ((Boolean) obj33).booleanValue();
                            try {
                                c0345i18.getClass();
                                webSettings17.setSupportMultipleWindows(booleanValue13);
                                T22 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th17) {
                                if (th17 instanceof C0337a) {
                                    C0337a c0337a17 = th17;
                                    T22 = h5.e.T(c0337a17.o, c0337a17.f5592p, c0337a17.f5593q);
                                } else {
                                    T22 = h5.e.T(th17.getClass().getSimpleName(), th17.toString(), AbstractC0034i.k("Cause: ", th17.getCause(), ", Stacktrace: ", Log.getStackTraceString(th17)));
                                }
                            }
                            cVar.g(T22);
                            return;
                    }
                }
            });
        } else {
            uVar13.y(null);
        }
        v3.u uVar14 = new v3.u(fVar, "dev.flutter.pigeon.webview_flutter_android.WebSettings.setGeolocationEnabled", gVar, (C0508g) null);
        if (c0345i != null) {
            final int i19 = 11;
            uVar14.y(new b() { // from class: c5.J
                @Override // M4.b
                public final void e(Object obj, A.c cVar) {
                    List T6;
                    List T7;
                    List T8;
                    List T9;
                    List T10;
                    List T11;
                    List T12;
                    List T13;
                    List T14;
                    List T15;
                    List T16;
                    List T17;
                    List T18;
                    List T19;
                    List T20;
                    List T21;
                    List T22;
                    switch (i19) {
                        case 0:
                            C0345i c0345i2 = c0345i;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list = (List) obj;
                            Object obj2 = list.get(0);
                            q5.h.c(obj2, "null cannot be cast to non-null type android.webkit.WebSettings");
                            WebSettings webSettings = (WebSettings) obj2;
                            Object obj3 = list.get(1);
                            q5.h.c(obj3, "null cannot be cast to non-null type kotlin.Boolean");
                            boolean booleanValue = ((Boolean) obj3).booleanValue();
                            try {
                                c0345i2.getClass();
                                webSettings.setDomStorageEnabled(booleanValue);
                                T6 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th) {
                                if (th instanceof C0337a) {
                                    C0337a c0337a = th;
                                    T6 = h5.e.T(c0337a.o, c0337a.f5592p, c0337a.f5593q);
                                } else {
                                    T6 = h5.e.T(th.getClass().getSimpleName(), th.toString(), AbstractC0034i.k("Cause: ", th.getCause(), ", Stacktrace: ", Log.getStackTraceString(th)));
                                }
                            }
                            cVar.g(T6);
                            return;
                        case 1:
                            C0345i c0345i3 = c0345i;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list2 = (List) obj;
                            Object obj4 = list2.get(0);
                            q5.h.c(obj4, "null cannot be cast to non-null type android.webkit.WebSettings");
                            WebSettings webSettings2 = (WebSettings) obj4;
                            Object obj5 = list2.get(1);
                            q5.h.c(obj5, "null cannot be cast to non-null type kotlin.Boolean");
                            boolean booleanValue2 = ((Boolean) obj5).booleanValue();
                            try {
                                c0345i3.getClass();
                                webSettings2.setJavaScriptEnabled(booleanValue2);
                                T7 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th2) {
                                if (th2 instanceof C0337a) {
                                    C0337a c0337a2 = th2;
                                    T7 = h5.e.T(c0337a2.o, c0337a2.f5592p, c0337a2.f5593q);
                                } else {
                                    T7 = h5.e.T(th2.getClass().getSimpleName(), th2.toString(), AbstractC0034i.k("Cause: ", th2.getCause(), ", Stacktrace: ", Log.getStackTraceString(th2)));
                                }
                            }
                            cVar.g(T7);
                            return;
                        case 2:
                            C0345i c0345i4 = c0345i;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list3 = (List) obj;
                            Object obj6 = list3.get(0);
                            q5.h.c(obj6, "null cannot be cast to non-null type android.webkit.WebSettings");
                            WebSettings webSettings3 = (WebSettings) obj6;
                            String str = (String) list3.get(1);
                            try {
                                c0345i4.getClass();
                                webSettings3.setUserAgentString(str);
                                T8 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th3) {
                                if (th3 instanceof C0337a) {
                                    C0337a c0337a3 = th3;
                                    T8 = h5.e.T(c0337a3.o, c0337a3.f5592p, c0337a3.f5593q);
                                } else {
                                    T8 = h5.e.T(th3.getClass().getSimpleName(), th3.toString(), AbstractC0034i.k("Cause: ", th3.getCause(), ", Stacktrace: ", Log.getStackTraceString(th3)));
                                }
                            }
                            cVar.g(T8);
                            return;
                        case 3:
                            C0345i c0345i5 = c0345i;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list4 = (List) obj;
                            Object obj7 = list4.get(0);
                            q5.h.c(obj7, "null cannot be cast to non-null type android.webkit.WebSettings");
                            WebSettings webSettings4 = (WebSettings) obj7;
                            Object obj8 = list4.get(1);
                            q5.h.c(obj8, "null cannot be cast to non-null type kotlin.Boolean");
                            boolean booleanValue3 = ((Boolean) obj8).booleanValue();
                            try {
                                c0345i5.getClass();
                                webSettings4.setMediaPlaybackRequiresUserGesture(booleanValue3);
                                T9 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th4) {
                                if (th4 instanceof C0337a) {
                                    C0337a c0337a4 = th4;
                                    T9 = h5.e.T(c0337a4.o, c0337a4.f5592p, c0337a4.f5593q);
                                } else {
                                    T9 = h5.e.T(th4.getClass().getSimpleName(), th4.toString(), AbstractC0034i.k("Cause: ", th4.getCause(), ", Stacktrace: ", Log.getStackTraceString(th4)));
                                }
                            }
                            cVar.g(T9);
                            return;
                        case 4:
                            C0345i c0345i6 = c0345i;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list5 = (List) obj;
                            Object obj9 = list5.get(0);
                            q5.h.c(obj9, "null cannot be cast to non-null type android.webkit.WebSettings");
                            WebSettings webSettings5 = (WebSettings) obj9;
                            Object obj10 = list5.get(1);
                            q5.h.c(obj10, "null cannot be cast to non-null type kotlin.Boolean");
                            boolean booleanValue4 = ((Boolean) obj10).booleanValue();
                            try {
                                c0345i6.getClass();
                                webSettings5.setSupportZoom(booleanValue4);
                                T10 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th5) {
                                if (th5 instanceof C0337a) {
                                    C0337a c0337a5 = th5;
                                    T10 = h5.e.T(c0337a5.o, c0337a5.f5592p, c0337a5.f5593q);
                                } else {
                                    T10 = h5.e.T(th5.getClass().getSimpleName(), th5.toString(), AbstractC0034i.k("Cause: ", th5.getCause(), ", Stacktrace: ", Log.getStackTraceString(th5)));
                                }
                            }
                            cVar.g(T10);
                            return;
                        case 5:
                            C0345i c0345i7 = c0345i;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list6 = (List) obj;
                            Object obj11 = list6.get(0);
                            q5.h.c(obj11, "null cannot be cast to non-null type android.webkit.WebSettings");
                            WebSettings webSettings6 = (WebSettings) obj11;
                            Object obj12 = list6.get(1);
                            q5.h.c(obj12, "null cannot be cast to non-null type kotlin.Boolean");
                            boolean booleanValue5 = ((Boolean) obj12).booleanValue();
                            try {
                                c0345i7.getClass();
                                webSettings6.setLoadWithOverviewMode(booleanValue5);
                                T11 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th6) {
                                if (th6 instanceof C0337a) {
                                    C0337a c0337a6 = th6;
                                    T11 = h5.e.T(c0337a6.o, c0337a6.f5592p, c0337a6.f5593q);
                                } else {
                                    T11 = h5.e.T(th6.getClass().getSimpleName(), th6.toString(), AbstractC0034i.k("Cause: ", th6.getCause(), ", Stacktrace: ", Log.getStackTraceString(th6)));
                                }
                            }
                            cVar.g(T11);
                            return;
                        case 6:
                            C0345i c0345i8 = c0345i;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list7 = (List) obj;
                            Object obj13 = list7.get(0);
                            q5.h.c(obj13, "null cannot be cast to non-null type android.webkit.WebSettings");
                            WebSettings webSettings7 = (WebSettings) obj13;
                            Object obj14 = list7.get(1);
                            q5.h.c(obj14, "null cannot be cast to non-null type kotlin.Boolean");
                            boolean booleanValue6 = ((Boolean) obj14).booleanValue();
                            try {
                                c0345i8.getClass();
                                webSettings7.setUseWideViewPort(booleanValue6);
                                T12 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th7) {
                                if (th7 instanceof C0337a) {
                                    C0337a c0337a7 = th7;
                                    T12 = h5.e.T(c0337a7.o, c0337a7.f5592p, c0337a7.f5593q);
                                } else {
                                    T12 = h5.e.T(th7.getClass().getSimpleName(), th7.toString(), AbstractC0034i.k("Cause: ", th7.getCause(), ", Stacktrace: ", Log.getStackTraceString(th7)));
                                }
                            }
                            cVar.g(T12);
                            return;
                        case 7:
                            C0345i c0345i9 = c0345i;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list8 = (List) obj;
                            Object obj15 = list8.get(0);
                            q5.h.c(obj15, "null cannot be cast to non-null type android.webkit.WebSettings");
                            WebSettings webSettings8 = (WebSettings) obj15;
                            Object obj16 = list8.get(1);
                            q5.h.c(obj16, "null cannot be cast to non-null type kotlin.Boolean");
                            boolean booleanValue7 = ((Boolean) obj16).booleanValue();
                            try {
                                c0345i9.getClass();
                                webSettings8.setDisplayZoomControls(booleanValue7);
                                T13 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th8) {
                                if (th8 instanceof C0337a) {
                                    C0337a c0337a8 = th8;
                                    T13 = h5.e.T(c0337a8.o, c0337a8.f5592p, c0337a8.f5593q);
                                } else {
                                    T13 = h5.e.T(th8.getClass().getSimpleName(), th8.toString(), AbstractC0034i.k("Cause: ", th8.getCause(), ", Stacktrace: ", Log.getStackTraceString(th8)));
                                }
                            }
                            cVar.g(T13);
                            return;
                        case 8:
                            C0345i c0345i10 = c0345i;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list9 = (List) obj;
                            Object obj17 = list9.get(0);
                            q5.h.c(obj17, "null cannot be cast to non-null type android.webkit.WebSettings");
                            WebSettings webSettings9 = (WebSettings) obj17;
                            Object obj18 = list9.get(1);
                            q5.h.c(obj18, "null cannot be cast to non-null type kotlin.Boolean");
                            boolean booleanValue8 = ((Boolean) obj18).booleanValue();
                            try {
                                c0345i10.getClass();
                                webSettings9.setBuiltInZoomControls(booleanValue8);
                                T14 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th9) {
                                if (th9 instanceof C0337a) {
                                    C0337a c0337a9 = th9;
                                    T14 = h5.e.T(c0337a9.o, c0337a9.f5592p, c0337a9.f5593q);
                                } else {
                                    T14 = h5.e.T(th9.getClass().getSimpleName(), th9.toString(), AbstractC0034i.k("Cause: ", th9.getCause(), ", Stacktrace: ", Log.getStackTraceString(th9)));
                                }
                            }
                            cVar.g(T14);
                            return;
                        case ContentHandlerProxy.PROCESSING_INSTRUCTION /* 9 */:
                            C0345i c0345i11 = c0345i;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list10 = (List) obj;
                            Object obj19 = list10.get(0);
                            q5.h.c(obj19, "null cannot be cast to non-null type android.webkit.WebSettings");
                            WebSettings webSettings10 = (WebSettings) obj19;
                            Object obj20 = list10.get(1);
                            q5.h.c(obj20, "null cannot be cast to non-null type kotlin.Boolean");
                            boolean booleanValue9 = ((Boolean) obj20).booleanValue();
                            try {
                                c0345i11.getClass();
                                webSettings10.setAllowFileAccess(booleanValue9);
                                T15 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th10) {
                                if (th10 instanceof C0337a) {
                                    C0337a c0337a10 = th10;
                                    T15 = h5.e.T(c0337a10.o, c0337a10.f5592p, c0337a10.f5593q);
                                } else {
                                    T15 = h5.e.T(th10.getClass().getSimpleName(), th10.toString(), AbstractC0034i.k("Cause: ", th10.getCause(), ", Stacktrace: ", Log.getStackTraceString(th10)));
                                }
                            }
                            cVar.g(T15);
                            return;
                        case 10:
                            C0345i c0345i12 = c0345i;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list11 = (List) obj;
                            Object obj21 = list11.get(0);
                            q5.h.c(obj21, "null cannot be cast to non-null type android.webkit.WebSettings");
                            WebSettings webSettings11 = (WebSettings) obj21;
                            Object obj22 = list11.get(1);
                            q5.h.c(obj22, "null cannot be cast to non-null type kotlin.Boolean");
                            boolean booleanValue10 = ((Boolean) obj22).booleanValue();
                            try {
                                c0345i12.getClass();
                                webSettings11.setAllowContentAccess(booleanValue10);
                                T16 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th11) {
                                if (th11 instanceof C0337a) {
                                    C0337a c0337a11 = th11;
                                    T16 = h5.e.T(c0337a11.o, c0337a11.f5592p, c0337a11.f5593q);
                                } else {
                                    T16 = h5.e.T(th11.getClass().getSimpleName(), th11.toString(), AbstractC0034i.k("Cause: ", th11.getCause(), ", Stacktrace: ", Log.getStackTraceString(th11)));
                                }
                            }
                            cVar.g(T16);
                            return;
                        case 11:
                            C0345i c0345i13 = c0345i;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list12 = (List) obj;
                            Object obj23 = list12.get(0);
                            q5.h.c(obj23, "null cannot be cast to non-null type android.webkit.WebSettings");
                            WebSettings webSettings12 = (WebSettings) obj23;
                            Object obj24 = list12.get(1);
                            q5.h.c(obj24, "null cannot be cast to non-null type kotlin.Boolean");
                            boolean booleanValue11 = ((Boolean) obj24).booleanValue();
                            try {
                                c0345i13.getClass();
                                webSettings12.setGeolocationEnabled(booleanValue11);
                                T17 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th12) {
                                if (th12 instanceof C0337a) {
                                    C0337a c0337a12 = th12;
                                    T17 = h5.e.T(c0337a12.o, c0337a12.f5592p, c0337a12.f5593q);
                                } else {
                                    T17 = h5.e.T(th12.getClass().getSimpleName(), th12.toString(), AbstractC0034i.k("Cause: ", th12.getCause(), ", Stacktrace: ", Log.getStackTraceString(th12)));
                                }
                            }
                            cVar.g(T17);
                            return;
                        case 12:
                            C0345i c0345i14 = c0345i;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list13 = (List) obj;
                            Object obj25 = list13.get(0);
                            q5.h.c(obj25, "null cannot be cast to non-null type android.webkit.WebSettings");
                            WebSettings webSettings13 = (WebSettings) obj25;
                            Object obj26 = list13.get(1);
                            q5.h.c(obj26, "null cannot be cast to non-null type kotlin.Long");
                            long longValue = ((Long) obj26).longValue();
                            try {
                                c0345i14.getClass();
                                webSettings13.setTextZoom((int) longValue);
                                T18 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th13) {
                                if (th13 instanceof C0337a) {
                                    C0337a c0337a13 = th13;
                                    T18 = h5.e.T(c0337a13.o, c0337a13.f5592p, c0337a13.f5593q);
                                } else {
                                    T18 = h5.e.T(th13.getClass().getSimpleName(), th13.toString(), AbstractC0034i.k("Cause: ", th13.getCause(), ", Stacktrace: ", Log.getStackTraceString(th13)));
                                }
                            }
                            cVar.g(T18);
                            return;
                        case 13:
                            C0345i c0345i15 = c0345i;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            Object obj27 = ((List) obj).get(0);
                            q5.h.c(obj27, "null cannot be cast to non-null type android.webkit.WebSettings");
                            WebSettings webSettings14 = (WebSettings) obj27;
                            try {
                                c0345i15.getClass();
                                T19 = android.support.v4.media.session.a.z(webSettings14.getUserAgentString());
                            } catch (Throwable th14) {
                                if (th14 instanceof C0337a) {
                                    C0337a c0337a14 = th14;
                                    T19 = h5.e.T(c0337a14.o, c0337a14.f5592p, c0337a14.f5593q);
                                } else {
                                    T19 = h5.e.T(th14.getClass().getSimpleName(), th14.toString(), AbstractC0034i.k("Cause: ", th14.getCause(), ", Stacktrace: ", Log.getStackTraceString(th14)));
                                }
                            }
                            cVar.g(T19);
                            return;
                        case 14:
                            C0345i c0345i16 = c0345i;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list14 = (List) obj;
                            Object obj28 = list14.get(0);
                            q5.h.c(obj28, "null cannot be cast to non-null type android.webkit.WebSettings");
                            WebSettings webSettings15 = (WebSettings) obj28;
                            Object obj29 = list14.get(1);
                            q5.h.c(obj29, "null cannot be cast to non-null type io.flutter.plugins.webviewflutter.MixedContentMode");
                            EnumC0359w enumC0359w = (EnumC0359w) obj29;
                            try {
                                c0345i16.getClass();
                                int ordinal = enumC0359w.ordinal();
                                if (ordinal != 0) {
                                    if (ordinal != 1) {
                                        if (ordinal == 2) {
                                            webSettings15.setMixedContentMode(1);
                                        }
                                    } else {
                                        webSettings15.setMixedContentMode(2);
                                    }
                                } else {
                                    webSettings15.setMixedContentMode(0);
                                }
                                T20 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th15) {
                                if (th15 instanceof C0337a) {
                                    C0337a c0337a15 = th15;
                                    T20 = h5.e.T(c0337a15.o, c0337a15.f5592p, c0337a15.f5593q);
                                } else {
                                    T20 = h5.e.T(th15.getClass().getSimpleName(), th15.toString(), AbstractC0034i.k("Cause: ", th15.getCause(), ", Stacktrace: ", Log.getStackTraceString(th15)));
                                }
                            }
                            cVar.g(T20);
                            return;
                        case 15:
                            C0345i c0345i17 = c0345i;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list15 = (List) obj;
                            Object obj30 = list15.get(0);
                            q5.h.c(obj30, "null cannot be cast to non-null type android.webkit.WebSettings");
                            WebSettings webSettings16 = (WebSettings) obj30;
                            Object obj31 = list15.get(1);
                            q5.h.c(obj31, "null cannot be cast to non-null type kotlin.Boolean");
                            boolean booleanValue12 = ((Boolean) obj31).booleanValue();
                            try {
                                c0345i17.getClass();
                                webSettings16.setJavaScriptCanOpenWindowsAutomatically(booleanValue12);
                                T21 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th16) {
                                if (th16 instanceof C0337a) {
                                    C0337a c0337a16 = th16;
                                    T21 = h5.e.T(c0337a16.o, c0337a16.f5592p, c0337a16.f5593q);
                                } else {
                                    T21 = h5.e.T(th16.getClass().getSimpleName(), th16.toString(), AbstractC0034i.k("Cause: ", th16.getCause(), ", Stacktrace: ", Log.getStackTraceString(th16)));
                                }
                            }
                            cVar.g(T21);
                            return;
                        default:
                            C0345i c0345i18 = c0345i;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list16 = (List) obj;
                            Object obj32 = list16.get(0);
                            q5.h.c(obj32, "null cannot be cast to non-null type android.webkit.WebSettings");
                            WebSettings webSettings17 = (WebSettings) obj32;
                            Object obj33 = list16.get(1);
                            q5.h.c(obj33, "null cannot be cast to non-null type kotlin.Boolean");
                            boolean booleanValue13 = ((Boolean) obj33).booleanValue();
                            try {
                                c0345i18.getClass();
                                webSettings17.setSupportMultipleWindows(booleanValue13);
                                T22 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th17) {
                                if (th17 instanceof C0337a) {
                                    C0337a c0337a17 = th17;
                                    T22 = h5.e.T(c0337a17.o, c0337a17.f5592p, c0337a17.f5593q);
                                } else {
                                    T22 = h5.e.T(th17.getClass().getSimpleName(), th17.toString(), AbstractC0034i.k("Cause: ", th17.getCause(), ", Stacktrace: ", Log.getStackTraceString(th17)));
                                }
                            }
                            cVar.g(T22);
                            return;
                    }
                }
            });
        } else {
            uVar14.y(null);
        }
        v3.u uVar15 = new v3.u(fVar, "dev.flutter.pigeon.webview_flutter_android.WebSettings.setTextZoom", gVar, (C0508g) null);
        if (c0345i != null) {
            final int i20 = 12;
            uVar15.y(new b() { // from class: c5.J
                @Override // M4.b
                public final void e(Object obj, A.c cVar) {
                    List T6;
                    List T7;
                    List T8;
                    List T9;
                    List T10;
                    List T11;
                    List T12;
                    List T13;
                    List T14;
                    List T15;
                    List T16;
                    List T17;
                    List T18;
                    List T19;
                    List T20;
                    List T21;
                    List T22;
                    switch (i20) {
                        case 0:
                            C0345i c0345i2 = c0345i;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list = (List) obj;
                            Object obj2 = list.get(0);
                            q5.h.c(obj2, "null cannot be cast to non-null type android.webkit.WebSettings");
                            WebSettings webSettings = (WebSettings) obj2;
                            Object obj3 = list.get(1);
                            q5.h.c(obj3, "null cannot be cast to non-null type kotlin.Boolean");
                            boolean booleanValue = ((Boolean) obj3).booleanValue();
                            try {
                                c0345i2.getClass();
                                webSettings.setDomStorageEnabled(booleanValue);
                                T6 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th) {
                                if (th instanceof C0337a) {
                                    C0337a c0337a = th;
                                    T6 = h5.e.T(c0337a.o, c0337a.f5592p, c0337a.f5593q);
                                } else {
                                    T6 = h5.e.T(th.getClass().getSimpleName(), th.toString(), AbstractC0034i.k("Cause: ", th.getCause(), ", Stacktrace: ", Log.getStackTraceString(th)));
                                }
                            }
                            cVar.g(T6);
                            return;
                        case 1:
                            C0345i c0345i3 = c0345i;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list2 = (List) obj;
                            Object obj4 = list2.get(0);
                            q5.h.c(obj4, "null cannot be cast to non-null type android.webkit.WebSettings");
                            WebSettings webSettings2 = (WebSettings) obj4;
                            Object obj5 = list2.get(1);
                            q5.h.c(obj5, "null cannot be cast to non-null type kotlin.Boolean");
                            boolean booleanValue2 = ((Boolean) obj5).booleanValue();
                            try {
                                c0345i3.getClass();
                                webSettings2.setJavaScriptEnabled(booleanValue2);
                                T7 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th2) {
                                if (th2 instanceof C0337a) {
                                    C0337a c0337a2 = th2;
                                    T7 = h5.e.T(c0337a2.o, c0337a2.f5592p, c0337a2.f5593q);
                                } else {
                                    T7 = h5.e.T(th2.getClass().getSimpleName(), th2.toString(), AbstractC0034i.k("Cause: ", th2.getCause(), ", Stacktrace: ", Log.getStackTraceString(th2)));
                                }
                            }
                            cVar.g(T7);
                            return;
                        case 2:
                            C0345i c0345i4 = c0345i;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list3 = (List) obj;
                            Object obj6 = list3.get(0);
                            q5.h.c(obj6, "null cannot be cast to non-null type android.webkit.WebSettings");
                            WebSettings webSettings3 = (WebSettings) obj6;
                            String str = (String) list3.get(1);
                            try {
                                c0345i4.getClass();
                                webSettings3.setUserAgentString(str);
                                T8 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th3) {
                                if (th3 instanceof C0337a) {
                                    C0337a c0337a3 = th3;
                                    T8 = h5.e.T(c0337a3.o, c0337a3.f5592p, c0337a3.f5593q);
                                } else {
                                    T8 = h5.e.T(th3.getClass().getSimpleName(), th3.toString(), AbstractC0034i.k("Cause: ", th3.getCause(), ", Stacktrace: ", Log.getStackTraceString(th3)));
                                }
                            }
                            cVar.g(T8);
                            return;
                        case 3:
                            C0345i c0345i5 = c0345i;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list4 = (List) obj;
                            Object obj7 = list4.get(0);
                            q5.h.c(obj7, "null cannot be cast to non-null type android.webkit.WebSettings");
                            WebSettings webSettings4 = (WebSettings) obj7;
                            Object obj8 = list4.get(1);
                            q5.h.c(obj8, "null cannot be cast to non-null type kotlin.Boolean");
                            boolean booleanValue3 = ((Boolean) obj8).booleanValue();
                            try {
                                c0345i5.getClass();
                                webSettings4.setMediaPlaybackRequiresUserGesture(booleanValue3);
                                T9 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th4) {
                                if (th4 instanceof C0337a) {
                                    C0337a c0337a4 = th4;
                                    T9 = h5.e.T(c0337a4.o, c0337a4.f5592p, c0337a4.f5593q);
                                } else {
                                    T9 = h5.e.T(th4.getClass().getSimpleName(), th4.toString(), AbstractC0034i.k("Cause: ", th4.getCause(), ", Stacktrace: ", Log.getStackTraceString(th4)));
                                }
                            }
                            cVar.g(T9);
                            return;
                        case 4:
                            C0345i c0345i6 = c0345i;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list5 = (List) obj;
                            Object obj9 = list5.get(0);
                            q5.h.c(obj9, "null cannot be cast to non-null type android.webkit.WebSettings");
                            WebSettings webSettings5 = (WebSettings) obj9;
                            Object obj10 = list5.get(1);
                            q5.h.c(obj10, "null cannot be cast to non-null type kotlin.Boolean");
                            boolean booleanValue4 = ((Boolean) obj10).booleanValue();
                            try {
                                c0345i6.getClass();
                                webSettings5.setSupportZoom(booleanValue4);
                                T10 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th5) {
                                if (th5 instanceof C0337a) {
                                    C0337a c0337a5 = th5;
                                    T10 = h5.e.T(c0337a5.o, c0337a5.f5592p, c0337a5.f5593q);
                                } else {
                                    T10 = h5.e.T(th5.getClass().getSimpleName(), th5.toString(), AbstractC0034i.k("Cause: ", th5.getCause(), ", Stacktrace: ", Log.getStackTraceString(th5)));
                                }
                            }
                            cVar.g(T10);
                            return;
                        case 5:
                            C0345i c0345i7 = c0345i;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list6 = (List) obj;
                            Object obj11 = list6.get(0);
                            q5.h.c(obj11, "null cannot be cast to non-null type android.webkit.WebSettings");
                            WebSettings webSettings6 = (WebSettings) obj11;
                            Object obj12 = list6.get(1);
                            q5.h.c(obj12, "null cannot be cast to non-null type kotlin.Boolean");
                            boolean booleanValue5 = ((Boolean) obj12).booleanValue();
                            try {
                                c0345i7.getClass();
                                webSettings6.setLoadWithOverviewMode(booleanValue5);
                                T11 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th6) {
                                if (th6 instanceof C0337a) {
                                    C0337a c0337a6 = th6;
                                    T11 = h5.e.T(c0337a6.o, c0337a6.f5592p, c0337a6.f5593q);
                                } else {
                                    T11 = h5.e.T(th6.getClass().getSimpleName(), th6.toString(), AbstractC0034i.k("Cause: ", th6.getCause(), ", Stacktrace: ", Log.getStackTraceString(th6)));
                                }
                            }
                            cVar.g(T11);
                            return;
                        case 6:
                            C0345i c0345i8 = c0345i;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list7 = (List) obj;
                            Object obj13 = list7.get(0);
                            q5.h.c(obj13, "null cannot be cast to non-null type android.webkit.WebSettings");
                            WebSettings webSettings7 = (WebSettings) obj13;
                            Object obj14 = list7.get(1);
                            q5.h.c(obj14, "null cannot be cast to non-null type kotlin.Boolean");
                            boolean booleanValue6 = ((Boolean) obj14).booleanValue();
                            try {
                                c0345i8.getClass();
                                webSettings7.setUseWideViewPort(booleanValue6);
                                T12 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th7) {
                                if (th7 instanceof C0337a) {
                                    C0337a c0337a7 = th7;
                                    T12 = h5.e.T(c0337a7.o, c0337a7.f5592p, c0337a7.f5593q);
                                } else {
                                    T12 = h5.e.T(th7.getClass().getSimpleName(), th7.toString(), AbstractC0034i.k("Cause: ", th7.getCause(), ", Stacktrace: ", Log.getStackTraceString(th7)));
                                }
                            }
                            cVar.g(T12);
                            return;
                        case 7:
                            C0345i c0345i9 = c0345i;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list8 = (List) obj;
                            Object obj15 = list8.get(0);
                            q5.h.c(obj15, "null cannot be cast to non-null type android.webkit.WebSettings");
                            WebSettings webSettings8 = (WebSettings) obj15;
                            Object obj16 = list8.get(1);
                            q5.h.c(obj16, "null cannot be cast to non-null type kotlin.Boolean");
                            boolean booleanValue7 = ((Boolean) obj16).booleanValue();
                            try {
                                c0345i9.getClass();
                                webSettings8.setDisplayZoomControls(booleanValue7);
                                T13 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th8) {
                                if (th8 instanceof C0337a) {
                                    C0337a c0337a8 = th8;
                                    T13 = h5.e.T(c0337a8.o, c0337a8.f5592p, c0337a8.f5593q);
                                } else {
                                    T13 = h5.e.T(th8.getClass().getSimpleName(), th8.toString(), AbstractC0034i.k("Cause: ", th8.getCause(), ", Stacktrace: ", Log.getStackTraceString(th8)));
                                }
                            }
                            cVar.g(T13);
                            return;
                        case 8:
                            C0345i c0345i10 = c0345i;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list9 = (List) obj;
                            Object obj17 = list9.get(0);
                            q5.h.c(obj17, "null cannot be cast to non-null type android.webkit.WebSettings");
                            WebSettings webSettings9 = (WebSettings) obj17;
                            Object obj18 = list9.get(1);
                            q5.h.c(obj18, "null cannot be cast to non-null type kotlin.Boolean");
                            boolean booleanValue8 = ((Boolean) obj18).booleanValue();
                            try {
                                c0345i10.getClass();
                                webSettings9.setBuiltInZoomControls(booleanValue8);
                                T14 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th9) {
                                if (th9 instanceof C0337a) {
                                    C0337a c0337a9 = th9;
                                    T14 = h5.e.T(c0337a9.o, c0337a9.f5592p, c0337a9.f5593q);
                                } else {
                                    T14 = h5.e.T(th9.getClass().getSimpleName(), th9.toString(), AbstractC0034i.k("Cause: ", th9.getCause(), ", Stacktrace: ", Log.getStackTraceString(th9)));
                                }
                            }
                            cVar.g(T14);
                            return;
                        case ContentHandlerProxy.PROCESSING_INSTRUCTION /* 9 */:
                            C0345i c0345i11 = c0345i;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list10 = (List) obj;
                            Object obj19 = list10.get(0);
                            q5.h.c(obj19, "null cannot be cast to non-null type android.webkit.WebSettings");
                            WebSettings webSettings10 = (WebSettings) obj19;
                            Object obj20 = list10.get(1);
                            q5.h.c(obj20, "null cannot be cast to non-null type kotlin.Boolean");
                            boolean booleanValue9 = ((Boolean) obj20).booleanValue();
                            try {
                                c0345i11.getClass();
                                webSettings10.setAllowFileAccess(booleanValue9);
                                T15 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th10) {
                                if (th10 instanceof C0337a) {
                                    C0337a c0337a10 = th10;
                                    T15 = h5.e.T(c0337a10.o, c0337a10.f5592p, c0337a10.f5593q);
                                } else {
                                    T15 = h5.e.T(th10.getClass().getSimpleName(), th10.toString(), AbstractC0034i.k("Cause: ", th10.getCause(), ", Stacktrace: ", Log.getStackTraceString(th10)));
                                }
                            }
                            cVar.g(T15);
                            return;
                        case 10:
                            C0345i c0345i12 = c0345i;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list11 = (List) obj;
                            Object obj21 = list11.get(0);
                            q5.h.c(obj21, "null cannot be cast to non-null type android.webkit.WebSettings");
                            WebSettings webSettings11 = (WebSettings) obj21;
                            Object obj22 = list11.get(1);
                            q5.h.c(obj22, "null cannot be cast to non-null type kotlin.Boolean");
                            boolean booleanValue10 = ((Boolean) obj22).booleanValue();
                            try {
                                c0345i12.getClass();
                                webSettings11.setAllowContentAccess(booleanValue10);
                                T16 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th11) {
                                if (th11 instanceof C0337a) {
                                    C0337a c0337a11 = th11;
                                    T16 = h5.e.T(c0337a11.o, c0337a11.f5592p, c0337a11.f5593q);
                                } else {
                                    T16 = h5.e.T(th11.getClass().getSimpleName(), th11.toString(), AbstractC0034i.k("Cause: ", th11.getCause(), ", Stacktrace: ", Log.getStackTraceString(th11)));
                                }
                            }
                            cVar.g(T16);
                            return;
                        case 11:
                            C0345i c0345i13 = c0345i;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list12 = (List) obj;
                            Object obj23 = list12.get(0);
                            q5.h.c(obj23, "null cannot be cast to non-null type android.webkit.WebSettings");
                            WebSettings webSettings12 = (WebSettings) obj23;
                            Object obj24 = list12.get(1);
                            q5.h.c(obj24, "null cannot be cast to non-null type kotlin.Boolean");
                            boolean booleanValue11 = ((Boolean) obj24).booleanValue();
                            try {
                                c0345i13.getClass();
                                webSettings12.setGeolocationEnabled(booleanValue11);
                                T17 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th12) {
                                if (th12 instanceof C0337a) {
                                    C0337a c0337a12 = th12;
                                    T17 = h5.e.T(c0337a12.o, c0337a12.f5592p, c0337a12.f5593q);
                                } else {
                                    T17 = h5.e.T(th12.getClass().getSimpleName(), th12.toString(), AbstractC0034i.k("Cause: ", th12.getCause(), ", Stacktrace: ", Log.getStackTraceString(th12)));
                                }
                            }
                            cVar.g(T17);
                            return;
                        case 12:
                            C0345i c0345i14 = c0345i;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list13 = (List) obj;
                            Object obj25 = list13.get(0);
                            q5.h.c(obj25, "null cannot be cast to non-null type android.webkit.WebSettings");
                            WebSettings webSettings13 = (WebSettings) obj25;
                            Object obj26 = list13.get(1);
                            q5.h.c(obj26, "null cannot be cast to non-null type kotlin.Long");
                            long longValue = ((Long) obj26).longValue();
                            try {
                                c0345i14.getClass();
                                webSettings13.setTextZoom((int) longValue);
                                T18 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th13) {
                                if (th13 instanceof C0337a) {
                                    C0337a c0337a13 = th13;
                                    T18 = h5.e.T(c0337a13.o, c0337a13.f5592p, c0337a13.f5593q);
                                } else {
                                    T18 = h5.e.T(th13.getClass().getSimpleName(), th13.toString(), AbstractC0034i.k("Cause: ", th13.getCause(), ", Stacktrace: ", Log.getStackTraceString(th13)));
                                }
                            }
                            cVar.g(T18);
                            return;
                        case 13:
                            C0345i c0345i15 = c0345i;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            Object obj27 = ((List) obj).get(0);
                            q5.h.c(obj27, "null cannot be cast to non-null type android.webkit.WebSettings");
                            WebSettings webSettings14 = (WebSettings) obj27;
                            try {
                                c0345i15.getClass();
                                T19 = android.support.v4.media.session.a.z(webSettings14.getUserAgentString());
                            } catch (Throwable th14) {
                                if (th14 instanceof C0337a) {
                                    C0337a c0337a14 = th14;
                                    T19 = h5.e.T(c0337a14.o, c0337a14.f5592p, c0337a14.f5593q);
                                } else {
                                    T19 = h5.e.T(th14.getClass().getSimpleName(), th14.toString(), AbstractC0034i.k("Cause: ", th14.getCause(), ", Stacktrace: ", Log.getStackTraceString(th14)));
                                }
                            }
                            cVar.g(T19);
                            return;
                        case 14:
                            C0345i c0345i16 = c0345i;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list14 = (List) obj;
                            Object obj28 = list14.get(0);
                            q5.h.c(obj28, "null cannot be cast to non-null type android.webkit.WebSettings");
                            WebSettings webSettings15 = (WebSettings) obj28;
                            Object obj29 = list14.get(1);
                            q5.h.c(obj29, "null cannot be cast to non-null type io.flutter.plugins.webviewflutter.MixedContentMode");
                            EnumC0359w enumC0359w = (EnumC0359w) obj29;
                            try {
                                c0345i16.getClass();
                                int ordinal = enumC0359w.ordinal();
                                if (ordinal != 0) {
                                    if (ordinal != 1) {
                                        if (ordinal == 2) {
                                            webSettings15.setMixedContentMode(1);
                                        }
                                    } else {
                                        webSettings15.setMixedContentMode(2);
                                    }
                                } else {
                                    webSettings15.setMixedContentMode(0);
                                }
                                T20 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th15) {
                                if (th15 instanceof C0337a) {
                                    C0337a c0337a15 = th15;
                                    T20 = h5.e.T(c0337a15.o, c0337a15.f5592p, c0337a15.f5593q);
                                } else {
                                    T20 = h5.e.T(th15.getClass().getSimpleName(), th15.toString(), AbstractC0034i.k("Cause: ", th15.getCause(), ", Stacktrace: ", Log.getStackTraceString(th15)));
                                }
                            }
                            cVar.g(T20);
                            return;
                        case 15:
                            C0345i c0345i17 = c0345i;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list15 = (List) obj;
                            Object obj30 = list15.get(0);
                            q5.h.c(obj30, "null cannot be cast to non-null type android.webkit.WebSettings");
                            WebSettings webSettings16 = (WebSettings) obj30;
                            Object obj31 = list15.get(1);
                            q5.h.c(obj31, "null cannot be cast to non-null type kotlin.Boolean");
                            boolean booleanValue12 = ((Boolean) obj31).booleanValue();
                            try {
                                c0345i17.getClass();
                                webSettings16.setJavaScriptCanOpenWindowsAutomatically(booleanValue12);
                                T21 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th16) {
                                if (th16 instanceof C0337a) {
                                    C0337a c0337a16 = th16;
                                    T21 = h5.e.T(c0337a16.o, c0337a16.f5592p, c0337a16.f5593q);
                                } else {
                                    T21 = h5.e.T(th16.getClass().getSimpleName(), th16.toString(), AbstractC0034i.k("Cause: ", th16.getCause(), ", Stacktrace: ", Log.getStackTraceString(th16)));
                                }
                            }
                            cVar.g(T21);
                            return;
                        default:
                            C0345i c0345i18 = c0345i;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list16 = (List) obj;
                            Object obj32 = list16.get(0);
                            q5.h.c(obj32, "null cannot be cast to non-null type android.webkit.WebSettings");
                            WebSettings webSettings17 = (WebSettings) obj32;
                            Object obj33 = list16.get(1);
                            q5.h.c(obj33, "null cannot be cast to non-null type kotlin.Boolean");
                            boolean booleanValue13 = ((Boolean) obj33).booleanValue();
                            try {
                                c0345i18.getClass();
                                webSettings17.setSupportMultipleWindows(booleanValue13);
                                T22 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th17) {
                                if (th17 instanceof C0337a) {
                                    C0337a c0337a17 = th17;
                                    T22 = h5.e.T(c0337a17.o, c0337a17.f5592p, c0337a17.f5593q);
                                } else {
                                    T22 = h5.e.T(th17.getClass().getSimpleName(), th17.toString(), AbstractC0034i.k("Cause: ", th17.getCause(), ", Stacktrace: ", Log.getStackTraceString(th17)));
                                }
                            }
                            cVar.g(T22);
                            return;
                    }
                }
            });
        } else {
            uVar15.y(null);
        }
        v3.u uVar16 = new v3.u(fVar, "dev.flutter.pigeon.webview_flutter_android.WebSettings.getUserAgentString", gVar, (C0508g) null);
        if (c0345i != null) {
            final int i21 = 13;
            uVar16.y(new b() { // from class: c5.J
                @Override // M4.b
                public final void e(Object obj, A.c cVar) {
                    List T6;
                    List T7;
                    List T8;
                    List T9;
                    List T10;
                    List T11;
                    List T12;
                    List T13;
                    List T14;
                    List T15;
                    List T16;
                    List T17;
                    List T18;
                    List T19;
                    List T20;
                    List T21;
                    List T22;
                    switch (i21) {
                        case 0:
                            C0345i c0345i2 = c0345i;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list = (List) obj;
                            Object obj2 = list.get(0);
                            q5.h.c(obj2, "null cannot be cast to non-null type android.webkit.WebSettings");
                            WebSettings webSettings = (WebSettings) obj2;
                            Object obj3 = list.get(1);
                            q5.h.c(obj3, "null cannot be cast to non-null type kotlin.Boolean");
                            boolean booleanValue = ((Boolean) obj3).booleanValue();
                            try {
                                c0345i2.getClass();
                                webSettings.setDomStorageEnabled(booleanValue);
                                T6 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th) {
                                if (th instanceof C0337a) {
                                    C0337a c0337a = th;
                                    T6 = h5.e.T(c0337a.o, c0337a.f5592p, c0337a.f5593q);
                                } else {
                                    T6 = h5.e.T(th.getClass().getSimpleName(), th.toString(), AbstractC0034i.k("Cause: ", th.getCause(), ", Stacktrace: ", Log.getStackTraceString(th)));
                                }
                            }
                            cVar.g(T6);
                            return;
                        case 1:
                            C0345i c0345i3 = c0345i;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list2 = (List) obj;
                            Object obj4 = list2.get(0);
                            q5.h.c(obj4, "null cannot be cast to non-null type android.webkit.WebSettings");
                            WebSettings webSettings2 = (WebSettings) obj4;
                            Object obj5 = list2.get(1);
                            q5.h.c(obj5, "null cannot be cast to non-null type kotlin.Boolean");
                            boolean booleanValue2 = ((Boolean) obj5).booleanValue();
                            try {
                                c0345i3.getClass();
                                webSettings2.setJavaScriptEnabled(booleanValue2);
                                T7 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th2) {
                                if (th2 instanceof C0337a) {
                                    C0337a c0337a2 = th2;
                                    T7 = h5.e.T(c0337a2.o, c0337a2.f5592p, c0337a2.f5593q);
                                } else {
                                    T7 = h5.e.T(th2.getClass().getSimpleName(), th2.toString(), AbstractC0034i.k("Cause: ", th2.getCause(), ", Stacktrace: ", Log.getStackTraceString(th2)));
                                }
                            }
                            cVar.g(T7);
                            return;
                        case 2:
                            C0345i c0345i4 = c0345i;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list3 = (List) obj;
                            Object obj6 = list3.get(0);
                            q5.h.c(obj6, "null cannot be cast to non-null type android.webkit.WebSettings");
                            WebSettings webSettings3 = (WebSettings) obj6;
                            String str = (String) list3.get(1);
                            try {
                                c0345i4.getClass();
                                webSettings3.setUserAgentString(str);
                                T8 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th3) {
                                if (th3 instanceof C0337a) {
                                    C0337a c0337a3 = th3;
                                    T8 = h5.e.T(c0337a3.o, c0337a3.f5592p, c0337a3.f5593q);
                                } else {
                                    T8 = h5.e.T(th3.getClass().getSimpleName(), th3.toString(), AbstractC0034i.k("Cause: ", th3.getCause(), ", Stacktrace: ", Log.getStackTraceString(th3)));
                                }
                            }
                            cVar.g(T8);
                            return;
                        case 3:
                            C0345i c0345i5 = c0345i;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list4 = (List) obj;
                            Object obj7 = list4.get(0);
                            q5.h.c(obj7, "null cannot be cast to non-null type android.webkit.WebSettings");
                            WebSettings webSettings4 = (WebSettings) obj7;
                            Object obj8 = list4.get(1);
                            q5.h.c(obj8, "null cannot be cast to non-null type kotlin.Boolean");
                            boolean booleanValue3 = ((Boolean) obj8).booleanValue();
                            try {
                                c0345i5.getClass();
                                webSettings4.setMediaPlaybackRequiresUserGesture(booleanValue3);
                                T9 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th4) {
                                if (th4 instanceof C0337a) {
                                    C0337a c0337a4 = th4;
                                    T9 = h5.e.T(c0337a4.o, c0337a4.f5592p, c0337a4.f5593q);
                                } else {
                                    T9 = h5.e.T(th4.getClass().getSimpleName(), th4.toString(), AbstractC0034i.k("Cause: ", th4.getCause(), ", Stacktrace: ", Log.getStackTraceString(th4)));
                                }
                            }
                            cVar.g(T9);
                            return;
                        case 4:
                            C0345i c0345i6 = c0345i;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list5 = (List) obj;
                            Object obj9 = list5.get(0);
                            q5.h.c(obj9, "null cannot be cast to non-null type android.webkit.WebSettings");
                            WebSettings webSettings5 = (WebSettings) obj9;
                            Object obj10 = list5.get(1);
                            q5.h.c(obj10, "null cannot be cast to non-null type kotlin.Boolean");
                            boolean booleanValue4 = ((Boolean) obj10).booleanValue();
                            try {
                                c0345i6.getClass();
                                webSettings5.setSupportZoom(booleanValue4);
                                T10 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th5) {
                                if (th5 instanceof C0337a) {
                                    C0337a c0337a5 = th5;
                                    T10 = h5.e.T(c0337a5.o, c0337a5.f5592p, c0337a5.f5593q);
                                } else {
                                    T10 = h5.e.T(th5.getClass().getSimpleName(), th5.toString(), AbstractC0034i.k("Cause: ", th5.getCause(), ", Stacktrace: ", Log.getStackTraceString(th5)));
                                }
                            }
                            cVar.g(T10);
                            return;
                        case 5:
                            C0345i c0345i7 = c0345i;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list6 = (List) obj;
                            Object obj11 = list6.get(0);
                            q5.h.c(obj11, "null cannot be cast to non-null type android.webkit.WebSettings");
                            WebSettings webSettings6 = (WebSettings) obj11;
                            Object obj12 = list6.get(1);
                            q5.h.c(obj12, "null cannot be cast to non-null type kotlin.Boolean");
                            boolean booleanValue5 = ((Boolean) obj12).booleanValue();
                            try {
                                c0345i7.getClass();
                                webSettings6.setLoadWithOverviewMode(booleanValue5);
                                T11 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th6) {
                                if (th6 instanceof C0337a) {
                                    C0337a c0337a6 = th6;
                                    T11 = h5.e.T(c0337a6.o, c0337a6.f5592p, c0337a6.f5593q);
                                } else {
                                    T11 = h5.e.T(th6.getClass().getSimpleName(), th6.toString(), AbstractC0034i.k("Cause: ", th6.getCause(), ", Stacktrace: ", Log.getStackTraceString(th6)));
                                }
                            }
                            cVar.g(T11);
                            return;
                        case 6:
                            C0345i c0345i8 = c0345i;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list7 = (List) obj;
                            Object obj13 = list7.get(0);
                            q5.h.c(obj13, "null cannot be cast to non-null type android.webkit.WebSettings");
                            WebSettings webSettings7 = (WebSettings) obj13;
                            Object obj14 = list7.get(1);
                            q5.h.c(obj14, "null cannot be cast to non-null type kotlin.Boolean");
                            boolean booleanValue6 = ((Boolean) obj14).booleanValue();
                            try {
                                c0345i8.getClass();
                                webSettings7.setUseWideViewPort(booleanValue6);
                                T12 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th7) {
                                if (th7 instanceof C0337a) {
                                    C0337a c0337a7 = th7;
                                    T12 = h5.e.T(c0337a7.o, c0337a7.f5592p, c0337a7.f5593q);
                                } else {
                                    T12 = h5.e.T(th7.getClass().getSimpleName(), th7.toString(), AbstractC0034i.k("Cause: ", th7.getCause(), ", Stacktrace: ", Log.getStackTraceString(th7)));
                                }
                            }
                            cVar.g(T12);
                            return;
                        case 7:
                            C0345i c0345i9 = c0345i;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list8 = (List) obj;
                            Object obj15 = list8.get(0);
                            q5.h.c(obj15, "null cannot be cast to non-null type android.webkit.WebSettings");
                            WebSettings webSettings8 = (WebSettings) obj15;
                            Object obj16 = list8.get(1);
                            q5.h.c(obj16, "null cannot be cast to non-null type kotlin.Boolean");
                            boolean booleanValue7 = ((Boolean) obj16).booleanValue();
                            try {
                                c0345i9.getClass();
                                webSettings8.setDisplayZoomControls(booleanValue7);
                                T13 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th8) {
                                if (th8 instanceof C0337a) {
                                    C0337a c0337a8 = th8;
                                    T13 = h5.e.T(c0337a8.o, c0337a8.f5592p, c0337a8.f5593q);
                                } else {
                                    T13 = h5.e.T(th8.getClass().getSimpleName(), th8.toString(), AbstractC0034i.k("Cause: ", th8.getCause(), ", Stacktrace: ", Log.getStackTraceString(th8)));
                                }
                            }
                            cVar.g(T13);
                            return;
                        case 8:
                            C0345i c0345i10 = c0345i;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list9 = (List) obj;
                            Object obj17 = list9.get(0);
                            q5.h.c(obj17, "null cannot be cast to non-null type android.webkit.WebSettings");
                            WebSettings webSettings9 = (WebSettings) obj17;
                            Object obj18 = list9.get(1);
                            q5.h.c(obj18, "null cannot be cast to non-null type kotlin.Boolean");
                            boolean booleanValue8 = ((Boolean) obj18).booleanValue();
                            try {
                                c0345i10.getClass();
                                webSettings9.setBuiltInZoomControls(booleanValue8);
                                T14 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th9) {
                                if (th9 instanceof C0337a) {
                                    C0337a c0337a9 = th9;
                                    T14 = h5.e.T(c0337a9.o, c0337a9.f5592p, c0337a9.f5593q);
                                } else {
                                    T14 = h5.e.T(th9.getClass().getSimpleName(), th9.toString(), AbstractC0034i.k("Cause: ", th9.getCause(), ", Stacktrace: ", Log.getStackTraceString(th9)));
                                }
                            }
                            cVar.g(T14);
                            return;
                        case ContentHandlerProxy.PROCESSING_INSTRUCTION /* 9 */:
                            C0345i c0345i11 = c0345i;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list10 = (List) obj;
                            Object obj19 = list10.get(0);
                            q5.h.c(obj19, "null cannot be cast to non-null type android.webkit.WebSettings");
                            WebSettings webSettings10 = (WebSettings) obj19;
                            Object obj20 = list10.get(1);
                            q5.h.c(obj20, "null cannot be cast to non-null type kotlin.Boolean");
                            boolean booleanValue9 = ((Boolean) obj20).booleanValue();
                            try {
                                c0345i11.getClass();
                                webSettings10.setAllowFileAccess(booleanValue9);
                                T15 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th10) {
                                if (th10 instanceof C0337a) {
                                    C0337a c0337a10 = th10;
                                    T15 = h5.e.T(c0337a10.o, c0337a10.f5592p, c0337a10.f5593q);
                                } else {
                                    T15 = h5.e.T(th10.getClass().getSimpleName(), th10.toString(), AbstractC0034i.k("Cause: ", th10.getCause(), ", Stacktrace: ", Log.getStackTraceString(th10)));
                                }
                            }
                            cVar.g(T15);
                            return;
                        case 10:
                            C0345i c0345i12 = c0345i;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list11 = (List) obj;
                            Object obj21 = list11.get(0);
                            q5.h.c(obj21, "null cannot be cast to non-null type android.webkit.WebSettings");
                            WebSettings webSettings11 = (WebSettings) obj21;
                            Object obj22 = list11.get(1);
                            q5.h.c(obj22, "null cannot be cast to non-null type kotlin.Boolean");
                            boolean booleanValue10 = ((Boolean) obj22).booleanValue();
                            try {
                                c0345i12.getClass();
                                webSettings11.setAllowContentAccess(booleanValue10);
                                T16 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th11) {
                                if (th11 instanceof C0337a) {
                                    C0337a c0337a11 = th11;
                                    T16 = h5.e.T(c0337a11.o, c0337a11.f5592p, c0337a11.f5593q);
                                } else {
                                    T16 = h5.e.T(th11.getClass().getSimpleName(), th11.toString(), AbstractC0034i.k("Cause: ", th11.getCause(), ", Stacktrace: ", Log.getStackTraceString(th11)));
                                }
                            }
                            cVar.g(T16);
                            return;
                        case 11:
                            C0345i c0345i13 = c0345i;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list12 = (List) obj;
                            Object obj23 = list12.get(0);
                            q5.h.c(obj23, "null cannot be cast to non-null type android.webkit.WebSettings");
                            WebSettings webSettings12 = (WebSettings) obj23;
                            Object obj24 = list12.get(1);
                            q5.h.c(obj24, "null cannot be cast to non-null type kotlin.Boolean");
                            boolean booleanValue11 = ((Boolean) obj24).booleanValue();
                            try {
                                c0345i13.getClass();
                                webSettings12.setGeolocationEnabled(booleanValue11);
                                T17 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th12) {
                                if (th12 instanceof C0337a) {
                                    C0337a c0337a12 = th12;
                                    T17 = h5.e.T(c0337a12.o, c0337a12.f5592p, c0337a12.f5593q);
                                } else {
                                    T17 = h5.e.T(th12.getClass().getSimpleName(), th12.toString(), AbstractC0034i.k("Cause: ", th12.getCause(), ", Stacktrace: ", Log.getStackTraceString(th12)));
                                }
                            }
                            cVar.g(T17);
                            return;
                        case 12:
                            C0345i c0345i14 = c0345i;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list13 = (List) obj;
                            Object obj25 = list13.get(0);
                            q5.h.c(obj25, "null cannot be cast to non-null type android.webkit.WebSettings");
                            WebSettings webSettings13 = (WebSettings) obj25;
                            Object obj26 = list13.get(1);
                            q5.h.c(obj26, "null cannot be cast to non-null type kotlin.Long");
                            long longValue = ((Long) obj26).longValue();
                            try {
                                c0345i14.getClass();
                                webSettings13.setTextZoom((int) longValue);
                                T18 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th13) {
                                if (th13 instanceof C0337a) {
                                    C0337a c0337a13 = th13;
                                    T18 = h5.e.T(c0337a13.o, c0337a13.f5592p, c0337a13.f5593q);
                                } else {
                                    T18 = h5.e.T(th13.getClass().getSimpleName(), th13.toString(), AbstractC0034i.k("Cause: ", th13.getCause(), ", Stacktrace: ", Log.getStackTraceString(th13)));
                                }
                            }
                            cVar.g(T18);
                            return;
                        case 13:
                            C0345i c0345i15 = c0345i;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            Object obj27 = ((List) obj).get(0);
                            q5.h.c(obj27, "null cannot be cast to non-null type android.webkit.WebSettings");
                            WebSettings webSettings14 = (WebSettings) obj27;
                            try {
                                c0345i15.getClass();
                                T19 = android.support.v4.media.session.a.z(webSettings14.getUserAgentString());
                            } catch (Throwable th14) {
                                if (th14 instanceof C0337a) {
                                    C0337a c0337a14 = th14;
                                    T19 = h5.e.T(c0337a14.o, c0337a14.f5592p, c0337a14.f5593q);
                                } else {
                                    T19 = h5.e.T(th14.getClass().getSimpleName(), th14.toString(), AbstractC0034i.k("Cause: ", th14.getCause(), ", Stacktrace: ", Log.getStackTraceString(th14)));
                                }
                            }
                            cVar.g(T19);
                            return;
                        case 14:
                            C0345i c0345i16 = c0345i;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list14 = (List) obj;
                            Object obj28 = list14.get(0);
                            q5.h.c(obj28, "null cannot be cast to non-null type android.webkit.WebSettings");
                            WebSettings webSettings15 = (WebSettings) obj28;
                            Object obj29 = list14.get(1);
                            q5.h.c(obj29, "null cannot be cast to non-null type io.flutter.plugins.webviewflutter.MixedContentMode");
                            EnumC0359w enumC0359w = (EnumC0359w) obj29;
                            try {
                                c0345i16.getClass();
                                int ordinal = enumC0359w.ordinal();
                                if (ordinal != 0) {
                                    if (ordinal != 1) {
                                        if (ordinal == 2) {
                                            webSettings15.setMixedContentMode(1);
                                        }
                                    } else {
                                        webSettings15.setMixedContentMode(2);
                                    }
                                } else {
                                    webSettings15.setMixedContentMode(0);
                                }
                                T20 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th15) {
                                if (th15 instanceof C0337a) {
                                    C0337a c0337a15 = th15;
                                    T20 = h5.e.T(c0337a15.o, c0337a15.f5592p, c0337a15.f5593q);
                                } else {
                                    T20 = h5.e.T(th15.getClass().getSimpleName(), th15.toString(), AbstractC0034i.k("Cause: ", th15.getCause(), ", Stacktrace: ", Log.getStackTraceString(th15)));
                                }
                            }
                            cVar.g(T20);
                            return;
                        case 15:
                            C0345i c0345i17 = c0345i;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list15 = (List) obj;
                            Object obj30 = list15.get(0);
                            q5.h.c(obj30, "null cannot be cast to non-null type android.webkit.WebSettings");
                            WebSettings webSettings16 = (WebSettings) obj30;
                            Object obj31 = list15.get(1);
                            q5.h.c(obj31, "null cannot be cast to non-null type kotlin.Boolean");
                            boolean booleanValue12 = ((Boolean) obj31).booleanValue();
                            try {
                                c0345i17.getClass();
                                webSettings16.setJavaScriptCanOpenWindowsAutomatically(booleanValue12);
                                T21 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th16) {
                                if (th16 instanceof C0337a) {
                                    C0337a c0337a16 = th16;
                                    T21 = h5.e.T(c0337a16.o, c0337a16.f5592p, c0337a16.f5593q);
                                } else {
                                    T21 = h5.e.T(th16.getClass().getSimpleName(), th16.toString(), AbstractC0034i.k("Cause: ", th16.getCause(), ", Stacktrace: ", Log.getStackTraceString(th16)));
                                }
                            }
                            cVar.g(T21);
                            return;
                        default:
                            C0345i c0345i18 = c0345i;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list16 = (List) obj;
                            Object obj32 = list16.get(0);
                            q5.h.c(obj32, "null cannot be cast to non-null type android.webkit.WebSettings");
                            WebSettings webSettings17 = (WebSettings) obj32;
                            Object obj33 = list16.get(1);
                            q5.h.c(obj33, "null cannot be cast to non-null type kotlin.Boolean");
                            boolean booleanValue13 = ((Boolean) obj33).booleanValue();
                            try {
                                c0345i18.getClass();
                                webSettings17.setSupportMultipleWindows(booleanValue13);
                                T22 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th17) {
                                if (th17 instanceof C0337a) {
                                    C0337a c0337a17 = th17;
                                    T22 = h5.e.T(c0337a17.o, c0337a17.f5592p, c0337a17.f5593q);
                                } else {
                                    T22 = h5.e.T(th17.getClass().getSimpleName(), th17.toString(), AbstractC0034i.k("Cause: ", th17.getCause(), ", Stacktrace: ", Log.getStackTraceString(th17)));
                                }
                            }
                            cVar.g(T22);
                            return;
                    }
                }
            });
        } else {
            uVar16.y(null);
        }
        v3.u uVar17 = new v3.u(fVar, "dev.flutter.pigeon.webview_flutter_android.WebSettings.setMixedContentMode", gVar, (C0508g) null);
        if (c0345i != null) {
            final int i22 = 14;
            uVar17.y(new b() { // from class: c5.J
                @Override // M4.b
                public final void e(Object obj, A.c cVar) {
                    List T6;
                    List T7;
                    List T8;
                    List T9;
                    List T10;
                    List T11;
                    List T12;
                    List T13;
                    List T14;
                    List T15;
                    List T16;
                    List T17;
                    List T18;
                    List T19;
                    List T20;
                    List T21;
                    List T22;
                    switch (i22) {
                        case 0:
                            C0345i c0345i2 = c0345i;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list = (List) obj;
                            Object obj2 = list.get(0);
                            q5.h.c(obj2, "null cannot be cast to non-null type android.webkit.WebSettings");
                            WebSettings webSettings = (WebSettings) obj2;
                            Object obj3 = list.get(1);
                            q5.h.c(obj3, "null cannot be cast to non-null type kotlin.Boolean");
                            boolean booleanValue = ((Boolean) obj3).booleanValue();
                            try {
                                c0345i2.getClass();
                                webSettings.setDomStorageEnabled(booleanValue);
                                T6 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th) {
                                if (th instanceof C0337a) {
                                    C0337a c0337a = th;
                                    T6 = h5.e.T(c0337a.o, c0337a.f5592p, c0337a.f5593q);
                                } else {
                                    T6 = h5.e.T(th.getClass().getSimpleName(), th.toString(), AbstractC0034i.k("Cause: ", th.getCause(), ", Stacktrace: ", Log.getStackTraceString(th)));
                                }
                            }
                            cVar.g(T6);
                            return;
                        case 1:
                            C0345i c0345i3 = c0345i;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list2 = (List) obj;
                            Object obj4 = list2.get(0);
                            q5.h.c(obj4, "null cannot be cast to non-null type android.webkit.WebSettings");
                            WebSettings webSettings2 = (WebSettings) obj4;
                            Object obj5 = list2.get(1);
                            q5.h.c(obj5, "null cannot be cast to non-null type kotlin.Boolean");
                            boolean booleanValue2 = ((Boolean) obj5).booleanValue();
                            try {
                                c0345i3.getClass();
                                webSettings2.setJavaScriptEnabled(booleanValue2);
                                T7 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th2) {
                                if (th2 instanceof C0337a) {
                                    C0337a c0337a2 = th2;
                                    T7 = h5.e.T(c0337a2.o, c0337a2.f5592p, c0337a2.f5593q);
                                } else {
                                    T7 = h5.e.T(th2.getClass().getSimpleName(), th2.toString(), AbstractC0034i.k("Cause: ", th2.getCause(), ", Stacktrace: ", Log.getStackTraceString(th2)));
                                }
                            }
                            cVar.g(T7);
                            return;
                        case 2:
                            C0345i c0345i4 = c0345i;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list3 = (List) obj;
                            Object obj6 = list3.get(0);
                            q5.h.c(obj6, "null cannot be cast to non-null type android.webkit.WebSettings");
                            WebSettings webSettings3 = (WebSettings) obj6;
                            String str = (String) list3.get(1);
                            try {
                                c0345i4.getClass();
                                webSettings3.setUserAgentString(str);
                                T8 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th3) {
                                if (th3 instanceof C0337a) {
                                    C0337a c0337a3 = th3;
                                    T8 = h5.e.T(c0337a3.o, c0337a3.f5592p, c0337a3.f5593q);
                                } else {
                                    T8 = h5.e.T(th3.getClass().getSimpleName(), th3.toString(), AbstractC0034i.k("Cause: ", th3.getCause(), ", Stacktrace: ", Log.getStackTraceString(th3)));
                                }
                            }
                            cVar.g(T8);
                            return;
                        case 3:
                            C0345i c0345i5 = c0345i;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list4 = (List) obj;
                            Object obj7 = list4.get(0);
                            q5.h.c(obj7, "null cannot be cast to non-null type android.webkit.WebSettings");
                            WebSettings webSettings4 = (WebSettings) obj7;
                            Object obj8 = list4.get(1);
                            q5.h.c(obj8, "null cannot be cast to non-null type kotlin.Boolean");
                            boolean booleanValue3 = ((Boolean) obj8).booleanValue();
                            try {
                                c0345i5.getClass();
                                webSettings4.setMediaPlaybackRequiresUserGesture(booleanValue3);
                                T9 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th4) {
                                if (th4 instanceof C0337a) {
                                    C0337a c0337a4 = th4;
                                    T9 = h5.e.T(c0337a4.o, c0337a4.f5592p, c0337a4.f5593q);
                                } else {
                                    T9 = h5.e.T(th4.getClass().getSimpleName(), th4.toString(), AbstractC0034i.k("Cause: ", th4.getCause(), ", Stacktrace: ", Log.getStackTraceString(th4)));
                                }
                            }
                            cVar.g(T9);
                            return;
                        case 4:
                            C0345i c0345i6 = c0345i;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list5 = (List) obj;
                            Object obj9 = list5.get(0);
                            q5.h.c(obj9, "null cannot be cast to non-null type android.webkit.WebSettings");
                            WebSettings webSettings5 = (WebSettings) obj9;
                            Object obj10 = list5.get(1);
                            q5.h.c(obj10, "null cannot be cast to non-null type kotlin.Boolean");
                            boolean booleanValue4 = ((Boolean) obj10).booleanValue();
                            try {
                                c0345i6.getClass();
                                webSettings5.setSupportZoom(booleanValue4);
                                T10 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th5) {
                                if (th5 instanceof C0337a) {
                                    C0337a c0337a5 = th5;
                                    T10 = h5.e.T(c0337a5.o, c0337a5.f5592p, c0337a5.f5593q);
                                } else {
                                    T10 = h5.e.T(th5.getClass().getSimpleName(), th5.toString(), AbstractC0034i.k("Cause: ", th5.getCause(), ", Stacktrace: ", Log.getStackTraceString(th5)));
                                }
                            }
                            cVar.g(T10);
                            return;
                        case 5:
                            C0345i c0345i7 = c0345i;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list6 = (List) obj;
                            Object obj11 = list6.get(0);
                            q5.h.c(obj11, "null cannot be cast to non-null type android.webkit.WebSettings");
                            WebSettings webSettings6 = (WebSettings) obj11;
                            Object obj12 = list6.get(1);
                            q5.h.c(obj12, "null cannot be cast to non-null type kotlin.Boolean");
                            boolean booleanValue5 = ((Boolean) obj12).booleanValue();
                            try {
                                c0345i7.getClass();
                                webSettings6.setLoadWithOverviewMode(booleanValue5);
                                T11 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th6) {
                                if (th6 instanceof C0337a) {
                                    C0337a c0337a6 = th6;
                                    T11 = h5.e.T(c0337a6.o, c0337a6.f5592p, c0337a6.f5593q);
                                } else {
                                    T11 = h5.e.T(th6.getClass().getSimpleName(), th6.toString(), AbstractC0034i.k("Cause: ", th6.getCause(), ", Stacktrace: ", Log.getStackTraceString(th6)));
                                }
                            }
                            cVar.g(T11);
                            return;
                        case 6:
                            C0345i c0345i8 = c0345i;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list7 = (List) obj;
                            Object obj13 = list7.get(0);
                            q5.h.c(obj13, "null cannot be cast to non-null type android.webkit.WebSettings");
                            WebSettings webSettings7 = (WebSettings) obj13;
                            Object obj14 = list7.get(1);
                            q5.h.c(obj14, "null cannot be cast to non-null type kotlin.Boolean");
                            boolean booleanValue6 = ((Boolean) obj14).booleanValue();
                            try {
                                c0345i8.getClass();
                                webSettings7.setUseWideViewPort(booleanValue6);
                                T12 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th7) {
                                if (th7 instanceof C0337a) {
                                    C0337a c0337a7 = th7;
                                    T12 = h5.e.T(c0337a7.o, c0337a7.f5592p, c0337a7.f5593q);
                                } else {
                                    T12 = h5.e.T(th7.getClass().getSimpleName(), th7.toString(), AbstractC0034i.k("Cause: ", th7.getCause(), ", Stacktrace: ", Log.getStackTraceString(th7)));
                                }
                            }
                            cVar.g(T12);
                            return;
                        case 7:
                            C0345i c0345i9 = c0345i;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list8 = (List) obj;
                            Object obj15 = list8.get(0);
                            q5.h.c(obj15, "null cannot be cast to non-null type android.webkit.WebSettings");
                            WebSettings webSettings8 = (WebSettings) obj15;
                            Object obj16 = list8.get(1);
                            q5.h.c(obj16, "null cannot be cast to non-null type kotlin.Boolean");
                            boolean booleanValue7 = ((Boolean) obj16).booleanValue();
                            try {
                                c0345i9.getClass();
                                webSettings8.setDisplayZoomControls(booleanValue7);
                                T13 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th8) {
                                if (th8 instanceof C0337a) {
                                    C0337a c0337a8 = th8;
                                    T13 = h5.e.T(c0337a8.o, c0337a8.f5592p, c0337a8.f5593q);
                                } else {
                                    T13 = h5.e.T(th8.getClass().getSimpleName(), th8.toString(), AbstractC0034i.k("Cause: ", th8.getCause(), ", Stacktrace: ", Log.getStackTraceString(th8)));
                                }
                            }
                            cVar.g(T13);
                            return;
                        case 8:
                            C0345i c0345i10 = c0345i;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list9 = (List) obj;
                            Object obj17 = list9.get(0);
                            q5.h.c(obj17, "null cannot be cast to non-null type android.webkit.WebSettings");
                            WebSettings webSettings9 = (WebSettings) obj17;
                            Object obj18 = list9.get(1);
                            q5.h.c(obj18, "null cannot be cast to non-null type kotlin.Boolean");
                            boolean booleanValue8 = ((Boolean) obj18).booleanValue();
                            try {
                                c0345i10.getClass();
                                webSettings9.setBuiltInZoomControls(booleanValue8);
                                T14 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th9) {
                                if (th9 instanceof C0337a) {
                                    C0337a c0337a9 = th9;
                                    T14 = h5.e.T(c0337a9.o, c0337a9.f5592p, c0337a9.f5593q);
                                } else {
                                    T14 = h5.e.T(th9.getClass().getSimpleName(), th9.toString(), AbstractC0034i.k("Cause: ", th9.getCause(), ", Stacktrace: ", Log.getStackTraceString(th9)));
                                }
                            }
                            cVar.g(T14);
                            return;
                        case ContentHandlerProxy.PROCESSING_INSTRUCTION /* 9 */:
                            C0345i c0345i11 = c0345i;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list10 = (List) obj;
                            Object obj19 = list10.get(0);
                            q5.h.c(obj19, "null cannot be cast to non-null type android.webkit.WebSettings");
                            WebSettings webSettings10 = (WebSettings) obj19;
                            Object obj20 = list10.get(1);
                            q5.h.c(obj20, "null cannot be cast to non-null type kotlin.Boolean");
                            boolean booleanValue9 = ((Boolean) obj20).booleanValue();
                            try {
                                c0345i11.getClass();
                                webSettings10.setAllowFileAccess(booleanValue9);
                                T15 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th10) {
                                if (th10 instanceof C0337a) {
                                    C0337a c0337a10 = th10;
                                    T15 = h5.e.T(c0337a10.o, c0337a10.f5592p, c0337a10.f5593q);
                                } else {
                                    T15 = h5.e.T(th10.getClass().getSimpleName(), th10.toString(), AbstractC0034i.k("Cause: ", th10.getCause(), ", Stacktrace: ", Log.getStackTraceString(th10)));
                                }
                            }
                            cVar.g(T15);
                            return;
                        case 10:
                            C0345i c0345i12 = c0345i;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list11 = (List) obj;
                            Object obj21 = list11.get(0);
                            q5.h.c(obj21, "null cannot be cast to non-null type android.webkit.WebSettings");
                            WebSettings webSettings11 = (WebSettings) obj21;
                            Object obj22 = list11.get(1);
                            q5.h.c(obj22, "null cannot be cast to non-null type kotlin.Boolean");
                            boolean booleanValue10 = ((Boolean) obj22).booleanValue();
                            try {
                                c0345i12.getClass();
                                webSettings11.setAllowContentAccess(booleanValue10);
                                T16 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th11) {
                                if (th11 instanceof C0337a) {
                                    C0337a c0337a11 = th11;
                                    T16 = h5.e.T(c0337a11.o, c0337a11.f5592p, c0337a11.f5593q);
                                } else {
                                    T16 = h5.e.T(th11.getClass().getSimpleName(), th11.toString(), AbstractC0034i.k("Cause: ", th11.getCause(), ", Stacktrace: ", Log.getStackTraceString(th11)));
                                }
                            }
                            cVar.g(T16);
                            return;
                        case 11:
                            C0345i c0345i13 = c0345i;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list12 = (List) obj;
                            Object obj23 = list12.get(0);
                            q5.h.c(obj23, "null cannot be cast to non-null type android.webkit.WebSettings");
                            WebSettings webSettings12 = (WebSettings) obj23;
                            Object obj24 = list12.get(1);
                            q5.h.c(obj24, "null cannot be cast to non-null type kotlin.Boolean");
                            boolean booleanValue11 = ((Boolean) obj24).booleanValue();
                            try {
                                c0345i13.getClass();
                                webSettings12.setGeolocationEnabled(booleanValue11);
                                T17 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th12) {
                                if (th12 instanceof C0337a) {
                                    C0337a c0337a12 = th12;
                                    T17 = h5.e.T(c0337a12.o, c0337a12.f5592p, c0337a12.f5593q);
                                } else {
                                    T17 = h5.e.T(th12.getClass().getSimpleName(), th12.toString(), AbstractC0034i.k("Cause: ", th12.getCause(), ", Stacktrace: ", Log.getStackTraceString(th12)));
                                }
                            }
                            cVar.g(T17);
                            return;
                        case 12:
                            C0345i c0345i14 = c0345i;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list13 = (List) obj;
                            Object obj25 = list13.get(0);
                            q5.h.c(obj25, "null cannot be cast to non-null type android.webkit.WebSettings");
                            WebSettings webSettings13 = (WebSettings) obj25;
                            Object obj26 = list13.get(1);
                            q5.h.c(obj26, "null cannot be cast to non-null type kotlin.Long");
                            long longValue = ((Long) obj26).longValue();
                            try {
                                c0345i14.getClass();
                                webSettings13.setTextZoom((int) longValue);
                                T18 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th13) {
                                if (th13 instanceof C0337a) {
                                    C0337a c0337a13 = th13;
                                    T18 = h5.e.T(c0337a13.o, c0337a13.f5592p, c0337a13.f5593q);
                                } else {
                                    T18 = h5.e.T(th13.getClass().getSimpleName(), th13.toString(), AbstractC0034i.k("Cause: ", th13.getCause(), ", Stacktrace: ", Log.getStackTraceString(th13)));
                                }
                            }
                            cVar.g(T18);
                            return;
                        case 13:
                            C0345i c0345i15 = c0345i;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            Object obj27 = ((List) obj).get(0);
                            q5.h.c(obj27, "null cannot be cast to non-null type android.webkit.WebSettings");
                            WebSettings webSettings14 = (WebSettings) obj27;
                            try {
                                c0345i15.getClass();
                                T19 = android.support.v4.media.session.a.z(webSettings14.getUserAgentString());
                            } catch (Throwable th14) {
                                if (th14 instanceof C0337a) {
                                    C0337a c0337a14 = th14;
                                    T19 = h5.e.T(c0337a14.o, c0337a14.f5592p, c0337a14.f5593q);
                                } else {
                                    T19 = h5.e.T(th14.getClass().getSimpleName(), th14.toString(), AbstractC0034i.k("Cause: ", th14.getCause(), ", Stacktrace: ", Log.getStackTraceString(th14)));
                                }
                            }
                            cVar.g(T19);
                            return;
                        case 14:
                            C0345i c0345i16 = c0345i;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list14 = (List) obj;
                            Object obj28 = list14.get(0);
                            q5.h.c(obj28, "null cannot be cast to non-null type android.webkit.WebSettings");
                            WebSettings webSettings15 = (WebSettings) obj28;
                            Object obj29 = list14.get(1);
                            q5.h.c(obj29, "null cannot be cast to non-null type io.flutter.plugins.webviewflutter.MixedContentMode");
                            EnumC0359w enumC0359w = (EnumC0359w) obj29;
                            try {
                                c0345i16.getClass();
                                int ordinal = enumC0359w.ordinal();
                                if (ordinal != 0) {
                                    if (ordinal != 1) {
                                        if (ordinal == 2) {
                                            webSettings15.setMixedContentMode(1);
                                        }
                                    } else {
                                        webSettings15.setMixedContentMode(2);
                                    }
                                } else {
                                    webSettings15.setMixedContentMode(0);
                                }
                                T20 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th15) {
                                if (th15 instanceof C0337a) {
                                    C0337a c0337a15 = th15;
                                    T20 = h5.e.T(c0337a15.o, c0337a15.f5592p, c0337a15.f5593q);
                                } else {
                                    T20 = h5.e.T(th15.getClass().getSimpleName(), th15.toString(), AbstractC0034i.k("Cause: ", th15.getCause(), ", Stacktrace: ", Log.getStackTraceString(th15)));
                                }
                            }
                            cVar.g(T20);
                            return;
                        case 15:
                            C0345i c0345i17 = c0345i;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list15 = (List) obj;
                            Object obj30 = list15.get(0);
                            q5.h.c(obj30, "null cannot be cast to non-null type android.webkit.WebSettings");
                            WebSettings webSettings16 = (WebSettings) obj30;
                            Object obj31 = list15.get(1);
                            q5.h.c(obj31, "null cannot be cast to non-null type kotlin.Boolean");
                            boolean booleanValue12 = ((Boolean) obj31).booleanValue();
                            try {
                                c0345i17.getClass();
                                webSettings16.setJavaScriptCanOpenWindowsAutomatically(booleanValue12);
                                T21 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th16) {
                                if (th16 instanceof C0337a) {
                                    C0337a c0337a16 = th16;
                                    T21 = h5.e.T(c0337a16.o, c0337a16.f5592p, c0337a16.f5593q);
                                } else {
                                    T21 = h5.e.T(th16.getClass().getSimpleName(), th16.toString(), AbstractC0034i.k("Cause: ", th16.getCause(), ", Stacktrace: ", Log.getStackTraceString(th16)));
                                }
                            }
                            cVar.g(T21);
                            return;
                        default:
                            C0345i c0345i18 = c0345i;
                            q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list16 = (List) obj;
                            Object obj32 = list16.get(0);
                            q5.h.c(obj32, "null cannot be cast to non-null type android.webkit.WebSettings");
                            WebSettings webSettings17 = (WebSettings) obj32;
                            Object obj33 = list16.get(1);
                            q5.h.c(obj33, "null cannot be cast to non-null type kotlin.Boolean");
                            boolean booleanValue13 = ((Boolean) obj33).booleanValue();
                            try {
                                c0345i18.getClass();
                                webSettings17.setSupportMultipleWindows(booleanValue13);
                                T22 = android.support.v4.media.session.a.z(null);
                            } catch (Throwable th17) {
                                if (th17 instanceof C0337a) {
                                    C0337a c0337a17 = th17;
                                    T22 = h5.e.T(c0337a17.o, c0337a17.f5592p, c0337a17.f5593q);
                                } else {
                                    T22 = h5.e.T(th17.getClass().getSimpleName(), th17.toString(), AbstractC0034i.k("Cause: ", th17.getCause(), ", Stacktrace: ", Log.getStackTraceString(th17)));
                                }
                            }
                            cVar.g(T22);
                            return;
                    }
                }
            });
        } else {
            uVar17.y(null);
        }
    }

    public static void H(u uVar) {
        uVar.t(3);
        uVar.t(8);
        boolean h6 = uVar.h();
        boolean h7 = uVar.h();
        if (h6) {
            uVar.t(5);
        }
        if (h7) {
            uVar.t(6);
        }
    }

    public static void I(u uVar) {
        int i6;
        int i7;
        int i8 = uVar.i(2);
        int i9 = 6;
        if (i8 == 0) {
            uVar.t(6);
            return;
        }
        int i10 = 5;
        int B6 = B(uVar, 5, 8, 16) + 1;
        if (i8 == 1) {
            uVar.t(B6 * 7);
            return;
        }
        if (i8 == 2) {
            boolean h6 = uVar.h();
            if (h6) {
                i6 = 1;
            } else {
                i6 = 5;
            }
            if (h6) {
                i10 = 7;
            }
            if (h6) {
                i9 = 8;
            }
            int i11 = 0;
            while (i11 < B6) {
                if (uVar.h()) {
                    uVar.t(7);
                    i7 = 0;
                } else {
                    if (uVar.i(2) == 3 && uVar.i(i10) * i6 != 0) {
                        uVar.s();
                    }
                    i7 = uVar.i(i9) * i6;
                    if (i7 != 0 && i7 != 180) {
                        uVar.s();
                    }
                    uVar.s();
                }
                if (i7 != 0 && i7 != 180 && uVar.h()) {
                    i11++;
                }
                i11++;
            }
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    public static void J(p pVar, AbstractC0894a abstractC0894a, AbstractC0894a abstractC0894a2) {
        try {
            C5.a.g(w(((AbstractC0560a) pVar).m(abstractC0894a2, abstractC0894a)), g5.h.f6800a);
        } catch (Throwable th) {
            abstractC0894a2.g(l(th));
            throw th;
        }
    }

    public static final void K(Object obj) {
        if (!(obj instanceof C0455d)) {
        } else {
            throw ((C0455d) obj).o;
        }
    }

    public static int[] L(Collection collection) {
        if (collection instanceof H2.b) {
            H2.b bVar = (H2.b) collection;
            return Arrays.copyOfRange(bVar.o, bVar.f1012p, bVar.f1013q);
        }
        Object[] array = collection.toArray();
        int length = array.length;
        int[] iArr = new int[length];
        for (int i6 = 0; i6 < length; i6++) {
            Object obj = array[i6];
            obj.getClass();
            iArr[i6] = ((Number) obj).intValue();
        }
        return iArr;
    }

    public static String M(String str) {
        int length = str.length();
        int i6 = 0;
        while (i6 < length) {
            char charAt = str.charAt(i6);
            if (charAt >= 'A' && charAt <= 'Z') {
                char[] charArray = str.toCharArray();
                while (i6 < length) {
                    char c6 = charArray[i6];
                    if (c6 >= 'A' && c6 <= 'Z') {
                        charArray[i6] = (char) (c6 ^ ' ');
                    }
                    i6++;
                }
                return String.valueOf(charArray);
            }
            i6++;
        }
        return str;
    }

    public static String N(String str) {
        int length = str.length();
        int i6 = 0;
        while (i6 < length) {
            char charAt = str.charAt(i6);
            if (charAt >= 'a' && charAt <= 'z') {
                char[] charArray = str.toCharArray();
                while (i6 < length) {
                    char c6 = charArray[i6];
                    if (c6 >= 'a' && c6 <= 'z') {
                        charArray[i6] = (char) (c6 ^ ' ');
                    }
                    i6++;
                }
                return String.valueOf(charArray);
            }
            i6++;
        }
        return str;
    }

    /* JADX WARN: Multi-variable type inference failed */
    public static Integer O(String str) {
        byte b6;
        Integer num;
        Long l6;
        byte b7;
        str.getClass();
        if (!str.isEmpty()) {
            int i6 = 0;
            if (str.charAt(0) == '-') {
                i6 = 1;
            }
            if (i6 != str.length()) {
                int i7 = i6 + 1;
                char charAt = str.charAt(i6);
                if (charAt < 128) {
                    b6 = c.f1014a[charAt];
                } else {
                    byte[] bArr = c.f1014a;
                    b6 = -1;
                }
                if (b6 >= 0 && b6 < 10) {
                    long j6 = -b6;
                    long j7 = 10;
                    long j8 = Long.MIN_VALUE / j7;
                    while (true) {
                        if (i7 < str.length()) {
                            int i8 = i7 + 1;
                            char charAt2 = str.charAt(i7);
                            if (charAt2 < 128) {
                                b7 = c.f1014a[charAt2];
                            } else {
                                byte[] bArr2 = c.f1014a;
                                b7 = -1;
                            }
                            if (b7 < 0 || b7 >= 10 || j6 < j8) {
                                break;
                            }
                            long j9 = j6 * j7;
                            num = null;
                            long j10 = b7;
                            if (j9 < j10 - Long.MIN_VALUE) {
                                break;
                            }
                            j6 = j9 - j10;
                            i7 = i8;
                        } else {
                            num = null;
                            if (i6 != 0) {
                                l6 = Long.valueOf(j6);
                            } else if (j6 != Long.MIN_VALUE) {
                                l6 = Long.valueOf(-j6);
                            }
                        }
                    }
                }
                num = null;
                l6 = num;
                if (l6 == 0 && l6.longValue() == l6.intValue()) {
                    return Integer.valueOf(l6.intValue());
                }
                return num;
            }
        }
        l6 = 0;
        num = null;
        if (l6 == 0) {
        }
        return num;
    }

    public static Object P(Object obj) {
        if (obj == null) {
            return JSONObject.NULL;
        }
        if (!(obj instanceof JSONArray)) {
            if (obj instanceof JSONObject) {
                return obj;
            }
            if (obj.equals(JSONObject.NULL)) {
                return obj;
            }
            if (obj instanceof Collection) {
                JSONArray jSONArray = new JSONArray();
                Iterator it = ((Collection) obj).iterator();
                while (it.hasNext()) {
                    jSONArray.put(P(it.next()));
                }
                return jSONArray;
            }
            if (obj.getClass().isArray()) {
                JSONArray jSONArray2 = new JSONArray();
                int length = Array.getLength(obj);
                for (int i6 = 0; i6 < length; i6++) {
                    jSONArray2.put(P(Array.get(obj, i6)));
                }
                return jSONArray2;
            }
            if (obj instanceof Map) {
                JSONObject jSONObject = new JSONObject();
                for (Map.Entry entry : ((Map) obj).entrySet()) {
                    jSONObject.put((String) entry.getKey(), P(entry.getValue()));
                }
                return jSONObject;
            }
            if (!(obj instanceof Boolean) && !(obj instanceof Byte) && !(obj instanceof Character) && !(obj instanceof Double) && !(obj instanceof Float) && !(obj instanceof Integer) && !(obj instanceof Long) && !(obj instanceof Short)) {
                if (obj instanceof String) {
                    return obj;
                }
                if (obj.getClass().getPackage().getName().startsWith("java.")) {
                    return obj.toString();
                }
                return null;
            }
            return obj;
        }
        return obj;
    }

    public static ArrayList Q(Throwable th) {
        ArrayList arrayList = new ArrayList(3);
        arrayList.add(th.toString());
        arrayList.add(th.getClass().getSimpleName());
        arrayList.add("Cause: " + th.getCause() + ", Stacktrace: " + Log.getStackTraceString(th));
        return arrayList;
    }

    public static ArrayList R(Throwable th) {
        ArrayList arrayList = new ArrayList(3);
        if (th instanceof n) {
            n nVar = (n) th;
            arrayList.add(nVar.o);
            arrayList.add(nVar.getMessage());
            arrayList.add(null);
            return arrayList;
        }
        arrayList.add(th.toString());
        arrayList.add(th.getClass().getSimpleName());
        arrayList.add("Cause: " + th.getCause() + ", Stacktrace: " + Log.getStackTraceString(th));
        return arrayList;
    }

    public static ArrayList S(Throwable th) {
        ArrayList arrayList = new ArrayList(3);
        arrayList.add(th.toString());
        arrayList.add(th.getClass().getSimpleName());
        arrayList.add("Cause: " + th.getCause() + ", Stacktrace: " + Log.getStackTraceString(th));
        return arrayList;
    }

    public static ArrayList T(Throwable th) {
        ArrayList arrayList = new ArrayList(3);
        arrayList.add(th.toString());
        arrayList.add(th.getClass().getSimpleName());
        arrayList.add("Cause: " + th.getCause() + ", Stacktrace: " + Log.getStackTraceString(th));
        return arrayList;
    }

    public static Object U(p pVar, Object obj, d dVar) {
        AbstractC0560a abstractC0562c;
        h.e(pVar, "<this>");
        i f6 = dVar.f();
        if (f6 == i5.j.o) {
            abstractC0562c = new AbstractC0560a(dVar);
            if (dVar.f() != i5.j.o) {
                throw new IllegalArgumentException("Coroutines with restricted suspension must have EmptyCoroutineContext");
            }
        } else {
            abstractC0562c = new AbstractC0562c(dVar, f6);
        }
        q5.s.a(2, pVar);
        return pVar.h(obj, abstractC0562c);
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Removed duplicated region for block: B:16:0x006b  */
    /* JADX WARN: Removed duplicated region for block: B:27:0x0091  */
    /* JADX WARN: Removed duplicated region for block: B:29:0x0094  */
    /* JADX WARN: Removed duplicated region for block: B:39:0x0042  */
    /* JADX WARN: Removed duplicated region for block: B:8:0x0022  */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:28:0x0082 -> B:13:0x0065). Please report as a decompilation issue!!! */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:29:0x0085 -> B:13:0x0065). Please report as a decompilation issue!!! */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public static final Object a(List list, C0090j c0090j, AbstractC0562c abstractC0562c) {
        C0084d c0084d;
        int i6;
        List list2;
        Iterator it;
        q5.p pVar;
        Throwable th;
        if (abstractC0562c instanceof C0084d) {
            C0084d c0084d2 = (C0084d) abstractC0562c;
            int i7 = c0084d2.f1198u;
            if ((i7 & Integer.MIN_VALUE) != 0) {
                c0084d2.f1198u = i7 - Integer.MIN_VALUE;
                c0084d = c0084d2;
                Object obj = c0084d.f1197t;
                i6 = c0084d.f1198u;
                Object obj2 = EnumC0522a.o;
                if (i6 == 0) {
                    if (i6 != 1) {
                        if (i6 == 2) {
                            it = c0084d.f1196s;
                            pVar = (q5.p) c0084d.f1195r;
                            try {
                                K(obj);
                                pVar = pVar;
                            } catch (Throwable th2) {
                                Object obj3 = pVar.o;
                                if (obj3 == null) {
                                    pVar.o = th2;
                                    pVar = pVar;
                                } else {
                                    android.support.v4.media.session.a.a((Throwable) obj3, th2);
                                    pVar = pVar;
                                }
                            }
                            while (it.hasNext()) {
                                p5.l lVar = (p5.l) it.next();
                                c0084d.f1195r = pVar;
                                c0084d.f1196s = it;
                                c0084d.f1198u = 2;
                                if (lVar.a(c0084d) == obj2) {
                                    return obj2;
                                }
                            }
                            th = (Throwable) pVar.o;
                            if (th == null) {
                                return g5.h.f6800a;
                            }
                            throw th;
                        }
                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                    }
                    list2 = (List) c0084d.f1195r;
                    K(obj);
                } else {
                    K(obj);
                    ArrayList arrayList = new ArrayList();
                    C0086f c0086f = new C0086f(list, arrayList, null);
                    c0084d.f1195r = arrayList;
                    c0084d.f1198u = 1;
                    if (c0090j.a(c0086f, c0084d) != obj2) {
                        list2 = arrayList;
                    } else {
                        return obj2;
                    }
                }
                Object obj4 = new Object();
                it = list2.iterator();
                pVar = obj4;
                while (it.hasNext()) {
                }
                th = (Throwable) pVar.o;
                if (th == null) {
                }
            }
        }
        c0084d = new AbstractC0562c(abstractC0562c);
        Object obj5 = c0084d.f1197t;
        i6 = c0084d.f1198u;
        Object obj22 = EnumC0522a.o;
        if (i6 == 0) {
        }
        Object obj42 = new Object();
        it = list2.iterator();
        pVar = obj42;
        while (it.hasNext()) {
        }
        th = (Throwable) pVar.o;
        if (th == null) {
        }
    }

    public static List b(int... iArr) {
        if (iArr.length == 0) {
            return Collections.EMPTY_LIST;
        }
        return new H2.b(0, iArr.length, iArr);
    }

    public static X.k c(m mVar, String str, d0.j jVar, int i6) {
        Map map = Collections.EMPTY_MAP;
        Uri y = AbstractC0133a.y(str, jVar.f5934c);
        long j6 = jVar.f5932a;
        long j7 = jVar.f5933b;
        String a6 = mVar.a();
        if (a6 == null) {
            a6 = AbstractC0133a.y(((C0391b) mVar.f5939p.get(0)).f5891a, jVar.f5934c).toString();
        }
        String str2 = a6;
        AbstractC0133a.k(y, "The uri must be set.");
        return new X.k(y, 1, null, e0.f744u, j6, j7, str2, i6);
    }

    public static Object g(Class cls, InvocationHandler invocationHandler) {
        if (invocationHandler == null) {
            return null;
        }
        return cls.cast(Proxy.newProxyInstance(a.class.getClassLoader(), new Class[]{cls}, invocationHandler));
    }

    public static void h(String str, float f6) {
        if (!Float.isNaN(f6)) {
            if (!Float.isInfinite(f6)) {
                return;
            } else {
                throw new IllegalArgumentException(str.concat(" must not be infinite"));
            }
        }
        throw new IllegalArgumentException(str.concat(" must not be NaN"));
    }

    public static int i(int i6, int i7) {
        boolean z6;
        long j6 = i6 + i7;
        int i8 = (int) j6;
        if (j6 == i8) {
            z6 = true;
        } else {
            z6 = false;
        }
        if (z6) {
            return i8;
        }
        throw new ArithmeticException(AbstractC0227o.e("overflow: checkedAdd(", i6, ", ", i7, ")"));
    }

    public static int j(long j6) {
        boolean z6;
        int i6 = (int) j6;
        if (i6 == j6) {
            z6 = true;
        } else {
            z6 = false;
        }
        AbstractC0194a.i(z6, "Out of range: %s", j6);
        return i6;
    }

    public static final void k(Closeable closeable, Throwable th) {
        if (closeable != null) {
            if (th == null) {
                closeable.close();
                return;
            }
            try {
                closeable.close();
            } catch (Throwable th2) {
                android.support.v4.media.session.a.a(th, th2);
            }
        }
    }

    public static final C0455d l(Throwable th) {
        h.e(th, "exception");
        return new C0455d(th);
    }

    public static boolean m(Object obj, Object obj2) {
        int nextInt;
        int nextInt2;
        if ((obj instanceof byte[]) && (obj2 instanceof byte[])) {
            return Arrays.equals((byte[]) obj, (byte[]) obj2);
        }
        if ((obj instanceof int[]) && (obj2 instanceof int[])) {
            return Arrays.equals((int[]) obj, (int[]) obj2);
        }
        if ((obj instanceof long[]) && (obj2 instanceof long[])) {
            return Arrays.equals((long[]) obj, (long[]) obj2);
        }
        if ((obj instanceof double[]) && (obj2 instanceof double[])) {
            return Arrays.equals((double[]) obj, (double[]) obj2);
        }
        if ((obj instanceof Object[]) && (obj2 instanceof Object[])) {
            Object[] objArr = (Object[]) obj;
            Object[] objArr2 = (Object[]) obj2;
            if (objArr.length == objArr2.length) {
                Iterable x02 = AbstractC0469c.x0(objArr);
                if (!(x02 instanceof Collection) || !((Collection) x02).isEmpty()) {
                    Iterator it = x02.iterator();
                    do {
                        C0797b c0797b = (C0797b) it;
                        if (c0797b.f9729q) {
                            nextInt2 = c0797b.nextInt();
                        } else {
                            return true;
                        }
                    } while (m(objArr[nextInt2], objArr2[nextInt2]));
                    return false;
                }
                return true;
            }
            return false;
        }
        if ((obj instanceof List) && (obj2 instanceof List)) {
            List list = (List) obj;
            List list2 = (List) obj2;
            if (list.size() == list2.size()) {
                Iterable R3 = h5.e.R((Collection) obj);
                if (!(R3 instanceof Collection) || !((Collection) R3).isEmpty()) {
                    Iterator it2 = R3.iterator();
                    do {
                        C0797b c0797b2 = (C0797b) it2;
                        if (c0797b2.f9729q) {
                            nextInt = c0797b2.nextInt();
                        } else {
                            return true;
                        }
                    } while (m(list.get(nextInt), list2.get(nextInt)));
                    return false;
                }
                return true;
            }
            return false;
        }
        if ((obj instanceof Map) && (obj2 instanceof Map)) {
            Map map = (Map) obj;
            Map map2 = (Map) obj2;
            if (map.size() == map2.size()) {
                if (!map.isEmpty()) {
                    for (Map.Entry entry : map.entrySet()) {
                        if (!map2.containsKey(entry.getKey()) || !m(entry.getValue(), map2.get(entry.getKey()))) {
                            return false;
                        }
                    }
                    return true;
                }
                return true;
            }
            return false;
        }
        return h.a(obj, obj2);
    }

    public static void n(ArrayList arrayList) {
        boolean z6;
        boolean z7;
        HashMap hashMap = new HashMap(arrayList.size());
        int size = arrayList.size();
        int i6 = 0;
        int i7 = 0;
        while (i7 < size) {
            Object obj = arrayList.get(i7);
            i7++;
            C0261a c0261a = (C0261a) obj;
            C0267g c0267g = new C0267g(c0261a);
            for (C0277q c0277q : c0261a.f5301b) {
                if (c0261a.e == 0) {
                    z7 = true;
                } else {
                    z7 = false;
                }
                C0268h c0268h = new C0268h(c0277q, !z7);
                if (!hashMap.containsKey(c0268h)) {
                    hashMap.put(c0268h, new HashSet());
                }
                Set set = (Set) hashMap.get(c0268h);
                if (!set.isEmpty() && z7) {
                    throw new IllegalArgumentException("Multiple components provide " + c0277q + ".");
                }
                set.add(c0267g);
            }
        }
        Iterator it = hashMap.values().iterator();
        while (it.hasNext()) {
            for (C0267g c0267g2 : (Set) it.next()) {
                for (C0269i c0269i : c0267g2.f5316a.f5302c) {
                    if (c0269i.f5323c == 0) {
                        C0277q c0277q2 = c0269i.f5321a;
                        if (c0269i.f5322b == 2) {
                            z6 = true;
                        } else {
                            z6 = false;
                        }
                        Set<C0267g> set2 = (Set) hashMap.get(new C0268h(c0277q2, z6));
                        if (set2 != null) {
                            for (C0267g c0267g3 : set2) {
                                c0267g2.f5317b.add(c0267g3);
                                c0267g3.f5318c.add(c0267g2);
                            }
                        }
                    }
                }
            }
        }
        HashSet hashSet = new HashSet();
        Iterator it2 = hashMap.values().iterator();
        while (it2.hasNext()) {
            hashSet.addAll((Set) it2.next());
        }
        HashSet hashSet2 = new HashSet();
        Iterator it3 = hashSet.iterator();
        while (it3.hasNext()) {
            C0267g c0267g4 = (C0267g) it3.next();
            if (c0267g4.f5318c.isEmpty()) {
                hashSet2.add(c0267g4);
            }
        }
        while (!hashSet2.isEmpty()) {
            C0267g c0267g5 = (C0267g) hashSet2.iterator().next();
            hashSet2.remove(c0267g5);
            i6++;
            Iterator it4 = c0267g5.f5317b.iterator();
            while (it4.hasNext()) {
                C0267g c0267g6 = (C0267g) it4.next();
                c0267g6.f5318c.remove(c0267g5);
                if (c0267g6.f5318c.isEmpty()) {
                    hashSet2.add(c0267g6);
                }
            }
        }
        if (i6 == arrayList.size()) {
            return;
        }
        ArrayList arrayList2 = new ArrayList();
        Iterator it5 = hashSet.iterator();
        while (it5.hasNext()) {
            C0267g c0267g7 = (C0267g) it5.next();
            if (!c0267g7.f5318c.isEmpty() && !c0267g7.f5317b.isEmpty()) {
                arrayList2.add(c0267g7.f5316a);
            }
        }
        throw new RuntimeException("Dependency cycle detected: " + Arrays.toString(arrayList2.toArray()));
    }

    public static boolean o(String str, String str2) {
        char c6;
        int length = str.length();
        if (str != str2) {
            if (length == str2.length()) {
                for (int i6 = 0; i6 < length; i6++) {
                    if (str.charAt(i6) == str2.charAt(i6) || ((c6 = (char) ((r3 | ' ') - 97)) < 26 && c6 == ((char) ((r4 | ' ') - 97)))) {
                    }
                }
                return true;
            }
            return false;
        }
        return true;
    }

    public static String p(C0219g c0219g) {
        StringBuilder sb = new StringBuilder(c0219g.size());
        for (int i6 = 0; i6 < c0219g.size(); i6++) {
            byte l6 = c0219g.l(i6);
            if (l6 != 34) {
                if (l6 != 39) {
                    if (l6 != 92) {
                        switch (l6) {
                            case 7:
                                sb.append("\\a");
                                break;
                            case 8:
                                sb.append("\\b");
                                break;
                            case ContentHandlerProxy.PROCESSING_INSTRUCTION /* 9 */:
                                sb.append("\\t");
                                break;
                            case 10:
                                sb.append("\\n");
                                break;
                            case 11:
                                sb.append("\\v");
                                break;
                            case 12:
                                sb.append("\\f");
                                break;
                            case 13:
                                sb.append("\\r");
                                break;
                            default:
                                if (l6 >= 32 && l6 <= 126) {
                                    sb.append((char) l6);
                                    break;
                                } else {
                                    sb.append('\\');
                                    sb.append((char) (((l6 >>> 6) & 3) + 48));
                                    sb.append((char) (((l6 >>> 3) & 7) + 48));
                                    sb.append((char) ((l6 & 7) + 48));
                                    break;
                                }
                                break;
                        }
                    } else {
                        sb.append("\\\\");
                    }
                } else {
                    sb.append("\\'");
                }
            } else {
                sb.append("\\\"");
            }
        }
        return sb.toString();
    }

    public static String q(AbstractC0370h abstractC0370h) {
        StringBuilder sb = new StringBuilder(abstractC0370h.size());
        for (int i6 = 0; i6 < abstractC0370h.size(); i6++) {
            byte l6 = abstractC0370h.l(i6);
            if (l6 != 34) {
                if (l6 != 39) {
                    if (l6 != 92) {
                        switch (l6) {
                            case 7:
                                sb.append("\\a");
                                break;
                            case 8:
                                sb.append("\\b");
                                break;
                            case ContentHandlerProxy.PROCESSING_INSTRUCTION /* 9 */:
                                sb.append("\\t");
                                break;
                            case 10:
                                sb.append("\\n");
                                break;
                            case 11:
                                sb.append("\\v");
                                break;
                            case 12:
                                sb.append("\\f");
                                break;
                            case 13:
                                sb.append("\\r");
                                break;
                            default:
                                if (l6 >= 32 && l6 <= 126) {
                                    sb.append((char) l6);
                                    break;
                                } else {
                                    sb.append('\\');
                                    sb.append((char) (((l6 >>> 6) & 3) + 48));
                                    sb.append((char) (((l6 >>> 3) & 7) + 48));
                                    sb.append((char) ((l6 & 7) + 48));
                                    break;
                                }
                                break;
                        }
                    } else {
                        sb.append("\\\\");
                    }
                } else {
                    sb.append("\\'");
                }
            } else {
                sb.append("\\\"");
            }
        }
        return sb.toString();
    }

    public static final FloatBuffer r(int i6) {
        ByteBuffer order = ByteBuffer.allocateDirect(i6 * 4).order(ByteOrder.nativeOrder());
        order.limit(order.capacity());
        FloatBuffer asFloatBuffer = order.asFloatBuffer();
        h.d(asFloatBuffer, "byteBuffer(size * Egloo.SIZE_OF_FLOAT).asFloatBuffer()");
        return asFloatBuffer;
    }

    public static int s(byte b6, byte b7, byte b8, byte b9) {
        return (b6 << 24) | ((b7 & ForkServer.ERROR) << 16) | ((b8 & ForkServer.ERROR) << 8) | (b9 & ForkServer.ERROR);
    }

    public static float t(EdgeEffect edgeEffect) {
        if (Build.VERSION.SDK_INT >= 31) {
            return G.d.b(edgeEffect);
        }
        return 0.0f;
    }

    /* JADX WARN: Type inference failed for: r2v0, types: [p.e, p.j] */
    public static t u(Map map) {
        Object obj = map.get("message");
        Objects.requireNonNull(obj);
        Map map2 = (Map) obj;
        Object obj2 = map2.get("to");
        Objects.requireNonNull(obj2);
        String str = (String) obj2;
        Bundle bundle = new Bundle();
        ?? jVar = new j(0);
        if (!TextUtils.isEmpty(str)) {
            bundle.putString("google.to", str);
            String str2 = (String) map2.get("collapseKey");
            String str3 = (String) map2.get("messageId");
            String str4 = (String) map2.get("messageType");
            Integer num = (Integer) map2.get("ttl");
            Map map3 = (Map) map2.get("data");
            if (str2 != null) {
                bundle.putString("collapse_key", str2);
            }
            if (str4 != null) {
                bundle.putString("message_type", str4);
            }
            if (str3 != null) {
                bundle.putString("google.message_id", str3);
            }
            if (num != null) {
                bundle.putString("google.ttl", String.valueOf(num.intValue()));
            }
            if (map3 != null) {
                jVar.clear();
                jVar.putAll(map3);
            }
            Bundle bundle2 = new Bundle();
            Iterator it = ((b0) jVar.entrySet()).iterator();
            while (true) {
                p.c cVar = (p.c) it;
                if (cVar.hasNext()) {
                    cVar.next();
                    p.c cVar2 = cVar;
                    bundle2.putString((String) cVar2.getKey(), (String) cVar2.getValue());
                } else {
                    bundle2.putAll(bundle);
                    bundle.remove("from");
                    return new t(bundle2);
                }
            }
        } else {
            throw new IllegalArgumentException("Invalid to: ".concat(str));
        }
    }

    public static int v(int i6, int i7, int i8, int[] iArr) {
        while (i7 < i8) {
            if (iArr[i7] == i6) {
                return i7;
            }
            i7++;
        }
        return -1;
    }

    public static d w(d dVar) {
        AbstractC0562c abstractC0562c;
        d dVar2;
        h.e(dVar, "<this>");
        if (dVar instanceof AbstractC0562c) {
            abstractC0562c = (AbstractC0562c) dVar;
        } else {
            abstractC0562c = null;
        }
        if (abstractC0562c != null && (dVar = abstractC0562c.f8001q) == null) {
            i5.f fVar = (i5.f) abstractC0562c.f().m(i5.e.o);
            if (fVar != null) {
                dVar2 = new C5.h((AbstractC0911s) fVar, abstractC0562c);
            } else {
                dVar2 = abstractC0562c;
            }
            abstractC0562c.f8001q = dVar2;
            return dVar2;
        }
        return dVar;
    }

    public static int x(int i6) {
        int i7 = i6 % 65536;
        if (i7 >= 0) {
            return i7;
        }
        return i7 + 65536;
    }

    public static float y(EdgeEffect edgeEffect, float f6, float f7) {
        if (Build.VERSION.SDK_INT >= 31) {
            return G.d.c(edgeEffect, f6, f7);
        }
        G.c.a(edgeEffect, f6, f7);
        return f6;
    }

    public abstract void A(r.g gVar, Thread thread);

    public abstract boolean d(r.h hVar, r.d dVar, r.d dVar2);

    public abstract boolean e(r.h hVar, Object obj, Object obj2);

    public abstract boolean f(r.h hVar, r.g gVar, r.g gVar2);

    public abstract void z(r.g gVar, r.g gVar2);
}
