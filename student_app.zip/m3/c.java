package m3;

import android.util.Base64OutputStream;
import io.flutter.plugin.editing.j;
import java.io.ByteArrayOutputStream;
import java.util.ArrayList;
import java.util.Collection;
import java.util.concurrent.Callable;
import java.util.zip.GZIPOutputStream;
import org.apache.tika.pipes.async.AsyncProcessor;
import org.json.JSONArray;
import org.json.JSONObject;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* loaded from: classes.dex */
public final /* synthetic */ class c implements Callable {
    public final /* synthetic */ int o;

    /* renamed from: p, reason: collision with root package name */
    public final /* synthetic */ Object f8677p;

    public /* synthetic */ c(Object obj, int i6) {
        this.o = i6;
        this.f8677p = obj;
    }

    @Override // java.util.concurrent.Callable
    public final Object call() {
        String byteArrayOutputStream;
        switch (this.o) {
            case 0:
                d dVar = (d) this.f8677p;
                synchronized (dVar) {
                    try {
                        j jVar = (j) dVar.f8678a.get();
                        ArrayList d6 = jVar.d();
                        jVar.b();
                        JSONArray jSONArray = new JSONArray();
                        for (int i6 = 0; i6 < d6.size(); i6++) {
                            C0656a c0656a = (C0656a) d6.get(i6);
                            JSONObject jSONObject = new JSONObject();
                            jSONObject.put("agent", c0656a.f8674a);
                            jSONObject.put("dates", new JSONArray((Collection) c0656a.f8675b));
                            jSONArray.put(jSONObject);
                        }
                        JSONObject jSONObject2 = new JSONObject();
                        jSONObject2.put("heartbeats", jSONArray);
                        jSONObject2.put("version", "2");
                        ByteArrayOutputStream byteArrayOutputStream2 = new ByteArrayOutputStream();
                        Base64OutputStream base64OutputStream = new Base64OutputStream(byteArrayOutputStream2, 11);
                        try {
                            GZIPOutputStream gZIPOutputStream = new GZIPOutputStream(base64OutputStream);
                            try {
                                gZIPOutputStream.write(jSONObject2.toString().getBytes("UTF-8"));
                                gZIPOutputStream.close();
                                base64OutputStream.close();
                                byteArrayOutputStream = byteArrayOutputStream2.toString("UTF-8");
                            } finally {
                            }
                        } catch (Throwable th) {
                            try {
                                base64OutputStream.close();
                            } catch (Throwable th2) {
                                th.addSuppressed(th2);
                            }
                            throw th;
                        }
                    } catch (Throwable th3) {
                        throw th3;
                    }
                }
                return byteArrayOutputStream;
            case 1:
                d dVar2 = (d) this.f8677p;
                synchronized (dVar2) {
                    ((j) dVar2.f8678a.get()).l(System.currentTimeMillis(), ((x3.b) dVar2.f8680c.get()).a());
                }
                return null;
            default:
                return AsyncProcessor.b((AsyncProcessor) this.f8677p);
        }
    }
}
