package m3;

import java.util.ArrayList;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* renamed from: m3.a, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0656a {

    /* renamed from: a, reason: collision with root package name */
    public final String f8674a;

    /* renamed from: b, reason: collision with root package name */
    public final ArrayList f8675b;

    public C0656a(String str, ArrayList arrayList) {
        if (str != null) {
            this.f8674a = str;
            this.f8675b = arrayList;
            return;
        }
        throw new NullPointerException("Null userAgent");
    }

    public final boolean equals(Object obj) {
        if (obj != this) {
            if (obj instanceof C0656a) {
                C0656a c0656a = (C0656a) obj;
                if (this.f8674a.equals(c0656a.f8674a) && this.f8675b.equals(c0656a.f8675b)) {
                    return true;
                }
                return false;
            }
            return false;
        }
        return true;
    }

    public final int hashCode() {
        return ((this.f8674a.hashCode() ^ 1000003) * 1000003) ^ this.f8675b.hashCode();
    }

    public final String toString() {
        return "HeartBeatResult{userAgent=" + this.f8674a + ", usedDates=" + this.f8675b + "}";
    }
}
