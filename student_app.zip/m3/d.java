package m3;

import C2.r;
import a.AbstractC0194a;
import android.content.Context;
import android.os.UserManager;
import java.util.Set;
import java.util.concurrent.Executor;
import o3.InterfaceC0675a;
import org.apache.tika.utils.StringUtils;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* loaded from: classes.dex */
public final class d implements f, g {

    /* renamed from: a, reason: collision with root package name */
    public final Y2.c f8678a;

    /* renamed from: b, reason: collision with root package name */
    public final Context f8679b;

    /* renamed from: c, reason: collision with root package name */
    public final InterfaceC0675a f8680c;

    /* renamed from: d, reason: collision with root package name */
    public final Set f8681d;
    public final Executor e;

    public d(Context context, String str, Set set, InterfaceC0675a interfaceC0675a, Executor executor) {
        this.f8678a = new Y2.c(context, str);
        this.f8681d = set;
        this.e = executor;
        this.f8680c = interfaceC0675a;
        this.f8679b = context;
    }

    public final r a() {
        if (!((UserManager) this.f8679b.getSystemService(UserManager.class)).isUserUnlocked()) {
            return AbstractC0194a.O(StringUtils.EMPTY);
        }
        return AbstractC0194a.h(this.e, new c(this, 0));
    }

    public final void b() {
        if (this.f8681d.size() <= 0) {
            AbstractC0194a.O(null);
        } else if (!((UserManager) this.f8679b.getSystemService(UserManager.class)).isUserUnlocked()) {
            AbstractC0194a.O(null);
        } else {
            AbstractC0194a.h(this.e, new c(this, 1));
        }
    }
}
