package m3;

import A1.i;
import E2.I;
import M4.m;
import M4.n;
import M4.o;
import M4.x;
import N.h;
import S.C0123p;
import U0.j;
import U0.l;
import W2.k;
import android.content.Context;
import android.content.pm.ApplicationInfo;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable;
import android.system.Os;
import android.system.OsConstants;
import android.util.Base64;
import android.util.Log;
import android.util.Pair;
import androidx.datastore.preferences.protobuf.AbstractC0227o;
import b2.C0259b;
import b2.C0260c;
import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.ByteArrayOutputStream;
import java.io.Closeable;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.ShortBuffer;
import java.security.KeyPairGenerator;
import java.security.MessageDigest;
import java.security.Provider;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;
import javax.crypto.KeyAgreement;
import org.apache.tika.fork.ContentHandlerProxy;
import org.apache.tika.metadata.TikaCoreProperties;
import org.apache.tika.utils.StringUtils;
import org.apache.tika.utils.XMLReaderUtils;
import v3.u;
import x0.InterfaceC0878A;
import x0.p;
import x0.s;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* loaded from: classes.dex */
public final class e implements M4.d, n, S0.g, j, k, X3.a, X1.b {
    public final /* synthetic */ int o;

    public /* synthetic */ e(int i6) {
        this.o = i6;
    }

    public static void k(Closeable closeable) {
        if (closeable != null) {
            try {
                closeable.close();
            } catch (IOException unused) {
            }
        }
    }

    /* JADX WARN: Failed to find 'out' block for switch in B:96:0x03cb. Please report as an issue. */
    /* JADX WARN: Removed duplicated region for block: B:109:0x0430  */
    /* JADX WARN: Removed duplicated region for block: B:120:0x04bd  */
    /* JADX WARN: Removed duplicated region for block: B:130:0x0507  */
    /* JADX WARN: Removed duplicated region for block: B:137:0x055a  */
    /* JADX WARN: Removed duplicated region for block: B:144:0x0585  */
    /* JADX WARN: Removed duplicated region for block: B:151:0x05b0  */
    /* JADX WARN: Removed duplicated region for block: B:153:0x05c1  */
    /* JADX WARN: Removed duplicated region for block: B:282:0x0704 A[Catch: all -> 0x070d, Exception -> 0x0712, TryCatch #20 {Exception -> 0x0712, all -> 0x070d, blocks: (B:280:0x0700, B:282:0x0704, B:284:0x0726, B:297:0x0715), top: B:279:0x0700 }] */
    /* JADX WARN: Removed duplicated region for block: B:294:0x076d  */
    /* JADX WARN: Removed duplicated region for block: B:297:0x0715 A[Catch: all -> 0x070d, Exception -> 0x0712, TryCatch #20 {Exception -> 0x0712, all -> 0x070d, blocks: (B:280:0x0700, B:282:0x0704, B:284:0x0726, B:297:0x0715), top: B:279:0x0700 }] */
    /* JADX WARN: Removed duplicated region for block: B:97:0x03ce  */
    /* JADX WARN: Removed duplicated region for block: B:99:0x03e3  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public static void l(h hVar, h hVar2) {
        byte[] m4;
        FileOutputStream fileOutputStream;
        FileInputStream fileInputStream;
        FileInputStream fileInputStream2;
        FileOutputStream fileOutputStream2;
        FileInputStream fileInputStream3;
        BufferedOutputStream bufferedOutputStream;
        BufferedInputStream bufferedInputStream;
        BufferedOutputStream bufferedOutputStream2;
        BufferedInputStream bufferedInputStream2;
        boolean z6;
        boolean z7;
        FileInputStream fileInputStream4;
        FileOutputStream fileOutputStream3;
        FileInputStream fileInputStream5;
        FileOutputStream fileOutputStream4;
        FileOutputStream fileOutputStream5;
        String str;
        N.e eVar;
        int i6;
        int i7;
        String str2;
        String str3;
        String str4;
        boolean z8;
        char c6;
        N.d dVar;
        String str5;
        long j6;
        N.f fVar;
        h hVar3 = hVar;
        for (String str6 : Arrays.asList("ImageDescription", "Make", "Model", "Software", "DateTime", "Artist", "Copyright", "ExposureTime", "FNumber", "ExposureProgram", "SpectralSensitivity", "PhotographicSensitivity", "ISOSpeedRatings", "OECF", "SensitivityType", "StandardOutputSensitivity", "RecommendedExposureIndex", "ISOSpeed", "ISOSpeedLatitudeyyy", "ISOSpeedLatitudezzz", "ExifVersion", "DateTimeOriginal", "DateTimeDigitized", "OffsetTime", "OffsetTimeOriginal", "OffsetTimeDigitized", "ShutterSpeedValue", "ApertureValue", "BrightnessValue", "ExposureBiasValue", "MaxApertureValue", "SubjectDistance", "MeteringMode", "LightSource", "Flash", "FocalLength", "MakerNote", "UserComment", "SubSecTime", "SubSecTimeOriginal", "SubSecTimeDigitized", "FlashpixVersion", "FlashEnergy", "SpatialFrequencyResponse", "FocalPlaneXResolution", "FocalPlaneYResolution", "FocalPlaneResolutionUnit", "ExposureIndex", "SensingMethod", "FileSource", "SceneType", "CFAPattern", "CustomRendered", "ExposureMode", "WhiteBalance", "DigitalZoomRatio", "FocalLengthIn35mmFilm", "SceneCaptureType", "GainControl", "Contrast", "Saturation", "Sharpness", "DeviceSettingDescription", "SubjectDistanceRange", "ImageUniqueID", "CameraOwnerName", "BodySerialNumber", "LensSpecification", "LensMake", "LensModel", "LensSerialNumber", "GPSVersionID", "GPSLatitudeRef", "GPSLatitude", "GPSLongitudeRef", "GPSLongitude", "GPSAltitudeRef", "GPSAltitude", "GPSTimeStamp", "GPSSatellites", "GPSStatus", "GPSMeasureMode", "GPSDOP", "GPSSpeedRef", "GPSSpeed", "GPSTrackRef", "GPSTrack", "GPSImgDirectionRef", "GPSImgDirection", "GPSMapDatum", "GPSDestLatitudeRef", "GPSDestLatitude", "GPSDestLongitudeRef", "GPSDestLongitude", "GPSDestBearingRef", "GPSDestBearing", "GPSDestDistanceRef", "GPSDestDistance", "GPSProcessingMethod", "GPSAreaInformation", "GPSDateStamp", "GPSDifferential", "GPSHPositioningError", "InteroperabilityIndex", "Orientation")) {
            if (hVar3.b(str6) != null) {
                String b6 = hVar3.b(str6);
                int[] iArr = h.f1779R;
                boolean z9 = h.f1794u;
                HashMap[] hashMapArr = hVar2.e;
                String str7 = "ExifInterface";
                if ("ISOSpeedRatings".equals(str6)) {
                    if (z9) {
                        Log.d("ExifInterface", "setAttribute: Replacing TAG_ISO_SPEED_RATINGS with TAG_PHOTOGRAPHIC_SENSITIVITY.");
                    }
                    str6 = "PhotographicSensitivity";
                }
                if (b6 == null) {
                    str = "/";
                } else {
                    String str8 = "Invalid value for ";
                    if (!h.f1786Y.contains(str6) || b6.contains("/")) {
                        str = "/";
                        if (str6.equals("GPSTimeStamp")) {
                            Matcher matcher = h.f1791d0.matcher(b6);
                            if (!matcher.find()) {
                                Log.w("ExifInterface", "Invalid value for " + str6 + " : " + b6);
                            } else {
                                b6 = Integer.parseInt(matcher.group(1)) + "/1," + Integer.parseInt(matcher.group(2)) + "/1," + Integer.parseInt(matcher.group(3)) + "/1";
                            }
                        } else if ("DateTime".equals(str6) || "DateTimeOriginal".equals(str6) || "DateTimeDigitized".equals(str6)) {
                            boolean find = h.f1792e0.matcher(b6).find();
                            boolean find2 = h.f1793f0.matcher(b6).find();
                            if (b6.length() == 19 && (find || find2)) {
                                if (find2) {
                                    b6 = b6.replaceAll("-", TikaCoreProperties.NAMESPACE_PREFIX_DELIMITER);
                                }
                            } else {
                                Log.w("ExifInterface", "Invalid value for " + str6 + " : " + b6);
                            }
                        }
                    } else {
                        try {
                            double parseDouble = Double.parseDouble(b6);
                            str = "/";
                            long j7 = 1;
                            if (parseDouble < 9.223372036854776E18d && parseDouble > -9.223372036854776E18d) {
                                double abs = Math.abs(parseDouble);
                                long j8 = 1;
                                double d6 = abs;
                                long j9 = 0;
                                long j10 = 0;
                                while (true) {
                                    double d7 = d6 % 1.0d;
                                    long j11 = (long) (d6 - d7);
                                    str5 = str8;
                                    long j12 = (j11 * j7) + j9;
                                    long j13 = (j11 * j10) + j8;
                                    d6 = 1.0d / d7;
                                    j9 = j7;
                                    try {
                                        if (Math.abs(abs - (j12 / j13)) <= 1.0E-8d * abs) {
                                            if (parseDouble < 0.0d) {
                                                j12 = -j12;
                                            }
                                            fVar = new N.f(j12, j13);
                                        } else {
                                            j7 = j12;
                                            j8 = j10;
                                            str8 = str5;
                                            j10 = j13;
                                        }
                                    } catch (NumberFormatException unused) {
                                        Log.w("ExifInterface", str5 + str6 + " : " + b6);
                                        hVar3 = hVar;
                                    }
                                }
                            } else {
                                if (parseDouble > 0.0d) {
                                    j6 = Long.MAX_VALUE;
                                } else {
                                    j6 = Long.MIN_VALUE;
                                }
                                fVar = new N.f(j6, 1L);
                            }
                            b6 = fVar.toString();
                        } catch (NumberFormatException unused2) {
                            str5 = "Invalid value for ";
                        }
                    }
                }
                int i8 = 12;
                int i9 = 9;
                if ("Xmp".equals(str6)) {
                    if (!hashMapArr[0].containsKey("Xmp") && !hashMapArr[5].containsKey("Xmp")) {
                        z8 = false;
                    } else {
                        z8 = true;
                    }
                    int i10 = hVar2.f1801c;
                    if (i10 != 4) {
                        if (i10 != 9 && i10 != 15 && i10 != 12 && i10 != 13) {
                            c6 = 1;
                        } else {
                            c6 = 2;
                        }
                    } else {
                        c6 = 3;
                    }
                    if ((c6 == 2 && (hVar2.f1815s != null || !z8)) || (c6 == 3 && !z8)) {
                        if (b6 != null) {
                            dVar = N.d.a(b6);
                        } else {
                            dVar = null;
                        }
                        hVar2.f1815s = dVar;
                    }
                }
                int i11 = 0;
                while (i11 < h.f1782U.length) {
                    if ((i11 != 4 || hVar2.f1805h) && (eVar = (N.e) h.f1785X[i11].get(str6)) != null) {
                        int i12 = eVar.f1760d;
                        int i13 = eVar.f1759c;
                        if (b6 == null) {
                            hashMapArr[i11].remove(str6);
                        } else {
                            Pair o = h.o(b6);
                            int i14 = i9;
                            if (i13 != ((Integer) o.first).intValue() && i13 != ((Integer) o.second).intValue()) {
                                if (i12 != -1 && (i12 == ((Integer) o.first).intValue() || i12 == ((Integer) o.second).intValue())) {
                                    i6 = i8;
                                    switch (i12) {
                                        case 1:
                                            i7 = i11;
                                            str2 = str7;
                                            hashMapArr[i7].put(str6, N.d.a(b6));
                                            break;
                                        case 2:
                                        case 7:
                                            i7 = i11;
                                            str2 = str7;
                                            hashMapArr[i7].put(str6, N.d.b(b6));
                                            break;
                                        case 3:
                                            i7 = i11;
                                            str2 = str7;
                                            String[] split = b6.split(",", -1);
                                            int[] iArr2 = new int[split.length];
                                            for (int i15 = 0; i15 < split.length; i15++) {
                                                iArr2[i15] = Integer.parseInt(split[i15]);
                                            }
                                            hashMapArr[i7].put(str6, N.d.g(iArr2, hVar2.f1804g));
                                            break;
                                        case 4:
                                            i7 = i11;
                                            str2 = str7;
                                            String[] split2 = b6.split(",", -1);
                                            long[] jArr = new long[split2.length];
                                            for (int i16 = 0; i16 < split2.length; i16++) {
                                                jArr[i16] = Long.parseLong(split2[i16]);
                                            }
                                            hashMapArr[i7].put(str6, N.d.d(jArr, hVar2.f1804g));
                                            break;
                                        case 5:
                                            i7 = i11;
                                            str2 = str7;
                                            String str9 = str;
                                            int i17 = -1;
                                            String[] split3 = b6.split(",", -1);
                                            N.f[] fVarArr = new N.f[split3.length];
                                            int i18 = 0;
                                            while (i18 < split3.length) {
                                                String[] split4 = split3[i18].split(str9, i17);
                                                int i19 = i18;
                                                fVarArr[i19] = new N.f((long) Double.parseDouble(split4[0]), (long) Double.parseDouble(split4[1]));
                                                i18 = i19 + 1;
                                                str9 = str9;
                                                i17 = -1;
                                            }
                                            str = str9;
                                            hashMapArr[i7].put(str6, N.d.e(fVarArr, hVar2.f1804g));
                                            break;
                                        case 6:
                                        case 8:
                                        case 11:
                                        default:
                                            if (z9) {
                                                Log.d(str7, "Data format isn't one of expected formats: " + i12);
                                                break;
                                            }
                                            break;
                                        case ContentHandlerProxy.PROCESSING_INSTRUCTION /* 9 */:
                                            i7 = i11;
                                            str2 = str7;
                                            str3 = str;
                                            String[] split5 = b6.split(",", -1);
                                            int length = split5.length;
                                            int[] iArr3 = new int[length];
                                            for (int i20 = 0; i20 < split5.length; i20++) {
                                                iArr3[i20] = Integer.parseInt(split5[i20]);
                                            }
                                            HashMap hashMap = hashMapArr[i7];
                                            ByteOrder byteOrder = hVar2.f1804g;
                                            ByteBuffer wrap = ByteBuffer.wrap(new byte[iArr[i14] * length]);
                                            wrap.order(byteOrder);
                                            for (int i21 = 0; i21 < length; i21++) {
                                                wrap.putInt(iArr3[i21]);
                                            }
                                            hashMap.put(str6, new N.d(wrap.array(), i14, length));
                                            str = str3;
                                            break;
                                        case 10:
                                            str2 = str7;
                                            int i22 = -1;
                                            String[] split6 = b6.split(",", -1);
                                            int length2 = split6.length;
                                            N.f[] fVarArr2 = new N.f[length2];
                                            int i23 = 0;
                                            while (i23 < split6.length) {
                                                String[] split7 = split6[i23].split(str, i22);
                                                int i24 = i23;
                                                N.f[] fVarArr3 = fVarArr2;
                                                fVarArr3[i24] = new N.f((long) Double.parseDouble(split7[0]), (long) Double.parseDouble(split7[1]));
                                                i23 = i24 + 1;
                                                split6 = split6;
                                                fVarArr2 = fVarArr3;
                                                i11 = i11;
                                                i22 = -1;
                                            }
                                            i7 = i11;
                                            N.f[] fVarArr4 = fVarArr2;
                                            str3 = str;
                                            HashMap hashMap2 = hashMapArr[i7];
                                            ByteOrder byteOrder2 = hVar2.f1804g;
                                            ByteBuffer wrap2 = ByteBuffer.wrap(new byte[iArr[10] * length2]);
                                            wrap2.order(byteOrder2);
                                            int i25 = 0;
                                            while (i25 < length2) {
                                                N.f fVar2 = fVarArr4[i25];
                                                wrap2.putInt((int) fVar2.f1761a);
                                                wrap2.putInt((int) fVar2.f1762b);
                                                i25++;
                                                length2 = length2;
                                            }
                                            hashMap2.put(str6, new N.d(wrap2.array(), 10, length2));
                                            str = str3;
                                            break;
                                        case 12:
                                            String[] split8 = b6.split(",", -1);
                                            int length3 = split8.length;
                                            double[] dArr = new double[length3];
                                            for (int i26 = 0; i26 < split8.length; i26++) {
                                                dArr[i26] = Double.parseDouble(split8[i26]);
                                            }
                                            HashMap hashMap3 = hashMapArr[i11];
                                            ByteOrder byteOrder3 = hVar2.f1804g;
                                            ByteBuffer wrap3 = ByteBuffer.wrap(new byte[iArr[i6] * length3]);
                                            wrap3.order(byteOrder3);
                                            int i27 = 0;
                                            while (i27 < length3) {
                                                double[] dArr2 = dArr;
                                                wrap3.putDouble(dArr2[i27]);
                                                i27++;
                                                str7 = str7;
                                                dArr = dArr2;
                                            }
                                            str2 = str7;
                                            hashMap3.put(str6, new N.d(wrap3.array(), i6, length3));
                                            i7 = i11;
                                            break;
                                    }
                                    i11 = i7 + 1;
                                    str7 = str2;
                                    i8 = 12;
                                    i9 = 9;
                                } else if (i13 != 1 && i13 != 7 && i13 != 2) {
                                    if (z9) {
                                        StringBuilder j14 = AbstractC0227o.j("Given tag (", str6, ") value didn't match with one of expected formats: ");
                                        String[] strArr = h.f1778Q;
                                        j14.append(strArr[i13]);
                                        String str10 = StringUtils.EMPTY;
                                        if (i12 == -1) {
                                            str4 = StringUtils.EMPTY;
                                        } else {
                                            str4 = ", " + strArr[i12];
                                        }
                                        j14.append(str4);
                                        j14.append(" (guess: ");
                                        j14.append(strArr[((Integer) o.first).intValue()]);
                                        if (((Integer) o.second).intValue() != -1) {
                                            str10 = ", " + strArr[((Integer) o.second).intValue()];
                                        }
                                        j14.append(str10);
                                        j14.append(")");
                                        Log.d(str7, j14.toString());
                                    } else {
                                        i7 = i11;
                                        str2 = str7;
                                        i11 = i7 + 1;
                                        str7 = str2;
                                        i8 = 12;
                                        i9 = 9;
                                    }
                                }
                            }
                            i6 = i8;
                            i12 = i13;
                            switch (i12) {
                            }
                            i11 = i7 + 1;
                            str7 = str2;
                            i8 = 12;
                            i9 = 9;
                        }
                    }
                    i7 = i11;
                    str2 = str7;
                    i11 = i7 + 1;
                    str7 = str2;
                    i8 = 12;
                    i9 = 9;
                }
            }
            hVar3 = hVar;
        }
        int i28 = hVar2.f1801c;
        if (i28 != 4 && i28 != 13 && i28 != 14) {
            throw new IOException("ExifInterface only supports saving attributes for JPEG, PNG, and WebP formats.");
        }
        if (hVar2.f1800b == null && hVar2.f1799a == null) {
            throw new IOException("ExifInterface does not support saving attributes for the current input.");
        }
        if (hVar2.f1805h && hVar2.f1806i && !hVar2.f1807j) {
            throw new IOException("ExifInterface does not support saving attributes when the image file has non-consecutive thumbnail strips");
        }
        int i29 = hVar2.f1811n;
        if (i29 != 6 && i29 != 7) {
            m4 = null;
        } else {
            m4 = hVar2.m();
        }
        hVar2.f1810m = m4;
        try {
            File createTempFile = File.createTempFile("temp", "tmp");
            if (hVar2.f1799a != null) {
                try {
                    fileInputStream2 = new FileInputStream(hVar2.f1799a);
                } catch (Exception e) {
                    e = e;
                    fileOutputStream = null;
                    fileInputStream = null;
                    try {
                        throw new IOException("Failed to copy original file to temp file", e);
                    } catch (Throwable th) {
                        th = th;
                        T5.h.d(fileInputStream);
                        T5.h.d(fileOutputStream);
                        throw th;
                    }
                } catch (Throwable th2) {
                    th = th2;
                    fileOutputStream = null;
                    fileInputStream = null;
                    T5.h.d(fileInputStream);
                    T5.h.d(fileOutputStream);
                    throw th;
                }
            } else {
                Os.lseek(hVar2.f1800b, 0L, OsConstants.SEEK_SET);
                fileInputStream2 = new FileInputStream(hVar2.f1800b);
            }
            FileInputStream fileInputStream6 = fileInputStream2;
            try {
                FileOutputStream fileOutputStream6 = new FileOutputStream(createTempFile);
                try {
                    T5.h.j(fileInputStream6, fileOutputStream6);
                    T5.h.d(fileInputStream6);
                    T5.h.d(fileOutputStream6);
                    try {
                        try {
                            fileInputStream5 = new FileInputStream(createTempFile);
                            try {
                                if (hVar2.f1799a != null) {
                                    try {
                                        fileOutputStream4 = new FileOutputStream(hVar2.f1799a);
                                    } catch (Exception e6) {
                                        e = e6;
                                        fileInputStream3 = fileInputStream5;
                                        fileOutputStream2 = null;
                                        bufferedOutputStream = null;
                                        bufferedInputStream = null;
                                        try {
                                            fileInputStream4 = new FileInputStream(createTempFile);
                                        } catch (Exception e7) {
                                            e = e7;
                                        } catch (Throwable th3) {
                                            th = th3;
                                        }
                                        try {
                                            if (hVar2.f1799a != null) {
                                            }
                                            fileOutputStream2 = fileOutputStream3;
                                            T5.h.j(fileInputStream4, fileOutputStream2);
                                            try {
                                                T5.h.d(fileInputStream4);
                                                T5.h.d(fileOutputStream2);
                                                throw new IOException("Failed to save new file", e);
                                            } catch (Throwable th4) {
                                                th = th4;
                                                bufferedOutputStream2 = bufferedOutputStream;
                                                z6 = false;
                                                bufferedInputStream2 = bufferedInputStream;
                                                T5.h.d(bufferedInputStream2);
                                                T5.h.d(bufferedOutputStream2);
                                                if (!z6) {
                                                }
                                                throw th;
                                            }
                                        } catch (Exception e8) {
                                            e = e8;
                                            fileInputStream3 = fileInputStream4;
                                            try {
                                                throw new IOException("Failed to save new file. Original file is stored in " + createTempFile.getAbsolutePath(), e);
                                            } catch (Throwable th5) {
                                                th = th5;
                                                z7 = true;
                                                try {
                                                    T5.h.d(fileInputStream3);
                                                    T5.h.d(fileOutputStream2);
                                                    throw th;
                                                } catch (Throwable th6) {
                                                    th = th6;
                                                    bufferedOutputStream2 = bufferedOutputStream;
                                                    z6 = z7;
                                                    bufferedInputStream2 = bufferedInputStream;
                                                    T5.h.d(bufferedInputStream2);
                                                    T5.h.d(bufferedOutputStream2);
                                                    if (!z6) {
                                                        createTempFile.delete();
                                                    }
                                                    throw th;
                                                }
                                            }
                                        } catch (Throwable th7) {
                                            th = th7;
                                            fileInputStream3 = fileInputStream4;
                                            z7 = false;
                                            T5.h.d(fileInputStream3);
                                            T5.h.d(fileOutputStream2);
                                            throw th;
                                        }
                                    } catch (Throwable th8) {
                                        th = th8;
                                        z6 = false;
                                        bufferedOutputStream2 = null;
                                        bufferedInputStream2 = null;
                                        T5.h.d(bufferedInputStream2);
                                        T5.h.d(bufferedOutputStream2);
                                        if (!z6) {
                                        }
                                        throw th;
                                    }
                                } else {
                                    Os.lseek(hVar2.f1800b, 0L, OsConstants.SEEK_SET);
                                    fileOutputStream4 = new FileOutputStream(hVar2.f1800b);
                                }
                                fileOutputStream5 = fileOutputStream4;
                            } catch (Exception e9) {
                                e = e9;
                                fileOutputStream2 = null;
                                bufferedOutputStream = null;
                                bufferedInputStream = null;
                            }
                        } catch (Throwable th9) {
                            th = th9;
                            bufferedOutputStream2 = null;
                            bufferedInputStream2 = null;
                        }
                    } catch (Exception e10) {
                        e = e10;
                        fileOutputStream2 = null;
                        fileInputStream3 = null;
                        bufferedOutputStream = null;
                        bufferedInputStream = null;
                    }
                    try {
                        bufferedInputStream2 = new BufferedInputStream(fileInputStream5);
                        try {
                            bufferedOutputStream = new BufferedOutputStream(fileOutputStream5);
                        } catch (Exception e11) {
                            e = e11;
                            bufferedOutputStream = null;
                        } catch (Throwable th10) {
                            th = th10;
                            bufferedOutputStream2 = null;
                        }
                    } catch (Exception e12) {
                        e = e12;
                        bufferedOutputStream = null;
                        bufferedInputStream = null;
                        fileInputStream3 = fileInputStream5;
                        fileOutputStream2 = fileOutputStream5;
                        fileInputStream4 = new FileInputStream(createTempFile);
                        if (hVar2.f1799a != null) {
                            fileOutputStream3 = new FileOutputStream(hVar2.f1799a);
                        } else {
                            Os.lseek(hVar2.f1800b, 0L, OsConstants.SEEK_SET);
                            fileOutputStream3 = new FileOutputStream(hVar2.f1800b);
                        }
                        fileOutputStream2 = fileOutputStream3;
                        T5.h.j(fileInputStream4, fileOutputStream2);
                        T5.h.d(fileInputStream4);
                        T5.h.d(fileOutputStream2);
                        throw new IOException("Failed to save new file", e);
                    }
                    try {
                        int i30 = hVar2.f1801c;
                        if (i30 == 4) {
                            hVar2.z(bufferedInputStream2, bufferedOutputStream);
                        } else if (i30 == 13) {
                            hVar2.A(bufferedInputStream2, bufferedOutputStream);
                        } else if (i30 == 14) {
                            hVar2.B(bufferedInputStream2, bufferedOutputStream);
                        }
                        T5.h.d(bufferedInputStream2);
                        T5.h.d(bufferedOutputStream);
                        createTempFile.delete();
                        hVar2.f1810m = null;
                    } catch (Exception e13) {
                        e = e13;
                        fileOutputStream2 = fileOutputStream5;
                        bufferedInputStream = bufferedInputStream2;
                        fileInputStream3 = fileInputStream5;
                        fileInputStream4 = new FileInputStream(createTempFile);
                        if (hVar2.f1799a != null) {
                        }
                        fileOutputStream2 = fileOutputStream3;
                        T5.h.j(fileInputStream4, fileOutputStream2);
                        T5.h.d(fileInputStream4);
                        T5.h.d(fileOutputStream2);
                        throw new IOException("Failed to save new file", e);
                    } catch (Throwable th11) {
                        th = th11;
                        bufferedOutputStream2 = bufferedOutputStream;
                        z6 = false;
                        T5.h.d(bufferedInputStream2);
                        T5.h.d(bufferedOutputStream2);
                        if (!z6) {
                        }
                        throw th;
                    }
                } catch (Exception e14) {
                    e = e14;
                    fileInputStream = fileInputStream6;
                    fileOutputStream = fileOutputStream6;
                    throw new IOException("Failed to copy original file to temp file", e);
                } catch (Throwable th12) {
                    th = th12;
                    fileInputStream = fileInputStream6;
                    fileOutputStream = fileOutputStream6;
                    T5.h.d(fileInputStream);
                    T5.h.d(fileOutputStream);
                    throw th;
                }
            } catch (Exception e15) {
                e = e15;
                fileOutputStream = null;
                fileInputStream = fileInputStream6;
            } catch (Throwable th13) {
                th = th13;
                fileOutputStream = null;
                fileInputStream = fileInputStream6;
            }
        } catch (Exception e16) {
            e = e16;
            fileOutputStream = null;
            fileInputStream = null;
        } catch (Throwable th14) {
            th = th14;
            fileOutputStream = null;
            fileInputStream = null;
        }
    }

    public static byte[] n(long j6, I i6) {
        T.e eVar = new T.e(3);
        ArrayList<? extends Parcelable> arrayList = new ArrayList<>(i6.size());
        int size = i6.size();
        int i7 = 0;
        while (i7 < size) {
            Object obj = i6.get(i7);
            i7++;
            arrayList.add((Bundle) eVar.apply(obj));
        }
        Bundle bundle = new Bundle();
        bundle.putParcelableArrayList("c", arrayList);
        bundle.putLong("d", j6);
        Parcel obtain = Parcel.obtain();
        obtain.writeBundle(bundle);
        byte[] marshall = obtain.marshall();
        obtain.recycle();
        return marshall;
    }

    public static A.c o(Context context, String[] strArr, String str, u uVar) {
        String[] r6 = r(context);
        int length = r6.length;
        int i6 = 0;
        while (true) {
            ZipFile zipFile = null;
            if (i6 >= length) {
                return null;
            }
            String str2 = r6[i6];
            int i7 = 0;
            while (true) {
                int i8 = i7 + 1;
                if (i7 >= 5) {
                    break;
                }
                try {
                    zipFile = new ZipFile(new File(str2), 1);
                    break;
                } catch (IOException unused) {
                    i7 = i8;
                }
            }
            if (zipFile != null) {
                int i9 = 0;
                while (true) {
                    int i10 = i9 + 1;
                    if (i9 < 5) {
                        for (String str3 : strArr) {
                            StringBuilder sb = new StringBuilder("lib");
                            char c6 = File.separatorChar;
                            sb.append(c6);
                            sb.append(str3);
                            sb.append(c6);
                            sb.append(str);
                            String sb2 = sb.toString();
                            uVar.m("Looking for %s in APK %s...", sb2, str2);
                            ZipEntry entry = zipFile.getEntry(sb2);
                            if (entry != null) {
                                A.c cVar = new A.c(9, false);
                                cVar.f4p = zipFile;
                                cVar.f5q = entry;
                                return cVar;
                            }
                        }
                        i9 = i10;
                    } else {
                        try {
                            zipFile.close();
                            break;
                        } catch (IOException unused2) {
                        }
                    }
                }
            }
            i6++;
        }
    }

    public static String p(Context context, Uri uri, String str, String[] strArr) {
        Throwable th;
        Cursor cursor = null;
        try {
            Cursor query = context.getContentResolver().query(uri, new String[]{"_data"}, str, strArr, null);
            if (query != null) {
                try {
                    if (query.moveToFirst()) {
                        String string = query.getString(query.getColumnIndexOrThrow("_data"));
                        query.close();
                        return string;
                    }
                } catch (Throwable th2) {
                    th = th2;
                    cursor = query;
                    if (cursor != null) {
                        cursor.close();
                        throw th;
                    }
                    throw th;
                }
            }
            if (query != null) {
                query.close();
            }
            return null;
        } catch (Throwable th3) {
            th = th3;
        }
    }

    public static String[] q(Context context, String str) {
        StringBuilder sb = new StringBuilder("lib");
        char c6 = File.separatorChar;
        sb.append(c6);
        sb.append("([^\\");
        sb.append(c6);
        sb.append("]*)");
        sb.append(c6);
        sb.append(str);
        Pattern compile = Pattern.compile(sb.toString());
        HashSet hashSet = new HashSet();
        for (String str2 : r(context)) {
            try {
                Enumeration<? extends ZipEntry> entries = new ZipFile(new File(str2), 1).entries();
                while (entries.hasMoreElements()) {
                    Matcher matcher = compile.matcher(entries.nextElement().getName());
                    if (matcher.matches()) {
                        hashSet.add(matcher.group(1));
                    }
                }
            } catch (IOException unused) {
            }
        }
        return (String[]) hashSet.toArray(new String[hashSet.size()]);
    }

    public static String[] r(Context context) {
        ApplicationInfo applicationInfo = context.getApplicationInfo();
        String[] strArr = applicationInfo.splitSourceDirs;
        if (strArr != null && strArr.length != 0) {
            String[] strArr2 = new String[strArr.length + 1];
            strArr2[0] = applicationInfo.sourceDir;
            System.arraycopy(strArr, 0, strArr2, 1, strArr.length);
            return strArr2;
        }
        return new String[]{applicationInfo.sourceDir};
    }

    @Override // W2.k
    public Object a(String str, Provider provider) {
        switch (this.o) {
            case 19:
                if (provider == null) {
                    return KeyAgreement.getInstance(str);
                }
                return KeyAgreement.getInstance(str, provider);
            case XMLReaderUtils.DEFAULT_MAX_ENTITY_EXPANSIONS /* 20 */:
                if (provider == null) {
                    return KeyPairGenerator.getInstance(str);
                }
                return KeyPairGenerator.getInstance(str, provider);
            default:
                if (provider == null) {
                    return MessageDigest.getInstance(str);
                }
                return MessageDigest.getInstance(str, provider);
        }
    }

    @Override // S0.g
    public InterfaceC0878A b() {
        return new s(-9223372036854775807L);
    }

    @Override // U0.j
    public l c(C0123p c0123p) {
        throw new IllegalStateException("This SubtitleParser.Factory doesn't support any formats.");
    }

    @Override // X3.a
    public int d(int i6) {
        switch (this.o) {
            case 22:
                return i6 / 2;
            default:
                return i6 * 2;
        }
    }

    @Override // X3.a
    public void e(ShortBuffer shortBuffer, ShortBuffer shortBuffer2) {
        int i6;
        switch (this.o) {
            case 22:
                int min = Math.min(shortBuffer.remaining() / 2, shortBuffer2.remaining());
                for (int i7 = 0; i7 < min; i7++) {
                    int i8 = shortBuffer.get() + 32768;
                    int i9 = shortBuffer.get() + 32768;
                    int i10 = 65535;
                    if (i8 >= 32768 && i9 >= 32768) {
                        i6 = (((i8 + i9) * 2) - ((i8 * i9) / 32768)) - 65535;
                    } else {
                        i6 = (i8 * i9) / 32768;
                    }
                    if (i6 != 65536) {
                        i10 = i6;
                    }
                    shortBuffer2.put((short) (i10 - 32768));
                }
                return;
            default:
                int min2 = Math.min(shortBuffer.remaining(), shortBuffer2.remaining() / 2);
                for (int i11 = 0; i11 < min2; i11++) {
                    short s3 = shortBuffer.get();
                    shortBuffer2.put(s3);
                    shortBuffer2.put(s3);
                }
                return;
        }
    }

    @Override // M4.d
    public void f(ByteBuffer byteBuffer, E4.g gVar) {
        x.f1745b.getClass();
        x.c(byteBuffer);
    }

    @Override // U0.j
    public boolean g(C0123p c0123p) {
        return false;
    }

    /* JADX WARN: Type inference failed for: r0v0, types: [java.lang.Object, e2.a] */
    @Override // f5.InterfaceC0446a
    public Object get() {
        ?? obj = new Object();
        HashMap hashMap = new HashMap();
        Set set = Collections.EMPTY_SET;
        if (set != null) {
            hashMap.put(S1.d.o, new C0260c(30000L, 86400000L, set));
            if (set != null) {
                hashMap.put(S1.d.f2711q, new C0260c(1000L, 86400000L, set));
                if (set != null) {
                    Set unmodifiableSet = Collections.unmodifiableSet(new HashSet(Arrays.asList(b2.d.f5286p)));
                    if (unmodifiableSet != null) {
                        hashMap.put(S1.d.f2710p, new C0260c(86400000L, 86400000L, unmodifiableSet));
                        if (hashMap.keySet().size() >= S1.d.values().length) {
                            new HashMap();
                            return new C0259b(obj, hashMap);
                        }
                        throw new IllegalStateException("Not all priorities have been configured");
                    }
                    throw new NullPointerException("Null flags");
                }
                throw new NullPointerException("Null flags");
            }
            throw new NullPointerException("Null flags");
        }
        throw new NullPointerException("Null flags");
    }

    @Override // S0.g
    public long h(p pVar) {
        return -1L;
    }

    @Override // U0.j
    public int i(C0123p c0123p) {
        return 1;
    }

    public String m(List list) {
        q5.h.e(list, "list");
        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
        ObjectOutputStream objectOutputStream = new ObjectOutputStream(byteArrayOutputStream);
        objectOutputStream.writeObject(list);
        objectOutputStream.flush();
        String encodeToString = Base64.encodeToString(byteArrayOutputStream.toByteArray(), 0);
        q5.h.d(encodeToString, "encodeToString(...)");
        return encodeToString;
    }

    @Override // M4.n
    public void onMethodCall(m mVar, o oVar) {
        switch (this.o) {
            case 7:
                ((L4.j) oVar).b(null);
                return;
            default:
                ((L4.j) oVar).b(null);
                return;
        }
    }

    public /* synthetic */ e(Object obj, int i6) {
        this.o = i6;
    }

    public e(i iVar) {
        this.o = 10;
        new CopyOnWriteArrayList();
    }

    @Override // S0.g
    public void j(long j6) {
    }
}
