package m3;

import Q2.n;
import android.content.Context;
import b3.C0277q;
import b3.InterfaceC0264d;
import com.google.firebase.messaging.FirebaseMessagingRegistrar;
import java.util.concurrent.Executor;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* loaded from: classes.dex */
public final /* synthetic */ class b implements InterfaceC0264d {
    public final /* synthetic */ int o;

    /* renamed from: p, reason: collision with root package name */
    public final /* synthetic */ C0277q f8676p;

    public /* synthetic */ b(C0277q c0277q, int i6) {
        this.o = i6;
        this.f8676p = c0277q;
    }

    @Override // b3.InterfaceC0264d
    public final Object b(n nVar) {
        switch (this.o) {
            case 0:
                return new d((Context) nVar.a(Context.class), ((Y2.g) nVar.a(Y2.g.class)).g(), nVar.c(C0277q.a(e.class)), nVar.e(x3.b.class), (Executor) nVar.b(this.f8676p));
            default:
                return FirebaseMessagingRegistrar.a(this.f8676p, nVar);
        }
    }
}
