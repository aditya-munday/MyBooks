package R2;

import Q2.s;
import V2.O;
import V2.r0;
import java.security.GeneralSecurityException;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* loaded from: classes.dex */
public abstract class k {

    /* renamed from: a, reason: collision with root package name */
    public static final Q2.j f2333a;

    /* renamed from: b, reason: collision with root package name */
    public static final Q2.i f2334b;

    /* renamed from: c, reason: collision with root package name */
    public static final Q2.b f2335c;

    /* renamed from: d, reason: collision with root package name */
    public static final Q2.a f2336d;

    static {
        X2.a b6 = s.b("type.googleapis.com/google.crypto.tink.HmacKey");
        f2333a = new Q2.j(j.class);
        f2334b = new Q2.i(b6);
        f2335c = new Q2.b(i.class);
        f2336d = new Q2.a(b6, new G5.a(27));
    }

    public static c a(O o) {
        int ordinal = o.ordinal();
        if (ordinal != 1) {
            if (ordinal != 2) {
                if (ordinal != 3) {
                    if (ordinal != 4) {
                        if (ordinal == 5) {
                            return c.f2311h;
                        }
                        throw new GeneralSecurityException("Unable to parse HashType: " + o.a());
                    }
                    return c.f2314k;
                }
                return c.f2312i;
            }
            return c.f2313j;
        }
        return c.f2310g;
    }

    public static c b(r0 r0Var) {
        int ordinal = r0Var.ordinal();
        if (ordinal != 1) {
            if (ordinal != 2) {
                if (ordinal != 3) {
                    if (ordinal == 4) {
                        return c.f2316m;
                    }
                    throw new GeneralSecurityException("Unable to parse OutputPrefixType: " + r0Var.b());
                }
                return c.o;
            }
            return c.f2317n;
        }
        return c.f2315l;
    }
}
