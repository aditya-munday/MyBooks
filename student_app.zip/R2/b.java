package R2;

import V2.C0137b;
import V2.C0139d;
import V2.C0141f;
import V2.O;
import V2.Q;
import V2.S;
import V2.T;
import V2.U;
import V2.V;
import V2.X;
import W2.p;
import com.google.crypto.tink.shaded.protobuf.AbstractC0363a;
import com.google.crypto.tink.shaded.protobuf.AbstractC0370h;
import com.google.crypto.tink.shaded.protobuf.C0376n;
import java.security.GeneralSecurityException;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* loaded from: classes.dex */
public final class b extends Q2.d {
    public static final Q2.k e = new Q2.k(a.class, new G5.a(24));

    /* renamed from: f, reason: collision with root package name */
    public static final Q2.k f2305f = new Q2.k(i.class, new G5.a(26));

    /* renamed from: d, reason: collision with root package name */
    public final /* synthetic */ int f2306d = 1;

    public /* synthetic */ b(Class cls, K2.g[] gVarArr) {
        super(cls, gVarArr);
    }

    public static Q2.c h(int i6, int i7, O o, int i8) {
        S B6 = T.B();
        U B7 = V.B();
        B7.e();
        V.w((V) B7.f5798p, o);
        B7.e();
        V.x((V) B7.f5798p, i7);
        V v6 = (V) B7.b();
        B6.e();
        T.w((T) B6.f5798p, v6);
        B6.e();
        T.x((T) B6.f5798p, i6);
        return new Q2.c((T) B6.b(), i8);
    }

    public static void i(C0141f c0141f) {
        if (c0141f.y() >= 10) {
            if (c0141f.y() <= 16) {
                return;
            } else {
                throw new GeneralSecurityException("tag size too long");
            }
        }
        throw new GeneralSecurityException("tag size too short");
    }

    public static void j(V v6) {
        if (v6.A() >= 10) {
            int ordinal = v6.z().ordinal();
            if (ordinal != 1) {
                if (ordinal != 2) {
                    if (ordinal != 3) {
                        if (ordinal != 4) {
                            if (ordinal == 5) {
                                if (v6.A() > 28) {
                                    throw new GeneralSecurityException("tag size too big");
                                }
                                return;
                            }
                            throw new GeneralSecurityException("unknown hash type");
                        }
                        if (v6.A() > 64) {
                            throw new GeneralSecurityException("tag size too big");
                        }
                        return;
                    }
                    if (v6.A() > 32) {
                        throw new GeneralSecurityException("tag size too big");
                    }
                    return;
                }
                if (v6.A() > 48) {
                    throw new GeneralSecurityException("tag size too big");
                }
                return;
            }
            if (v6.A() <= 20) {
                return;
            } else {
                throw new GeneralSecurityException("tag size too big");
            }
        }
        throw new GeneralSecurityException("tag size too small");
    }

    @Override // Q2.d
    public int a() {
        switch (this.f2306d) {
            case 1:
                return 2;
            default:
                return super.a();
        }
    }

    @Override // Q2.d
    public final String b() {
        switch (this.f2306d) {
            case 0:
                return "type.googleapis.com/google.crypto.tink.AesCmacKey";
            default:
                return "type.googleapis.com/google.crypto.tink.HmacKey";
        }
    }

    @Override // Q2.d
    public final D0.e d() {
        switch (this.f2306d) {
            case 0:
                return new K2.h(C0139d.class);
            default:
                return new K2.h(this);
        }
    }

    @Override // Q2.d
    public final X e() {
        switch (this.f2306d) {
            case 0:
                return X.f3264q;
            default:
                return X.f3264q;
        }
    }

    @Override // Q2.d
    public final AbstractC0363a f(AbstractC0370h abstractC0370h) {
        switch (this.f2306d) {
            case 0:
                return C0137b.D(abstractC0370h, C0376n.a());
            default:
                return Q.E(abstractC0370h, C0376n.a());
        }
    }

    @Override // Q2.d
    public final void g(AbstractC0363a abstractC0363a) {
        switch (this.f2306d) {
            case 0:
                C0137b c0137b = (C0137b) abstractC0363a;
                p.c(c0137b.B());
                if (c0137b.z().size() == 32) {
                    i(c0137b.A());
                    return;
                }
                throw new GeneralSecurityException("AesCmacKey size wrong, must be 32 bytes");
            default:
                Q q6 = (Q) abstractC0363a;
                p.c(q6.C());
                if (q6.A().size() >= 16) {
                    j(q6.B());
                    return;
                }
                throw new GeneralSecurityException("key too short");
        }
    }

    public b() {
        super(Q.class, new K2.g(J2.j.class, 11));
    }
}
