package Q;

import java.util.LinkedHashMap;
import java.util.LinkedHashSet;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* loaded from: classes.dex */
public final class a {

    /* renamed from: a, reason: collision with root package name */
    public final b f2037a = new Object();

    /* renamed from: b, reason: collision with root package name */
    public final LinkedHashMap f2038b = new LinkedHashMap();

    /* renamed from: c, reason: collision with root package name */
    public final LinkedHashSet f2039c = new LinkedHashSet();

    /* renamed from: d, reason: collision with root package name */
    public volatile boolean f2040d;
}
