package V2;

import com.google.crypto.tink.shaded.protobuf.AbstractC0370h;
import com.google.crypto.tink.shaded.protobuf.AbstractC0381t;
import com.google.crypto.tink.shaded.protobuf.AbstractC0383v;
import com.google.crypto.tink.shaded.protobuf.C0376n;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* renamed from: V2.h, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0143h extends AbstractC0383v {
    public static final int AES_CTR_KEY_FIELD_NUMBER = 2;
    private static final C0143h DEFAULT_INSTANCE;
    public static final int HMAC_KEY_FIELD_NUMBER = 3;
    private static volatile com.google.crypto.tink.shaded.protobuf.W PARSER = null;
    public static final int VERSION_FIELD_NUMBER = 1;
    private C0147l aesCtrKey_;
    private Q hmacKey_;
    private int version_;

    /* JADX WARN: Type inference failed for: r0v0, types: [V2.h, com.google.crypto.tink.shaded.protobuf.v] */
    static {
        ?? abstractC0383v = new AbstractC0383v();
        DEFAULT_INSTANCE = abstractC0383v;
        AbstractC0383v.t(C0143h.class, abstractC0383v);
    }

    public static C0142g C() {
        return (C0142g) DEFAULT_INSTANCE.h();
    }

    public static C0143h D(AbstractC0370h abstractC0370h, C0376n c0376n) {
        return (C0143h) AbstractC0383v.r(DEFAULT_INSTANCE, abstractC0370h, c0376n);
    }

    public static void w(C0143h c0143h) {
        c0143h.version_ = 0;
    }

    public static void x(C0143h c0143h, C0147l c0147l) {
        c0143h.getClass();
        c0147l.getClass();
        c0143h.aesCtrKey_ = c0147l;
    }

    public static void y(C0143h c0143h, Q q6) {
        c0143h.getClass();
        q6.getClass();
        c0143h.hmacKey_ = q6;
    }

    public final Q A() {
        Q q6 = this.hmacKey_;
        if (q6 == null) {
            return Q.z();
        }
        return q6;
    }

    public final int B() {
        return this.version_;
    }

    /* JADX WARN: Type inference failed for: r4v14, types: [java.lang.Object, com.google.crypto.tink.shaded.protobuf.W] */
    @Override // com.google.crypto.tink.shaded.protobuf.AbstractC0383v
    public final Object i(int i6) {
        com.google.crypto.tink.shaded.protobuf.W w6;
        switch (L.i.b(i6)) {
            case 0:
                return (byte) 1;
            case 1:
                return null;
            case 2:
                return new com.google.crypto.tink.shaded.protobuf.a0(DEFAULT_INSTANCE, "\u0000\u0003\u0000\u0000\u0001\u0003\u0003\u0000\u0000\u0000\u0001\u000b\u0002\t\u0003\t", new Object[]{"version_", "aesCtrKey_", "hmacKey_"});
            case 3:
                return new AbstractC0383v();
            case 4:
                return new AbstractC0381t(DEFAULT_INSTANCE);
            case 5:
                return DEFAULT_INSTANCE;
            case 6:
                com.google.crypto.tink.shaded.protobuf.W w7 = PARSER;
                if (w7 == null) {
                    synchronized (C0143h.class) {
                        try {
                            com.google.crypto.tink.shaded.protobuf.W w8 = PARSER;
                            w6 = w8;
                            if (w8 == null) {
                                ?? obj = new Object();
                                PARSER = obj;
                                w6 = obj;
                            }
                        } catch (Throwable th) {
                            throw th;
                        }
                    }
                    return w6;
                }
                return w7;
            default:
                throw new UnsupportedOperationException();
        }
    }

    public final C0147l z() {
        C0147l c0147l = this.aesCtrKey_;
        if (c0147l == null) {
            return C0147l.z();
        }
        return c0147l;
    }
}
