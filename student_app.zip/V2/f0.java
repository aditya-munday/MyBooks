package V2;

import com.google.crypto.tink.shaded.protobuf.AbstractC0381t;
import com.google.crypto.tink.shaded.protobuf.AbstractC0383v;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* loaded from: classes.dex */
public final class f0 extends AbstractC0383v {
    private static final f0 DEFAULT_INSTANCE;
    public static final int KEY_DATA_FIELD_NUMBER = 1;
    public static final int KEY_ID_FIELD_NUMBER = 3;
    public static final int OUTPUT_PREFIX_TYPE_FIELD_NUMBER = 4;
    private static volatile com.google.crypto.tink.shaded.protobuf.W PARSER = null;
    public static final int STATUS_FIELD_NUMBER = 2;
    private Y keyData_;
    private int keyId_;
    private int outputPrefixType_;
    private int status_;

    /* JADX WARN: Type inference failed for: r0v0, types: [com.google.crypto.tink.shaded.protobuf.v, V2.f0] */
    static {
        ?? abstractC0383v = new AbstractC0383v();
        DEFAULT_INSTANCE = abstractC0383v;
        AbstractC0383v.t(f0.class, abstractC0383v);
    }

    public static e0 F() {
        return (e0) DEFAULT_INSTANCE.h();
    }

    public static void w(f0 f0Var, Y y) {
        f0Var.getClass();
        f0Var.keyData_ = y;
    }

    public static void x(f0 f0Var, r0 r0Var) {
        f0Var.getClass();
        f0Var.outputPrefixType_ = r0Var.b();
    }

    public static void y(f0 f0Var) {
        f0Var.getClass();
        f0Var.status_ = Z.f3271q.a();
    }

    public static void z(f0 f0Var, int i6) {
        f0Var.keyId_ = i6;
    }

    public final Y A() {
        Y y = this.keyData_;
        if (y == null) {
            return Y.z();
        }
        return y;
    }

    public final int B() {
        return this.keyId_;
    }

    public final r0 C() {
        r0 a6 = r0.a(this.outputPrefixType_);
        if (a6 == null) {
            return r0.f3281u;
        }
        return a6;
    }

    public final Z D() {
        Z z6;
        int i6 = this.status_;
        if (i6 != 0) {
            if (i6 != 1) {
                if (i6 != 2) {
                    if (i6 != 3) {
                        z6 = null;
                    } else {
                        z6 = Z.f3273s;
                    }
                } else {
                    z6 = Z.f3272r;
                }
            } else {
                z6 = Z.f3271q;
            }
        } else {
            z6 = Z.f3270p;
        }
        if (z6 == null) {
            return Z.f3274t;
        }
        return z6;
    }

    public final boolean E() {
        if (this.keyData_ != null) {
            return true;
        }
        return false;
    }

    /* JADX WARN: Type inference failed for: r4v14, types: [java.lang.Object, com.google.crypto.tink.shaded.protobuf.W] */
    @Override // com.google.crypto.tink.shaded.protobuf.AbstractC0383v
    public final Object i(int i6) {
        com.google.crypto.tink.shaded.protobuf.W w6;
        switch (L.i.b(i6)) {
            case 0:
                return (byte) 1;
            case 1:
                return null;
            case 2:
                return new com.google.crypto.tink.shaded.protobuf.a0(DEFAULT_INSTANCE, "\u0000\u0004\u0000\u0000\u0001\u0004\u0004\u0000\u0000\u0000\u0001\t\u0002\f\u0003\u000b\u0004\f", new Object[]{"keyData_", "status_", "keyId_", "outputPrefixType_"});
            case 3:
                return new AbstractC0383v();
            case 4:
                return new AbstractC0381t(DEFAULT_INSTANCE);
            case 5:
                return DEFAULT_INSTANCE;
            case 6:
                com.google.crypto.tink.shaded.protobuf.W w7 = PARSER;
                if (w7 == null) {
                    synchronized (f0.class) {
                        try {
                            com.google.crypto.tink.shaded.protobuf.W w8 = PARSER;
                            w6 = w8;
                            if (w8 == null) {
                                ?? obj = new Object();
                                PARSER = obj;
                                w6 = obj;
                            }
                        } catch (Throwable th) {
                            throw th;
                        }
                    }
                    return w6;
                }
                return w7;
            default:
                throw new UnsupportedOperationException();
        }
    }
}
