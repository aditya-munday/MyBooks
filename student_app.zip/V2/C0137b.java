package V2;

import com.google.crypto.tink.shaded.protobuf.AbstractC0370h;
import com.google.crypto.tink.shaded.protobuf.AbstractC0381t;
import com.google.crypto.tink.shaded.protobuf.AbstractC0383v;
import com.google.crypto.tink.shaded.protobuf.C0369g;
import com.google.crypto.tink.shaded.protobuf.C0376n;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* renamed from: V2.b, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0137b extends AbstractC0383v {
    private static final C0137b DEFAULT_INSTANCE;
    public static final int KEY_VALUE_FIELD_NUMBER = 2;
    public static final int PARAMS_FIELD_NUMBER = 3;
    private static volatile com.google.crypto.tink.shaded.protobuf.W PARSER = null;
    public static final int VERSION_FIELD_NUMBER = 1;
    private AbstractC0370h keyValue_ = AbstractC0370h.f5757p;
    private C0141f params_;
    private int version_;

    static {
        C0137b c0137b = new C0137b();
        DEFAULT_INSTANCE = c0137b;
        AbstractC0383v.t(C0137b.class, c0137b);
    }

    public static C0136a C() {
        return (C0136a) DEFAULT_INSTANCE.h();
    }

    public static C0137b D(AbstractC0370h abstractC0370h, C0376n c0376n) {
        return (C0137b) AbstractC0383v.r(DEFAULT_INSTANCE, abstractC0370h, c0376n);
    }

    public static void w(C0137b c0137b) {
        c0137b.version_ = 0;
    }

    public static void x(C0137b c0137b, C0369g c0369g) {
        c0137b.getClass();
        c0137b.keyValue_ = c0369g;
    }

    public static void y(C0137b c0137b, C0141f c0141f) {
        c0137b.getClass();
        c0141f.getClass();
        c0137b.params_ = c0141f;
    }

    public final C0141f A() {
        C0141f c0141f = this.params_;
        if (c0141f == null) {
            return C0141f.x();
        }
        return c0141f;
    }

    public final int B() {
        return this.version_;
    }

    /* JADX WARN: Type inference failed for: r4v14, types: [java.lang.Object, com.google.crypto.tink.shaded.protobuf.W] */
    @Override // com.google.crypto.tink.shaded.protobuf.AbstractC0383v
    public final Object i(int i6) {
        com.google.crypto.tink.shaded.protobuf.W w6;
        switch (L.i.b(i6)) {
            case 0:
                return (byte) 1;
            case 1:
                return null;
            case 2:
                return new com.google.crypto.tink.shaded.protobuf.a0(DEFAULT_INSTANCE, "\u0000\u0003\u0000\u0000\u0001\u0003\u0003\u0000\u0000\u0000\u0001\u000b\u0002\n\u0003\t", new Object[]{"version_", "keyValue_", "params_"});
            case 3:
                return new C0137b();
            case 4:
                return new AbstractC0381t(DEFAULT_INSTANCE);
            case 5:
                return DEFAULT_INSTANCE;
            case 6:
                com.google.crypto.tink.shaded.protobuf.W w7 = PARSER;
                if (w7 == null) {
                    synchronized (C0137b.class) {
                        try {
                            com.google.crypto.tink.shaded.protobuf.W w8 = PARSER;
                            w6 = w8;
                            if (w8 == null) {
                                ?? obj = new Object();
                                PARSER = obj;
                                w6 = obj;
                            }
                        } catch (Throwable th) {
                            throw th;
                        }
                    }
                    return w6;
                }
                return w7;
            default:
                throw new UnsupportedOperationException();
        }
    }

    public final AbstractC0370h z() {
        return this.keyValue_;
    }
}
