package V2;

import com.google.crypto.tink.shaded.protobuf.AbstractC0370h;
import com.google.crypto.tink.shaded.protobuf.AbstractC0381t;
import com.google.crypto.tink.shaded.protobuf.AbstractC0383v;
import com.google.crypto.tink.shaded.protobuf.C0369g;
import com.google.crypto.tink.shaded.protobuf.C0372j;
import com.google.crypto.tink.shaded.protobuf.C0376n;
import java.io.ByteArrayInputStream;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* loaded from: classes.dex */
public final class N extends AbstractC0383v {
    private static final N DEFAULT_INSTANCE;
    public static final int ENCRYPTED_KEYSET_FIELD_NUMBER = 2;
    public static final int KEYSET_INFO_FIELD_NUMBER = 3;
    private static volatile com.google.crypto.tink.shaded.protobuf.W PARSER;
    private AbstractC0370h encryptedKeyset_ = AbstractC0370h.f5757p;
    private k0 keysetInfo_;

    static {
        N n6 = new N();
        DEFAULT_INSTANCE = n6;
        AbstractC0383v.t(N.class, n6);
    }

    public static N A(ByteArrayInputStream byteArrayInputStream, C0376n c0376n) {
        AbstractC0383v s3 = AbstractC0383v.s(DEFAULT_INSTANCE, new C0372j(byteArrayInputStream), c0376n);
        AbstractC0383v.g(s3);
        return (N) s3;
    }

    public static void w(N n6, C0369g c0369g) {
        n6.getClass();
        n6.encryptedKeyset_ = c0369g;
    }

    public static void x(N n6, k0 k0Var) {
        n6.getClass();
        n6.keysetInfo_ = k0Var;
    }

    public static M z() {
        return (M) DEFAULT_INSTANCE.h();
    }

    /* JADX WARN: Type inference failed for: r4v14, types: [java.lang.Object, com.google.crypto.tink.shaded.protobuf.W] */
    @Override // com.google.crypto.tink.shaded.protobuf.AbstractC0383v
    public final Object i(int i6) {
        com.google.crypto.tink.shaded.protobuf.W w6;
        switch (L.i.b(i6)) {
            case 0:
                return (byte) 1;
            case 1:
                return null;
            case 2:
                return new com.google.crypto.tink.shaded.protobuf.a0(DEFAULT_INSTANCE, "\u0000\u0002\u0000\u0000\u0002\u0003\u0002\u0000\u0000\u0000\u0002\n\u0003\t", new Object[]{"encryptedKeyset_", "keysetInfo_"});
            case 3:
                return new N();
            case 4:
                return new AbstractC0381t(DEFAULT_INSTANCE);
            case 5:
                return DEFAULT_INSTANCE;
            case 6:
                com.google.crypto.tink.shaded.protobuf.W w7 = PARSER;
                if (w7 == null) {
                    synchronized (N.class) {
                        try {
                            com.google.crypto.tink.shaded.protobuf.W w8 = PARSER;
                            w6 = w8;
                            if (w8 == null) {
                                ?? obj = new Object();
                                PARSER = obj;
                                w6 = obj;
                            }
                        } catch (Throwable th) {
                            throw th;
                        }
                    }
                    return w6;
                }
                return w7;
            default:
                throw new UnsupportedOperationException();
        }
    }

    public final AbstractC0370h y() {
        return this.encryptedKeyset_;
    }
}
