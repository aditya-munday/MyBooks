package V2;

import com.google.crypto.tink.shaded.protobuf.AbstractC0370h;
import com.google.crypto.tink.shaded.protobuf.AbstractC0381t;
import com.google.crypto.tink.shaded.protobuf.AbstractC0383v;
import com.google.crypto.tink.shaded.protobuf.C0369g;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* renamed from: V2.l, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0147l extends AbstractC0383v {
    private static final C0147l DEFAULT_INSTANCE;
    public static final int KEY_VALUE_FIELD_NUMBER = 3;
    public static final int PARAMS_FIELD_NUMBER = 2;
    private static volatile com.google.crypto.tink.shaded.protobuf.W PARSER = null;
    public static final int VERSION_FIELD_NUMBER = 1;
    private AbstractC0370h keyValue_ = AbstractC0370h.f5757p;
    private C0151p params_;
    private int version_;

    static {
        C0147l c0147l = new C0147l();
        DEFAULT_INSTANCE = c0147l;
        AbstractC0383v.t(C0147l.class, c0147l);
    }

    public static C0146k D() {
        return (C0146k) DEFAULT_INSTANCE.h();
    }

    public static void w(C0147l c0147l) {
        c0147l.version_ = 0;
    }

    public static void x(C0147l c0147l, C0151p c0151p) {
        c0147l.getClass();
        c0151p.getClass();
        c0147l.params_ = c0151p;
    }

    public static void y(C0147l c0147l, C0369g c0369g) {
        c0147l.getClass();
        c0147l.keyValue_ = c0369g;
    }

    public static C0147l z() {
        return DEFAULT_INSTANCE;
    }

    public final AbstractC0370h A() {
        return this.keyValue_;
    }

    public final C0151p B() {
        C0151p c0151p = this.params_;
        if (c0151p == null) {
            return C0151p.x();
        }
        return c0151p;
    }

    public final int C() {
        return this.version_;
    }

    /* JADX WARN: Type inference failed for: r4v14, types: [java.lang.Object, com.google.crypto.tink.shaded.protobuf.W] */
    @Override // com.google.crypto.tink.shaded.protobuf.AbstractC0383v
    public final Object i(int i6) {
        com.google.crypto.tink.shaded.protobuf.W w6;
        switch (L.i.b(i6)) {
            case 0:
                return (byte) 1;
            case 1:
                return null;
            case 2:
                return new com.google.crypto.tink.shaded.protobuf.a0(DEFAULT_INSTANCE, "\u0000\u0003\u0000\u0000\u0001\u0003\u0003\u0000\u0000\u0000\u0001\u000b\u0002\t\u0003\n", new Object[]{"version_", "params_", "keyValue_"});
            case 3:
                return new C0147l();
            case 4:
                return new AbstractC0381t(DEFAULT_INSTANCE);
            case 5:
                return DEFAULT_INSTANCE;
            case 6:
                com.google.crypto.tink.shaded.protobuf.W w7 = PARSER;
                if (w7 == null) {
                    synchronized (C0147l.class) {
                        try {
                            com.google.crypto.tink.shaded.protobuf.W w8 = PARSER;
                            w6 = w8;
                            if (w8 == null) {
                                ?? obj = new Object();
                                PARSER = obj;
                                w6 = obj;
                            }
                        } catch (Throwable th) {
                            throw th;
                        }
                    }
                    return w6;
                }
                return w7;
            default:
                throw new UnsupportedOperationException();
        }
    }
}
