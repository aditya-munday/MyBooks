package V2;

import com.google.crypto.tink.shaded.protobuf.AbstractC0370h;
import com.google.crypto.tink.shaded.protobuf.AbstractC0381t;
import com.google.crypto.tink.shaded.protobuf.AbstractC0383v;
import com.google.crypto.tink.shaded.protobuf.C0376n;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* renamed from: V2.t, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0154t extends AbstractC0383v {
    private static final C0154t DEFAULT_INSTANCE;
    public static final int KEY_SIZE_FIELD_NUMBER = 2;
    public static final int PARAMS_FIELD_NUMBER = 1;
    private static volatile com.google.crypto.tink.shaded.protobuf.W PARSER;
    private int keySize_;
    private C0156v params_;

    /* JADX WARN: Type inference failed for: r0v0, types: [V2.t, com.google.crypto.tink.shaded.protobuf.v] */
    static {
        ?? abstractC0383v = new AbstractC0383v();
        DEFAULT_INSTANCE = abstractC0383v;
        AbstractC0383v.t(C0154t.class, abstractC0383v);
    }

    public static C0153s A() {
        return (C0153s) DEFAULT_INSTANCE.h();
    }

    public static C0154t B(AbstractC0370h abstractC0370h, C0376n c0376n) {
        return (C0154t) AbstractC0383v.r(DEFAULT_INSTANCE, abstractC0370h, c0376n);
    }

    public static void w(C0154t c0154t, C0156v c0156v) {
        c0154t.getClass();
        c0154t.params_ = c0156v;
    }

    public static void x(C0154t c0154t, int i6) {
        c0154t.keySize_ = i6;
    }

    /* JADX WARN: Type inference failed for: r4v14, types: [java.lang.Object, com.google.crypto.tink.shaded.protobuf.W] */
    @Override // com.google.crypto.tink.shaded.protobuf.AbstractC0383v
    public final Object i(int i6) {
        com.google.crypto.tink.shaded.protobuf.W w6;
        switch (L.i.b(i6)) {
            case 0:
                return (byte) 1;
            case 1:
                return null;
            case 2:
                return new com.google.crypto.tink.shaded.protobuf.a0(DEFAULT_INSTANCE, "\u0000\u0002\u0000\u0000\u0001\u0002\u0002\u0000\u0000\u0000\u0001\t\u0002\u000b", new Object[]{"params_", "keySize_"});
            case 3:
                return new AbstractC0383v();
            case 4:
                return new AbstractC0381t(DEFAULT_INSTANCE);
            case 5:
                return DEFAULT_INSTANCE;
            case 6:
                com.google.crypto.tink.shaded.protobuf.W w7 = PARSER;
                if (w7 == null) {
                    synchronized (C0154t.class) {
                        try {
                            com.google.crypto.tink.shaded.protobuf.W w8 = PARSER;
                            w6 = w8;
                            if (w8 == null) {
                                ?? obj = new Object();
                                PARSER = obj;
                                w6 = obj;
                            }
                        } catch (Throwable th) {
                            throw th;
                        }
                    }
                    return w6;
                }
                return w7;
            default:
                throw new UnsupportedOperationException();
        }
    }

    public final int y() {
        return this.keySize_;
    }

    public final C0156v z() {
        C0156v c0156v = this.params_;
        if (c0156v == null) {
            return C0156v.x();
        }
        return c0156v;
    }
}
