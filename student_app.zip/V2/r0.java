package V2;

import com.google.crypto.tink.shaded.protobuf.InterfaceC0385x;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* loaded from: classes.dex */
public enum r0 implements InterfaceC0385x {
    f3276p(0),
    f3277q(1),
    f3278r(2),
    f3279s(3),
    f3280t(4),
    f3281u(-1);

    public final int o;

    r0(int i6) {
        this.o = i6;
    }

    public static r0 a(int i6) {
        if (i6 != 0) {
            if (i6 != 1) {
                if (i6 != 2) {
                    if (i6 != 3) {
                        if (i6 != 4) {
                            return null;
                        }
                        return f3280t;
                    }
                    return f3279s;
                }
                return f3278r;
            }
            return f3277q;
        }
        return f3276p;
    }

    public final int b() {
        if (this != f3281u) {
            return this.o;
        }
        throw new IllegalArgumentException("Can't get the number of an unknown enum value.");
    }
}
