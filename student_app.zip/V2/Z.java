package V2;

import com.google.crypto.tink.shaded.protobuf.InterfaceC0385x;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* loaded from: classes.dex */
public enum Z implements InterfaceC0385x {
    f3270p(0),
    f3271q(1),
    f3272r(2),
    f3273s(3),
    f3274t(-1);

    public final int o;

    Z(int i6) {
        this.o = i6;
    }

    public final int a() {
        if (this != f3274t) {
            return this.o;
        }
        throw new IllegalArgumentException("Can't get the number of an unknown enum value.");
    }
}
