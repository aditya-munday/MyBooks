package V2;

import com.google.crypto.tink.shaded.protobuf.InterfaceC0385x;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* loaded from: classes.dex */
public enum O implements InterfaceC0385x {
    f3255p(0),
    f3256q(1),
    f3257r(2),
    f3258s(3),
    f3259t(4),
    f3260u(5),
    f3261v(-1);

    public final int o;

    O(int i6) {
        this.o = i6;
    }

    public final int a() {
        if (this != f3261v) {
            return this.o;
        }
        throw new IllegalArgumentException("Can't get the number of an unknown enum value.");
    }
}
