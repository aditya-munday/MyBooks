package V2;

import com.google.crypto.tink.shaded.protobuf.AbstractC0381t;
import com.google.crypto.tink.shaded.protobuf.AbstractC0383v;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* loaded from: classes.dex */
public final class M extends AbstractC0381t implements com.google.crypto.tink.shaded.protobuf.P {
    @Override // com.google.crypto.tink.shaded.protobuf.P
    public final AbstractC0383v a() {
        return this.o;
    }

    public final /* bridge */ /* synthetic */ Object clone() {
        return d();
    }
}
