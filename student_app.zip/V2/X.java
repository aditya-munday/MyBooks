package V2;

import com.google.crypto.tink.shaded.protobuf.InterfaceC0385x;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* loaded from: classes.dex */
public enum X implements InterfaceC0385x {
    f3263p(0),
    f3264q(1),
    f3265r(2),
    f3266s(3),
    f3267t(4),
    f3268u(-1);

    public final int o;

    X(int i6) {
        this.o = i6;
    }
}
