package V2;

import com.google.crypto.tink.shaded.protobuf.AbstractC0381t;
import com.google.crypto.tink.shaded.protobuf.AbstractC0383v;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* loaded from: classes.dex */
public final class K extends AbstractC0381t implements com.google.crypto.tink.shaded.protobuf.P {

    /* renamed from: q, reason: collision with root package name */
    public final /* synthetic */ int f3254q;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public /* synthetic */ K(AbstractC0383v abstractC0383v, int i6) {
        super(abstractC0383v);
        this.f3254q = i6;
    }

    @Override // com.google.crypto.tink.shaded.protobuf.P
    public final AbstractC0383v a() {
        switch (this.f3254q) {
            case 0:
                return this.o;
            case 1:
                return this.o;
            case 2:
                return this.o;
            case 3:
                return this.o;
            case 4:
                return this.o;
            default:
                return this.o;
        }
    }

    public final /* bridge */ /* synthetic */ Object clone() {
        switch (this.f3254q) {
            case 0:
                return d();
            case 1:
                return d();
            case 2:
                return d();
            case 3:
                return d();
            case 4:
                return d();
            default:
                return d();
        }
    }
}
