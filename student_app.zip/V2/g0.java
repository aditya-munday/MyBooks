package V2;

import com.google.crypto.tink.shaded.protobuf.AbstractC0364b;
import com.google.crypto.tink.shaded.protobuf.AbstractC0381t;
import com.google.crypto.tink.shaded.protobuf.AbstractC0383v;
import com.google.crypto.tink.shaded.protobuf.C0372j;
import com.google.crypto.tink.shaded.protobuf.C0376n;
import com.google.crypto.tink.shaded.protobuf.InterfaceC0386y;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.util.List;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* loaded from: classes.dex */
public final class g0 extends AbstractC0383v {
    private static final g0 DEFAULT_INSTANCE;
    public static final int KEY_FIELD_NUMBER = 2;
    private static volatile com.google.crypto.tink.shaded.protobuf.W PARSER = null;
    public static final int PRIMARY_KEY_ID_FIELD_NUMBER = 1;
    private InterfaceC0386y key_ = com.google.crypto.tink.shaded.protobuf.Z.f5735r;
    private int primaryKeyId_;

    static {
        g0 g0Var = new g0();
        DEFAULT_INSTANCE = g0Var;
        AbstractC0383v.t(g0.class, g0Var);
    }

    public static d0 C() {
        return (d0) DEFAULT_INSTANCE.h();
    }

    public static g0 D(ByteArrayInputStream byteArrayInputStream, C0376n c0376n) {
        AbstractC0383v s3 = AbstractC0383v.s(DEFAULT_INSTANCE, new C0372j(byteArrayInputStream), c0376n);
        AbstractC0383v.g(s3);
        return (g0) s3;
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r6v0, types: [T1.b, java.lang.Object] */
    public static g0 E(byte[] bArr, C0376n c0376n) {
        g0 g0Var = DEFAULT_INSTANCE;
        int length = bArr.length;
        AbstractC0383v q6 = g0Var.q();
        try {
            com.google.crypto.tink.shaded.protobuf.Y y = com.google.crypto.tink.shaded.protobuf.Y.f5732c;
            y.getClass();
            com.google.crypto.tink.shaded.protobuf.b0 a6 = y.a(q6.getClass());
            ?? obj = new Object();
            c0376n.getClass();
            a6.f(q6, bArr, 0, length, obj);
            a6.b(q6);
            AbstractC0383v.g(q6);
            return (g0) q6;
        } catch (com.google.crypto.tink.shaded.protobuf.B e) {
            if (e.o) {
                throw new IOException(e.getMessage(), e);
            }
            throw e;
        } catch (com.google.crypto.tink.shaded.protobuf.d0 e6) {
            throw new IOException(e6.getMessage());
        } catch (IOException e7) {
            if (e7.getCause() instanceof com.google.crypto.tink.shaded.protobuf.B) {
                throw ((com.google.crypto.tink.shaded.protobuf.B) e7.getCause());
            }
            throw new IOException(e7.getMessage(), e7);
        } catch (IndexOutOfBoundsException unused) {
            throw com.google.crypto.tink.shaded.protobuf.B.g();
        }
    }

    public static void w(g0 g0Var, int i6) {
        g0Var.primaryKeyId_ = i6;
    }

    public static void x(g0 g0Var, f0 f0Var) {
        int i6;
        g0Var.getClass();
        InterfaceC0386y interfaceC0386y = g0Var.key_;
        if (!((AbstractC0364b) interfaceC0386y).o) {
            int size = interfaceC0386y.size();
            if (size == 0) {
                i6 = 10;
            } else {
                i6 = size * 2;
            }
            g0Var.key_ = interfaceC0386y.f(i6);
        }
        g0Var.key_.add(f0Var);
    }

    public final List A() {
        return this.key_;
    }

    public final int B() {
        return this.primaryKeyId_;
    }

    /* JADX WARN: Type inference failed for: r4v14, types: [java.lang.Object, com.google.crypto.tink.shaded.protobuf.W] */
    @Override // com.google.crypto.tink.shaded.protobuf.AbstractC0383v
    public final Object i(int i6) {
        com.google.crypto.tink.shaded.protobuf.W w6;
        switch (L.i.b(i6)) {
            case 0:
                return (byte) 1;
            case 1:
                return null;
            case 2:
                return new com.google.crypto.tink.shaded.protobuf.a0(DEFAULT_INSTANCE, "\u0000\u0002\u0000\u0000\u0001\u0002\u0002\u0000\u0001\u0000\u0001\u000b\u0002\u001b", new Object[]{"primaryKeyId_", "key_", f0.class});
            case 3:
                return new g0();
            case 4:
                return new AbstractC0381t(DEFAULT_INSTANCE);
            case 5:
                return DEFAULT_INSTANCE;
            case 6:
                com.google.crypto.tink.shaded.protobuf.W w7 = PARSER;
                if (w7 == null) {
                    synchronized (g0.class) {
                        try {
                            com.google.crypto.tink.shaded.protobuf.W w8 = PARSER;
                            w6 = w8;
                            if (w8 == null) {
                                ?? obj = new Object();
                                PARSER = obj;
                                w6 = obj;
                            }
                        } catch (Throwable th) {
                            throw th;
                        }
                    }
                    return w6;
                }
                return w7;
            default:
                throw new UnsupportedOperationException();
        }
    }

    public final f0 y(int i6) {
        return (f0) this.key_.get(i6);
    }

    public final int z() {
        return this.key_.size();
    }
}
