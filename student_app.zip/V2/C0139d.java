package V2;

import com.google.crypto.tink.shaded.protobuf.AbstractC0370h;
import com.google.crypto.tink.shaded.protobuf.AbstractC0381t;
import com.google.crypto.tink.shaded.protobuf.AbstractC0383v;
import com.google.crypto.tink.shaded.protobuf.C0376n;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* renamed from: V2.d, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0139d extends AbstractC0383v {
    private static final C0139d DEFAULT_INSTANCE;
    public static final int KEY_SIZE_FIELD_NUMBER = 1;
    public static final int PARAMS_FIELD_NUMBER = 2;
    private static volatile com.google.crypto.tink.shaded.protobuf.W PARSER;
    private int keySize_;
    private C0141f params_;

    /* JADX WARN: Type inference failed for: r0v0, types: [V2.d, com.google.crypto.tink.shaded.protobuf.v] */
    static {
        ?? abstractC0383v = new AbstractC0383v();
        DEFAULT_INSTANCE = abstractC0383v;
        AbstractC0383v.t(C0139d.class, abstractC0383v);
    }

    public static C0138c A() {
        return (C0138c) DEFAULT_INSTANCE.h();
    }

    public static C0139d B(AbstractC0370h abstractC0370h, C0376n c0376n) {
        return (C0139d) AbstractC0383v.r(DEFAULT_INSTANCE, abstractC0370h, c0376n);
    }

    public static void w(C0139d c0139d) {
        c0139d.keySize_ = 32;
    }

    public static void x(C0139d c0139d, C0141f c0141f) {
        c0139d.getClass();
        c0139d.params_ = c0141f;
    }

    /* JADX WARN: Type inference failed for: r4v14, types: [java.lang.Object, com.google.crypto.tink.shaded.protobuf.W] */
    @Override // com.google.crypto.tink.shaded.protobuf.AbstractC0383v
    public final Object i(int i6) {
        com.google.crypto.tink.shaded.protobuf.W w6;
        switch (L.i.b(i6)) {
            case 0:
                return (byte) 1;
            case 1:
                return null;
            case 2:
                return new com.google.crypto.tink.shaded.protobuf.a0(DEFAULT_INSTANCE, "\u0000\u0002\u0000\u0000\u0001\u0002\u0002\u0000\u0000\u0000\u0001\u000b\u0002\t", new Object[]{"keySize_", "params_"});
            case 3:
                return new AbstractC0383v();
            case 4:
                return new AbstractC0381t(DEFAULT_INSTANCE);
            case 5:
                return DEFAULT_INSTANCE;
            case 6:
                com.google.crypto.tink.shaded.protobuf.W w7 = PARSER;
                if (w7 == null) {
                    synchronized (C0139d.class) {
                        try {
                            com.google.crypto.tink.shaded.protobuf.W w8 = PARSER;
                            w6 = w8;
                            if (w8 == null) {
                                ?? obj = new Object();
                                PARSER = obj;
                                w6 = obj;
                            }
                        } catch (Throwable th) {
                            throw th;
                        }
                    }
                    return w6;
                }
                return w7;
            default:
                throw new UnsupportedOperationException();
        }
    }

    public final int y() {
        return this.keySize_;
    }

    public final C0141f z() {
        C0141f c0141f = this.params_;
        if (c0141f == null) {
            return C0141f.x();
        }
        return c0141f;
    }
}
