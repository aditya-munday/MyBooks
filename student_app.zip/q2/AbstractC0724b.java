package q2;

import android.content.Context;
import android.content.pm.PackageManager;
import android.os.Build;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* renamed from: q2.b, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public abstract class AbstractC0724b {

    /* renamed from: a, reason: collision with root package name */
    public static final char[] f9251a = {'0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'A', 'B', 'C', 'D', 'E', 'F'};

    /* renamed from: b, reason: collision with root package name */
    public static Boolean f9252b;

    /* renamed from: c, reason: collision with root package name */
    public static Boolean f9253c;

    /* renamed from: d, reason: collision with root package name */
    public static Boolean f9254d;
    public static Boolean e;

    public static boolean a() {
        if (Build.VERSION.SDK_INT >= 26) {
            return true;
        }
        return false;
    }

    public static boolean b(Context context) {
        PackageManager packageManager = context.getPackageManager();
        if (f9252b == null) {
            f9252b = Boolean.valueOf(packageManager.hasSystemFeature("android.hardware.type.watch"));
        }
        f9252b.booleanValue();
        if (f9253c == null) {
            f9253c = Boolean.valueOf(context.getPackageManager().hasSystemFeature("cn.google"));
        }
        if (f9253c.booleanValue()) {
            if (!a() || Build.VERSION.SDK_INT >= 30) {
                return true;
            }
            return false;
        }
        return false;
    }
}
