package q2;

import java.util.regex.Pattern;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* renamed from: q2.d, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public abstract class AbstractC0726d {

    /* renamed from: a, reason: collision with root package name */
    public static final /* synthetic */ int f9257a = 0;

    static {
        Pattern.compile("\\$\\{(.*?)\\}");
    }
}
