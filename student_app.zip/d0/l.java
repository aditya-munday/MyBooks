package d0;

import E2.I;
import S.C0123p;
import android.net.Uri;
import java.util.ArrayList;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* loaded from: classes.dex */
public final class l extends m {

    /* renamed from: t, reason: collision with root package name */
    public final j f5937t;

    /* renamed from: u, reason: collision with root package name */
    public final X2.b f5938u;

    public l(C0123p c0123p, I i6, r rVar, ArrayList arrayList) {
        super(c0123p, i6, rVar, arrayList);
        j jVar;
        Uri.parse(((C0391b) i6.get(0)).f5891a);
        long j6 = rVar.e;
        if (j6 <= 0) {
            jVar = null;
        } else {
            jVar = new j(rVar.f5954d, j6, null);
        }
        this.f5937t = jVar;
        this.f5938u = jVar == null ? new X2.b(new j(0L, -1L, null)) : null;
    }

    @Override // d0.m
    public final String a() {
        return null;
    }

    @Override // d0.m
    public final c0.j d() {
        return this.f5938u;
    }

    @Override // d0.m
    public final j f() {
        return this.f5937t;
    }
}
