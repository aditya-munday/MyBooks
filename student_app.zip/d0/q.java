package d0;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* loaded from: classes.dex */
public final class q {

    /* renamed from: a, reason: collision with root package name */
    public final long f5952a;

    /* renamed from: b, reason: collision with root package name */
    public final long f5953b;

    public q(long j6, long j7) {
        this.f5952a = j6;
        this.f5953b = j7;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj != null && q.class == obj.getClass()) {
            q qVar = (q) obj;
            if (this.f5952a == qVar.f5952a && this.f5953b == qVar.f5953b) {
                return true;
            }
        }
        return false;
    }

    public final int hashCode() {
        return (((int) this.f5952a) * 31) + ((int) this.f5953b);
    }
}
