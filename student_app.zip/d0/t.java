package d0;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* loaded from: classes.dex */
public final class t {

    /* renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f5958a;

    /* renamed from: b, reason: collision with root package name */
    public final String f5959b;

    /* renamed from: c, reason: collision with root package name */
    public final String f5960c;

    public /* synthetic */ t(String str, int i6, String str2) {
        this.f5958a = i6;
        this.f5959b = str;
        this.f5960c = str2;
    }

    public String toString() {
        switch (this.f5958a) {
            case 0:
                return this.f5959b + ", " + this.f5960c;
            default:
                return super.toString();
        }
    }
}
