package d0;

import V.C;
import java.math.RoundingMode;
import java.util.List;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* loaded from: classes.dex */
public abstract class n extends s {

    /* renamed from: d, reason: collision with root package name */
    public final long f5943d;
    public final long e;

    /* renamed from: f, reason: collision with root package name */
    public final List f5944f;

    /* renamed from: g, reason: collision with root package name */
    public final long f5945g;

    /* renamed from: h, reason: collision with root package name */
    public final long f5946h;

    /* renamed from: i, reason: collision with root package name */
    public final long f5947i;

    public n(j jVar, long j6, long j7, long j8, long j9, List list, long j10, long j11, long j12) {
        super(jVar, j6, j7);
        this.f5943d = j8;
        this.e = j9;
        this.f5944f = list;
        this.f5947i = j10;
        this.f5945g = j11;
        this.f5946h = j12;
    }

    public final long b(long j6, long j7) {
        long d6 = d(j6);
        if (d6 != -1) {
            return d6;
        }
        return (int) (f((j7 - this.f5946h) + this.f5947i, j6) - c(j6, j7));
    }

    public final long c(long j6, long j7) {
        long d6 = d(j6);
        long j8 = this.f5943d;
        if (d6 == -1) {
            long j9 = this.f5945g;
            if (j9 != -9223372036854775807L) {
                return Math.max(j8, f((j7 - this.f5946h) - j9, j6));
            }
        }
        return j8;
    }

    public abstract long d(long j6);

    public final long e(long j6, long j7) {
        long j8 = this.f5956b;
        long j9 = this.f5943d;
        List list = this.f5944f;
        if (list != null) {
            return (((q) list.get((int) (j6 - j9))).f5953b * 1000000) / j8;
        }
        long d6 = d(j7);
        if (d6 != -1 && j6 == (j9 + d6) - 1) {
            return j7 - g(j6);
        }
        return (this.e * 1000000) / j8;
    }

    public final long f(long j6, long j7) {
        long d6 = d(j7);
        long j8 = this.f5943d;
        if (d6 != 0) {
            if (this.f5944f == null) {
                long j9 = (j6 / ((this.e * 1000000) / this.f5956b)) + j8;
                if (j9 >= j8) {
                    if (d6 == -1) {
                        return j9;
                    }
                    return Math.min(j9, (j8 + d6) - 1);
                }
            } else {
                long j10 = (d6 + j8) - 1;
                long j11 = j8;
                while (j11 <= j10) {
                    long j12 = ((j10 - j11) / 2) + j11;
                    long g2 = g(j12);
                    if (g2 < j6) {
                        j11 = j12 + 1;
                    } else if (g2 > j6) {
                        j10 = j12 - 1;
                    } else {
                        return j12;
                    }
                }
                if (j11 == j8) {
                    return j11;
                }
                return j10;
            }
        }
        return j8;
    }

    public final long g(long j6) {
        long j7;
        long j8 = this.f5943d;
        List list = this.f5944f;
        if (list != null) {
            j7 = ((q) list.get((int) (j6 - j8))).f5952a - this.f5957c;
        } else {
            j7 = (j6 - j8) * this.e;
        }
        long j9 = j7;
        String str = C.f3053a;
        return C.V(j9, 1000000L, this.f5956b, RoundingMode.DOWN);
    }

    public abstract j h(k kVar, long j6);

    public boolean i() {
        if (this.f5944f != null) {
            return true;
        }
        return false;
    }
}
