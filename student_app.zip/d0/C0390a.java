package d0;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* renamed from: d0.a, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0390a {

    /* renamed from: a, reason: collision with root package name */
    public final long f5886a;

    /* renamed from: b, reason: collision with root package name */
    public final int f5887b;

    /* renamed from: c, reason: collision with root package name */
    public final List f5888c;

    /* renamed from: d, reason: collision with root package name */
    public final List f5889d;
    public final List e;

    /* renamed from: f, reason: collision with root package name */
    public final List f5890f;

    public C0390a(long j6, int i6, ArrayList arrayList, List list, List list2, List list3) {
        this.f5886a = j6;
        this.f5887b = i6;
        this.f5888c = Collections.unmodifiableList(arrayList);
        this.f5889d = Collections.unmodifiableList(list);
        this.e = Collections.unmodifiableList(list2);
        this.f5890f = Collections.unmodifiableList(list3);
    }
}
