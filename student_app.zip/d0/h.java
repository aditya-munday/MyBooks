package d0;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* loaded from: classes.dex */
public final class h {

    /* renamed from: a, reason: collision with root package name */
    public final String f5924a;

    /* renamed from: b, reason: collision with root package name */
    public final long f5925b;

    /* renamed from: c, reason: collision with root package name */
    public final List f5926c;

    /* renamed from: d, reason: collision with root package name */
    public final List f5927d;

    public h(String str, long j6, ArrayList arrayList, List list) {
        this.f5924a = str;
        this.f5925b = j6;
        this.f5926c = Collections.unmodifiableList(arrayList);
        this.f5927d = Collections.unmodifiableList(list);
    }
}
