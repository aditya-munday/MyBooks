package d0;

import java.util.Objects;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* loaded from: classes.dex */
public final class i {

    /* renamed from: a, reason: collision with root package name */
    public final String f5928a;

    /* renamed from: b, reason: collision with root package name */
    public final String f5929b;

    /* renamed from: c, reason: collision with root package name */
    public final String f5930c;

    /* renamed from: d, reason: collision with root package name */
    public final String f5931d;
    public final String e;

    public i(String str, String str2, String str3, String str4, String str5) {
        this.f5928a = str;
        this.f5929b = str2;
        this.f5930c = str3;
        this.f5931d = str4;
        this.e = str5;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof i)) {
            return false;
        }
        i iVar = (i) obj;
        if (Objects.equals(this.f5928a, iVar.f5928a) && Objects.equals(this.f5929b, iVar.f5929b) && Objects.equals(this.f5930c, iVar.f5930c) && Objects.equals(this.f5931d, iVar.f5931d) && Objects.equals(this.e, iVar.e)) {
            return true;
        }
        return false;
    }

    public final int hashCode() {
        int i6;
        int i7;
        int i8;
        int i9;
        int i10 = 0;
        String str = this.f5928a;
        if (str != null) {
            i6 = str.hashCode();
        } else {
            i6 = 0;
        }
        int i11 = (527 + i6) * 31;
        String str2 = this.f5929b;
        if (str2 != null) {
            i7 = str2.hashCode();
        } else {
            i7 = 0;
        }
        int i12 = (i11 + i7) * 31;
        String str3 = this.f5930c;
        if (str3 != null) {
            i8 = str3.hashCode();
        } else {
            i8 = 0;
        }
        int i13 = (i12 + i8) * 31;
        String str4 = this.f5931d;
        if (str4 != null) {
            i9 = str4.hashCode();
        } else {
            i9 = 0;
        }
        int i14 = (i13 + i9) * 31;
        String str5 = this.e;
        if (str5 != null) {
            i10 = str5.hashCode();
        }
        return i14 + i10;
    }
}
