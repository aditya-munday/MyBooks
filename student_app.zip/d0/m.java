package d0;

import E2.I;
import S.C0123p;
import V.AbstractC0133a;
import V.C;
import java.math.RoundingMode;
import java.util.Collections;
import java.util.List;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* loaded from: classes.dex */
public abstract class m {
    public final C0123p o;

    /* renamed from: p, reason: collision with root package name */
    public final I f5939p;

    /* renamed from: q, reason: collision with root package name */
    public final long f5940q;

    /* renamed from: r, reason: collision with root package name */
    public final List f5941r;

    /* renamed from: s, reason: collision with root package name */
    public final j f5942s;

    public m(C0123p c0123p, List list, s sVar, List list2) {
        List unmodifiableList;
        AbstractC0133a.c(!list.isEmpty());
        this.o = c0123p;
        this.f5939p = I.u(list);
        if (list2 == null) {
            unmodifiableList = Collections.EMPTY_LIST;
        } else {
            unmodifiableList = Collections.unmodifiableList(list2);
        }
        this.f5941r = unmodifiableList;
        this.f5942s = sVar.a(this);
        long j6 = sVar.f5957c;
        long j7 = sVar.f5956b;
        String str = C.f3053a;
        this.f5940q = C.V(j6, 1000000L, j7, RoundingMode.DOWN);
    }

    public abstract String a();

    public abstract c0.j d();

    public abstract j f();
}
