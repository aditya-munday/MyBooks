package d0;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* loaded from: classes.dex */
public final class g {

    /* renamed from: a, reason: collision with root package name */
    public final I0.a[] f5920a;

    /* renamed from: b, reason: collision with root package name */
    public final long[] f5921b;

    /* renamed from: c, reason: collision with root package name */
    public final String f5922c;

    /* renamed from: d, reason: collision with root package name */
    public final String f5923d;

    public g(String str, String str2, long[] jArr, I0.a[] aVarArr) {
        this.f5922c = str;
        this.f5923d = str2;
        this.f5921b = jArr;
        this.f5920a = aVarArr;
    }

    public final String a() {
        return this.f5922c + "/" + this.f5923d;
    }
}
