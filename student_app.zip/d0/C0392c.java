package d0;

import S.C0127u;
import S.N;
import V.C;
import android.net.Uri;
import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedList;
import java.util.List;
import k0.InterfaceC0525a;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* renamed from: d0.c, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0392c implements InterfaceC0525a {

    /* renamed from: a, reason: collision with root package name */
    public final long f5895a;

    /* renamed from: b, reason: collision with root package name */
    public final long f5896b;

    /* renamed from: c, reason: collision with root package name */
    public final long f5897c;

    /* renamed from: d, reason: collision with root package name */
    public final boolean f5898d;
    public final long e;

    /* renamed from: f, reason: collision with root package name */
    public final long f5899f;

    /* renamed from: g, reason: collision with root package name */
    public final long f5900g;

    /* renamed from: h, reason: collision with root package name */
    public final long f5901h;

    /* renamed from: i, reason: collision with root package name */
    public final t f5902i;

    /* renamed from: j, reason: collision with root package name */
    public final C0127u f5903j;

    /* renamed from: k, reason: collision with root package name */
    public final Uri f5904k;

    /* renamed from: l, reason: collision with root package name */
    public final i f5905l;

    /* renamed from: m, reason: collision with root package name */
    public final List f5906m;

    public C0392c(long j6, long j7, long j8, boolean z6, long j9, long j10, long j11, long j12, i iVar, t tVar, C0127u c0127u, Uri uri, ArrayList arrayList) {
        this.f5895a = j6;
        this.f5896b = j7;
        this.f5897c = j8;
        this.f5898d = z6;
        this.e = j9;
        this.f5899f = j10;
        this.f5900g = j11;
        this.f5901h = j12;
        this.f5905l = iVar;
        this.f5902i = tVar;
        this.f5904k = uri;
        this.f5903j = c0127u;
        this.f5906m = arrayList;
    }

    @Override // k0.InterfaceC0525a
    public final Object a(List list) {
        long j6;
        long j7;
        LinkedList linkedList = new LinkedList(list);
        Collections.sort(linkedList);
        linkedList.add(new N());
        ArrayList arrayList = new ArrayList();
        long j8 = 0;
        int i6 = 0;
        while (true) {
            j6 = -9223372036854775807L;
            if (i6 >= this.f5906m.size()) {
                break;
            }
            if (((N) linkedList.peek()).o != i6) {
                long c6 = c(i6);
                if (c6 != -9223372036854775807L) {
                    j8 += c6;
                }
            } else {
                h b6 = b(i6);
                List list2 = b6.f5926c;
                N n6 = (N) linkedList.poll();
                int i7 = n6.o;
                ArrayList arrayList2 = new ArrayList();
                while (true) {
                    int i8 = n6.f2451p;
                    C0390a c0390a = (C0390a) list2.get(i8);
                    List list3 = c0390a.f5888c;
                    ArrayList arrayList3 = new ArrayList();
                    do {
                        arrayList3.add((m) list3.get(n6.f2452q));
                        n6 = (N) linkedList.poll();
                        if (n6.o != i7) {
                            break;
                        }
                    } while (n6.f2451p == i8);
                    j7 = j8;
                    arrayList2.add(new C0390a(c0390a.f5886a, c0390a.f5887b, arrayList3, c0390a.f5889d, c0390a.e, c0390a.f5890f));
                    if (n6.o != i7) {
                        break;
                    }
                    j8 = j7;
                }
                linkedList.addFirst(n6);
                arrayList.add(new h(b6.f5924a, b6.f5925b - j7, arrayList2, b6.f5927d));
                j8 = j7;
            }
            i6++;
        }
        long j9 = j8;
        long j10 = this.f5896b;
        if (j10 != -9223372036854775807L) {
            j6 = j10 - j9;
        }
        C0127u c0127u = this.f5903j;
        Uri uri = this.f5904k;
        return new C0392c(this.f5895a, j6, this.f5897c, this.f5898d, this.e, this.f5899f, this.f5900g, this.f5901h, this.f5905l, this.f5902i, c0127u, uri, arrayList);
    }

    public final h b(int i6) {
        return (h) this.f5906m.get(i6);
    }

    public final long c(int i6) {
        long j6;
        long j7;
        List list = this.f5906m;
        if (i6 == list.size() - 1) {
            j6 = this.f5896b;
            if (j6 == -9223372036854775807L) {
                return -9223372036854775807L;
            }
            j7 = ((h) list.get(i6)).f5925b;
        } else {
            j6 = ((h) list.get(i6 + 1)).f5925b;
            j7 = ((h) list.get(i6)).f5925b;
        }
        return j6 - j7;
    }

    public final long d(int i6) {
        return C.N(c(i6));
    }
}
