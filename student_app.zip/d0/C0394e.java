package d0;

import E2.G;
import E2.I;
import E2.Z;
import S.AbstractC0114g;
import S.C0119l;
import S.C0120m;
import S.C0122o;
import S.C0123p;
import S.C0124q;
import S.C0127u;
import S.F;
import V.AbstractC0133a;
import V.C;
import android.net.Uri;
import android.text.TextUtils;
import android.util.Base64;
import android.util.Pair;
import android.util.Xml;
import java.io.ByteArrayOutputStream;
import java.math.RoundingMode;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import org.apache.tika.fork.ContentHandlerProxy;
import org.apache.tika.metadata.HttpHeaders;
import org.apache.tika.mime.MimeTypesReaderMetKeys;
import org.apache.tika.utils.StringUtils;
import org.xml.sax.helpers.DefaultHandler;
import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;
import org.xmlpull.v1.XmlPullParserFactory;
import org.xmlpull.v1.XmlSerializer;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* renamed from: d0.e, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0394e extends DefaultHandler implements t0.q {

    /* renamed from: p, reason: collision with root package name */
    public static final Pattern f5912p = Pattern.compile("(\\d+)(?:/(\\d+))?");

    /* renamed from: q, reason: collision with root package name */
    public static final Pattern f5913q = Pattern.compile("CC([1-4])=.*");

    /* renamed from: r, reason: collision with root package name */
    public static final Pattern f5914r = Pattern.compile("([1-9]|[1-5][0-9]|6[0-3])=.*");

    /* renamed from: s, reason: collision with root package name */
    public static final int[] f5915s = {2, 1, 2, 2, 2, 2, 1, 2, 2, 1, 1, 1, 1, 2, 1, 1, 2, 2, 2};

    /* renamed from: t, reason: collision with root package name */
    public static final int[] f5916t = {-1, 1, 2, 3, 4, 5, 6, 8, 2, 3, 4, 7, 8, 24, 8, 12, 10, 12, 14, 12, 14};
    public final XmlPullParserFactory o;

    public C0394e() {
        try {
            this.o = XmlPullParserFactory.newInstance();
        } catch (XmlPullParserException e) {
            throw new RuntimeException("Couldn't create XmlPullParserFactory instance", e);
        }
    }

    public static long a(ArrayList arrayList, long j6, long j7, int i6, long j8) {
        int i7;
        if (i6 >= 0) {
            i7 = i6 + 1;
        } else {
            String str = C.f3053a;
            i7 = (int) ((((j8 - j6) + j7) - 1) / j7);
        }
        for (int i8 = 0; i8 < i7; i8++) {
            arrayList.add(new q(j6, j7));
            j6 += j7;
        }
        return j6;
    }

    public static void b(XmlPullParser xmlPullParser) {
        if (xmlPullParser.getEventType() == 2) {
            int i6 = 1;
            while (i6 != 0) {
                xmlPullParser.next();
                if (xmlPullParser.getEventType() == 2) {
                    i6++;
                } else if (xmlPullParser.getEventType() == 3) {
                    i6--;
                }
            }
        }
    }

    /* JADX WARN: Can't fix incorrect switch cases order, some code will duplicate */
    /* JADX WARN: Code restructure failed: missing block: B:12:0x008f, code lost:
    
        if (r13 == 0) goto L135;
     */
    /* JADX WARN: Code restructure failed: missing block: B:13:0x0093, code lost:
    
        r10 = r13;
     */
    /* JADX WARN: Code restructure failed: missing block: B:38:0x00d7, code lost:
    
        if (r13.equals("f801") == false) goto L63;
     */
    /* JADX WARN: Code restructure failed: missing block: B:74:0x019b, code lost:
    
        if (r13 == 0) goto L135;
     */
    /* JADX WARN: Code restructure failed: missing block: B:80:0x01ae, code lost:
    
        if (r13 < 33) goto L49;
     */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public static int c(XmlPullParser xmlPullParser, String str) {
        char c6;
        int parseInt;
        int parseInt2;
        String attributeValue = xmlPullParser.getAttributeValue(null, "schemeIdUri");
        if (attributeValue == null) {
            attributeValue = null;
        }
        attributeValue.getClass();
        int i6 = 5;
        char c7 = 3;
        int i7 = 0;
        int i8 = -1;
        switch (attributeValue.hashCode()) {
            case -2128649360:
                if (attributeValue.equals("urn:dts:dash:audio_channel_configuration:2012")) {
                    c6 = 0;
                    break;
                }
                c6 = 65535;
                break;
            case -2060825028:
                if (attributeValue.equals("tag:dolby.com,2015:dash:audio_channel_configuration:2015")) {
                    c6 = 1;
                    break;
                }
                c6 = 65535;
                break;
            case -1352850286:
                if (attributeValue.equals("urn:mpeg:dash:23003:3:audio_channel_configuration:2011")) {
                    c6 = 2;
                    break;
                }
                c6 = 65535;
                break;
            case -1138141449:
                if (attributeValue.equals("tag:dolby.com,2014:dash:audio_channel_configuration:2011")) {
                    c6 = 3;
                    break;
                }
                c6 = 65535;
                break;
            case -986633423:
                if (attributeValue.equals("urn:mpeg:mpegB:cicp:ChannelConfiguration")) {
                    c6 = 4;
                    break;
                }
                c6 = 65535;
                break;
            case -79006963:
                if (attributeValue.equals("tag:dts.com,2014:dash:audio_channel_configuration:2012")) {
                    c6 = 5;
                    break;
                }
                c6 = 65535;
                break;
            case 312179081:
                if (attributeValue.equals("tag:dts.com,2018:uhd:audio_channel_configuration")) {
                    c6 = 6;
                    break;
                }
                c6 = 65535;
                break;
            case 2036691300:
                if (attributeValue.equals("urn:dolby:dash:audio_channel_configuration:2011")) {
                    c6 = 7;
                    break;
                }
                c6 = 65535;
                break;
            default:
                c6 = 65535;
                break;
        }
        switch (c6) {
            case 0:
            case 5:
                String attributeValue2 = xmlPullParser.getAttributeValue(null, MimeTypesReaderMetKeys.MATCH_VALUE_ATTR);
                if (attributeValue2 == null) {
                    parseInt = -1;
                } else {
                    parseInt = Integer.parseInt(attributeValue2);
                }
                if (parseInt > 0) {
                    break;
                }
                break;
            case 1:
                String attributeValue3 = xmlPullParser.getAttributeValue(null, MimeTypesReaderMetKeys.MATCH_VALUE_ATTR);
                if (attributeValue3 != null && attributeValue3.length() == 6) {
                    int parseInt3 = Integer.parseInt(attributeValue3, 16);
                    if ((8388608 & parseInt3) != 0) {
                        String[] X5 = C.X(str);
                        if (X5.length != 0) {
                            List k6 = new D2.i(new x3.c(new D2.b('.'), 4)).k(Q5.a.M(X5[0].trim()));
                            if (k6.size() == 4 && ((String) k6.get(0)).equals("ac-4")) {
                                String str2 = (String) k6.get(3);
                                str2.getClass();
                                if (!str2.equals("03")) {
                                    if (str2.equals("04")) {
                                        i8 = 21;
                                        break;
                                    }
                                } else {
                                    i8 = 18;
                                    break;
                                }
                            }
                        }
                    } else {
                        parseInt = 0;
                        while (true) {
                            int[] iArr = f5915s;
                            if (i7 >= iArr.length) {
                                break;
                            } else {
                                parseInt += ((parseInt3 >> i7) & 1) * iArr[i7];
                                i7++;
                            }
                        }
                    }
                }
                break;
            case 2:
                String attributeValue4 = xmlPullParser.getAttributeValue(null, MimeTypesReaderMetKeys.MATCH_VALUE_ATTR);
                if (attributeValue4 != null) {
                    i8 = Integer.parseInt(attributeValue4);
                    break;
                }
                break;
            case 3:
            case 7:
                String attributeValue5 = xmlPullParser.getAttributeValue(null, MimeTypesReaderMetKeys.MATCH_VALUE_ATTR);
                if (attributeValue5 != null) {
                    String M6 = Q5.a.M(attributeValue5);
                    M6.getClass();
                    switch (M6.hashCode()) {
                        case 1596796:
                            if (M6.equals("4000")) {
                                c7 = 0;
                                break;
                            }
                            c7 = 65535;
                            break;
                        case 2937391:
                            if (M6.equals("a000")) {
                                c7 = 1;
                                break;
                            }
                            c7 = 65535;
                            break;
                        case 3094034:
                            if (M6.equals("f800")) {
                                c7 = 2;
                                break;
                            }
                            c7 = 65535;
                            break;
                        case 3094035:
                            break;
                        case 3133436:
                            if (M6.equals("fa01")) {
                                c7 = 4;
                                break;
                            }
                            c7 = 65535;
                            break;
                        default:
                            c7 = 65535;
                            break;
                    }
                    switch (c7) {
                        case 0:
                            i6 = 1;
                            break;
                        case 1:
                            i6 = 2;
                            break;
                        case 3:
                            i6 = 6;
                            break;
                        case 4:
                            i6 = 8;
                            break;
                    }
                    i8 = i6;
                    break;
                }
                i6 = -1;
                i8 = i6;
            case 4:
                String attributeValue6 = xmlPullParser.getAttributeValue(null, MimeTypesReaderMetKeys.MATCH_VALUE_ATTR);
                if (attributeValue6 == null) {
                    parseInt2 = -1;
                } else {
                    parseInt2 = Integer.parseInt(attributeValue6);
                }
                if (parseInt2 >= 0) {
                    int[] iArr2 = f5916t;
                    if (parseInt2 < iArr2.length) {
                        i8 = iArr2[parseInt2];
                        break;
                    }
                }
                break;
            case 6:
                String attributeValue7 = xmlPullParser.getAttributeValue(null, MimeTypesReaderMetKeys.MATCH_VALUE_ATTR);
                if (attributeValue7 != null) {
                    parseInt = Integer.bitCount(Integer.parseInt(attributeValue7, 16));
                    break;
                }
                break;
        }
        do {
            xmlPullParser.next();
        } while (!AbstractC0133a.s(xmlPullParser, "AudioChannelConfiguration"));
        return i8;
    }

    public static long d(XmlPullParser xmlPullParser, long j6) {
        String attributeValue = xmlPullParser.getAttributeValue(null, "availabilityTimeOffset");
        if (attributeValue == null) {
            return j6;
        }
        if ("INF".equals(attributeValue)) {
            return Long.MAX_VALUE;
        }
        return Float.parseFloat(attributeValue) * 1000000.0f;
    }

    public static ArrayList e(XmlPullParser xmlPullParser, ArrayList arrayList, boolean z6) {
        int i6;
        String str;
        String attributeValue = xmlPullParser.getAttributeValue(null, "dvb:priority");
        int i7 = 1;
        if (attributeValue != null) {
            i6 = Integer.parseInt(attributeValue);
        } else if (z6) {
            i6 = 1;
        } else {
            i6 = Integer.MIN_VALUE;
        }
        String attributeValue2 = xmlPullParser.getAttributeValue(null, "dvb:weight");
        if (attributeValue2 != null) {
            i7 = Integer.parseInt(attributeValue2);
        }
        String attributeValue3 = xmlPullParser.getAttributeValue(null, "serviceLocation");
        String str2 = StringUtils.EMPTY;
        do {
            xmlPullParser.next();
            if (xmlPullParser.getEventType() == 4) {
                str2 = xmlPullParser.getText();
            } else {
                b(xmlPullParser);
            }
        } while (!AbstractC0133a.s(xmlPullParser, "BaseURL"));
        if (str2 != null && AbstractC0133a.q(str2)[0] != -1) {
            if (attributeValue3 == null) {
                attributeValue3 = str2;
            }
            return E2.r.n(new C0391b(i6, i7, str2, attributeValue3));
        }
        ArrayList arrayList2 = new ArrayList();
        for (int i8 = 0; i8 < arrayList.size(); i8++) {
            C0391b c0391b = (C0391b) arrayList.get(i8);
            String x6 = AbstractC0133a.x(c0391b.f5891a, str2);
            if (attributeValue3 == null) {
                str = x6;
            } else {
                str = attributeValue3;
            }
            if (z6) {
                i6 = c0391b.f5893c;
                i7 = c0391b.f5894d;
                str = c0391b.f5892b;
            }
            arrayList2.add(new C0391b(i6, i7, x6, str));
        }
        return arrayList2;
    }

    /* JADX WARN: Can't fix incorrect switch cases order, some code will duplicate */
    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Removed duplicated region for block: B:39:0x016f  */
    /* JADX WARN: Type inference failed for: r10v7, types: [java.util.UUID] */
    /* JADX WARN: Type inference failed for: r7v0 */
    /* JADX WARN: Type inference failed for: r7v1 */
    /* JADX WARN: Type inference failed for: r7v10 */
    /* JADX WARN: Type inference failed for: r7v16, types: [java.util.UUID] */
    /* JADX WARN: Type inference failed for: r7v17, types: [java.util.UUID] */
    /* JADX WARN: Type inference failed for: r7v18 */
    /* JADX WARN: Type inference failed for: r7v19, types: [java.util.UUID] */
    /* JADX WARN: Type inference failed for: r7v2 */
    /* JADX WARN: Type inference failed for: r7v24 */
    /* JADX WARN: Type inference failed for: r7v26, types: [java.util.UUID] */
    /* JADX WARN: Type inference failed for: r7v3 */
    /* JADX WARN: Type inference failed for: r7v4, types: [java.lang.Object] */
    /* JADX WARN: Type inference failed for: r7v5, types: [java.util.UUID] */
    /* JADX WARN: Type inference failed for: r7v8 */
    /* JADX WARN: Type inference failed for: r8v12 */
    /* JADX WARN: Type inference failed for: r8v13 */
    /* JADX WARN: Type inference failed for: r8v2 */
    /* JADX WARN: Type inference failed for: r8v26 */
    /* JADX WARN: Type inference failed for: r8v27 */
    /* JADX WARN: Type inference failed for: r8v28 */
    /* JADX WARN: Type inference failed for: r8v29 */
    /* JADX WARN: Type inference failed for: r8v3 */
    /* JADX WARN: Type inference failed for: r8v30 */
    /* JADX WARN: Type inference failed for: r8v31 */
    /* JADX WARN: Type inference failed for: r8v4, types: [byte[]] */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public static Pair f(XmlPullParser xmlPullParser) {
        String str;
        ?? r7;
        String str2;
        String str3;
        ?? r8;
        UUID uuid;
        char c6;
        String str4;
        C0119l c0119l = null;
        String attributeValue = xmlPullParser.getAttributeValue(null, "schemeIdUri");
        if (attributeValue != null) {
            String M6 = Q5.a.M(attributeValue);
            M6.getClass();
            switch (M6.hashCode()) {
                case -1980789791:
                    if (M6.equals("urn:uuid:e2719d58-a985-b3c9-781a-b030af78d30e")) {
                        c6 = 0;
                        break;
                    }
                    c6 = 65535;
                    break;
                case 489446379:
                    if (M6.equals("urn:uuid:9a04f079-9840-4286-ab92-e65be0885f95")) {
                        c6 = 1;
                        break;
                    }
                    c6 = 65535;
                    break;
                case 755418770:
                    if (M6.equals("urn:uuid:edef8ba9-79d6-4ace-a3c8-27dcd51d21ed")) {
                        c6 = 2;
                        break;
                    }
                    c6 = 65535;
                    break;
                case 1812765994:
                    if (M6.equals("urn:mpeg:dash:mp4protection:2011")) {
                        c6 = 3;
                        break;
                    }
                    c6 = 65535;
                    break;
                default:
                    c6 = 65535;
                    break;
            }
            switch (c6) {
                case 0:
                    r7 = AbstractC0114g.f2542c;
                    str = null;
                    str2 = null;
                    str3 = str2;
                    r8 = str2;
                    break;
                case 1:
                    r7 = AbstractC0114g.e;
                    str = null;
                    str2 = null;
                    str3 = str2;
                    r8 = str2;
                    break;
                case 2:
                    r7 = AbstractC0114g.f2543d;
                    str = null;
                    str2 = null;
                    str3 = str2;
                    r8 = str2;
                    break;
                case 3:
                    str = xmlPullParser.getAttributeValue(null, MimeTypesReaderMetKeys.MATCH_VALUE_ATTR);
                    int attributeCount = xmlPullParser.getAttributeCount();
                    int i6 = 0;
                    while (true) {
                        if (i6 < attributeCount) {
                            String attributeName = xmlPullParser.getAttributeName(i6);
                            int indexOf = attributeName.indexOf(58);
                            if (indexOf != -1) {
                                attributeName = attributeName.substring(indexOf + 1);
                            }
                            if (attributeName.equals("default_KID")) {
                                str4 = xmlPullParser.getAttributeValue(i6);
                            } else {
                                i6++;
                            }
                        } else {
                            str4 = null;
                        }
                    }
                    if (!TextUtils.isEmpty(str4) && !"00000000-0000-0000-0000-000000000000".equals(str4)) {
                        String[] split = str4.split("\\s+");
                        UUID[] uuidArr = new UUID[split.length];
                        for (int i7 = 0; i7 < split.length; i7++) {
                            uuidArr[i7] = UUID.fromString(split[i7]);
                        }
                        r7 = AbstractC0114g.f2541b;
                        str3 = null;
                        r8 = R0.t.a(r7, uuidArr, null);
                        break;
                    } else {
                        AbstractC0133a.A("MpdParser", "Ignoring <ContentProtection> with schemeIdUri=\"urn:mpeg:dash:mp4protection:2011\" (ClearKey) due to missing required default_KID attribute.");
                        r7 = null;
                        str2 = r7;
                        str3 = str2;
                        r8 = str2;
                        break;
                    }
                    break;
            }
            do {
                xmlPullParser.next();
                if ((!AbstractC0133a.u(xmlPullParser, "clearkey:Laurl") || AbstractC0133a.u(xmlPullParser, "dashif:Laurl")) && xmlPullParser.next() == 4) {
                    str3 = xmlPullParser.getText();
                    r8 = r8;
                } else if (AbstractC0133a.u(xmlPullParser, "ms:laurl")) {
                    str3 = xmlPullParser.getAttributeValue(null, "licenseUrl");
                    r8 = r8;
                } else {
                    if (r8 == 0 && xmlPullParser.getEventType() == 2) {
                        String name = xmlPullParser.getName();
                        int indexOf2 = name.indexOf(58);
                        if (indexOf2 != -1) {
                            name = name.substring(indexOf2 + 1);
                        }
                        if (name.equals("pssh") && xmlPullParser.next() == 4) {
                            byte[] decode = Base64.decode(xmlPullParser.getText(), 0);
                            A1.l j6 = R0.t.j(decode);
                            if (j6 == null) {
                                uuid = null;
                            } else {
                                uuid = (UUID) j6.f60p;
                            }
                            if (uuid == null) {
                                AbstractC0133a.A("MpdParser", "Skipping malformed cenc:pssh data");
                                r7 = uuid;
                                r8 = 0;
                            } else {
                                UUID uuid2 = uuid;
                                r8 = decode;
                                r7 = uuid2;
                            }
                        }
                    }
                    if (r8 == 0) {
                        ?? r10 = AbstractC0114g.e;
                        if (r10.equals(r7) && AbstractC0133a.u(xmlPullParser, "mspr:pro") && xmlPullParser.next() == 4) {
                            r8 = R0.t.a(r10, null, Base64.decode(xmlPullParser.getText(), 0));
                        }
                    }
                    b(xmlPullParser);
                    r8 = r8;
                }
            } while (!AbstractC0133a.s(xmlPullParser, "ContentProtection"));
            if (r7 != null) {
                c0119l = new C0119l(r7, str3, "video/mp4", r8);
            }
            return Pair.create(str, c0119l);
        }
        str = null;
        r7 = null;
        str2 = r7;
        str3 = str2;
        r8 = str2;
        do {
            xmlPullParser.next();
            if (!AbstractC0133a.u(xmlPullParser, "clearkey:Laurl")) {
            }
            str3 = xmlPullParser.getText();
            r8 = r8;
        } while (!AbstractC0133a.s(xmlPullParser, "ContentProtection"));
        if (r7 != null) {
        }
        return Pair.create(str, c0119l);
    }

    public static int g(XmlPullParser xmlPullParser) {
        String attributeValue = xmlPullParser.getAttributeValue(null, "contentType");
        if (!TextUtils.isEmpty(attributeValue)) {
            if ("audio".equals(attributeValue)) {
                return 1;
            }
            if ("video".equals(attributeValue)) {
                return 2;
            }
            if ("text".equals(attributeValue)) {
                return 3;
            }
            if ("image".equals(attributeValue)) {
                return 4;
            }
            return -1;
        }
        return -1;
    }

    public static C0395f h(XmlPullParser xmlPullParser, String str) {
        String str2 = null;
        String attributeValue = xmlPullParser.getAttributeValue(null, "schemeIdUri");
        if (attributeValue == null) {
            attributeValue = StringUtils.EMPTY;
        }
        String attributeValue2 = xmlPullParser.getAttributeValue(null, MimeTypesReaderMetKeys.MATCH_VALUE_ATTR);
        if (attributeValue2 == null) {
            attributeValue2 = null;
        }
        String attributeValue3 = xmlPullParser.getAttributeValue(null, "id");
        if (attributeValue3 != null) {
            str2 = attributeValue3;
        }
        do {
            xmlPullParser.next();
        } while (!AbstractC0133a.s(xmlPullParser, str));
        return new C0395f(attributeValue, attributeValue2, str2);
    }

    public static long i(XmlPullParser xmlPullParser, String str, long j6) {
        double d6;
        double d7;
        double d8;
        double d9;
        double d10;
        String attributeValue = xmlPullParser.getAttributeValue(null, str);
        if (attributeValue == null) {
            return j6;
        }
        Matcher matcher = C.e.matcher(attributeValue);
        if (matcher.matches()) {
            boolean isEmpty = TextUtils.isEmpty(matcher.group(1));
            String group = matcher.group(3);
            double d11 = 0.0d;
            if (group != null) {
                d6 = Double.parseDouble(group) * 3.1556908E7d;
            } else {
                d6 = 0.0d;
            }
            String group2 = matcher.group(5);
            if (group2 != null) {
                d7 = Double.parseDouble(group2) * 2629739.0d;
            } else {
                d7 = 0.0d;
            }
            double d12 = d6 + d7;
            String group3 = matcher.group(7);
            if (group3 != null) {
                d8 = Double.parseDouble(group3) * 86400.0d;
            } else {
                d8 = 0.0d;
            }
            double d13 = d12 + d8;
            String group4 = matcher.group(10);
            if (group4 != null) {
                d9 = Double.parseDouble(group4) * 3600.0d;
            } else {
                d9 = 0.0d;
            }
            double d14 = d13 + d9;
            String group5 = matcher.group(12);
            if (group5 != null) {
                d10 = Double.parseDouble(group5) * 60.0d;
            } else {
                d10 = 0.0d;
            }
            double d15 = d14 + d10;
            String group6 = matcher.group(14);
            if (group6 != null) {
                d11 = Double.parseDouble(group6);
            }
            long j7 = (long) ((d15 + d11) * 1000.0d);
            if (!isEmpty) {
                return -j7;
            }
            return j7;
        }
        return (long) (Double.parseDouble(attributeValue) * 3600.0d * 1000.0d);
    }

    public static float j(XmlPullParser xmlPullParser, float f6) {
        String attributeValue = xmlPullParser.getAttributeValue(null, "frameRate");
        if (attributeValue != null) {
            Matcher matcher = f5912p.matcher(attributeValue);
            if (matcher.matches()) {
                int parseInt = Integer.parseInt(matcher.group(1));
                if (!TextUtils.isEmpty(matcher.group(2))) {
                    return parseInt / Integer.parseInt(r2);
                }
                return parseInt;
            }
        }
        return f6;
    }

    /* JADX WARN: Code restructure failed: missing block: B:384:0x09c0, code lost:
    
        if ("audio/eac3-joc".equals(r3) != false) goto L343;
     */
    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Removed duplicated region for block: B:191:0x1015 A[LOOP:5: B:182:0x040d->B:191:0x1015, LOOP_END] */
    /* JADX WARN: Removed duplicated region for block: B:192:0x0e99 A[SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:365:0x0cc8 A[LOOP:11: B:356:0x06a9->B:365:0x0cc8, LOOP_END] */
    /* JADX WARN: Removed duplicated region for block: B:366:0x08fd A[SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:43:0x140e A[LOOP:1: B:35:0x00cd->B:43:0x140e, LOOP_END] */
    /* JADX WARN: Removed duplicated region for block: B:44:0x13da A[SYNTHETIC] */
    /* JADX WARN: Type inference failed for: r1v120, types: [java.lang.Object, S.u] */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public static C0392c k(XmlPullParser xmlPullParser, Uri uri) {
        int i6;
        boolean z6;
        int i7;
        ArrayList arrayList;
        boolean z7;
        long j6;
        long j7;
        int i8;
        long j8;
        long j9;
        ArrayList arrayList2;
        ArrayList arrayList3;
        ArrayList arrayList4;
        String str;
        String str2;
        ArrayList arrayList5;
        ArrayList arrayList6;
        String str3;
        String str4;
        String str5;
        long j10;
        long j11;
        ArrayList arrayList7;
        String str6;
        ByteArrayOutputStream byteArrayOutputStream;
        String str7;
        long j12;
        String str8;
        String str9;
        long j13;
        String str10;
        ByteArrayOutputStream byteArrayOutputStream2;
        String str11;
        ArrayList arrayList8;
        long j14;
        ArrayList arrayList9;
        String str12;
        String str13;
        String str14;
        String str15;
        float f6;
        String str16;
        String str17;
        String str18;
        String str19;
        String str20;
        ArrayList arrayList10;
        ArrayList arrayList11;
        long j15;
        ArrayList arrayList12;
        ArrayList arrayList13;
        String str21;
        long j16;
        String str22;
        int i9;
        String str23;
        ArrayList arrayList14;
        ArrayList arrayList15;
        long j17;
        ArrayList arrayList16;
        String str24;
        long j18;
        String str25;
        String str26;
        int i10;
        String str27;
        String str28;
        ArrayList arrayList17;
        int parseInt;
        String str29;
        String str30;
        float f7;
        ArrayList arrayList18;
        String str31;
        String str32;
        ArrayList arrayList19;
        String str33;
        String str34;
        int i11;
        String str35;
        ArrayList arrayList20;
        int i12;
        String str36;
        String str37;
        int i13;
        ArrayList arrayList21;
        float f8;
        ArrayList arrayList22;
        String str38;
        ArrayList arrayList23;
        long j19;
        ArrayList arrayList24;
        long j20;
        String str39;
        String str40;
        String str41;
        ArrayList arrayList25;
        long j21;
        ArrayList arrayList26;
        String str42;
        String str43;
        int i14;
        String str44;
        String str45;
        String d6;
        ArrayList arrayList27;
        String str46;
        Pair pair;
        int parseInt2;
        String str47;
        int i15;
        int i16;
        String str48;
        String str49;
        long j22;
        m kVar;
        String str50;
        long j23;
        int i17 = 0;
        String[] strArr = new String[0];
        String str51 = null;
        String attributeValue = xmlPullParser.getAttributeValue(null, "profiles");
        if (attributeValue != null) {
            strArr = attributeValue.split(",");
        }
        int length = strArr.length;
        int i18 = 0;
        while (true) {
            i6 = 1;
            if (i18 >= length) {
                z6 = false;
                break;
            }
            if (strArr[i18].startsWith("urn:dvb:dash:profile:dvb-dash:")) {
                z6 = true;
                break;
            }
            i18++;
        }
        String attributeValue2 = xmlPullParser.getAttributeValue(null, "availabilityStartTime");
        long j24 = -9223372036854775807L;
        long Q6 = attributeValue2 == null ? -9223372036854775807L : C.Q(attributeValue2);
        long i19 = i(xmlPullParser, "mediaPresentationDuration", -9223372036854775807L);
        long i20 = i(xmlPullParser, "minBufferTime", -9223372036854775807L);
        boolean equals = "dynamic".equals(xmlPullParser.getAttributeValue(null, "type"));
        long i21 = equals ? i(xmlPullParser, "minimumUpdatePeriod", -9223372036854775807L) : -9223372036854775807L;
        long i22 = equals ? i(xmlPullParser, "timeShiftBufferDepth", -9223372036854775807L) : -9223372036854775807L;
        long i23 = equals ? i(xmlPullParser, "suggestedPresentationDelay", -9223372036854775807L) : -9223372036854775807L;
        String attributeValue3 = xmlPullParser.getAttributeValue(null, "publishTime");
        long Q7 = attributeValue3 == null ? -9223372036854775807L : C.Q(attributeValue3);
        long j25 = equals ? 0L : -9223372036854775807L;
        ArrayList n6 = E2.r.n(new C0391b(z6 ? 1 : Integer.MIN_VALUE, 1, uri.toString(), uri.toString()));
        ArrayList arrayList28 = new ArrayList();
        ArrayList arrayList29 = new ArrayList();
        long j26 = equals ? -9223372036854775807L : 0L;
        int i24 = 0;
        int i25 = 0;
        i iVar = null;
        t tVar = null;
        Uri uri2 = null;
        C0127u c0127u = null;
        while (true) {
            xmlPullParser.next();
            String str52 = "BaseURL";
            if (AbstractC0133a.u(xmlPullParser, "BaseURL")) {
                if (i24 == 0) {
                    j25 = d(xmlPullParser, j25);
                    i24 = i6;
                }
                arrayList29.addAll(e(xmlPullParser, n6, z6));
                arrayList = n6;
                j6 = j24;
                arrayList2 = arrayList29;
                z7 = z6;
                i8 = i17;
                i7 = i6;
                arrayList3 = arrayList28;
            } else {
                i7 = i6;
                long j27 = j24;
                String str53 = "lang";
                if (AbstractC0133a.u(xmlPullParser, "ProgramInformation")) {
                    String attributeValue4 = xmlPullParser.getAttributeValue(str51, "moreInformationURL");
                    String str54 = attributeValue4 == null ? str51 : attributeValue4;
                    String attributeValue5 = xmlPullParser.getAttributeValue(str51, "lang");
                    String str55 = attributeValue5 == null ? str51 : attributeValue5;
                    String str56 = str51;
                    String str57 = str56;
                    String str58 = str57;
                    while (true) {
                        xmlPullParser.next();
                        if (AbstractC0133a.u(xmlPullParser, "Title")) {
                            str56 = xmlPullParser.nextText();
                        } else if (AbstractC0133a.u(xmlPullParser, "Source")) {
                            str57 = xmlPullParser.nextText();
                        } else if (AbstractC0133a.u(xmlPullParser, "Copyright")) {
                            str58 = xmlPullParser.nextText();
                        } else {
                            b(xmlPullParser);
                        }
                        String str59 = str56;
                        String str60 = str57;
                        String str61 = str58;
                        if (AbstractC0133a.s(xmlPullParser, "ProgramInformation")) {
                            i iVar2 = new i(str59, str60, str61, str54, str55);
                            arrayList = n6;
                            arrayList2 = arrayList29;
                            z7 = z6;
                            arrayList3 = arrayList28;
                            j6 = j27;
                            iVar = iVar2;
                        } else {
                            str56 = str59;
                            str57 = str60;
                            str58 = str61;
                        }
                    }
                } else {
                    String str62 = "schemeIdUri";
                    if (AbstractC0133a.u(xmlPullParser, "UTCTiming")) {
                        arrayList = n6;
                        arrayList2 = arrayList29;
                        tVar = new t(xmlPullParser.getAttributeValue(str51, "schemeIdUri"), 0, xmlPullParser.getAttributeValue(str51, MimeTypesReaderMetKeys.MATCH_VALUE_ATTR));
                        z7 = z6;
                        i8 = 0;
                        arrayList3 = arrayList28;
                        j6 = j27;
                    } else if (AbstractC0133a.u(xmlPullParser, HttpHeaders.LOCATION)) {
                        uri2 = AbstractC0133a.y(uri.toString(), xmlPullParser.nextText());
                        arrayList = n6;
                        arrayList2 = arrayList29;
                        z7 = z6;
                        arrayList3 = arrayList28;
                        j6 = j27;
                    } else {
                        if (AbstractC0133a.u(xmlPullParser, "ServiceDescription")) {
                            long j28 = j27;
                            long j29 = j28;
                            long j30 = j29;
                            float f9 = -3.4028235E38f;
                            float f10 = -3.4028235E38f;
                            while (true) {
                                xmlPullParser.next();
                                if (AbstractC0133a.u(xmlPullParser, "Latency")) {
                                    arrayList = n6;
                                    String attributeValue6 = xmlPullParser.getAttributeValue(null, "target");
                                    j28 = attributeValue6 == null ? j27 : Long.parseLong(attributeValue6);
                                    String attributeValue7 = xmlPullParser.getAttributeValue(null, "min");
                                    j29 = attributeValue7 == null ? j27 : Long.parseLong(attributeValue7);
                                    String attributeValue8 = xmlPullParser.getAttributeValue(null, "max");
                                    j30 = attributeValue8 == null ? j27 : Long.parseLong(attributeValue8);
                                } else {
                                    arrayList = n6;
                                    if (AbstractC0133a.u(xmlPullParser, "PlaybackRate")) {
                                        String attributeValue9 = xmlPullParser.getAttributeValue(null, "min");
                                        f9 = attributeValue9 == null ? -3.4028235E38f : Float.parseFloat(attributeValue9);
                                        String attributeValue10 = xmlPullParser.getAttributeValue(null, "max");
                                        f10 = attributeValue10 == null ? -3.4028235E38f : Float.parseFloat(attributeValue10);
                                    }
                                }
                                long j31 = j28;
                                long j32 = j25;
                                long j33 = j29;
                                long j34 = i22;
                                long j35 = j30;
                                if (AbstractC0133a.s(xmlPullParser, "ServiceDescription")) {
                                    ?? obj = new Object();
                                    obj.f2641a = j31;
                                    obj.f2642b = j33;
                                    obj.f2643c = j35;
                                    obj.f2644d = f9;
                                    obj.e = f10;
                                    c0127u = obj;
                                    z7 = z6;
                                    j6 = j27;
                                    j25 = j32;
                                    j7 = j34;
                                    i8 = 0;
                                    arrayList2 = arrayList29;
                                    arrayList3 = arrayList28;
                                } else {
                                    j30 = j35;
                                    i22 = j34;
                                    n6 = arrayList;
                                    j29 = j33;
                                    j25 = j32;
                                    j28 = j31;
                                }
                            }
                        } else {
                            arrayList = n6;
                            long j36 = j25;
                            long j37 = i22;
                            if (AbstractC0133a.u(xmlPullParser, "Period") && i25 == 0) {
                                ArrayList arrayList30 = !arrayList29.isEmpty() ? arrayList29 : arrayList;
                                String str63 = "id";
                                String attributeValue11 = xmlPullParser.getAttributeValue(null, "id");
                                long i26 = i(xmlPullParser, "start", j26);
                                String str64 = "duration";
                                long j38 = Q6 != j27 ? Q6 + i26 : j27;
                                long i27 = i(xmlPullParser, "duration", j27);
                                ArrayList arrayList31 = new ArrayList();
                                ArrayList arrayList32 = new ArrayList();
                                ArrayList arrayList33 = new ArrayList();
                                long j39 = j27;
                                String str65 = MimeTypesReaderMetKeys.MATCH_VALUE_ATTR;
                                String str66 = "Period";
                                long j40 = j36;
                                int i28 = 0;
                                s sVar = null;
                                while (true) {
                                    xmlPullParser.next();
                                    if (AbstractC0133a.u(xmlPullParser, str52)) {
                                        if (i28 == 0) {
                                            j40 = d(xmlPullParser, j40);
                                            i28 = i7;
                                        }
                                        arrayList33.addAll(e(xmlPullParser, arrayList30, z6));
                                        arrayList4 = arrayList30;
                                        str = str53;
                                        str5 = str63;
                                        str2 = str52;
                                        str4 = str64;
                                        arrayList5 = arrayList33;
                                        z7 = z6;
                                        j10 = i27;
                                        j7 = j37;
                                        j11 = j38;
                                        arrayList7 = arrayList31;
                                        arrayList6 = arrayList32;
                                        str6 = str66;
                                        i8 = 0;
                                        j6 = -9223372036854775807L;
                                        j8 = j26;
                                        str3 = str62;
                                        j9 = j36;
                                        arrayList2 = arrayList29;
                                    } else {
                                        long j41 = j40;
                                        String str67 = str62;
                                        if (AbstractC0133a.u(xmlPullParser, "AdaptationSet")) {
                                            if (arrayList33.isEmpty()) {
                                                arrayList8 = arrayList30;
                                                arrayList4 = arrayList8;
                                            } else {
                                                arrayList4 = arrayList30;
                                                arrayList8 = arrayList33;
                                            }
                                            String attributeValue12 = xmlPullParser.getAttributeValue(null, str63);
                                            long parseLong = attributeValue12 == null ? -1L : Long.parseLong(attributeValue12);
                                            int g2 = g(xmlPullParser);
                                            String str68 = "SegmentTemplate";
                                            String attributeValue13 = xmlPullParser.getAttributeValue(null, "mimeType");
                                            String str69 = "AdaptationSet";
                                            ArrayList arrayList34 = arrayList29;
                                            String attributeValue14 = xmlPullParser.getAttributeValue(null, "codecs");
                                            long j42 = j26;
                                            String attributeValue15 = xmlPullParser.getAttributeValue(null, "scte214:supplementalCodecs");
                                            xmlPullParser.getAttributeValue(null, "scte214:supplementalProfiles");
                                            String str70 = str64;
                                            String attributeValue16 = xmlPullParser.getAttributeValue(null, "width");
                                            int parseInt3 = attributeValue16 == null ? -1 : Integer.parseInt(attributeValue16);
                                            arrayList5 = arrayList33;
                                            String attributeValue17 = xmlPullParser.getAttributeValue(null, "height");
                                            int parseInt4 = attributeValue17 == null ? -1 : Integer.parseInt(attributeValue17);
                                            float j43 = j(xmlPullParser, -1.0f);
                                            String str71 = "SegmentList";
                                            String str72 = "SegmentBase";
                                            String attributeValue18 = xmlPullParser.getAttributeValue(null, "audioSamplingRate");
                                            int parseInt5 = attributeValue18 == null ? -1 : Integer.parseInt(attributeValue18);
                                            String attributeValue19 = xmlPullParser.getAttributeValue(null, str53);
                                            String str73 = "audioSamplingRate";
                                            String attributeValue20 = xmlPullParser.getAttributeValue(null, "label");
                                            ArrayList arrayList35 = new ArrayList();
                                            String str74 = attributeValue20;
                                            ArrayList arrayList36 = new ArrayList();
                                            ArrayList arrayList37 = new ArrayList();
                                            ArrayList arrayList38 = new ArrayList();
                                            float f11 = j43;
                                            ArrayList arrayList39 = new ArrayList();
                                            String str75 = "height";
                                            ArrayList arrayList40 = new ArrayList();
                                            String str76 = "width";
                                            ArrayList arrayList41 = new ArrayList();
                                            String str77 = "scte214:supplementalProfiles";
                                            ArrayList arrayList42 = new ArrayList();
                                            ArrayList arrayList43 = new ArrayList();
                                            String str78 = "codecs";
                                            String str79 = "scte214:supplementalCodecs";
                                            String str80 = "mimeType";
                                            ArrayList arrayList44 = arrayList38;
                                            s sVar2 = sVar;
                                            long j44 = j39;
                                            long j45 = j41;
                                            int i29 = g2;
                                            String str81 = attributeValue19;
                                            int i30 = 0;
                                            String str82 = null;
                                            int i31 = -1;
                                            while (true) {
                                                xmlPullParser.next();
                                                if (AbstractC0133a.u(xmlPullParser, str52)) {
                                                    if (i30 == 0) {
                                                        j45 = d(xmlPullParser, j45);
                                                        i30 = i7;
                                                    }
                                                    j14 = j45;
                                                    arrayList43.addAll(e(xmlPullParser, arrayList8, z6));
                                                } else {
                                                    j14 = j45;
                                                    if (AbstractC0133a.u(xmlPullParser, "ContentProtection")) {
                                                        Pair f12 = f(xmlPullParser);
                                                        Object obj2 = f12.first;
                                                        if (obj2 != null) {
                                                            str82 = (String) obj2;
                                                        }
                                                        Object obj3 = f12.second;
                                                        if (obj3 != null) {
                                                            arrayList36.add((C0119l) obj3);
                                                        }
                                                    } else if (AbstractC0133a.u(xmlPullParser, "ContentComponent")) {
                                                        String attributeValue21 = xmlPullParser.getAttributeValue(null, str53);
                                                        if (str81 == null) {
                                                            str81 = attributeValue21;
                                                        } else if (attributeValue21 != null) {
                                                            AbstractC0133a.i(str81.equals(attributeValue21));
                                                        }
                                                        int g3 = g(xmlPullParser);
                                                        if (i29 == -1) {
                                                            i29 = g3;
                                                        } else if (g3 != -1) {
                                                            AbstractC0133a.i(i29 == g3 ? i7 : 0);
                                                        }
                                                    } else {
                                                        if (AbstractC0133a.u(xmlPullParser, "Role")) {
                                                            arrayList39.add(h(xmlPullParser, "Role"));
                                                            str5 = str63;
                                                            str12 = str81;
                                                            i9 = i29;
                                                            str2 = str52;
                                                            z7 = z6;
                                                            arrayList9 = arrayList36;
                                                            arrayList7 = arrayList31;
                                                            arrayList6 = arrayList32;
                                                            str22 = str68;
                                                            str13 = str69;
                                                            str24 = attributeValue15;
                                                            str14 = str70;
                                                            str21 = str71;
                                                            str23 = str72;
                                                            str15 = str73;
                                                            arrayList16 = arrayList37;
                                                            f6 = f11;
                                                            str16 = str77;
                                                            arrayList14 = arrayList42;
                                                            str17 = str79;
                                                            str18 = str78;
                                                            str19 = str80;
                                                            i8 = 0;
                                                            arrayList10 = arrayList43;
                                                            arrayList15 = arrayList41;
                                                            j17 = i27;
                                                            j8 = j42;
                                                            arrayList13 = arrayList40;
                                                            str25 = str53;
                                                        } else {
                                                            String str83 = "AudioChannelConfiguration";
                                                            if (AbstractC0133a.u(xmlPullParser, "AudioChannelConfiguration")) {
                                                                str5 = str63;
                                                                str12 = str81;
                                                                str2 = str52;
                                                                z7 = z6;
                                                                arrayList9 = arrayList36;
                                                                i31 = c(xmlPullParser, attributeValue14);
                                                                arrayList7 = arrayList31;
                                                                arrayList6 = arrayList32;
                                                                str22 = str68;
                                                                str24 = attributeValue15;
                                                                str14 = str70;
                                                                str21 = str71;
                                                                str23 = str72;
                                                                str15 = str73;
                                                                arrayList16 = arrayList37;
                                                                f6 = f11;
                                                                str16 = str77;
                                                                arrayList14 = arrayList42;
                                                                str17 = str79;
                                                                str18 = str78;
                                                                str19 = str80;
                                                                i8 = 0;
                                                                arrayList10 = arrayList43;
                                                                arrayList15 = arrayList41;
                                                                j17 = i27;
                                                                j8 = j42;
                                                                arrayList13 = arrayList40;
                                                                str25 = str53;
                                                                str27 = str69;
                                                                i10 = i29;
                                                                arrayList12 = arrayList8;
                                                                j9 = j36;
                                                                j11 = j38;
                                                                arrayList2 = arrayList34;
                                                                str20 = attributeValue14;
                                                                arrayList11 = arrayList39;
                                                                j15 = j37;
                                                                if (AbstractC0133a.s(xmlPullParser, str27)) {
                                                                    long j46 = j15;
                                                                    i7 = 1;
                                                                    str53 = str25;
                                                                    str72 = str23;
                                                                    str68 = str22;
                                                                    arrayList34 = arrayList2;
                                                                    j36 = j9;
                                                                    attributeValue14 = str20;
                                                                    arrayList39 = arrayList11;
                                                                    z6 = z7;
                                                                    i29 = i10;
                                                                    arrayList41 = arrayList15;
                                                                    arrayList43 = arrayList10;
                                                                    str78 = str18;
                                                                    arrayList36 = arrayList9;
                                                                    str80 = str19;
                                                                    str73 = str15;
                                                                    arrayList42 = arrayList14;
                                                                    str70 = str14;
                                                                    str63 = str5;
                                                                    str69 = str27;
                                                                    j38 = j11;
                                                                    str71 = str21;
                                                                    arrayList8 = arrayList12;
                                                                    attributeValue15 = str24;
                                                                    arrayList40 = arrayList13;
                                                                    j37 = j46;
                                                                    str79 = str17;
                                                                    j45 = j14;
                                                                    str77 = str16;
                                                                    f11 = f6;
                                                                    str81 = str12;
                                                                    arrayList37 = arrayList16;
                                                                    j42 = j8;
                                                                    i27 = j17;
                                                                    str52 = str2;
                                                                    arrayList31 = arrayList7;
                                                                    arrayList32 = arrayList6;
                                                                } else {
                                                                    ArrayList arrayList45 = new ArrayList(arrayList14.size());
                                                                    int i32 = i8;
                                                                    while (i32 < arrayList14.size()) {
                                                                        ArrayList arrayList46 = arrayList14;
                                                                        C0393d c0393d = (C0393d) arrayList46.get(i32);
                                                                        C0122o a6 = c0393d.f5907a.a();
                                                                        if (str74 != null && arrayList35.isEmpty()) {
                                                                            str48 = str74;
                                                                            a6.f2577b = str48;
                                                                        } else {
                                                                            str48 = str74;
                                                                            a6.f2578c = I.u(arrayList35);
                                                                        }
                                                                        String str84 = c0393d.f5910d;
                                                                        if (str84 == null) {
                                                                            str84 = str82;
                                                                        }
                                                                        ArrayList arrayList47 = c0393d.e;
                                                                        ArrayList arrayList48 = arrayList9;
                                                                        arrayList47.addAll(arrayList48);
                                                                        long j47 = j11;
                                                                        if (arrayList47.isEmpty()) {
                                                                            str74 = str48;
                                                                            str49 = str25;
                                                                            j22 = j15;
                                                                        } else {
                                                                            int i33 = i8;
                                                                            while (true) {
                                                                                if (i33 < arrayList47.size()) {
                                                                                    C0119l c0119l = (C0119l) arrayList47.get(i33);
                                                                                    str74 = str48;
                                                                                    if (!AbstractC0114g.f2542c.equals(c0119l.f2555p) || (str50 = c0119l.f2556q) == null) {
                                                                                        i33++;
                                                                                        str48 = str74;
                                                                                    } else {
                                                                                        arrayList47.remove(i33);
                                                                                    }
                                                                                } else {
                                                                                    str74 = str48;
                                                                                    str50 = null;
                                                                                }
                                                                            }
                                                                            if (str50 != null) {
                                                                                int i34 = i8;
                                                                                while (i34 < arrayList47.size()) {
                                                                                    C0119l c0119l2 = (C0119l) arrayList47.get(i34);
                                                                                    String str85 = str25;
                                                                                    if (AbstractC0114g.f2541b.equals(c0119l2.f2555p) && c0119l2.f2556q == null) {
                                                                                        j23 = j15;
                                                                                        arrayList47.set(i34, new C0119l(AbstractC0114g.f2542c, str50, c0119l2.f2557r, c0119l2.f2558s));
                                                                                    } else {
                                                                                        j23 = j15;
                                                                                    }
                                                                                    i34++;
                                                                                    j15 = j23;
                                                                                    str25 = str85;
                                                                                }
                                                                            }
                                                                            str49 = str25;
                                                                            j22 = j15;
                                                                            for (int size = arrayList47.size() - 1; size >= 0; size--) {
                                                                                C0119l c0119l3 = (C0119l) arrayList47.get(size);
                                                                                if (c0119l3.f2558s == null) {
                                                                                    int i35 = i8;
                                                                                    while (true) {
                                                                                        if (i35 < arrayList47.size()) {
                                                                                            C0119l c0119l4 = (C0119l) arrayList47.get(i35);
                                                                                            if (c0119l4.f2558s != null && c0119l3.f2558s == null) {
                                                                                                UUID uuid = c0119l3.f2555p;
                                                                                                c0119l4.getClass();
                                                                                                UUID uuid2 = AbstractC0114g.f2540a;
                                                                                                UUID uuid3 = c0119l4.f2555p;
                                                                                                if (((uuid2.equals(uuid3) || uuid.equals(uuid3)) ? 1 : i8) != 0) {
                                                                                                    arrayList47.remove(size);
                                                                                                }
                                                                                            }
                                                                                            i35++;
                                                                                        }
                                                                                    }
                                                                                }
                                                                            }
                                                                            a6.f2590q = new C0120m(str84, arrayList47);
                                                                        }
                                                                        ArrayList arrayList49 = c0393d.f5911f;
                                                                        arrayList49.addAll(arrayList16);
                                                                        C0123p c0123p = new C0123p(a6);
                                                                        I i36 = c0393d.f5908b;
                                                                        s sVar3 = c0393d.f5909c;
                                                                        if (sVar3 instanceof r) {
                                                                            kVar = new l(c0123p, i36, (r) sVar3, arrayList49);
                                                                        } else if (sVar3 instanceof n) {
                                                                            kVar = new k(c0123p, i36, (n) sVar3, arrayList49);
                                                                        } else {
                                                                            throw new IllegalArgumentException("segmentBase must be of type SingleSegmentBase or MultiSegmentBase");
                                                                        }
                                                                        arrayList45.add(kVar);
                                                                        i32++;
                                                                        arrayList9 = arrayList48;
                                                                        j15 = j22;
                                                                        arrayList14 = arrayList46;
                                                                        str25 = str49;
                                                                        j11 = j47;
                                                                    }
                                                                    str = str25;
                                                                    i7 = 1;
                                                                    arrayList7.add(new C0390a(parseLong, i10, arrayList45, arrayList44, arrayList13, arrayList15));
                                                                    j10 = j17;
                                                                    str3 = str67;
                                                                    j7 = j15;
                                                                    str4 = str14;
                                                                }
                                                            } else {
                                                                String str86 = str53;
                                                                if (AbstractC0133a.u(xmlPullParser, "Accessibility")) {
                                                                    arrayList44.add(h(xmlPullParser, "Accessibility"));
                                                                } else if (AbstractC0133a.u(xmlPullParser, "EssentialProperty")) {
                                                                    arrayList40.add(h(xmlPullParser, "EssentialProperty"));
                                                                } else {
                                                                    arrayList9 = arrayList36;
                                                                    if (!AbstractC0133a.u(xmlPullParser, "SupplementalProperty")) {
                                                                        String str87 = "SupplementalProperty";
                                                                        String str88 = "Representation";
                                                                        if (AbstractC0133a.u(xmlPullParser, "Representation")) {
                                                                            if (arrayList43.isEmpty()) {
                                                                                str28 = "InbandEventStream";
                                                                                arrayList17 = arrayList8;
                                                                            } else {
                                                                                str28 = "InbandEventStream";
                                                                                arrayList17 = arrayList43;
                                                                            }
                                                                            String str89 = "EssentialProperty";
                                                                            String str90 = "ContentProtection";
                                                                            String attributeValue22 = xmlPullParser.getAttributeValue(null, str63);
                                                                            String str91 = str63;
                                                                            String attributeValue23 = xmlPullParser.getAttributeValue(null, "bandwidth");
                                                                            if (attributeValue23 == null) {
                                                                                String str92 = str80;
                                                                                str29 = attributeValue22;
                                                                                str30 = str92;
                                                                                parseInt = -1;
                                                                            } else {
                                                                                parseInt = Integer.parseInt(attributeValue23);
                                                                                String str93 = str80;
                                                                                str29 = attributeValue22;
                                                                                str30 = str93;
                                                                            }
                                                                            String attributeValue24 = xmlPullParser.getAttributeValue(null, str30);
                                                                            String str94 = str78;
                                                                            int i37 = parseInt;
                                                                            String str95 = attributeValue24 == null ? attributeValue13 : attributeValue24;
                                                                            String attributeValue25 = xmlPullParser.getAttributeValue(null, str94);
                                                                            String str96 = str79;
                                                                            str18 = str94;
                                                                            str19 = str30;
                                                                            String str97 = attributeValue25 == null ? attributeValue14 : attributeValue25;
                                                                            String attributeValue26 = xmlPullParser.getAttributeValue(null, str96);
                                                                            String str98 = str77;
                                                                            str17 = str96;
                                                                            String str99 = attributeValue26 == null ? attributeValue15 : attributeValue26;
                                                                            xmlPullParser.getAttributeValue(null, str98);
                                                                            str16 = str98;
                                                                            String str100 = str76;
                                                                            String attributeValue27 = xmlPullParser.getAttributeValue(null, str100);
                                                                            int parseInt6 = attributeValue27 == null ? parseInt3 : Integer.parseInt(attributeValue27);
                                                                            str76 = str100;
                                                                            String str101 = str75;
                                                                            String attributeValue28 = xmlPullParser.getAttributeValue(null, str101);
                                                                            int parseInt7 = attributeValue28 == null ? parseInt4 : Integer.parseInt(attributeValue28);
                                                                            str75 = str101;
                                                                            float f13 = f11;
                                                                            String str102 = str81;
                                                                            float j48 = j(xmlPullParser, f13);
                                                                            f6 = f13;
                                                                            String str103 = str73;
                                                                            String attributeValue29 = xmlPullParser.getAttributeValue(null, str103);
                                                                            int parseInt8 = attributeValue29 == null ? parseInt5 : Integer.parseInt(attributeValue29);
                                                                            ArrayList arrayList50 = new ArrayList();
                                                                            ArrayList arrayList51 = new ArrayList();
                                                                            ArrayList arrayList52 = new ArrayList(arrayList40);
                                                                            ArrayList arrayList53 = arrayList40;
                                                                            ArrayList arrayList54 = new ArrayList(arrayList41);
                                                                            ArrayList arrayList55 = new ArrayList();
                                                                            ArrayList arrayList56 = arrayList52;
                                                                            str15 = str103;
                                                                            String str104 = attributeValue14;
                                                                            int i38 = i29;
                                                                            s sVar4 = sVar2;
                                                                            long j49 = j44;
                                                                            int i39 = i31;
                                                                            long j50 = j14;
                                                                            int i40 = 0;
                                                                            String str105 = null;
                                                                            while (true) {
                                                                                xmlPullParser.next();
                                                                                if (AbstractC0133a.u(xmlPullParser, str52)) {
                                                                                    if (i40 == 0) {
                                                                                        j50 = d(xmlPullParser, j50);
                                                                                        i40 = i7;
                                                                                    }
                                                                                    f7 = j48;
                                                                                    arrayList55.addAll(e(xmlPullParser, arrayList17, z6));
                                                                                } else {
                                                                                    f7 = j48;
                                                                                    if (AbstractC0133a.u(xmlPullParser, str83)) {
                                                                                        i39 = c(xmlPullParser, str97);
                                                                                    } else {
                                                                                        String str106 = str72;
                                                                                        if (AbstractC0133a.u(xmlPullParser, str106)) {
                                                                                            arrayList18 = arrayList55;
                                                                                            sVar4 = o(xmlPullParser, (r) sVar4);
                                                                                            str32 = str106;
                                                                                            str2 = str52;
                                                                                            z7 = z6;
                                                                                            arrayList19 = arrayList17;
                                                                                            str33 = str83;
                                                                                            arrayList7 = arrayList31;
                                                                                            arrayList6 = arrayList32;
                                                                                            str39 = str68;
                                                                                            str34 = str69;
                                                                                            str14 = str70;
                                                                                            str31 = str71;
                                                                                            i11 = parseInt8;
                                                                                            str35 = str102;
                                                                                            arrayList20 = arrayList42;
                                                                                            i12 = i37;
                                                                                            str36 = str86;
                                                                                            str41 = str87;
                                                                                            str37 = str89;
                                                                                            str5 = str91;
                                                                                            i13 = i38;
                                                                                            arrayList21 = arrayList50;
                                                                                            i14 = i39;
                                                                                            f8 = f7;
                                                                                            arrayList10 = arrayList43;
                                                                                            arrayList22 = arrayList41;
                                                                                            str38 = str97;
                                                                                            str40 = str28;
                                                                                            str43 = str105;
                                                                                            arrayList23 = arrayList51;
                                                                                            arrayList25 = arrayList56;
                                                                                            j21 = j49;
                                                                                            str42 = str88;
                                                                                            arrayList26 = arrayList54;
                                                                                            arrayList12 = arrayList8;
                                                                                            j9 = j36;
                                                                                            j19 = j38;
                                                                                            arrayList2 = arrayList34;
                                                                                            str20 = str104;
                                                                                            arrayList24 = arrayList39;
                                                                                            j20 = i27;
                                                                                            j15 = j37;
                                                                                            j8 = j42;
                                                                                            arrayList13 = arrayList53;
                                                                                            if (AbstractC0133a.s(xmlPullParser, str42)) {
                                                                                                if (F.i(str95)) {
                                                                                                    if (str38 != null) {
                                                                                                        for (String str107 : C.X(str38)) {
                                                                                                            d6 = F.d(str107);
                                                                                                            if (d6 != null && F.i(d6)) {
                                                                                                                str44 = d6;
                                                                                                                str45 = str95;
                                                                                                            }
                                                                                                        }
                                                                                                    }
                                                                                                    d6 = null;
                                                                                                    str44 = d6;
                                                                                                    str45 = str95;
                                                                                                } else if (F.m(str95)) {
                                                                                                    if (str38 != null) {
                                                                                                        for (String str108 : C.X(str38)) {
                                                                                                            d6 = F.d(str108);
                                                                                                            if (d6 != null && F.m(d6)) {
                                                                                                                str44 = d6;
                                                                                                                str45 = str95;
                                                                                                            }
                                                                                                        }
                                                                                                    }
                                                                                                    d6 = null;
                                                                                                    str44 = d6;
                                                                                                    str45 = str95;
                                                                                                } else if (F.l(str95) || F.k(str95)) {
                                                                                                    str44 = str95;
                                                                                                    str45 = str44;
                                                                                                } else {
                                                                                                    str45 = str95;
                                                                                                    if ("application/mp4".equals(str45)) {
                                                                                                        str44 = F.d(str38);
                                                                                                        if ("text/vtt".equals(str44)) {
                                                                                                            str44 = "application/x-mp4-vtt";
                                                                                                        }
                                                                                                    } else {
                                                                                                        str44 = null;
                                                                                                    }
                                                                                                }
                                                                                                if ("audio/eac3".equals(str44)) {
                                                                                                    int i41 = 0;
                                                                                                    while (true) {
                                                                                                        str46 = "ec+3";
                                                                                                        if (i41 >= arrayList26.size()) {
                                                                                                            arrayList27 = arrayList26;
                                                                                                            str44 = "audio/eac3";
                                                                                                        } else {
                                                                                                            C0395f c0395f = (C0395f) arrayList26.get(i41);
                                                                                                            arrayList27 = arrayList26;
                                                                                                            String str109 = c0395f.f5917a;
                                                                                                            String str110 = c0395f.f5918b;
                                                                                                            int i42 = i41;
                                                                                                            if ((!"tag:dolby.com,2018:dash:EC3_ExtensionType:2018".equals(str109) || !"JOC".equals(str110)) && (!"tag:dolby.com,2014:dash:DolbyDigitalPlusExtensionType:2014".equals(str109) || !"ec+3".equals(str110))) {
                                                                                                                i41 = i42 + 1;
                                                                                                                arrayList26 = arrayList27;
                                                                                                            }
                                                                                                        }
                                                                                                    }
                                                                                                    str44 = "audio/eac3-joc";
                                                                                                } else {
                                                                                                    arrayList27 = arrayList26;
                                                                                                }
                                                                                                str46 = str38;
                                                                                                String str111 = str99;
                                                                                                if (F.j(str46, str111)) {
                                                                                                    str44 = "video/dolby-vision";
                                                                                                    str46 = str111 != null ? str111 : str46;
                                                                                                }
                                                                                                int i43 = 0;
                                                                                                int i44 = 0;
                                                                                                while (i43 < arrayList24.size()) {
                                                                                                    ArrayList arrayList57 = arrayList24;
                                                                                                    int i45 = i43;
                                                                                                    C0395f c0395f2 = (C0395f) arrayList57.get(i43);
                                                                                                    long j51 = j19;
                                                                                                    if (Q5.a.o("urn:mpeg:dash:role:2011", c0395f2.f5917a)) {
                                                                                                        String str112 = c0395f2.f5918b;
                                                                                                        i44 = ((str112 != null && (str112.equals("forced_subtitle") || str112.equals("forced-subtitle"))) ? 2 : 0) | i44;
                                                                                                    }
                                                                                                    i43 = i45 + 1;
                                                                                                    arrayList24 = arrayList57;
                                                                                                    j19 = j51;
                                                                                                }
                                                                                                long j52 = j19;
                                                                                                ArrayList arrayList58 = arrayList24;
                                                                                                int i46 = 0;
                                                                                                int i47 = 0;
                                                                                                while (i46 < arrayList58.size()) {
                                                                                                    C0395f c0395f3 = (C0395f) arrayList58.get(i46);
                                                                                                    int i48 = i46;
                                                                                                    if (Q5.a.o("urn:mpeg:dash:role:2011", c0395f3.f5917a)) {
                                                                                                        i47 = m(c0395f3.f5918b) | i47;
                                                                                                    }
                                                                                                    i46 = i48 + 1;
                                                                                                }
                                                                                                int i49 = i47;
                                                                                                int i50 = 0;
                                                                                                int i51 = 0;
                                                                                                while (i50 < arrayList44.size()) {
                                                                                                    ArrayList arrayList59 = arrayList44;
                                                                                                    int i52 = i50;
                                                                                                    C0395f c0395f4 = (C0395f) arrayList59.get(i50);
                                                                                                    int i53 = i51;
                                                                                                    String str113 = c0395f4.f5917a;
                                                                                                    String str114 = str45;
                                                                                                    String str115 = c0395f4.f5918b;
                                                                                                    if (Q5.a.o("urn:mpeg:dash:role:2011", str113)) {
                                                                                                        i16 = m(str115);
                                                                                                    } else if (Q5.a.o("urn:tva:metadata:cs:AudioPurposeCS:2007", c0395f4.f5917a)) {
                                                                                                        if (str115 != null) {
                                                                                                            switch (str115.hashCode()) {
                                                                                                                case 49:
                                                                                                                    if (str115.equals("1")) {
                                                                                                                        i15 = 0;
                                                                                                                        break;
                                                                                                                    }
                                                                                                                    break;
                                                                                                                case 50:
                                                                                                                    if (str115.equals("2")) {
                                                                                                                        i15 = i7;
                                                                                                                        break;
                                                                                                                    }
                                                                                                                    break;
                                                                                                                case 51:
                                                                                                                    if (str115.equals("3")) {
                                                                                                                        i15 = 2;
                                                                                                                        break;
                                                                                                                    }
                                                                                                                    break;
                                                                                                                case 52:
                                                                                                                    if (str115.equals("4")) {
                                                                                                                        i15 = 3;
                                                                                                                        break;
                                                                                                                    }
                                                                                                                    break;
                                                                                                                case 54:
                                                                                                                    if (str115.equals("6")) {
                                                                                                                        i15 = 4;
                                                                                                                        break;
                                                                                                                    }
                                                                                                                    break;
                                                                                                            }
                                                                                                            i15 = -1;
                                                                                                            switch (i15) {
                                                                                                                case 0:
                                                                                                                    i16 = 512;
                                                                                                                    break;
                                                                                                                case 1:
                                                                                                                    i16 = 2048;
                                                                                                                    break;
                                                                                                                case 2:
                                                                                                                    i16 = 4;
                                                                                                                    break;
                                                                                                                case 3:
                                                                                                                    i16 = 8;
                                                                                                                    break;
                                                                                                                case 4:
                                                                                                                    i16 = i7;
                                                                                                                    break;
                                                                                                            }
                                                                                                        }
                                                                                                        i16 = 0;
                                                                                                    } else {
                                                                                                        i51 = i53;
                                                                                                        i50 = i52 + 1;
                                                                                                        arrayList44 = arrayList59;
                                                                                                        str45 = str114;
                                                                                                    }
                                                                                                    i51 = i53 | i16;
                                                                                                    i50 = i52 + 1;
                                                                                                    arrayList44 = arrayList59;
                                                                                                    str45 = str114;
                                                                                                }
                                                                                                String str116 = str45;
                                                                                                ArrayList arrayList60 = arrayList44;
                                                                                                int n7 = i49 | i51 | n(arrayList25) | n(arrayList27);
                                                                                                int i54 = 0;
                                                                                                while (true) {
                                                                                                    if (i54 < arrayList25.size()) {
                                                                                                        C0395f c0395f5 = (C0395f) arrayList25.get(i54);
                                                                                                        int i55 = i54;
                                                                                                        if ((Q5.a.o("http://dashif.org/thumbnail_tile", c0395f5.f5917a) || Q5.a.o("http://dashif.org/guidelines/thumbnail_tile", c0395f5.f5917a)) && (str47 = c0395f5.f5918b) != null) {
                                                                                                            String str117 = C.f3053a;
                                                                                                            String[] split = str47.split("x", -1);
                                                                                                            if (split.length == 2) {
                                                                                                                i8 = 0;
                                                                                                                try {
                                                                                                                    pair = Pair.create(Integer.valueOf(Integer.parseInt(split[0])), Integer.valueOf(Integer.parseInt(split[i7])));
                                                                                                                } catch (NumberFormatException unused) {
                                                                                                                    continue;
                                                                                                                }
                                                                                                            }
                                                                                                        }
                                                                                                        i54 = i55 + 1;
                                                                                                    } else {
                                                                                                        i8 = 0;
                                                                                                        pair = null;
                                                                                                    }
                                                                                                }
                                                                                                C0122o c0122o = new C0122o();
                                                                                                c0122o.f2576a = str29;
                                                                                                c0122o.f2586l = F.n(str116);
                                                                                                c0122o.f2587m = F.n(str44);
                                                                                                c0122o.f2584j = str46;
                                                                                                c0122o.f2583i = i12;
                                                                                                c0122o.e = i44;
                                                                                                c0122o.f2580f = n7;
                                                                                                String str118 = str35;
                                                                                                c0122o.f2579d = str118;
                                                                                                c0122o.f2573L = pair != null ? ((Integer) pair.first).intValue() : -1;
                                                                                                c0122o.f2574M = pair != null ? ((Integer) pair.second).intValue() : -1;
                                                                                                if (F.m(str44)) {
                                                                                                    c0122o.f2593t = parseInt6;
                                                                                                    c0122o.f2594u = parseInt7;
                                                                                                    c0122o.f2597x = f8;
                                                                                                } else {
                                                                                                    int i56 = parseInt6;
                                                                                                    int i57 = parseInt7;
                                                                                                    if (F.i(str44)) {
                                                                                                        c0122o.f2567E = i14;
                                                                                                        c0122o.f2568F = i11;
                                                                                                    } else if (F.l(str44)) {
                                                                                                        if ("application/cea-608".equals(str44)) {
                                                                                                            int i58 = i8;
                                                                                                            while (i58 < arrayList60.size()) {
                                                                                                                C0395f c0395f6 = (C0395f) arrayList60.get(i58);
                                                                                                                String str119 = c0395f6.f5917a;
                                                                                                                String str120 = c0395f6.f5918b;
                                                                                                                if ("urn:scte:dash:cc:cea-608:2015".equals(str119) && str120 != null) {
                                                                                                                    Matcher matcher = f5913q.matcher(str120);
                                                                                                                    if (matcher.matches()) {
                                                                                                                        parseInt2 = Integer.parseInt(matcher.group(i7));
                                                                                                                        c0122o.f2572J = parseInt2;
                                                                                                                    } else {
                                                                                                                        AbstractC0133a.A("MpdParser", "Unable to parse CEA-608 channel number from: ".concat(str120));
                                                                                                                    }
                                                                                                                }
                                                                                                                i58++;
                                                                                                                i7 = 1;
                                                                                                            }
                                                                                                            parseInt2 = -1;
                                                                                                            c0122o.f2572J = parseInt2;
                                                                                                        } else {
                                                                                                            if ("application/cea-708".equals(str44)) {
                                                                                                                for (int i59 = i8; i59 < arrayList60.size(); i59++) {
                                                                                                                    C0395f c0395f7 = (C0395f) arrayList60.get(i59);
                                                                                                                    String str121 = c0395f7.f5917a;
                                                                                                                    String str122 = c0395f7.f5918b;
                                                                                                                    if ("urn:scte:dash:cc:cea-708:2015".equals(str121) && str122 != null) {
                                                                                                                        Matcher matcher2 = f5914r.matcher(str122);
                                                                                                                        if (matcher2.matches()) {
                                                                                                                            parseInt2 = Integer.parseInt(matcher2.group(1));
                                                                                                                            c0122o.f2572J = parseInt2;
                                                                                                                        } else {
                                                                                                                            AbstractC0133a.A("MpdParser", "Unable to parse CEA-708 service block number from: ".concat(str122));
                                                                                                                        }
                                                                                                                    }
                                                                                                                }
                                                                                                            }
                                                                                                            parseInt2 = -1;
                                                                                                            c0122o.f2572J = parseInt2;
                                                                                                        }
                                                                                                        str6 = str66;
                                                                                                        j40 = j41;
                                                                                                    } else if (F.k(str44)) {
                                                                                                        c0122o.f2593t = i56;
                                                                                                        c0122o.f2594u = i57;
                                                                                                    }
                                                                                                }
                                                                                                C0123p c0123p2 = new C0123p(c0122o);
                                                                                                C0393d c0393d2 = new C0393d(c0123p2, !arrayList18.isEmpty() ? arrayList18 : arrayList19, sVar4 != null ? sVar4 : new r(null, 1L, 0L, 0L, 0L), str43, arrayList21, arrayList23, arrayList25, arrayList27);
                                                                                                int h6 = F.h(c0123p2.f2626n);
                                                                                                int i60 = i13;
                                                                                                if (i60 != -1) {
                                                                                                    if (h6 != -1) {
                                                                                                        AbstractC0133a.i(i60 == h6 ? 1 : i8);
                                                                                                    }
                                                                                                    h6 = i60;
                                                                                                }
                                                                                                ArrayList arrayList61 = arrayList20;
                                                                                                arrayList61.add(c0393d2);
                                                                                                str12 = str118;
                                                                                                arrayList44 = arrayList60;
                                                                                                arrayList11 = arrayList58;
                                                                                                arrayList14 = arrayList61;
                                                                                                str24 = attributeValue15;
                                                                                                arrayList16 = arrayList37;
                                                                                                j11 = j52;
                                                                                                str25 = str36;
                                                                                                str27 = str34;
                                                                                                str21 = str31;
                                                                                                str23 = str32;
                                                                                                str22 = str39;
                                                                                                arrayList15 = arrayList22;
                                                                                                j17 = j20;
                                                                                                i10 = h6;
                                                                                            } else {
                                                                                                arrayList54 = arrayList26;
                                                                                                i39 = i14;
                                                                                                str88 = str42;
                                                                                                arrayList56 = arrayList25;
                                                                                                arrayList50 = arrayList21;
                                                                                                arrayList51 = arrayList23;
                                                                                                str89 = str37;
                                                                                                str104 = str20;
                                                                                                arrayList41 = arrayList22;
                                                                                                str97 = str38;
                                                                                                str83 = str33;
                                                                                                arrayList53 = arrayList13;
                                                                                                arrayList55 = arrayList18;
                                                                                                j49 = j21;
                                                                                                str105 = str43;
                                                                                                arrayList17 = arrayList19;
                                                                                                i38 = i13;
                                                                                                arrayList31 = arrayList7;
                                                                                                arrayList32 = arrayList6;
                                                                                                arrayList42 = arrayList20;
                                                                                                str102 = str35;
                                                                                                i37 = i12;
                                                                                                parseInt8 = i11;
                                                                                                str86 = str36;
                                                                                                str70 = str14;
                                                                                                str72 = str32;
                                                                                                str91 = str5;
                                                                                                str68 = str39;
                                                                                                i7 = 1;
                                                                                                str28 = str40;
                                                                                                str87 = str41;
                                                                                                j42 = j8;
                                                                                                i27 = j20;
                                                                                                arrayList43 = arrayList10;
                                                                                                str52 = str2;
                                                                                                str69 = str34;
                                                                                                str71 = str31;
                                                                                                arrayList34 = arrayList2;
                                                                                                j36 = j9;
                                                                                                long j53 = j19;
                                                                                                arrayList8 = arrayList12;
                                                                                                j37 = j15;
                                                                                                arrayList39 = arrayList24;
                                                                                                z6 = z7;
                                                                                                j48 = f8;
                                                                                                j38 = j53;
                                                                                            }
                                                                                        } else {
                                                                                            arrayList18 = arrayList55;
                                                                                            String str123 = str71;
                                                                                            if (AbstractC0133a.u(xmlPullParser, str123)) {
                                                                                                arrayList10 = arrayList43;
                                                                                                str2 = str52;
                                                                                                long d7 = d(xmlPullParser, j49);
                                                                                                str31 = str123;
                                                                                                str32 = str106;
                                                                                                arrayList19 = arrayList17;
                                                                                                str33 = str83;
                                                                                                long j54 = j38;
                                                                                                arrayList7 = arrayList31;
                                                                                                arrayList6 = arrayList32;
                                                                                                str34 = str69;
                                                                                                str14 = str70;
                                                                                                i11 = parseInt8;
                                                                                                str35 = str102;
                                                                                                arrayList20 = arrayList42;
                                                                                                i12 = i37;
                                                                                                str36 = str86;
                                                                                                str37 = str89;
                                                                                                str5 = str91;
                                                                                                str20 = str104;
                                                                                                i13 = i38;
                                                                                                arrayList21 = arrayList50;
                                                                                                f8 = f7;
                                                                                                arrayList22 = arrayList41;
                                                                                                arrayList24 = arrayList39;
                                                                                                str38 = str97;
                                                                                                long j55 = j37;
                                                                                                arrayList23 = arrayList51;
                                                                                                arrayList12 = arrayList8;
                                                                                                long j56 = i27;
                                                                                                j9 = j36;
                                                                                                arrayList2 = arrayList34;
                                                                                                j8 = j42;
                                                                                                arrayList13 = arrayList53;
                                                                                                sVar4 = q(xmlPullParser, (o) sVar4, j54, j56, j50, d7, j55);
                                                                                                j20 = j56;
                                                                                                j19 = j54;
                                                                                                z7 = z6;
                                                                                                str39 = str68;
                                                                                                str42 = str88;
                                                                                                str43 = str105;
                                                                                                i14 = i39;
                                                                                                arrayList26 = arrayList54;
                                                                                                j15 = j55;
                                                                                                arrayList25 = arrayList56;
                                                                                                str41 = str87;
                                                                                                str40 = str28;
                                                                                                j21 = d7;
                                                                                            } else {
                                                                                                str31 = str123;
                                                                                                str32 = str106;
                                                                                                arrayList10 = arrayList43;
                                                                                                str2 = str52;
                                                                                                arrayList19 = arrayList17;
                                                                                                str33 = str83;
                                                                                                arrayList7 = arrayList31;
                                                                                                arrayList6 = arrayList32;
                                                                                                String str124 = str68;
                                                                                                str34 = str69;
                                                                                                str14 = str70;
                                                                                                i11 = parseInt8;
                                                                                                str35 = str102;
                                                                                                arrayList20 = arrayList42;
                                                                                                i12 = i37;
                                                                                                str36 = str86;
                                                                                                str37 = str89;
                                                                                                str5 = str91;
                                                                                                i13 = i38;
                                                                                                arrayList21 = arrayList50;
                                                                                                ArrayList arrayList62 = arrayList54;
                                                                                                f8 = f7;
                                                                                                arrayList22 = arrayList41;
                                                                                                str38 = str97;
                                                                                                arrayList23 = arrayList51;
                                                                                                long j57 = j37;
                                                                                                arrayList12 = arrayList8;
                                                                                                j9 = j36;
                                                                                                j19 = j38;
                                                                                                arrayList2 = arrayList34;
                                                                                                str20 = str104;
                                                                                                arrayList24 = arrayList39;
                                                                                                j20 = i27;
                                                                                                j8 = j42;
                                                                                                arrayList13 = arrayList53;
                                                                                                if (AbstractC0133a.u(xmlPullParser, str124)) {
                                                                                                    j15 = j57;
                                                                                                    long d8 = d(xmlPullParser, j49);
                                                                                                    str39 = str124;
                                                                                                    z7 = z6;
                                                                                                    long j58 = j50;
                                                                                                    sVar4 = r(xmlPullParser, (p) sVar4, arrayList22, j19, j20, j58, d8, j15);
                                                                                                    j50 = j58;
                                                                                                    j19 = j19;
                                                                                                    str40 = str28;
                                                                                                    str42 = str88;
                                                                                                    str43 = str105;
                                                                                                    i14 = i39;
                                                                                                    arrayList26 = arrayList62;
                                                                                                    str41 = str87;
                                                                                                    j21 = d8;
                                                                                                    arrayList25 = arrayList56;
                                                                                                } else {
                                                                                                    str39 = str124;
                                                                                                    z7 = z6;
                                                                                                    String str125 = str90;
                                                                                                    j15 = j57;
                                                                                                    if (AbstractC0133a.u(xmlPullParser, str125)) {
                                                                                                        Pair f14 = f(xmlPullParser);
                                                                                                        Object obj4 = f14.first;
                                                                                                        if (obj4 != null) {
                                                                                                            str105 = (String) obj4;
                                                                                                        }
                                                                                                        Object obj5 = f14.second;
                                                                                                        if (obj5 != null) {
                                                                                                            arrayList21.add((C0119l) obj5);
                                                                                                        }
                                                                                                        str90 = str125;
                                                                                                        str41 = str87;
                                                                                                        str40 = str28;
                                                                                                        str43 = str105;
                                                                                                        arrayList25 = arrayList56;
                                                                                                        i14 = i39;
                                                                                                        j21 = j49;
                                                                                                        str42 = str88;
                                                                                                        arrayList26 = arrayList62;
                                                                                                    } else {
                                                                                                        str40 = str28;
                                                                                                        if (AbstractC0133a.u(xmlPullParser, str40)) {
                                                                                                            arrayList23.add(h(xmlPullParser, str40));
                                                                                                            str90 = str125;
                                                                                                            str41 = str87;
                                                                                                            arrayList25 = arrayList56;
                                                                                                        } else if (AbstractC0133a.u(xmlPullParser, str37)) {
                                                                                                            arrayList25 = arrayList56;
                                                                                                            arrayList25.add(h(xmlPullParser, str37));
                                                                                                            str90 = str125;
                                                                                                            str41 = str87;
                                                                                                        } else {
                                                                                                            str41 = str87;
                                                                                                            arrayList25 = arrayList56;
                                                                                                            if (AbstractC0133a.u(xmlPullParser, str41)) {
                                                                                                                str90 = str125;
                                                                                                                j21 = j49;
                                                                                                                arrayList26 = arrayList62;
                                                                                                                arrayList26.add(h(xmlPullParser, str41));
                                                                                                            } else {
                                                                                                                str90 = str125;
                                                                                                                j21 = j49;
                                                                                                                arrayList26 = arrayList62;
                                                                                                                b(xmlPullParser);
                                                                                                            }
                                                                                                            str42 = str88;
                                                                                                            str43 = str105;
                                                                                                            i14 = i39;
                                                                                                        }
                                                                                                        j21 = j49;
                                                                                                        arrayList26 = arrayList62;
                                                                                                        str42 = str88;
                                                                                                        str43 = str105;
                                                                                                        i14 = i39;
                                                                                                    }
                                                                                                }
                                                                                            }
                                                                                            if (AbstractC0133a.s(xmlPullParser, str42)) {
                                                                                            }
                                                                                        }
                                                                                    }
                                                                                }
                                                                                str2 = str52;
                                                                                z7 = z6;
                                                                                arrayList19 = arrayList17;
                                                                                str33 = str83;
                                                                                arrayList7 = arrayList31;
                                                                                arrayList6 = arrayList32;
                                                                                str39 = str68;
                                                                                str34 = str69;
                                                                                str14 = str70;
                                                                                str31 = str71;
                                                                                str32 = str72;
                                                                                i11 = parseInt8;
                                                                                str35 = str102;
                                                                                arrayList20 = arrayList42;
                                                                                i12 = i37;
                                                                                str36 = str86;
                                                                                str41 = str87;
                                                                                str37 = str89;
                                                                                str5 = str91;
                                                                                i13 = i38;
                                                                                arrayList21 = arrayList50;
                                                                                f8 = f7;
                                                                                arrayList18 = arrayList55;
                                                                                arrayList10 = arrayList43;
                                                                                arrayList22 = arrayList41;
                                                                                str38 = str97;
                                                                                str40 = str28;
                                                                                str43 = str105;
                                                                                arrayList23 = arrayList51;
                                                                                arrayList25 = arrayList56;
                                                                                i14 = i39;
                                                                                j21 = j49;
                                                                                str42 = str88;
                                                                                arrayList26 = arrayList54;
                                                                                arrayList12 = arrayList8;
                                                                                j9 = j36;
                                                                                j19 = j38;
                                                                                arrayList2 = arrayList34;
                                                                                str20 = str104;
                                                                                arrayList24 = arrayList39;
                                                                                j20 = i27;
                                                                                j15 = j37;
                                                                                j8 = j42;
                                                                                arrayList13 = arrayList53;
                                                                                if (AbstractC0133a.s(xmlPullParser, str42)) {
                                                                                }
                                                                            }
                                                                        } else {
                                                                            str5 = str63;
                                                                            str12 = str81;
                                                                            str2 = str52;
                                                                            z7 = z6;
                                                                            long j59 = j38;
                                                                            arrayList7 = arrayList31;
                                                                            arrayList6 = arrayList32;
                                                                            String str126 = str68;
                                                                            str13 = str69;
                                                                            str14 = str70;
                                                                            String str127 = str71;
                                                                            str15 = str73;
                                                                            f6 = f11;
                                                                            str16 = str77;
                                                                            str17 = str79;
                                                                            str18 = str78;
                                                                            str19 = str80;
                                                                            ArrayList arrayList63 = arrayList44;
                                                                            i8 = 0;
                                                                            str20 = attributeValue14;
                                                                            arrayList10 = arrayList43;
                                                                            ArrayList arrayList64 = arrayList41;
                                                                            arrayList11 = arrayList39;
                                                                            j15 = j37;
                                                                            ArrayList arrayList65 = arrayList42;
                                                                            arrayList12 = arrayList8;
                                                                            int i61 = i29;
                                                                            j9 = j36;
                                                                            arrayList2 = arrayList34;
                                                                            long j60 = i27;
                                                                            j8 = j42;
                                                                            arrayList13 = arrayList40;
                                                                            String str128 = str72;
                                                                            if (AbstractC0133a.u(xmlPullParser, str128)) {
                                                                                sVar2 = o(xmlPullParser, (r) sVar2);
                                                                                arrayList44 = arrayList63;
                                                                                arrayList14 = arrayList65;
                                                                                str24 = attributeValue15;
                                                                                arrayList16 = arrayList37;
                                                                                j11 = j59;
                                                                                str25 = str86;
                                                                                str21 = str127;
                                                                                str22 = str126;
                                                                                arrayList15 = arrayList64;
                                                                                j17 = j60;
                                                                                i10 = i61;
                                                                                str23 = str128;
                                                                            } else {
                                                                                str21 = str127;
                                                                                if (AbstractC0133a.u(xmlPullParser, str21)) {
                                                                                    long d9 = d(xmlPullParser, j44);
                                                                                    arrayList44 = arrayList63;
                                                                                    sVar2 = q(xmlPullParser, (o) sVar2, j59, j60, j14, d9, j15);
                                                                                    j15 = j15;
                                                                                    j11 = j59;
                                                                                    j44 = d9;
                                                                                    str24 = attributeValue15;
                                                                                    arrayList16 = arrayList37;
                                                                                    arrayList14 = arrayList65;
                                                                                    str25 = str86;
                                                                                    str27 = str13;
                                                                                    str22 = str126;
                                                                                    arrayList15 = arrayList64;
                                                                                    j17 = j60;
                                                                                    i10 = i61;
                                                                                    str23 = str128;
                                                                                } else {
                                                                                    arrayList44 = arrayList63;
                                                                                    long j61 = j44;
                                                                                    j16 = j14;
                                                                                    j11 = j59;
                                                                                    if (AbstractC0133a.u(xmlPullParser, str126)) {
                                                                                        long d10 = d(xmlPullParser, j61);
                                                                                        str22 = str126;
                                                                                        str23 = str128;
                                                                                        arrayList14 = arrayList65;
                                                                                        sVar2 = r(xmlPullParser, (p) sVar2, arrayList64, j11, j60, j16, d10, j15);
                                                                                        j17 = j60;
                                                                                        String str129 = attributeValue15;
                                                                                        arrayList15 = arrayList64;
                                                                                        j11 = j11;
                                                                                        str24 = str129;
                                                                                        j14 = j16;
                                                                                        j44 = d10;
                                                                                        arrayList16 = arrayList37;
                                                                                        i10 = i61;
                                                                                        str25 = str86;
                                                                                    } else {
                                                                                        str22 = str126;
                                                                                        i9 = i61;
                                                                                        String str130 = attributeValue15;
                                                                                        str23 = str128;
                                                                                        arrayList14 = arrayList65;
                                                                                        arrayList15 = arrayList64;
                                                                                        j17 = j60;
                                                                                        if (AbstractC0133a.u(xmlPullParser, "InbandEventStream")) {
                                                                                            arrayList16 = arrayList37;
                                                                                            arrayList16.add(h(xmlPullParser, "InbandEventStream"));
                                                                                            str24 = str130;
                                                                                            j18 = j61;
                                                                                            str25 = str86;
                                                                                        } else {
                                                                                            arrayList16 = arrayList37;
                                                                                            if (AbstractC0133a.u(xmlPullParser, "Label")) {
                                                                                                str24 = str130;
                                                                                                j18 = j61;
                                                                                                str25 = str86;
                                                                                                String attributeValue30 = xmlPullParser.getAttributeValue(null, str25);
                                                                                                String str131 = StringUtils.EMPTY;
                                                                                                while (true) {
                                                                                                    xmlPullParser.next();
                                                                                                    String str132 = str131;
                                                                                                    if (xmlPullParser.getEventType() == 4) {
                                                                                                        str26 = xmlPullParser.getText();
                                                                                                    } else {
                                                                                                        b(xmlPullParser);
                                                                                                        str26 = str132;
                                                                                                    }
                                                                                                    if (AbstractC0133a.s(xmlPullParser, "Label")) {
                                                                                                        arrayList35.add(new C0124q(attributeValue30, str26));
                                                                                                    } else {
                                                                                                        str131 = str26;
                                                                                                    }
                                                                                                }
                                                                                            } else {
                                                                                                str24 = str130;
                                                                                                j18 = j61;
                                                                                                str25 = str86;
                                                                                                if (xmlPullParser.getEventType() == 2) {
                                                                                                    b(xmlPullParser);
                                                                                                }
                                                                                            }
                                                                                        }
                                                                                        j14 = j16;
                                                                                        j44 = j18;
                                                                                        i10 = i9;
                                                                                    }
                                                                                }
                                                                            }
                                                                            str27 = str13;
                                                                        }
                                                                        if (AbstractC0133a.s(xmlPullParser, str27)) {
                                                                        }
                                                                    } else {
                                                                        arrayList41.add(h(xmlPullParser, "SupplementalProperty"));
                                                                        str5 = str63;
                                                                        str12 = str81;
                                                                        i9 = i29;
                                                                        str2 = str52;
                                                                        z7 = z6;
                                                                        arrayList7 = arrayList31;
                                                                        arrayList6 = arrayList32;
                                                                        str22 = str68;
                                                                        str13 = str69;
                                                                        str24 = attributeValue15;
                                                                        str14 = str70;
                                                                        str21 = str71;
                                                                        str23 = str72;
                                                                        str15 = str73;
                                                                        arrayList16 = arrayList37;
                                                                        f6 = f11;
                                                                        str16 = str77;
                                                                        arrayList14 = arrayList42;
                                                                        str17 = str79;
                                                                        str18 = str78;
                                                                        str19 = str80;
                                                                        i8 = 0;
                                                                        arrayList10 = arrayList43;
                                                                        arrayList15 = arrayList41;
                                                                        j17 = i27;
                                                                        j8 = j42;
                                                                        str25 = str86;
                                                                        arrayList13 = arrayList40;
                                                                    }
                                                                }
                                                                str5 = str63;
                                                                str12 = str81;
                                                                i9 = i29;
                                                                str2 = str52;
                                                                z7 = z6;
                                                                arrayList9 = arrayList36;
                                                                arrayList7 = arrayList31;
                                                                arrayList6 = arrayList32;
                                                                str22 = str68;
                                                                str13 = str69;
                                                                str24 = attributeValue15;
                                                                str14 = str70;
                                                                str21 = str71;
                                                                str23 = str72;
                                                                str15 = str73;
                                                                arrayList16 = arrayList37;
                                                                f6 = f11;
                                                                str16 = str77;
                                                                arrayList14 = arrayList42;
                                                                str17 = str79;
                                                                str18 = str78;
                                                                str19 = str80;
                                                                i8 = 0;
                                                                arrayList10 = arrayList43;
                                                                arrayList15 = arrayList41;
                                                                j17 = i27;
                                                                j8 = j42;
                                                                str25 = str86;
                                                                arrayList13 = arrayList40;
                                                            }
                                                        }
                                                        arrayList12 = arrayList8;
                                                        j9 = j36;
                                                        j11 = j38;
                                                        arrayList2 = arrayList34;
                                                        j18 = j44;
                                                        str20 = attributeValue14;
                                                        arrayList11 = arrayList39;
                                                        j15 = j37;
                                                        j16 = j14;
                                                        j14 = j16;
                                                        j44 = j18;
                                                        i10 = i9;
                                                        str27 = str13;
                                                        if (AbstractC0133a.s(xmlPullParser, str27)) {
                                                        }
                                                    }
                                                }
                                                str5 = str63;
                                                str12 = str81;
                                                str2 = str52;
                                                z7 = z6;
                                                arrayList9 = arrayList36;
                                                arrayList7 = arrayList31;
                                                arrayList6 = arrayList32;
                                                str22 = str68;
                                                str24 = attributeValue15;
                                                str14 = str70;
                                                str21 = str71;
                                                str23 = str72;
                                                str15 = str73;
                                                arrayList16 = arrayList37;
                                                f6 = f11;
                                                str16 = str77;
                                                arrayList14 = arrayList42;
                                                str17 = str79;
                                                str18 = str78;
                                                str19 = str80;
                                                i8 = 0;
                                                arrayList10 = arrayList43;
                                                arrayList15 = arrayList41;
                                                j17 = i27;
                                                j8 = j42;
                                                arrayList13 = arrayList40;
                                                str25 = str53;
                                                str27 = str69;
                                                i10 = i29;
                                                arrayList12 = arrayList8;
                                                j9 = j36;
                                                j11 = j38;
                                                arrayList2 = arrayList34;
                                                str20 = attributeValue14;
                                                arrayList11 = arrayList39;
                                                j15 = j37;
                                                if (AbstractC0133a.s(xmlPullParser, str27)) {
                                                }
                                            }
                                        } else {
                                            arrayList4 = arrayList30;
                                            str = str53;
                                            String str133 = str63;
                                            str2 = str52;
                                            String str134 = str64;
                                            arrayList5 = arrayList33;
                                            z7 = z6;
                                            long j62 = j37;
                                            long j63 = j38;
                                            ArrayList arrayList66 = arrayList31;
                                            arrayList6 = arrayList32;
                                            i8 = 0;
                                            long j64 = i27;
                                            j9 = j36;
                                            arrayList2 = arrayList29;
                                            j8 = j26;
                                            if (AbstractC0133a.u(xmlPullParser, "EventStream")) {
                                                String str135 = str67;
                                                String attributeValue31 = xmlPullParser.getAttributeValue(null, str135);
                                                String str136 = attributeValue31 == null ? StringUtils.EMPTY : attributeValue31;
                                                String str137 = str65;
                                                String attributeValue32 = xmlPullParser.getAttributeValue(null, str137);
                                                String str138 = attributeValue32 == null ? StringUtils.EMPTY : attributeValue32;
                                                String attributeValue33 = xmlPullParser.getAttributeValue(null, "timescale");
                                                long parseLong2 = attributeValue33 == null ? 1L : Long.parseLong(attributeValue33);
                                                String attributeValue34 = xmlPullParser.getAttributeValue(null, "presentationTimeOffset");
                                                long parseLong3 = attributeValue34 == null ? 0L : Long.parseLong(attributeValue34);
                                                ArrayList arrayList67 = new ArrayList();
                                                ByteArrayOutputStream byteArrayOutputStream3 = new ByteArrayOutputStream(512);
                                                while (true) {
                                                    xmlPullParser.next();
                                                    String str139 = "Event";
                                                    if (AbstractC0133a.u(xmlPullParser, "Event")) {
                                                        str9 = str133;
                                                        String attributeValue35 = xmlPullParser.getAttributeValue(null, str9);
                                                        long parseLong4 = attributeValue35 == null ? 0L : Long.parseLong(attributeValue35);
                                                        str8 = str134;
                                                        String attributeValue36 = xmlPullParser.getAttributeValue(null, str8);
                                                        long parseLong5 = attributeValue36 == null ? -9223372036854775807L : Long.parseLong(attributeValue36);
                                                        String attributeValue37 = xmlPullParser.getAttributeValue(null, "presentationTime");
                                                        long parseLong6 = attributeValue37 == null ? 0L : Long.parseLong(attributeValue37);
                                                        String str140 = C.f3053a;
                                                        RoundingMode roundingMode = RoundingMode.DOWN;
                                                        long V6 = C.V(parseLong5, 1000L, parseLong2, roundingMode);
                                                        long V7 = C.V(parseLong6 - parseLong3, 1000000L, parseLong2, roundingMode);
                                                        str3 = str135;
                                                        j12 = parseLong2;
                                                        str65 = str137;
                                                        String attributeValue38 = xmlPullParser.getAttributeValue(null, "messageData");
                                                        if (attributeValue38 == null) {
                                                            attributeValue38 = null;
                                                        }
                                                        byteArrayOutputStream3.reset();
                                                        XmlSerializer newSerializer = Xml.newSerializer();
                                                        j13 = parseLong3;
                                                        newSerializer.setOutput(byteArrayOutputStream3, StandardCharsets.UTF_8.name());
                                                        xmlPullParser.nextToken();
                                                        while (!AbstractC0133a.s(xmlPullParser, str139)) {
                                                            switch (xmlPullParser.getEventType()) {
                                                                case 0:
                                                                    byteArrayOutputStream2 = byteArrayOutputStream3;
                                                                    str11 = str139;
                                                                    newSerializer.startDocument(null, Boolean.FALSE);
                                                                    break;
                                                                case 1:
                                                                    byteArrayOutputStream2 = byteArrayOutputStream3;
                                                                    str11 = str139;
                                                                    newSerializer.endDocument();
                                                                    break;
                                                                case 2:
                                                                    newSerializer.startTag(xmlPullParser.getNamespace(), xmlPullParser.getName());
                                                                    int i62 = 0;
                                                                    while (i62 < xmlPullParser.getAttributeCount()) {
                                                                        newSerializer.attribute(xmlPullParser.getAttributeNamespace(i62), xmlPullParser.getAttributeName(i62), xmlPullParser.getAttributeValue(i62));
                                                                        i62++;
                                                                        byteArrayOutputStream3 = byteArrayOutputStream3;
                                                                        str139 = str139;
                                                                    }
                                                                    break;
                                                                case 3:
                                                                    newSerializer.endTag(xmlPullParser.getNamespace(), xmlPullParser.getName());
                                                                    break;
                                                                case 4:
                                                                    newSerializer.text(xmlPullParser.getText());
                                                                    break;
                                                                case 5:
                                                                    newSerializer.cdsect(xmlPullParser.getText());
                                                                    break;
                                                                case 6:
                                                                    newSerializer.entityRef(xmlPullParser.getText());
                                                                    break;
                                                                case 7:
                                                                    newSerializer.ignorableWhitespace(xmlPullParser.getText());
                                                                    break;
                                                                case 8:
                                                                    newSerializer.processingInstruction(xmlPullParser.getText());
                                                                    break;
                                                                case ContentHandlerProxy.PROCESSING_INSTRUCTION /* 9 */:
                                                                    newSerializer.comment(xmlPullParser.getText());
                                                                    break;
                                                                case 10:
                                                                    newSerializer.docdecl(xmlPullParser.getText());
                                                                    break;
                                                            }
                                                            byteArrayOutputStream2 = byteArrayOutputStream3;
                                                            str11 = str139;
                                                            xmlPullParser.nextToken();
                                                            byteArrayOutputStream3 = byteArrayOutputStream2;
                                                            str139 = str11;
                                                        }
                                                        byteArrayOutputStream = byteArrayOutputStream3;
                                                        newSerializer.flush();
                                                        byte[] byteArray = byteArrayOutputStream.toByteArray();
                                                        Long valueOf = Long.valueOf(V7);
                                                        if (attributeValue38 != null) {
                                                            byteArray = attributeValue38.getBytes(StandardCharsets.UTF_8);
                                                        }
                                                        str7 = str136;
                                                        str10 = str138;
                                                        arrayList67.add(Pair.create(valueOf, new I0.a(str136, str138, V6, parseLong4, byteArray)));
                                                    } else {
                                                        str3 = str135;
                                                        str65 = str137;
                                                        byteArrayOutputStream = byteArrayOutputStream3;
                                                        str7 = str136;
                                                        j12 = parseLong2;
                                                        str8 = str134;
                                                        str9 = str133;
                                                        j13 = parseLong3;
                                                        str10 = str138;
                                                        b(xmlPullParser);
                                                    }
                                                    if (AbstractC0133a.s(xmlPullParser, "EventStream")) {
                                                        long[] jArr = new long[arrayList67.size()];
                                                        I0.a[] aVarArr = new I0.a[arrayList67.size()];
                                                        for (int i63 = 0; i63 < arrayList67.size(); i63++) {
                                                            Pair pair2 = (Pair) arrayList67.get(i63);
                                                            jArr[i63] = ((Long) pair2.first).longValue();
                                                            aVarArr[i63] = (I0.a) pair2.second;
                                                        }
                                                        arrayList6.add(new g(str7, str10, jArr, aVarArr));
                                                        str5 = str9;
                                                        arrayList7 = arrayList66;
                                                        str4 = str8;
                                                        j10 = j64;
                                                        j7 = j62;
                                                        j11 = j63;
                                                    } else {
                                                        str136 = str7;
                                                        str138 = str10;
                                                        str133 = str9;
                                                        str134 = str8;
                                                        str135 = str3;
                                                        str137 = str65;
                                                        byteArrayOutputStream3 = byteArrayOutputStream;
                                                        parseLong3 = j13;
                                                        parseLong2 = j12;
                                                    }
                                                }
                                            } else {
                                                str3 = str67;
                                                str4 = str134;
                                                if (AbstractC0133a.u(xmlPullParser, "SegmentBase")) {
                                                    sVar = o(xmlPullParser, null);
                                                    arrayList6 = arrayList6;
                                                    str5 = str133;
                                                    arrayList7 = arrayList66;
                                                    j10 = j64;
                                                    str6 = str66;
                                                    j40 = j41;
                                                    j7 = j62;
                                                    j11 = j63;
                                                    j6 = -9223372036854775807L;
                                                } else if (AbstractC0133a.u(xmlPullParser, "SegmentList")) {
                                                    str5 = str133;
                                                    long d11 = d(xmlPullParser, -9223372036854775807L);
                                                    arrayList6 = arrayList6;
                                                    j6 = -9223372036854775807L;
                                                    sVar = q(xmlPullParser, null, j63, j64, j41, d11, j62);
                                                    j10 = j64;
                                                    j11 = j63;
                                                    j39 = d11;
                                                    arrayList7 = arrayList66;
                                                    str6 = str66;
                                                    j40 = j41;
                                                    j7 = j62;
                                                } else {
                                                    arrayList6 = arrayList6;
                                                    str5 = str133;
                                                    j10 = j64;
                                                    j11 = j63;
                                                    if (AbstractC0133a.u(xmlPullParser, "SegmentTemplate")) {
                                                        long d12 = d(xmlPullParser, -9223372036854775807L);
                                                        G g6 = I.f699p;
                                                        j6 = -9223372036854775807L;
                                                        arrayList7 = arrayList66;
                                                        j7 = j62;
                                                        sVar = r(xmlPullParser, null, Z.f721s, j11, j10, j41, d12, j7);
                                                        j11 = j11;
                                                        j39 = d12;
                                                    } else {
                                                        j6 = -9223372036854775807L;
                                                        arrayList7 = arrayList66;
                                                        j7 = j62;
                                                        if (AbstractC0133a.u(xmlPullParser, "AssetIdentifier")) {
                                                            h(xmlPullParser, "AssetIdentifier");
                                                        } else {
                                                            b(xmlPullParser);
                                                        }
                                                    }
                                                    str6 = str66;
                                                    j40 = j41;
                                                }
                                            }
                                        }
                                        j6 = -9223372036854775807L;
                                        str6 = str66;
                                        j40 = j41;
                                    }
                                    if (AbstractC0133a.s(xmlPullParser, str6)) {
                                        Pair create = Pair.create(new h(attributeValue11, i26, arrayList7, arrayList6), Long.valueOf(j10));
                                        h hVar = (h) create.first;
                                        if (hVar.f5925b != j6) {
                                            long longValue = ((Long) create.second).longValue();
                                            long j65 = longValue == j6 ? j6 : longValue + hVar.f5925b;
                                            arrayList3 = arrayList28;
                                            arrayList3.add(hVar);
                                            j26 = j65;
                                        } else {
                                            if (!equals) {
                                                throw S.G.b("Unable to determine start of period " + arrayList28.size(), null);
                                            }
                                            arrayList3 = arrayList28;
                                            i25 = i7;
                                        }
                                    } else {
                                        str66 = str6;
                                        j26 = j8;
                                        arrayList29 = arrayList2;
                                        j36 = j9;
                                        str62 = str3;
                                        arrayList30 = arrayList4;
                                        i27 = j10;
                                        str64 = str4;
                                        str53 = str;
                                        str52 = str2;
                                        arrayList31 = arrayList7;
                                        arrayList32 = arrayList6;
                                        str63 = str5;
                                        j38 = j11;
                                        j37 = j7;
                                        z6 = z7;
                                        arrayList33 = arrayList5;
                                    }
                                }
                            } else {
                                z7 = z6;
                                j6 = j27;
                                j7 = j37;
                                i8 = 0;
                                j8 = j26;
                                j9 = j36;
                                arrayList2 = arrayList29;
                                arrayList3 = arrayList28;
                                b(xmlPullParser);
                            }
                            j26 = j8;
                            j25 = j9;
                        }
                        if (!AbstractC0133a.s(xmlPullParser, "MPD")) {
                            if (i19 == j6) {
                                if (j26 != j6) {
                                    i19 = j26;
                                } else if (!equals) {
                                    throw S.G.b("Unable to determine duration of static manifest.", null);
                                }
                            }
                            if (!arrayList3.isEmpty()) {
                                return new C0392c(Q6, i19, i20, equals, i21, j7, i23, Q7, iVar, tVar, c0127u, uri2, arrayList3);
                            }
                            throw S.G.b("No periods found.", null);
                        }
                        arrayList28 = arrayList3;
                        i22 = j7;
                        i6 = i7;
                        i17 = i8;
                        arrayList29 = arrayList2;
                        n6 = arrayList;
                        z6 = z7;
                        j24 = j6;
                        str51 = null;
                    }
                }
                i8 = 0;
            }
            j7 = i22;
            if (!AbstractC0133a.s(xmlPullParser, "MPD")) {
            }
        }
    }

    public static j l(XmlPullParser xmlPullParser, String str, String str2) {
        long j6;
        String attributeValue = xmlPullParser.getAttributeValue(null, str);
        String attributeValue2 = xmlPullParser.getAttributeValue(null, str2);
        long j7 = -1;
        if (attributeValue2 != null) {
            String[] split = attributeValue2.split("-");
            j6 = Long.parseLong(split[0]);
            if (split.length == 2) {
                j7 = (Long.parseLong(split[1]) - j6) + 1;
            }
        } else {
            j6 = 0;
        }
        return new j(j6, j7, attributeValue);
    }

    public static int m(String str) {
        if (str != null) {
            char c6 = 65535;
            switch (str.hashCode()) {
                case -2060497896:
                    if (str.equals("subtitle")) {
                        c6 = 0;
                        break;
                    }
                    break;
                case -1724546052:
                    if (str.equals("description")) {
                        c6 = 1;
                        break;
                    }
                    break;
                case -1580883024:
                    if (str.equals("enhanced-audio-intelligibility")) {
                        c6 = 2;
                        break;
                    }
                    break;
                case -1574842690:
                    if (str.equals("forced_subtitle")) {
                        c6 = 3;
                        break;
                    }
                    break;
                case -1408024454:
                    if (str.equals("alternate")) {
                        c6 = 4;
                        break;
                    }
                    break;
                case -1396432756:
                    if (str.equals("forced-subtitle")) {
                        c6 = 5;
                        break;
                    }
                    break;
                case 99825:
                    if (str.equals("dub")) {
                        c6 = 6;
                        break;
                    }
                    break;
                case 3343801:
                    if (str.equals("main")) {
                        c6 = 7;
                        break;
                    }
                    break;
                case 3530173:
                    if (str.equals("sign")) {
                        c6 = '\b';
                        break;
                    }
                    break;
                case 552573414:
                    if (str.equals("caption")) {
                        c6 = '\t';
                        break;
                    }
                    break;
                case 899152809:
                    if (str.equals("commentary")) {
                        c6 = '\n';
                        break;
                    }
                    break;
                case 1629013393:
                    if (str.equals("emergency")) {
                        c6 = 11;
                        break;
                    }
                    break;
                case 1855372047:
                    if (str.equals("supplementary")) {
                        c6 = '\f';
                        break;
                    }
                    break;
            }
            switch (c6) {
                case 0:
                case 3:
                case 5:
                    return 128;
                case 1:
                    return 512;
                case 2:
                    return 2048;
                case 4:
                    return 2;
                case 6:
                    return 16;
                case 7:
                    return 1;
                case '\b':
                    return 256;
                case ContentHandlerProxy.PROCESSING_INSTRUCTION /* 9 */:
                    return 64;
                case '\n':
                    return 8;
                case 11:
                    return 32;
                case '\f':
                    return 4;
            }
        }
        return 0;
    }

    public static int n(ArrayList arrayList) {
        int i6 = 0;
        for (int i7 = 0; i7 < arrayList.size(); i7++) {
            if (Q5.a.o("http://dashif.org/guidelines/trickmode", ((C0395f) arrayList.get(i7)).f5917a)) {
                i6 = 16384;
            }
        }
        return i6;
    }

    public static r o(XmlPullParser xmlPullParser, r rVar) {
        long j6;
        long j7;
        long j8;
        if (rVar != null) {
            j6 = rVar.f5956b;
        } else {
            j6 = 1;
        }
        j jVar = null;
        String attributeValue = xmlPullParser.getAttributeValue(null, "timescale");
        if (attributeValue != null) {
            j6 = Long.parseLong(attributeValue);
        }
        long j9 = j6;
        long j10 = 0;
        if (rVar != null) {
            j7 = rVar.f5957c;
        } else {
            j7 = 0;
        }
        String attributeValue2 = xmlPullParser.getAttributeValue(null, "presentationTimeOffset");
        if (attributeValue2 != null) {
            j7 = Long.parseLong(attributeValue2);
        }
        long j11 = j7;
        if (rVar != null) {
            j8 = rVar.f5954d;
        } else {
            j8 = 0;
        }
        if (rVar != null) {
            j10 = rVar.e;
        }
        String attributeValue3 = xmlPullParser.getAttributeValue(null, "indexRange");
        if (attributeValue3 != null) {
            String[] split = attributeValue3.split("-");
            j8 = Long.parseLong(split[0]);
            j10 = (Long.parseLong(split[1]) - j8) + 1;
        }
        long j12 = j10;
        long j13 = j8;
        if (rVar != null) {
            jVar = rVar.f5955a;
        }
        while (true) {
            xmlPullParser.next();
            if (AbstractC0133a.u(xmlPullParser, "Initialization")) {
                jVar = l(xmlPullParser, "sourceURL", "range");
            } else {
                b(xmlPullParser);
            }
            j jVar2 = jVar;
            if (AbstractC0133a.s(xmlPullParser, "SegmentBase")) {
                return new r(jVar2, j9, j11, j13, j12);
            }
            jVar = jVar2;
        }
    }

    public static o q(XmlPullParser xmlPullParser, o oVar, long j6, long j7, long j8, long j9, long j10) {
        long j11;
        long j12;
        long j13;
        long j14;
        long j15;
        long j16 = 1;
        if (oVar != null) {
            j11 = oVar.f5956b;
        } else {
            j11 = 1;
        }
        List list = null;
        String attributeValue = xmlPullParser.getAttributeValue(null, "timescale");
        if (attributeValue != null) {
            j11 = Long.parseLong(attributeValue);
        }
        long j17 = j11;
        if (oVar != null) {
            j12 = oVar.f5957c;
        } else {
            j12 = 0;
        }
        String attributeValue2 = xmlPullParser.getAttributeValue(null, "presentationTimeOffset");
        if (attributeValue2 != null) {
            j12 = Long.parseLong(attributeValue2);
        }
        long j18 = j12;
        if (oVar != null) {
            j13 = oVar.e;
        } else {
            j13 = -9223372036854775807L;
        }
        String attributeValue3 = xmlPullParser.getAttributeValue(null, "duration");
        if (attributeValue3 != null) {
            j13 = Long.parseLong(attributeValue3);
        }
        long j19 = j13;
        if (oVar != null) {
            j16 = oVar.f5943d;
        }
        String attributeValue4 = xmlPullParser.getAttributeValue(null, "startNumber");
        if (attributeValue4 != null) {
            j16 = Long.parseLong(attributeValue4);
        }
        long j20 = j16;
        if (j9 == -9223372036854775807L) {
            j14 = j8;
        } else {
            j14 = j9;
        }
        if (j14 == Long.MAX_VALUE) {
            j15 = -9223372036854775807L;
        } else {
            j15 = j14;
        }
        j jVar = null;
        List list2 = null;
        do {
            xmlPullParser.next();
            if (AbstractC0133a.u(xmlPullParser, "Initialization")) {
                jVar = l(xmlPullParser, "sourceURL", "range");
            } else if (AbstractC0133a.u(xmlPullParser, "SegmentTimeline")) {
                list2 = s(xmlPullParser, j17, j7);
            } else if (AbstractC0133a.u(xmlPullParser, "SegmentURL")) {
                if (list == null) {
                    list = new ArrayList();
                }
                list.add(l(xmlPullParser, "media", "mediaRange"));
            } else {
                b(xmlPullParser);
            }
        } while (!AbstractC0133a.s(xmlPullParser, "SegmentList"));
        if (oVar != null) {
            if (jVar == null) {
                jVar = oVar.f5955a;
            }
            if (list2 == null) {
                list2 = oVar.f5944f;
            }
            if (list == null) {
                list = oVar.f5948j;
            }
        }
        return new o(jVar, j17, j18, j20, j19, list2, j15, list, C.N(j10), C.N(j6));
    }

    public static p r(XmlPullParser xmlPullParser, p pVar, List list, long j6, long j7, long j8, long j9, long j10) {
        long j11;
        long j12;
        long j13;
        long j14;
        long j15;
        long j16;
        X4.g gVar;
        X4.g gVar2;
        long j17 = 1;
        if (pVar != null) {
            j11 = pVar.f5956b;
        } else {
            j11 = 1;
        }
        j jVar = null;
        String attributeValue = xmlPullParser.getAttributeValue(null, "timescale");
        if (attributeValue != null) {
            j11 = Long.parseLong(attributeValue);
        }
        long j18 = j11;
        if (pVar != null) {
            j12 = pVar.f5957c;
        } else {
            j12 = 0;
        }
        String attributeValue2 = xmlPullParser.getAttributeValue(null, "presentationTimeOffset");
        if (attributeValue2 != null) {
            j12 = Long.parseLong(attributeValue2);
        }
        long j19 = j12;
        if (pVar != null) {
            j13 = pVar.e;
        } else {
            j13 = -9223372036854775807L;
        }
        String attributeValue3 = xmlPullParser.getAttributeValue(null, "duration");
        if (attributeValue3 != null) {
            j13 = Long.parseLong(attributeValue3);
        }
        long j20 = j13;
        if (pVar != null) {
            j17 = pVar.f5943d;
        }
        String attributeValue4 = xmlPullParser.getAttributeValue(null, "startNumber");
        if (attributeValue4 != null) {
            j17 = Long.parseLong(attributeValue4);
        }
        long j21 = j17;
        int i6 = 0;
        while (true) {
            if (i6 < list.size()) {
                C0395f c0395f = (C0395f) list.get(i6);
                if (Q5.a.o("http://dashif.org/guidelines/last-segment-number", c0395f.f5917a)) {
                    j14 = Long.parseLong(c0395f.f5918b);
                    break;
                }
                i6++;
            } else {
                j14 = -1;
                break;
            }
        }
        long j22 = j14;
        if (j9 == -9223372036854775807L) {
            j15 = j8;
        } else {
            j15 = j9;
        }
        if (j15 == Long.MAX_VALUE) {
            j16 = -9223372036854775807L;
        } else {
            j16 = j15;
        }
        if (pVar != null) {
            gVar = pVar.f5950k;
        } else {
            gVar = null;
        }
        X4.g t6 = t(xmlPullParser, "media", gVar);
        if (pVar != null) {
            gVar2 = pVar.f5949j;
        } else {
            gVar2 = null;
        }
        X4.g t7 = t(xmlPullParser, "initialization", gVar2);
        List list2 = null;
        do {
            xmlPullParser.next();
            if (AbstractC0133a.u(xmlPullParser, "Initialization")) {
                jVar = l(xmlPullParser, "sourceURL", "range");
            } else if (AbstractC0133a.u(xmlPullParser, "SegmentTimeline")) {
                list2 = s(xmlPullParser, j18, j7);
            } else {
                b(xmlPullParser);
            }
        } while (!AbstractC0133a.s(xmlPullParser, "SegmentTemplate"));
        if (pVar != null) {
            if (jVar == null) {
                jVar = pVar.f5955a;
            }
            if (list2 == null) {
                list2 = pVar.f5944f;
            }
        }
        return new p(jVar, j18, j19, j21, j22, j20, list2, j16, t7, t6, C.N(j10), C.N(j6));
    }

    public static ArrayList s(XmlPullParser xmlPullParser, long j6, long j7) {
        long parseLong;
        long j8;
        ArrayList arrayList = new ArrayList();
        long j9 = 0;
        long j10 = -9223372036854775807L;
        boolean z6 = false;
        int i6 = 0;
        do {
            xmlPullParser.next();
            if (AbstractC0133a.u(xmlPullParser, "S")) {
                String attributeValue = xmlPullParser.getAttributeValue(null, "t");
                if (attributeValue == null) {
                    parseLong = -9223372036854775807L;
                } else {
                    parseLong = Long.parseLong(attributeValue);
                }
                if (z6) {
                    int i7 = i6;
                    j8 = parseLong;
                    j9 = a(arrayList, j9, j10, i7, j8);
                } else {
                    j8 = parseLong;
                }
                if (j8 != -9223372036854775807L) {
                    j9 = j8;
                }
                String attributeValue2 = xmlPullParser.getAttributeValue(null, "d");
                if (attributeValue2 == null) {
                    j10 = -9223372036854775807L;
                } else {
                    j10 = Long.parseLong(attributeValue2);
                }
                String attributeValue3 = xmlPullParser.getAttributeValue(null, "r");
                if (attributeValue3 == null) {
                    i6 = 0;
                } else {
                    i6 = Integer.parseInt(attributeValue3);
                }
                z6 = true;
            } else {
                b(xmlPullParser);
            }
        } while (!AbstractC0133a.s(xmlPullParser, "SegmentTimeline"));
        if (z6) {
            String str = C.f3053a;
            a(arrayList, j9, j10, i6, C.V(j7, j6, 1000L, RoundingMode.DOWN));
        }
        return arrayList;
    }

    /* JADX WARN: Failed to find 'out' block for switch in B:31:0x00ff. Please report as an issue. */
    public static X4.g t(XmlPullParser xmlPullParser, String str, X4.g gVar) {
        String str2;
        String attributeValue = xmlPullParser.getAttributeValue(null, str);
        if (attributeValue != null) {
            ArrayList arrayList = new ArrayList();
            ArrayList arrayList2 = new ArrayList();
            ArrayList arrayList3 = new ArrayList();
            arrayList.add(StringUtils.EMPTY);
            int i6 = 0;
            while (i6 < attributeValue.length()) {
                int indexOf = attributeValue.indexOf("$", i6);
                char c6 = 65535;
                if (indexOf == -1) {
                    arrayList.set(arrayList2.size(), ((String) arrayList.get(arrayList2.size())) + attributeValue.substring(i6));
                    i6 = attributeValue.length();
                } else if (indexOf != i6) {
                    arrayList.set(arrayList2.size(), ((String) arrayList.get(arrayList2.size())) + attributeValue.substring(i6, indexOf));
                    i6 = indexOf;
                } else if (attributeValue.startsWith("$$", i6)) {
                    arrayList.set(arrayList2.size(), ((String) arrayList.get(arrayList2.size())) + "$");
                    i6 += 2;
                } else {
                    arrayList3.add(StringUtils.EMPTY);
                    int i7 = i6 + 1;
                    int indexOf2 = attributeValue.indexOf("$", i7);
                    String substring = attributeValue.substring(i7, indexOf2);
                    if (substring.equals("RepresentationID")) {
                        arrayList2.add(1);
                    } else {
                        int indexOf3 = substring.indexOf("%0");
                        if (indexOf3 != -1) {
                            str2 = substring.substring(indexOf3);
                            if (!str2.endsWith("d") && !str2.endsWith("x") && !str2.endsWith("X")) {
                                str2 = str2.concat("d");
                            }
                            substring = substring.substring(0, indexOf3);
                        } else {
                            str2 = "%01d";
                        }
                        substring.getClass();
                        switch (substring.hashCode()) {
                            case -1950496919:
                                if (substring.equals("Number")) {
                                    c6 = 0;
                                    break;
                                }
                                break;
                            case 2606829:
                                if (substring.equals("Time")) {
                                    c6 = 1;
                                    break;
                                }
                                break;
                            case 38199441:
                                if (substring.equals("Bandwidth")) {
                                    c6 = 2;
                                    break;
                                }
                                break;
                        }
                        switch (c6) {
                            case 0:
                                arrayList2.add(2);
                                break;
                            case 1:
                                arrayList2.add(4);
                                break;
                            case 2:
                                arrayList2.add(3);
                                break;
                            default:
                                throw new IllegalArgumentException("Invalid template: ".concat(attributeValue));
                        }
                        arrayList3.set(arrayList2.size() - 1, str2);
                    }
                    arrayList.add(StringUtils.EMPTY);
                    i6 = indexOf2 + 1;
                }
            }
            return new X4.g(arrayList, arrayList2, arrayList3, 7);
        }
        return gVar;
    }

    @Override // t0.q
    public final Object p(Uri uri, X.j jVar) {
        try {
            XmlPullParser newPullParser = this.o.newPullParser();
            newPullParser.setInput(jVar, null);
            if (newPullParser.next() == 2 && "MPD".equals(newPullParser.getName())) {
                return k(newPullParser, uri);
            }
            throw S.G.b("inputStream does not contain a valid media presentation description", null);
        } catch (XmlPullParserException e) {
            throw S.G.b(null, e);
        }
    }
}
