package d0;

import java.util.Objects;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* renamed from: d0.b, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0391b {

    /* renamed from: a, reason: collision with root package name */
    public final String f5891a;

    /* renamed from: b, reason: collision with root package name */
    public final String f5892b;

    /* renamed from: c, reason: collision with root package name */
    public final int f5893c;

    /* renamed from: d, reason: collision with root package name */
    public final int f5894d;

    public C0391b(int i6, int i7, String str, String str2) {
        this.f5891a = str;
        this.f5892b = str2;
        this.f5893c = i6;
        this.f5894d = i7;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof C0391b)) {
            return false;
        }
        C0391b c0391b = (C0391b) obj;
        if (this.f5893c == c0391b.f5893c && this.f5894d == c0391b.f5894d && Objects.equals(this.f5891a, c0391b.f5891a) && Objects.equals(this.f5892b, c0391b.f5892b)) {
            return true;
        }
        return false;
    }

    public final int hashCode() {
        return Objects.hash(this.f5891a, this.f5892b, Integer.valueOf(this.f5893c), Integer.valueOf(this.f5894d));
    }
}
