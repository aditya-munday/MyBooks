package d0;

import E2.I;
import S.C0123p;
import java.util.ArrayList;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* renamed from: d0.d, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0393d {

    /* renamed from: a, reason: collision with root package name */
    public final C0123p f5907a;

    /* renamed from: b, reason: collision with root package name */
    public final I f5908b;

    /* renamed from: c, reason: collision with root package name */
    public final s f5909c;

    /* renamed from: d, reason: collision with root package name */
    public final String f5910d;
    public final ArrayList e;

    /* renamed from: f, reason: collision with root package name */
    public final ArrayList f5911f;

    public C0393d(C0123p c0123p, ArrayList arrayList, s sVar, String str, ArrayList arrayList2, ArrayList arrayList3, ArrayList arrayList4, ArrayList arrayList5) {
        this.f5907a = c0123p;
        this.f5908b = I.u(arrayList);
        this.f5909c = sVar;
        this.f5910d = str;
        this.e = arrayList2;
        this.f5911f = arrayList3;
    }
}
