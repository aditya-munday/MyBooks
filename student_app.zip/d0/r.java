package d0;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* loaded from: classes.dex */
public final class r extends s {

    /* renamed from: d, reason: collision with root package name */
    public final long f5954d;
    public final long e;

    public r(j jVar, long j6, long j7, long j8, long j9) {
        super(jVar, j6, j7);
        this.f5954d = j8;
        this.e = j9;
    }
}
