package d0;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* loaded from: classes.dex */
public abstract class s {

    /* renamed from: a, reason: collision with root package name */
    public final j f5955a;

    /* renamed from: b, reason: collision with root package name */
    public final long f5956b;

    /* renamed from: c, reason: collision with root package name */
    public final long f5957c;

    public s(j jVar, long j6, long j7) {
        this.f5955a = jVar;
        this.f5956b = j6;
        this.f5957c = j7;
    }

    public j a(m mVar) {
        return this.f5955a;
    }
}
