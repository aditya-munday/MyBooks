package d0;

import S.C0123p;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.math.RoundingMode;
import java.util.List;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* loaded from: classes.dex */
public final class p extends n {

    /* renamed from: j, reason: collision with root package name */
    public final X4.g f5949j;

    /* renamed from: k, reason: collision with root package name */
    public final X4.g f5950k;

    /* renamed from: l, reason: collision with root package name */
    public final long f5951l;

    public p(j jVar, long j6, long j7, long j8, long j9, long j10, List list, long j11, X4.g gVar, X4.g gVar2, long j12, long j13) {
        super(jVar, j6, j7, j8, j10, list, j11, j12, j13);
        this.f5949j = gVar;
        this.f5950k = gVar2;
        this.f5951l = j9;
    }

    @Override // d0.s
    public final j a(m mVar) {
        X4.g gVar = this.f5949j;
        if (gVar != null) {
            C0123p c0123p = mVar.o;
            return new j(0L, -1L, gVar.y(c0123p.f2614a, 0L, c0123p.f2622j, 0L));
        }
        return this.f5955a;
    }

    @Override // d0.n
    public final long d(long j6) {
        if (this.f5944f != null) {
            return r0.size();
        }
        long j7 = this.f5951l;
        if (j7 != -1) {
            return (j7 - this.f5943d) + 1;
        }
        if (j6 == -9223372036854775807L) {
            return -1L;
        }
        BigInteger multiply = BigInteger.valueOf(j6).multiply(BigInteger.valueOf(this.f5956b));
        BigInteger multiply2 = BigInteger.valueOf(this.e).multiply(BigInteger.valueOf(1000000L));
        RoundingMode roundingMode = RoundingMode.CEILING;
        int i6 = G2.a.f960a;
        return new BigDecimal(multiply).divide(new BigDecimal(multiply2), 0, roundingMode).toBigIntegerExact().longValue();
    }

    @Override // d0.n
    public final j h(k kVar, long j6) {
        long j7;
        long j8 = this.f5943d;
        List list = this.f5944f;
        if (list != null) {
            j7 = ((q) list.get((int) (j6 - j8))).f5952a;
        } else {
            j7 = (j6 - j8) * this.e;
        }
        long j9 = j7;
        C0123p c0123p = kVar.o;
        return new j(0L, -1L, this.f5950k.y(c0123p.f2614a, j6, c0123p.f2622j, j9));
    }
}
