package d0;

import java.util.List;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* loaded from: classes.dex */
public final class o extends n {

    /* renamed from: j, reason: collision with root package name */
    public final List f5948j;

    public o(j jVar, long j6, long j7, long j8, long j9, List list, long j10, List list2, long j11, long j12) {
        super(jVar, j6, j7, j8, j9, list, j10, j11, j12);
        this.f5948j = list2;
    }

    @Override // d0.n
    public final long d(long j6) {
        return this.f5948j.size();
    }

    @Override // d0.n
    public final j h(k kVar, long j6) {
        return (j) this.f5948j.get((int) (j6 - this.f5943d));
    }

    @Override // d0.n
    public final boolean i() {
        return true;
    }
}
