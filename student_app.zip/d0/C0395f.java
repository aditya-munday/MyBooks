package d0;

import java.util.Objects;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* renamed from: d0.f, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0395f {

    /* renamed from: a, reason: collision with root package name */
    public final String f5917a;

    /* renamed from: b, reason: collision with root package name */
    public final String f5918b;

    /* renamed from: c, reason: collision with root package name */
    public final String f5919c;

    public C0395f(String str, String str2, String str3) {
        this.f5917a = str;
        this.f5918b = str2;
        this.f5919c = str3;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj != null && C0395f.class == obj.getClass()) {
            C0395f c0395f = (C0395f) obj;
            if (Objects.equals(this.f5917a, c0395f.f5917a) && Objects.equals(this.f5918b, c0395f.f5918b) && Objects.equals(this.f5919c, c0395f.f5919c)) {
                return true;
            }
        }
        return false;
    }

    public final int hashCode() {
        int i6;
        int hashCode = this.f5917a.hashCode() * 31;
        int i7 = 0;
        String str = this.f5918b;
        if (str != null) {
            i6 = str.hashCode();
        } else {
            i6 = 0;
        }
        int i8 = (hashCode + i6) * 31;
        String str2 = this.f5919c;
        if (str2 != null) {
            i7 = str2.hashCode();
        }
        return i8 + i7;
    }
}
