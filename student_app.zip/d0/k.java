package d0;

import E2.I;
import S.C0123p;
import java.util.ArrayList;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* loaded from: classes.dex */
public final class k extends m implements c0.j {

    /* renamed from: t, reason: collision with root package name */
    public final n f5936t;

    public k(C0123p c0123p, I i6, n nVar, ArrayList arrayList) {
        super(c0123p, i6, nVar, arrayList);
        this.f5936t = nVar;
    }

    @Override // d0.m
    public final String a() {
        return null;
    }

    @Override // c0.j
    public final long b(long j6) {
        return this.f5936t.g(j6);
    }

    @Override // c0.j
    public final long c(long j6, long j7) {
        return this.f5936t.f(j6, j7);
    }

    @Override // c0.j
    public final long e(long j6, long j7) {
        return this.f5936t.e(j6, j7);
    }

    @Override // d0.m
    public final j f() {
        return null;
    }

    @Override // c0.j
    public final long j(long j6, long j7) {
        return this.f5936t.c(j6, j7);
    }

    @Override // c0.j
    public final long m(long j6, long j7) {
        n nVar = this.f5936t;
        if (nVar.f5944f != null) {
            return -9223372036854775807L;
        }
        long b6 = nVar.b(j6, j7) + nVar.c(j6, j7);
        return (nVar.e(b6, j6) + nVar.g(b6)) - nVar.f5947i;
    }

    @Override // c0.j
    public final j n(long j6) {
        return this.f5936t.h(this, j6);
    }

    @Override // c0.j
    public final boolean r() {
        return this.f5936t.i();
    }

    @Override // c0.j
    public final long t() {
        return this.f5936t.f5943d;
    }

    @Override // c0.j
    public final long y(long j6) {
        return this.f5936t.d(j6);
    }

    @Override // c0.j
    public final long z(long j6, long j7) {
        return this.f5936t.b(j6, j7);
    }

    @Override // d0.m
    public final c0.j d() {
        return this;
    }
}
