package d0;

import C4.AbstractC0034i;
import V.AbstractC0133a;
import org.apache.tika.utils.StringUtils;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* loaded from: classes.dex */
public final class j {

    /* renamed from: a, reason: collision with root package name */
    public final long f5932a;

    /* renamed from: b, reason: collision with root package name */
    public final long f5933b;

    /* renamed from: c, reason: collision with root package name */
    public final String f5934c;

    /* renamed from: d, reason: collision with root package name */
    public int f5935d;

    public j(long j6, long j7, String str) {
        this.f5934c = str == null ? StringUtils.EMPTY : str;
        this.f5932a = j6;
        this.f5933b = j7;
    }

    public final j a(j jVar, String str) {
        j jVar2;
        long j6;
        String x6 = AbstractC0133a.x(str, this.f5934c);
        if (jVar != null) {
            long j7 = jVar.f5933b;
            if (x6.equals(AbstractC0133a.x(str, jVar.f5934c))) {
                long j8 = this.f5933b;
                long j9 = -1;
                if (j8 != -1) {
                    j6 = j7;
                    long j10 = this.f5932a;
                    jVar2 = null;
                    if (j10 + j8 == jVar.f5932a) {
                        if (j6 != -1) {
                            j9 = j8 + j6;
                        }
                        return new j(j10, j9, x6);
                    }
                } else {
                    jVar2 = null;
                    j6 = j7;
                }
                if (j6 != -1) {
                    long j11 = jVar.f5932a;
                    if (j11 + j6 == this.f5932a) {
                        if (j8 != -1) {
                            j9 = j6 + j8;
                        }
                        return new j(j11, j9, x6);
                    }
                    return jVar2;
                }
                return jVar2;
            }
        }
        return null;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj != null && j.class == obj.getClass()) {
            j jVar = (j) obj;
            if (this.f5932a == jVar.f5932a && this.f5933b == jVar.f5933b && this.f5934c.equals(jVar.f5934c)) {
                return true;
            }
        }
        return false;
    }

    public final int hashCode() {
        if (this.f5935d == 0) {
            this.f5935d = this.f5934c.hashCode() + ((((527 + ((int) this.f5932a)) * 31) + ((int) this.f5933b)) * 31);
        }
        return this.f5935d;
    }

    public final String toString() {
        StringBuilder sb = new StringBuilder("RangedUri(referenceUri=");
        sb.append(this.f5934c);
        sb.append(", start=");
        sb.append(this.f5932a);
        sb.append(", length=");
        return AbstractC0034i.m(sb, this.f5933b, ")");
    }
}
