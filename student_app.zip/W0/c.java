package W0;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* loaded from: classes.dex */
public final class c {

    /* renamed from: a, reason: collision with root package name */
    public final int f3439a;

    /* renamed from: b, reason: collision with root package name */
    public final boolean f3440b;

    /* renamed from: c, reason: collision with root package name */
    public final byte[] f3441c;

    /* renamed from: d, reason: collision with root package name */
    public final byte[] f3442d;

    public c(int i6, boolean z6, byte[] bArr, byte[] bArr2) {
        this.f3439a = i6;
        this.f3440b = z6;
        this.f3441c = bArr;
        this.f3442d = bArr2;
    }
}
