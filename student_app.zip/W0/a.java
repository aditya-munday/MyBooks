package W0;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* loaded from: classes.dex */
public final class a {

    /* renamed from: a, reason: collision with root package name */
    public final int f3430a;

    /* renamed from: b, reason: collision with root package name */
    public final int[] f3431b;

    /* renamed from: c, reason: collision with root package name */
    public final int[] f3432c;

    /* renamed from: d, reason: collision with root package name */
    public final int[] f3433d;

    public a(int i6, int[] iArr, int[] iArr2, int[] iArr3) {
        this.f3430a = i6;
        this.f3431b = iArr;
        this.f3432c = iArr2;
        this.f3433d = iArr3;
    }
}
