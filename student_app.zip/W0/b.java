package W0;

import V.AbstractC0133a;
import android.text.TextUtils;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* loaded from: classes.dex */
public final class b {

    /* renamed from: a, reason: collision with root package name */
    public final int f3434a;

    /* renamed from: b, reason: collision with root package name */
    public final int f3435b;

    /* renamed from: c, reason: collision with root package name */
    public final int f3436c;

    /* renamed from: d, reason: collision with root package name */
    public final int f3437d;
    public final int e;

    /* renamed from: f, reason: collision with root package name */
    public final int f3438f;

    public /* synthetic */ b(int i6, int i7, int i8, int i9, int i10, int i11) {
        this.f3434a = i6;
        this.f3435b = i7;
        this.f3436c = i8;
        this.f3437d = i9;
        this.e = i10;
        this.f3438f = i11;
    }

    public static b a(String str) {
        char c6;
        AbstractC0133a.c(str.startsWith("Format:"));
        String[] split = TextUtils.split(str.substring(7), ",");
        int i6 = -1;
        int i7 = -1;
        int i8 = -1;
        int i9 = -1;
        int i10 = -1;
        for (int i11 = 0; i11 < split.length; i11++) {
            String M6 = Q5.a.M(split[i11].trim());
            M6.getClass();
            switch (M6.hashCode()) {
                case 100571:
                    if (M6.equals("end")) {
                        c6 = 0;
                        break;
                    }
                    break;
                case 3556653:
                    if (M6.equals("text")) {
                        c6 = 1;
                        break;
                    }
                    break;
                case 102749521:
                    if (M6.equals("layer")) {
                        c6 = 2;
                        break;
                    }
                    break;
                case 109757538:
                    if (M6.equals("start")) {
                        c6 = 3;
                        break;
                    }
                    break;
                case 109780401:
                    if (M6.equals("style")) {
                        c6 = 4;
                        break;
                    }
                    break;
            }
            c6 = 65535;
            switch (c6) {
                case 0:
                    i8 = i11;
                    break;
                case 1:
                    i10 = i11;
                    break;
                case 2:
                    i6 = i11;
                    break;
                case 3:
                    i7 = i11;
                    break;
                case 4:
                    i9 = i11;
                    break;
            }
        }
        if (i7 != -1 && i8 != -1 && i10 != -1) {
            return new b(i6, i7, i8, i9, i10, split.length);
        }
        return null;
    }
}
