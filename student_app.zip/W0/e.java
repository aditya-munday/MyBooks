package W0;

import android.util.SparseArray;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* loaded from: classes.dex */
public final class e {

    /* renamed from: a, reason: collision with root package name */
    public final int f3445a;

    /* renamed from: b, reason: collision with root package name */
    public final boolean f3446b;

    /* renamed from: c, reason: collision with root package name */
    public final int f3447c;

    /* renamed from: d, reason: collision with root package name */
    public final int f3448d;
    public final int e;

    /* renamed from: f, reason: collision with root package name */
    public final int f3449f;

    /* renamed from: g, reason: collision with root package name */
    public final int f3450g;

    /* renamed from: h, reason: collision with root package name */
    public final int f3451h;

    /* renamed from: i, reason: collision with root package name */
    public final int f3452i;

    /* renamed from: j, reason: collision with root package name */
    public final SparseArray f3453j;

    public e(int i6, boolean z6, int i7, int i8, int i9, int i10, int i11, int i12, int i13, SparseArray sparseArray) {
        this.f3445a = i6;
        this.f3446b = z6;
        this.f3447c = i7;
        this.f3448d = i8;
        this.e = i9;
        this.f3449f = i10;
        this.f3450g = i11;
        this.f3451h = i12;
        this.f3452i = i13;
        this.f3453j = sparseArray;
    }
}
