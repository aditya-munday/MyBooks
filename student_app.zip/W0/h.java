package W0;

import E2.G;
import E2.I;
import E2.Z;
import U0.k;
import U0.l;
import V.AbstractC0133a;
import V.C;
import V.u;
import V.v;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffXfermode;
import android.util.SparseArray;
import java.util.ArrayList;
import java.util.List;
import org.apache.tika.pipes.PipesServer;
import org.apache.tika.utils.XMLReaderUtils;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* loaded from: classes.dex */
public final class h implements l {

    /* renamed from: v, reason: collision with root package name */
    public static final byte[] f3464v = {0, 7, 8, 15};

    /* renamed from: w, reason: collision with root package name */
    public static final byte[] f3465w = {0, 119, -120, -1};

    /* renamed from: x, reason: collision with root package name */
    public static final byte[] f3466x = {0, 17, 34, 51, 68, 85, 102, 119, -120, -103, -86, -69, -52, -35, -18, -1};
    public final Paint o;

    /* renamed from: p, reason: collision with root package name */
    public final Paint f3467p;

    /* renamed from: q, reason: collision with root package name */
    public final Canvas f3468q;

    /* renamed from: r, reason: collision with root package name */
    public final b f3469r;

    /* renamed from: s, reason: collision with root package name */
    public final a f3470s;

    /* renamed from: t, reason: collision with root package name */
    public final g f3471t;

    /* renamed from: u, reason: collision with root package name */
    public Bitmap f3472u;

    public h(List list) {
        v vVar = new v((byte[]) list.get(0));
        int D5 = vVar.D();
        int D6 = vVar.D();
        Paint paint = new Paint();
        this.o = paint;
        paint.setStyle(Paint.Style.FILL_AND_STROKE);
        paint.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.SRC));
        paint.setPathEffect(null);
        Paint paint2 = new Paint();
        this.f3467p = paint2;
        paint2.setStyle(Paint.Style.FILL);
        paint2.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.DST_OVER));
        paint2.setPathEffect(null);
        this.f3468q = new Canvas();
        this.f3469r = new b(719, 575, 0, 719, 0, 575);
        this.f3470s = new a(0, new int[]{0, -1, -16777216, -8421505}, b(), c());
        this.f3471t = new g(D5, D6);
    }

    public static byte[] a(int i6, int i7, u uVar) {
        byte[] bArr = new byte[i6];
        for (int i8 = 0; i8 < i6; i8++) {
            bArr[i8] = (byte) uVar.i(i7);
        }
        return bArr;
    }

    public static int[] b() {
        int i6;
        int i7;
        int i8;
        int i9;
        int i10;
        int[] iArr = new int[16];
        iArr[0] = 0;
        for (int i11 = 1; i11 < 16; i11++) {
            if (i11 < 8) {
                if ((i11 & 1) != 0) {
                    i8 = 255;
                } else {
                    i8 = 0;
                }
                if ((i11 & 2) != 0) {
                    i9 = 255;
                } else {
                    i9 = 0;
                }
                if ((i11 & 4) != 0) {
                    i10 = 255;
                } else {
                    i10 = 0;
                }
                iArr[i11] = d(255, i8, i9, i10);
            } else {
                int i12 = 127;
                if ((i11 & 1) != 0) {
                    i6 = 127;
                } else {
                    i6 = 0;
                }
                if ((i11 & 2) != 0) {
                    i7 = 127;
                } else {
                    i7 = 0;
                }
                if ((i11 & 4) == 0) {
                    i12 = 0;
                }
                iArr[i11] = d(255, i6, i7, i12);
            }
        }
        return iArr;
    }

    public static int[] c() {
        int i6;
        int i7;
        int i8;
        int i9;
        int i10;
        int i11;
        int i12;
        int i13;
        int i14;
        int i15;
        int i16;
        int i17;
        int i18;
        int i19;
        int i20;
        int i21;
        int i22;
        int i23;
        int[] iArr = new int[256];
        iArr[0] = 0;
        for (int i24 = 0; i24 < 256; i24++) {
            int i25 = 255;
            if (i24 < 8) {
                if ((i24 & 1) != 0) {
                    i22 = 255;
                } else {
                    i22 = 0;
                }
                if ((i24 & 2) != 0) {
                    i23 = 255;
                } else {
                    i23 = 0;
                }
                if ((i24 & 4) == 0) {
                    i25 = 0;
                }
                iArr[i24] = d(63, i22, i23, i25);
            } else {
                int i26 = i24 & 136;
                int i27 = 170;
                int i28 = 85;
                if (i26 != 0) {
                    if (i26 != 8) {
                        int i29 = 43;
                        if (i26 != 128) {
                            if (i26 == 136) {
                                if ((i24 & 1) != 0) {
                                    i18 = 43;
                                } else {
                                    i18 = 0;
                                }
                                if ((i24 & 16) != 0) {
                                    i19 = 85;
                                } else {
                                    i19 = 0;
                                }
                                int i30 = i18 + i19;
                                if ((i24 & 2) != 0) {
                                    i20 = 43;
                                } else {
                                    i20 = 0;
                                }
                                if ((i24 & 32) != 0) {
                                    i21 = 85;
                                } else {
                                    i21 = 0;
                                }
                                int i31 = i20 + i21;
                                if ((i24 & 4) == 0) {
                                    i29 = 0;
                                }
                                if ((i24 & 64) == 0) {
                                    i28 = 0;
                                }
                                iArr[i24] = d(255, i30, i31, i29 + i28);
                            }
                        } else {
                            if ((i24 & 1) != 0) {
                                i14 = 43;
                            } else {
                                i14 = 0;
                            }
                            int i32 = i14 + 127;
                            if ((i24 & 16) != 0) {
                                i15 = 85;
                            } else {
                                i15 = 0;
                            }
                            int i33 = i32 + i15;
                            if ((i24 & 2) != 0) {
                                i16 = 43;
                            } else {
                                i16 = 0;
                            }
                            int i34 = i16 + 127;
                            if ((i24 & 32) != 0) {
                                i17 = 85;
                            } else {
                                i17 = 0;
                            }
                            int i35 = i34 + i17;
                            if ((i24 & 4) == 0) {
                                i29 = 0;
                            }
                            int i36 = i29 + 127;
                            if ((i24 & 64) == 0) {
                                i28 = 0;
                            }
                            iArr[i24] = d(255, i33, i35, i36 + i28);
                        }
                    } else {
                        if ((i24 & 1) != 0) {
                            i10 = 85;
                        } else {
                            i10 = 0;
                        }
                        if ((i24 & 16) != 0) {
                            i11 = 170;
                        } else {
                            i11 = 0;
                        }
                        int i37 = i10 + i11;
                        if ((i24 & 2) != 0) {
                            i12 = 85;
                        } else {
                            i12 = 0;
                        }
                        if ((i24 & 32) != 0) {
                            i13 = 170;
                        } else {
                            i13 = 0;
                        }
                        int i38 = i12 + i13;
                        if ((i24 & 4) == 0) {
                            i28 = 0;
                        }
                        if ((i24 & 64) == 0) {
                            i27 = 0;
                        }
                        iArr[i24] = d(127, i37, i38, i28 + i27);
                    }
                } else {
                    if ((i24 & 1) != 0) {
                        i6 = 85;
                    } else {
                        i6 = 0;
                    }
                    if ((i24 & 16) != 0) {
                        i7 = 170;
                    } else {
                        i7 = 0;
                    }
                    int i39 = i6 + i7;
                    if ((i24 & 2) != 0) {
                        i8 = 85;
                    } else {
                        i8 = 0;
                    }
                    if ((i24 & 32) != 0) {
                        i9 = 170;
                    } else {
                        i9 = 0;
                    }
                    int i40 = i8 + i9;
                    if ((i24 & 4) == 0) {
                        i28 = 0;
                    }
                    if ((i24 & 64) == 0) {
                        i27 = 0;
                    }
                    iArr[i24] = d(255, i39, i40, i28 + i27);
                }
            }
        }
        return iArr;
    }

    public static int d(int i6, int i7, int i8, int i9) {
        return (i6 << 24) | (i7 << 16) | (i8 << 8) | i9;
    }

    /* JADX WARN: Removed duplicated region for block: B:92:0x01d5 A[ADDED_TO_REGION] */
    /* JADX WARN: Removed duplicated region for block: B:98:0x0203 A[LOOP:3: B:86:0x0156->B:98:0x0203, LOOP_END] */
    /* JADX WARN: Removed duplicated region for block: B:99:0x01ff A[SYNTHETIC] */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public static void e(byte[] bArr, int[] iArr, int i6, int i7, int i8, Paint paint, Canvas canvas) {
        byte[] bArr2;
        char c6;
        char c7;
        boolean z6;
        int i9;
        int i10;
        int i11;
        byte[] bArr3;
        boolean z7;
        int i12;
        int i13;
        int i14;
        int i15;
        int i16;
        int i17;
        byte[] bArr4;
        boolean z8;
        int i18;
        int i19;
        Paint paint2 = paint;
        u uVar = new u(bArr, bArr.length);
        int i20 = i7;
        int i21 = i8;
        byte[] bArr5 = null;
        byte[] bArr6 = null;
        byte[] bArr7 = null;
        while (uVar.b() != 0) {
            int i22 = 8;
            int i23 = uVar.i(8);
            if (i23 != 240) {
                int i24 = 3;
                int i25 = 2;
                int i26 = 4;
                switch (i23) {
                    case 16:
                        if (i6 == 3) {
                            if (bArr5 == null) {
                                bArr2 = f3465w;
                            } else {
                                bArr2 = bArr5;
                            }
                        } else if (i6 == 2) {
                            if (bArr7 == null) {
                                bArr2 = f3464v;
                            } else {
                                bArr2 = bArr7;
                            }
                        } else {
                            bArr2 = null;
                        }
                        boolean z9 = false;
                        while (true) {
                            int i27 = uVar.i(2);
                            if (i27 != 0) {
                                z6 = z9;
                                i9 = i27;
                                i10 = 1;
                            } else if (uVar.h()) {
                                int i28 = uVar.i(3) + 3;
                                z6 = z9;
                                i9 = uVar.i(2);
                                i10 = i28;
                            } else {
                                if (uVar.h()) {
                                    z6 = z9;
                                    i10 = 1;
                                    c6 = '\b';
                                    c7 = 4;
                                } else {
                                    int i29 = uVar.i(2);
                                    if (i29 != 0) {
                                        if (i29 != 1) {
                                            if (i29 != 2) {
                                                if (i29 != 3) {
                                                    z6 = z9;
                                                    c6 = '\b';
                                                    c7 = 4;
                                                } else {
                                                    c6 = '\b';
                                                    int i30 = uVar.i(8) + 29;
                                                    i9 = uVar.i(2);
                                                    z6 = z9;
                                                    i10 = i30;
                                                    c7 = 4;
                                                    if (i10 == 0 && paint2 != null) {
                                                        if (bArr2 != 0) {
                                                            i9 = bArr2[i9];
                                                        }
                                                        paint2.setColor(iArr[i9]);
                                                        i11 = i20;
                                                        canvas.drawRect(i20, i21, i20 + i10, i21 + 1, paint2);
                                                    } else {
                                                        i11 = i20;
                                                    }
                                                    i20 = i11 + i10;
                                                    if (z6) {
                                                        uVar.c();
                                                        break;
                                                    } else {
                                                        paint2 = paint;
                                                        z9 = z6;
                                                    }
                                                }
                                            } else {
                                                c6 = '\b';
                                                c7 = 4;
                                                i10 = uVar.i(4) + 12;
                                                i9 = uVar.i(2);
                                                z6 = z9;
                                                if (i10 == 0) {
                                                }
                                                i11 = i20;
                                                i20 = i11 + i10;
                                                if (z6) {
                                                }
                                            }
                                        } else {
                                            c6 = '\b';
                                            c7 = 4;
                                            z6 = z9;
                                            i10 = 2;
                                        }
                                    } else {
                                        c6 = '\b';
                                        c7 = 4;
                                        z6 = true;
                                    }
                                    i9 = 0;
                                    i10 = 0;
                                    if (i10 == 0) {
                                    }
                                    i11 = i20;
                                    i20 = i11 + i10;
                                    if (z6) {
                                    }
                                }
                                i9 = 0;
                                if (i10 == 0) {
                                }
                                i11 = i20;
                                i20 = i11 + i10;
                                if (z6) {
                                }
                            }
                            c6 = '\b';
                            c7 = 4;
                            if (i10 == 0) {
                            }
                            i11 = i20;
                            i20 = i11 + i10;
                            if (z6) {
                            }
                        }
                    case PipesServer.TIMEOUT_EXIT_CODE /* 17 */:
                        if (i6 == 3) {
                            if (bArr6 == null) {
                                bArr4 = f3466x;
                            } else {
                                bArr4 = bArr6;
                            }
                            bArr3 = bArr4;
                        } else {
                            bArr3 = null;
                        }
                        boolean z10 = false;
                        while (true) {
                            int i31 = uVar.i(i26);
                            if (i31 != 0) {
                                z7 = z10;
                                i14 = i31;
                                i12 = 1;
                            } else if (!uVar.h()) {
                                int i32 = uVar.i(i24);
                                if (i32 != 0) {
                                    i12 = i32 + 2;
                                    z7 = z10;
                                    i14 = 0;
                                } else {
                                    z7 = true;
                                    i12 = 0;
                                    i14 = 0;
                                }
                            } else {
                                if (!uVar.h()) {
                                    i12 = uVar.i(i25) + 4;
                                    i14 = uVar.i(i26);
                                } else {
                                    int i33 = uVar.i(i25);
                                    if (i33 != 0) {
                                        if (i33 != 1) {
                                            if (i33 != i25) {
                                                if (i33 != i24) {
                                                    z7 = z10;
                                                    i12 = 0;
                                                } else {
                                                    i12 = uVar.i(i22) + 25;
                                                    i13 = uVar.i(i26);
                                                }
                                            } else {
                                                i12 = uVar.i(i26) + 9;
                                                i13 = uVar.i(i26);
                                            }
                                            i14 = i13;
                                        } else {
                                            z7 = z10;
                                            i12 = i25;
                                        }
                                    } else {
                                        z7 = z10;
                                        i12 = 1;
                                    }
                                    i14 = 0;
                                }
                                z7 = z10;
                            }
                            if (i12 != 0 && paint2 != null) {
                                if (bArr3 != 0) {
                                    i14 = bArr3[i14];
                                }
                                paint2.setColor(iArr[i14]);
                                i16 = i24;
                                i17 = 2;
                                i15 = i20;
                                canvas.drawRect(i20, i21, i20 + i12, i21 + 1, paint2);
                            } else {
                                i15 = i20;
                                i16 = i24;
                                i17 = i25;
                            }
                            i20 = i15 + i12;
                            if (z7) {
                                uVar.c();
                                break;
                            } else {
                                z10 = z7;
                                i24 = i16;
                                i25 = i17;
                                i26 = 4;
                                i22 = 8;
                            }
                        }
                    case 18:
                        boolean z11 = false;
                        while (true) {
                            int i34 = uVar.i(8);
                            if (i34 != 0) {
                                z8 = z11;
                                i18 = 1;
                            } else if (!uVar.h()) {
                                int i35 = uVar.i(7);
                                if (i35 != 0) {
                                    z8 = z11;
                                    i18 = i35;
                                    i34 = 0;
                                } else {
                                    z8 = true;
                                    i34 = 0;
                                    i18 = 0;
                                }
                            } else {
                                z8 = z11;
                                i18 = uVar.i(7);
                                i34 = uVar.i(8);
                            }
                            if (i18 != 0 && paint2 != null) {
                                paint2.setColor(iArr[i34]);
                                i19 = i20;
                                canvas.drawRect(i20, i21, i20 + i18, i21 + 1, paint2);
                            } else {
                                i19 = i20;
                            }
                            i20 = i19 + i18;
                            if (z8) {
                                break;
                            } else {
                                z11 = z8;
                            }
                        }
                        break;
                    default:
                        switch (i23) {
                            case 32:
                                bArr7 = a(4, 4, uVar);
                                break;
                            case 33:
                                bArr5 = a(4, 8, uVar);
                                break;
                            case 34:
                                bArr6 = a(16, 8, uVar);
                                break;
                        }
                }
            } else {
                i21 += 2;
                i20 = i7;
            }
            paint2 = paint;
        }
    }

    public static a f(u uVar, int i6) {
        int[] iArr;
        int i7;
        int i8;
        int i9;
        int i10;
        int i11;
        int i12 = 8;
        int i13 = uVar.i(8);
        uVar.t(8);
        int i14 = 2;
        int i15 = i6 - 2;
        int i16 = 0;
        int[] iArr2 = {0, -1, -16777216, -8421505};
        int[] b6 = b();
        int[] c6 = c();
        while (i15 > 0) {
            int i17 = uVar.i(i12);
            int i18 = uVar.i(i12);
            if ((i18 & 128) != 0) {
                iArr = iArr2;
            } else if ((i18 & 64) != 0) {
                iArr = b6;
            } else {
                iArr = c6;
            }
            if ((i18 & 1) != 0) {
                i10 = uVar.i(i12);
                i11 = uVar.i(i12);
                i7 = uVar.i(i12);
                i9 = uVar.i(i12);
                i8 = i15 - 6;
            } else {
                int i19 = uVar.i(6) << i14;
                int i20 = uVar.i(4) << 4;
                i7 = uVar.i(4) << 4;
                i8 = i15 - 4;
                i9 = uVar.i(i14) << 6;
                i10 = i19;
                i11 = i20;
            }
            if (i10 == 0) {
                i11 = i16;
                i7 = i11;
                i9 = 255;
            }
            double d6 = i10;
            double d7 = i11 - 128;
            double d8 = i7 - 128;
            iArr[i17] = d((byte) (255 - (i9 & 255)), C.i((int) ((1.402d * d7) + d6), 0, 255), C.i((int) ((d6 - (0.34414d * d8)) - (d7 * 0.71414d)), 0, 255), C.i((int) ((d8 * 1.772d) + d6), 0, 255));
            i15 = i8;
            i16 = 0;
            i13 = i13;
            c6 = c6;
            i12 = 8;
            i14 = 2;
        }
        return new a(i13, iArr2, b6, c6);
    }

    public static c g(u uVar) {
        byte[] bArr;
        int i6 = uVar.i(16);
        uVar.t(4);
        int i7 = uVar.i(2);
        boolean h6 = uVar.h();
        uVar.t(1);
        byte[] bArr2 = C.f3054b;
        if (i7 == 1) {
            uVar.t(uVar.i(8) * 16);
        } else if (i7 == 0) {
            int i8 = uVar.i(16);
            int i9 = uVar.i(16);
            if (i8 > 0) {
                bArr2 = new byte[i8];
                uVar.l(bArr2, i8);
            }
            if (i9 > 0) {
                bArr = new byte[i9];
                uVar.l(bArr, i9);
                return new c(i6, h6, bArr2, bArr);
            }
        }
        bArr = bArr2;
        return new c(i6, h6, bArr2, bArr);
    }

    /* JADX WARN: Can't fix incorrect switch cases order, some code will duplicate */
    /* JADX WARN: Code restructure failed: missing block: B:67:0x01e4, code lost:
    
        r2.u(r12 - r2.f());
     */
    @Override // U0.l
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final void j(byte[] bArr, int i6, int i7, k kVar, V.g gVar) {
        g gVar2;
        boolean z6;
        U0.a aVar;
        char c6;
        char c7;
        char c8;
        int i8;
        ArrayList arrayList;
        int i9;
        b bVar;
        g gVar3;
        e eVar;
        int i10;
        int i11;
        int i12;
        int i13;
        int[] iArr;
        e eVar2;
        int i14;
        int i15;
        int i16;
        int i17;
        u uVar = new u(bArr, i6 + i7);
        uVar.q(i6);
        while (true) {
            int b6 = uVar.b();
            gVar2 = this.f3471t;
            z6 = true;
            if (b6 >= 48 && uVar.i(8) == 15) {
                int i18 = uVar.i(8);
                int i19 = uVar.i(16);
                int i20 = uVar.i(16);
                int f6 = uVar.f() + i20;
                if (i20 * 8 > uVar.b()) {
                    AbstractC0133a.A("DvbParser", "Data field length exceeds limit");
                    uVar.t(uVar.b());
                } else {
                    switch (i18) {
                        case 16:
                            if (i19 == gVar2.f3456a) {
                                R0.f fVar = gVar2.f3463i;
                                uVar.i(8);
                                int i21 = uVar.i(4);
                                int i22 = uVar.i(2);
                                uVar.t(2);
                                int i23 = i20 - 2;
                                SparseArray sparseArray = new SparseArray();
                                while (i23 > 0) {
                                    int i24 = uVar.i(8);
                                    uVar.t(8);
                                    i23 -= 6;
                                    sparseArray.put(i24, new d(uVar.i(16), uVar.i(16)));
                                }
                                R0.f fVar2 = new R0.f(i21, i22, sparseArray);
                                if (i22 != 0) {
                                    gVar2.f3463i = fVar2;
                                    gVar2.f3458c.clear();
                                    gVar2.f3459d.clear();
                                    gVar2.e.clear();
                                    break;
                                } else if (fVar != null && fVar.f2144a != i21) {
                                    gVar2.f3463i = fVar2;
                                    break;
                                }
                            }
                            break;
                        case PipesServer.TIMEOUT_EXIT_CODE /* 17 */:
                            R0.f fVar3 = gVar2.f3463i;
                            SparseArray sparseArray2 = gVar2.f3458c;
                            if (i19 == gVar2.f3456a && fVar3 != null) {
                                int i25 = uVar.i(8);
                                uVar.t(4);
                                boolean h6 = uVar.h();
                                uVar.t(3);
                                int i26 = uVar.i(16);
                                int i27 = uVar.i(16);
                                uVar.i(3);
                                int i28 = uVar.i(3);
                                uVar.t(2);
                                int i29 = uVar.i(8);
                                int i30 = uVar.i(8);
                                int i31 = uVar.i(4);
                                int i32 = uVar.i(2);
                                uVar.t(2);
                                int i33 = i20 - 10;
                                SparseArray sparseArray3 = new SparseArray();
                                while (i33 > 0) {
                                    int i34 = uVar.i(16);
                                    int i35 = uVar.i(2);
                                    uVar.i(2);
                                    int i36 = uVar.i(12);
                                    uVar.t(4);
                                    int i37 = uVar.i(12);
                                    int i38 = i33 - 6;
                                    if (i35 == 1 || i35 == 2) {
                                        uVar.i(8);
                                        uVar.i(8);
                                        i33 -= 8;
                                    } else {
                                        i33 = i38;
                                    }
                                    sparseArray3.put(i34, new f(i36, i37));
                                }
                                e eVar3 = new e(i25, h6, i26, i27, i28, i29, i30, i31, i32, sparseArray3);
                                if (fVar3.f2145b == 0 && (eVar2 = (e) sparseArray2.get(i25)) != null) {
                                    SparseArray sparseArray4 = eVar2.f3453j;
                                    for (int i39 = 0; i39 < sparseArray4.size(); i39++) {
                                        eVar3.f3453j.put(sparseArray4.keyAt(i39), (f) sparseArray4.valueAt(i39));
                                    }
                                }
                                sparseArray2.put(eVar3.f3445a, eVar3);
                                break;
                            }
                            break;
                        case 18:
                            if (i19 == gVar2.f3456a) {
                                a f7 = f(uVar, i20);
                                gVar2.f3459d.put(f7.f3430a, f7);
                                break;
                            } else if (i19 == gVar2.f3457b) {
                                a f8 = f(uVar, i20);
                                gVar2.f3460f.put(f8.f3430a, f8);
                                break;
                            }
                            break;
                        case 19:
                            if (i19 == gVar2.f3456a) {
                                c g2 = g(uVar);
                                gVar2.e.put(g2.f3439a, g2);
                                break;
                            } else if (i19 == gVar2.f3457b) {
                                c g3 = g(uVar);
                                gVar2.f3461g.put(g3.f3439a, g3);
                                break;
                            }
                            break;
                        case XMLReaderUtils.DEFAULT_MAX_ENTITY_EXPANSIONS /* 20 */:
                            if (i19 == gVar2.f3456a) {
                                uVar.t(4);
                                boolean h7 = uVar.h();
                                uVar.t(3);
                                int i40 = uVar.i(16);
                                int i41 = uVar.i(16);
                                if (h7) {
                                    int i42 = uVar.i(16);
                                    i14 = uVar.i(16);
                                    i17 = uVar.i(16);
                                    i15 = uVar.i(16);
                                    i16 = i42;
                                } else {
                                    i14 = i40;
                                    i15 = i41;
                                    i16 = 0;
                                    i17 = 0;
                                }
                                gVar2.f3462h = new b(i40, i41, i16, i14, i17, i15);
                                break;
                            }
                            break;
                    }
                }
            }
        }
        R0.f fVar4 = gVar2.f3463i;
        if (fVar4 == null) {
            G g6 = I.f699p;
            aVar = new U0.a(-9223372036854775807L, -9223372036854775807L, Z.f721s);
        } else {
            b bVar2 = gVar2.f3462h;
            if (bVar2 == null) {
                bVar2 = this.f3469r;
            }
            Bitmap bitmap = this.f3472u;
            Canvas canvas = this.f3468q;
            if (bitmap == null || bVar2.f3434a + 1 != bitmap.getWidth() || bVar2.f3435b + 1 != this.f3472u.getHeight()) {
                Bitmap createBitmap = Bitmap.createBitmap(bVar2.f3434a + 1, bVar2.f3435b + 1, Bitmap.Config.ARGB_8888);
                this.f3472u = createBitmap;
                canvas.setBitmap(createBitmap);
            }
            ArrayList arrayList2 = new ArrayList();
            SparseArray sparseArray5 = (SparseArray) fVar4.f2146c;
            int i43 = 0;
            while (i43 < sparseArray5.size()) {
                canvas.save();
                d dVar = (d) sparseArray5.valueAt(i43);
                e eVar4 = (e) gVar2.f3458c.get(sparseArray5.keyAt(i43));
                int i44 = dVar.f3443a + bVar2.f3436c;
                int i45 = dVar.f3444b + bVar2.e;
                int i46 = eVar4.f3447c;
                int i47 = eVar4.f3449f;
                int i48 = eVar4.f3448d;
                boolean z7 = z6;
                int i49 = i44 + i46;
                int i50 = i45 + i48;
                SparseArray sparseArray6 = sparseArray5;
                canvas.clipRect(i44, i45, Math.min(i49, bVar2.f3437d), Math.min(i50, bVar2.f3438f));
                a aVar2 = (a) gVar2.f3459d.get(i47);
                if (aVar2 == null && (aVar2 = (a) gVar2.f3460f.get(i47)) == null) {
                    aVar2 = this.f3470s;
                }
                SparseArray sparseArray7 = eVar4.f3453j;
                int i51 = i43;
                int i52 = 0;
                while (i52 < sparseArray7.size()) {
                    int keyAt = sparseArray7.keyAt(i52);
                    SparseArray sparseArray8 = sparseArray7;
                    f fVar5 = (f) sparseArray7.valueAt(i52);
                    int i53 = i45;
                    c cVar = (c) gVar2.e.get(keyAt);
                    if (cVar == null) {
                        cVar = (c) gVar2.f3461g.get(keyAt);
                    }
                    c cVar2 = cVar;
                    if (cVar2 != null) {
                        Paint paint = cVar2.f3440b ? null : this.o;
                        int i54 = i44;
                        int i55 = eVar4.e;
                        gVar3 = gVar2;
                        int i56 = i54 + fVar5.f3454a;
                        int i57 = i53 + fVar5.f3455b;
                        if (i55 == 3) {
                            iArr = aVar2.f3433d;
                        } else if (i55 == 2) {
                            iArr = aVar2.f3432c;
                        } else {
                            iArr = aVar2.f3431b;
                        }
                        int i58 = i48;
                        Paint paint2 = paint;
                        bVar = bVar2;
                        i11 = i46;
                        i10 = i54;
                        arrayList = arrayList2;
                        i9 = i53;
                        e eVar5 = eVar4;
                        int[] iArr2 = iArr;
                        eVar = eVar5;
                        i12 = i52;
                        i13 = i58;
                        e(cVar2.f3441c, iArr2, i55, i56, i57, paint2, canvas);
                        e(cVar2.f3442d, iArr2, i55, i56, i57 + 1, paint2, canvas);
                    } else {
                        arrayList = arrayList2;
                        i9 = i53;
                        bVar = bVar2;
                        gVar3 = gVar2;
                        eVar = eVar4;
                        i10 = i44;
                        i11 = i46;
                        i12 = i52;
                        i13 = i48;
                    }
                    i52 = i12 + 1;
                    i46 = i11;
                    i45 = i9;
                    eVar4 = eVar;
                    i44 = i10;
                    arrayList2 = arrayList;
                    sparseArray7 = sparseArray8;
                    bVar2 = bVar;
                    gVar2 = gVar3;
                    i48 = i13;
                }
                b bVar3 = bVar2;
                ArrayList arrayList3 = arrayList2;
                g gVar4 = gVar2;
                int i59 = i45;
                e eVar6 = eVar4;
                int i60 = i44;
                int i61 = i46;
                int i62 = i48;
                if (eVar6.f3446b) {
                    int i63 = eVar6.e;
                    if (i63 == 3) {
                        i8 = aVar2.f3433d[eVar6.f3450g];
                        c8 = 2;
                    } else {
                        c8 = 2;
                        if (i63 == 2) {
                            i8 = aVar2.f3432c[eVar6.f3451h];
                        } else {
                            i8 = aVar2.f3431b[eVar6.f3452i];
                        }
                    }
                    Paint paint3 = this.f3467p;
                    paint3.setColor(i8);
                    c6 = c8;
                    c7 = 3;
                    canvas.drawRect(i60, i59, i49, i50, paint3);
                } else {
                    c6 = 2;
                    c7 = 3;
                }
                Bitmap createBitmap2 = Bitmap.createBitmap(this.f3472u, i60, i59, i61, i62);
                float f9 = bVar3.f3434a;
                float f10 = bVar3.f3435b;
                arrayList3.add(new U.b(null, null, null, createBitmap2, i59 / f10, 0, 0, i60 / f9, 0, Integer.MIN_VALUE, -3.4028235E38f, i61 / f9, i62 / f10, false, -16777216, Integer.MIN_VALUE, 0.0f, 0));
                canvas.drawColor(0, PorterDuff.Mode.CLEAR);
                canvas.restore();
                i43 = i51 + 1;
                z6 = z7;
                bVar2 = bVar3;
                arrayList2 = arrayList3;
                gVar2 = gVar4;
                sparseArray5 = sparseArray6;
            }
            aVar = new U0.a(-9223372036854775807L, -9223372036854775807L, arrayList2);
        }
        gVar.accept(aVar);
    }

    @Override // U0.l
    public final void reset() {
        g gVar = this.f3471t;
        gVar.f3458c.clear();
        gVar.f3459d.clear();
        gVar.e.clear();
        gVar.f3460f.clear();
        gVar.f3461g.clear();
        gVar.f3462h = null;
        gVar.f3463i = null;
    }

    @Override // U0.l
    public final int z() {
        return 2;
    }
}
