package W0;

import android.util.SparseArray;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* loaded from: classes.dex */
public final class g {

    /* renamed from: a, reason: collision with root package name */
    public final int f3456a;

    /* renamed from: b, reason: collision with root package name */
    public final int f3457b;

    /* renamed from: c, reason: collision with root package name */
    public final SparseArray f3458c = new SparseArray();

    /* renamed from: d, reason: collision with root package name */
    public final SparseArray f3459d = new SparseArray();
    public final SparseArray e = new SparseArray();

    /* renamed from: f, reason: collision with root package name */
    public final SparseArray f3460f = new SparseArray();

    /* renamed from: g, reason: collision with root package name */
    public final SparseArray f3461g = new SparseArray();

    /* renamed from: h, reason: collision with root package name */
    public b f3462h;

    /* renamed from: i, reason: collision with root package name */
    public R0.f f3463i;

    public g(int i6, int i7) {
        this.f3456a = i6;
        this.f3457b = i7;
    }
}
