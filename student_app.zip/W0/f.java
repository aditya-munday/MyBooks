package W0;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* loaded from: classes.dex */
public final class f {

    /* renamed from: a, reason: collision with root package name */
    public final int f3454a;

    /* renamed from: b, reason: collision with root package name */
    public final int f3455b;

    public f(int i6, int i7) {
        this.f3454a = i6;
        this.f3455b = i7;
    }
}
