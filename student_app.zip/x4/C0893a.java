package x4;

import I4.b;
import L4.j;
import M4.m;
import M4.n;
import M4.o;
import M4.p;
import android.content.Context;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.Signature;
import android.content.pm.SigningInfo;
import android.os.Build;
import h5.AbstractC0469c;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.HashMap;
import org.apache.tika.fork.ForkServer;
import org.apache.tika.utils.StringUtils;
import q5.h;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* renamed from: x4.a, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0893a implements n, b {
    public Context o;

    /* renamed from: p, reason: collision with root package name */
    public p f10282p;

    public static String b(byte[] bArr) {
        MessageDigest messageDigest = MessageDigest.getInstance("SHA-256");
        messageDigest.update(bArr);
        byte[] digest = messageDigest.digest();
        h.b(digest);
        char[] cArr = {'0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'A', 'B', 'C', 'D', 'E', 'F'};
        char[] cArr2 = new char[digest.length * 2];
        int length = digest.length;
        for (int i6 = 0; i6 < length; i6++) {
            byte b6 = digest[i6];
            int i7 = i6 * 2;
            cArr2[i7] = cArr[(b6 & ForkServer.ERROR) >>> 4];
            cArr2[i7 + 1] = cArr[b6 & 15];
        }
        return new String(cArr2);
    }

    public final String a(PackageManager packageManager) {
        try {
            if (Build.VERSION.SDK_INT >= 28) {
                Context context = this.o;
                h.b(context);
                SigningInfo signingInfo = packageManager.getPackageInfo(context.getPackageName(), 134217728).signingInfo;
                if (signingInfo != null) {
                    if (signingInfo.hasMultipleSigners()) {
                        Signature[] apkContentsSigners = signingInfo.getApkContentsSigners();
                        h.d(apkContentsSigners, "getApkContentsSigners(...)");
                        byte[] byteArray = ((Signature) AbstractC0469c.w0(apkContentsSigners)).toByteArray();
                        h.d(byteArray, "toByteArray(...)");
                        return b(byteArray);
                    }
                    Signature[] signingCertificateHistory = signingInfo.getSigningCertificateHistory();
                    h.d(signingCertificateHistory, "getSigningCertificateHistory(...)");
                    byte[] byteArray2 = ((Signature) AbstractC0469c.w0(signingCertificateHistory)).toByteArray();
                    h.d(byteArray2, "toByteArray(...)");
                    return b(byteArray2);
                }
                return null;
            }
            Context context2 = this.o;
            h.b(context2);
            Signature[] signatureArr = packageManager.getPackageInfo(context2.getPackageName(), 64).signatures;
            if (signatureArr != null && signatureArr.length != 0 && AbstractC0469c.w0(signatureArr) != null) {
                byte[] byteArray3 = ((Signature) AbstractC0469c.w0(signatureArr)).toByteArray();
                h.d(byteArray3, "toByteArray(...)");
                return b(byteArray3);
            }
            return null;
        } catch (PackageManager.NameNotFoundException | NoSuchAlgorithmException unused) {
            return null;
        }
    }

    @Override // I4.b
    public final void onAttachedToEngine(I4.a aVar) {
        h.e(aVar, "binding");
        this.o = aVar.f1090a;
        p pVar = new p(aVar.f1091b, "dev.fluttercommunity.plus/package_info");
        this.f10282p = pVar;
        pVar.b(this);
    }

    @Override // I4.b
    public final void onDetachedFromEngine(I4.a aVar) {
        h.e(aVar, "binding");
        this.o = null;
        p pVar = this.f10282p;
        h.b(pVar);
        pVar.b(null);
        this.f10282p = null;
    }

    /* JADX WARN: Removed duplicated region for block: B:18:0x0087  */
    /* JADX WARN: Removed duplicated region for block: B:21:0x0092 A[Catch: NameNotFoundException -> 0x006d, TryCatch #0 {NameNotFoundException -> 0x006d, blocks: (B:3:0x0005, B:5:0x000f, B:7:0x0042, B:8:0x004f, B:11:0x0060, B:13:0x0066, B:16:0x0070, B:19:0x0089, B:21:0x0092, B:22:0x009a, B:24:0x00a3, B:26:0x00aa, B:27:0x00af, B:30:0x0097, B:33:0x004b, B:34:0x00c8), top: B:2:0x0005 }] */
    /* JADX WARN: Removed duplicated region for block: B:24:0x00a3 A[Catch: NameNotFoundException -> 0x006d, TryCatch #0 {NameNotFoundException -> 0x006d, blocks: (B:3:0x0005, B:5:0x000f, B:7:0x0042, B:8:0x004f, B:11:0x0060, B:13:0x0066, B:16:0x0070, B:19:0x0089, B:21:0x0092, B:22:0x009a, B:24:0x00a3, B:26:0x00aa, B:27:0x00af, B:30:0x0097, B:33:0x004b, B:34:0x00c8), top: B:2:0x0005 }] */
    /* JADX WARN: Removed duplicated region for block: B:26:0x00aa A[Catch: NameNotFoundException -> 0x006d, TryCatch #0 {NameNotFoundException -> 0x006d, blocks: (B:3:0x0005, B:5:0x000f, B:7:0x0042, B:8:0x004f, B:11:0x0060, B:13:0x0066, B:16:0x0070, B:19:0x0089, B:21:0x0092, B:22:0x009a, B:24:0x00a3, B:26:0x00aa, B:27:0x00af, B:30:0x0097, B:33:0x004b, B:34:0x00c8), top: B:2:0x0005 }] */
    /* JADX WARN: Removed duplicated region for block: B:30:0x0097 A[Catch: NameNotFoundException -> 0x006d, TryCatch #0 {NameNotFoundException -> 0x006d, blocks: (B:3:0x0005, B:5:0x000f, B:7:0x0042, B:8:0x004f, B:11:0x0060, B:13:0x0066, B:16:0x0070, B:19:0x0089, B:21:0x0092, B:22:0x009a, B:24:0x00a3, B:26:0x00aa, B:27:0x00af, B:30:0x0097, B:33:0x004b, B:34:0x00c8), top: B:2:0x0005 }] */
    /* JADX WARN: Removed duplicated region for block: B:31:0x0088  */
    @Override // M4.n
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final void onMethodCall(m mVar, o oVar) {
        String installerPackageName;
        String str;
        String str2;
        long j6;
        h.e(mVar, "call");
        try {
            if (mVar.f1733a.equals("getAll")) {
                Context context = this.o;
                h.b(context);
                PackageManager packageManager = context.getPackageManager();
                Context context2 = this.o;
                h.b(context2);
                PackageInfo packageInfo = packageManager.getPackageInfo(context2.getPackageName(), 0);
                String a6 = a(packageManager);
                Context context3 = this.o;
                h.b(context3);
                PackageManager packageManager2 = context3.getPackageManager();
                Context context4 = this.o;
                h.b(context4);
                String packageName = context4.getPackageName();
                int i6 = Build.VERSION.SDK_INT;
                if (i6 >= 30) {
                    installerPackageName = packageManager2.getInstallSourceInfo(packageName).getInitiatingPackageName();
                } else {
                    installerPackageName = packageManager2.getInstallerPackageName(packageName);
                }
                long j7 = packageInfo.firstInstallTime;
                long j8 = packageInfo.lastUpdateTime;
                HashMap hashMap = new HashMap();
                ApplicationInfo applicationInfo = packageInfo.applicationInfo;
                String str3 = StringUtils.EMPTY;
                if (applicationInfo != null) {
                    CharSequence loadLabel = applicationInfo.loadLabel(packageManager);
                    if (loadLabel != null) {
                        str = loadLabel.toString();
                        if (str == null) {
                        }
                        hashMap.put("appName", str);
                        Context context5 = this.o;
                        h.b(context5);
                        hashMap.put("packageName", context5.getPackageName());
                        str2 = packageInfo.versionName;
                        if (str2 == null) {
                            str3 = str2;
                        }
                        hashMap.put("version", str3);
                        if (i6 < 28) {
                            j6 = packageInfo.getLongVersionCode();
                        } else {
                            j6 = packageInfo.versionCode;
                        }
                        hashMap.put("buildNumber", String.valueOf(j6));
                        if (a6 != null) {
                            hashMap.put("buildSignature", a6);
                        }
                        if (installerPackageName != null) {
                            hashMap.put("installerStore", installerPackageName);
                        }
                        hashMap.put("installTime", String.valueOf(j7));
                        hashMap.put("updateTime", String.valueOf(j8));
                        ((j) oVar).b(hashMap);
                        return;
                    }
                }
                str = StringUtils.EMPTY;
                hashMap.put("appName", str);
                Context context52 = this.o;
                h.b(context52);
                hashMap.put("packageName", context52.getPackageName());
                str2 = packageInfo.versionName;
                if (str2 == null) {
                }
                hashMap.put("version", str3);
                if (i6 < 28) {
                }
                hashMap.put("buildNumber", String.valueOf(j6));
                if (a6 != null) {
                }
                if (installerPackageName != null) {
                }
                hashMap.put("installTime", String.valueOf(j7));
                hashMap.put("updateTime", String.valueOf(j8));
                ((j) oVar).b(hashMap);
                return;
            }
            ((j) oVar).c();
        } catch (PackageManager.NameNotFoundException e) {
            ((j) oVar).d("Name not found", e.getMessage(), null);
        }
    }
}
