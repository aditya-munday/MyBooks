package M2;

import C4.AbstractC0034i;
import L2.b;
import W2.o;
import W2.p;
import java.security.GeneralSecurityException;
import java.security.spec.AlgorithmParameterSpec;
import javax.crypto.Cipher;
import javax.crypto.spec.GCMParameterSpec;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* loaded from: classes.dex */
public final class a implements J2.a {

    /* renamed from: b, reason: collision with root package name */
    public static final b f1721b = new b(1);

    /* renamed from: c, reason: collision with root package name */
    public static final boolean f1722c;

    /* renamed from: a, reason: collision with root package name */
    public final SecretKeySpec f1723a;

    static {
        boolean z6 = true;
        try {
            Class.forName("javax.crypto.spec.GCMParameterSpec");
        } catch (ClassNotFoundException unused) {
            z6 = false;
        }
        f1722c = z6;
    }

    public a(byte[] bArr) {
        p.a(bArr.length);
        this.f1723a = new SecretKeySpec(bArr, "AES");
    }

    public static AlgorithmParameterSpec c(byte[] bArr, int i6) {
        if (f1722c) {
            return new GCMParameterSpec(128, bArr, 0, i6);
        }
        if ("The Android Project".equals(System.getProperty("java.vendor"))) {
            return new IvParameterSpec(bArr, 0, i6);
        }
        throw new GeneralSecurityException("cannot use AES-GCM: javax.crypto.spec.GCMParameterSpec not found");
    }

    @Override // J2.a
    public final byte[] a(byte[] bArr, byte[] bArr2) {
        if (bArr.length <= 2147483619) {
            byte[] bArr3 = new byte[bArr.length + 28];
            byte[] a6 = o.a(12);
            System.arraycopy(a6, 0, bArr3, 0, 12);
            AlgorithmParameterSpec c6 = c(a6, a6.length);
            b bVar = f1721b;
            ((Cipher) bVar.get()).init(1, this.f1723a, c6);
            if (bArr2 != null && bArr2.length != 0) {
                ((Cipher) bVar.get()).updateAAD(bArr2);
            }
            int doFinal = ((Cipher) bVar.get()).doFinal(bArr, 0, bArr.length, bArr3, 12);
            if (doFinal == bArr.length + 16) {
                return bArr3;
            }
            throw new GeneralSecurityException(AbstractC0034i.i("encryption failed; GCM tag must be 16 bytes, but got only ", doFinal - bArr.length, " bytes"));
        }
        throw new GeneralSecurityException("plaintext too long");
    }

    @Override // J2.a
    public final byte[] b(byte[] bArr, byte[] bArr2) {
        if (bArr.length >= 28) {
            AlgorithmParameterSpec c6 = c(bArr, 12);
            b bVar = f1721b;
            ((Cipher) bVar.get()).init(2, this.f1723a, c6);
            if (bArr2 != null && bArr2.length != 0) {
                ((Cipher) bVar.get()).updateAAD(bArr2);
            }
            return ((Cipher) bVar.get()).doFinal(bArr, 12, bArr.length - 12);
        }
        throw new GeneralSecurityException("ciphertext too short");
    }
}
