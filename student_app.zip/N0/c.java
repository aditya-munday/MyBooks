package N0;

import S.D;
import S.E;
import V.A;
import V.u;
import V.v;
import a.AbstractC0194a;
import j2.C0508g;
import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import m3.e;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* loaded from: classes.dex */
public final class c extends AbstractC0194a {

    /* renamed from: q, reason: collision with root package name */
    public final v f1820q;

    /* renamed from: r, reason: collision with root package name */
    public final u f1821r;

    /* renamed from: s, reason: collision with root package name */
    public A f1822s;

    public c() {
        super(4);
        this.f1820q = new v();
        this.f1821r = new u();
    }

    /* JADX WARN: Code restructure failed: missing block: B:9:0x0014, code lost:
    
        if (r5 != r7) goto L14;
     */
    /* JADX WARN: Multi-variable type inference failed */
    @Override // a.AbstractC0194a
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final E x(G0.a aVar, ByteBuffer byteBuffer) {
        Object obj;
        boolean z6;
        boolean z7;
        boolean z8;
        boolean z9;
        long j6;
        boolean z10;
        boolean z11;
        boolean z12;
        long j7;
        long j8;
        v vVar = this.f1820q;
        u uVar = this.f1821r;
        A a6 = this.f1822s;
        if (a6 != null) {
            long j9 = aVar.f956x;
            synchronized (a6) {
                long j10 = a6.f3049b;
            }
        }
        A a7 = new A(aVar.f3737u);
        this.f1822s = a7;
        a7.a(aVar.f3737u - aVar.f956x);
        byte[] array = byteBuffer.array();
        int limit = byteBuffer.limit();
        vVar.H(array, limit);
        uVar.p(array, limit);
        uVar.t(39);
        long i6 = (uVar.i(1) << 32) | uVar.i(32);
        uVar.t(20);
        int i7 = uVar.i(12);
        int i8 = uVar.i(8);
        vVar.K(14);
        if (i8 != 0) {
            if (i8 != 255) {
                if (i8 != 4) {
                    if (i8 != 5) {
                        if (i8 != 6) {
                            obj = null;
                        } else {
                            A a8 = this.f1822s;
                            long d6 = a.d(i6, vVar);
                            obj = new a(2, d6, a8.b(d6));
                        }
                    } else {
                        A a9 = this.f1822s;
                        vVar.z();
                        if ((vVar.x() & 128) != 0) {
                            z9 = true;
                        } else {
                            z9 = false;
                        }
                        List list = Collections.EMPTY_LIST;
                        if (!z9) {
                            int x6 = vVar.x();
                            if ((x6 & 64) != 0) {
                                z10 = true;
                            } else {
                                z10 = false;
                            }
                            if ((x6 & 32) != 0) {
                                z11 = true;
                            } else {
                                z11 = false;
                            }
                            if ((x6 & 16) != 0) {
                                z12 = true;
                            } else {
                                z12 = false;
                            }
                            if (z10 && !z12) {
                                j7 = a.d(i6, vVar);
                            } else {
                                j7 = -9223372036854775807L;
                            }
                            if (!z10) {
                                int x7 = vVar.x();
                                ArrayList arrayList = new ArrayList(x7);
                                for (int i9 = 0; i9 < x7; i9++) {
                                    vVar.x();
                                    if (!z12) {
                                        j8 = a.d(i6, vVar);
                                    } else {
                                        j8 = -9223372036854775807L;
                                    }
                                    a9.b(j8);
                                    arrayList.add(new C0508g(9, false));
                                }
                                list = arrayList;
                            }
                            if (z11) {
                                vVar.x();
                                vVar.z();
                            }
                            vVar.D();
                            vVar.x();
                            vVar.x();
                            j6 = j7;
                        } else {
                            j6 = -9223372036854775807L;
                        }
                        obj = new a(j6, a9.b(j6), list);
                    }
                } else {
                    int x8 = vVar.x();
                    ArrayList arrayList2 = new ArrayList(x8);
                    for (int i10 = 0; i10 < x8; i10++) {
                        vVar.z();
                        if ((vVar.x() & 128) != 0) {
                            z6 = true;
                        } else {
                            z6 = false;
                        }
                        ArrayList arrayList3 = new ArrayList();
                        if (!z6) {
                            int x9 = vVar.x();
                            if ((x9 & 64) != 0) {
                                z7 = true;
                            } else {
                                z7 = false;
                            }
                            if ((x9 & 32) != 0) {
                                z8 = true;
                            } else {
                                z8 = false;
                            }
                            if (z7) {
                                vVar.z();
                            }
                            if (!z7) {
                                int x10 = vVar.x();
                                ArrayList arrayList4 = new ArrayList(x10);
                                for (int i11 = 0; i11 < x10; i11++) {
                                    vVar.x();
                                    vVar.z();
                                    arrayList4.add(new e(9));
                                }
                                arrayList3 = arrayList4;
                            }
                            if (z8) {
                                vVar.x();
                                vVar.z();
                            }
                            vVar.D();
                            vVar.x();
                            vVar.x();
                        }
                        C0508g c0508g = new C0508g(10, false);
                        Collections.unmodifiableList(arrayList3);
                        arrayList2.add(c0508g);
                    }
                    obj = new Object();
                    Collections.unmodifiableList(arrayList2);
                }
            } else {
                long z13 = vVar.z();
                int i12 = i7 - 4;
                vVar.i(new byte[i12], 0, i12);
                obj = new a(0, z13, i6);
            }
        } else {
            obj = new Object();
        }
        if (obj == null) {
            return new E(new D[0]);
        }
        return new E(obj);
    }
}
