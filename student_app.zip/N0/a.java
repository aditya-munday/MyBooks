package N0;

import C4.AbstractC0034i;
import V.v;
import java.util.Collections;
import java.util.List;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* loaded from: classes.dex */
public final class a extends b {

    /* renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f1817a;

    /* renamed from: b, reason: collision with root package name */
    public final long f1818b;

    /* renamed from: c, reason: collision with root package name */
    public final long f1819c;

    public a(int i6, long j6, long j7) {
        this.f1817a = i6;
        switch (i6) {
            case 2:
                this.f1818b = j6;
                this.f1819c = j7;
                return;
            default:
                this.f1818b = j7;
                this.f1819c = j6;
                return;
        }
    }

    public static long d(long j6, v vVar) {
        long x6 = vVar.x();
        if ((128 & x6) != 0) {
            return 8589934591L & ((((x6 & 1) << 32) | vVar.z()) + j6);
        }
        return -9223372036854775807L;
    }

    @Override // N0.b
    public final String toString() {
        switch (this.f1817a) {
            case 0:
                StringBuilder sb = new StringBuilder("SCTE-35 PrivateCommand { ptsAdjustment=");
                sb.append(this.f1818b);
                sb.append(", identifier= ");
                return AbstractC0034i.m(sb, this.f1819c, " }");
            case 1:
                StringBuilder sb2 = new StringBuilder("SCTE-35 SpliceInsertCommand { programSplicePts=");
                sb2.append(this.f1818b);
                sb2.append(", programSplicePlaybackPositionUs= ");
                return AbstractC0034i.m(sb2, this.f1819c, " }");
            default:
                StringBuilder sb3 = new StringBuilder("SCTE-35 TimeSignalCommand { ptsTime=");
                sb3.append(this.f1818b);
                sb3.append(", playbackPositionUs= ");
                return AbstractC0034i.m(sb3, this.f1819c, " }");
        }
    }

    public a(long j6, long j7, List list) {
        this.f1817a = 1;
        this.f1818b = j6;
        this.f1819c = j7;
        Collections.unmodifiableList(list);
    }
}
