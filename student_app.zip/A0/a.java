package A0;

import S.r;
import V.v;
import x0.C;
import x0.l;
import x0.o;
import x0.p;
import x0.q;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* loaded from: classes.dex */
public final class a implements o {

    /* renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f40a;

    /* renamed from: b, reason: collision with root package name */
    public final v f41b;

    /* renamed from: c, reason: collision with root package name */
    public final C f42c;

    public a(int i6) {
        this.f40a = i6;
        switch (i6) {
            case 1:
                this.f41b = new v(4);
                this.f42c = new C(-1, "image/heif", -1);
                return;
            case 2:
                this.f41b = new v(4);
                this.f42c = new C(-1, "image/webp", -1);
                return;
            default:
                this.f41b = new v(4);
                this.f42c = new C(-1, "image/avif", -1);
                return;
        }
    }

    @Override // x0.o
    public final void a(long j6, long j7) {
        switch (this.f40a) {
            case 0:
                this.f42c.a(j6, j7);
                return;
            case 1:
                this.f42c.a(j6, j7);
                return;
            default:
                this.f42c.a(j6, j7);
                return;
        }
    }

    @Override // x0.o
    public final boolean f(p pVar) {
        switch (this.f40a) {
            case 0:
                l lVar = (l) pVar;
                lVar.b(4, false);
                v vVar = this.f41b;
                vVar.G(4);
                lVar.x(vVar.f3120a, 0, 4, false);
                if (vVar.z() != 1718909296) {
                    return false;
                }
                vVar.G(4);
                lVar.x(vVar.f3120a, 0, 4, false);
                if (vVar.z() != 1635150182) {
                    return false;
                }
                return true;
            case 1:
                l lVar2 = (l) pVar;
                lVar2.b(4, false);
                v vVar2 = this.f41b;
                vVar2.G(4);
                lVar2.x(vVar2.f3120a, 0, 4, false);
                if (vVar2.z() != 1718909296) {
                    return false;
                }
                vVar2.G(4);
                lVar2.x(vVar2.f3120a, 0, 4, false);
                if (vVar2.z() != 1751476579) {
                    return false;
                }
                return true;
            default:
                v vVar3 = this.f41b;
                vVar3.G(4);
                l lVar3 = (l) pVar;
                lVar3.x(vVar3.f3120a, 0, 4, false);
                if (vVar3.z() != 1380533830) {
                    return false;
                }
                lVar3.b(4, false);
                vVar3.G(4);
                lVar3.x(vVar3.f3120a, 0, 4, false);
                if (vVar3.z() != 1464156752) {
                    return false;
                }
                return true;
        }
    }

    @Override // x0.o
    public final int h(p pVar, r rVar) {
        switch (this.f40a) {
            case 0:
                return this.f42c.h(pVar, rVar);
            case 1:
                return this.f42c.h(pVar, rVar);
            default:
                return this.f42c.h(pVar, rVar);
        }
    }

    @Override // x0.o
    public final void k(q qVar) {
        switch (this.f40a) {
            case 0:
                this.f42c.k(qVar);
                return;
            case 1:
                this.f42c.k(qVar);
                return;
            default:
                this.f42c.k(qVar);
                return;
        }
    }

    @Override // x0.o
    public final void release() {
        int i6 = this.f40a;
    }

    private final void b() {
    }

    private final void c() {
    }

    private final void d() {
    }
}
