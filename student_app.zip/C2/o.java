package C2;

import androidx.lifecycle.k;
import androidx.lifecycle.r;
import androidx.lifecycle.t;
import java.util.ArrayDeque;
import l.h0;
import l1.C0627a;
import q5.h;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* loaded from: classes.dex */
public final class o {

    /* renamed from: a, reason: collision with root package name */
    public boolean f276a;

    /* renamed from: b, reason: collision with root package name */
    public Object f277b;

    /* renamed from: c, reason: collision with root package name */
    public Object f278c;

    public void a(double d6, double d7) {
        double[] dArr = (double[]) this.f277b;
        double d8 = 1.0d;
        if (!this.f276a) {
            d8 = 1.0d / (((dArr[7] * d7) + (dArr[3] * d6)) + dArr[15]);
        }
        double d9 = ((dArr[4] * d7) + (dArr[0] * d6) + dArr[12]) * d8;
        double d10 = ((dArr[5] * d7) + (dArr[1] * d6) + dArr[13]) * d8;
        double[] dArr2 = (double[]) this.f278c;
        if (d9 < dArr2[0]) {
            dArr2[0] = d9;
        } else if (d9 > dArr2[1]) {
            dArr2[1] = d9;
        }
        if (d10 < dArr2[2]) {
            dArr2[2] = d10;
        } else if (d10 > dArr2[3]) {
            dArr2[3] = d10;
        }
    }

    /* JADX WARN: Type inference failed for: r0v0, types: [androidx.lifecycle.r, java.lang.Object] */
    public void b() {
        ?? r02 = this.f277b;
        t d6 = r02.d();
        if (d6.f4917c == androidx.lifecycle.l.f4907p) {
            d6.a(new C0627a(r02, 0));
            final h0 h0Var = (h0) this.f278c;
            h0Var.getClass();
            if (!h0Var.f8112a) {
                d6.a(new androidx.lifecycle.p() { // from class: l1.b
                    @Override // androidx.lifecycle.p
                    public final void d(r rVar, k kVar) {
                        h.e(h0.this, "this$0");
                    }
                });
                h0Var.f8112a = true;
                this.f276a = true;
                return;
            }
            throw new IllegalStateException("SavedStateRegistry was already attached.");
        }
        throw new IllegalStateException("Restarter must be created only during owner's initialization stage");
    }

    public void c(n nVar) {
        synchronized (this.f277b) {
            try {
                if (((ArrayDeque) this.f278c) == null) {
                    this.f278c = new ArrayDeque();
                }
                ((ArrayDeque) this.f278c).add(nVar);
            } catch (Throwable th) {
                throw th;
            }
        }
    }

    public void d(i iVar) {
        n nVar;
        synchronized (this.f277b) {
            if (((ArrayDeque) this.f278c) != null && !this.f276a) {
                this.f276a = true;
                while (true) {
                    synchronized (this.f277b) {
                        try {
                            nVar = (n) ((ArrayDeque) this.f278c).poll();
                            if (nVar == null) {
                                this.f276a = false;
                                return;
                            }
                        } finally {
                        }
                    }
                    nVar.a(iVar);
                }
            }
        }
    }
}
