package C2;

import java.util.concurrent.Executor;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* loaded from: classes.dex */
public final class m implements n, f, e, c {
    public final /* synthetic */ int o;

    /* renamed from: p, reason: collision with root package name */
    public final Executor f273p;

    /* renamed from: q, reason: collision with root package name */
    public final Object f274q;

    /* renamed from: r, reason: collision with root package name */
    public final Object f275r;

    public m(Executor executor, c cVar) {
        this.o = 0;
        this.f274q = new Object();
        this.f273p = executor;
        this.f275r = cVar;
    }

    @Override // C2.n
    public final void a(i iVar) {
        switch (this.o) {
            case 0:
                if (((r) iVar).f283d) {
                    synchronized (this.f274q) {
                    }
                    this.f273p.execute(new B2.b(this, 1));
                    return;
                }
                return;
            case 1:
                synchronized (this.f274q) {
                }
                this.f273p.execute(new A.a(this, iVar, 4, false));
                return;
            case 2:
                if (!iVar.f() && !((r) iVar).f283d) {
                    synchronized (this.f274q) {
                    }
                    this.f273p.execute(new A.a(this, iVar, 5, false));
                    return;
                }
                return;
            case 3:
                if (iVar.f()) {
                    synchronized (this.f274q) {
                    }
                    this.f273p.execute(new A.a(this, iVar, 6, false));
                    return;
                }
                return;
            default:
                this.f273p.execute(new A.a(this, iVar, 7, false));
                return;
        }
    }

    @Override // C2.c
    public void b() {
        ((r) this.f275r).n();
    }

    @Override // C2.f
    public void c(Object obj) {
        ((r) this.f275r).m(obj);
    }

    @Override // C2.e
    public void e(Exception exc) {
        ((r) this.f275r).l(exc);
    }

    public m(Executor executor, d dVar) {
        this.o = 1;
        this.f274q = new Object();
        this.f273p = executor;
        this.f275r = dVar;
    }

    public m(Executor executor, e eVar) {
        this.o = 2;
        this.f274q = new Object();
        this.f273p = executor;
        this.f275r = eVar;
    }

    public m(Executor executor, f fVar) {
        this.o = 3;
        this.f274q = new Object();
        this.f273p = executor;
        this.f275r = fVar;
    }

    public m(Executor executor, h hVar, r rVar) {
        this.o = 4;
        this.f273p = executor;
        this.f274q = hVar;
        this.f275r = rVar;
    }
}
