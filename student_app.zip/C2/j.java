package C2;

import m2.s;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* loaded from: classes.dex */
public final class j {

    /* renamed from: a, reason: collision with root package name */
    public final r f267a = new r();

    public final void a(Exception exc) {
        this.f267a.l(exc);
    }

    public final void b(Object obj) {
        this.f267a.m(obj);
    }

    public final boolean c(Exception exc) {
        r rVar = this.f267a;
        rVar.getClass();
        s.f(exc, "Exception must not be null");
        synchronized (rVar.f280a) {
            try {
                if (rVar.f282c) {
                    return false;
                }
                rVar.f282c = true;
                rVar.f284f = exc;
                rVar.f281b.d(rVar);
                return true;
            } catch (Throwable th) {
                throw th;
            }
        }
    }

    public final void d(Object obj) {
        r rVar = this.f267a;
        synchronized (rVar.f280a) {
            try {
                if (rVar.f282c) {
                    return;
                }
                rVar.f282c = true;
                rVar.e = obj;
                rVar.f281b.d(rVar);
            } catch (Throwable th) {
                throw th;
            }
        }
    }
}
