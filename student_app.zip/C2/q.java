package C2;

import android.os.Handler;
import android.os.Looper;
import java.util.concurrent.Executor;
import java.util.concurrent.ExecutorService;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* loaded from: classes.dex */
public final class q implements Executor {
    public final /* synthetic */ int o = 0;

    /* renamed from: p, reason: collision with root package name */
    public final Object f279p;

    public q() {
        Handler handler = new Handler(Looper.getMainLooper());
        Looper.getMainLooper();
        this.f279p = handler;
    }

    @Override // java.util.concurrent.Executor
    public final void execute(Runnable runnable) {
        switch (this.o) {
            case 0:
                ((u2.f) this.f279p).post(runnable);
                return;
            default:
                ((Executor) this.f279p).execute(new V1.o(runnable, 0));
                return;
        }
    }

    public q(ExecutorService executorService) {
        this.f279p = executorService;
    }
}
