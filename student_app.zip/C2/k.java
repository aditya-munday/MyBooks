package C2;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* loaded from: classes.dex */
public abstract class k {

    /* renamed from: a, reason: collision with root package name */
    public static final q f268a = new q();

    /* renamed from: b, reason: collision with root package name */
    public static final p f269b = new Object();
}
