package C2;

import java.util.concurrent.CancellationException;
import java.util.concurrent.Executor;
import m2.s;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* loaded from: classes.dex */
public final class r extends i {

    /* renamed from: a, reason: collision with root package name */
    public final Object f280a = new Object();

    /* renamed from: b, reason: collision with root package name */
    public final o f281b;

    /* renamed from: c, reason: collision with root package name */
    public boolean f282c;

    /* renamed from: d, reason: collision with root package name */
    public volatile boolean f283d;
    public Object e;

    /* renamed from: f, reason: collision with root package name */
    public Exception f284f;

    /* JADX WARN: Type inference failed for: r0v1, types: [java.lang.Object, C2.o] */
    public r() {
        ?? obj = new Object();
        obj.f277b = new Object();
        this.f281b = obj;
    }

    @Override // C2.i
    public final r a(Executor executor, e eVar) {
        this.f281b.c(new m(executor, eVar));
        p();
        return this;
    }

    @Override // C2.i
    public final r b(Executor executor, f fVar) {
        this.f281b.c(new m(executor, fVar));
        p();
        return this;
    }

    @Override // C2.i
    public final Exception c() {
        Exception exc;
        synchronized (this.f280a) {
            exc = this.f284f;
        }
        return exc;
    }

    @Override // C2.i
    public final Object d() {
        Object obj;
        synchronized (this.f280a) {
            try {
                if (this.f282c) {
                    if (!this.f283d) {
                        Exception exc = this.f284f;
                        if (exc == null) {
                            obj = this.e;
                        } else {
                            throw new RuntimeException(exc);
                        }
                    } else {
                        throw new CancellationException("Task is already canceled.");
                    }
                } else {
                    throw new IllegalStateException("Task is not yet complete");
                }
            } catch (Throwable th) {
                throw th;
            }
        }
        return obj;
    }

    @Override // C2.i
    public final boolean e() {
        boolean z6;
        synchronized (this.f280a) {
            z6 = this.f282c;
        }
        return z6;
    }

    @Override // C2.i
    public final boolean f() {
        boolean z6;
        synchronized (this.f280a) {
            try {
                z6 = false;
                if (this.f282c && !this.f283d && this.f284f == null) {
                    z6 = true;
                }
            } finally {
            }
        }
        return z6;
    }

    public final r g(d dVar) {
        this.f281b.c(new m(k.f268a, dVar));
        p();
        return this;
    }

    public final r h(Executor executor, d dVar) {
        this.f281b.c(new m(executor, dVar));
        p();
        return this;
    }

    public final r i(Executor executor, a aVar) {
        r rVar = new r();
        this.f281b.c(new l(executor, aVar, rVar, 0));
        p();
        return rVar;
    }

    public final r j(Executor executor, a aVar) {
        r rVar = new r();
        this.f281b.c(new l(executor, aVar, rVar, 1));
        p();
        return rVar;
    }

    public final r k(Executor executor, h hVar) {
        r rVar = new r();
        this.f281b.c(new m(executor, hVar, rVar));
        p();
        return rVar;
    }

    public final void l(Exception exc) {
        s.f(exc, "Exception must not be null");
        synchronized (this.f280a) {
            o();
            this.f282c = true;
            this.f284f = exc;
        }
        this.f281b.d(this);
    }

    public final void m(Object obj) {
        synchronized (this.f280a) {
            o();
            this.f282c = true;
            this.e = obj;
        }
        this.f281b.d(this);
    }

    public final void n() {
        synchronized (this.f280a) {
            try {
                if (this.f282c) {
                    return;
                }
                this.f282c = true;
                this.f283d = true;
                this.f281b.d(this);
            } catch (Throwable th) {
                throw th;
            }
        }
    }

    public final void o() {
        String str;
        if (this.f282c) {
            int i6 = b.o;
            if (e()) {
                Exception c6 = c();
                if (c6 == null) {
                    if (!f()) {
                        if (this.f283d) {
                            str = "cancellation";
                        } else {
                            str = "unknown issue";
                        }
                    } else {
                        str = "result ".concat(String.valueOf(d()));
                    }
                } else {
                    str = "failure";
                }
                throw new IllegalStateException("Complete with: ".concat(str), c6);
            }
            throw new IllegalStateException("DuplicateTaskCompletionException can only be created from completed Task.");
        }
    }

    public final void p() {
        synchronized (this.f280a) {
            try {
                if (!this.f282c) {
                    return;
                }
                this.f281b.d(this);
            } catch (Throwable th) {
                throw th;
            }
        }
    }
}
