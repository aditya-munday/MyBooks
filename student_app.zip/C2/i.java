package C2;

import java.util.concurrent.Executor;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* loaded from: classes.dex */
public abstract class i {
    public abstract r a(Executor executor, e eVar);

    public abstract r b(Executor executor, f fVar);

    public abstract Exception c();

    public abstract Object d();

    public abstract boolean e();

    public abstract boolean f();
}
