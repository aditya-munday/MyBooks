package C2;

import java.util.concurrent.Executor;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* loaded from: classes.dex */
public final class l implements n, f, e, c {
    public final /* synthetic */ int o;

    /* renamed from: p, reason: collision with root package name */
    public final Executor f270p;

    /* renamed from: q, reason: collision with root package name */
    public final a f271q;

    /* renamed from: r, reason: collision with root package name */
    public final r f272r;

    public /* synthetic */ l(Executor executor, a aVar, r rVar, int i6) {
        this.o = i6;
        this.f270p = executor;
        this.f271q = aVar;
        this.f272r = rVar;
    }

    @Override // C2.n
    public final void a(i iVar) {
        switch (this.o) {
            case 0:
                this.f270p.execute(new A.a(this, iVar, 2, false));
                return;
            default:
                this.f270p.execute(new A.a(this, iVar, 3, false));
                return;
        }
    }

    @Override // C2.c
    public void b() {
        this.f272r.n();
    }

    @Override // C2.f
    public void c(Object obj) {
        this.f272r.m(obj);
    }

    @Override // C2.e
    public void e(Exception exc) {
        this.f272r.l(exc);
    }
}
