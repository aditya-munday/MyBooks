package T3;

import C5.v;
import F5.g;
import T5.h;
import V3.c;
import V3.d;
import Z.C0179k;
import android.os.Handler;
import android.util.Log;
import c4.C0309c;
import c4.RunnableC0310d;
import java.util.concurrent.Callable;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* loaded from: classes.dex */
public final class a implements Callable {
    public final /* synthetic */ b o;

    public a(b bVar) {
        this.o = bVar;
    }

    /* JADX WARN: Not initialized variable reg: 6, insn: 0x0045: MOVE (r1 I:??[OBJECT, ARRAY]) = (r6 I:??[OBJECT, ARRAY]) (LINE:70), block:B:32:0x0045 */
    /* JADX WARN: Removed duplicated region for block: B:34:0x0099  */
    @Override // java.util.concurrent.Callable
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final Object call() {
        C0309c c0309c;
        C0309c c0309c2;
        C0309c c0309c3 = null;
        if (v.f519c <= 1) {
            Log.i("TranscodeEngine", "transcode(): called...", null);
        }
        b bVar = this.o;
        C0179k c0179k = new C0179k(bVar);
        Handler handler = (Handler) c0179k.f4193p;
        try {
            try {
                c0309c = new C0309c(new d(bVar), bVar.f2805a, new c(bVar.e, bVar.f2808d), bVar.f2809f, bVar.f2811h, bVar.f2812i, bVar.f2810g);
                try {
                    if (!c0309c.c()) {
                        handler.post(new RunnableC0310d(c0179k, 1));
                    } else {
                        c0309c.b(new g(c0179k, 2));
                        handler.post(new RunnableC0310d(c0179k, 0));
                    }
                    c0309c.a();
                    return null;
                } catch (Exception e) {
                    e = e;
                    if (h.w(e)) {
                        if (v.f519c <= 1) {
                            Log.i("TranscodeEngine", "Transcode canceled.", e);
                        }
                        handler.post(new RunnableC0310d(c0179k));
                        if (c0309c != null) {
                            c0309c.a();
                        }
                        return null;
                    }
                    if (v.f519c <= 3) {
                        Log.e("TranscodeEngine", "Unexpected error while transcoding.", e);
                    }
                    handler.post(new RunnableC0310d(c0179k, e));
                    throw e;
                }
            } catch (Throwable th) {
                th = th;
                c0309c3 = c0309c2;
                if (c0309c3 != null) {
                    c0309c3.a();
                }
                throw th;
            }
        } catch (Exception e6) {
            e = e6;
            c0309c = null;
        } catch (Throwable th2) {
            th = th2;
            if (c0309c3 != null) {
            }
            throw th;
        }
    }
}
