package l0;

import android.net.Uri;
import java.util.HashMap;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* renamed from: l0.D, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0606D {

    /* renamed from: a, reason: collision with root package name */
    public final HashMap f8240a = new HashMap();

    /* renamed from: b, reason: collision with root package name */
    public final E2.F f8241b = new E2.C(4);

    /* renamed from: c, reason: collision with root package name */
    public int f8242c = -1;

    /* renamed from: d, reason: collision with root package name */
    public String f8243d;
    public String e;

    /* renamed from: f, reason: collision with root package name */
    public String f8244f;

    /* renamed from: g, reason: collision with root package name */
    public Uri f8245g;

    /* renamed from: h, reason: collision with root package name */
    public String f8246h;

    /* renamed from: i, reason: collision with root package name */
    public String f8247i;

    /* renamed from: j, reason: collision with root package name */
    public String f8248j;

    /* renamed from: k, reason: collision with root package name */
    public String f8249k;

    /* renamed from: l, reason: collision with root package name */
    public String f8250l;
}
