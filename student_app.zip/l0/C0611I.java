package l0;

import C4.AbstractC0034i;
import V.AbstractC0133a;
import android.net.Uri;
import java.net.DatagramSocket;
import java.util.Locale;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* renamed from: l0.I, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0611I implements InterfaceC0616e {
    public final X.B o = new X.B(Q5.a.j(8000));

    /* renamed from: p, reason: collision with root package name */
    public C0611I f8270p;

    @Override // X.h
    public final long B(X.k kVar) {
        this.o.B(kVar);
        return -1L;
    }

    @Override // l0.InterfaceC0616e
    public final C0609G C() {
        return null;
    }

    @Override // l0.InterfaceC0616e
    public final String a() {
        boolean z6;
        int h6 = h();
        if (h6 != -1) {
            z6 = true;
        } else {
            z6 = false;
        }
        AbstractC0133a.i(z6);
        String str = V.C.f3053a;
        Locale locale = Locale.US;
        return AbstractC0034i.h(h6, h6 + 1, "RTP/AVP;unicast;client_port=", "-");
    }

    @Override // X.h
    public final void close() {
        this.o.close();
        C0611I c0611i = this.f8270p;
        if (c0611i != null) {
            c0611i.close();
        }
    }

    @Override // l0.InterfaceC0616e
    public final int h() {
        int localPort;
        DatagramSocket datagramSocket = this.o.f3552w;
        if (datagramSocket == null) {
            localPort = -1;
        } else {
            localPort = datagramSocket.getLocalPort();
        }
        if (localPort == -1) {
            return -1;
        }
        return localPort;
    }

    @Override // X.h
    public final void i(X.z zVar) {
        this.o.i(zVar);
    }

    @Override // S.InterfaceC0116i
    public final int read(byte[] bArr, int i6, int i7) {
        try {
            return this.o.read(bArr, i6, i7);
        } catch (X.A e) {
            if (e.o == 2002) {
                return -1;
            }
            throw e;
        }
    }

    @Override // l0.InterfaceC0616e
    public final boolean s() {
        return true;
    }

    @Override // X.h
    public final Uri v() {
        return this.o.f3551v;
    }
}
