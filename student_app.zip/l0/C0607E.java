package l0;

import E2.Z;
import E2.e0;
import android.net.Uri;
import java.util.Objects;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* renamed from: l0.E, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0607E {

    /* renamed from: a, reason: collision with root package name */
    public final e0 f8251a;

    /* renamed from: b, reason: collision with root package name */
    public final Z f8252b;

    /* renamed from: c, reason: collision with root package name */
    public final String f8253c;

    /* renamed from: d, reason: collision with root package name */
    public final String f8254d;
    public final String e;

    /* renamed from: f, reason: collision with root package name */
    public final int f8255f;

    /* renamed from: g, reason: collision with root package name */
    public final Uri f8256g;

    /* renamed from: h, reason: collision with root package name */
    public final String f8257h;

    /* renamed from: i, reason: collision with root package name */
    public final String f8258i;

    /* renamed from: j, reason: collision with root package name */
    public final String f8259j;

    /* renamed from: k, reason: collision with root package name */
    public final String f8260k;

    /* renamed from: l, reason: collision with root package name */
    public final String f8261l;

    public C0607E(C0606D c0606d) {
        this.f8251a = e0.a(c0606d.f8240a);
        this.f8252b = c0606d.f8241b.f();
        String str = c0606d.f8243d;
        String str2 = V.C.f3053a;
        this.f8253c = str;
        this.f8254d = c0606d.e;
        this.e = c0606d.f8244f;
        this.f8256g = c0606d.f8245g;
        this.f8257h = c0606d.f8246h;
        this.f8255f = c0606d.f8242c;
        this.f8258i = c0606d.f8247i;
        this.f8259j = c0606d.f8249k;
        this.f8260k = c0606d.f8250l;
        this.f8261l = c0606d.f8248j;
    }

    public final boolean equals(Object obj) {
        if (this != obj) {
            if (obj != null && C0607E.class == obj.getClass()) {
                C0607E c0607e = (C0607E) obj;
                if (this.f8255f == c0607e.f8255f) {
                    e0 e0Var = c0607e.f8251a;
                    e0 e0Var2 = this.f8251a;
                    e0Var2.getClass();
                    if (E2.r.f(e0Var, e0Var2) && this.f8252b.equals(c0607e.f8252b) && Objects.equals(this.f8254d, c0607e.f8254d) && Objects.equals(this.f8253c, c0607e.f8253c) && Objects.equals(this.e, c0607e.e) && Objects.equals(this.f8261l, c0607e.f8261l) && Objects.equals(this.f8256g, c0607e.f8256g) && Objects.equals(this.f8259j, c0607e.f8259j) && Objects.equals(this.f8260k, c0607e.f8260k) && Objects.equals(this.f8257h, c0607e.f8257h) && Objects.equals(this.f8258i, c0607e.f8258i)) {
                        return true;
                    }
                    return false;
                }
                return false;
            }
            return false;
        }
        return true;
    }

    public final int hashCode() {
        int hashCode;
        int hashCode2;
        int hashCode3;
        int hashCode4;
        int hashCode5;
        int hashCode6;
        int hashCode7;
        int hashCode8;
        int hashCode9 = (this.f8252b.hashCode() + ((this.f8251a.hashCode() + 217) * 31)) * 31;
        int i6 = 0;
        String str = this.f8254d;
        if (str == null) {
            hashCode = 0;
        } else {
            hashCode = str.hashCode();
        }
        int i7 = (hashCode9 + hashCode) * 31;
        String str2 = this.f8253c;
        if (str2 == null) {
            hashCode2 = 0;
        } else {
            hashCode2 = str2.hashCode();
        }
        int i8 = (i7 + hashCode2) * 31;
        String str3 = this.e;
        if (str3 == null) {
            hashCode3 = 0;
        } else {
            hashCode3 = str3.hashCode();
        }
        int i9 = (((i8 + hashCode3) * 31) + this.f8255f) * 31;
        String str4 = this.f8261l;
        if (str4 == null) {
            hashCode4 = 0;
        } else {
            hashCode4 = str4.hashCode();
        }
        int i10 = (i9 + hashCode4) * 31;
        Uri uri = this.f8256g;
        if (uri == null) {
            hashCode5 = 0;
        } else {
            hashCode5 = uri.hashCode();
        }
        int i11 = (i10 + hashCode5) * 31;
        String str5 = this.f8259j;
        if (str5 == null) {
            hashCode6 = 0;
        } else {
            hashCode6 = str5.hashCode();
        }
        int i12 = (i11 + hashCode6) * 31;
        String str6 = this.f8260k;
        if (str6 == null) {
            hashCode7 = 0;
        } else {
            hashCode7 = str6.hashCode();
        }
        int i13 = (i12 + hashCode7) * 31;
        String str7 = this.f8257h;
        if (str7 == null) {
            hashCode8 = 0;
        } else {
            hashCode8 = str7.hashCode();
        }
        int i14 = (i13 + hashCode8) * 31;
        String str8 = this.f8258i;
        if (str8 != null) {
            i6 = str8.hashCode();
        }
        return i14 + i6;
    }
}
