package l0;

import E2.e0;
import android.os.Handler;
import java.io.Closeable;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* renamed from: l0.l, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class RunnableC0623l implements Runnable, Closeable {
    public final Handler o = V.C.p(null);

    /* renamed from: p, reason: collision with root package name */
    public final long f8331p;

    /* renamed from: q, reason: collision with root package name */
    public boolean f8332q;

    /* renamed from: r, reason: collision with root package name */
    public final /* synthetic */ C0624m f8333r;

    public RunnableC0623l(C0624m c0624m, long j6) {
        this.f8333r = c0624m;
        this.f8331p = j6;
    }

    @Override // java.io.Closeable, java.lang.AutoCloseable
    public final void close() {
        this.f8332q = false;
        this.o.removeCallbacks(this);
    }

    @Override // java.lang.Runnable
    public final void run() {
        C0624m c0624m = this.f8333r;
        D2.i iVar = c0624m.f8346u;
        iVar.j(iVar.g(4, c0624m.y, e0.f744u, c0624m.f8347v));
        this.o.postDelayed(this, this.f8331p);
    }
}
