package l0;

import E2.Z;
import V.AbstractC0133a;
import Z.C0179k;
import c5.C0346j;
import java.io.Closeable;
import java.net.Socket;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* loaded from: classes.dex */
public final class y implements Closeable {

    /* renamed from: u, reason: collision with root package name */
    public static final Charset f8398u = StandardCharsets.UTF_8;
    public final C0179k o;

    /* renamed from: p, reason: collision with root package name */
    public final t0.o f8399p = new t0.o("ExoPlayer:RtspMessageChannel:ReceiverLoader");

    /* renamed from: q, reason: collision with root package name */
    public final Map f8400q = Collections.synchronizedMap(new HashMap());

    /* renamed from: r, reason: collision with root package name */
    public x f8401r;

    /* renamed from: s, reason: collision with root package name */
    public Socket f8402s;

    /* renamed from: t, reason: collision with root package name */
    public volatile boolean f8403t;

    public y(C0179k c0179k) {
        this.o = c0179k;
    }

    public final void a(Socket socket) {
        this.f8402s = socket;
        this.f8401r = new x(this, socket.getOutputStream());
        this.f8399p.f(new w(this, socket.getInputStream()), new C0346j(this, 19), 0);
    }

    public final void b(Z z6) {
        AbstractC0133a.j(this.f8401r);
        x xVar = this.f8401r;
        xVar.getClass();
        xVar.f8397q.post(new I3.b(xVar, new D2.e(z.f8410h, 0).b(z6).getBytes(f8398u), z6));
    }

    @Override // java.io.Closeable, java.lang.AutoCloseable
    public final void close() {
        if (this.f8403t) {
            return;
        }
        try {
            x xVar = this.f8401r;
            if (xVar != null) {
                xVar.close();
            }
            this.f8399p.e(null);
            Socket socket = this.f8402s;
            if (socket != null) {
                socket.close();
            }
            this.f8403t = true;
        } catch (Throwable th) {
            this.f8403t = true;
            throw th;
        }
    }
}
