package l0;

import android.net.Uri;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* renamed from: l0.A, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0603A {

    /* renamed from: a, reason: collision with root package name */
    public final Uri f8229a;

    /* renamed from: b, reason: collision with root package name */
    public final int f8230b;

    /* renamed from: c, reason: collision with root package name */
    public final C0625n f8231c;

    /* renamed from: d, reason: collision with root package name */
    public final String f8232d;

    public C0603A(Uri uri, int i6, C0625n c0625n, String str) {
        this.f8229a = uri;
        this.f8230b = i6;
        this.f8231c = c0625n;
        this.f8232d = str;
    }
}
