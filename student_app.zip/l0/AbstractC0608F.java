package l0;

import V.AbstractC0133a;
import android.net.Uri;
import java.util.Objects;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import org.apache.tika.pipes.pipesiterator.PipesIterator;
import org.apache.tika.utils.StringUtils;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* renamed from: l0.F, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public abstract class AbstractC0608F {

    /* renamed from: a, reason: collision with root package name */
    public static final Pattern f8262a = Pattern.compile("([a-z])=\\s?((?:.|\f)+)");

    /* renamed from: b, reason: collision with root package name */
    public static final Pattern f8263b = Pattern.compile("^([a-z])=$");

    /* renamed from: c, reason: collision with root package name */
    public static final Pattern f8264c = Pattern.compile("([\\x21\\x23-\\x27\\x2a\\x2b\\x2d\\x2e\\x30-\\x39\\x41-\\x5a\\x5e-\\x7e]+)(?::((?:.|\f)*))?");

    /* renamed from: d, reason: collision with root package name */
    public static final Pattern f8265d = Pattern.compile("(\\S+)\\s(\\S+)\\s(\\S+)\\s(\\S+)");

    /* JADX WARN: Code restructure failed: missing block: B:157:0x0218, code lost:
    
        continue;
     */
    /* JADX WARN: Code restructure failed: missing block: B:17:0x0062, code lost:
    
        throw S.G.b("Malformed SDP line: ".concat(r10), null);
     */
    /* JADX WARN: Failed to find 'out' block for switch in B:23:0x0076. Please report as an issue. */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public static C0607E a(String str) {
        boolean z6;
        String str2;
        C0606D c0606d = new C0606D();
        String str3 = z.f8410h;
        if (!str.contains(str3)) {
            str3 = z.f8409g;
        }
        String str4 = V.C.f3053a;
        String[] split = str.split(str3, -1);
        int length = split.length;
        C0612a c0612a = null;
        int i6 = 0;
        boolean z7 = false;
        while (true) {
            E2.F f6 = c0606d.f8241b;
            if (i6 < length) {
                String trim = split[i6].trim();
                if (!trim.isEmpty()) {
                    Matcher matcher = f8262a.matcher(trim);
                    if (!matcher.matches()) {
                        Matcher matcher2 = f8263b.matcher(trim);
                        if (!matcher2.matches() || !Objects.equals(matcher2.group(1), "i")) {
                        }
                    } else {
                        String group = matcher.group(1);
                        group.getClass();
                        String group2 = matcher.group(2);
                        group2.getClass();
                        switch (group.hashCode()) {
                            case 97:
                                if (group.equals("a") && !z7) {
                                    Matcher matcher3 = f8264c.matcher(group2);
                                    if (matcher3.matches()) {
                                        String group3 = matcher3.group(1);
                                        group3.getClass();
                                        String group4 = matcher3.group(2);
                                        if (group4 == null) {
                                            group4 = StringUtils.EMPTY;
                                        }
                                        if (c0612a == null) {
                                            c0606d.f8240a.put(group3, group4);
                                            break;
                                        } else {
                                            c0612a.e.put(group3, group4);
                                            break;
                                        }
                                    } else {
                                        throw S.G.b("Malformed Attribute line: ".concat(trim), null);
                                    }
                                }
                                break;
                            case 98:
                                if (group.equals("b") && !z7) {
                                    String[] split2 = group2.split(":\\s?", -1);
                                    if (split2.length == 2) {
                                        z6 = true;
                                    } else {
                                        z6 = false;
                                    }
                                    AbstractC0133a.c(z6);
                                    int parseInt = Integer.parseInt(split2[1]);
                                    if (c0612a == null) {
                                        c0606d.f8242c = parseInt * PipesIterator.DEFAULT_QUEUE_SIZE;
                                        break;
                                    } else {
                                        c0612a.f8275f = parseInt * PipesIterator.DEFAULT_QUEUE_SIZE;
                                        break;
                                    }
                                }
                                break;
                            case 99:
                                if (group.equals("c") && !z7) {
                                    if (c0612a == null) {
                                        c0606d.f8246h = group2;
                                        break;
                                    } else {
                                        c0612a.f8277h = group2;
                                        break;
                                    }
                                }
                                break;
                            case 101:
                                if (!group.equals("e")) {
                                    break;
                                } else {
                                    c0606d.f8249k = group2;
                                    break;
                                }
                            case 105:
                                if (group.equals("i") && !z7) {
                                    if (c0612a == null) {
                                        c0606d.f8248j = group2;
                                        break;
                                    } else {
                                        c0612a.f8276g = group2;
                                        break;
                                    }
                                }
                                break;
                            case 107:
                                if (group.equals("k") && !z7) {
                                    if (c0612a == null) {
                                        c0606d.f8247i = group2;
                                        break;
                                    } else {
                                        c0612a.f8278i = group2;
                                        break;
                                    }
                                }
                                break;
                            case 109:
                                if (group.equals("m")) {
                                    if (c0612a != null) {
                                        try {
                                            f6.a(c0612a.a());
                                        } catch (IllegalArgumentException | IllegalStateException e) {
                                            throw S.G.b(null, e);
                                        }
                                    }
                                    Matcher matcher4 = f8265d.matcher(group2);
                                    if (matcher4.matches()) {
                                        String group5 = matcher4.group(1);
                                        group5.getClass();
                                        String group6 = matcher4.group(2);
                                        group6.getClass();
                                        String group7 = matcher4.group(3);
                                        group7.getClass();
                                        String group8 = matcher4.group(4);
                                        group8.getClass();
                                        try {
                                            c0612a = new C0612a(Integer.parseInt(group6), Integer.parseInt(group8), group5, group7);
                                        } catch (NumberFormatException e6) {
                                            AbstractC0133a.B("SDPParser", "Malformed SDP media description line: ".concat(group2), e6);
                                            c0612a = null;
                                        }
                                        if (c0612a == null) {
                                            z7 = true;
                                            break;
                                        } else {
                                            z7 = false;
                                            break;
                                        }
                                    } else {
                                        throw S.G.b("Malformed SDP media description line: ".concat(group2), null);
                                    }
                                } else {
                                    continue;
                                }
                            case 111:
                                if (!group.equals("o")) {
                                    break;
                                } else {
                                    c0606d.e = group2;
                                    break;
                                }
                            case 112:
                                if (!group.equals("p")) {
                                    break;
                                } else {
                                    c0606d.f8250l = group2;
                                    break;
                                }
                            case 114:
                                str2 = "r";
                                group.equals(str2);
                                break;
                            case 115:
                                if (!group.equals("s")) {
                                    break;
                                } else {
                                    c0606d.f8243d = group2;
                                    break;
                                }
                            case 116:
                                if (!group.equals("t")) {
                                    break;
                                } else {
                                    c0606d.f8244f = group2;
                                    break;
                                }
                            case 117:
                                if (!group.equals("u")) {
                                    break;
                                } else {
                                    c0606d.f8245g = Uri.parse(group2);
                                    break;
                                }
                            case 118:
                                if (group.equals("v") && !"0".equals(group2)) {
                                    throw S.G.b("SDP version " + group2 + " is not supported.", null);
                                }
                                break;
                            case 122:
                                str2 = "z";
                                group.equals(str2);
                                break;
                        }
                    }
                }
                i6++;
            } else {
                if (c0612a != null) {
                    try {
                        f6.a(c0612a.a());
                    } catch (IllegalArgumentException | IllegalStateException e7) {
                        throw S.G.b(null, e7);
                    }
                }
                try {
                    return new C0607E(c0606d);
                } catch (IllegalArgumentException | IllegalStateException e8) {
                    throw S.G.b(null, e8);
                }
            }
        }
    }
}
