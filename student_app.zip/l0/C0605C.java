package l0;

import E2.Z;
import V.AbstractC0133a;
import android.net.Uri;
import java.util.Arrays;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* renamed from: l0.C, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0605C {

    /* renamed from: a, reason: collision with root package name */
    public final long f8237a;

    /* renamed from: b, reason: collision with root package name */
    public final int f8238b;

    /* renamed from: c, reason: collision with root package name */
    public final Uri f8239c;

    public C0605C(int i6, long j6, Uri uri) {
        this.f8237a = j6;
        this.f8238b = i6;
        this.f8239c = uri;
    }

    public static Z a(Uri uri, String str) {
        E2.r.d(4, "initialCapacity");
        Object[] objArr = new Object[4];
        String str2 = V.C.f3053a;
        int i6 = -1;
        String[] split = str.split(",", -1);
        int length = split.length;
        int i7 = 0;
        int i8 = 0;
        while (i7 < length) {
            String str3 = split[i7];
            String[] split2 = str3.split(";", i6);
            int length2 = split2.length;
            int i9 = i6;
            int i10 = i7;
            long j6 = -9223372036854775807L;
            int i11 = 0;
            Uri uri2 = null;
            while (i11 < length2) {
                String str4 = split2[i11];
                try {
                    String[] split3 = str4.split("=", 2);
                    String str5 = split3[0];
                    String str6 = split3[1];
                    int hashCode = str5.hashCode();
                    String[] strArr = split;
                    if (hashCode != 113759) {
                        if (hashCode != 116079) {
                            if (hashCode == 1524180539 && str5.equals("rtptime")) {
                                j6 = Long.parseLong(str6);
                                i11++;
                                split = strArr;
                            }
                            throw S.G.b(str5, null);
                        }
                        if (str5.equals("url")) {
                            uri2 = b(uri, str6);
                            i11++;
                            split = strArr;
                        } else {
                            throw S.G.b(str5, null);
                        }
                    } else if (str5.equals("seq")) {
                        i9 = Integer.parseInt(str6);
                        i11++;
                        split = strArr;
                    } else {
                        throw S.G.b(str5, null);
                    }
                } catch (Exception e) {
                    throw S.G.b(str4, e);
                }
                throw S.G.b(str4, e);
            }
            String[] strArr2 = split;
            if (uri2 != null && uri2.getScheme() != null) {
                i6 = -1;
                if (i9 != -1 || j6 != -9223372036854775807L) {
                    C0605C c0605c = new C0605C(i9, j6, uri2);
                    int i12 = i8 + 1;
                    int e6 = E2.C.e(objArr.length, i12);
                    if (e6 > objArr.length) {
                        objArr = Arrays.copyOf(objArr, e6);
                    }
                    objArr[i8] = c0605c;
                    i8 = i12;
                    split = strArr2;
                    i7 = i10 + 1;
                }
            }
            throw S.G.b(str3, null);
        }
        return E2.I.s(i8, objArr);
    }

    public static Uri b(Uri uri, String str) {
        String scheme = uri.getScheme();
        scheme.getClass();
        AbstractC0133a.c(scheme.equals("rtsp"));
        Uri parse = Uri.parse(str);
        if (parse.isAbsolute()) {
            return parse;
        }
        Uri parse2 = Uri.parse("rtsp://" + str);
        String uri2 = uri.toString();
        String host = parse2.getHost();
        host.getClass();
        if (host.equals(uri.getHost())) {
            return parse2;
        }
        if (uri2.endsWith("/")) {
            return AbstractC0133a.y(uri2, str);
        }
        return AbstractC0133a.y(uri2.concat("/"), str);
    }
}
