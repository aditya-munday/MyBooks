package l0;

import android.os.Handler;
import android.os.HandlerThread;
import java.io.Closeable;
import java.io.OutputStream;
import java.util.Objects;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* loaded from: classes.dex */
public final class x implements Closeable {
    public final OutputStream o;

    /* renamed from: p, reason: collision with root package name */
    public final HandlerThread f8396p;

    /* renamed from: q, reason: collision with root package name */
    public final Handler f8397q;

    public x(y yVar, OutputStream outputStream) {
        this.o = outputStream;
        HandlerThread handlerThread = new HandlerThread("ExoPlayer:RtspMessageChannel:Sender");
        this.f8396p = handlerThread;
        handlerThread.start();
        this.f8397q = new Handler(handlerThread.getLooper());
    }

    @Override // java.io.Closeable, java.lang.AutoCloseable
    public final void close() {
        HandlerThread handlerThread = this.f8396p;
        Objects.requireNonNull(handlerThread);
        this.f8397q.post(new G4.d(handlerThread, 18));
        try {
            handlerThread.join();
        } catch (InterruptedException unused) {
            handlerThread.interrupt();
        }
    }
}
