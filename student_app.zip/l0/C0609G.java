package l0;

import C4.AbstractC0034i;
import V.AbstractC0133a;
import android.net.Uri;
import java.util.Arrays;
import java.util.Locale;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.TimeUnit;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* renamed from: l0.G, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0609G extends X.c implements InterfaceC0616e {

    /* renamed from: s, reason: collision with root package name */
    public final LinkedBlockingQueue f8266s;

    /* renamed from: t, reason: collision with root package name */
    public final long f8267t;

    /* renamed from: u, reason: collision with root package name */
    public byte[] f8268u;

    /* renamed from: v, reason: collision with root package name */
    public int f8269v;

    public C0609G() {
        super(true);
        this.f8267t = 8000L;
        this.f8266s = new LinkedBlockingQueue();
        this.f8268u = new byte[0];
        this.f8269v = -1;
    }

    @Override // X.h
    public final long B(X.k kVar) {
        this.f8269v = kVar.f3579a.getPort();
        return -1L;
    }

    @Override // l0.InterfaceC0616e
    public final String a() {
        boolean z6;
        if (this.f8269v != -1) {
            z6 = true;
        } else {
            z6 = false;
        }
        AbstractC0133a.i(z6);
        int i6 = this.f8269v;
        int i7 = this.f8269v + 1;
        String str = V.C.f3053a;
        Locale locale = Locale.US;
        return AbstractC0034i.h(i6, i7, "RTP/AVP/TCP;unicast;interleaved=", "-");
    }

    @Override // l0.InterfaceC0616e
    public final int h() {
        return this.f8269v;
    }

    @Override // S.InterfaceC0116i
    public final int read(byte[] bArr, int i6, int i7) {
        if (i7 == 0) {
            return 0;
        }
        int min = Math.min(i7, this.f8268u.length);
        System.arraycopy(this.f8268u, 0, bArr, i6, min);
        byte[] bArr2 = this.f8268u;
        this.f8268u = Arrays.copyOfRange(bArr2, min, bArr2.length);
        if (min == i7) {
            return min;
        }
        try {
            byte[] bArr3 = (byte[]) this.f8266s.poll(this.f8267t, TimeUnit.MILLISECONDS);
            if (bArr3 == null) {
                return -1;
            }
            int min2 = Math.min(i7 - min, bArr3.length);
            System.arraycopy(bArr3, 0, bArr, i6 + min, min2);
            if (min2 < bArr3.length) {
                this.f8268u = Arrays.copyOfRange(bArr3, min2, bArr3.length);
            }
            return min + min2;
        } catch (InterruptedException unused) {
            Thread.currentThread().interrupt();
            return -1;
        }
    }

    @Override // l0.InterfaceC0616e
    public final boolean s() {
        return false;
    }

    @Override // X.h
    public final Uri v() {
        return null;
    }

    @Override // l0.InterfaceC0616e
    public final C0609G C() {
        return this;
    }

    @Override // X.h
    public final void close() {
    }
}
