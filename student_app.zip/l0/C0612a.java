package l0;

import E2.e0;
import V.AbstractC0133a;
import androidx.datastore.preferences.protobuf.AbstractC0227o;
import java.util.HashMap;
import java.util.Locale;
import org.apache.tika.utils.StringUtils;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* renamed from: l0.a, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0612a {

    /* renamed from: a, reason: collision with root package name */
    public final String f8271a;

    /* renamed from: b, reason: collision with root package name */
    public final int f8272b;

    /* renamed from: c, reason: collision with root package name */
    public final String f8273c;

    /* renamed from: d, reason: collision with root package name */
    public final int f8274d;
    public final HashMap e = new HashMap();

    /* renamed from: f, reason: collision with root package name */
    public int f8275f = -1;

    /* renamed from: g, reason: collision with root package name */
    public String f8276g;

    /* renamed from: h, reason: collision with root package name */
    public String f8277h;

    /* renamed from: i, reason: collision with root package name */
    public String f8278i;

    public C0612a(int i6, int i7, String str, String str2) {
        this.f8271a = str;
        this.f8272b = i6;
        this.f8273c = str2;
        this.f8274d = i7;
    }

    public static String b(int i6, int i7, int i8, String str) {
        String str2 = V.C.f3053a;
        Locale locale = Locale.US;
        return i6 + StringUtils.SPACE + str + "/" + i7 + "/" + i8;
    }

    public final C0614c a() {
        boolean z6;
        String b6;
        C0613b a6;
        HashMap hashMap = this.e;
        try {
            if (hashMap.containsKey("rtpmap")) {
                String str = (String) hashMap.get("rtpmap");
                String str2 = V.C.f3053a;
                a6 = C0613b.a(str);
            } else {
                int i6 = this.f8274d;
                if (i6 < 96) {
                    z6 = true;
                } else {
                    z6 = false;
                }
                AbstractC0133a.c(z6);
                if (i6 != 0) {
                    if (i6 != 8) {
                        if (i6 != 10) {
                            if (i6 == 11) {
                                b6 = b(11, 44100, 1, "L16");
                            } else {
                                throw new IllegalStateException(AbstractC0227o.d(i6, "Unsupported static paylod type "));
                            }
                        } else {
                            b6 = b(10, 44100, 2, "L16");
                        }
                    } else {
                        b6 = b(8, 8000, 1, "PCMA");
                    }
                } else {
                    b6 = b(0, 8000, 1, "PCMU");
                }
                a6 = C0613b.a(b6);
            }
            return new C0614c(this, e0.a(hashMap), a6);
        } catch (S.G e) {
            throw new IllegalStateException(e);
        }
    }
}
