package l0;

import V.AbstractC0133a;
import java.util.regex.Pattern;
import org.apache.tika.utils.StringUtils;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* renamed from: l0.b, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0613b {

    /* renamed from: a, reason: collision with root package name */
    public final int f8279a;

    /* renamed from: b, reason: collision with root package name */
    public final String f8280b;

    /* renamed from: c, reason: collision with root package name */
    public final int f8281c;

    /* renamed from: d, reason: collision with root package name */
    public final int f8282d;

    public C0613b(int i6, int i7, int i8, String str) {
        this.f8279a = i6;
        this.f8280b = str;
        this.f8281c = i7;
        this.f8282d = i8;
    }

    public static C0613b a(String str) {
        boolean z6;
        boolean z7;
        String str2 = V.C.f3053a;
        String[] split = str.split(StringUtils.SPACE, 2);
        if (split.length == 2) {
            z6 = true;
        } else {
            z6 = false;
        }
        AbstractC0133a.c(z6);
        String str3 = split[0];
        Pattern pattern = z.f8404a;
        try {
            int parseInt = Integer.parseInt(str3);
            int i6 = -1;
            String[] split2 = split[1].trim().split("/", -1);
            if (split2.length >= 2) {
                z7 = true;
            } else {
                z7 = false;
            }
            AbstractC0133a.c(z7);
            String str4 = split2[1];
            try {
                int parseInt2 = Integer.parseInt(str4);
                if (split2.length == 3) {
                    String str5 = split2[2];
                    try {
                        i6 = Integer.parseInt(str5);
                    } catch (NumberFormatException e) {
                        throw S.G.b(str5, e);
                    }
                }
                return new C0613b(parseInt, parseInt2, i6, split2[0]);
            } catch (NumberFormatException e6) {
                throw S.G.b(str4, e6);
            }
        } catch (NumberFormatException e7) {
            throw S.G.b(str3, e7);
        }
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj != null && C0613b.class == obj.getClass()) {
            C0613b c0613b = (C0613b) obj;
            if (this.f8279a == c0613b.f8279a && this.f8280b.equals(c0613b.f8280b) && this.f8281c == c0613b.f8281c && this.f8282d == c0613b.f8282d) {
                return true;
            }
        }
        return false;
    }

    public final int hashCode() {
        return ((((this.f8280b.hashCode() + ((217 + this.f8279a) * 31)) * 31) + this.f8281c) * 31) + this.f8282d;
    }
}
