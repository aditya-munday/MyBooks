package l0;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* renamed from: l0.d, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public interface InterfaceC0615d {
    InterfaceC0616e c(int i6);

    default InterfaceC0615d d() {
        return null;
    }
}
