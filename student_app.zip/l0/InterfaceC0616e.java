package l0;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* renamed from: l0.e, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public interface InterfaceC0616e extends X.h {
    C0609G C();

    String a();

    int h();

    boolean s();
}
