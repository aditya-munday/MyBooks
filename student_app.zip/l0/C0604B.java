package l0;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* renamed from: l0.B, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0604B {

    /* renamed from: c, reason: collision with root package name */
    public static final C0604B f8233c = new C0604B(0, -9223372036854775807L);

    /* renamed from: d, reason: collision with root package name */
    public static final Pattern f8234d = Pattern.compile("npt[:=]([.\\d]+|now)\\s?-\\s?([.\\d]+)?");

    /* renamed from: a, reason: collision with root package name */
    public final long f8235a;

    /* renamed from: b, reason: collision with root package name */
    public final long f8236b;

    public C0604B(long j6, long j7) {
        this.f8235a = j6;
        this.f8236b = j7;
    }

    public static C0604B a(String str) {
        long parseFloat;
        long parseFloat2;
        Matcher matcher = f8234d.matcher(str);
        boolean matches = matcher.matches();
        Pattern pattern = z.f8404a;
        if (matches) {
            String group = matcher.group(1);
            if (group != null) {
                String str2 = V.C.f3053a;
                if (group.equals("now")) {
                    parseFloat = 0;
                } else {
                    parseFloat = Float.parseFloat(group) * 1000.0f;
                }
                String group2 = matcher.group(2);
                if (group2 != null) {
                    try {
                        parseFloat2 = Float.parseFloat(group2) * 1000.0f;
                        if (parseFloat2 < parseFloat) {
                            throw S.G.b(str, null);
                        }
                    } catch (NumberFormatException e) {
                        throw S.G.b(group2, e);
                    }
                } else {
                    parseFloat2 = -9223372036854775807L;
                }
                return new C0604B(parseFloat, parseFloat2);
            }
            throw S.G.b(str, null);
        }
        throw S.G.b(str, null);
    }
}
