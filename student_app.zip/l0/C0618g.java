package l0;

import V.AbstractC0133a;
import android.os.SystemClock;
import java.util.TreeSet;
import m0.C0643a;
import m0.C0644b;
import m0.C0645c;
import m0.C0646d;
import org.apache.tika.fork.ContentHandlerProxy;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* renamed from: l0.g, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0618g implements x0.o {

    /* renamed from: a, reason: collision with root package name */
    public final m0.i f8302a;

    /* renamed from: b, reason: collision with root package name */
    public final V.v f8303b;

    /* renamed from: c, reason: collision with root package name */
    public final V.v f8304c;

    /* renamed from: d, reason: collision with root package name */
    public final int f8305d;
    public final Object e;

    /* renamed from: f, reason: collision with root package name */
    public final L4.b f8306f;

    /* renamed from: g, reason: collision with root package name */
    public x0.q f8307g;

    /* renamed from: h, reason: collision with root package name */
    public boolean f8308h;

    /* renamed from: i, reason: collision with root package name */
    public volatile long f8309i;

    /* renamed from: j, reason: collision with root package name */
    public volatile int f8310j;

    /* renamed from: k, reason: collision with root package name */
    public boolean f8311k;

    /* renamed from: l, reason: collision with root package name */
    public long f8312l;

    /* renamed from: m, reason: collision with root package name */
    public long f8313m;

    /* JADX WARN: Can't fix incorrect switch cases order, some code will duplicate */
    public C0618g(C0622k c0622k, int i6) {
        char c6;
        m0.i c0646d;
        m0.i iVar;
        this.f8305d = i6;
        String str = c0622k.f8329c.f2626n;
        str.getClass();
        switch (str.hashCode()) {
            case -1664118616:
                if (str.equals("video/3gpp")) {
                    c6 = 0;
                    break;
                }
                c6 = 65535;
                break;
            case -1662541442:
                if (str.equals("video/hevc")) {
                    c6 = 1;
                    break;
                }
                c6 = 65535;
                break;
            case -1606874997:
                if (str.equals("audio/amr-wb")) {
                    c6 = 2;
                    break;
                }
                c6 = 65535;
                break;
            case -53558318:
                if (str.equals("audio/mp4a-latm")) {
                    c6 = 3;
                    break;
                }
                c6 = 65535;
                break;
            case 187078296:
                if (str.equals("audio/ac3")) {
                    c6 = 4;
                    break;
                }
                c6 = 65535;
                break;
            case 187094639:
                if (str.equals("audio/raw")) {
                    c6 = 5;
                    break;
                }
                c6 = 65535;
                break;
            case 1187890754:
                if (str.equals("video/mp4v-es")) {
                    c6 = 6;
                    break;
                }
                c6 = 65535;
                break;
            case 1331836730:
                if (str.equals("video/avc")) {
                    c6 = 7;
                    break;
                }
                c6 = 65535;
                break;
            case 1503095341:
                if (str.equals("audio/3gpp")) {
                    c6 = '\b';
                    break;
                }
                c6 = 65535;
                break;
            case 1504891608:
                if (str.equals("audio/opus")) {
                    c6 = '\t';
                    break;
                }
                c6 = 65535;
                break;
            case 1599127256:
                if (str.equals("video/x-vnd.on2.vp8")) {
                    c6 = '\n';
                    break;
                }
                c6 = 65535;
                break;
            case 1599127257:
                if (str.equals("video/x-vnd.on2.vp9")) {
                    c6 = 11;
                    break;
                }
                c6 = 65535;
                break;
            case 1903231877:
                if (str.equals("audio/g711-alaw")) {
                    c6 = '\f';
                    break;
                }
                c6 = 65535;
                break;
            case 1903589369:
                if (str.equals("audio/g711-mlaw")) {
                    c6 = '\r';
                    break;
                }
                c6 = 65535;
                break;
            default:
                c6 = 65535;
                break;
        }
        switch (c6) {
            case 0:
                c0646d = new C0646d(c0622k, 0);
                iVar = c0646d;
                break;
            case 1:
                c0646d = new m0.e(c0622k, 1);
                iVar = c0646d;
                break;
            case 2:
            case '\b':
                c0646d = new C0645c(c0622k);
                iVar = c0646d;
                break;
            case 3:
                if (c0622k.e.equals("MP4A-LATM")) {
                    c0646d = new m0.f(c0622k);
                } else {
                    c0646d = new C0643a(c0622k);
                }
                iVar = c0646d;
                break;
            case 4:
                c0646d = new C0644b(c0622k);
                iVar = c0646d;
                break;
            case 5:
            case '\f':
            case '\r':
                c0646d = new l2.r(c0622k);
                iVar = c0646d;
                break;
            case 6:
                c0646d = new m0.g(c0622k);
                iVar = c0646d;
                break;
            case 7:
                c0646d = new m0.e(c0622k, 0);
                iVar = c0646d;
                break;
            case ContentHandlerProxy.PROCESSING_INSTRUCTION /* 9 */:
                c0646d = new m0.h(c0622k);
                iVar = c0646d;
                break;
            case '\n':
                c0646d = new m0.j(c0622k);
                iVar = c0646d;
                break;
            case 11:
                c0646d = new C0646d(c0622k, 1);
                iVar = c0646d;
                break;
            default:
                iVar = null;
                break;
        }
        iVar.getClass();
        this.f8302a = iVar;
        this.f8303b = new V.v(65507);
        this.f8304c = new V.v();
        this.e = new Object();
        this.f8306f = new L4.b();
        this.f8309i = -9223372036854775807L;
        this.f8310j = -1;
        this.f8312l = -9223372036854775807L;
        this.f8313m = -9223372036854775807L;
    }

    @Override // x0.o
    public final void a(long j6, long j7) {
        synchronized (this.e) {
            try {
                if (!this.f8311k) {
                    this.f8311k = true;
                }
                this.f8312l = j6;
                this.f8313m = j7;
            } catch (Throwable th) {
                throw th;
            }
        }
    }

    @Override // x0.o
    public final boolean f(x0.p pVar) {
        throw new UnsupportedOperationException("RTP packets are transmitted in a packet stream do not support sniffing.");
    }

    /* JADX WARN: Removed duplicated region for block: B:13:0x00cc  */
    /* JADX WARN: Type inference failed for: r0v5, types: [java.lang.Object, l0.h] */
    @Override // x0.o
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final int h(x0.p pVar, S.r rVar) {
        boolean z6;
        boolean z7;
        boolean z8;
        boolean z9;
        this.f8307g.getClass();
        int read = pVar.read(this.f8303b.f3120a, 0, 65507);
        if (read == -1) {
            return -1;
        }
        if (read == 0) {
            return 0;
        }
        this.f8303b.J(0);
        this.f8303b.I(read);
        V.v vVar = this.f8303b;
        byte[] bArr = C0620i.f8319g;
        C0620i c0620i = null;
        if (vVar.a() >= 12) {
            int x6 = vVar.x();
            byte b6 = (byte) (x6 >> 6);
            byte b7 = (byte) (x6 & 15);
            if (((x6 >> 4) & 1) == 1) {
                z6 = true;
            } else {
                z6 = false;
            }
            if (b6 == 2) {
                int x7 = vVar.x();
                if (((x7 >> 7) & 1) == 1) {
                    z7 = true;
                } else {
                    z7 = false;
                }
                byte b8 = (byte) (x7 & 127);
                int D5 = vVar.D();
                long z10 = vVar.z();
                int k6 = vVar.k();
                if (b7 > 0) {
                    byte[] bArr2 = new byte[b7 * 4];
                    z8 = true;
                    for (int i6 = 0; i6 < b7; i6++) {
                        vVar.i(bArr2, i6 * 4, 4);
                    }
                } else {
                    z8 = true;
                }
                if (z6) {
                    vVar.K(2);
                    short u6 = vVar.u();
                    if (u6 != 0) {
                        vVar.K(u6 * 4);
                    }
                }
                byte[] bArr3 = new byte[vVar.a()];
                vVar.i(bArr3, 0, vVar.a());
                ?? obj = new Object();
                obj.f8318f = bArr;
                obj.f8314a = z7;
                obj.f8315b = b8;
                if (D5 >= 0 && D5 <= 65535) {
                    z9 = z8;
                } else {
                    z9 = false;
                }
                AbstractC0133a.c(z9);
                obj.f8316c = 65535 & D5;
                obj.f8317d = z10;
                obj.e = k6;
                obj.f8318f = bArr3;
                c0620i = new C0620i(obj);
                if (c0620i != null) {
                    long elapsedRealtime = SystemClock.elapsedRealtime();
                    long j6 = elapsedRealtime - 30;
                    L4.b bVar = this.f8306f;
                    synchronized (bVar) {
                        if (((TreeSet) bVar.f1623d).size() < 5000) {
                            int i7 = c0620i.f8322c;
                            if (!bVar.f1622c) {
                                bVar.d();
                                bVar.f1621b = Q5.a.x(i7 - 1);
                                bVar.f1622c = z8;
                                bVar.a(new C0621j(c0620i, elapsedRealtime));
                            } else if (Math.abs(L4.b.b(i7, C0620i.a(bVar.f1620a))) < 1000) {
                                if (L4.b.b(i7, bVar.f1621b) > 0) {
                                    bVar.a(new C0621j(c0620i, elapsedRealtime));
                                }
                            } else {
                                bVar.f1621b = Q5.a.x(i7 - 1);
                                ((TreeSet) bVar.f1623d).clear();
                                bVar.a(new C0621j(c0620i, elapsedRealtime));
                            }
                        } else {
                            throw new IllegalStateException("Queue size limit of 5000 reached.");
                        }
                    }
                    C0620i c6 = this.f8306f.c(j6);
                    if (c6 != null) {
                        if (!this.f8308h) {
                            if (this.f8309i == -9223372036854775807L) {
                                this.f8309i = c6.f8323d;
                            }
                            if (this.f8310j == -1) {
                                this.f8310j = c6.f8322c;
                            }
                            this.f8302a.b(this.f8309i);
                            this.f8308h = true;
                        }
                        synchronized (this.e) {
                            try {
                                if (this.f8311k) {
                                    if (this.f8312l != -9223372036854775807L && this.f8313m != -9223372036854775807L) {
                                        this.f8306f.d();
                                        this.f8302a.a(this.f8312l, this.f8313m);
                                        this.f8311k = false;
                                        this.f8312l = -9223372036854775807L;
                                        this.f8313m = -9223372036854775807L;
                                    }
                                } else {
                                    do {
                                        V.v vVar2 = this.f8304c;
                                        byte[] bArr4 = c6.f8324f;
                                        vVar2.getClass();
                                        vVar2.H(bArr4, bArr4.length);
                                        this.f8302a.c(this.f8304c, c6.f8323d, c6.f8322c, c6.f8320a);
                                        c6 = this.f8306f.c(j6);
                                    } while (c6 != null);
                                }
                            } catch (Throwable th) {
                                throw th;
                            }
                        }
                        return 0;
                    }
                }
                return 0;
            }
        }
        z8 = true;
        if (c0620i != null) {
        }
        return 0;
    }

    @Override // x0.o
    public final void k(x0.q qVar) {
        this.f8302a.d(qVar, this.f8305d);
        qVar.g();
        qVar.o(new x0.s(-9223372036854775807L));
        this.f8307g = qVar;
    }

    @Override // x0.o
    public final void release() {
    }
}
