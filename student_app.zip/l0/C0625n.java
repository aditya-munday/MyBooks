package l0;

import E2.C0074t;
import E2.C0076v;
import E2.J;
import E2.Z;
import java.util.AbstractCollection;
import java.util.Collection;
import java.util.Iterator;
import java.util.Map;
import org.apache.tika.metadata.HttpHeaders;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* renamed from: l0.n, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0625n {

    /* renamed from: a, reason: collision with root package name */
    public final J f8351a;

    static {
        new C0625n(new Z4.s(15));
    }

    public C0625n(Z4.s sVar) {
        J j6;
        C0076v c0076v = (C0076v) ((A1.l) sVar.o).f60p;
        if (c0076v == null) {
            j6 = E2.B.f689s;
        } else {
            Collection entrySet = c0076v.entrySet();
            if (((AbstractCollection) entrySet).isEmpty()) {
                j6 = E2.B.f689s;
            } else {
                C0074t c0074t = (C0074t) entrySet;
                D2.i iVar = new D2.i(c0074t.f780p.size(), 1);
                Iterator it = c0074t.iterator();
                int i6 = 0;
                while (it.hasNext()) {
                    Map.Entry entry = (Map.Entry) it.next();
                    Object key = entry.getKey();
                    Z f6 = ((E2.F) entry.getValue()).f();
                    iVar.h(key, f6);
                    i6 += f6.f723r;
                }
                j6 = new J(iVar.e(), i6);
            }
        }
        this.f8351a = j6;
    }

    public static String a(String str) {
        if (Q5.a.o(str, "Accept")) {
            return "Accept";
        }
        if (Q5.a.o(str, "Allow")) {
            return "Allow";
        }
        if (Q5.a.o(str, "Authorization")) {
            return "Authorization";
        }
        if (Q5.a.o(str, "Bandwidth")) {
            return "Bandwidth";
        }
        if (Q5.a.o(str, "Blocksize")) {
            return "Blocksize";
        }
        if (Q5.a.o(str, "Cache-Control")) {
            return "Cache-Control";
        }
        if (Q5.a.o(str, "Connection")) {
            return "Connection";
        }
        if (Q5.a.o(str, "Content-Base")) {
            return "Content-Base";
        }
        if (Q5.a.o(str, HttpHeaders.CONTENT_ENCODING)) {
            return HttpHeaders.CONTENT_ENCODING;
        }
        if (Q5.a.o(str, HttpHeaders.CONTENT_LANGUAGE)) {
            return HttpHeaders.CONTENT_LANGUAGE;
        }
        if (Q5.a.o(str, HttpHeaders.CONTENT_LENGTH)) {
            return HttpHeaders.CONTENT_LENGTH;
        }
        if (Q5.a.o(str, HttpHeaders.CONTENT_LOCATION)) {
            return HttpHeaders.CONTENT_LOCATION;
        }
        if (Q5.a.o(str, HttpHeaders.CONTENT_TYPE)) {
            return HttpHeaders.CONTENT_TYPE;
        }
        if (Q5.a.o(str, "CSeq")) {
            return "CSeq";
        }
        if (Q5.a.o(str, "Date")) {
            return "Date";
        }
        if (Q5.a.o(str, "Expires")) {
            return "Expires";
        }
        if (Q5.a.o(str, HttpHeaders.LOCATION)) {
            return HttpHeaders.LOCATION;
        }
        if (Q5.a.o(str, "Proxy-Authenticate")) {
            return "Proxy-Authenticate";
        }
        if (Q5.a.o(str, "Proxy-Require")) {
            return "Proxy-Require";
        }
        if (Q5.a.o(str, "Public")) {
            return "Public";
        }
        if (Q5.a.o(str, "Range")) {
            return "Range";
        }
        if (Q5.a.o(str, "RTP-Info")) {
            return "RTP-Info";
        }
        if (Q5.a.o(str, "RTCP-Interval")) {
            return "RTCP-Interval";
        }
        if (Q5.a.o(str, "Scale")) {
            return "Scale";
        }
        if (Q5.a.o(str, "Session")) {
            return "Session";
        }
        if (Q5.a.o(str, "Speed")) {
            return "Speed";
        }
        if (Q5.a.o(str, "Supported")) {
            return "Supported";
        }
        if (Q5.a.o(str, "Timestamp")) {
            return "Timestamp";
        }
        if (Q5.a.o(str, "Transport")) {
            return "Transport";
        }
        if (Q5.a.o(str, "User-Agent")) {
            return "User-Agent";
        }
        if (Q5.a.o(str, "Via")) {
            return "Via";
        }
        if (Q5.a.o(str, "WWW-Authenticate")) {
            return "WWW-Authenticate";
        }
        return str;
    }

    public final String b(String str) {
        E2.I d6 = this.f8351a.d(a(str));
        if (d6.isEmpty()) {
            return null;
        }
        return (String) E2.r.j(d6);
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof C0625n)) {
            return false;
        }
        return this.f8351a.equals(((C0625n) obj).f8351a);
    }

    public final int hashCode() {
        return this.f8351a.hashCode();
    }
}
