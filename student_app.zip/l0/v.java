package l0;

import E2.Z;
import E2.e0;
import S.C0115h;
import S.C0122o;
import S.C0123p;
import V.AbstractC0133a;
import android.net.Uri;
import android.text.TextUtils;
import android.util.Base64;
import android.util.Pair;
import org.apache.tika.fork.ContentHandlerProxy;
import org.apache.tika.metadata.HttpHeaders;
import org.apache.tika.utils.StringUtils;
import x0.AbstractC0880b;
import x0.C0879a;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* loaded from: classes.dex */
public final class v {

    /* renamed from: a, reason: collision with root package name */
    public final C0622k f8391a;

    /* renamed from: b, reason: collision with root package name */
    public final Uri f8392b;

    /* JADX WARN: Can't fix incorrect switch cases order, some code will duplicate */
    /* JADX WARN: Code restructure failed: missing block: B:201:0x059f, code lost:
    
        if (r2.equals("audio/amr-wb") != false) goto L273;
     */
    /* JADX WARN: Failed to find 'out' block for switch in B:23:0x0220. Please report as an issue. */
    /* JADX WARN: Failed to find 'out' block for switch in B:8:0x0138. Please report as an issue. */
    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Removed duplicated region for block: B:126:0x0451  */
    /* JADX WARN: Removed duplicated region for block: B:141:0x0480  */
    /* JADX WARN: Removed duplicated region for block: B:142:0x048a  */
    /* JADX WARN: Removed duplicated region for block: B:15:0x018a  */
    /* JADX WARN: Removed duplicated region for block: B:200:0x0595  */
    /* JADX WARN: Removed duplicated region for block: B:202:0x05ce  */
    /* JADX WARN: Removed duplicated region for block: B:214:0x06ba  */
    /* JADX WARN: Removed duplicated region for block: B:217:0x023a  */
    /* JADX WARN: Removed duplicated region for block: B:218:0x01ba  */
    /* JADX WARN: Removed duplicated region for block: B:21:0x01b1  */
    /* JADX WARN: Removed duplicated region for block: B:231:0x01a4  */
    /* JADX WARN: Removed duplicated region for block: B:24:0x0224  */
    /* JADX WARN: Removed duplicated region for block: B:25:0x0229  */
    /* JADX WARN: Removed duplicated region for block: B:26:0x022e  */
    /* JADX WARN: Removed duplicated region for block: B:29:0x0240  */
    /* JADX WARN: Removed duplicated region for block: B:32:0x024d  */
    /* JADX WARN: Removed duplicated region for block: B:43:0x026a  */
    /* JADX WARN: Removed duplicated region for block: B:50:0x06d0  */
    /* JADX WARN: Removed duplicated region for block: B:53:0x06fe  */
    /* JADX WARN: Removed duplicated region for block: B:65:0x06d2  */
    /* JADX WARN: Removed duplicated region for block: B:67:0x0276  */
    /* JADX WARN: Removed duplicated region for block: B:77:0x0313  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public v(C0625n c0625n, C0614c c0614c, Uri uri) {
        char c6;
        String str;
        String str2;
        String str3;
        int i6;
        String str4;
        e0 e0Var;
        Object obj;
        Object obj2;
        boolean z6;
        e0 e;
        String str5;
        boolean z7;
        int i7;
        boolean z8;
        boolean z9;
        boolean z10;
        boolean z11;
        boolean z12;
        boolean z13;
        boolean z14;
        boolean z15;
        boolean z16;
        boolean z17;
        int i8;
        boolean z18;
        boolean z19;
        boolean z20;
        boolean z21;
        boolean z22;
        Uri parse;
        boolean z23;
        boolean z24;
        boolean z25;
        e0 e0Var2 = c0614c.f8290i;
        AbstractC0133a.b("missing attribute control", e0Var2.containsKey("control"));
        C0122o c0122o = new C0122o();
        int i9 = c0614c.e;
        C0613b c0613b = c0614c.f8291j;
        if (i9 > 0) {
            c0122o.f2582h = i9;
        }
        int i10 = c0613b.f8279a;
        String str6 = c0613b.f8280b;
        String N5 = Q5.a.N(str6);
        N5.getClass();
        switch (N5.hashCode()) {
            case -1922091719:
                if (N5.equals("MPEG4-GENERIC")) {
                    c6 = 0;
                    break;
                }
                c6 = 65535;
                break;
            case 2412:
                if (N5.equals("L8")) {
                    c6 = 1;
                    break;
                }
                c6 = 65535;
                break;
            case 64593:
                if (N5.equals("AC3")) {
                    c6 = 2;
                    break;
                }
                c6 = 65535;
                break;
            case 64934:
                if (N5.equals("AMR")) {
                    c6 = 3;
                    break;
                }
                c6 = 65535;
                break;
            case 74609:
                if (N5.equals("L16")) {
                    c6 = 4;
                    break;
                }
                c6 = 65535;
                break;
            case 85182:
                if (N5.equals("VP8")) {
                    c6 = 5;
                    break;
                }
                c6 = 65535;
                break;
            case 85183:
                if (N5.equals("VP9")) {
                    c6 = 6;
                    break;
                }
                c6 = 65535;
                break;
            case 2194728:
                if (N5.equals("H264")) {
                    c6 = 7;
                    break;
                }
                c6 = 65535;
                break;
            case 2194729:
                if (N5.equals("H265")) {
                    c6 = '\b';
                    break;
                }
                c6 = 65535;
                break;
            case 2433087:
                if (N5.equals("OPUS")) {
                    c6 = '\t';
                    break;
                }
                c6 = 65535;
                break;
            case 2450119:
                if (N5.equals("PCMA")) {
                    c6 = '\n';
                    break;
                }
                c6 = 65535;
                break;
            case 2450139:
                if (N5.equals("PCMU")) {
                    c6 = 11;
                    break;
                }
                c6 = 65535;
                break;
            case 1061166827:
                if (N5.equals("MP4A-LATM")) {
                    c6 = '\f';
                    break;
                }
                c6 = 65535;
                break;
            case 1934494802:
                if (N5.equals("AMR-WB")) {
                    c6 = '\r';
                    break;
                }
                c6 = 65535;
                break;
            case 1959269366:
                if (N5.equals("MP4V-ES")) {
                    c6 = 14;
                    break;
                }
                c6 = 65535;
                break;
            case 2137188397:
                if (N5.equals("H263-1998")) {
                    c6 = 15;
                    break;
                }
                c6 = 65535;
                break;
            case 2137209252:
                if (N5.equals("H263-2000")) {
                    c6 = 16;
                    break;
                }
                c6 = 65535;
                break;
            default:
                c6 = 65535;
                break;
        }
        char c7 = 1;
        switch (c6) {
            case 0:
            case '\f':
                str = str6;
                str2 = "audio/mp4a-latm";
                c0122o.f2587m = S.F.n(str2);
                int i11 = c0613b.f8281c;
                if (!"audio".equals(c0614c.f8283a)) {
                    int i12 = c0613b.f8282d;
                    if (i12 != -1) {
                        i6 = i12;
                        str3 = str2;
                    } else {
                        str3 = str2;
                        if (str3.equals("audio/ac3")) {
                            i6 = 6;
                        } else {
                            i6 = 1;
                        }
                    }
                    c0122o.f2568F = i11;
                    c0122o.f2567E = i6;
                } else {
                    str3 = str2;
                    i6 = -1;
                }
                str4 = (String) e0Var2.get("fmtp");
                if (str4 != null) {
                    e = e0.f744u;
                    e0Var = e0Var2;
                    obj2 = "audio/raw";
                    obj = "audio/ac3";
                } else {
                    String str7 = V.C.f3053a;
                    e0Var = e0Var2;
                    obj = "audio/ac3";
                    String[] split = str4.split(StringUtils.SPACE, 2);
                    obj2 = "audio/raw";
                    if (split.length == 2) {
                        z6 = true;
                    } else {
                        z6 = false;
                    }
                    AbstractC0133a.b(str4, z6);
                    String[] split2 = split[1].split(";\\s?", 0);
                    char c8 = 0;
                    D2.i iVar = new D2.i(4, 1);
                    int length = split2.length;
                    int i13 = 0;
                    while (i13 < length) {
                        String[] strArr = split2;
                        String[] split3 = strArr[i13].split("=", 2);
                        iVar.h(split3[c8], split3[c7]);
                        i13++;
                        split2 = strArr;
                        length = length;
                        c8 = 0;
                        c7 = 1;
                    }
                    e = iVar.e();
                }
                switch (str3.hashCode()) {
                    case -1664118616:
                        str5 = str;
                        z7 = false;
                        i7 = 1;
                        if (str3.equals("video/3gpp")) {
                            c0122o.f2593t = 352;
                            c0122o.f2594u = 288;
                        }
                        if (i11 > 0) {
                            z22 = i7;
                        } else {
                            z22 = z7;
                        }
                        AbstractC0133a.c(z22);
                        this.f8391a = new C0622k(new C0123p(c0122o), i10, i11, e, str5);
                        String str8 = (String) e0Var.get("control");
                        parse = Uri.parse(str8);
                        if (!parse.isAbsolute()) {
                            if (!TextUtils.isEmpty(c0625n.b("Content-Base"))) {
                                parse = Uri.parse(c0625n.b("Content-Base"));
                            } else if (!TextUtils.isEmpty(c0625n.b(HttpHeaders.CONTENT_LOCATION))) {
                                parse = Uri.parse(c0625n.b(HttpHeaders.CONTENT_LOCATION));
                            } else {
                                parse = uri;
                            }
                            if (!str8.equals("*")) {
                                parse = parse.buildUpon().appendEncodedPath(str8).build();
                            }
                        }
                        this.f8392b = parse;
                        return;
                    case -1662541442:
                        str5 = str;
                        z7 = false;
                        i7 = 1;
                        if (str3.equals("video/hevc")) {
                            AbstractC0133a.b("missing attribute fmtp", !e.isEmpty());
                            if (e.containsKey("sprop-max-don-diff")) {
                                String str9 = (String) e.get("sprop-max-don-diff");
                                str9.getClass();
                                int parseInt = Integer.parseInt(str9);
                                if (parseInt == 0) {
                                    z8 = true;
                                } else {
                                    z8 = false;
                                }
                                AbstractC0133a.b("non-zero sprop-max-don-diff " + parseInt + " is not supported", z8);
                            }
                            AbstractC0133a.b("missing sprop-vps parameter", e.containsKey("sprop-vps"));
                            String str10 = (String) e.get("sprop-vps");
                            str10.getClass();
                            AbstractC0133a.b("missing sprop-sps parameter", e.containsKey("sprop-sps"));
                            String str11 = (String) e.get("sprop-sps");
                            str11.getClass();
                            AbstractC0133a.b("missing sprop-pps parameter", e.containsKey("sprop-pps"));
                            String str12 = (String) e.get("sprop-pps");
                            str12.getClass();
                            Object[] objArr = {a(str10), a(str11), a(str12)};
                            E2.r.b(3, objArr);
                            Z s3 = E2.I.s(3, objArr);
                            c0122o.f2589p = s3;
                            i7 = 1;
                            byte[] bArr = (byte[]) s3.get(1);
                            W.m h6 = W.q.h(bArr, 4, bArr.length, null);
                            c0122o.f2598z = h6.f3394i;
                            c0122o.f2594u = h6.f3391f;
                            c0122o.f2593t = h6.e;
                            c0122o.f2565C = new C0115h(h6.f3396k, h6.f3397l, h6.f3398m, null, h6.f3389c + 8, h6.f3390d + 8);
                            W.j jVar = h6.f3388b;
                            if (jVar != null) {
                                c0122o.f2584j = V.d.b(jVar.f3376a, jVar.f3377b, jVar.f3378c, jVar.f3379d, jVar.e, jVar.f3380f);
                            }
                        }
                        if (i11 > 0) {
                        }
                        AbstractC0133a.c(z22);
                        this.f8391a = new C0622k(new C0123p(c0122o), i10, i11, e, str5);
                        String str82 = (String) e0Var.get("control");
                        parse = Uri.parse(str82);
                        if (!parse.isAbsolute()) {
                        }
                        this.f8392b = parse;
                        return;
                    case -1606874997:
                        str5 = str;
                        z7 = false;
                        i7 = 1;
                        break;
                    case -53558318:
                        str5 = str;
                        if (str3.equals("audio/mp4a-latm")) {
                            if (i6 != -1) {
                                z9 = true;
                            } else {
                                z9 = false;
                            }
                            AbstractC0133a.c(z9);
                            AbstractC0133a.b("missing attribute fmtp", !e.isEmpty());
                            if (str5.equals("MP4A-LATM")) {
                                if (e.containsKey("cpresent") && ((String) e.get("cpresent")).equals("0")) {
                                    z11 = true;
                                } else {
                                    z11 = false;
                                }
                                AbstractC0133a.b("Only supports cpresent=0 in AAC audio.", z11);
                                String str13 = (String) e.get("config");
                                if (str13 != null) {
                                    if (str13.length() % 2 == 0) {
                                        z12 = true;
                                    } else {
                                        z12 = false;
                                    }
                                    AbstractC0133a.b("Malformat MPEG4 config: ".concat(str13), z12);
                                    byte[] u6 = V.C.u(str13);
                                    V.u uVar = new V.u(u6, u6.length);
                                    if (uVar.i(1) == 0) {
                                        z13 = true;
                                    } else {
                                        z13 = false;
                                    }
                                    AbstractC0133a.b("Only supports audio mux version 0.", z13);
                                    if (uVar.i(1) == 1) {
                                        z14 = true;
                                    } else {
                                        z14 = false;
                                    }
                                    AbstractC0133a.b("Only supports allStreamsSameTimeFraming.", z14);
                                    uVar.t(6);
                                    if (uVar.i(4) == 0) {
                                        z15 = true;
                                    } else {
                                        z15 = false;
                                    }
                                    AbstractC0133a.b("Only supports one program.", z15);
                                    if (uVar.i(3) == 0) {
                                        z16 = true;
                                    } else {
                                        z16 = false;
                                    }
                                    AbstractC0133a.b("Only supports one numLayer.", z16);
                                    z7 = false;
                                    try {
                                        C0879a q6 = AbstractC0880b.q(uVar, false);
                                        c0122o.f2568F = q6.f10126b;
                                        c0122o.f2567E = q6.f10127c;
                                        c0122o.f2584j = q6.f10125a;
                                    } catch (S.G e6) {
                                        throw new IllegalArgumentException(e6);
                                    }
                                } else {
                                    throw new NullPointerException("AAC audio stream must include config fmtp parameter");
                                }
                            } else {
                                z7 = false;
                            }
                            String str14 = (String) e.get("profile-level-id");
                            if (str14 == null && str5.equals("MP4A-LATM")) {
                                str14 = "30";
                            }
                            if (str14 != null && !str14.isEmpty()) {
                                z10 = true;
                            } else {
                                z10 = z7;
                            }
                            AbstractC0133a.b("missing profile-level-id param", z10);
                            c0122o.f2584j = "mp4a.40." + str14;
                            c0122o.f2589p = E2.I.y(AbstractC0880b.a(i11, i6));
                            i7 = 1;
                            if (i11 > 0) {
                            }
                            AbstractC0133a.c(z22);
                            this.f8391a = new C0622k(new C0123p(c0122o), i10, i11, e, str5);
                            String str822 = (String) e0Var.get("control");
                            parse = Uri.parse(str822);
                            if (!parse.isAbsolute()) {
                            }
                            this.f8392b = parse;
                            return;
                        }
                        z7 = false;
                        i7 = 1;
                        if (i11 > 0) {
                        }
                        AbstractC0133a.c(z22);
                        this.f8391a = new C0622k(new C0123p(c0122o), i10, i11, e, str5);
                        String str8222 = (String) e0Var.get("control");
                        parse = Uri.parse(str8222);
                        if (!parse.isAbsolute()) {
                        }
                        this.f8392b = parse;
                        return;
                    case 187078296:
                        str5 = str;
                        str3.equals(obj);
                        z7 = false;
                        i7 = 1;
                        if (i11 > 0) {
                        }
                        AbstractC0133a.c(z22);
                        this.f8391a = new C0622k(new C0123p(c0122o), i10, i11, e, str5);
                        String str82222 = (String) e0Var.get("control");
                        parse = Uri.parse(str82222);
                        if (!parse.isAbsolute()) {
                        }
                        this.f8392b = parse;
                        return;
                    case 187094639:
                        if (str3.equals(obj2)) {
                            str5 = str;
                            if (!str5.equals("L8") && !str5.equals("L16")) {
                                z17 = false;
                            } else {
                                z17 = true;
                            }
                            AbstractC0133a.c(z17);
                            if (str5.equals("L8")) {
                                i8 = 3;
                            } else {
                                i8 = 268435456;
                            }
                            c0122o.f2569G = i8;
                            z7 = false;
                            i7 = 1;
                            if (i11 > 0) {
                            }
                            AbstractC0133a.c(z22);
                            this.f8391a = new C0622k(new C0123p(c0122o), i10, i11, e, str5);
                            String str822222 = (String) e0Var.get("control");
                            parse = Uri.parse(str822222);
                            if (!parse.isAbsolute()) {
                            }
                            this.f8392b = parse;
                            return;
                        }
                        str5 = str;
                        z7 = false;
                        i7 = 1;
                        if (i11 > 0) {
                        }
                        AbstractC0133a.c(z22);
                        this.f8391a = new C0622k(new C0123p(c0122o), i10, i11, e, str5);
                        String str8222222 = (String) e0Var.get("control");
                        parse = Uri.parse(str8222222);
                        if (!parse.isAbsolute()) {
                        }
                        this.f8392b = parse;
                        return;
                    case 1187890754:
                        if (str3.equals("video/mp4v-es")) {
                            AbstractC0133a.c(!e.isEmpty());
                            String str15 = (String) e.get("config");
                            if (str15 != null) {
                                byte[] u7 = V.C.u(str15);
                                c0122o.f2589p = E2.I.y(u7);
                                byte[] bArr2 = V.d.f3073a;
                                V.v vVar = new V.v(u7);
                                int i14 = 0;
                                while (true) {
                                    int i15 = i14 + 3;
                                    if (i15 < u7.length) {
                                        if (vVar.A() == 1 && (u7[i15] & 240) == 32) {
                                            z18 = true;
                                        } else {
                                            vVar.J(vVar.f3121b - 2);
                                            i14++;
                                        }
                                    } else {
                                        z18 = false;
                                    }
                                }
                                AbstractC0133a.b("Invalid input: VOL not found.", z18);
                                V.u uVar2 = new V.u(u7, u7.length);
                                uVar2.t((i14 + 4) * 8);
                                uVar2.t(1);
                                uVar2.t(8);
                                if (uVar2.h()) {
                                    uVar2.t(4);
                                    uVar2.t(3);
                                }
                                if (uVar2.i(4) == 15) {
                                    uVar2.t(8);
                                    uVar2.t(8);
                                }
                                if (uVar2.h()) {
                                    uVar2.t(2);
                                    uVar2.t(1);
                                    if (uVar2.h()) {
                                        uVar2.t(79);
                                    }
                                }
                                if (uVar2.i(2) == 0) {
                                    z19 = true;
                                } else {
                                    z19 = false;
                                }
                                AbstractC0133a.b("Only supports rectangular video object layer shape.", z19);
                                AbstractC0133a.c(uVar2.h());
                                int i16 = uVar2.i(16);
                                AbstractC0133a.c(uVar2.h());
                                if (uVar2.h()) {
                                    if (i16 > 0) {
                                        z20 = true;
                                    } else {
                                        z20 = false;
                                    }
                                    AbstractC0133a.c(z20);
                                    int i17 = 0;
                                    for (int i18 = i16 - 1; i18 > 0; i18 >>= 1) {
                                        i17++;
                                    }
                                    uVar2.t(i17);
                                }
                                AbstractC0133a.c(uVar2.h());
                                int i19 = uVar2.i(13);
                                AbstractC0133a.c(uVar2.h());
                                int i20 = uVar2.i(13);
                                AbstractC0133a.c(uVar2.h());
                                uVar2.t(1);
                                Pair create = Pair.create(Integer.valueOf(i19), Integer.valueOf(i20));
                                c0122o.f2593t = ((Integer) create.first).intValue();
                                c0122o.f2594u = ((Integer) create.second).intValue();
                            } else {
                                c0122o.f2593t = 352;
                                c0122o.f2594u = 288;
                            }
                            String str16 = (String) e.get("profile-level-id");
                            c0122o.f2584j = "mp4v.".concat(str16 == null ? "1" : str16);
                        }
                        str5 = str;
                        z7 = false;
                        i7 = 1;
                        if (i11 > 0) {
                        }
                        AbstractC0133a.c(z22);
                        this.f8391a = new C0622k(new C0123p(c0122o), i10, i11, e, str5);
                        String str82222222 = (String) e0Var.get("control");
                        parse = Uri.parse(str82222222);
                        if (!parse.isAbsolute()) {
                        }
                        this.f8392b = parse;
                        return;
                    case 1331836730:
                        if (str3.equals("video/avc")) {
                            AbstractC0133a.b("missing attribute fmtp", !e.isEmpty());
                            AbstractC0133a.b("missing sprop parameter", e.containsKey("sprop-parameter-sets"));
                            String str17 = (String) e.get("sprop-parameter-sets");
                            str17.getClass();
                            String str18 = V.C.f3053a;
                            String[] split4 = str17.split(",", -1);
                            if (split4.length == 2) {
                                z21 = true;
                            } else {
                                z21 = false;
                            }
                            AbstractC0133a.b("empty sprop value", z21);
                            Z z26 = E2.I.z(a(split4[0]), a(split4[1]));
                            c0122o.f2589p = z26;
                            byte[] bArr3 = (byte[]) z26.get(0);
                            W.p j6 = W.q.j(bArr3, 4, bArr3.length);
                            c0122o.f2598z = j6.f3409g;
                            c0122o.f2594u = j6.f3408f;
                            c0122o.f2593t = j6.e;
                            c0122o.f2565C = new C0115h(j6.f3417p, j6.f3418q, j6.f3419r, null, j6.f3410h + 8, j6.f3411i + 8);
                            String str19 = (String) e.get("profile-level-id");
                            if (str19 != null) {
                                c0122o.f2584j = "avc1.".concat(str19);
                            } else {
                                c0122o.f2584j = V.d.a(j6.f3404a, j6.f3405b, j6.f3406c);
                            }
                        }
                        str5 = str;
                        z7 = false;
                        i7 = 1;
                        if (i11 > 0) {
                        }
                        AbstractC0133a.c(z22);
                        this.f8391a = new C0622k(new C0123p(c0122o), i10, i11, e, str5);
                        String str822222222 = (String) e0Var.get("control");
                        parse = Uri.parse(str822222222);
                        if (!parse.isAbsolute()) {
                        }
                        this.f8392b = parse;
                        return;
                    case 1503095341:
                        if (str3.equals("audio/3gpp")) {
                            str5 = str;
                            z7 = false;
                            i7 = 1;
                            if (i6 == i7) {
                                z23 = i7;
                            } else {
                                z23 = z7;
                            }
                            AbstractC0133a.b("Multi channel AMR is not currently supported.", z23);
                            AbstractC0133a.b("fmtp parameters must include octet-align.", (e.isEmpty() ? 1 : 0) ^ i7);
                            AbstractC0133a.b("Only octet aligned mode is currently supported.", e.containsKey("octet-align"));
                            AbstractC0133a.b("Interleaving mode is not currently supported.", (e.containsKey("interleaving") ? 1 : 0) ^ i7);
                            if (i11 > 0) {
                            }
                            AbstractC0133a.c(z22);
                            this.f8391a = new C0622k(new C0123p(c0122o), i10, i11, e, str5);
                            String str8222222222 = (String) e0Var.get("control");
                            parse = Uri.parse(str8222222222);
                            if (!parse.isAbsolute()) {
                            }
                            this.f8392b = parse;
                            return;
                        }
                        str5 = str;
                        z7 = false;
                        i7 = 1;
                        if (i11 > 0) {
                        }
                        AbstractC0133a.c(z22);
                        this.f8391a = new C0622k(new C0123p(c0122o), i10, i11, e, str5);
                        String str82222222222 = (String) e0Var.get("control");
                        parse = Uri.parse(str82222222222);
                        if (!parse.isAbsolute()) {
                        }
                        this.f8392b = parse;
                        return;
                    case 1504891608:
                        if (str3.equals("audio/opus")) {
                            if (i6 != -1) {
                                z24 = true;
                            } else {
                                z24 = false;
                            }
                            AbstractC0133a.c(z24);
                            if (i11 == 48000) {
                                z25 = true;
                            } else {
                                z25 = false;
                            }
                            AbstractC0133a.b("Invalid OPUS clock rate.", z25);
                        }
                        str5 = str;
                        z7 = false;
                        i7 = 1;
                        if (i11 > 0) {
                        }
                        AbstractC0133a.c(z22);
                        this.f8391a = new C0622k(new C0123p(c0122o), i10, i11, e, str5);
                        String str822222222222 = (String) e0Var.get("control");
                        parse = Uri.parse(str822222222222);
                        if (!parse.isAbsolute()) {
                        }
                        this.f8392b = parse;
                        return;
                    case 1599127256:
                        if (str3.equals("video/x-vnd.on2.vp8")) {
                            c0122o.f2593t = 320;
                            c0122o.f2594u = 240;
                        }
                        str5 = str;
                        z7 = false;
                        i7 = 1;
                        if (i11 > 0) {
                        }
                        AbstractC0133a.c(z22);
                        this.f8391a = new C0622k(new C0123p(c0122o), i10, i11, e, str5);
                        String str8222222222222 = (String) e0Var.get("control");
                        parse = Uri.parse(str8222222222222);
                        if (!parse.isAbsolute()) {
                        }
                        this.f8392b = parse;
                        return;
                    case 1599127257:
                        if (str3.equals("video/x-vnd.on2.vp9")) {
                            c0122o.f2593t = 320;
                            c0122o.f2594u = 240;
                        }
                        str5 = str;
                        z7 = false;
                        i7 = 1;
                        if (i11 > 0) {
                        }
                        AbstractC0133a.c(z22);
                        this.f8391a = new C0622k(new C0123p(c0122o), i10, i11, e, str5);
                        String str82222222222222 = (String) e0Var.get("control");
                        parse = Uri.parse(str82222222222222);
                        if (!parse.isAbsolute()) {
                        }
                        this.f8392b = parse;
                        return;
                    case 1903231877:
                        str3.equals("audio/g711-alaw");
                        str5 = str;
                        z7 = false;
                        i7 = 1;
                        if (i11 > 0) {
                        }
                        AbstractC0133a.c(z22);
                        this.f8391a = new C0622k(new C0123p(c0122o), i10, i11, e, str5);
                        String str822222222222222 = (String) e0Var.get("control");
                        parse = Uri.parse(str822222222222222);
                        if (!parse.isAbsolute()) {
                        }
                        this.f8392b = parse;
                        return;
                    case 1903589369:
                        str3.equals("audio/g711-mlaw");
                        str5 = str;
                        z7 = false;
                        i7 = 1;
                        if (i11 > 0) {
                        }
                        AbstractC0133a.c(z22);
                        this.f8391a = new C0622k(new C0123p(c0122o), i10, i11, e, str5);
                        String str8222222222222222 = (String) e0Var.get("control");
                        parse = Uri.parse(str8222222222222222);
                        if (!parse.isAbsolute()) {
                        }
                        this.f8392b = parse;
                        return;
                    default:
                        str5 = str;
                        z7 = false;
                        i7 = 1;
                        if (i11 > 0) {
                        }
                        AbstractC0133a.c(z22);
                        this.f8391a = new C0622k(new C0123p(c0122o), i10, i11, e, str5);
                        String str82222222222222222 = (String) e0Var.get("control");
                        parse = Uri.parse(str82222222222222222);
                        if (!parse.isAbsolute()) {
                        }
                        this.f8392b = parse;
                        return;
                }
            case 1:
            case 4:
                str2 = "audio/raw";
                str = str6;
                c0122o.f2587m = S.F.n(str2);
                int i112 = c0613b.f8281c;
                if (!"audio".equals(c0614c.f8283a)) {
                }
                str4 = (String) e0Var2.get("fmtp");
                if (str4 != null) {
                }
                switch (str3.hashCode()) {
                    case -1664118616:
                        break;
                    case -1662541442:
                        break;
                    case -1606874997:
                        break;
                    case -53558318:
                        break;
                    case 187078296:
                        break;
                    case 187094639:
                        break;
                    case 1187890754:
                        break;
                    case 1331836730:
                        break;
                    case 1503095341:
                        break;
                    case 1504891608:
                        break;
                    case 1599127256:
                        break;
                    case 1599127257:
                        break;
                    case 1903231877:
                        break;
                    case 1903589369:
                        break;
                }
            case 2:
                str = str6;
                str2 = "audio/ac3";
                c0122o.f2587m = S.F.n(str2);
                int i1122 = c0613b.f8281c;
                if (!"audio".equals(c0614c.f8283a)) {
                }
                str4 = (String) e0Var2.get("fmtp");
                if (str4 != null) {
                }
                switch (str3.hashCode()) {
                    case -1664118616:
                        break;
                    case -1662541442:
                        break;
                    case -1606874997:
                        break;
                    case -53558318:
                        break;
                    case 187078296:
                        break;
                    case 187094639:
                        break;
                    case 1187890754:
                        break;
                    case 1331836730:
                        break;
                    case 1503095341:
                        break;
                    case 1504891608:
                        break;
                    case 1599127256:
                        break;
                    case 1599127257:
                        break;
                    case 1903231877:
                        break;
                    case 1903589369:
                        break;
                }
            case 3:
                str2 = "audio/3gpp";
                str = str6;
                c0122o.f2587m = S.F.n(str2);
                int i11222 = c0613b.f8281c;
                if (!"audio".equals(c0614c.f8283a)) {
                }
                str4 = (String) e0Var2.get("fmtp");
                if (str4 != null) {
                }
                switch (str3.hashCode()) {
                    case -1664118616:
                        break;
                    case -1662541442:
                        break;
                    case -1606874997:
                        break;
                    case -53558318:
                        break;
                    case 187078296:
                        break;
                    case 187094639:
                        break;
                    case 1187890754:
                        break;
                    case 1331836730:
                        break;
                    case 1503095341:
                        break;
                    case 1504891608:
                        break;
                    case 1599127256:
                        break;
                    case 1599127257:
                        break;
                    case 1903231877:
                        break;
                    case 1903589369:
                        break;
                }
            case 5:
                str2 = "video/x-vnd.on2.vp8";
                str = str6;
                c0122o.f2587m = S.F.n(str2);
                int i112222 = c0613b.f8281c;
                if (!"audio".equals(c0614c.f8283a)) {
                }
                str4 = (String) e0Var2.get("fmtp");
                if (str4 != null) {
                }
                switch (str3.hashCode()) {
                    case -1664118616:
                        break;
                    case -1662541442:
                        break;
                    case -1606874997:
                        break;
                    case -53558318:
                        break;
                    case 187078296:
                        break;
                    case 187094639:
                        break;
                    case 1187890754:
                        break;
                    case 1331836730:
                        break;
                    case 1503095341:
                        break;
                    case 1504891608:
                        break;
                    case 1599127256:
                        break;
                    case 1599127257:
                        break;
                    case 1903231877:
                        break;
                    case 1903589369:
                        break;
                }
            case 6:
                str2 = "video/x-vnd.on2.vp9";
                str = str6;
                c0122o.f2587m = S.F.n(str2);
                int i1122222 = c0613b.f8281c;
                if (!"audio".equals(c0614c.f8283a)) {
                }
                str4 = (String) e0Var2.get("fmtp");
                if (str4 != null) {
                }
                switch (str3.hashCode()) {
                    case -1664118616:
                        break;
                    case -1662541442:
                        break;
                    case -1606874997:
                        break;
                    case -53558318:
                        break;
                    case 187078296:
                        break;
                    case 187094639:
                        break;
                    case 1187890754:
                        break;
                    case 1331836730:
                        break;
                    case 1503095341:
                        break;
                    case 1504891608:
                        break;
                    case 1599127256:
                        break;
                    case 1599127257:
                        break;
                    case 1903231877:
                        break;
                    case 1903589369:
                        break;
                }
            case 7:
                str2 = "video/avc";
                str = str6;
                c0122o.f2587m = S.F.n(str2);
                int i11222222 = c0613b.f8281c;
                if (!"audio".equals(c0614c.f8283a)) {
                }
                str4 = (String) e0Var2.get("fmtp");
                if (str4 != null) {
                }
                switch (str3.hashCode()) {
                    case -1664118616:
                        break;
                    case -1662541442:
                        break;
                    case -1606874997:
                        break;
                    case -53558318:
                        break;
                    case 187078296:
                        break;
                    case 187094639:
                        break;
                    case 1187890754:
                        break;
                    case 1331836730:
                        break;
                    case 1503095341:
                        break;
                    case 1504891608:
                        break;
                    case 1599127256:
                        break;
                    case 1599127257:
                        break;
                    case 1903231877:
                        break;
                    case 1903589369:
                        break;
                }
            case '\b':
                str = str6;
                str2 = "video/hevc";
                c0122o.f2587m = S.F.n(str2);
                int i112222222 = c0613b.f8281c;
                if (!"audio".equals(c0614c.f8283a)) {
                }
                str4 = (String) e0Var2.get("fmtp");
                if (str4 != null) {
                }
                switch (str3.hashCode()) {
                    case -1664118616:
                        break;
                    case -1662541442:
                        break;
                    case -1606874997:
                        break;
                    case -53558318:
                        break;
                    case 187078296:
                        break;
                    case 187094639:
                        break;
                    case 1187890754:
                        break;
                    case 1331836730:
                        break;
                    case 1503095341:
                        break;
                    case 1504891608:
                        break;
                    case 1599127256:
                        break;
                    case 1599127257:
                        break;
                    case 1903231877:
                        break;
                    case 1903589369:
                        break;
                }
            case ContentHandlerProxy.PROCESSING_INSTRUCTION /* 9 */:
                str2 = "audio/opus";
                str = str6;
                c0122o.f2587m = S.F.n(str2);
                int i1122222222 = c0613b.f8281c;
                if (!"audio".equals(c0614c.f8283a)) {
                }
                str4 = (String) e0Var2.get("fmtp");
                if (str4 != null) {
                }
                switch (str3.hashCode()) {
                    case -1664118616:
                        break;
                    case -1662541442:
                        break;
                    case -1606874997:
                        break;
                    case -53558318:
                        break;
                    case 187078296:
                        break;
                    case 187094639:
                        break;
                    case 1187890754:
                        break;
                    case 1331836730:
                        break;
                    case 1503095341:
                        break;
                    case 1504891608:
                        break;
                    case 1599127256:
                        break;
                    case 1599127257:
                        break;
                    case 1903231877:
                        break;
                    case 1903589369:
                        break;
                }
            case '\n':
                str2 = "audio/g711-alaw";
                str = str6;
                c0122o.f2587m = S.F.n(str2);
                int i11222222222 = c0613b.f8281c;
                if (!"audio".equals(c0614c.f8283a)) {
                }
                str4 = (String) e0Var2.get("fmtp");
                if (str4 != null) {
                }
                switch (str3.hashCode()) {
                    case -1664118616:
                        break;
                    case -1662541442:
                        break;
                    case -1606874997:
                        break;
                    case -53558318:
                        break;
                    case 187078296:
                        break;
                    case 187094639:
                        break;
                    case 1187890754:
                        break;
                    case 1331836730:
                        break;
                    case 1503095341:
                        break;
                    case 1504891608:
                        break;
                    case 1599127256:
                        break;
                    case 1599127257:
                        break;
                    case 1903231877:
                        break;
                    case 1903589369:
                        break;
                }
            case 11:
                str2 = "audio/g711-mlaw";
                str = str6;
                c0122o.f2587m = S.F.n(str2);
                int i112222222222 = c0613b.f8281c;
                if (!"audio".equals(c0614c.f8283a)) {
                }
                str4 = (String) e0Var2.get("fmtp");
                if (str4 != null) {
                }
                switch (str3.hashCode()) {
                    case -1664118616:
                        break;
                    case -1662541442:
                        break;
                    case -1606874997:
                        break;
                    case -53558318:
                        break;
                    case 187078296:
                        break;
                    case 187094639:
                        break;
                    case 1187890754:
                        break;
                    case 1331836730:
                        break;
                    case 1503095341:
                        break;
                    case 1504891608:
                        break;
                    case 1599127256:
                        break;
                    case 1599127257:
                        break;
                    case 1903231877:
                        break;
                    case 1903589369:
                        break;
                }
            case '\r':
                str = str6;
                str2 = "audio/amr-wb";
                c0122o.f2587m = S.F.n(str2);
                int i1122222222222 = c0613b.f8281c;
                if (!"audio".equals(c0614c.f8283a)) {
                }
                str4 = (String) e0Var2.get("fmtp");
                if (str4 != null) {
                }
                switch (str3.hashCode()) {
                    case -1664118616:
                        break;
                    case -1662541442:
                        break;
                    case -1606874997:
                        break;
                    case -53558318:
                        break;
                    case 187078296:
                        break;
                    case 187094639:
                        break;
                    case 1187890754:
                        break;
                    case 1331836730:
                        break;
                    case 1503095341:
                        break;
                    case 1504891608:
                        break;
                    case 1599127256:
                        break;
                    case 1599127257:
                        break;
                    case 1903231877:
                        break;
                    case 1903589369:
                        break;
                }
            case 14:
                str2 = "video/mp4v-es";
                str = str6;
                c0122o.f2587m = S.F.n(str2);
                int i11222222222222 = c0613b.f8281c;
                if (!"audio".equals(c0614c.f8283a)) {
                }
                str4 = (String) e0Var2.get("fmtp");
                if (str4 != null) {
                }
                switch (str3.hashCode()) {
                    case -1664118616:
                        break;
                    case -1662541442:
                        break;
                    case -1606874997:
                        break;
                    case -53558318:
                        break;
                    case 187078296:
                        break;
                    case 187094639:
                        break;
                    case 1187890754:
                        break;
                    case 1331836730:
                        break;
                    case 1503095341:
                        break;
                    case 1504891608:
                        break;
                    case 1599127256:
                        break;
                    case 1599127257:
                        break;
                    case 1903231877:
                        break;
                    case 1903589369:
                        break;
                }
            case 15:
            case 16:
                str = str6;
                str2 = "video/3gpp";
                c0122o.f2587m = S.F.n(str2);
                int i112222222222222 = c0613b.f8281c;
                if (!"audio".equals(c0614c.f8283a)) {
                }
                str4 = (String) e0Var2.get("fmtp");
                if (str4 != null) {
                }
                switch (str3.hashCode()) {
                    case -1664118616:
                        break;
                    case -1662541442:
                        break;
                    case -1606874997:
                        break;
                    case -53558318:
                        break;
                    case 187078296:
                        break;
                    case 187094639:
                        break;
                    case 1187890754:
                        break;
                    case 1331836730:
                        break;
                    case 1503095341:
                        break;
                    case 1504891608:
                        break;
                    case 1599127256:
                        break;
                    case 1599127257:
                        break;
                    case 1903231877:
                        break;
                    case 1903589369:
                        break;
                }
            default:
                throw new IllegalArgumentException(str6);
        }
    }

    public static byte[] a(String str) {
        byte[] decode = Base64.decode(str, 0);
        byte[] bArr = new byte[decode.length + 4];
        System.arraycopy(W.q.f3421a, 0, bArr, 0, 4);
        System.arraycopy(decode, 0, bArr, 4, decode.length);
        return bArr;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj != null && v.class == obj.getClass()) {
            v vVar = (v) obj;
            if (this.f8391a.equals(vVar.f8391a) && this.f8392b.equals(vVar.f8392b)) {
                return true;
            }
        }
        return false;
    }

    public final int hashCode() {
        return this.f8392b.hashCode() + ((this.f8391a.hashCode() + 217) * 31);
    }
}
