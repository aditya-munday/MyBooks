package l0;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* renamed from: l0.h, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0619h {

    /* renamed from: a, reason: collision with root package name */
    public boolean f8314a;

    /* renamed from: b, reason: collision with root package name */
    public byte f8315b;

    /* renamed from: c, reason: collision with root package name */
    public int f8316c;

    /* renamed from: d, reason: collision with root package name */
    public long f8317d;
    public int e;

    /* renamed from: f, reason: collision with root package name */
    public byte[] f8318f;
}
