package l0;

import androidx.datastore.preferences.protobuf.AbstractC0227o;
import p0.X;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* loaded from: classes.dex */
public final class q {

    /* renamed from: a, reason: collision with root package name */
    public final p f8357a;

    /* renamed from: b, reason: collision with root package name */
    public final t0.o f8358b;

    /* renamed from: c, reason: collision with root package name */
    public final X f8359c;

    /* renamed from: d, reason: collision with root package name */
    public boolean f8360d;
    public boolean e;

    /* renamed from: f, reason: collision with root package name */
    public final /* synthetic */ r f8361f;

    public q(r rVar, v vVar, int i6, InterfaceC0615d interfaceC0615d) {
        this.f8361f = rVar;
        this.f8358b = new t0.o(AbstractC0227o.d(i6, "ExoPlayer:RtspMediaPeriod:RtspLoaderWrapper "));
        X x6 = new X(rVar.o, null, null);
        this.f8359c = x6;
        this.f8357a = new p(rVar, vVar, i6, x6, interfaceC0615d);
        x6.f9025f = rVar.f8373q;
    }

    public final void a() {
        if (!this.f8360d) {
            this.f8357a.f8354b.f8300x = true;
            this.f8360d = true;
            r.a(this.f8361f);
        }
    }
}
