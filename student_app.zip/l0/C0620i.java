package l0;

import java.util.Locale;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* renamed from: l0.i, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0620i {

    /* renamed from: g, reason: collision with root package name */
    public static final byte[] f8319g = new byte[0];

    /* renamed from: a, reason: collision with root package name */
    public final boolean f8320a;

    /* renamed from: b, reason: collision with root package name */
    public final byte f8321b;

    /* renamed from: c, reason: collision with root package name */
    public final int f8322c;

    /* renamed from: d, reason: collision with root package name */
    public final long f8323d;
    public final int e;

    /* renamed from: f, reason: collision with root package name */
    public final byte[] f8324f;

    public C0620i(C0619h c0619h) {
        this.f8320a = c0619h.f8314a;
        this.f8321b = c0619h.f8315b;
        this.f8322c = c0619h.f8316c;
        this.f8323d = c0619h.f8317d;
        this.e = c0619h.e;
        this.f8324f = c0619h.f8318f;
    }

    public static int a(int i6) {
        return Q5.a.x(i6 + 1);
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj != null && C0620i.class == obj.getClass()) {
            C0620i c0620i = (C0620i) obj;
            if (this.f8321b == c0620i.f8321b && this.f8322c == c0620i.f8322c && this.f8320a == c0620i.f8320a && this.f8323d == c0620i.f8323d && this.e == c0620i.e) {
                return true;
            }
        }
        return false;
    }

    public final int hashCode() {
        int i6 = (((((527 + this.f8321b) * 31) + this.f8322c) * 31) + (this.f8320a ? 1 : 0)) * 31;
        long j6 = this.f8323d;
        return ((i6 + ((int) (j6 ^ (j6 >>> 32)))) * 31) + this.e;
    }

    public final String toString() {
        Object[] objArr = {Byte.valueOf(this.f8321b), Integer.valueOf(this.f8322c), Long.valueOf(this.f8323d), Integer.valueOf(this.e), Boolean.valueOf(this.f8320a)};
        String str = V.C.f3053a;
        return String.format(Locale.US, "RtpPacket(payloadType=%d, seq=%d, timestamp=%d, ssrc=%x, marker=%b)", objArr);
    }
}
