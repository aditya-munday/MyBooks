package l0;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* renamed from: l0.H, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0610H implements InterfaceC0615d {
    @Override // l0.InterfaceC0615d
    public final InterfaceC0616e c(int i6) {
        C0609G c0609g = new C0609G();
        c0609g.B(android.support.v4.media.session.a.o(i6 * 2));
        return c0609g;
    }
}
