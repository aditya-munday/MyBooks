package l0;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* renamed from: l0.o, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final /* synthetic */ class RunnableC0626o implements Runnable {
    public final /* synthetic */ int o;

    /* renamed from: p, reason: collision with root package name */
    public final /* synthetic */ r f8352p;

    public /* synthetic */ RunnableC0626o(r rVar, int i6) {
        this.o = i6;
        this.f8352p = rVar;
    }

    @Override // java.lang.Runnable
    public final void run() {
        switch (this.o) {
            case 0:
                r.f(this.f8352p);
                return;
            default:
                r.f(this.f8352p);
                return;
        }
    }
}
