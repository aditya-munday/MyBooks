package l0;

import androidx.datastore.preferences.protobuf.C0223k;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* loaded from: classes.dex */
public final class t extends C0223k {
}
