package l0;

import S.C0129w;
import S.C0132z;
import S.S;
import android.net.Uri;
import java.util.ArrayList;
import javax.net.SocketFactory;
import p0.AbstractC0683a;
import p0.C0678A;
import p0.InterfaceC0706y;
import p0.c0;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* loaded from: classes.dex */
public final class u extends AbstractC0683a {

    /* renamed from: A, reason: collision with root package name */
    public boolean f8383A;

    /* renamed from: B, reason: collision with root package name */
    public boolean f8384B;

    /* renamed from: C, reason: collision with root package name */
    public boolean f8385C;

    /* renamed from: D, reason: collision with root package name */
    public C0132z f8386D;

    /* renamed from: v, reason: collision with root package name */
    public final InterfaceC0615d f8387v;

    /* renamed from: w, reason: collision with root package name */
    public final String f8388w = "AndroidXMedia3/1.8.0";

    /* renamed from: x, reason: collision with root package name */
    public final Uri f8389x;
    public final SocketFactory y;

    /* renamed from: z, reason: collision with root package name */
    public long f8390z;

    static {
        S.A.a("media3.exoplayer.rtsp");
    }

    public u(C0132z c0132z, InterfaceC0615d interfaceC0615d, SocketFactory socketFactory) {
        this.f8386D = c0132z;
        this.f8387v = interfaceC0615d;
        C0129w c0129w = c0132z.f2655b;
        c0129w.getClass();
        Uri uri = c0129w.f2649a;
        String scheme = uri.getScheme();
        if (scheme != null && Q5.a.o("rtspt", scheme)) {
            uri = Uri.parse("rtsp" + uri.toString().substring(5));
        }
        this.f8389x = uri;
        this.y = socketFactory;
        this.f8390z = -9223372036854775807L;
        this.f8385C = true;
    }

    @Override // p0.AbstractC0683a
    public final InterfaceC0706y b(C0678A c0678a, t0.f fVar, long j6) {
        return new r(fVar, this.f8387v, this.f8389x, new X2.b(this), this.f8388w, this.y);
    }

    @Override // p0.AbstractC0683a
    public final synchronized C0132z k() {
        return this.f8386D;
    }

    @Override // p0.AbstractC0683a
    public final void o(X.z zVar) {
        x();
    }

    @Override // p0.AbstractC0683a
    public final void q(InterfaceC0706y interfaceC0706y) {
        r rVar = (r) interfaceC0706y;
        ArrayList arrayList = rVar.f8375s;
        for (int i6 = 0; i6 < arrayList.size(); i6++) {
            q qVar = (q) arrayList.get(i6);
            if (!qVar.e) {
                qVar.f8358b.e(null);
                qVar.f8359c.A();
                qVar.e = true;
            }
        }
        V.C.g(rVar.f8374r);
        rVar.f8367F = true;
    }

    @Override // p0.AbstractC0683a
    public final synchronized void w(C0132z c0132z) {
        this.f8386D = c0132z;
    }

    public final void x() {
        S c0Var = new c0(this.f8390z, this.f8383A, this.f8384B, k());
        if (this.f8385C) {
            c0Var = new s(c0Var, 0);
        }
        p(c0Var);
    }

    @Override // p0.AbstractC0683a
    public final void m() {
    }

    @Override // p0.AbstractC0683a
    public final void t() {
    }
}
