package l0;

import E2.J;
import E2.Z;
import E2.n0;
import V.AbstractC0133a;
import android.net.Uri;
import java.util.Arrays;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import org.apache.tika.fork.ContentHandlerProxy;
import org.apache.tika.metadata.TikaCoreProperties;
import org.apache.tika.utils.StringUtils;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* loaded from: classes.dex */
public abstract class z {

    /* renamed from: a, reason: collision with root package name */
    public static final Pattern f8404a = Pattern.compile("([A-Z_]+) (.*) RTSP/1\\.0");

    /* renamed from: b, reason: collision with root package name */
    public static final Pattern f8405b = Pattern.compile("RTSP/1\\.0 (\\d+) (.+)");

    /* renamed from: c, reason: collision with root package name */
    public static final Pattern f8406c = Pattern.compile("Content-Length:\\s?(\\d+)", 2);

    /* renamed from: d, reason: collision with root package name */
    public static final Pattern f8407d = Pattern.compile("([\\w$\\-_.+]+)(?:;\\s?timeout=(\\d+))?");
    public static final Pattern e = Pattern.compile("Digest realm=\"([^\"\\x00-\\x08\\x0A-\\x1f\\x7f]+)\",\\s?(?:domain=\"(.+)\",\\s?)?nonce=\"([^\"\\x00-\\x08\\x0A-\\x1f\\x7f]+)\"(?:,\\s?opaque=\"([^\"\\x00-\\x08\\x0A-\\x1f\\x7f]+)\")?");

    /* renamed from: f, reason: collision with root package name */
    public static final Pattern f8408f = Pattern.compile("Basic realm=\"([^\"\\x00-\\x08\\x0A-\\x1f\\x7f]+)\"");

    /* renamed from: g, reason: collision with root package name */
    public static final String f8409g = new String(new byte[]{10});

    /* renamed from: h, reason: collision with root package name */
    public static final String f8410h = new String(new byte[]{13, 10});

    public static int a(String str) {
        str.getClass();
        char c6 = 65535;
        switch (str.hashCode()) {
            case -1881579439:
                if (str.equals("RECORD")) {
                    c6 = 0;
                    break;
                }
                break;
            case -880847356:
                if (str.equals("TEARDOWN")) {
                    c6 = 1;
                    break;
                }
                break;
            case -702888512:
                if (str.equals("GET_PARAMETER")) {
                    c6 = 2;
                    break;
                }
                break;
            case -531492226:
                if (str.equals("OPTIONS")) {
                    c6 = 3;
                    break;
                }
                break;
            case -84360524:
                if (str.equals("PLAY_NOTIFY")) {
                    c6 = 4;
                    break;
                }
                break;
            case 2458420:
                if (str.equals("PLAY")) {
                    c6 = 5;
                    break;
                }
                break;
            case 6481884:
                if (str.equals("REDIRECT")) {
                    c6 = 6;
                    break;
                }
                break;
            case 71242700:
                if (str.equals("SET_PARAMETER")) {
                    c6 = 7;
                    break;
                }
                break;
            case 75902422:
                if (str.equals("PAUSE")) {
                    c6 = '\b';
                    break;
                }
                break;
            case 78791261:
                if (str.equals("SETUP")) {
                    c6 = '\t';
                    break;
                }
                break;
            case 133006441:
                if (str.equals("ANNOUNCE")) {
                    c6 = '\n';
                    break;
                }
                break;
            case 1800840907:
                if (str.equals("DESCRIBE")) {
                    c6 = 11;
                    break;
                }
                break;
        }
        switch (c6) {
            case 0:
                return 8;
            case 1:
                return 12;
            case 2:
                return 3;
            case 3:
                return 4;
            case 4:
                return 7;
            case 5:
                return 6;
            case 6:
                return 9;
            case 7:
                return 11;
            case '\b':
                return 5;
            case ContentHandlerProxy.PROCESSING_INSTRUCTION /* 9 */:
                return 10;
            case '\n':
                return 1;
            case 11:
                return 2;
            default:
                return 0;
        }
    }

    public static Z b(String str) {
        if (str == null) {
            E2.G g2 = E2.I.f699p;
            return Z.f721s;
        }
        E2.r.d(4, "initialCapacity");
        Object[] objArr = new Object[4];
        String str2 = V.C.f3053a;
        int i6 = 0;
        for (String str3 : str.split(",\\s?", -1)) {
            int a6 = a(str3);
            if (a6 != 0) {
                Integer valueOf = Integer.valueOf(a6);
                int i7 = i6 + 1;
                int e6 = E2.C.e(objArr.length, i7);
                if (e6 > objArr.length) {
                    objArr = Arrays.copyOf(objArr, e6);
                }
                objArr[i6] = valueOf;
                i6 = i7;
            }
        }
        return E2.I.s(i6, objArr);
    }

    public static F0.c c(String str) {
        long parseInt;
        Matcher matcher = f8407d.matcher(str);
        if (matcher.matches()) {
            String group = matcher.group(1);
            group.getClass();
            if (matcher.group(2) != null) {
                try {
                    parseInt = Integer.parseInt(r0) * 1000;
                } catch (NumberFormatException e6) {
                    throw S.G.b(str, e6);
                }
            } else {
                parseInt = 60000;
            }
            return new F0.c(group, parseInt, 5);
        }
        throw S.G.b(str, null);
    }

    public static d0.t d(Uri uri) {
        String userInfo = uri.getUserInfo();
        if (userInfo != null && userInfo.contains(TikaCoreProperties.NAMESPACE_PREFIX_DELIMITER)) {
            String str = V.C.f3053a;
            String[] split = userInfo.split(TikaCoreProperties.NAMESPACE_PREFIX_DELIMITER, 2);
            return new d0.t(split[0], 1, split[1]);
        }
        return null;
    }

    public static i2.m e(String str) {
        Matcher matcher = e.matcher(str);
        boolean find = matcher.find();
        String str2 = StringUtils.EMPTY;
        if (find) {
            String group = matcher.group(1);
            group.getClass();
            String group2 = matcher.group(3);
            group2.getClass();
            String group3 = matcher.group(4);
            if (group3 != null) {
                str2 = group3;
            }
            return new i2.m(2, group, group2, str2);
        }
        Matcher matcher2 = f8408f.matcher(str);
        if (matcher2.matches()) {
            String group4 = matcher2.group(1);
            group4.getClass();
            return new i2.m(1, group4, StringUtils.EMPTY, StringUtils.EMPTY);
        }
        throw S.G.b("Invalid WWW-Authenticate header " + str, null);
    }

    /* JADX WARN: Type inference failed for: r0v4, types: [E2.C, E2.F] */
    public static Z f(C0603A c0603a) {
        boolean z6;
        if (c0603a.f8231c.b("CSeq") != null) {
            z6 = true;
        } else {
            z6 = false;
        }
        AbstractC0133a.c(z6);
        ?? c6 = new E2.C(4);
        Object[] objArr = {g(c0603a.f8230b), c0603a.f8229a, "RTSP/1.0"};
        String str = V.C.f3053a;
        c6.a(String.format(Locale.US, "%s %s %s", objArr));
        J j6 = c0603a.f8231c.f8351a;
        n0 it = j6.f700r.keySet().iterator();
        while (it.hasNext()) {
            String str2 = (String) it.next();
            E2.I d6 = j6.d(str2);
            for (int i6 = 0; i6 < d6.size(); i6++) {
                c6.a(String.format(Locale.US, "%s: %s", str2, d6.get(i6)));
            }
        }
        c6.a(StringUtils.EMPTY);
        c6.a(c0603a.f8232d);
        return c6.f();
    }

    public static String g(int i6) {
        switch (i6) {
            case 1:
                return "ANNOUNCE";
            case 2:
                return "DESCRIBE";
            case 3:
                return "GET_PARAMETER";
            case 4:
                return "OPTIONS";
            case 5:
                return "PAUSE";
            case 6:
                return "PLAY";
            case 7:
                return "PLAY_NOTIFY";
            case 8:
                return "RECORD";
            case ContentHandlerProxy.PROCESSING_INSTRUCTION /* 9 */:
                return "REDIRECT";
            case 10:
                return "SETUP";
            case 11:
                return "SET_PARAMETER";
            case 12:
                return "TEARDOWN";
            default:
                throw new IllegalStateException();
        }
    }
}
