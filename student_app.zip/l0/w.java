package l0;

import V.AbstractC0133a;
import Z.C0179k;
import android.os.Handler;
import java.io.DataInputStream;
import java.io.InputStream;
import java.util.ArrayList;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* loaded from: classes.dex */
public final class w implements t0.l {
    public final DataInputStream o;

    /* renamed from: p, reason: collision with root package name */
    public final T1.b f8393p;

    /* renamed from: q, reason: collision with root package name */
    public volatile boolean f8394q;

    /* renamed from: r, reason: collision with root package name */
    public final /* synthetic */ y f8395r;

    /* JADX WARN: Type inference failed for: r1v2, types: [T1.b, java.lang.Object] */
    public w(y yVar, InputStream inputStream) {
        this.f8395r = yVar;
        this.o = new DataInputStream(inputStream);
        ?? obj = new Object();
        obj.f2792c = new ArrayList();
        obj.f2790a = 1;
        this.f8393p = obj;
    }

    @Override // t0.l
    public final void b() {
        boolean z6;
        boolean z7;
        String str;
        while (!this.f8394q) {
            byte readByte = this.o.readByte();
            if (readByte == 36) {
                int readUnsignedByte = this.o.readUnsignedByte();
                int readUnsignedShort = this.o.readUnsignedShort();
                byte[] bArr = new byte[readUnsignedShort];
                this.o.readFully(bArr, 0, readUnsignedShort);
                C0609G c0609g = (C0609G) this.f8395r.f8400q.get(Integer.valueOf(readUnsignedByte));
                if (c0609g != null && !this.f8395r.f8403t) {
                    c0609g.f8266s.add(bArr);
                }
            } else if (this.f8395r.f8403t) {
                continue;
            } else {
                C0179k c0179k = this.f8395r.o;
                T1.b bVar = this.f8393p;
                DataInputStream dataInputStream = this.o;
                bVar.getClass();
                E2.I a6 = bVar.a(T1.b.b(readByte, dataInputStream));
                while (a6 == null) {
                    if (bVar.f2790a == 3) {
                        long j6 = bVar.f2791b;
                        if (j6 > 0) {
                            int j7 = Q5.a.j(j6);
                            if (j7 != -1) {
                                z6 = true;
                            } else {
                                z6 = false;
                            }
                            AbstractC0133a.i(z6);
                            byte[] bArr2 = new byte[j7];
                            dataInputStream.readFully(bArr2, 0, j7);
                            ArrayList arrayList = (ArrayList) bVar.f2792c;
                            if (bVar.f2790a == 3) {
                                z7 = true;
                            } else {
                                z7 = false;
                            }
                            AbstractC0133a.i(z7);
                            if (j7 > 0) {
                                int i6 = j7 - 1;
                                if (bArr2[i6] == 10) {
                                    if (j7 > 1) {
                                        int i7 = j7 - 2;
                                        if (bArr2[i7] == 13) {
                                            str = new String(bArr2, 0, i7, y.f8398u);
                                            arrayList.add(str);
                                            a6 = E2.I.u(arrayList);
                                            ((ArrayList) bVar.f2792c).clear();
                                            bVar.f2790a = 1;
                                            bVar.f2791b = 0L;
                                        }
                                    }
                                    str = new String(bArr2, 0, i6, y.f8398u);
                                    arrayList.add(str);
                                    a6 = E2.I.u(arrayList);
                                    ((ArrayList) bVar.f2792c).clear();
                                    bVar.f2790a = 1;
                                    bVar.f2791b = 0L;
                                }
                            }
                            throw new IllegalArgumentException("Message body is empty or does not end with a LF.");
                        }
                        throw new IllegalStateException("Expects a greater than zero Content-Length.");
                    }
                    a6 = bVar.a(T1.b.b(dataInputStream.readByte(), dataInputStream));
                }
                ((Handler) c0179k.f4193p).post(new I3.b(c0179k, a6, 25));
            }
        }
    }

    @Override // t0.l
    public final void f() {
        this.f8394q = true;
    }
}
