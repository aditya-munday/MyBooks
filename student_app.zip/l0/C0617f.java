package l0;

import Z.C0179k;
import Z.T;
import android.os.Handler;
import c5.C0324M;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* renamed from: l0.f, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0617f implements t0.l {
    public final int o;

    /* renamed from: p, reason: collision with root package name */
    public final v f8292p;

    /* renamed from: q, reason: collision with root package name */
    public final C0324M f8293q;

    /* renamed from: r, reason: collision with root package name */
    public final C0179k f8294r;

    /* renamed from: t, reason: collision with root package name */
    public final InterfaceC0615d f8296t;

    /* renamed from: u, reason: collision with root package name */
    public InterfaceC0616e f8297u;

    /* renamed from: v, reason: collision with root package name */
    public C0618g f8298v;

    /* renamed from: w, reason: collision with root package name */
    public x0.l f8299w;

    /* renamed from: x, reason: collision with root package name */
    public volatile boolean f8300x;

    /* renamed from: z, reason: collision with root package name */
    public volatile long f8301z;

    /* renamed from: s, reason: collision with root package name */
    public final Handler f8295s = V.C.p(null);
    public volatile long y = -9223372036854775807L;

    public C0617f(int i6, v vVar, C0324M c0324m, C0179k c0179k, InterfaceC0615d interfaceC0615d) {
        this.o = i6;
        this.f8292p = vVar;
        this.f8293q = c0324m;
        this.f8294r = c0179k;
        this.f8296t = interfaceC0615d;
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r4v0, types: [S.r, java.lang.Object] */
    @Override // t0.l
    public final void b() {
        if (this.f8300x) {
            this.f8300x = false;
        }
        try {
            if (this.f8297u == null) {
                InterfaceC0616e c6 = this.f8296t.c(this.o);
                this.f8297u = c6;
                this.f8295s.post(new T(this, c6.a(), this.f8297u, 4));
                InterfaceC0616e interfaceC0616e = this.f8297u;
                interfaceC0616e.getClass();
                this.f8299w = new x0.l(interfaceC0616e, 0L, -1L);
                C0618g c0618g = new C0618g(this.f8292p.f8391a, this.o);
                this.f8298v = c0618g;
                c0618g.k(this.f8294r);
            }
            while (!this.f8300x) {
                if (this.y != -9223372036854775807L) {
                    C0618g c0618g2 = this.f8298v;
                    c0618g2.getClass();
                    c0618g2.a(this.f8301z, this.y);
                    this.y = -9223372036854775807L;
                }
                C0618g c0618g3 = this.f8298v;
                c0618g3.getClass();
                x0.l lVar = this.f8299w;
                lVar.getClass();
                if (c0618g3.h(lVar, new Object()) == -1) {
                    break;
                }
            }
            this.f8300x = false;
            InterfaceC0616e interfaceC0616e2 = this.f8297u;
            interfaceC0616e2.getClass();
            if (interfaceC0616e2.s()) {
                android.support.v4.media.session.a.c(this.f8297u);
                this.f8297u = null;
            }
        } catch (Throwable th) {
            InterfaceC0616e interfaceC0616e3 = this.f8297u;
            interfaceC0616e3.getClass();
            if (interfaceC0616e3.s()) {
                android.support.v4.media.session.a.c(this.f8297u);
                this.f8297u = null;
            }
            throw th;
        }
    }

    @Override // t0.l
    public final void f() {
        this.f8300x = true;
    }
}
