package l0;

import E2.e0;
import V.AbstractC0133a;
import Z.C0179k;
import android.net.Uri;
import android.util.SparseArray;
import androidx.datastore.preferences.protobuf.C0223k;
import java.io.Closeable;
import java.net.Socket;
import java.util.ArrayDeque;
import java.util.Locale;
import java.util.regex.Pattern;
import javax.net.SocketFactory;
import org.apache.tika.utils.StringUtils;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* renamed from: l0.m, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0624m implements Closeable {

    /* renamed from: A, reason: collision with root package name */
    public RunnableC0623l f8334A;

    /* renamed from: B, reason: collision with root package name */
    public i2.m f8335B;

    /* renamed from: C, reason: collision with root package name */
    public int f8336C;

    /* renamed from: D, reason: collision with root package name */
    public boolean f8337D;

    /* renamed from: E, reason: collision with root package name */
    public boolean f8338E;

    /* renamed from: F, reason: collision with root package name */
    public boolean f8339F;

    /* renamed from: G, reason: collision with root package name */
    public long f8340G;
    public final c0.h o;

    /* renamed from: p, reason: collision with root package name */
    public final c0.h f8341p;

    /* renamed from: q, reason: collision with root package name */
    public final String f8342q;

    /* renamed from: r, reason: collision with root package name */
    public final SocketFactory f8343r;

    /* renamed from: s, reason: collision with root package name */
    public final ArrayDeque f8344s = new ArrayDeque();

    /* renamed from: t, reason: collision with root package name */
    public final SparseArray f8345t = new SparseArray();

    /* renamed from: u, reason: collision with root package name */
    public final D2.i f8346u;

    /* renamed from: v, reason: collision with root package name */
    public Uri f8347v;

    /* renamed from: w, reason: collision with root package name */
    public y f8348w;

    /* renamed from: x, reason: collision with root package name */
    public d0.t f8349x;
    public String y;

    /* renamed from: z, reason: collision with root package name */
    public long f8350z;

    /* JADX WARN: Type inference failed for: r3v3, types: [D2.i, java.lang.Object] */
    public C0624m(c0.h hVar, c0.h hVar2, String str, Uri uri, SocketFactory socketFactory) {
        Uri build;
        this.o = hVar;
        this.f8341p = hVar2;
        this.f8342q = str;
        this.f8343r = socketFactory;
        ?? obj = new Object();
        obj.f623q = this;
        this.f8346u = obj;
        Pattern pattern = z.f8404a;
        if (uri.getUserInfo() == null) {
            build = uri;
        } else {
            String encodedAuthority = uri.getEncodedAuthority();
            encodedAuthority.getClass();
            AbstractC0133a.c(encodedAuthority.contains("@"));
            String str2 = V.C.f3053a;
            build = uri.buildUpon().encodedAuthority(encodedAuthority.split("@", -1)[1]).build();
        }
        this.f8347v = build;
        this.f8348w = new y(new C0179k(this));
        this.f8350z = 60000L;
        this.f8349x = z.d(uri);
        this.f8340G = -9223372036854775807L;
        this.f8336C = -1;
    }

    public static void a(C0624m c0624m, C0223k c0223k) {
        if (c0624m.f8337D) {
            c0624m.f8341p.c(c0223k);
            return;
        }
        c0.h hVar = c0624m.o;
        String message = c0223k.getMessage();
        if (message == null) {
            message = StringUtils.EMPTY;
        }
        hVar.e(message, c0223k);
    }

    public final void b() {
        long j6;
        p pVar = (p) this.f8344s.pollFirst();
        if (pVar == null) {
            r rVar = (r) this.f8341p.f5398p;
            long j7 = rVar.f8363B;
            if (j7 != -9223372036854775807L) {
                j6 = V.C.Z(j7);
            } else {
                long j8 = rVar.f8364C;
                if (j8 != -9223372036854775807L) {
                    j6 = V.C.Z(j8);
                } else {
                    j6 = 0;
                }
            }
            rVar.f8374r.e(j6);
            return;
        }
        Uri uri = pVar.f8354b.f8292p.f8392b;
        AbstractC0133a.j(pVar.f8355c);
        String str = pVar.f8355c;
        String str2 = this.y;
        D2.i iVar = this.f8346u;
        ((C0624m) iVar.f623q).f8336C = 0;
        E2.r.c("Transport", str);
        iVar.j(iVar.g(10, str2, e0.b(1, new Object[]{"Transport", str}, null), uri));
    }

    public final Socket c(Uri uri) {
        boolean z6;
        int i6;
        if (uri.getHost() != null) {
            z6 = true;
        } else {
            z6 = false;
        }
        AbstractC0133a.c(z6);
        if (uri.getPort() > 0) {
            i6 = uri.getPort();
        } else {
            i6 = 554;
        }
        String host = uri.getHost();
        host.getClass();
        return this.f8343r.createSocket(host, i6);
    }

    @Override // java.io.Closeable, java.lang.AutoCloseable
    public final void close() {
        RunnableC0623l runnableC0623l = this.f8334A;
        if (runnableC0623l != null) {
            runnableC0623l.close();
            this.f8334A = null;
            Uri uri = this.f8347v;
            String str = this.y;
            str.getClass();
            D2.i iVar = this.f8346u;
            C0624m c0624m = (C0624m) iVar.f623q;
            int i6 = c0624m.f8336C;
            if (i6 != -1 && i6 != 0) {
                c0624m.f8336C = 0;
                iVar.j(iVar.g(12, str, e0.f744u, uri));
            }
        }
        this.f8348w.close();
    }

    public final void d(long j6) {
        boolean z6;
        if (this.f8336C == 2 && !this.f8339F) {
            Uri uri = this.f8347v;
            String str = this.y;
            str.getClass();
            D2.i iVar = this.f8346u;
            C0624m c0624m = (C0624m) iVar.f623q;
            if (c0624m.f8336C == 2) {
                z6 = true;
            } else {
                z6 = false;
            }
            AbstractC0133a.i(z6);
            iVar.j(iVar.g(5, str, e0.f744u, uri));
            c0624m.f8339F = true;
        }
        this.f8340G = j6;
    }

    public final void e(long j6) {
        boolean z6;
        Uri uri = this.f8347v;
        String str = this.y;
        str.getClass();
        D2.i iVar = this.f8346u;
        int i6 = ((C0624m) iVar.f623q).f8336C;
        if (i6 != 1 && i6 != 2) {
            z6 = false;
        } else {
            z6 = true;
        }
        AbstractC0133a.i(z6);
        C0604B c0604b = C0604B.f8233c;
        Object[] objArr = {Double.valueOf(j6 / 1000.0d)};
        String str2 = V.C.f3053a;
        iVar.j(iVar.g(6, str, e0.b(1, new Object[]{"Range", String.format(Locale.US, "npt=%.3f-", objArr)}, null), uri));
    }
}
