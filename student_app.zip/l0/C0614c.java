package l0;

import E2.e0;
import java.util.Objects;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* renamed from: l0.c, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0614c {

    /* renamed from: a, reason: collision with root package name */
    public final String f8283a;

    /* renamed from: b, reason: collision with root package name */
    public final int f8284b;

    /* renamed from: c, reason: collision with root package name */
    public final String f8285c;

    /* renamed from: d, reason: collision with root package name */
    public final int f8286d;
    public final int e;

    /* renamed from: f, reason: collision with root package name */
    public final String f8287f;

    /* renamed from: g, reason: collision with root package name */
    public final String f8288g;

    /* renamed from: h, reason: collision with root package name */
    public final String f8289h;

    /* renamed from: i, reason: collision with root package name */
    public final e0 f8290i;

    /* renamed from: j, reason: collision with root package name */
    public final C0613b f8291j;

    public C0614c(C0612a c0612a, e0 e0Var, C0613b c0613b) {
        this.f8283a = c0612a.f8271a;
        this.f8284b = c0612a.f8272b;
        this.f8285c = c0612a.f8273c;
        this.f8286d = c0612a.f8274d;
        this.f8287f = c0612a.f8276g;
        this.f8288g = c0612a.f8277h;
        this.e = c0612a.f8275f;
        this.f8289h = c0612a.f8278i;
        this.f8290i = e0Var;
        this.f8291j = c0613b;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj != null && C0614c.class == obj.getClass()) {
            C0614c c0614c = (C0614c) obj;
            if (this.f8283a.equals(c0614c.f8283a) && this.f8284b == c0614c.f8284b && this.f8285c.equals(c0614c.f8285c) && this.f8286d == c0614c.f8286d && this.e == c0614c.e) {
                e0 e0Var = c0614c.f8290i;
                e0 e0Var2 = this.f8290i;
                e0Var2.getClass();
                if (E2.r.f(e0Var, e0Var2) && this.f8291j.equals(c0614c.f8291j) && Objects.equals(this.f8287f, c0614c.f8287f) && Objects.equals(this.f8288g, c0614c.f8288g) && Objects.equals(this.f8289h, c0614c.f8289h)) {
                    return true;
                }
            }
        }
        return false;
    }

    public final int hashCode() {
        int hashCode;
        int hashCode2;
        int hashCode3 = (this.f8291j.hashCode() + ((this.f8290i.hashCode() + ((((((this.f8285c.hashCode() + ((((this.f8283a.hashCode() + 217) * 31) + this.f8284b) * 31)) * 31) + this.f8286d) * 31) + this.e) * 31)) * 31)) * 31;
        int i6 = 0;
        String str = this.f8287f;
        if (str == null) {
            hashCode = 0;
        } else {
            hashCode = str.hashCode();
        }
        int i7 = (hashCode3 + hashCode) * 31;
        String str2 = this.f8288g;
        if (str2 == null) {
            hashCode2 = 0;
        } else {
            hashCode2 = str2.hashCode();
        }
        int i8 = (i7 + hashCode2) * 31;
        String str3 = this.f8289h;
        if (str3 != null) {
            i6 = str3.hashCode();
        }
        return i8 + i6;
    }
}
