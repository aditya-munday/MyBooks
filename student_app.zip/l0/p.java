package l0;

import Z.C0179k;
import c5.C0324M;
import p0.X;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* loaded from: classes.dex */
public final class p {

    /* renamed from: a, reason: collision with root package name */
    public final v f8353a;

    /* renamed from: b, reason: collision with root package name */
    public final C0617f f8354b;

    /* renamed from: c, reason: collision with root package name */
    public String f8355c;

    /* renamed from: d, reason: collision with root package name */
    public final /* synthetic */ r f8356d;

    public p(r rVar, v vVar, int i6, X x6, InterfaceC0615d interfaceC0615d) {
        this.f8356d = rVar;
        this.f8353a = vVar;
        this.f8354b = new C0617f(i6, vVar, new C0324M(this, 5), new C0179k(rVar, x6, 23, false), interfaceC0615d);
    }
}
