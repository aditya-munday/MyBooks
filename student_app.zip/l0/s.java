package l0;

import S.P;
import S.Q;
import S.S;
import p0.AbstractC0699q;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* loaded from: classes.dex */
public final class s extends AbstractC0699q {

    /* renamed from: c, reason: collision with root package name */
    public final /* synthetic */ int f8382c;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public /* synthetic */ s(S s3, int i6) {
        super(s3);
        this.f8382c = i6;
    }

    @Override // p0.AbstractC0699q, S.S
    public final P f(int i6, P p6, boolean z6) {
        switch (this.f8382c) {
            case 0:
                super.f(i6, p6, z6);
                p6.f2457f = true;
                return p6;
            default:
                super.f(i6, p6, z6);
                p6.f2457f = true;
                return p6;
        }
    }

    @Override // p0.AbstractC0699q, S.S
    public final Q m(int i6, Q q6, long j6) {
        switch (this.f8382c) {
            case 0:
                super.m(i6, q6, j6);
                q6.f2470k = true;
                return q6;
            default:
                super.m(i6, q6, j6);
                q6.f2470k = true;
                return q6;
        }
    }
}
