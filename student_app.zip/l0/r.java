package l0;

import E2.Z;
import E2.e0;
import S.C0123p;
import S.T;
import V.AbstractC0133a;
import Z.C0179k;
import Z.O;
import Z.o0;
import android.net.Uri;
import android.os.Handler;
import androidx.datastore.preferences.protobuf.C0223k;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import javax.net.SocketFactory;
import p0.InterfaceC0705x;
import p0.InterfaceC0706y;
import p0.X;
import p0.Y;
import p0.f0;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* loaded from: classes.dex */
public final class r implements InterfaceC0706y {

    /* renamed from: A, reason: collision with root package name */
    public long f8362A;

    /* renamed from: B, reason: collision with root package name */
    public long f8363B;

    /* renamed from: C, reason: collision with root package name */
    public long f8364C;

    /* renamed from: D, reason: collision with root package name */
    public boolean f8365D;

    /* renamed from: E, reason: collision with root package name */
    public boolean f8366E;

    /* renamed from: F, reason: collision with root package name */
    public boolean f8367F;

    /* renamed from: G, reason: collision with root package name */
    public boolean f8368G;

    /* renamed from: H, reason: collision with root package name */
    public boolean f8369H;

    /* renamed from: I, reason: collision with root package name */
    public int f8370I;

    /* renamed from: J, reason: collision with root package name */
    public boolean f8371J;
    public final t0.f o;

    /* renamed from: p, reason: collision with root package name */
    public final Handler f8372p = V.C.p(null);

    /* renamed from: q, reason: collision with root package name */
    public final c0.h f8373q;

    /* renamed from: r, reason: collision with root package name */
    public final C0624m f8374r;

    /* renamed from: s, reason: collision with root package name */
    public final ArrayList f8375s;

    /* renamed from: t, reason: collision with root package name */
    public final ArrayList f8376t;

    /* renamed from: u, reason: collision with root package name */
    public final X2.b f8377u;

    /* renamed from: v, reason: collision with root package name */
    public final InterfaceC0615d f8378v;

    /* renamed from: w, reason: collision with root package name */
    public InterfaceC0705x f8379w;

    /* renamed from: x, reason: collision with root package name */
    public Z f8380x;
    public IOException y;

    /* renamed from: z, reason: collision with root package name */
    public C0223k f8381z;

    public r(t0.f fVar, InterfaceC0615d interfaceC0615d, Uri uri, X2.b bVar, String str, SocketFactory socketFactory) {
        this.o = fVar;
        this.f8378v = interfaceC0615d;
        this.f8377u = bVar;
        c0.h hVar = new c0.h(this, 1);
        this.f8373q = hVar;
        this.f8374r = new C0624m(hVar, hVar, str, uri, socketFactory);
        this.f8375s = new ArrayList();
        this.f8376t = new ArrayList();
        this.f8363B = -9223372036854775807L;
        this.f8362A = -9223372036854775807L;
        this.f8364C = -9223372036854775807L;
    }

    public static void a(r rVar) {
        ArrayList arrayList = rVar.f8375s;
        rVar.f8365D = true;
        for (int i6 = 0; i6 < arrayList.size(); i6++) {
            rVar.f8365D &= ((q) arrayList.get(i6)).f8360d;
        }
    }

    public static void f(r rVar) {
        ArrayList arrayList = rVar.f8375s;
        if (!rVar.f8367F && !rVar.f8368G) {
            int i6 = 0;
            for (int i7 = 0; i7 < arrayList.size(); i7++) {
                if (((q) arrayList.get(i7)).f8359c.t() == null) {
                    return;
                }
            }
            rVar.f8368G = true;
            E2.I u6 = E2.I.u(arrayList);
            E2.r.d(4, "initialCapacity");
            Object[] objArr = new Object[4];
            int i8 = 0;
            while (i6 < u6.size()) {
                X x6 = ((q) u6.get(i6)).f8359c;
                String num = Integer.toString(i6);
                C0123p t6 = x6.t();
                t6.getClass();
                T t7 = new T(num, t6);
                int i9 = i8 + 1;
                int e = E2.C.e(objArr.length, i9);
                if (e > objArr.length) {
                    objArr = Arrays.copyOf(objArr, e);
                }
                objArr[i8] = t7;
                i6++;
                i8 = i9;
            }
            rVar.f8380x = E2.I.s(i8, objArr);
            InterfaceC0705x interfaceC0705x = rVar.f8379w;
            interfaceC0705x.getClass();
            interfaceC0705x.i(rVar);
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v4, types: [androidx.datastore.preferences.protobuf.k, java.io.IOException] */
    /* JADX WARN: Type inference failed for: r5v0, types: [androidx.datastore.preferences.protobuf.k, java.io.IOException] */
    public static void g(r rVar) {
        ArrayList arrayList = rVar.f8376t;
        ArrayList arrayList2 = rVar.f8375s;
        rVar.f8371J = true;
        C0624m c0624m = rVar.f8374r;
        c0624m.getClass();
        try {
            c0624m.close();
            y yVar = new y(new C0179k(c0624m));
            c0624m.f8348w = yVar;
            yVar.a(c0624m.c(c0624m.f8347v));
            c0624m.y = null;
            c0624m.f8338E = false;
            c0624m.f8335B = null;
        } catch (IOException e) {
            c0624m.f8341p.c(new IOException(e));
        }
        InterfaceC0615d d6 = rVar.f8378v.d();
        if (d6 == null) {
            rVar.f8381z = new IOException("No fallback data channel factory for TCP retry");
            return;
        }
        ArrayList arrayList3 = new ArrayList(arrayList2.size());
        ArrayList arrayList4 = new ArrayList(arrayList.size());
        for (int i6 = 0; i6 < arrayList2.size(); i6++) {
            q qVar = (q) arrayList2.get(i6);
            boolean z6 = qVar.f8360d;
            p pVar = qVar.f8357a;
            if (!z6) {
                q qVar2 = new q(rVar, pVar.f8353a, i6, d6);
                arrayList3.add(qVar2);
                p pVar2 = qVar2.f8357a;
                qVar2.f8358b.f(pVar2.f8354b, rVar.f8373q, 0);
                if (arrayList.contains(pVar)) {
                    arrayList4.add(pVar2);
                }
            } else {
                arrayList3.add(qVar);
            }
        }
        E2.I u6 = E2.I.u(arrayList2);
        arrayList2.clear();
        arrayList2.addAll(arrayList3);
        arrayList.clear();
        arrayList.addAll(arrayList4);
        for (int i7 = 0; i7 < u6.size(); i7++) {
            ((q) u6.get(i7)).a();
        }
    }

    @Override // p0.a0
    public final boolean c() {
        if (!this.f8365D) {
            int i6 = this.f8374r.f8336C;
            if (i6 == 2 || i6 == 1) {
                return true;
            }
            return false;
        }
        return false;
    }

    @Override // p0.InterfaceC0706y
    public final long d(s0.t[] tVarArr, boolean[] zArr, Y[] yArr, boolean[] zArr2, long j6) {
        ArrayList arrayList;
        for (int i6 = 0; i6 < tVarArr.length; i6++) {
            if (yArr[i6] != null && (tVarArr[i6] == null || !zArr[i6])) {
                yArr[i6] = null;
            }
        }
        ArrayList arrayList2 = this.f8376t;
        arrayList2.clear();
        int i7 = 0;
        while (true) {
            int length = tVarArr.length;
            arrayList = this.f8375s;
            if (i7 >= length) {
                break;
            }
            s0.t tVar = tVarArr[i7];
            if (tVar != null) {
                T i8 = tVar.i();
                Z z6 = this.f8380x;
                z6.getClass();
                int indexOf = z6.indexOf(i8);
                q qVar = (q) arrayList.get(indexOf);
                qVar.getClass();
                arrayList2.add(qVar.f8357a);
                if (this.f8380x.contains(i8) && yArr[i7] == null) {
                    yArr[i7] = new C.b(this, indexOf);
                    zArr2[i7] = true;
                }
            }
            i7++;
        }
        for (int i9 = 0; i9 < arrayList.size(); i9++) {
            q qVar2 = (q) arrayList.get(i9);
            if (!arrayList2.contains(qVar2.f8357a)) {
                qVar2.a();
            }
        }
        this.f8369H = true;
        if (j6 != 0) {
            this.f8362A = j6;
            this.f8363B = j6;
            this.f8364C = j6;
        }
        i();
        return j6;
    }

    @Override // p0.a0
    public final boolean e(O o) {
        return c();
    }

    public final boolean h() {
        if (this.f8363B != -9223372036854775807L) {
            return true;
        }
        return false;
    }

    public final void i() {
        ArrayList arrayList;
        boolean z6;
        boolean z7 = true;
        int i6 = 0;
        while (true) {
            arrayList = this.f8376t;
            if (i6 >= arrayList.size()) {
                break;
            }
            if (((p) arrayList.get(i6)).f8355c != null) {
                z6 = true;
            } else {
                z6 = false;
            }
            z7 &= z6;
            i6++;
        }
        if (z7 && this.f8369H) {
            C0624m c0624m = this.f8374r;
            c0624m.f8344s.addAll(arrayList);
            c0624m.b();
        }
    }

    @Override // p0.a0
    public final long k() {
        return p();
    }

    @Override // p0.InterfaceC0706y
    public final long l() {
        if (this.f8366E) {
            this.f8366E = false;
            return 0L;
        }
        return -9223372036854775807L;
    }

    @Override // p0.InterfaceC0706y
    public final void m(InterfaceC0705x interfaceC0705x, long j6) {
        C0624m c0624m = this.f8374r;
        this.f8379w = interfaceC0705x;
        try {
            c0624m.getClass();
            try {
                c0624m.f8348w.a(c0624m.c(c0624m.f8347v));
                D2.i iVar = c0624m.f8346u;
                iVar.j(iVar.g(4, c0624m.y, e0.f744u, c0624m.f8347v));
            } catch (IOException e) {
                V.C.g(c0624m.f8348w);
                throw e;
            }
        } catch (IOException e6) {
            this.y = e6;
            V.C.g(c0624m);
        }
    }

    @Override // p0.InterfaceC0706y
    public final f0 n() {
        AbstractC0133a.i(this.f8368G);
        Z z6 = this.f8380x;
        z6.getClass();
        return new f0((T[]) z6.toArray(new T[0]));
    }

    @Override // p0.a0
    public final long p() {
        if (!this.f8365D) {
            ArrayList arrayList = this.f8375s;
            if (!arrayList.isEmpty()) {
                long j6 = this.f8362A;
                if (j6 != -9223372036854775807L) {
                    return j6;
                }
                boolean z6 = true;
                long j7 = Long.MAX_VALUE;
                for (int i6 = 0; i6 < arrayList.size(); i6++) {
                    q qVar = (q) arrayList.get(i6);
                    if (!qVar.f8360d) {
                        j7 = Math.min(j7, qVar.f8359c.n());
                        z6 = false;
                    }
                }
                if (!z6 && j7 != Long.MIN_VALUE) {
                    return j7;
                }
                return 0L;
            }
        }
        return Long.MIN_VALUE;
    }

    @Override // p0.InterfaceC0706y
    public final void q() {
        IOException iOException = this.y;
        if (iOException == null) {
        } else {
            throw iOException;
        }
    }

    @Override // p0.InterfaceC0706y
    public final long s(long j6) {
        if (p() == 0 && !this.f8371J) {
            this.f8364C = j6;
            return j6;
        }
        t(j6);
        this.f8362A = j6;
        if (h()) {
            C0624m c0624m = this.f8374r;
            int i6 = c0624m.f8336C;
            if (i6 != 1) {
                if (i6 == 2) {
                    this.f8363B = j6;
                    c0624m.d(j6);
                    return j6;
                }
                throw new IllegalStateException();
            }
        } else {
            ArrayList arrayList = this.f8375s;
            int i7 = 0;
            while (true) {
                if (i7 >= arrayList.size()) {
                    break;
                }
                if (!((q) arrayList.get(i7)).f8359c.D(j6, this.f8365D)) {
                    this.f8363B = j6;
                    if (this.f8365D) {
                        for (int i8 = 0; i8 < this.f8375s.size(); i8++) {
                            q qVar = (q) this.f8375s.get(i8);
                            AbstractC0133a.i(qVar.f8360d);
                            qVar.f8360d = false;
                            a(qVar.f8361f);
                            qVar.f8358b.f(qVar.f8357a.f8354b, qVar.f8361f.f8373q, 0);
                        }
                        if (this.f8371J) {
                            this.f8374r.e(V.C.Z(j6));
                        } else {
                            this.f8374r.d(j6);
                        }
                    } else {
                        this.f8374r.d(j6);
                    }
                    for (int i9 = 0; i9 < this.f8375s.size(); i9++) {
                        q qVar2 = (q) this.f8375s.get(i9);
                        if (!qVar2.f8360d) {
                            C0618g c0618g = qVar2.f8357a.f8354b.f8298v;
                            c0618g.getClass();
                            synchronized (c0618g.e) {
                                c0618g.f8311k = true;
                            }
                            qVar2.f8359c.B(false);
                            qVar2.f8359c.f9038t = j6;
                        }
                    }
                } else {
                    i7++;
                }
            }
        }
        return j6;
    }

    @Override // p0.InterfaceC0706y
    public final void t(long j6) {
        if (!h()) {
            int i6 = 0;
            while (true) {
                ArrayList arrayList = this.f8375s;
                if (i6 < arrayList.size()) {
                    q qVar = (q) arrayList.get(i6);
                    if (!qVar.f8360d) {
                        qVar.f8359c.g(j6, true);
                    }
                    i6++;
                } else {
                    return;
                }
            }
        }
    }

    @Override // p0.a0
    public final void v(long j6) {
    }

    @Override // p0.InterfaceC0706y
    public final long b(long j6, o0 o0Var) {
        return j6;
    }
}
