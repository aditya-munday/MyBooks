package l0;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* renamed from: l0.j, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0621j {

    /* renamed from: a, reason: collision with root package name */
    public final C0620i f8325a;

    /* renamed from: b, reason: collision with root package name */
    public final long f8326b;

    public C0621j(C0620i c0620i, long j6) {
        this.f8325a = c0620i;
        this.f8326b = j6;
    }
}
