package l0;

import E2.e0;
import S.C0123p;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* renamed from: l0.k, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0622k {

    /* renamed from: a, reason: collision with root package name */
    public final int f8327a;

    /* renamed from: b, reason: collision with root package name */
    public final int f8328b;

    /* renamed from: c, reason: collision with root package name */
    public final C0123p f8329c;

    /* renamed from: d, reason: collision with root package name */
    public final e0 f8330d;
    public final String e;

    public C0622k(C0123p c0123p, int i6, int i7, e0 e0Var, String str) {
        this.f8327a = i6;
        this.f8328b = i7;
        this.f8329c = c0123p;
        this.f8330d = e0.a(e0Var);
        this.e = str;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj != null && C0622k.class == obj.getClass()) {
            C0622k c0622k = (C0622k) obj;
            if (this.f8327a == c0622k.f8327a && this.f8328b == c0622k.f8328b && this.f8329c.equals(c0622k.f8329c)) {
                e0 e0Var = c0622k.f8330d;
                e0 e0Var2 = this.f8330d;
                e0Var2.getClass();
                if (E2.r.f(e0Var, e0Var2) && this.e.equals(c0622k.e)) {
                    return true;
                }
            }
        }
        return false;
    }

    public final int hashCode() {
        return this.e.hashCode() + ((this.f8330d.hashCode() + ((this.f8329c.hashCode() + ((((217 + this.f8327a) * 31) + this.f8328b) * 31)) * 31)) * 31);
    }
}
