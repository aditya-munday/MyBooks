package t2;

import A2.d;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* renamed from: t2.a, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class BinderC0787a extends d {

    /* renamed from: d, reason: collision with root package name */
    public final Object f9685d;

    public BinderC0787a(Object obj) {
        super("com.google.android.gms.dynamic.IObjectWrapper");
        this.f9685d = obj;
    }
}
