package Q4;

import C4.AbstractActivityC0029d;
import C4.AbstractC0034i;
import android.app.Activity;
import android.os.Build;
import android.view.View;
import x3.c;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* loaded from: classes.dex */
public final class a {

    /* renamed from: a, reason: collision with root package name */
    public Activity f2123a;

    /* renamed from: b, reason: collision with root package name */
    public final int f2124b;

    /* renamed from: c, reason: collision with root package name */
    public final c f2125c;

    public a(int i6, AbstractActivityC0029d abstractActivityC0029d, c cVar) {
        this.f2123a = abstractActivityC0029d;
        this.f2124b = i6;
        this.f2125c = cVar;
        cVar.f10281p = this;
    }

    public final int a() {
        if (Build.VERSION.SDK_INT >= 35) {
            Activity activity = this.f2123a;
            int i6 = this.f2124b;
            View findViewById = activity.findViewById(i6);
            if (findViewById != null) {
                return findViewById.getContentSensitivity();
            }
            throw new IllegalArgumentException(AbstractC0034i.i("FlutterView with ID ", i6, "not found"));
        }
        return 2;
    }

    public final void b(int i6) {
        if (Build.VERSION.SDK_INT >= 35) {
            Activity activity = this.f2123a;
            int i7 = this.f2124b;
            View findViewById = activity.findViewById(i7);
            if (findViewById != null) {
                if (findViewById.getContentSensitivity() == i6) {
                    return;
                }
                findViewById.setContentSensitivity(i6);
                findViewById.invalidate();
                return;
            }
            throw new IllegalArgumentException(AbstractC0034i.i("FlutterView with ID ", i7, "not found"));
        }
        throw new IllegalStateException("isSupported() should be called before attempting to set content sensitivity as it is not supported on this device.");
    }
}
