package c5;

import android.hardware.display.DisplayManager;
import java.util.ArrayList;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* renamed from: c5.p, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0352p implements DisplayManager.DisplayListener {

    /* renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f5634a;

    /* renamed from: b, reason: collision with root package name */
    public final DisplayManager f5635b;

    /* renamed from: c, reason: collision with root package name */
    public final /* synthetic */ Object f5636c;

    public /* synthetic */ C0352p(Object obj, DisplayManager displayManager, int i6) {
        this.f5634a = i6;
        this.f5636c = obj;
        this.f5635b = displayManager;
    }

    @Override // android.hardware.display.DisplayManager.DisplayListener
    public final void onDisplayAdded(int i6) {
        switch (this.f5634a) {
            case 0:
                ArrayList arrayList = (ArrayList) this.f5636c;
                int size = arrayList.size();
                int i7 = 0;
                while (i7 < size) {
                    Object obj = arrayList.get(i7);
                    i7++;
                    ((DisplayManager.DisplayListener) obj).onDisplayAdded(i6);
                }
                return;
            case 1:
            default:
                return;
        }
    }

    @Override // android.hardware.display.DisplayManager.DisplayListener
    public final void onDisplayChanged(int i6) {
        switch (this.f5634a) {
            case 0:
                if (this.f5635b.getDisplay(i6) != null) {
                    ArrayList arrayList = (ArrayList) this.f5636c;
                    int size = arrayList.size();
                    int i7 = 0;
                    while (i7 < size) {
                        Object obj = arrayList.get(i7);
                        i7++;
                        ((DisplayManager.DisplayListener) obj).onDisplayChanged(i6);
                    }
                    return;
                }
                return;
            case 1:
                if (i6 == 0) {
                    float refreshRate = this.f5635b.getDisplay(0).getRefreshRate();
                    io.flutter.view.p pVar = (io.flutter.view.p) this.f5636c;
                    pVar.f7395a = (long) (1.0E9d / refreshRate);
                    pVar.f7396b.setRefreshRateFPS(refreshRate);
                    return;
                }
                return;
            default:
                if (i6 == 0) {
                    v0.w.a((v0.w) this.f5636c, this.f5635b.getDisplay(0));
                    return;
                }
                return;
        }
    }

    @Override // android.hardware.display.DisplayManager.DisplayListener
    public final void onDisplayRemoved(int i6) {
        switch (this.f5634a) {
            case 0:
                ArrayList arrayList = (ArrayList) this.f5636c;
                int size = arrayList.size();
                int i7 = 0;
                while (i7 < size) {
                    Object obj = arrayList.get(i7);
                    i7++;
                    ((DisplayManager.DisplayListener) obj).onDisplayRemoved(i6);
                }
                return;
            case 1:
            default:
                return;
        }
    }

    private final void a(int i6) {
    }

    private final void b(int i6) {
    }

    private final void c(int i6) {
    }

    private final void d(int i6) {
    }
}
