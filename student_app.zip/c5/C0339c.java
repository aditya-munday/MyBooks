package c5;

import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import java.lang.ref.ReferenceQueue;
import java.util.HashMap;
import java.util.WeakHashMap;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* renamed from: c5.c, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0339c {

    /* renamed from: a, reason: collision with root package name */
    public final Z4.s f5598a;

    /* renamed from: b, reason: collision with root package name */
    public final WeakHashMap f5599b = new WeakHashMap();

    /* renamed from: c, reason: collision with root package name */
    public final HashMap f5600c = new HashMap();

    /* renamed from: d, reason: collision with root package name */
    public final HashMap f5601d = new HashMap();
    public final ReferenceQueue e = new ReferenceQueue();

    /* renamed from: f, reason: collision with root package name */
    public final HashMap f5602f = new HashMap();

    /* renamed from: g, reason: collision with root package name */
    public final Handler f5603g;

    /* renamed from: h, reason: collision with root package name */
    public final G4.d f5604h;

    /* renamed from: i, reason: collision with root package name */
    public long f5605i;

    /* renamed from: j, reason: collision with root package name */
    public boolean f5606j;

    /* renamed from: k, reason: collision with root package name */
    public final long f5607k;

    public C0339c(Z4.s sVar) {
        this.f5598a = sVar;
        Handler handler = new Handler(Looper.getMainLooper());
        this.f5603g = handler;
        G4.d dVar = new G4.d(this, 13);
        this.f5604h = dVar;
        this.f5605i = 65536L;
        this.f5607k = 3000L;
        handler.postDelayed(dVar, 3000L);
    }

    public final void a(long j6, Object obj) {
        q5.h.e(obj, "instance");
        f();
        c(j6, obj);
    }

    public final long b(Object obj) {
        q5.h.e(obj, "instance");
        f();
        if (!d(obj)) {
            long j6 = this.f5605i;
            this.f5605i = 1 + j6;
            c(j6, obj);
            return j6;
        }
        throw new IllegalArgumentException(("Instance of " + obj.getClass() + " has already been added.").toString());
    }

    public final void c(long j6, Object obj) {
        if (j6 >= 0) {
            Long valueOf = Long.valueOf(j6);
            HashMap hashMap = this.f5600c;
            if (!hashMap.containsKey(valueOf)) {
                C0338b c0338b = new C0338b(obj, this.e);
                this.f5599b.put(c0338b, Long.valueOf(j6));
                hashMap.put(Long.valueOf(j6), c0338b);
                this.f5602f.put(c0338b, Long.valueOf(j6));
                this.f5601d.put(Long.valueOf(j6), obj);
                return;
            }
            throw new IllegalArgumentException(("Identifier has already been added: " + j6).toString());
        }
        throw new IllegalArgumentException(("Identifier must be >= 0: " + j6).toString());
    }

    public final boolean d(Object obj) {
        f();
        if (obj != null) {
            if (this.f5599b.containsKey(new C0338b(obj))) {
                return true;
            }
            return false;
        }
        return false;
    }

    public final Object e(long j6) {
        f();
        C0338b c0338b = (C0338b) this.f5600c.get(Long.valueOf(j6));
        if (c0338b != null) {
            return c0338b.get();
        }
        return null;
    }

    public final void f() {
        if (this.f5606j) {
            Log.w("PigeonInstanceManager", "The manager was used after calls to the PigeonFinalizationListener has been stopped.");
        }
    }
}
