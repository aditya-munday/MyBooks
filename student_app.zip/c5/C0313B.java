package c5;

import C4.AbstractC0034i;
import android.util.Log;
import g5.C0455d;
import g5.C0456e;
import java.util.List;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* renamed from: c5.B, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final /* synthetic */ class C0313B implements p5.l {
    public final /* synthetic */ int o;

    /* renamed from: p, reason: collision with root package name */
    public final /* synthetic */ Object f5541p;

    public /* synthetic */ C0313B(Object obj, int i6) {
        this.o = i6;
        this.f5541p = obj;
    }

    @Override // p5.l
    public final Object a(Object obj) {
        List T6;
        List T7;
        switch (this.o) {
            case 0:
                A.c cVar = (A.c) this.f5541p;
                C0456e c0456e = (C0456e) obj;
                Throwable a6 = C0456e.a(c0456e.o);
                if (a6 != null) {
                    if (a6 instanceof C0337a) {
                        C0337a c0337a = (C0337a) a6;
                        T6 = h5.e.T(c0337a.o, c0337a.f5592p, c0337a.f5593q);
                    } else {
                        T6 = h5.e.T(a6.getClass().getSimpleName(), a6.toString(), AbstractC0034i.k("Cause: ", a6.getCause(), ", Stacktrace: ", Log.getStackTraceString(a6)));
                    }
                    cVar.g(T6);
                } else {
                    Object obj2 = c0456e.o;
                    if (obj2 instanceof C0455d) {
                        obj2 = null;
                    }
                    cVar.g(android.support.v4.media.session.a.z((Boolean) obj2));
                }
                return g5.h.f6800a;
            case 1:
                A.c cVar2 = (A.c) this.f5541p;
                C0456e c0456e2 = (C0456e) obj;
                Throwable a7 = C0456e.a(c0456e2.o);
                if (a7 != null) {
                    if (a7 instanceof C0337a) {
                        C0337a c0337a2 = (C0337a) a7;
                        T7 = h5.e.T(c0337a2.o, c0337a2.f5592p, c0337a2.f5593q);
                    } else {
                        T7 = h5.e.T(a7.getClass().getSimpleName(), a7.toString(), AbstractC0034i.k("Cause: ", a7.getCause(), ", Stacktrace: ", Log.getStackTraceString(a7)));
                    }
                    cVar2.g(T7);
                } else {
                    Object obj3 = c0456e2.o;
                    if (obj3 instanceof C0455d) {
                        obj3 = null;
                    }
                    cVar2.g(android.support.v4.media.session.a.z((String) obj3));
                }
                return g5.h.f6800a;
            default:
                ((p5.l) this.f5541p).a(new C0325N(((C0456e) obj).o));
                return g5.h.f6800a;
        }
    }
}
