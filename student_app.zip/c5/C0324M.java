package c5;

import S.C0123p;
import android.content.Intent;
import android.view.View;
import androidx.datastore.preferences.protobuf.AbstractC0227o;
import e1.C0409C;
import java.util.List;
import java.util.concurrent.ScheduledFuture;
import org.apache.tika.fork.ContentHandlerProxy;
import org.apache.tika.utils.StringUtils;
import s0.C0750h;
import s0.C0753k;
import v3.AbstractC0840D;
import v3.C0842F;
import x0.AbstractC0880b;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* renamed from: c5.M, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final /* synthetic */ class C0324M implements M4.c, d5.c, W.v, i0.w, s0.o, C2.d {
    public final /* synthetic */ int o;

    /* renamed from: p, reason: collision with root package name */
    public final /* synthetic */ Object f5551p;

    public /* synthetic */ C0324M(Object obj, int i6) {
        this.o = i6;
        this.f5551p = obj;
    }

    @Override // d5.c
    public boolean a(View view) {
        for (Class cls : (Class[]) this.f5551p) {
            if (cls.isInstance(view)) {
                return true;
            }
        }
        return false;
    }

    @Override // i0.w
    public int b(Object obj) {
        C0123p c0123p = (C0123p) this.f5551p;
        i0.p pVar = (i0.p) obj;
        String str = pVar.f6904b;
        if ((!str.equals(c0123p.f2626n) && !str.equals(i0.x.b(c0123p))) || !pVar.c(c0123p, false) || !pVar.d(c0123p)) {
            return 0;
        }
        return 1;
    }

    @Override // W.v
    public void c(long j6, V.v vVar) {
        switch (this.o) {
            case 2:
                AbstractC0880b.f(j6, vVar, ((C0409C) this.f5551p).f6030c);
                return;
            default:
                AbstractC0880b.g(j6, vVar, ((C0409C) this.f5551p).f6030c);
                return;
        }
    }

    @Override // s0.o
    public E2.Z d(int i6, S.T t6, int[] iArr) {
        C0753k c0753k = (C0753k) this.f5551p;
        E2.F t7 = E2.I.t();
        for (int i7 = 0; i7 < t6.f2476a; i7++) {
            t7.a(new C0750h(i6, t6, i7, c0753k, iArr[i7]));
        }
        return t7.f();
    }

    @Override // M4.c
    public void g(Object obj) {
        Object obj2 = ((C0342f) this.f5551p).f5618p;
        if (obj instanceof List) {
            List list = (List) obj;
            if (list.size() > 1) {
                Object obj3 = list.get(0);
                q5.h.c(obj3, "null cannot be cast to non-null type kotlin.String");
                Object obj4 = list.get(1);
                q5.h.c(obj4, "null cannot be cast to non-null type kotlin.String");
                AbstractC0227o.m(new C0337a((String) obj3, (String) obj4, (String) list.get(2)), "X509Certificate", obj2);
                return;
            }
            return;
        }
        AbstractC0227o.p("channel-error", "Unable to establish connection on channel: 'dev.flutter.pigeon.webview_flutter_android.X509Certificate.pigeon_newInstance'.", StringUtils.EMPTY, "X509Certificate", obj2);
    }

    @Override // C2.d
    public void v(C2.i iVar) {
        switch (this.o) {
            case 8:
                AbstractC0840D.b((Intent) this.f5551p);
                return;
            case ContentHandlerProxy.PROCESSING_INSTRUCTION /* 9 */:
                ((C0842F) this.f5551p).f9960b.d(null);
                return;
            default:
                ((ScheduledFuture) this.f5551p).cancel(false);
                return;
        }
    }
}
