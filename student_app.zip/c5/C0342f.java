package c5;

import g5.C0455d;
import g5.C0456e;
import org.apache.tika.fork.ContentHandlerProxy;
import org.apache.tika.pipes.PipesServer;
import org.apache.tika.utils.XMLReaderUtils;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* renamed from: c5.f, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final /* synthetic */ class C0342f implements p5.l {
    public final /* synthetic */ int o;

    /* renamed from: p, reason: collision with root package name */
    public final /* synthetic */ Object f5618p;

    public /* synthetic */ C0342f(Object obj, int i6) {
        this.o = i6;
        this.f5618p = obj;
    }

    @Override // p5.l
    public final Object a(Object obj) {
        C0456e c0456e = (C0456e) obj;
        switch (this.o) {
            case 0:
                Object obj2 = c0456e.o;
                if (obj2 instanceof C0455d) {
                    C0343g.l("WebResourceRequest", this.f5618p, C0456e.a(obj2));
                }
                return g5.h.f6800a;
            case 1:
                Object obj3 = c0456e.o;
                if (obj3 instanceof C0455d) {
                    C0343g.l("HttpAuthHandler", this.f5618p, C0456e.a(obj3));
                }
                return g5.h.f6800a;
            case 2:
                Object obj4 = c0456e.o;
                if (obj4 instanceof C0455d) {
                    C0343g.l("AndroidMessage", this.f5618p, C0456e.a(obj4));
                }
                return g5.h.f6800a;
            case 3:
                Object obj5 = c0456e.o;
                if (obj5 instanceof C0455d) {
                    C0343g.l("ClientCertRequest", this.f5618p, C0456e.a(obj5));
                }
                return g5.h.f6800a;
            case 4:
                Object obj6 = c0456e.o;
                if (obj6 instanceof C0455d) {
                    C0343g.l("PrivateKey", this.f5618p, C0456e.a(obj6));
                }
                return g5.h.f6800a;
            case 5:
                Object obj7 = c0456e.o;
                if (obj7 instanceof C0455d) {
                    C0343g.l("X509Certificate", this.f5618p, C0456e.a(obj7));
                }
                return g5.h.f6800a;
            case 6:
                Object obj8 = c0456e.o;
                if (obj8 instanceof C0455d) {
                    C0343g.l("SslErrorHandler", this.f5618p, C0456e.a(obj8));
                }
                return g5.h.f6800a;
            case 7:
                Object obj9 = c0456e.o;
                if (obj9 instanceof C0455d) {
                    C0343g.l("SslError", this.f5618p, C0456e.a(obj9));
                }
                return g5.h.f6800a;
            case 8:
                Object obj10 = c0456e.o;
                if (obj10 instanceof C0455d) {
                    C0343g.l("SslCertificateDName", this.f5618p, C0456e.a(obj10));
                }
                return g5.h.f6800a;
            case ContentHandlerProxy.PROCESSING_INSTRUCTION /* 9 */:
                Object obj11 = c0456e.o;
                if (obj11 instanceof C0455d) {
                    C0343g.l("SslCertificate", this.f5618p, C0456e.a(obj11));
                }
                return g5.h.f6800a;
            case 10:
                Object obj12 = c0456e.o;
                if (obj12 instanceof C0455d) {
                    C0343g.l("Certificate", this.f5618p, C0456e.a(obj12));
                }
                return g5.h.f6800a;
            case 11:
                Object obj13 = c0456e.o;
                if (obj13 instanceof C0455d) {
                    C0343g.l("WebViewClient", this.f5618p, C0456e.a(obj13));
                }
                return g5.h.f6800a;
            case 12:
                Object obj14 = c0456e.o;
                if (obj14 instanceof C0455d) {
                    C0343g.l("WebResourceError", this.f5618p, C0456e.a(obj14));
                }
                return g5.h.f6800a;
            case 13:
                Object obj15 = c0456e.o;
                if (obj15 instanceof C0455d) {
                    C0343g.l("WebViewPoint", this.f5618p, C0456e.a(obj15));
                }
                return g5.h.f6800a;
            case 14:
                Object obj16 = c0456e.o;
                if (obj16 instanceof C0455d) {
                    C0343g.l("ConsoleMessage", this.f5618p, C0456e.a(obj16));
                }
                return g5.h.f6800a;
            case 15:
                Object obj17 = c0456e.o;
                if (obj17 instanceof C0455d) {
                    C0343g.l("CookieManager", this.f5618p, C0456e.a(obj17));
                }
                return g5.h.f6800a;
            case 16:
                Object obj18 = c0456e.o;
                if (obj18 instanceof C0455d) {
                    C0343g.l("WebView", this.f5618p, C0456e.a(obj18));
                }
                return g5.h.f6800a;
            case PipesServer.TIMEOUT_EXIT_CODE /* 17 */:
                Object obj19 = c0456e.o;
                if (obj19 instanceof C0455d) {
                    C0343g.l("WebSettings", this.f5618p, C0456e.a(obj19));
                }
                return g5.h.f6800a;
            case 18:
                Object obj20 = c0456e.o;
                if (obj20 instanceof C0455d) {
                    C0343g.l("FlutterAssetManager", this.f5618p, C0456e.a(obj20));
                }
                return g5.h.f6800a;
            case 19:
                Object obj21 = c0456e.o;
                if (obj21 instanceof C0455d) {
                    C0343g.l("WebStorage", this.f5618p, C0456e.a(obj21));
                }
                return g5.h.f6800a;
            case XMLReaderUtils.DEFAULT_MAX_ENTITY_EXPANSIONS /* 20 */:
                Object obj22 = c0456e.o;
                if (obj22 instanceof C0455d) {
                    C0343g.l("FileChooserParams", this.f5618p, C0456e.a(obj22));
                }
                return g5.h.f6800a;
            case 21:
                Object obj23 = c0456e.o;
                if (obj23 instanceof C0455d) {
                    C0343g.l("PermissionRequest", this.f5618p, C0456e.a(obj23));
                }
                return g5.h.f6800a;
            case 22:
                Object obj24 = c0456e.o;
                if (obj24 instanceof C0455d) {
                    C0343g.l("CustomViewCallback", this.f5618p, C0456e.a(obj24));
                }
                return g5.h.f6800a;
            case 23:
                Object obj25 = c0456e.o;
                if (obj25 instanceof C0455d) {
                    C0343g.l("View", this.f5618p, C0456e.a(obj25));
                }
                return g5.h.f6800a;
            case 24:
                Object obj26 = c0456e.o;
                if (obj26 instanceof C0455d) {
                    C0343g.l("GeolocationPermissionsCallback", this.f5618p, C0456e.a(obj26));
                }
                return g5.h.f6800a;
            default:
                Object obj27 = c0456e.o;
                if (obj27 instanceof C0455d) {
                    C0343g.l("WebResourceResponse", this.f5618p, C0456e.a(obj27));
                }
                return g5.h.f6800a;
        }
    }
}
