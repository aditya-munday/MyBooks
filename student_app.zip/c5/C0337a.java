package c5;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* renamed from: c5.a, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0337a extends Throwable {
    public final String o;

    /* renamed from: p, reason: collision with root package name */
    public final String f5592p;

    /* renamed from: q, reason: collision with root package name */
    public final Object f5593q;

    public C0337a(String str, String str2, String str3) {
        this.o = str;
        this.f5592p = str2;
        this.f5593q = str3;
    }

    @Override // java.lang.Throwable
    public final String getMessage() {
        return this.f5592p;
    }
}
