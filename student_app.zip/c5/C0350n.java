package c5;

import android.content.Context;
import android.hardware.display.DisplayManager;
import java.util.ArrayList;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* renamed from: c5.n, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0350n {

    /* renamed from: a, reason: collision with root package name */
    public final J2.k f5633a;

    public C0350n(J2.k kVar, int i6) {
        switch (i6) {
            case 1:
                q5.h.e(kVar, "pigeonRegistrar");
                this.f5633a = kVar;
                return;
            case 2:
                q5.h.e(kVar, "pigeonRegistrar");
                this.f5633a = kVar;
                return;
            case 3:
                q5.h.e(kVar, "pigeonRegistrar");
                this.f5633a = kVar;
                return;
            case 4:
                q5.h.e(kVar, "pigeonRegistrar");
                this.f5633a = kVar;
                return;
            case 5:
                q5.h.e(kVar, "pigeonRegistrar");
                this.f5633a = kVar;
                return;
            case 6:
                q5.h.e(kVar, "pigeonRegistrar");
                this.f5633a = kVar;
                return;
            default:
                q5.h.e(kVar, "pigeonRegistrar");
                this.f5633a = kVar;
                return;
        }
    }

    public d0 a() {
        DisplayManager displayManager = (DisplayManager) ((Context) this.f5633a.f1305r).getSystemService("display");
        ArrayList N5 = android.support.v4.media.session.a.N(displayManager);
        d0 d0Var = new d0(this);
        ArrayList N6 = android.support.v4.media.session.a.N(displayManager);
        N6.removeAll(N5);
        if (!N6.isEmpty()) {
            int size = N6.size();
            int i6 = 0;
            while (i6 < size) {
                Object obj = N6.get(i6);
                i6++;
                displayManager.unregisterDisplayListener((DisplayManager.DisplayListener) obj);
                displayManager.registerDisplayListener(new C0352p(N6, displayManager, 0), null);
            }
        }
        return d0Var;
    }
}
