package c5;

import android.media.MediaCodec;
import android.media.MediaCrypto;
import android.media.MediaFormat;
import android.os.Build;
import android.os.SystemClock;
import android.os.Trace;
import android.text.TextUtils;
import android.util.Log;
import android.view.Surface;
import android.webkit.WebSettings;
import androidx.datastore.preferences.protobuf.AbstractC0227o;
import androidx.preference.EditTextPreference;
import androidx.preference.Preference;
import b3.C0261a;
import com.google.firebase.components.ComponentRegistrar;
import com.shockwave.pdfium.R;
import e2.InterfaceC0418a;
import f4.InterfaceC0445a;
import java.io.IOException;
import java.nio.ShortBuffer;
import java.util.ArrayList;
import java.util.List;
import java.util.NoSuchElementException;
import org.apache.tika.fork.ContentHandlerProxy;
import org.apache.tika.utils.StringUtils;
import org.chromium.support_lib_boundary.WebSettingsBoundaryInterface;
import org.chromium.support_lib_boundary.WebkitToCompatConverterBoundaryInterface;
import x0.InterfaceC0878A;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* renamed from: c5.j, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0346j implements InterfaceC0418a, InterfaceC0445a, h1.a, i0.l, i1.c, k4.a, t0.j, q0.m, t0.p, x0.q {

    /* renamed from: p, reason: collision with root package name */
    public static C0346j f5620p;

    /* renamed from: q, reason: collision with root package name */
    public static C0346j f5621q;
    public final /* synthetic */ int o;

    public /* synthetic */ C0346j(int i6) {
        this.o = i6;
    }

    public static MediaCodec d(Q2.n nVar) {
        String str = ((i0.p) nVar.f2107a).f6903a;
        Trace.beginSection("createCodec:" + str);
        MediaCodec createByCodecName = MediaCodec.createByCodecName(str);
        Trace.endSection();
        return createByCodecName;
    }

    public static void p(WebSettings webSettings, boolean z6) {
        X2.b bVar;
        if (s1.j.f9482b.b()) {
            try {
                bVar = new X2.b((WebSettingsBoundaryInterface) Q5.a.g(WebSettingsBoundaryInterface.class, ((WebkitToCompatConverterBoundaryInterface) s1.k.f9483a.o).convertSettings(webSettings)));
            } catch (ClassCastException e) {
                if (Build.VERSION.SDK_INT == 30 && "android.webkit.WebSettingsWrapper".equals(webSettings.getClass().getCanonicalName())) {
                    Log.e("WebSettingsCompat", "Error converting WebSettings to Chrome implementation. All AndroidX method calls on this WebSettings instance will be no-op calls. See https://crbug.com/388824130 for more info.", e);
                    bVar = new X2.b((Object) null);
                } else {
                    throw e;
                }
            }
            bVar.F(z6);
            return;
        }
        throw new UnsupportedOperationException("This method is not supported by the current version of the framework and the current WebView APK");
    }

    /* JADX WARN: Removed duplicated region for block: B:18:0x004b  */
    @Override // i0.l
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public i0.m D(Q2.n nVar) {
        int i6;
        MediaCodec mediaCodec = null;
        try {
            mediaCodec = d(nVar);
            Trace.beginSection("configureCodec");
            Surface surface = (Surface) nVar.e;
            if (surface == null && ((i0.p) nVar.f2107a).f6909h && Build.VERSION.SDK_INT >= 35) {
                i6 = 8;
            } else {
                i6 = 0;
            }
            mediaCodec.configure((MediaFormat) nVar.f2109c, surface, (MediaCrypto) nVar.f2111f, i6);
            Trace.endSection();
            Trace.beginSection("startCodec");
            mediaCodec.start();
            Trace.endSection();
            return new i0.y(mediaCodec, (i0.k) nVar.f2108b);
        } catch (IOException e) {
            e = e;
            if (mediaCodec != null) {
                mediaCodec.release();
            }
            throw e;
        } catch (RuntimeException e6) {
            e = e6;
            if (mediaCodec != null) {
            }
            throw e;
        }
    }

    @Override // q0.m
    public long b() {
        throw new NoSuchElementException();
    }

    @Override // q0.m
    public long c() {
        throw new NoSuchElementException();
    }

    public List e(ComponentRegistrar componentRegistrar) {
        ArrayList arrayList = new ArrayList();
        for (C0261a c0261a : componentRegistrar.getComponents()) {
            String str = c0261a.f5300a;
            if (str != null) {
                c0261a = new C0261a(str, c0261a.f5301b, c0261a.f5302c, c0261a.f5303d, c0261a.e, new T4.d(str, c0261a, 11), c0261a.f5305g);
            }
            arrayList.add(c0261a);
        }
        return arrayList;
    }

    @Override // t0.j
    public /* bridge */ /* synthetic */ void f(t0.l lVar, long j6, long j7) {
    }

    @Override // x0.q
    public void g() {
        throw new UnsupportedOperationException();
    }

    @Override // e2.InterfaceC0418a
    public long h() {
        return SystemClock.elapsedRealtime();
    }

    @Override // t0.j
    public /* bridge */ /* synthetic */ void i(t0.l lVar, long j6, long j7, boolean z6) {
    }

    @Override // i1.c
    public void k() {
        Log.d("ProfileInstaller", "DIAGNOSTIC_PROFILE_IS_COMPRESSED");
    }

    @Override // h1.a
    public CharSequence l(Preference preference) {
        EditTextPreference editTextPreference = (EditTextPreference) preference;
        if (!TextUtils.isEmpty(null)) {
            return null;
        }
        return editTextPreference.o.getString(R.string.not_set);
    }

    @Override // i1.c
    public void m(int i6, Object obj) {
        String str;
        switch (i6) {
            case 1:
                str = "RESULT_INSTALL_SUCCESS";
                break;
            case 2:
                str = "RESULT_ALREADY_INSTALLED";
                break;
            case 3:
                str = "RESULT_UNSUPPORTED_ART_VERSION";
                break;
            case 4:
                str = "RESULT_NOT_WRITABLE";
                break;
            case 5:
                str = "RESULT_DESIRED_FORMAT_UNSUPPORTED";
                break;
            case 6:
                str = "RESULT_BASELINE_PROFILE_NOT_FOUND";
                break;
            case 7:
                str = "RESULT_IO_EXCEPTION";
                break;
            case 8:
                str = "RESULT_PARSE_EXCEPTION";
                break;
            case ContentHandlerProxy.PROCESSING_INSTRUCTION /* 9 */:
            default:
                str = StringUtils.EMPTY;
                break;
            case 10:
                str = "RESULT_INSTALL_SKIP_FILE_SUCCESS";
                break;
            case 11:
                str = "RESULT_DELETE_SKIP_FILE_SUCCESS";
                break;
        }
        if (i6 != 6 && i6 != 7 && i6 != 8) {
            Log.d("ProfileInstaller", str);
        } else {
            Log.e("ProfileInstaller", str, (Throwable) obj);
        }
    }

    public void n(ShortBuffer shortBuffer, int i6, ShortBuffer shortBuffer2, int i7, int i8) {
        switch (this.o) {
            case 8:
                if (i6 >= i7) {
                    if (i8 != 1 && i8 != 2) {
                        throw new IllegalArgumentException(AbstractC0227o.d(i8, "Illegal use of DownsampleAudioResampler. Channels:"));
                    }
                    int remaining = shortBuffer.remaining() / i8;
                    int ceil = (int) Math.ceil((i7 / i6) * remaining);
                    int i9 = remaining - ceil;
                    float f6 = ceil;
                    float f7 = f6 / f6;
                    float f8 = i9;
                    float f9 = f8 / f8;
                    while (ceil > 0 && i9 > 0) {
                        if (f7 >= f9) {
                            shortBuffer2.put(shortBuffer.get());
                            if (i8 == 2) {
                                shortBuffer2.put(shortBuffer.get());
                            }
                            ceil--;
                            f7 = ceil / f6;
                        } else {
                            shortBuffer.position(shortBuffer.position() + i8);
                            i9--;
                            f9 = i9 / f8;
                        }
                    }
                    return;
                }
                throw new IllegalArgumentException("Illegal use of DownsampleAudioResampler");
            default:
                if (i6 <= i7) {
                    if (i8 != 1 && i8 != 2) {
                        throw new IllegalArgumentException(AbstractC0227o.d(i8, "Illegal use of UpsampleAudioResampler. Channels:"));
                    }
                    int remaining2 = shortBuffer.remaining() / i8;
                    int ceil2 = ((int) Math.ceil((i7 / i6) * remaining2)) - remaining2;
                    float f10 = remaining2;
                    float f11 = f10 / f10;
                    float f12 = ceil2;
                    float f13 = f12 / f12;
                    while (remaining2 > 0 && ceil2 > 0) {
                        if (f11 >= f13) {
                            shortBuffer2.put(shortBuffer.get());
                            if (i8 == 2) {
                                shortBuffer2.put(shortBuffer.get());
                            }
                            remaining2--;
                            f11 = remaining2 / f10;
                        } else {
                            shortBuffer2.put(shortBuffer2.get(shortBuffer2.position() - i8));
                            if (i8 == 2) {
                                shortBuffer2.put(shortBuffer2.get(shortBuffer2.position() - i8));
                            }
                            ceil2--;
                            f13 = ceil2 / f12;
                        }
                    }
                    return;
                }
                throw new IllegalArgumentException("Illegal use of UpsampleAudioResampler");
        }
    }

    @Override // q0.m
    public boolean next() {
        return false;
    }

    @Override // x0.q
    public void o(InterfaceC0878A interfaceC0878A) {
        throw new UnsupportedOperationException();
    }

    @Override // t0.j
    public f1.f r(t0.l lVar, long j6, long j7, IOException iOException, int i6) {
        return t0.o.f9665s;
    }

    @Override // x0.q
    public x0.G w(int i6, int i7) {
        throw new UnsupportedOperationException();
    }

    public /* synthetic */ C0346j(Object obj, int i6) {
        this.o = i6;
    }

    public C0346j() {
        this.o = 16;
        new p.j(0);
        new p.g();
    }

    @Override // t0.p
    public void a() {
    }
}
