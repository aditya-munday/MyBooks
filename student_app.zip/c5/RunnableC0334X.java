package c5;

import android.webkit.HttpAuthHandler;
import android.webkit.WebView;
import j2.C0508g;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* renamed from: c5.X, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final /* synthetic */ class RunnableC0334X implements Runnable {
    public final /* synthetic */ int o = 1;

    /* renamed from: p, reason: collision with root package name */
    public final /* synthetic */ C0336Z f5581p;

    /* renamed from: q, reason: collision with root package name */
    public final /* synthetic */ WebView f5582q;

    /* renamed from: r, reason: collision with root package name */
    public final /* synthetic */ String f5583r;

    /* renamed from: s, reason: collision with root package name */
    public final /* synthetic */ String f5584s;

    /* renamed from: t, reason: collision with root package name */
    public final /* synthetic */ Object f5585t;

    public /* synthetic */ RunnableC0334X(C0336Z c0336z, WebView webView, HttpAuthHandler httpAuthHandler, String str, String str2) {
        this.f5581p = c0336z;
        this.f5582q = webView;
        this.f5585t = httpAuthHandler;
        this.f5583r = str;
        this.f5584s = str2;
    }

    @Override // java.lang.Runnable
    public final void run() {
        switch (this.o) {
            case 0:
                String str = (String) this.f5585t;
                C0336Z c0336z = this.f5581p;
                C0345i c0345i = c0336z.f5590a;
                C0354r c0354r = new C0354r(2);
                c0345i.getClass();
                WebView webView = this.f5582q;
                q5.h.e(webView, "viewArg");
                String str2 = this.f5583r;
                q5.h.e(str2, "realmArg");
                q5.h.e(str, "argsArg");
                J2.k kVar = c0345i.f5619a;
                kVar.getClass();
                new v3.u((M4.f) kVar.o, "dev.flutter.pigeon.webview_flutter_android.WebViewClient.onReceivedLoginRequest", kVar.f(), (C0508g) null).x(h5.e.T(c0336z, webView, str2, this.f5584s, str), new C0322K(c0354r, 5));
                return;
            default:
                HttpAuthHandler httpAuthHandler = (HttpAuthHandler) this.f5585t;
                C0336Z c0336z2 = this.f5581p;
                C0345i c0345i2 = c0336z2.f5590a;
                C0354r c0354r2 = new C0354r(2);
                c0345i2.getClass();
                WebView webView2 = this.f5582q;
                q5.h.e(webView2, "webViewArg");
                q5.h.e(httpAuthHandler, "handlerArg");
                String str3 = this.f5583r;
                q5.h.e(str3, "hostArg");
                String str4 = this.f5584s;
                q5.h.e(str4, "realmArg");
                J2.k kVar2 = c0345i2.f5619a;
                kVar2.getClass();
                new v3.u((M4.f) kVar2.o, "dev.flutter.pigeon.webview_flutter_android.WebViewClient.onReceivedHttpAuthRequest", kVar2.f(), (C0508g) null).x(h5.e.T(c0336z2, webView2, httpAuthHandler, str3, str4), new C0322K(c0354r2, 12));
                return;
        }
    }

    public /* synthetic */ RunnableC0334X(C0336Z c0336z, WebView webView, String str, String str2, String str3) {
        this.f5581p = c0336z;
        this.f5582q = webView;
        this.f5583r = str;
        this.f5584s = str2;
        this.f5585t = str3;
    }
}
