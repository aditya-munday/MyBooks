package c5;

import android.net.http.SslCertificate;
import android.net.http.SslError;
import android.os.Message;
import android.util.Log;
import android.view.View;
import android.webkit.ClientCertRequest;
import android.webkit.ConsoleMessage;
import android.webkit.CookieManager;
import android.webkit.DownloadListener;
import android.webkit.GeolocationPermissions;
import android.webkit.HttpAuthHandler;
import android.webkit.PermissionRequest;
import android.webkit.SslErrorHandler;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebStorage;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import g5.C0456e;
import j2.C0508g;
import java.nio.ByteBuffer;
import java.security.PrivateKey;
import java.security.cert.Certificate;
import java.security.cert.X509Certificate;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import org.apache.tika.utils.StringUtils;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* renamed from: c5.g, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0343g extends defpackage.g {
    public final J2.k e;

    public C0343g(J2.k kVar) {
        super(2);
        this.e = kVar;
    }

    public static final void l(String str, Object obj, Throwable th) {
        Log.w("PigeonProxyApiBaseCodec", "Failed to create new Dart proxy instance of " + str + ": " + obj + ". " + th);
    }

    @Override // defpackage.g, M4.v
    public final Object f(byte b6, ByteBuffer byteBuffer) {
        q5.h.e(byteBuffer, "buffer");
        if (b6 == Byte.MIN_VALUE) {
            Object e = e(byteBuffer);
            q5.h.c(e, "null cannot be cast to non-null type kotlin.Long");
            long longValue = ((Long) e).longValue();
            Object e6 = ((C0339c) this.e.f1303p).e(longValue);
            if (e6 == null) {
                Log.e("PigeonProxyApiBaseCodec", "Failed to find instance with identifier: " + longValue);
            }
            return e6;
        }
        return super.f(b6, byteBuffer);
    }

    @Override // defpackage.g, M4.v
    public final void k(M4.u uVar, Object obj) {
        EnumC0356t enumC0356t;
        EnumC0347k enumC0347k;
        Map<String, String> requestHeaders;
        J2.k kVar = this.e;
        M4.f fVar = (M4.f) kVar.o;
        C0339c c0339c = (C0339c) kVar.f1303p;
        if (!(obj instanceof Boolean) && !(obj instanceof byte[]) && !(obj instanceof Double) && !(obj instanceof double[]) && !(obj instanceof float[]) && !(obj instanceof Integer) && !(obj instanceof int[]) && !(obj instanceof List) && !(obj instanceof Long) && !(obj instanceof long[]) && !(obj instanceof Map) && !(obj instanceof String) && !(obj instanceof EnumC0356t) && !(obj instanceof EnumC0347k) && !(obj instanceof EnumC0360x) && !(obj instanceof EnumC0327P) && !(obj instanceof EnumC0359w) && obj != null) {
            if (obj instanceof WebResourceRequest) {
                WebResourceRequest webResourceRequest = (WebResourceRequest) obj;
                C0342f c0342f = new C0342f(obj, 0);
                if (!c0339c.d(webResourceRequest)) {
                    long b6 = c0339c.b(webResourceRequest);
                    String uri = webResourceRequest.getUrl().toString();
                    boolean isForMainFrame = webResourceRequest.isForMainFrame();
                    boolean isRedirect = webResourceRequest.isRedirect();
                    boolean hasGesture = webResourceRequest.hasGesture();
                    String method = webResourceRequest.getMethod();
                    if (webResourceRequest.getRequestHeaders() == null) {
                        requestHeaders = Collections.EMPTY_MAP;
                    } else {
                        requestHeaders = webResourceRequest.getRequestHeaders();
                    }
                    new v3.u(fVar, "dev.flutter.pigeon.webview_flutter_android.WebResourceRequest.pigeon_newInstance", kVar.f(), (C0508g) null).x(h5.e.T(Long.valueOf(b6), uri, Boolean.valueOf(isForMainFrame), Boolean.valueOf(isRedirect), Boolean.valueOf(hasGesture), method, requestHeaders), new C0361y(c0342f, 21));
                }
            } else if (obj instanceof WebResourceResponse) {
                WebResourceResponse webResourceResponse = (WebResourceResponse) obj;
                C0342f c0342f2 = new C0342f(obj, 25);
                if (!c0339c.d(webResourceResponse)) {
                    new v3.u(fVar, "dev.flutter.pigeon.webview_flutter_android.WebResourceResponse.pigeon_newInstance", kVar.f(), (C0508g) null).x(h5.e.T(Long.valueOf(c0339c.b(webResourceResponse)), Long.valueOf(webResourceResponse.getStatusCode())), new C0361y(c0342f2, 22));
                }
            } else if (obj instanceof WebResourceError) {
                WebResourceError webResourceError = (WebResourceError) obj;
                C0342f c0342f3 = new C0342f(obj, 12);
                if (!c0339c.d(webResourceError)) {
                    new v3.u(fVar, "dev.flutter.pigeon.webview_flutter_android.WebResourceError.pigeon_newInstance", kVar.f(), (C0508g) null).x(h5.e.T(Long.valueOf(c0339c.b(webResourceError)), Long.valueOf(webResourceError.getErrorCode()), webResourceError.getDescription().toString()), new C0361y(c0342f3, 20));
                }
            } else if (obj instanceof b0) {
                b0 b0Var = (b0) obj;
                C0342f c0342f4 = new C0342f(obj, 13);
                if (!c0339c.d(b0Var)) {
                    new v3.u(fVar, "dev.flutter.pigeon.webview_flutter_android.WebViewPoint.pigeon_newInstance", kVar.f(), (C0508g) null).x(h5.e.T(Long.valueOf(c0339c.b(b0Var)), Long.valueOf(b0Var.f5596a), Long.valueOf(b0Var.f5597b)), new C0361y(c0342f4, 29));
                }
            } else if (obj instanceof ConsoleMessage) {
                ConsoleMessage consoleMessage = (ConsoleMessage) obj;
                C0342f c0342f5 = new C0342f(obj, 14);
                if (!c0339c.d(consoleMessage)) {
                    long b7 = c0339c.b(consoleMessage);
                    long lineNumber = consoleMessage.lineNumber();
                    String message = consoleMessage.message();
                    int i6 = AbstractC0348l.f5630a[consoleMessage.messageLevel().ordinal()];
                    if (i6 != 1) {
                        if (i6 != 2) {
                            if (i6 != 3) {
                                if (i6 != 4) {
                                    if (i6 != 5) {
                                        enumC0347k = EnumC0347k.f5628v;
                                    } else {
                                        enumC0347k = EnumC0347k.f5623q;
                                    }
                                } else {
                                    enumC0347k = EnumC0347k.f5624r;
                                }
                            } else {
                                enumC0347k = EnumC0347k.f5627u;
                            }
                        } else {
                            enumC0347k = EnumC0347k.f5625s;
                        }
                    } else {
                        enumC0347k = EnumC0347k.f5626t;
                    }
                    new v3.u(fVar, "dev.flutter.pigeon.webview_flutter_android.ConsoleMessage.pigeon_newInstance", kVar.f(), (C0508g) null).x(h5.e.T(Long.valueOf(b7), Long.valueOf(lineNumber), message, enumC0347k, consoleMessage.sourceId()), new C0361y(c0342f5, 3));
                }
            } else if (obj instanceof CookieManager) {
                CookieManager cookieManager = (CookieManager) obj;
                C0342f c0342f6 = new C0342f(obj, 15);
                if (!c0339c.d(cookieManager)) {
                    new v3.u(fVar, "dev.flutter.pigeon.webview_flutter_android.CookieManager.pigeon_newInstance", kVar.f(), (C0508g) null).x(android.support.v4.media.session.a.z(Long.valueOf(c0339c.b(cookieManager))), new C0361y(c0342f6, 4));
                }
            } else if (obj instanceof WebView) {
                WebView webView = (WebView) obj;
                C0342f c0342f7 = new C0342f(obj, 16);
                if (!c0339c.d(webView)) {
                    new v3.u(fVar, "dev.flutter.pigeon.webview_flutter_android.WebView.pigeon_newInstance", kVar.f(), (C0508g) null).x(android.support.v4.media.session.a.z(Long.valueOf(c0339c.b(webView))), new C0361y(c0342f7, 26));
                }
            } else if (obj instanceof WebSettings) {
                WebSettings webSettings = (WebSettings) obj;
                C0342f c0342f8 = new C0342f(obj, 17);
                if (!c0339c.d(webSettings)) {
                    new v3.u(fVar, "dev.flutter.pigeon.webview_flutter_android.WebSettings.pigeon_newInstance", kVar.f(), (C0508g) null).x(android.support.v4.media.session.a.z(Long.valueOf(c0339c.b(webSettings))), new C0361y(c0342f8, 23));
                }
            } else if (obj instanceof C0358v) {
                if (!c0339c.d((C0358v) obj)) {
                    l("JavaScriptChannel", obj, C0456e.a(Q5.a.l(new C0337a("new-instance-error", "Attempting to create a new Dart instance of JavaScriptChannel, but the class has a nonnull callback method.", StringUtils.EMPTY))));
                }
            } else if (obj instanceof WebViewClient) {
                WebViewClient webViewClient = (WebViewClient) obj;
                C0342f c0342f9 = new C0342f(obj, 11);
                if (!c0339c.d(webViewClient)) {
                    new v3.u(fVar, "dev.flutter.pigeon.webview_flutter_android.WebViewClient.pigeon_newInstance", kVar.f(), (C0508g) null).x(android.support.v4.media.session.a.z(Long.valueOf(c0339c.b(webViewClient))), new C0361y(c0342f9, 27));
                }
            } else if (obj instanceof DownloadListener) {
                if (!c0339c.d((DownloadListener) obj)) {
                    l("DownloadListener", obj, C0456e.a(Q5.a.l(new C0337a("new-instance-error", "Attempting to create a new Dart instance of DownloadListener, but the class has a nonnull callback method.", StringUtils.EMPTY))));
                }
            } else if (obj instanceof C0332V) {
                if (!c0339c.d((C0332V) obj)) {
                    l("WebChromeClient", obj, C0456e.a(Q5.a.l(new C0337a("new-instance-error", "Attempting to create a new Dart instance of WebChromeClient, but the class has a nonnull callback method.", StringUtils.EMPTY))));
                }
            } else if (obj instanceof C0357u) {
                C0357u c0357u = (C0357u) obj;
                C0342f c0342f10 = new C0342f(obj, 18);
                if (!c0339c.d(c0357u)) {
                    new v3.u(fVar, "dev.flutter.pigeon.webview_flutter_android.FlutterAssetManager.pigeon_newInstance", kVar.f(), (C0508g) null).x(android.support.v4.media.session.a.z(Long.valueOf(c0339c.b(c0357u))), new C0361y(c0342f10, 8));
                }
            } else if (obj instanceof WebStorage) {
                WebStorage webStorage = (WebStorage) obj;
                C0342f c0342f11 = new C0342f(obj, 19);
                if (!c0339c.d(webStorage)) {
                    new v3.u(fVar, "dev.flutter.pigeon.webview_flutter_android.WebStorage.pigeon_newInstance", kVar.f(), (C0508g) null).x(android.support.v4.media.session.a.z(Long.valueOf(c0339c.b(webStorage))), new C0361y(c0342f11, 24));
                }
            } else if (obj instanceof WebChromeClient.FileChooserParams) {
                WebChromeClient.FileChooserParams fileChooserParams = (WebChromeClient.FileChooserParams) obj;
                C0342f c0342f12 = new C0342f(obj, 20);
                if (!c0339c.d(fileChooserParams)) {
                    long b8 = c0339c.b(fileChooserParams);
                    boolean isCaptureEnabled = fileChooserParams.isCaptureEnabled();
                    List asList = Arrays.asList(fileChooserParams.getAcceptTypes());
                    int mode = fileChooserParams.getMode();
                    if (mode != 0) {
                        if (mode != 1) {
                            if (mode != 3) {
                                enumC0356t = EnumC0356t.f5647t;
                            } else {
                                enumC0356t = EnumC0356t.f5646s;
                            }
                        } else {
                            enumC0356t = EnumC0356t.f5645r;
                        }
                    } else {
                        enumC0356t = EnumC0356t.f5644q;
                    }
                    new v3.u(fVar, "dev.flutter.pigeon.webview_flutter_android.FileChooserParams.pigeon_newInstance", kVar.f(), (C0508g) null).x(h5.e.T(Long.valueOf(b8), Boolean.valueOf(isCaptureEnabled), asList, enumC0356t, fileChooserParams.getFilenameHint()), new C0361y(c0342f12, 7));
                }
            } else if (obj instanceof PermissionRequest) {
                PermissionRequest permissionRequest = (PermissionRequest) obj;
                C0342f c0342f13 = new C0342f(obj, 21);
                if (!c0339c.d(permissionRequest)) {
                    new v3.u(fVar, "dev.flutter.pigeon.webview_flutter_android.PermissionRequest.pigeon_newInstance", kVar.f(), (C0508g) null).x(h5.e.T(Long.valueOf(c0339c.b(permissionRequest)), Arrays.asList(permissionRequest.getResources())), new C0361y(c0342f13, 12));
                }
            } else if (obj instanceof WebChromeClient.CustomViewCallback) {
                WebChromeClient.CustomViewCallback customViewCallback = (WebChromeClient.CustomViewCallback) obj;
                C0342f c0342f14 = new C0342f(obj, 22);
                if (!c0339c.d(customViewCallback)) {
                    new v3.u(fVar, "dev.flutter.pigeon.webview_flutter_android.CustomViewCallback.pigeon_newInstance", kVar.f(), (C0508g) null).x(android.support.v4.media.session.a.z(Long.valueOf(c0339c.b(customViewCallback))), new C0361y(c0342f14, 5));
                }
            } else if (obj instanceof View) {
                View view = (View) obj;
                C0342f c0342f15 = new C0342f(obj, 23);
                if (!c0339c.d(view)) {
                    new v3.u(fVar, "dev.flutter.pigeon.webview_flutter_android.View.pigeon_newInstance", kVar.f(), (C0508g) null).x(android.support.v4.media.session.a.z(Long.valueOf(c0339c.b(view))), new C0361y(c0342f15, 19));
                }
            } else if (obj instanceof GeolocationPermissions.Callback) {
                GeolocationPermissions.Callback callback = (GeolocationPermissions.Callback) obj;
                C0342f c0342f16 = new C0342f(obj, 24);
                if (!c0339c.d(callback)) {
                    new v3.u(fVar, "dev.flutter.pigeon.webview_flutter_android.GeolocationPermissionsCallback.pigeon_newInstance", kVar.f(), (C0508g) null).x(android.support.v4.media.session.a.z(Long.valueOf(c0339c.b(callback))), new C0361y(c0342f16, 9));
                }
            } else if (obj instanceof HttpAuthHandler) {
                HttpAuthHandler httpAuthHandler = (HttpAuthHandler) obj;
                C0342f c0342f17 = new C0342f(obj, 1);
                if (!c0339c.d(httpAuthHandler)) {
                    new v3.u(fVar, "dev.flutter.pigeon.webview_flutter_android.HttpAuthHandler.pigeon_newInstance", kVar.f(), (C0508g) null).x(android.support.v4.media.session.a.z(Long.valueOf(c0339c.b(httpAuthHandler))), new C0361y(c0342f17, 10));
                }
            } else if (obj instanceof Message) {
                Message message2 = (Message) obj;
                C0342f c0342f18 = new C0342f(obj, 2);
                if (!c0339c.d(message2)) {
                    new v3.u(fVar, "dev.flutter.pigeon.webview_flutter_android.AndroidMessage.pigeon_newInstance", kVar.f(), (C0508g) null).x(android.support.v4.media.session.a.z(Long.valueOf(c0339c.b(message2))), new C0361y(c0342f18, 0));
                }
            } else if (obj instanceof ClientCertRequest) {
                ClientCertRequest clientCertRequest = (ClientCertRequest) obj;
                C0342f c0342f19 = new C0342f(obj, 3);
                if (!c0339c.d(clientCertRequest)) {
                    new v3.u(fVar, "dev.flutter.pigeon.webview_flutter_android.ClientCertRequest.pigeon_newInstance", kVar.f(), (C0508g) null).x(android.support.v4.media.session.a.z(Long.valueOf(c0339c.b(clientCertRequest))), new C0361y(c0342f19, 2));
                }
            } else if (obj instanceof PrivateKey) {
                PrivateKey privateKey = (PrivateKey) obj;
                C0342f c0342f20 = new C0342f(obj, 4);
                if (!c0339c.d(privateKey)) {
                    new v3.u(fVar, "dev.flutter.pigeon.webview_flutter_android.PrivateKey.pigeon_newInstance", kVar.f(), (C0508g) null).x(android.support.v4.media.session.a.z(Long.valueOf(c0339c.b(privateKey))), new C0361y(c0342f20, 13));
                }
            } else if (obj instanceof X509Certificate) {
                X509Certificate x509Certificate = (X509Certificate) obj;
                C0342f c0342f21 = new C0342f(obj, 5);
                if (!c0339c.d(x509Certificate)) {
                    new v3.u(fVar, "dev.flutter.pigeon.webview_flutter_android.X509Certificate.pigeon_newInstance", kVar.f(), (C0508g) null).x(android.support.v4.media.session.a.z(Long.valueOf(c0339c.b(x509Certificate))), new C0324M(c0342f21, 0));
                }
            } else if (obj instanceof SslErrorHandler) {
                SslErrorHandler sslErrorHandler = (SslErrorHandler) obj;
                C0342f c0342f22 = new C0342f(obj, 6);
                if (!c0339c.d(sslErrorHandler)) {
                    new v3.u(fVar, "dev.flutter.pigeon.webview_flutter_android.SslErrorHandler.pigeon_newInstance", kVar.f(), (C0508g) null).x(android.support.v4.media.session.a.z(Long.valueOf(c0339c.b(sslErrorHandler))), new C0361y(c0342f22, 18));
                }
            } else if (obj instanceof SslError) {
                SslError sslError = (SslError) obj;
                C0342f c0342f23 = new C0342f(obj, 7);
                if (!c0339c.d(sslError)) {
                    new v3.u(fVar, "dev.flutter.pigeon.webview_flutter_android.SslError.pigeon_newInstance", kVar.f(), (C0508g) null).x(h5.e.T(Long.valueOf(c0339c.b(sslError)), sslError.getCertificate(), sslError.getUrl()), new C0361y(c0342f23, 16));
                }
            } else if (obj instanceof SslCertificate.DName) {
                SslCertificate.DName dName = (SslCertificate.DName) obj;
                C0342f c0342f24 = new C0342f(obj, 8);
                if (!c0339c.d(dName)) {
                    new v3.u(fVar, "dev.flutter.pigeon.webview_flutter_android.SslCertificateDName.pigeon_newInstance", kVar.f(), (C0508g) null).x(android.support.v4.media.session.a.z(Long.valueOf(c0339c.b(dName))), new C0361y(c0342f24, 15));
                }
            } else if (obj instanceof SslCertificate) {
                SslCertificate sslCertificate = (SslCertificate) obj;
                C0342f c0342f25 = new C0342f(obj, 9);
                if (!c0339c.d(sslCertificate)) {
                    new v3.u(fVar, "dev.flutter.pigeon.webview_flutter_android.SslCertificate.pigeon_newInstance", kVar.f(), (C0508g) null).x(android.support.v4.media.session.a.z(Long.valueOf(c0339c.b(sslCertificate))), new C0361y(c0342f25, 14));
                }
            } else if (obj instanceof Certificate) {
                Certificate certificate = (Certificate) obj;
                C0342f c0342f26 = new C0342f(obj, 10);
                if (!c0339c.d(certificate)) {
                    new v3.u(fVar, "dev.flutter.pigeon.webview_flutter_android.Certificate.pigeon_newInstance", kVar.f(), (C0508g) null).x(android.support.v4.media.session.a.z(Long.valueOf(c0339c.b(certificate))), new C0361y(c0342f26, 1));
                }
            }
            if (c0339c.d(obj)) {
                uVar.write(128);
                c0339c.f();
                Long l6 = (Long) c0339c.f5599b.get(new C0338b(obj));
                if (l6 != null) {
                    c0339c.f5601d.put(l6, obj);
                }
                k(uVar, l6);
                return;
            }
            throw new IllegalArgumentException("Unsupported value: '" + obj + "' of type '" + obj.getClass().getName() + "'");
        }
        super.k(uVar, obj);
    }
}
