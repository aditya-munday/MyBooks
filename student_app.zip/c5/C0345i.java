package c5;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* renamed from: c5.i, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0345i {

    /* renamed from: a, reason: collision with root package name */
    public final J2.k f5619a;

    public C0345i(J2.k kVar, int i6) {
        switch (i6) {
            case 1:
                q5.h.e(kVar, "pigeonRegistrar");
                this.f5619a = kVar;
                return;
            case 2:
                q5.h.e(kVar, "pigeonRegistrar");
                this.f5619a = kVar;
                return;
            case 3:
                q5.h.e(kVar, "pigeonRegistrar");
                this.f5619a = kVar;
                return;
            case 4:
                q5.h.e(kVar, "pigeonRegistrar");
                this.f5619a = kVar;
                return;
            case 5:
                q5.h.e(kVar, "pigeonRegistrar");
                this.f5619a = kVar;
                return;
            case 6:
                q5.h.e(kVar, "pigeonRegistrar");
                this.f5619a = kVar;
                return;
            default:
                q5.h.e(kVar, "pigeonRegistrar");
                this.f5619a = kVar;
                return;
        }
    }
}
