package c5;

import android.os.SystemClock;
import android.text.TextUtils;
import androidx.preference.ListPreference;
import androidx.preference.Preference;
import com.shockwave.pdfium.R;
import e2.InterfaceC0418a;
import f4.InterfaceC0445a;
import java.io.FileNotFoundException;
import java.io.IOException;
import l0.C0611I;
import l0.InterfaceC0615d;
import l0.InterfaceC0616e;
import org.apache.tika.pipes.pipesiterator.PipesIterator;
import u0.AbstractC0806b;
import x0.InterfaceC0878A;
import x0.InterfaceC0886h;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* renamed from: c5.o, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0351o implements InterfaceC0418a, InterfaceC0445a, g0.s, h1.a, i1.c, k4.a, k.o, InterfaceC0615d, t0.l, InterfaceC0886h, x0.q {
    public static C0351o o;

    public /* synthetic */ C0351o(Object obj) {
    }

    public static f1.f j(t0.i iVar, C.b bVar) {
        IOException iOException = (IOException) bVar.f247p;
        if (iOException instanceof X.u) {
            int i6 = ((X.u) iOException).f3612r;
            if (i6 == 403 || i6 == 404 || i6 == 410 || i6 == 416 || i6 == 500 || i6 == 503) {
                if (iVar.a(1)) {
                    return new f1.f(300000L, 1);
                }
                if (iVar.a(2)) {
                    return new f1.f(60000L, 2);
                }
                return null;
            }
            return null;
        }
        return null;
    }

    public static long q(C.b bVar) {
        Throwable th = (IOException) bVar.f247p;
        if (!(th instanceof S.G) && !(th instanceof FileNotFoundException) && !(th instanceof X.r) && !(th instanceof t0.n)) {
            int i6 = X.i.f3573p;
            while (th != null) {
                if (!(th instanceof X.i) || ((X.i) th).o != 2008) {
                    th = th.getCause();
                } else {
                    return -9223372036854775807L;
                }
            }
            return Math.min((bVar.o - 1) * PipesIterator.DEFAULT_QUEUE_SIZE, 5000);
        }
        return -9223372036854775807L;
    }

    @Override // t0.l
    public void b() {
        synchronized (AbstractC0806b.f9741a) {
            Object obj = AbstractC0806b.f9742b;
            synchronized (obj) {
                if (AbstractC0806b.f9743c) {
                    return;
                }
                long a6 = AbstractC0806b.a();
                synchronized (obj) {
                    SystemClock.elapsedRealtime();
                    AbstractC0806b.f9744d = a6;
                    AbstractC0806b.f9743c = true;
                }
            }
        }
    }

    @Override // l0.InterfaceC0615d
    public InterfaceC0616e c(int i6) {
        int i7;
        C0611I c0611i = new C0611I();
        C0611I c0611i2 = new C0611I();
        boolean z6 = false;
        try {
            c0611i.o.B(android.support.v4.media.session.a.o(0));
            int h6 = c0611i.h();
            if (h6 % 2 == 0) {
                z6 = true;
            }
            if (z6) {
                i7 = h6 + 1;
            } else {
                i7 = h6 - 1;
            }
            c0611i2.o.B(android.support.v4.media.session.a.o(i7));
            if (z6) {
                c0611i.f8270p = c0611i2;
                return c0611i;
            }
            c0611i2.f8270p = c0611i;
            return c0611i2;
        } catch (IOException e) {
            android.support.v4.media.session.a.c(c0611i);
            android.support.v4.media.session.a.c(c0611i2);
            throw e;
        }
    }

    /* JADX WARN: Type inference failed for: r0v0, types: [java.lang.Object, l0.d] */
    @Override // l0.InterfaceC0615d
    public InterfaceC0615d d() {
        return new Object();
    }

    @Override // e2.InterfaceC0418a
    public long h() {
        return System.currentTimeMillis();
    }

    @Override // k.o
    public boolean i(k.j jVar) {
        return false;
    }

    @Override // h1.a
    public CharSequence l(Preference preference) {
        ListPreference listPreference = (ListPreference) preference;
        if (!TextUtils.isEmpty(null)) {
            return null;
        }
        return listPreference.o.getString(R.string.not_set);
    }

    @Override // g0.s
    public t0.q n(g0.o oVar, g0.l lVar) {
        return new g0.r(oVar, lVar);
    }

    public int p(int i6) {
        if (i6 == 7) {
            return 6;
        }
        return 3;
    }

    @Override // x0.q
    public x0.G w(int i6, int i7) {
        return new x0.n();
    }

    @Override // g0.s
    public t0.q y() {
        return new g0.r(g0.o.f6711l, null);
    }

    @Override // t0.l
    public void f() {
    }

    @Override // x0.q
    public void g() {
    }

    @Override // i1.c
    public void k() {
    }

    @Override // x0.InterfaceC0886h
    public long e(long j6) {
        return j6;
    }

    @Override // x0.q
    public void o(InterfaceC0878A interfaceC0878A) {
    }

    @Override // k.o
    public void a(k.j jVar, boolean z6) {
    }

    @Override // i1.c
    public void m(int i6, Object obj) {
    }
}
