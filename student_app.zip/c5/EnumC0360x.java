package c5;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* renamed from: c5.x, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public enum EnumC0360x {
    /* JADX INFO: Fake field, exist only in values array */
    EF0(0),
    /* JADX INFO: Fake field, exist only in values array */
    EF1(1),
    /* JADX INFO: Fake field, exist only in values array */
    EF2(2),
    f5656q(3);


    /* renamed from: p, reason: collision with root package name */
    public static final C0346j f5655p = new C0346j(3);
    public final int o;

    EnumC0360x(int i6) {
        this.o = i6;
    }
}
