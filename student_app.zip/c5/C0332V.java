package c5;

import android.net.Uri;
import android.view.View;
import android.webkit.ConsoleMessage;
import android.webkit.GeolocationPermissions;
import android.webkit.JsPromptResult;
import android.webkit.JsResult;
import android.webkit.PermissionRequest;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import j2.C0508g;
import java.util.List;
import java.util.Objects;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* renamed from: c5.V, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0332V extends C0329S {

    /* renamed from: h, reason: collision with root package name */
    public static final /* synthetic */ int f5572h = 0;

    /* renamed from: b, reason: collision with root package name */
    public final C0350n f5573b;

    /* renamed from: c, reason: collision with root package name */
    public boolean f5574c = false;

    /* renamed from: d, reason: collision with root package name */
    public boolean f5575d = false;
    public boolean e = false;

    /* renamed from: f, reason: collision with root package name */
    public boolean f5576f = false;

    /* renamed from: g, reason: collision with root package name */
    public boolean f5577g = false;

    public C0332V(C0350n c0350n) {
        this.f5573b = c0350n;
    }

    @Override // android.webkit.WebChromeClient
    public final boolean onConsoleMessage(ConsoleMessage consoleMessage) {
        C0354r c0354r = new C0354r(1);
        C0350n c0350n = this.f5573b;
        c0350n.getClass();
        q5.h.e(consoleMessage, "messageArg");
        J2.k kVar = c0350n.f5633a;
        kVar.getClass();
        new v3.u((M4.f) kVar.o, "dev.flutter.pigeon.webview_flutter_android.WebChromeClient.onConsoleMessage", kVar.f(), (C0508g) null).x(h5.e.T(this, consoleMessage), new a0.e(c0354r, 27));
        return this.f5575d;
    }

    @Override // android.webkit.WebChromeClient
    public final void onGeolocationPermissionsHidePrompt() {
        C0354r c0354r = new C0354r(1);
        C0350n c0350n = this.f5573b;
        c0350n.getClass();
        J2.k kVar = c0350n.f5633a;
        kVar.getClass();
        new v3.u((M4.f) kVar.o, "dev.flutter.pigeon.webview_flutter_android.WebChromeClient.onGeolocationPermissionsHidePrompt", kVar.f(), (C0508g) null).x(android.support.v4.media.session.a.z(this), new a0.e(c0354r, 29));
    }

    @Override // android.webkit.WebChromeClient
    public final void onGeolocationPermissionsShowPrompt(String str, GeolocationPermissions.Callback callback) {
        C0354r c0354r = new C0354r(1);
        C0350n c0350n = this.f5573b;
        c0350n.getClass();
        q5.h.e(str, "originArg");
        q5.h.e(callback, "callbackArg");
        J2.k kVar = c0350n.f5633a;
        kVar.getClass();
        new v3.u((M4.f) kVar.o, "dev.flutter.pigeon.webview_flutter_android.WebChromeClient.onGeolocationPermissionsShowPrompt", kVar.f(), (C0508g) null).x(h5.e.T(this, str, callback), new a0.e(c0354r, 28));
    }

    @Override // android.webkit.WebChromeClient
    public final void onHideCustomView() {
        C0354r c0354r = new C0354r(1);
        C0350n c0350n = this.f5573b;
        c0350n.getClass();
        J2.k kVar = c0350n.f5633a;
        kVar.getClass();
        new v3.u((M4.f) kVar.o, "dev.flutter.pigeon.webview_flutter_android.WebChromeClient.onHideCustomView", kVar.f(), (C0508g) null).x(android.support.v4.media.session.a.z(this), new a0.e(c0354r, 23));
    }

    @Override // android.webkit.WebChromeClient
    public final boolean onJsAlert(WebView webView, String str, String str2, JsResult jsResult) {
        if (this.e) {
            C0313B c0313b = new C0313B(new C0330T(this, jsResult, 1), 2);
            C0350n c0350n = this.f5573b;
            c0350n.getClass();
            q5.h.e(webView, "webViewArg");
            q5.h.e(str, "urlArg");
            q5.h.e(str2, "messageArg");
            J2.k kVar = c0350n.f5633a;
            kVar.getClass();
            new v3.u((M4.f) kVar.o, "dev.flutter.pigeon.webview_flutter_android.WebChromeClient.onJsAlert", kVar.f(), (C0508g) null).x(h5.e.T(this, webView, str, str2), new C0319H(c0313b, 1));
            return true;
        }
        return false;
    }

    @Override // android.webkit.WebChromeClient
    public final boolean onJsConfirm(WebView webView, String str, String str2, JsResult jsResult) {
        if (this.f5576f) {
            C0313B c0313b = new C0313B(new C0330T(this, jsResult, 0), 2);
            C0350n c0350n = this.f5573b;
            c0350n.getClass();
            q5.h.e(webView, "webViewArg");
            q5.h.e(str, "urlArg");
            q5.h.e(str2, "messageArg");
            J2.k kVar = c0350n.f5633a;
            kVar.getClass();
            new v3.u((M4.f) kVar.o, "dev.flutter.pigeon.webview_flutter_android.WebChromeClient.onJsConfirm", kVar.f(), (C0508g) null).x(h5.e.T(this, webView, str, str2), new C0319H(c0313b, 3));
            return true;
        }
        return false;
    }

    @Override // android.webkit.WebChromeClient
    public final boolean onJsPrompt(WebView webView, String str, String str2, String str3, JsPromptResult jsPromptResult) {
        if (this.f5577g) {
            C0313B c0313b = new C0313B(new C0330T(this, jsPromptResult, 2), 2);
            C0350n c0350n = this.f5573b;
            c0350n.getClass();
            q5.h.e(webView, "webViewArg");
            q5.h.e(str, "urlArg");
            q5.h.e(str2, "messageArg");
            q5.h.e(str3, "defaultValueArg");
            J2.k kVar = c0350n.f5633a;
            kVar.getClass();
            new v3.u((M4.f) kVar.o, "dev.flutter.pigeon.webview_flutter_android.WebChromeClient.onJsPrompt", kVar.f(), (C0508g) null).x(h5.e.T(this, webView, str, str2, str3), new C0319H(c0313b, 0));
            return true;
        }
        return false;
    }

    @Override // android.webkit.WebChromeClient
    public final void onPermissionRequest(PermissionRequest permissionRequest) {
        C0354r c0354r = new C0354r(1);
        C0350n c0350n = this.f5573b;
        c0350n.getClass();
        q5.h.e(permissionRequest, "requestArg");
        J2.k kVar = c0350n.f5633a;
        kVar.getClass();
        new v3.u((M4.f) kVar.o, "dev.flutter.pigeon.webview_flutter_android.WebChromeClient.onPermissionRequest", kVar.f(), (C0508g) null).x(h5.e.T(this, permissionRequest), new a0.e(c0354r, 25));
    }

    @Override // android.webkit.WebChromeClient
    public final void onProgressChanged(WebView webView, int i6) {
        long j6 = i6;
        C0354r c0354r = new C0354r(1);
        C0350n c0350n = this.f5573b;
        c0350n.getClass();
        q5.h.e(webView, "webViewArg");
        J2.k kVar = c0350n.f5633a;
        kVar.getClass();
        new v3.u((M4.f) kVar.o, "dev.flutter.pigeon.webview_flutter_android.WebChromeClient.onProgressChanged", kVar.f(), (C0508g) null).x(h5.e.T(this, webView, Long.valueOf(j6)), new a0.e(c0354r, 24));
    }

    @Override // android.webkit.WebChromeClient
    public final void onShowCustomView(View view, WebChromeClient.CustomViewCallback customViewCallback) {
        C0354r c0354r = new C0354r(1);
        C0350n c0350n = this.f5573b;
        c0350n.getClass();
        q5.h.e(view, "viewArg");
        q5.h.e(customViewCallback, "callbackArg");
        J2.k kVar = c0350n.f5633a;
        kVar.getClass();
        new v3.u((M4.f) kVar.o, "dev.flutter.pigeon.webview_flutter_android.WebChromeClient.onShowCustomView", kVar.f(), (C0508g) null).x(h5.e.T(this, view, customViewCallback), new a0.e(c0354r, 26));
    }

    @Override // android.webkit.WebChromeClient
    public final boolean onShowFileChooser(WebView webView, final ValueCallback valueCallback, WebChromeClient.FileChooserParams fileChooserParams) {
        final boolean z6 = this.f5574c;
        C0313B c0313b = new C0313B(new p5.l() { // from class: c5.U
            @Override // p5.l
            public final Object a(Object obj) {
                C0325N c0325n = (C0325N) obj;
                if (c0325n.f5555d) {
                    J2.k kVar = C0332V.this.f5573b.f5633a;
                    Throwable th = c0325n.f5554c;
                    Objects.requireNonNull(th);
                    kVar.getClass();
                    J2.k.i(th);
                    return null;
                }
                List list = (List) c0325n.f5553b;
                Objects.requireNonNull(list);
                if (z6) {
                    Uri[] uriArr = new Uri[list.size()];
                    for (int i6 = 0; i6 < list.size(); i6++) {
                        uriArr[i6] = Uri.parse((String) list.get(i6));
                    }
                    valueCallback.onReceiveValue(uriArr);
                    return null;
                }
                return null;
            }
        }, 2);
        C0350n c0350n = this.f5573b;
        c0350n.getClass();
        q5.h.e(webView, "webViewArg");
        q5.h.e(fileChooserParams, "paramsArg");
        J2.k kVar = c0350n.f5633a;
        kVar.getClass();
        new v3.u((M4.f) kVar.o, "dev.flutter.pigeon.webview_flutter_android.WebChromeClient.onShowFileChooser", kVar.f(), (C0508g) null).x(h5.e.T(this, webView, fileChooserParams), new C0319H(c0313b, 2));
        return z6;
    }
}
