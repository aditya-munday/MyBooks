package c5;

import android.content.res.AssetManager;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* renamed from: c5.u, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0357u {

    /* renamed from: a, reason: collision with root package name */
    public final AssetManager f5649a;

    /* renamed from: b, reason: collision with root package name */
    public final x3.c f5650b;

    public C0357u(AssetManager assetManager, x3.c cVar) {
        this.f5649a = assetManager;
        this.f5650b = cVar;
    }
}
