package c5;

import android.net.http.SslCertificate;
import android.os.Build;
import android.util.Log;
import java.security.cert.X509Certificate;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* renamed from: c5.O, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0326O extends D0.e {
    @Override // D0.e
    public final X509Certificate k(SslCertificate sslCertificate) {
        ((J2.k) this.f604b).getClass();
        if (Build.VERSION.SDK_INT >= 29) {
            return sslCertificate.getX509Certificate();
        }
        Log.d("SslCertificateProxyApi", "SslCertificate.getX509Certificate requires Build.VERSION_CODES.Q.");
        return null;
    }
}
