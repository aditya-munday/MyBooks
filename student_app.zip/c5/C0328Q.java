package c5;

import android.webkit.WebResourceRequest;
import android.webkit.WebView;
import android.webkit.WebViewClient;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* renamed from: c5.Q, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0328Q extends WebViewClient {

    /* renamed from: a, reason: collision with root package name */
    public final /* synthetic */ WebView f5565a;

    /* renamed from: b, reason: collision with root package name */
    public final /* synthetic */ C0329S f5566b;

    public C0328Q(C0329S c0329s, WebView webView) {
        this.f5566b = c0329s;
        this.f5565a = webView;
    }

    @Override // android.webkit.WebViewClient
    public final boolean shouldOverrideUrlLoading(WebView webView, WebResourceRequest webResourceRequest) {
        WebViewClient webViewClient = this.f5566b.f5567a;
        WebView webView2 = this.f5565a;
        if (!webViewClient.shouldOverrideUrlLoading(webView2, webResourceRequest)) {
            webView2.loadUrl(webResourceRequest.getUrl().toString());
            return true;
        }
        return true;
    }
}
