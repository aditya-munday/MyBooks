package c5;

import Z.RunnableC0192y;
import android.graphics.Bitmap;
import android.net.http.SslError;
import android.os.Message;
import android.view.KeyEvent;
import android.webkit.ClientCertRequest;
import android.webkit.HttpAuthHandler;
import android.webkit.SslErrorHandler;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import j2.C0508g;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* renamed from: c5.Z, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0336Z extends WebViewClient {

    /* renamed from: c, reason: collision with root package name */
    public static final /* synthetic */ int f5589c = 0;

    /* renamed from: a, reason: collision with root package name */
    public final C0345i f5590a;

    /* renamed from: b, reason: collision with root package name */
    public boolean f5591b = false;

    public C0336Z(C0345i c0345i) {
        this.f5590a = c0345i;
    }

    @Override // android.webkit.WebViewClient
    public final void doUpdateVisitedHistory(WebView webView, String str, boolean z6) {
        this.f5590a.f5619a.j(new RunnableC0192y(this, webView, str, z6));
    }

    @Override // android.webkit.WebViewClient
    public final void onFormResubmission(WebView webView, Message message, Message message2) {
        this.f5590a.f5619a.j(new I3.c(this, webView, message, message2, 5));
    }

    @Override // android.webkit.WebViewClient
    public final void onLoadResource(WebView webView, String str) {
        this.f5590a.f5619a.j(new RunnableC0333W(this, webView, str, 1));
    }

    @Override // android.webkit.WebViewClient
    public final void onPageCommitVisible(WebView webView, String str) {
        this.f5590a.f5619a.j(new RunnableC0333W(this, webView, str, 3));
    }

    @Override // android.webkit.WebViewClient
    public final void onPageFinished(WebView webView, String str) {
        this.f5590a.f5619a.j(new RunnableC0333W(this, webView, str, 2));
    }

    @Override // android.webkit.WebViewClient
    public final void onPageStarted(WebView webView, String str, Bitmap bitmap) {
        this.f5590a.f5619a.j(new RunnableC0333W(this, webView, str, 0));
    }

    @Override // android.webkit.WebViewClient
    public final void onReceivedClientCertRequest(WebView webView, ClientCertRequest clientCertRequest) {
        this.f5590a.f5619a.j(new Z.T(this, webView, clientCertRequest, 2));
    }

    @Override // android.webkit.WebViewClient
    public final void onReceivedError(WebView webView, WebResourceRequest webResourceRequest, WebResourceError webResourceError) {
        this.f5590a.f5619a.j(new I3.c(this, webView, webResourceRequest, webResourceError, 7));
    }

    @Override // android.webkit.WebViewClient
    public final void onReceivedHttpAuthRequest(WebView webView, HttpAuthHandler httpAuthHandler, String str, String str2) {
        this.f5590a.f5619a.j(new RunnableC0334X(this, webView, httpAuthHandler, str, str2));
    }

    @Override // android.webkit.WebViewClient
    public final void onReceivedHttpError(WebView webView, WebResourceRequest webResourceRequest, WebResourceResponse webResourceResponse) {
        this.f5590a.f5619a.j(new I3.c(this, webView, webResourceRequest, webResourceResponse, 8));
    }

    @Override // android.webkit.WebViewClient
    public final void onReceivedLoginRequest(WebView webView, String str, String str2, String str3) {
        this.f5590a.f5619a.j(new RunnableC0334X(this, webView, str, str2, str3));
    }

    @Override // android.webkit.WebViewClient
    public final void onReceivedSslError(WebView webView, SslErrorHandler sslErrorHandler, SslError sslError) {
        this.f5590a.f5619a.j(new I3.c(this, webView, sslErrorHandler, sslError, 6));
    }

    @Override // android.webkit.WebViewClient
    public final void onScaleChanged(final WebView webView, final float f6, final float f7) {
        this.f5590a.f5619a.j(new Runnable() { // from class: c5.Y
            @Override // java.lang.Runnable
            public final void run() {
                C0336Z c0336z = C0336Z.this;
                C0345i c0345i = c0336z.f5590a;
                double d6 = f6;
                double d7 = f7;
                C0354r c0354r = new C0354r(2);
                c0345i.getClass();
                WebView webView2 = webView;
                q5.h.e(webView2, "viewArg");
                J2.k kVar = c0345i.f5619a;
                kVar.getClass();
                new v3.u((M4.f) kVar.o, "dev.flutter.pigeon.webview_flutter_android.WebViewClient.onScaleChanged", kVar.f(), (C0508g) null).x(h5.e.T(c0336z, webView2, Double.valueOf(d6), Double.valueOf(d7)), new C0322K(c0354r, 15));
            }
        });
    }

    @Override // android.webkit.WebViewClient
    public final boolean shouldOverrideUrlLoading(WebView webView, WebResourceRequest webResourceRequest) {
        this.f5590a.f5619a.j(new Z.T(this, webView, webResourceRequest, 3));
        if (webResourceRequest.isForMainFrame() && this.f5591b) {
            return true;
        }
        return false;
    }

    @Override // android.webkit.WebViewClient
    public final void onUnhandledKeyEvent(WebView webView, KeyEvent keyEvent) {
    }
}
