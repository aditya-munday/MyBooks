package c5;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* renamed from: c5.r, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final /* synthetic */ class C0354r implements p5.l {
    public final /* synthetic */ int o;

    public /* synthetic */ C0354r(int i6) {
        this.o = i6;
    }

    @Override // p5.l
    public final Object a(Object obj) {
        boolean z6;
        switch (this.o) {
            case 0:
                return null;
            case 1:
                int i6 = C0332V.f5572h;
                return null;
            case 2:
                int i7 = C0336Z.f5589c;
                return null;
            case 3:
                int i8 = d0.f5613r;
                return null;
            default:
                if (obj == null) {
                    z6 = true;
                } else {
                    z6 = false;
                }
                return Boolean.valueOf(z6);
        }
    }
}
