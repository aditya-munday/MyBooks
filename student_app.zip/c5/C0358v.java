package c5;

import android.webkit.JavascriptInterface;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* renamed from: c5.v, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0358v {

    /* renamed from: a, reason: collision with root package name */
    public final String f5651a;

    /* renamed from: b, reason: collision with root package name */
    public final C0350n f5652b;

    public C0358v(String str, C0350n c0350n) {
        this.f5651a = str;
        this.f5652b = c0350n;
    }

    @JavascriptInterface
    public void postMessage(String str) {
        this.f5652b.f5633a.j(new I3.b(this, str, 22));
    }
}
