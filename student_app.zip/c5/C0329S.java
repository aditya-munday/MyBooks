package c5;

import android.os.Message;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* renamed from: c5.S, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public class C0329S extends WebChromeClient {

    /* renamed from: a, reason: collision with root package name */
    public WebViewClient f5567a;

    @Override // android.webkit.WebChromeClient
    public final boolean onCreateWindow(WebView webView, boolean z6, boolean z7, Message message) {
        WebView webView2 = new WebView(webView.getContext());
        if (this.f5567a == null) {
            return false;
        }
        webView2.setWebViewClient(new C0328Q(this, webView));
        ((WebView.WebViewTransport) message.obj).setWebView(webView2);
        message.sendToTarget();
        return true;
    }
}
