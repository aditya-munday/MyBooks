package c5;

import g5.C0455d;
import g5.C0456e;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* renamed from: c5.N, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0325N {

    /* renamed from: a, reason: collision with root package name */
    public final Object f5552a;

    /* renamed from: b, reason: collision with root package name */
    public final Object f5553b;

    /* renamed from: c, reason: collision with root package name */
    public final Throwable f5554c;

    /* renamed from: d, reason: collision with root package name */
    public final boolean f5555d;

    public C0325N(Object obj) {
        Object obj2;
        this.f5552a = obj;
        boolean z6 = obj instanceof C0455d;
        if (z6) {
            obj2 = null;
        } else {
            obj2 = obj;
        }
        this.f5553b = obj2;
        this.f5554c = C0456e.a(obj);
        this.f5555d = z6;
    }
}
