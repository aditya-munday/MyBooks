package c5;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* renamed from: c5.k, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public enum EnumC0347k {
    f5623q(0),
    f5624r(1),
    f5625s(2),
    f5626t(3),
    f5627u(4),
    f5628v(5);


    /* renamed from: p, reason: collision with root package name */
    public static final C0346j f5622p = new C0346j(0);
    public final int o;

    EnumC0347k(int i6) {
        this.o = i6;
    }
}
