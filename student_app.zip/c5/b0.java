package c5;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* loaded from: classes.dex */
public final class b0 {

    /* renamed from: a, reason: collision with root package name */
    public final long f5596a;

    /* renamed from: b, reason: collision with root package name */
    public final long f5597b;

    public b0(long j6, long j7) {
        this.f5596a = j6;
        this.f5597b = j7;
    }
}
