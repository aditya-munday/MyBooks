package c5;

import android.webkit.DownloadListener;
import j2.C0508g;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* renamed from: c5.s, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0355s implements DownloadListener {

    /* renamed from: a, reason: collision with root package name */
    public final C0345i f5642a;

    public C0355s(C0345i c0345i) {
        this.f5642a = c0345i;
    }

    @Override // android.webkit.DownloadListener
    public final void onDownloadStart(final String str, final String str2, final String str3, final String str4, final long j6) {
        this.f5642a.f5619a.j(new Runnable() { // from class: c5.q
            @Override // java.lang.Runnable
            public final void run() {
                C0355s c0355s = C0355s.this;
                C0345i c0345i = c0355s.f5642a;
                C0354r c0354r = new C0354r(0);
                String str5 = str;
                q5.h.e(str5, "urlArg");
                String str6 = str2;
                q5.h.e(str6, "userAgentArg");
                String str7 = str3;
                q5.h.e(str7, "contentDispositionArg");
                String str8 = str4;
                q5.h.e(str8, "mimetypeArg");
                J2.k kVar = c0345i.f5619a;
                kVar.getClass();
                new v3.u((M4.f) kVar.o, "dev.flutter.pigeon.webview_flutter_android.DownloadListener.onDownloadStart", kVar.f(), (C0508g) null).x(h5.e.T(c0355s, str5, str6, str7, str8, Long.valueOf(j6)), new a0.e(c0354r, 15));
            }
        });
    }
}
