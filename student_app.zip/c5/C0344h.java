package c5;

import android.util.Log;
import g5.C0455d;
import g5.C0456e;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* renamed from: c5.h, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final /* synthetic */ class C0344h implements p5.l {
    public final /* synthetic */ long o;

    public /* synthetic */ C0344h(long j6) {
        this.o = j6;
    }

    @Override // p5.l
    public final Object a(Object obj) {
        if (((C0456e) obj).o instanceof C0455d) {
            Log.e("PigeonProxyApiRegistrar", "Failed to remove Dart strong reference with identifier: " + this.o);
        }
        return g5.h.f6800a;
    }
}
