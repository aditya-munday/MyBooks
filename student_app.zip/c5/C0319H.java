package c5;

import java.util.List;
import org.apache.tika.utils.StringUtils;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* renamed from: c5.H, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final /* synthetic */ class C0319H implements M4.c {
    public final /* synthetic */ int o;

    /* renamed from: p, reason: collision with root package name */
    public final /* synthetic */ C0313B f5547p;

    public /* synthetic */ C0319H(C0313B c0313b, int i6) {
        this.o = i6;
        this.f5547p = c0313b;
    }

    @Override // M4.c
    public final void g(Object obj) {
        switch (this.o) {
            case 0:
                p5.l lVar = (p5.l) this.f5547p.f5541p;
                if (obj instanceof List) {
                    List list = (List) obj;
                    if (list.size() > 1) {
                        Object obj2 = list.get(0);
                        q5.h.c(obj2, "null cannot be cast to non-null type kotlin.String");
                        Object obj3 = list.get(1);
                        q5.h.c(obj3, "null cannot be cast to non-null type kotlin.String");
                        lVar.a(new C0325N(Q5.a.l(new C0337a((String) obj2, (String) obj3, (String) list.get(2)))));
                        return;
                    }
                    lVar.a(new C0325N((String) list.get(0)));
                    return;
                }
                lVar.a(new C0325N(Q5.a.l(new C0337a("channel-error", "Unable to establish connection on channel: 'dev.flutter.pigeon.webview_flutter_android.WebChromeClient.onJsPrompt'.", StringUtils.EMPTY))));
                return;
            case 1:
                p5.l lVar2 = (p5.l) this.f5547p.f5541p;
                if (obj instanceof List) {
                    List list2 = (List) obj;
                    if (list2.size() > 1) {
                        Object obj4 = list2.get(0);
                        q5.h.c(obj4, "null cannot be cast to non-null type kotlin.String");
                        Object obj5 = list2.get(1);
                        q5.h.c(obj5, "null cannot be cast to non-null type kotlin.String");
                        lVar2.a(new C0325N(Q5.a.l(new C0337a((String) obj4, (String) obj5, (String) list2.get(2)))));
                        return;
                    }
                    lVar2.a(new C0325N(g5.h.f6800a));
                    return;
                }
                lVar2.a(new C0325N(Q5.a.l(new C0337a("channel-error", "Unable to establish connection on channel: 'dev.flutter.pigeon.webview_flutter_android.WebChromeClient.onJsAlert'.", StringUtils.EMPTY))));
                return;
            case 2:
                p5.l lVar3 = (p5.l) this.f5547p.f5541p;
                if (obj instanceof List) {
                    List list3 = (List) obj;
                    if (list3.size() > 1) {
                        Object obj6 = list3.get(0);
                        q5.h.c(obj6, "null cannot be cast to non-null type kotlin.String");
                        Object obj7 = list3.get(1);
                        q5.h.c(obj7, "null cannot be cast to non-null type kotlin.String");
                        lVar3.a(new C0325N(Q5.a.l(new C0337a((String) obj6, (String) obj7, (String) list3.get(2)))));
                        return;
                    }
                    if (list3.get(0) == null) {
                        lVar3.a(new C0325N(Q5.a.l(new C0337a("null-error", "Flutter api returned null value for non-null return value.", StringUtils.EMPTY))));
                        return;
                    }
                    Object obj8 = list3.get(0);
                    q5.h.c(obj8, "null cannot be cast to non-null type kotlin.collections.List<kotlin.String>");
                    lVar3.a(new C0325N((List) obj8));
                    return;
                }
                lVar3.a(new C0325N(Q5.a.l(new C0337a("channel-error", "Unable to establish connection on channel: 'dev.flutter.pigeon.webview_flutter_android.WebChromeClient.onShowFileChooser'.", StringUtils.EMPTY))));
                return;
            default:
                p5.l lVar4 = (p5.l) this.f5547p.f5541p;
                if (obj instanceof List) {
                    List list4 = (List) obj;
                    if (list4.size() > 1) {
                        Object obj9 = list4.get(0);
                        q5.h.c(obj9, "null cannot be cast to non-null type kotlin.String");
                        Object obj10 = list4.get(1);
                        q5.h.c(obj10, "null cannot be cast to non-null type kotlin.String");
                        lVar4.a(new C0325N(Q5.a.l(new C0337a((String) obj9, (String) obj10, (String) list4.get(2)))));
                        return;
                    }
                    if (list4.get(0) == null) {
                        lVar4.a(new C0325N(Q5.a.l(new C0337a("null-error", "Flutter api returned null value for non-null return value.", StringUtils.EMPTY))));
                        return;
                    }
                    Object obj11 = list4.get(0);
                    q5.h.c(obj11, "null cannot be cast to non-null type kotlin.Boolean");
                    lVar4.a(new C0325N((Boolean) obj11));
                    return;
                }
                lVar4.a(new C0325N(Q5.a.l(new C0337a("channel-error", "Unable to establish connection on channel: 'dev.flutter.pigeon.webview_flutter_android.WebChromeClient.onJsConfirm'.", StringUtils.EMPTY))));
                return;
        }
    }
}
