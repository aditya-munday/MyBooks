package c5;

import android.webkit.JsPromptResult;
import android.webkit.JsResult;
import java.util.Objects;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* renamed from: c5.T, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final /* synthetic */ class C0330T implements p5.l {
    public final /* synthetic */ int o;

    /* renamed from: p, reason: collision with root package name */
    public final /* synthetic */ C0332V f5568p;

    /* renamed from: q, reason: collision with root package name */
    public final /* synthetic */ JsResult f5569q;

    public /* synthetic */ C0330T(C0332V c0332v, JsResult jsResult, int i6) {
        this.o = i6;
        this.f5568p = c0332v;
        this.f5569q = jsResult;
    }

    @Override // p5.l
    public final Object a(Object obj) {
        switch (this.o) {
            case 0:
                C0325N c0325n = (C0325N) obj;
                if (c0325n.f5555d) {
                    J2.k kVar = this.f5568p.f5573b.f5633a;
                    Throwable th = c0325n.f5554c;
                    Objects.requireNonNull(th);
                    kVar.getClass();
                    J2.k.i(th);
                    return null;
                }
                boolean equals = Boolean.TRUE.equals(c0325n.f5553b);
                JsResult jsResult = this.f5569q;
                if (equals) {
                    jsResult.confirm();
                    return null;
                }
                jsResult.cancel();
                return null;
            case 1:
                C0325N c0325n2 = (C0325N) obj;
                if (c0325n2.f5555d) {
                    J2.k kVar2 = this.f5568p.f5573b.f5633a;
                    Throwable th2 = c0325n2.f5554c;
                    Objects.requireNonNull(th2);
                    kVar2.getClass();
                    J2.k.i(th2);
                    return null;
                }
                this.f5569q.confirm();
                return null;
            default:
                JsPromptResult jsPromptResult = (JsPromptResult) this.f5569q;
                C0325N c0325n3 = (C0325N) obj;
                if (c0325n3.f5555d) {
                    J2.k kVar3 = this.f5568p.f5573b.f5633a;
                    Throwable th3 = c0325n3.f5554c;
                    Objects.requireNonNull(th3);
                    kVar3.getClass();
                    J2.k.i(th3);
                    return null;
                }
                String str = (String) c0325n3.f5553b;
                if (str != null) {
                    jsPromptResult.confirm(str);
                    return null;
                }
                jsPromptResult.cancel();
                return null;
        }
    }
}
