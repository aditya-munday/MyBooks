package c5;

import android.content.Context;
import android.os.Build;
import android.view.View;
import android.view.ViewParent;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import j2.C0508g;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* loaded from: classes.dex */
public final class d0 extends WebView implements io.flutter.plugin.platform.h {

    /* renamed from: r, reason: collision with root package name */
    public static final /* synthetic */ int f5613r = 0;
    public final C0350n o;

    /* renamed from: p, reason: collision with root package name */
    public WebViewClient f5614p;

    /* renamed from: q, reason: collision with root package name */
    public C0329S f5615q;

    /* JADX WARN: Type inference failed for: r2v2, types: [c5.S, android.webkit.WebChromeClient] */
    public d0(C0350n c0350n) {
        super((Context) c0350n.f5633a.f1305r);
        this.o = c0350n;
        this.f5614p = new WebViewClient();
        this.f5615q = new WebChromeClient();
        setWebViewClient(this.f5614p);
        setWebChromeClient(this.f5615q);
    }

    @Override // android.webkit.WebView
    public WebChromeClient getWebChromeClient() {
        return this.f5615q;
    }

    @Override // android.webkit.WebView, android.view.ViewGroup, android.view.View
    public final void onAttachedToWindow() {
        C4.r rVar;
        super.onAttachedToWindow();
        this.o.f5633a.getClass();
        if (Build.VERSION.SDK_INT >= 26) {
            ViewParent viewParent = this;
            while (true) {
                if (viewParent.getParent() != null) {
                    viewParent = viewParent.getParent();
                    if (viewParent instanceof C4.r) {
                        rVar = (C4.r) viewParent;
                        break;
                    }
                } else {
                    rVar = null;
                    break;
                }
            }
            if (rVar != null) {
                rVar.setImportantForAutofill(1);
            }
        }
    }

    @Override // android.webkit.WebView, android.view.View
    public final void onScrollChanged(final int i6, final int i7, final int i8, final int i9) {
        super.onScrollChanged(i6, i7, i8, i9);
        this.o.f5633a.j(new Runnable() { // from class: c5.c0
            @Override // java.lang.Runnable
            public final void run() {
                d0 d0Var = d0.this;
                C0350n c0350n = d0Var.o;
                long j6 = i6;
                long j7 = i7;
                long j8 = i8;
                long j9 = i9;
                C0354r c0354r = new C0354r(3);
                c0350n.getClass();
                J2.k kVar = c0350n.f5633a;
                kVar.getClass();
                new v3.u((M4.f) kVar.o, "dev.flutter.pigeon.webview_flutter_android.WebView.onScrollChanged", kVar.f(), (C0508g) null).x(h5.e.T(d0Var, Long.valueOf(j6), Long.valueOf(j7), Long.valueOf(j8), Long.valueOf(j9)), new C0322K(c0354r, 2));
            }
        });
    }

    @Override // android.webkit.WebView
    public void setWebChromeClient(WebChromeClient webChromeClient) {
        super.setWebChromeClient(webChromeClient);
        if (webChromeClient instanceof C0329S) {
            C0329S c0329s = (C0329S) webChromeClient;
            this.f5615q = c0329s;
            c0329s.f5567a = this.f5614p;
            return;
        }
        throw new AssertionError("Client must be a SecureWebChromeClient.");
    }

    @Override // android.webkit.WebView
    public void setWebViewClient(WebViewClient webViewClient) {
        super.setWebViewClient(webViewClient);
        this.f5614p = webViewClient;
        this.f5615q.f5567a = webViewClient;
    }

    @Override // io.flutter.plugin.platform.h
    public final void b() {
    }

    @Override // io.flutter.plugin.platform.h
    public View getView() {
        return this;
    }
}
