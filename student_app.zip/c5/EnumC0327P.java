package c5;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* renamed from: c5.P, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public enum EnumC0327P {
    f5557q(0),
    f5558r(1),
    f5559s(2),
    f5560t(3),
    f5561u(4),
    f5562v(5),
    f5563w(6);


    /* renamed from: p, reason: collision with root package name */
    public static final C0351o f5556p = new Object();
    public final int o;

    EnumC0327P(int i6) {
        this.o = i6;
    }
}
