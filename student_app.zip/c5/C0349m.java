package c5;

import android.webkit.ValueCallback;
import g5.C0456e;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* renamed from: c5.m, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final /* synthetic */ class C0349m implements ValueCallback {

    /* renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f5631a;

    /* renamed from: b, reason: collision with root package name */
    public final /* synthetic */ p5.l f5632b;

    public /* synthetic */ C0349m(p5.l lVar, int i6) {
        this.f5631a = i6;
        this.f5632b = lVar;
    }

    @Override // android.webkit.ValueCallback
    public final void onReceiveValue(Object obj) {
        switch (this.f5631a) {
            case 0:
                C0313B c0313b = (C0313B) this.f5632b;
                q5.s.a(1, c0313b);
                c0313b.a(new C0456e((Boolean) obj));
                return;
            default:
                C0313B c0313b2 = (C0313B) this.f5632b;
                q5.s.a(1, c0313b2);
                c0313b2.a(new C0456e((String) obj));
                return;
        }
    }
}
