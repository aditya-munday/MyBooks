package c5;

import a.AbstractC0194a;
import android.app.Activity;
import android.content.Context;
import g5.C0457f;
import j2.C0508g;
import l.r0;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* loaded from: classes.dex */
public class a0 implements I4.b, J4.a {
    public I4.a o;

    /* renamed from: p, reason: collision with root package name */
    public J2.k f5594p;

    @Override // J4.a
    public final void onAttachedToActivity(J4.b bVar) {
        J2.k kVar = this.f5594p;
        if (kVar != null) {
            kVar.f1305r = (Activity) ((r0) bVar).o;
        }
    }

    /* JADX WARN: Type inference failed for: r0v0, types: [J2.k, java.lang.Object] */
    /* JADX WARN: Type inference failed for: r1v24, types: [D0.e, c5.O] */
    @Override // I4.b
    public final void onAttachedToEngine(I4.a aVar) {
        this.o = aVar;
        M4.f fVar = aVar.f1091b;
        Context context = aVar.f1090a;
        C0357u c0357u = new C0357u(context.getAssets(), aVar.e);
        q5.h.e(fVar, "binaryMessenger");
        ?? obj = new Object();
        obj.o = fVar;
        obj.f1303p = new C0339c(new Z4.s(new C0341e(fVar)));
        obj.f1305r = context;
        obj.f1306s = c0357u;
        this.f5594p = obj;
        aVar.f1093d.d("plugins.flutter.io/webview", new A4.e((C0339c) obj.f1303p));
        J2.k kVar = this.f5594p;
        kVar.getClass();
        C0457f c0457f = C0341e.f5616b;
        M4.f fVar2 = (M4.f) kVar.o;
        AbstractC0194a.g0(fVar2, (C0339c) kVar.f1303p);
        T5.h.H(fVar2, new C0350n(kVar, 0));
        T5.h.I(fVar2, new C0350n(kVar, 6));
        Q5.a.G(fVar2, new C0345i(kVar, 5));
        new v3.u(fVar2, "dev.flutter.pigeon.webview_flutter_android.JavaScriptChannel.pigeon_defaultConstructor", kVar.f(), (C0508g) null).y(new C0361y(new C0350n(kVar, 2), 11));
        C0345i c0345i = new C0345i(kVar, 6);
        M4.l f6 = kVar.f();
        new v3.u(fVar2, "dev.flutter.pigeon.webview_flutter_android.WebViewClient.pigeon_defaultConstructor", f6, (C0508g) null).y(new C0361y(c0345i, 28));
        new v3.u(fVar2, "dev.flutter.pigeon.webview_flutter_android.WebViewClient.setSynchronousReturnValueForShouldOverrideUrlLoading", f6, (C0508g) null).y(new C0322K(c0345i, 17));
        new v3.u(fVar2, "dev.flutter.pigeon.webview_flutter_android.DownloadListener.pigeon_defaultConstructor", kVar.f(), (C0508g) null).y(new C0361y(new C0345i(kVar, 1), 6));
        android.support.v4.media.session.a.F(fVar2, new C0350n(kVar, 4));
        AbstractC0194a.i0(fVar2, new C0350n(kVar, 1));
        C0350n c0350n = new C0350n(kVar, 5);
        M4.l f7 = kVar.f();
        new v3.u(fVar2, "dev.flutter.pigeon.webview_flutter_android.WebStorage.instance", f7, (C0508g) null).y(new C0361y(c0350n, 25));
        new v3.u(fVar2, "dev.flutter.pigeon.webview_flutter_android.WebStorage.deleteAllData", f7, (C0508g) null).y(new C0322K(c0350n, 1));
        Object obj2 = new Object();
        M4.l f8 = kVar.f();
        new v3.u(fVar2, "dev.flutter.pigeon.webview_flutter_android.PermissionRequest.grant", f8, (C0508g) null).y(new a0.e(obj2, 18));
        new v3.u(fVar2, "dev.flutter.pigeon.webview_flutter_android.PermissionRequest.deny", f8, (C0508g) null).y(new a0.e(obj2, 19));
        new v3.u(fVar2, "dev.flutter.pigeon.webview_flutter_android.CustomViewCallback.onCustomViewHidden", kVar.f(), (C0508g) null).y(new a0.e(new Object(), 14));
        AbstractC0194a.h0(fVar2, new C0345i(kVar, 4));
        new v3.u(fVar2, "dev.flutter.pigeon.webview_flutter_android.GeolocationPermissionsCallback.invoke", kVar.f(), (C0508g) null).y(new a0.e(new Object(), 16));
        android.support.v4.media.session.a.E(fVar2, new C0345i(kVar, 2));
        new v3.u(fVar2, "dev.flutter.pigeon.webview_flutter_android.AndroidMessage.sendToTarget", kVar.f(), (C0508g) null).y(new a0.e(new C0346j(2), 12));
        Q5.a.E(fVar2, new C0345i(kVar, 0));
        C0346j c0346j = new C0346j(4);
        M4.l f9 = kVar.f();
        new v3.u(fVar2, "dev.flutter.pigeon.webview_flutter_android.SslErrorHandler.cancel", f9, (C0508g) null).y(new a0.e(c0346j, 21));
        new v3.u(fVar2, "dev.flutter.pigeon.webview_flutter_android.SslErrorHandler.proceed", f9, (C0508g) null).y(new a0.e(c0346j, 22));
        C0350n c0350n2 = new C0350n(kVar, 3);
        M4.l f10 = kVar.f();
        new v3.u(fVar2, "dev.flutter.pigeon.webview_flutter_android.SslError.getPrimaryError", f10, (C0508g) null).y(new a0.e(c0350n2, 20));
        new v3.u(fVar2, "dev.flutter.pigeon.webview_flutter_android.SslError.hasError", f10, (C0508g) null).y(new C0361y(c0350n2, 17));
        T5.h.G(fVar2, new C0345i(kVar, 3));
        Q5.a.F(fVar2, new D0.e(kVar));
        new v3.u(fVar2, "dev.flutter.pigeon.webview_flutter_android.Certificate.getEncoded", kVar.f(), (C0508g) null).y(new a0.e(new m3.e(29), 13));
        new v3.u(fVar2, "dev.flutter.pigeon.webview_flutter_android.WebSettingsCompat.setPaymentRequestEnabled", kVar.f(), (C0508g) null).y(new C0322K(new C0346j(5), 0));
        new v3.u(fVar2, "dev.flutter.pigeon.webview_flutter_android.WebViewFeature.isFeatureSupported", kVar.f(), (C0508g) null).y(new C0322K(new Object(), 18));
    }

    @Override // J4.a
    public final void onDetachedFromActivity() {
        this.f5594p.f1305r = this.o.f1090a;
    }

    @Override // J4.a
    public final void onDetachedFromActivityForConfigChanges() {
        this.f5594p.f1305r = this.o.f1090a;
    }

    @Override // I4.b
    public final void onDetachedFromEngine(I4.a aVar) {
        J2.k kVar = this.f5594p;
        if (kVar != null) {
            C0457f c0457f = C0341e.f5616b;
            M4.f fVar = (M4.f) kVar.o;
            AbstractC0194a.g0(fVar, null);
            T5.h.H(fVar, null);
            T5.h.I(fVar, null);
            Q5.a.G(fVar, null);
            new v3.u(fVar, "dev.flutter.pigeon.webview_flutter_android.JavaScriptChannel.pigeon_defaultConstructor", new defpackage.g(2), (C0508g) null).y(null);
            defpackage.g gVar = new defpackage.g(2);
            new v3.u(fVar, "dev.flutter.pigeon.webview_flutter_android.WebViewClient.pigeon_defaultConstructor", gVar, (C0508g) null).y(null);
            new v3.u(fVar, "dev.flutter.pigeon.webview_flutter_android.WebViewClient.setSynchronousReturnValueForShouldOverrideUrlLoading", gVar, (C0508g) null).y(null);
            new v3.u(fVar, "dev.flutter.pigeon.webview_flutter_android.DownloadListener.pigeon_defaultConstructor", new defpackage.g(2), (C0508g) null).y(null);
            android.support.v4.media.session.a.F(fVar, null);
            AbstractC0194a.i0(fVar, null);
            defpackage.g gVar2 = new defpackage.g(2);
            new v3.u(fVar, "dev.flutter.pigeon.webview_flutter_android.WebStorage.instance", gVar2, (C0508g) null).y(null);
            new v3.u(fVar, "dev.flutter.pigeon.webview_flutter_android.WebStorage.deleteAllData", gVar2, (C0508g) null).y(null);
            defpackage.g gVar3 = new defpackage.g(2);
            new v3.u(fVar, "dev.flutter.pigeon.webview_flutter_android.PermissionRequest.grant", gVar3, (C0508g) null).y(null);
            new v3.u(fVar, "dev.flutter.pigeon.webview_flutter_android.PermissionRequest.deny", gVar3, (C0508g) null).y(null);
            new v3.u(fVar, "dev.flutter.pigeon.webview_flutter_android.CustomViewCallback.onCustomViewHidden", new defpackage.g(2), (C0508g) null).y(null);
            AbstractC0194a.h0(fVar, null);
            new v3.u(fVar, "dev.flutter.pigeon.webview_flutter_android.GeolocationPermissionsCallback.invoke", new defpackage.g(2), (C0508g) null).y(null);
            android.support.v4.media.session.a.E(fVar, null);
            new v3.u(fVar, "dev.flutter.pigeon.webview_flutter_android.AndroidMessage.sendToTarget", new defpackage.g(2), (C0508g) null).y(null);
            Q5.a.E(fVar, null);
            defpackage.g gVar4 = new defpackage.g(2);
            new v3.u(fVar, "dev.flutter.pigeon.webview_flutter_android.SslErrorHandler.cancel", gVar4, (C0508g) null).y(null);
            new v3.u(fVar, "dev.flutter.pigeon.webview_flutter_android.SslErrorHandler.proceed", gVar4, (C0508g) null).y(null);
            defpackage.g gVar5 = new defpackage.g(2);
            new v3.u(fVar, "dev.flutter.pigeon.webview_flutter_android.SslError.getPrimaryError", gVar5, (C0508g) null).y(null);
            new v3.u(fVar, "dev.flutter.pigeon.webview_flutter_android.SslError.hasError", gVar5, (C0508g) null).y(null);
            T5.h.G(fVar, null);
            Q5.a.F(fVar, null);
            new v3.u(fVar, "dev.flutter.pigeon.webview_flutter_android.Certificate.getEncoded", new defpackage.g(2), (C0508g) null).y(null);
            new v3.u(fVar, "dev.flutter.pigeon.webview_flutter_android.WebSettingsCompat.setPaymentRequestEnabled", new defpackage.g(2), (C0508g) null).y(null);
            new v3.u(fVar, "dev.flutter.pigeon.webview_flutter_android.WebViewFeature.isFeatureSupported", new defpackage.g(2), (C0508g) null).y(null);
            C0339c c0339c = (C0339c) this.f5594p.f1303p;
            c0339c.f5603g.removeCallbacks(c0339c.f5604h);
            c0339c.f5606j = true;
            this.f5594p = null;
        }
    }

    @Override // J4.a
    public final void onReattachedToActivityForConfigChanges(J4.b bVar) {
        this.f5594p.f1305r = (Activity) ((r0) bVar).o;
    }
}
