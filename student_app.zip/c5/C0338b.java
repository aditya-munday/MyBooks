package c5;

import java.lang.ref.ReferenceQueue;
import java.lang.ref.WeakReference;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* renamed from: c5.b, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0338b extends WeakReference {

    /* renamed from: a, reason: collision with root package name */
    public final int f5595a;

    /* JADX WARN: 'this' call moved to the top of the method (can break code semantics) */
    public C0338b(Object obj) {
        this(obj, null);
        q5.h.e(obj, "instance");
    }

    public final boolean equals(Object obj) {
        T t6 = get();
        if (t6 != 0) {
            if (!(obj instanceof C0338b) || ((C0338b) obj).get() != t6) {
                return false;
            }
            return true;
        }
        if (obj != this) {
            return false;
        }
        return true;
    }

    public final int hashCode() {
        return this.f5595a;
    }

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public C0338b(Object obj, ReferenceQueue referenceQueue) {
        super(obj, referenceQueue);
        q5.h.e(obj, "instance");
        this.f5595a = System.identityHashCode(obj);
    }
}
