package c5;

import g5.C0457f;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* renamed from: c5.e, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0341e {

    /* renamed from: b, reason: collision with root package name */
    public static final C0457f f5616b = new C0457f(new defpackage.c(4));

    /* renamed from: a, reason: collision with root package name */
    public final M4.f f5617a;

    public C0341e(M4.f fVar) {
        q5.h.e(fVar, "binaryMessenger");
        this.f5617a = fVar;
    }
}
