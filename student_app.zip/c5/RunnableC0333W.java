package c5;

import android.webkit.WebView;
import j2.C0508g;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* renamed from: c5.W, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final /* synthetic */ class RunnableC0333W implements Runnable {
    public final /* synthetic */ int o;

    /* renamed from: p, reason: collision with root package name */
    public final /* synthetic */ C0336Z f5578p;

    /* renamed from: q, reason: collision with root package name */
    public final /* synthetic */ WebView f5579q;

    /* renamed from: r, reason: collision with root package name */
    public final /* synthetic */ String f5580r;

    public /* synthetic */ RunnableC0333W(C0336Z c0336z, WebView webView, String str, int i6) {
        this.o = i6;
        this.f5578p = c0336z;
        this.f5579q = webView;
        this.f5580r = str;
    }

    @Override // java.lang.Runnable
    public final void run() {
        switch (this.o) {
            case 0:
                C0336Z c0336z = this.f5578p;
                C0345i c0345i = c0336z.f5590a;
                C0354r c0354r = new C0354r(2);
                c0345i.getClass();
                WebView webView = this.f5579q;
                q5.h.e(webView, "webViewArg");
                String str = this.f5580r;
                q5.h.e(str, "urlArg");
                J2.k kVar = c0345i.f5619a;
                kVar.getClass();
                new v3.u((M4.f) kVar.o, "dev.flutter.pigeon.webview_flutter_android.WebViewClient.onPageStarted", kVar.f(), (C0508g) null).x(h5.e.T(c0336z, webView, str), new C0322K(c0354r, 6));
                return;
            case 1:
                C0336Z c0336z2 = this.f5578p;
                C0345i c0345i2 = c0336z2.f5590a;
                C0354r c0354r2 = new C0354r(2);
                c0345i2.getClass();
                WebView webView2 = this.f5579q;
                q5.h.e(webView2, "viewArg");
                String str2 = this.f5580r;
                q5.h.e(str2, "urlArg");
                J2.k kVar2 = c0345i2.f5619a;
                kVar2.getClass();
                new v3.u((M4.f) kVar2.o, "dev.flutter.pigeon.webview_flutter_android.WebViewClient.onLoadResource", kVar2.f(), (C0508g) null).x(h5.e.T(c0336z2, webView2, str2), new C0322K(c0354r2, 4));
                return;
            case 2:
                C0336Z c0336z3 = this.f5578p;
                C0345i c0345i3 = c0336z3.f5590a;
                C0354r c0354r3 = new C0354r(2);
                c0345i3.getClass();
                WebView webView3 = this.f5579q;
                q5.h.e(webView3, "webViewArg");
                String str3 = this.f5580r;
                q5.h.e(str3, "urlArg");
                J2.k kVar3 = c0345i3.f5619a;
                kVar3.getClass();
                new v3.u((M4.f) kVar3.o, "dev.flutter.pigeon.webview_flutter_android.WebViewClient.onPageFinished", kVar3.f(), (C0508g) null).x(h5.e.T(c0336z3, webView3, str3), new C0322K(c0354r3, 11));
                return;
            default:
                C0336Z c0336z4 = this.f5578p;
                C0345i c0345i4 = c0336z4.f5590a;
                C0354r c0354r4 = new C0354r(2);
                c0345i4.getClass();
                WebView webView4 = this.f5579q;
                q5.h.e(webView4, "viewArg");
                String str4 = this.f5580r;
                q5.h.e(str4, "urlArg");
                J2.k kVar4 = c0345i4.f5619a;
                kVar4.getClass();
                new v3.u((M4.f) kVar4.o, "dev.flutter.pigeon.webview_flutter_android.WebViewClient.onPageCommitVisible", kVar4.f(), (C0508g) null).x(h5.e.T(c0336z4, webView4, str4), new C0322K(c0354r4, 9));
                return;
        }
    }
}
