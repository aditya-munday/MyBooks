package c5;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* renamed from: c5.w, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public enum EnumC0359w {
    /* JADX INFO: Fake field, exist only in values array */
    EF5(0),
    /* JADX INFO: Fake field, exist only in values array */
    EF13(1),
    /* JADX INFO: Fake field, exist only in values array */
    EF21(2);


    /* renamed from: p, reason: collision with root package name */
    public static final C0351o f5653p = new Object();
    public final int o;

    EnumC0359w(int i6) {
        this.o = i6;
    }
}
