package c5;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* renamed from: c5.t, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public enum EnumC0356t {
    f5644q(0),
    f5645r(1),
    f5646s(2),
    f5647t(3);


    /* renamed from: p, reason: collision with root package name */
    public static final C0346j f5643p = new C0346j(1);
    public final int o;

    EnumC0356t(int i6) {
        this.o = i6;
    }
}
