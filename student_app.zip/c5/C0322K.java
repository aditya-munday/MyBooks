package c5;

import C4.AbstractC0034i;
import android.util.Log;
import android.view.View;
import android.webkit.WebSettings;
import android.webkit.WebStorage;
import android.webkit.WebViewClient;
import androidx.datastore.preferences.protobuf.AbstractC0227o;
import b3.InterfaceC0264d;
import com.google.firebase.datatransport.TransportRegistrar;
import e1.C0410D;
import e1.C0411a;
import e1.C0413c;
import e1.C0414d;
import f1.C0437a;
import java.util.List;
import org.apache.tika.fork.ContentHandlerProxy;
import org.apache.tika.pipes.PipesServer;
import org.apache.tika.utils.StringUtils;
import org.apache.tika.utils.XMLReaderUtils;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* renamed from: c5.K, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final /* synthetic */ class C0322K implements M4.b, M4.c, InterfaceC0264d, d5.c, x0.r, D2.d {
    public final /* synthetic */ int o;

    public /* synthetic */ C0322K(int i6) {
        this.o = i6;
    }

    @Override // d5.c
    public boolean a(View view) {
        return view.hasFocus();
    }

    @Override // D2.d
    public Object apply(Object obj) {
        f0.q qVar = (f0.q) obj;
        qVar.u();
        return E2.I.u(E2.r.u(qVar.f6486W.f9081b, new C0437a(26)));
    }

    @Override // b3.InterfaceC0264d
    public Object b(Q2.n nVar) {
        switch (this.o) {
            case XMLReaderUtils.DEFAULT_MAX_ENTITY_EXPANSIONS /* 20 */:
                return TransportRegistrar.c(nVar);
            case 21:
                return TransportRegistrar.b(nVar);
            default:
                return TransportRegistrar.a(nVar);
        }
    }

    @Override // x0.r
    public x0.o[] c() {
        switch (this.o) {
            case 24:
                return new x0.o[]{new C0411a()};
            case 25:
                return new x0.o[]{new C0413c()};
            case 26:
                return new x0.o[]{new C0414d(0)};
            case 27:
                return new x0.o[]{new e1.z()};
            default:
                V.A a6 = new V.A(0L);
                E2.G g2 = E2.I.f699p;
                return new x0.o[]{new C0410D(1, 1, U0.j.f2959c, a6, new A.l(0, E2.Z.f721s))};
        }
    }

    @Override // M4.b
    public void e(Object obj, A.c cVar) {
        List T6;
        List T7;
        List T8;
        List T9;
        switch (this.o) {
            case 0:
                q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                List list = (List) obj;
                Object obj2 = list.get(0);
                q5.h.c(obj2, "null cannot be cast to non-null type android.webkit.WebSettings");
                WebSettings webSettings = (WebSettings) obj2;
                Object obj3 = list.get(1);
                q5.h.c(obj3, "null cannot be cast to non-null type kotlin.Boolean");
                try {
                    C0346j.p(webSettings, ((Boolean) obj3).booleanValue());
                    T6 = android.support.v4.media.session.a.z(null);
                } catch (Throwable th) {
                    if (th instanceof C0337a) {
                        C0337a c0337a = th;
                        T6 = h5.e.T(c0337a.o, c0337a.f5592p, c0337a.f5593q);
                    } else {
                        T6 = h5.e.T(th.getClass().getSimpleName(), th.toString(), AbstractC0034i.k("Cause: ", th.getCause(), ", Stacktrace: ", Log.getStackTraceString(th)));
                    }
                }
                cVar.g(T6);
                return;
            case 1:
                q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                Object obj4 = ((List) obj).get(0);
                q5.h.c(obj4, "null cannot be cast to non-null type android.webkit.WebStorage");
                try {
                    ((WebStorage) obj4).deleteAllData();
                    T7 = android.support.v4.media.session.a.z(null);
                } catch (Throwable th2) {
                    if (th2 instanceof C0337a) {
                        C0337a c0337a2 = th2;
                        T7 = h5.e.T(c0337a2.o, c0337a2.f5592p, c0337a2.f5593q);
                    } else {
                        T7 = h5.e.T(th2.getClass().getSimpleName(), th2.toString(), AbstractC0034i.k("Cause: ", th2.getCause(), ", Stacktrace: ", Log.getStackTraceString(th2)));
                    }
                }
                cVar.g(T7);
                return;
            case PipesServer.TIMEOUT_EXIT_CODE /* 17 */:
                q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                List list2 = (List) obj;
                Object obj5 = list2.get(0);
                q5.h.c(obj5, "null cannot be cast to non-null type android.webkit.WebViewClient");
                WebViewClient webViewClient = (WebViewClient) obj5;
                Object obj6 = list2.get(1);
                q5.h.c(obj6, "null cannot be cast to non-null type kotlin.Boolean");
                boolean booleanValue = ((Boolean) obj6).booleanValue();
                try {
                } catch (Throwable th3) {
                    if (th3 instanceof C0337a) {
                        C0337a c0337a3 = th3;
                        T8 = h5.e.T(c0337a3.o, c0337a3.f5592p, c0337a3.f5593q);
                    } else {
                        T8 = h5.e.T(th3.getClass().getSimpleName(), th3.toString(), AbstractC0034i.k("Cause: ", th3.getCause(), ", Stacktrace: ", Log.getStackTraceString(th3)));
                    }
                }
                if (webViewClient instanceof C0336Z) {
                    ((C0336Z) webViewClient).f5591b = booleanValue;
                    T8 = android.support.v4.media.session.a.z(null);
                    cVar.g(T8);
                    return;
                }
                throw new IllegalStateException("This WebViewClient doesn't support setting the returnValueForShouldOverrideUrlLoading.");
            default:
                q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                Object obj7 = ((List) obj).get(0);
                q5.h.c(obj7, "null cannot be cast to non-null type kotlin.String");
                try {
                    T9 = android.support.v4.media.session.a.z(Boolean.valueOf(T5.h.v((String) obj7)));
                } catch (Throwable th4) {
                    if (th4 instanceof C0337a) {
                        C0337a c0337a4 = th4;
                        T9 = h5.e.T(c0337a4.o, c0337a4.f5592p, c0337a4.f5593q);
                    } else {
                        T9 = h5.e.T(th4.getClass().getSimpleName(), th4.toString(), AbstractC0034i.k("Cause: ", th4.getCause(), ", Stacktrace: ", Log.getStackTraceString(th4)));
                    }
                }
                cVar.g(T9);
                return;
        }
    }

    @Override // M4.c
    public void g(Object obj) {
        switch (this.o) {
            case 2:
                if (obj instanceof List) {
                    List list = (List) obj;
                    if (list.size() > 1) {
                        Object obj2 = list.get(0);
                        q5.h.c(obj2, "null cannot be cast to non-null type kotlin.String");
                        Object obj3 = list.get(1);
                        q5.h.c(obj3, "null cannot be cast to non-null type kotlin.String");
                        Q5.a.l(new C0337a((String) obj2, (String) obj3, (String) list.get(2)));
                        int i6 = d0.f5613r;
                        return;
                    }
                    int i7 = d0.f5613r;
                    return;
                }
                AbstractC0227o.o("channel-error", "Unable to establish connection on channel: 'dev.flutter.pigeon.webview_flutter_android.WebView.onScrollChanged'.", StringUtils.EMPTY);
                int i8 = d0.f5613r;
                return;
            case 3:
                if (obj instanceof List) {
                    List list2 = (List) obj;
                    if (list2.size() > 1) {
                        Object obj4 = list2.get(0);
                        q5.h.c(obj4, "null cannot be cast to non-null type kotlin.String");
                        Object obj5 = list2.get(1);
                        q5.h.c(obj5, "null cannot be cast to non-null type kotlin.String");
                        Q5.a.l(new C0337a((String) obj4, (String) obj5, (String) list2.get(2)));
                        int i9 = C0336Z.f5589c;
                        return;
                    }
                    int i10 = C0336Z.f5589c;
                    return;
                }
                AbstractC0227o.o("channel-error", "Unable to establish connection on channel: 'dev.flutter.pigeon.webview_flutter_android.WebViewClient.onReceivedHttpError'.", StringUtils.EMPTY);
                int i11 = C0336Z.f5589c;
                return;
            case 4:
                if (obj instanceof List) {
                    List list3 = (List) obj;
                    if (list3.size() > 1) {
                        Object obj6 = list3.get(0);
                        q5.h.c(obj6, "null cannot be cast to non-null type kotlin.String");
                        Object obj7 = list3.get(1);
                        q5.h.c(obj7, "null cannot be cast to non-null type kotlin.String");
                        Q5.a.l(new C0337a((String) obj6, (String) obj7, (String) list3.get(2)));
                        int i12 = C0336Z.f5589c;
                        return;
                    }
                    int i13 = C0336Z.f5589c;
                    return;
                }
                AbstractC0227o.o("channel-error", "Unable to establish connection on channel: 'dev.flutter.pigeon.webview_flutter_android.WebViewClient.onLoadResource'.", StringUtils.EMPTY);
                int i14 = C0336Z.f5589c;
                return;
            case 5:
                if (obj instanceof List) {
                    List list4 = (List) obj;
                    if (list4.size() > 1) {
                        Object obj8 = list4.get(0);
                        q5.h.c(obj8, "null cannot be cast to non-null type kotlin.String");
                        Object obj9 = list4.get(1);
                        q5.h.c(obj9, "null cannot be cast to non-null type kotlin.String");
                        Q5.a.l(new C0337a((String) obj8, (String) obj9, (String) list4.get(2)));
                        int i15 = C0336Z.f5589c;
                        return;
                    }
                    int i16 = C0336Z.f5589c;
                    return;
                }
                AbstractC0227o.o("channel-error", "Unable to establish connection on channel: 'dev.flutter.pigeon.webview_flutter_android.WebViewClient.onReceivedLoginRequest'.", StringUtils.EMPTY);
                int i17 = C0336Z.f5589c;
                return;
            case 6:
                if (obj instanceof List) {
                    List list5 = (List) obj;
                    if (list5.size() > 1) {
                        Object obj10 = list5.get(0);
                        q5.h.c(obj10, "null cannot be cast to non-null type kotlin.String");
                        Object obj11 = list5.get(1);
                        q5.h.c(obj11, "null cannot be cast to non-null type kotlin.String");
                        Q5.a.l(new C0337a((String) obj10, (String) obj11, (String) list5.get(2)));
                        int i18 = C0336Z.f5589c;
                        return;
                    }
                    int i19 = C0336Z.f5589c;
                    return;
                }
                AbstractC0227o.o("channel-error", "Unable to establish connection on channel: 'dev.flutter.pigeon.webview_flutter_android.WebViewClient.onPageStarted'.", StringUtils.EMPTY);
                int i20 = C0336Z.f5589c;
                return;
            case 7:
                if (obj instanceof List) {
                    List list6 = (List) obj;
                    if (list6.size() > 1) {
                        Object obj12 = list6.get(0);
                        q5.h.c(obj12, "null cannot be cast to non-null type kotlin.String");
                        Object obj13 = list6.get(1);
                        q5.h.c(obj13, "null cannot be cast to non-null type kotlin.String");
                        Q5.a.l(new C0337a((String) obj12, (String) obj13, (String) list6.get(2)));
                        int i21 = C0336Z.f5589c;
                        return;
                    }
                    int i22 = C0336Z.f5589c;
                    return;
                }
                AbstractC0227o.o("channel-error", "Unable to establish connection on channel: 'dev.flutter.pigeon.webview_flutter_android.WebViewClient.onReceivedClientCertRequest'.", StringUtils.EMPTY);
                int i23 = C0336Z.f5589c;
                return;
            case 8:
                if (obj instanceof List) {
                    List list7 = (List) obj;
                    if (list7.size() > 1) {
                        Object obj14 = list7.get(0);
                        q5.h.c(obj14, "null cannot be cast to non-null type kotlin.String");
                        Object obj15 = list7.get(1);
                        q5.h.c(obj15, "null cannot be cast to non-null type kotlin.String");
                        Q5.a.l(new C0337a((String) obj14, (String) obj15, (String) list7.get(2)));
                        int i24 = C0336Z.f5589c;
                        return;
                    }
                    int i25 = C0336Z.f5589c;
                    return;
                }
                AbstractC0227o.o("channel-error", "Unable to establish connection on channel: 'dev.flutter.pigeon.webview_flutter_android.WebViewClient.requestLoading'.", StringUtils.EMPTY);
                int i26 = C0336Z.f5589c;
                return;
            case ContentHandlerProxy.PROCESSING_INSTRUCTION /* 9 */:
                if (obj instanceof List) {
                    List list8 = (List) obj;
                    if (list8.size() > 1) {
                        Object obj16 = list8.get(0);
                        q5.h.c(obj16, "null cannot be cast to non-null type kotlin.String");
                        Object obj17 = list8.get(1);
                        q5.h.c(obj17, "null cannot be cast to non-null type kotlin.String");
                        Q5.a.l(new C0337a((String) obj16, (String) obj17, (String) list8.get(2)));
                        int i27 = C0336Z.f5589c;
                        return;
                    }
                    int i28 = C0336Z.f5589c;
                    return;
                }
                AbstractC0227o.o("channel-error", "Unable to establish connection on channel: 'dev.flutter.pigeon.webview_flutter_android.WebViewClient.onPageCommitVisible'.", StringUtils.EMPTY);
                int i29 = C0336Z.f5589c;
                return;
            case 10:
                if (obj instanceof List) {
                    List list9 = (List) obj;
                    if (list9.size() > 1) {
                        Object obj18 = list9.get(0);
                        q5.h.c(obj18, "null cannot be cast to non-null type kotlin.String");
                        Object obj19 = list9.get(1);
                        q5.h.c(obj19, "null cannot be cast to non-null type kotlin.String");
                        Q5.a.l(new C0337a((String) obj18, (String) obj19, (String) list9.get(2)));
                        int i30 = C0336Z.f5589c;
                        return;
                    }
                    int i31 = C0336Z.f5589c;
                    return;
                }
                AbstractC0227o.o("channel-error", "Unable to establish connection on channel: 'dev.flutter.pigeon.webview_flutter_android.WebViewClient.onReceivedRequestError'.", StringUtils.EMPTY);
                int i32 = C0336Z.f5589c;
                return;
            case 11:
                if (obj instanceof List) {
                    List list10 = (List) obj;
                    if (list10.size() > 1) {
                        Object obj20 = list10.get(0);
                        q5.h.c(obj20, "null cannot be cast to non-null type kotlin.String");
                        Object obj21 = list10.get(1);
                        q5.h.c(obj21, "null cannot be cast to non-null type kotlin.String");
                        Q5.a.l(new C0337a((String) obj20, (String) obj21, (String) list10.get(2)));
                        int i33 = C0336Z.f5589c;
                        return;
                    }
                    int i34 = C0336Z.f5589c;
                    return;
                }
                AbstractC0227o.o("channel-error", "Unable to establish connection on channel: 'dev.flutter.pigeon.webview_flutter_android.WebViewClient.onPageFinished'.", StringUtils.EMPTY);
                int i35 = C0336Z.f5589c;
                return;
            case 12:
                if (obj instanceof List) {
                    List list11 = (List) obj;
                    if (list11.size() > 1) {
                        Object obj22 = list11.get(0);
                        q5.h.c(obj22, "null cannot be cast to non-null type kotlin.String");
                        Object obj23 = list11.get(1);
                        q5.h.c(obj23, "null cannot be cast to non-null type kotlin.String");
                        Q5.a.l(new C0337a((String) obj22, (String) obj23, (String) list11.get(2)));
                        int i36 = C0336Z.f5589c;
                        return;
                    }
                    int i37 = C0336Z.f5589c;
                    return;
                }
                AbstractC0227o.o("channel-error", "Unable to establish connection on channel: 'dev.flutter.pigeon.webview_flutter_android.WebViewClient.onReceivedHttpAuthRequest'.", StringUtils.EMPTY);
                int i38 = C0336Z.f5589c;
                return;
            case 13:
                if (obj instanceof List) {
                    List list12 = (List) obj;
                    if (list12.size() > 1) {
                        Object obj24 = list12.get(0);
                        q5.h.c(obj24, "null cannot be cast to non-null type kotlin.String");
                        Object obj25 = list12.get(1);
                        q5.h.c(obj25, "null cannot be cast to non-null type kotlin.String");
                        Q5.a.l(new C0337a((String) obj24, (String) obj25, (String) list12.get(2)));
                        int i39 = C0336Z.f5589c;
                        return;
                    }
                    int i40 = C0336Z.f5589c;
                    return;
                }
                AbstractC0227o.o("channel-error", "Unable to establish connection on channel: 'dev.flutter.pigeon.webview_flutter_android.WebViewClient.onFormResubmission'.", StringUtils.EMPTY);
                int i41 = C0336Z.f5589c;
                return;
            case 14:
                if (obj instanceof List) {
                    List list13 = (List) obj;
                    if (list13.size() > 1) {
                        Object obj26 = list13.get(0);
                        q5.h.c(obj26, "null cannot be cast to non-null type kotlin.String");
                        Object obj27 = list13.get(1);
                        q5.h.c(obj27, "null cannot be cast to non-null type kotlin.String");
                        Q5.a.l(new C0337a((String) obj26, (String) obj27, (String) list13.get(2)));
                        int i42 = C0336Z.f5589c;
                        return;
                    }
                    int i43 = C0336Z.f5589c;
                    return;
                }
                AbstractC0227o.o("channel-error", "Unable to establish connection on channel: 'dev.flutter.pigeon.webview_flutter_android.WebViewClient.onReceivedSslError'.", StringUtils.EMPTY);
                int i44 = C0336Z.f5589c;
                return;
            case 15:
                if (obj instanceof List) {
                    List list14 = (List) obj;
                    if (list14.size() > 1) {
                        Object obj28 = list14.get(0);
                        q5.h.c(obj28, "null cannot be cast to non-null type kotlin.String");
                        Object obj29 = list14.get(1);
                        q5.h.c(obj29, "null cannot be cast to non-null type kotlin.String");
                        Q5.a.l(new C0337a((String) obj28, (String) obj29, (String) list14.get(2)));
                        int i45 = C0336Z.f5589c;
                        return;
                    }
                    int i46 = C0336Z.f5589c;
                    return;
                }
                AbstractC0227o.o("channel-error", "Unable to establish connection on channel: 'dev.flutter.pigeon.webview_flutter_android.WebViewClient.onScaleChanged'.", StringUtils.EMPTY);
                int i47 = C0336Z.f5589c;
                return;
            default:
                if (obj instanceof List) {
                    List list15 = (List) obj;
                    if (list15.size() > 1) {
                        Object obj30 = list15.get(0);
                        q5.h.c(obj30, "null cannot be cast to non-null type kotlin.String");
                        Object obj31 = list15.get(1);
                        q5.h.c(obj31, "null cannot be cast to non-null type kotlin.String");
                        Q5.a.l(new C0337a((String) obj30, (String) obj31, (String) list15.get(2)));
                        int i48 = C0336Z.f5589c;
                        return;
                    }
                    int i49 = C0336Z.f5589c;
                    return;
                }
                AbstractC0227o.o("channel-error", "Unable to establish connection on channel: 'dev.flutter.pigeon.webview_flutter_android.WebViewClient.doUpdateVisitedHistory'.", StringUtils.EMPTY);
                int i50 = C0336Z.f5589c;
                return;
        }
    }

    public /* synthetic */ C0322K(Object obj, int i6) {
        this.o = i6;
    }
}
