package c5;

import C4.AbstractC0034i;
import android.net.http.SslError;
import android.util.Log;
import android.webkit.WebStorage;
import androidx.datastore.preferences.protobuf.AbstractC0227o;
import java.util.List;
import org.apache.tika.fork.ContentHandlerProxy;
import org.apache.tika.pipes.PipesServer;
import org.apache.tika.utils.StringUtils;
import org.apache.tika.utils.XMLReaderUtils;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* renamed from: c5.y, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final /* synthetic */ class C0361y implements M4.c, M4.b {
    public final /* synthetic */ int o;

    /* renamed from: p, reason: collision with root package name */
    public final /* synthetic */ Object f5658p;

    public /* synthetic */ C0361y(Object obj, int i6) {
        this.o = i6;
        this.f5658p = obj;
    }

    /* JADX WARN: Can't fix incorrect switch cases order, some code will duplicate */
    /* JADX WARN: Failed to find 'out' block for switch in B:29:0x0105. Please report as an issue. */
    @Override // M4.b
    public void e(Object obj, A.c cVar) {
        List T6;
        List T7;
        List T8;
        List T9;
        List T10;
        switch (this.o) {
            case 6:
                C0345i c0345i = (C0345i) this.f5658p;
                q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                Object obj2 = ((List) obj).get(0);
                q5.h.c(obj2, "null cannot be cast to non-null type kotlin.Long");
                try {
                    ((C0339c) c0345i.f5619a.f1303p).a(((Long) obj2).longValue(), new C0355s(c0345i));
                    T6 = android.support.v4.media.session.a.z(null);
                } catch (Throwable th) {
                    if (th instanceof C0337a) {
                        C0337a c0337a = th;
                        T6 = h5.e.T(c0337a.o, c0337a.f5592p, c0337a.f5593q);
                    } else {
                        T6 = h5.e.T(th.getClass().getSimpleName(), th.toString(), AbstractC0034i.k("Cause: ", th.getCause(), ", Stacktrace: ", Log.getStackTraceString(th)));
                    }
                }
                cVar.g(T6);
                return;
            case 11:
                C0350n c0350n = (C0350n) this.f5658p;
                q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                List list = (List) obj;
                Object obj3 = list.get(0);
                q5.h.c(obj3, "null cannot be cast to non-null type kotlin.Long");
                long longValue = ((Long) obj3).longValue();
                Object obj4 = list.get(1);
                q5.h.c(obj4, "null cannot be cast to non-null type kotlin.String");
                try {
                    ((C0339c) c0350n.f5633a.f1303p).a(longValue, new C0358v((String) obj4, c0350n));
                    T7 = android.support.v4.media.session.a.z(null);
                } catch (Throwable th2) {
                    if (th2 instanceof C0337a) {
                        C0337a c0337a2 = th2;
                        T7 = h5.e.T(c0337a2.o, c0337a2.f5592p, c0337a2.f5593q);
                    } else {
                        T7 = h5.e.T(th2.getClass().getSimpleName(), th2.toString(), AbstractC0034i.k("Cause: ", th2.getCause(), ", Stacktrace: ", Log.getStackTraceString(th2)));
                    }
                }
                cVar.g(T7);
                return;
            case PipesServer.TIMEOUT_EXIT_CODE /* 17 */:
                C0350n c0350n2 = (C0350n) this.f5658p;
                q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                List list2 = (List) obj;
                int i6 = 0;
                Object obj5 = list2.get(0);
                q5.h.c(obj5, "null cannot be cast to non-null type android.net.http.SslError");
                SslError sslError = (SslError) obj5;
                Object obj6 = list2.get(1);
                q5.h.c(obj6, "null cannot be cast to non-null type io.flutter.plugins.webviewflutter.SslErrorType");
                EnumC0327P enumC0327P = (EnumC0327P) obj6;
                try {
                } catch (Throwable th3) {
                    if (th3 instanceof C0337a) {
                        C0337a c0337a3 = th3;
                        T8 = h5.e.T(c0337a3.o, c0337a3.f5592p, c0337a3.f5593q);
                    } else {
                        T8 = h5.e.T(th3.getClass().getSimpleName(), th3.toString(), AbstractC0034i.k("Cause: ", th3.getCause(), ", Stacktrace: ", Log.getStackTraceString(th3)));
                    }
                }
                switch (enumC0327P) {
                    case f5557q:
                        i6 = 4;
                        T8 = android.support.v4.media.session.a.z(Boolean.valueOf(sslError.hasError(i6)));
                        cVar.g(T8);
                        return;
                    case f5558r:
                        i6 = 1;
                        T8 = android.support.v4.media.session.a.z(Boolean.valueOf(sslError.hasError(i6)));
                        cVar.g(T8);
                        return;
                    case f5559s:
                        i6 = 2;
                        T8 = android.support.v4.media.session.a.z(Boolean.valueOf(sslError.hasError(i6)));
                        cVar.g(T8);
                        return;
                    case f5560t:
                        i6 = 5;
                        T8 = android.support.v4.media.session.a.z(Boolean.valueOf(sslError.hasError(i6)));
                        cVar.g(T8);
                        return;
                    case f5561u:
                        T8 = android.support.v4.media.session.a.z(Boolean.valueOf(sslError.hasError(i6)));
                        cVar.g(T8);
                        return;
                    case f5562v:
                        i6 = 3;
                        T8 = android.support.v4.media.session.a.z(Boolean.valueOf(sslError.hasError(i6)));
                        cVar.g(T8);
                        return;
                    case f5563w:
                        c0350n2.f5633a.getClass();
                        throw new IllegalArgumentException(enumC0327P + " doesn't represent a native value.");
                    default:
                        i6 = -1;
                        T8 = android.support.v4.media.session.a.z(Boolean.valueOf(sslError.hasError(i6)));
                        cVar.g(T8);
                        return;
                }
            case 25:
                C0350n c0350n3 = (C0350n) this.f5658p;
                q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                Object obj7 = ((List) obj).get(0);
                q5.h.c(obj7, "null cannot be cast to non-null type kotlin.Long");
                try {
                    ((C0339c) c0350n3.f5633a.f1303p).a(((Long) obj7).longValue(), WebStorage.getInstance());
                    T9 = android.support.v4.media.session.a.z(null);
                } catch (Throwable th4) {
                    if (th4 instanceof C0337a) {
                        C0337a c0337a4 = th4;
                        T9 = h5.e.T(c0337a4.o, c0337a4.f5592p, c0337a4.f5593q);
                    } else {
                        T9 = h5.e.T(th4.getClass().getSimpleName(), th4.toString(), AbstractC0034i.k("Cause: ", th4.getCause(), ", Stacktrace: ", Log.getStackTraceString(th4)));
                    }
                }
                cVar.g(T9);
                return;
            default:
                C0345i c0345i2 = (C0345i) this.f5658p;
                q5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                Object obj8 = ((List) obj).get(0);
                q5.h.c(obj8, "null cannot be cast to non-null type kotlin.Long");
                try {
                    ((C0339c) c0345i2.f5619a.f1303p).a(((Long) obj8).longValue(), new C0336Z(c0345i2));
                    T10 = android.support.v4.media.session.a.z(null);
                } catch (Throwable th5) {
                    if (th5 instanceof C0337a) {
                        C0337a c0337a5 = th5;
                        T10 = h5.e.T(c0337a5.o, c0337a5.f5592p, c0337a5.f5593q);
                    } else {
                        T10 = h5.e.T(th5.getClass().getSimpleName(), th5.toString(), AbstractC0034i.k("Cause: ", th5.getCause(), ", Stacktrace: ", Log.getStackTraceString(th5)));
                    }
                }
                cVar.g(T10);
                return;
        }
    }

    @Override // M4.c
    public void g(Object obj) {
        switch (this.o) {
            case 0:
                Object obj2 = ((C0342f) this.f5658p).f5618p;
                if (obj instanceof List) {
                    List list = (List) obj;
                    if (list.size() > 1) {
                        Object obj3 = list.get(0);
                        q5.h.c(obj3, "null cannot be cast to non-null type kotlin.String");
                        Object obj4 = list.get(1);
                        q5.h.c(obj4, "null cannot be cast to non-null type kotlin.String");
                        AbstractC0227o.m(new C0337a((String) obj3, (String) obj4, (String) list.get(2)), "AndroidMessage", obj2);
                        return;
                    }
                    return;
                }
                AbstractC0227o.p("channel-error", "Unable to establish connection on channel: 'dev.flutter.pigeon.webview_flutter_android.AndroidMessage.pigeon_newInstance'.", StringUtils.EMPTY, "AndroidMessage", obj2);
                return;
            case 1:
                Object obj5 = ((C0342f) this.f5658p).f5618p;
                if (obj instanceof List) {
                    List list2 = (List) obj;
                    if (list2.size() > 1) {
                        Object obj6 = list2.get(0);
                        q5.h.c(obj6, "null cannot be cast to non-null type kotlin.String");
                        Object obj7 = list2.get(1);
                        q5.h.c(obj7, "null cannot be cast to non-null type kotlin.String");
                        AbstractC0227o.m(new C0337a((String) obj6, (String) obj7, (String) list2.get(2)), "Certificate", obj5);
                        return;
                    }
                    return;
                }
                AbstractC0227o.p("channel-error", "Unable to establish connection on channel: 'dev.flutter.pigeon.webview_flutter_android.Certificate.pigeon_newInstance'.", StringUtils.EMPTY, "Certificate", obj5);
                return;
            case 2:
                Object obj8 = ((C0342f) this.f5658p).f5618p;
                if (obj instanceof List) {
                    List list3 = (List) obj;
                    if (list3.size() > 1) {
                        Object obj9 = list3.get(0);
                        q5.h.c(obj9, "null cannot be cast to non-null type kotlin.String");
                        Object obj10 = list3.get(1);
                        q5.h.c(obj10, "null cannot be cast to non-null type kotlin.String");
                        AbstractC0227o.m(new C0337a((String) obj9, (String) obj10, (String) list3.get(2)), "ClientCertRequest", obj8);
                        return;
                    }
                    return;
                }
                AbstractC0227o.p("channel-error", "Unable to establish connection on channel: 'dev.flutter.pigeon.webview_flutter_android.ClientCertRequest.pigeon_newInstance'.", StringUtils.EMPTY, "ClientCertRequest", obj8);
                return;
            case 3:
                Object obj11 = ((C0342f) this.f5658p).f5618p;
                if (obj instanceof List) {
                    List list4 = (List) obj;
                    if (list4.size() > 1) {
                        Object obj12 = list4.get(0);
                        q5.h.c(obj12, "null cannot be cast to non-null type kotlin.String");
                        Object obj13 = list4.get(1);
                        q5.h.c(obj13, "null cannot be cast to non-null type kotlin.String");
                        AbstractC0227o.m(new C0337a((String) obj12, (String) obj13, (String) list4.get(2)), "ConsoleMessage", obj11);
                        return;
                    }
                    return;
                }
                AbstractC0227o.p("channel-error", "Unable to establish connection on channel: 'dev.flutter.pigeon.webview_flutter_android.ConsoleMessage.pigeon_newInstance'.", StringUtils.EMPTY, "ConsoleMessage", obj11);
                return;
            case 4:
                Object obj14 = ((C0342f) this.f5658p).f5618p;
                if (obj instanceof List) {
                    List list5 = (List) obj;
                    if (list5.size() > 1) {
                        Object obj15 = list5.get(0);
                        q5.h.c(obj15, "null cannot be cast to non-null type kotlin.String");
                        Object obj16 = list5.get(1);
                        q5.h.c(obj16, "null cannot be cast to non-null type kotlin.String");
                        AbstractC0227o.m(new C0337a((String) obj15, (String) obj16, (String) list5.get(2)), "CookieManager", obj14);
                        return;
                    }
                    return;
                }
                AbstractC0227o.p("channel-error", "Unable to establish connection on channel: 'dev.flutter.pigeon.webview_flutter_android.CookieManager.pigeon_newInstance'.", StringUtils.EMPTY, "CookieManager", obj14);
                return;
            case 5:
                Object obj17 = ((C0342f) this.f5658p).f5618p;
                if (obj instanceof List) {
                    List list6 = (List) obj;
                    if (list6.size() > 1) {
                        Object obj18 = list6.get(0);
                        q5.h.c(obj18, "null cannot be cast to non-null type kotlin.String");
                        Object obj19 = list6.get(1);
                        q5.h.c(obj19, "null cannot be cast to non-null type kotlin.String");
                        AbstractC0227o.m(new C0337a((String) obj18, (String) obj19, (String) list6.get(2)), "CustomViewCallback", obj17);
                        return;
                    }
                    return;
                }
                AbstractC0227o.p("channel-error", "Unable to establish connection on channel: 'dev.flutter.pigeon.webview_flutter_android.CustomViewCallback.pigeon_newInstance'.", StringUtils.EMPTY, "CustomViewCallback", obj17);
                return;
            case 6:
            case 11:
            case PipesServer.TIMEOUT_EXIT_CODE /* 17 */:
            case 25:
            default:
                Object obj20 = ((C0342f) this.f5658p).f5618p;
                if (obj instanceof List) {
                    List list7 = (List) obj;
                    if (list7.size() > 1) {
                        Object obj21 = list7.get(0);
                        q5.h.c(obj21, "null cannot be cast to non-null type kotlin.String");
                        Object obj22 = list7.get(1);
                        q5.h.c(obj22, "null cannot be cast to non-null type kotlin.String");
                        AbstractC0227o.m(new C0337a((String) obj21, (String) obj22, (String) list7.get(2)), "WebViewPoint", obj20);
                        return;
                    }
                    return;
                }
                AbstractC0227o.p("channel-error", "Unable to establish connection on channel: 'dev.flutter.pigeon.webview_flutter_android.WebViewPoint.pigeon_newInstance'.", StringUtils.EMPTY, "WebViewPoint", obj20);
                return;
            case 7:
                Object obj23 = ((C0342f) this.f5658p).f5618p;
                if (obj instanceof List) {
                    List list8 = (List) obj;
                    if (list8.size() > 1) {
                        Object obj24 = list8.get(0);
                        q5.h.c(obj24, "null cannot be cast to non-null type kotlin.String");
                        Object obj25 = list8.get(1);
                        q5.h.c(obj25, "null cannot be cast to non-null type kotlin.String");
                        AbstractC0227o.m(new C0337a((String) obj24, (String) obj25, (String) list8.get(2)), "FileChooserParams", obj23);
                        return;
                    }
                    return;
                }
                AbstractC0227o.p("channel-error", "Unable to establish connection on channel: 'dev.flutter.pigeon.webview_flutter_android.FileChooserParams.pigeon_newInstance'.", StringUtils.EMPTY, "FileChooserParams", obj23);
                return;
            case 8:
                Object obj26 = ((C0342f) this.f5658p).f5618p;
                if (obj instanceof List) {
                    List list9 = (List) obj;
                    if (list9.size() > 1) {
                        Object obj27 = list9.get(0);
                        q5.h.c(obj27, "null cannot be cast to non-null type kotlin.String");
                        Object obj28 = list9.get(1);
                        q5.h.c(obj28, "null cannot be cast to non-null type kotlin.String");
                        AbstractC0227o.m(new C0337a((String) obj27, (String) obj28, (String) list9.get(2)), "FlutterAssetManager", obj26);
                        return;
                    }
                    return;
                }
                AbstractC0227o.p("channel-error", "Unable to establish connection on channel: 'dev.flutter.pigeon.webview_flutter_android.FlutterAssetManager.pigeon_newInstance'.", StringUtils.EMPTY, "FlutterAssetManager", obj26);
                return;
            case ContentHandlerProxy.PROCESSING_INSTRUCTION /* 9 */:
                Object obj29 = ((C0342f) this.f5658p).f5618p;
                if (obj instanceof List) {
                    List list10 = (List) obj;
                    if (list10.size() > 1) {
                        Object obj30 = list10.get(0);
                        q5.h.c(obj30, "null cannot be cast to non-null type kotlin.String");
                        Object obj31 = list10.get(1);
                        q5.h.c(obj31, "null cannot be cast to non-null type kotlin.String");
                        AbstractC0227o.m(new C0337a((String) obj30, (String) obj31, (String) list10.get(2)), "GeolocationPermissionsCallback", obj29);
                        return;
                    }
                    return;
                }
                AbstractC0227o.p("channel-error", "Unable to establish connection on channel: 'dev.flutter.pigeon.webview_flutter_android.GeolocationPermissionsCallback.pigeon_newInstance'.", StringUtils.EMPTY, "GeolocationPermissionsCallback", obj29);
                return;
            case 10:
                Object obj32 = ((C0342f) this.f5658p).f5618p;
                if (obj instanceof List) {
                    List list11 = (List) obj;
                    if (list11.size() > 1) {
                        Object obj33 = list11.get(0);
                        q5.h.c(obj33, "null cannot be cast to non-null type kotlin.String");
                        Object obj34 = list11.get(1);
                        q5.h.c(obj34, "null cannot be cast to non-null type kotlin.String");
                        AbstractC0227o.m(new C0337a((String) obj33, (String) obj34, (String) list11.get(2)), "HttpAuthHandler", obj32);
                        return;
                    }
                    return;
                }
                AbstractC0227o.p("channel-error", "Unable to establish connection on channel: 'dev.flutter.pigeon.webview_flutter_android.HttpAuthHandler.pigeon_newInstance'.", StringUtils.EMPTY, "HttpAuthHandler", obj32);
                return;
            case 12:
                Object obj35 = ((C0342f) this.f5658p).f5618p;
                if (obj instanceof List) {
                    List list12 = (List) obj;
                    if (list12.size() > 1) {
                        Object obj36 = list12.get(0);
                        q5.h.c(obj36, "null cannot be cast to non-null type kotlin.String");
                        Object obj37 = list12.get(1);
                        q5.h.c(obj37, "null cannot be cast to non-null type kotlin.String");
                        AbstractC0227o.m(new C0337a((String) obj36, (String) obj37, (String) list12.get(2)), "PermissionRequest", obj35);
                        return;
                    }
                    return;
                }
                AbstractC0227o.p("channel-error", "Unable to establish connection on channel: 'dev.flutter.pigeon.webview_flutter_android.PermissionRequest.pigeon_newInstance'.", StringUtils.EMPTY, "PermissionRequest", obj35);
                return;
            case 13:
                Object obj38 = ((C0342f) this.f5658p).f5618p;
                if (obj instanceof List) {
                    List list13 = (List) obj;
                    if (list13.size() > 1) {
                        Object obj39 = list13.get(0);
                        q5.h.c(obj39, "null cannot be cast to non-null type kotlin.String");
                        Object obj40 = list13.get(1);
                        q5.h.c(obj40, "null cannot be cast to non-null type kotlin.String");
                        AbstractC0227o.m(new C0337a((String) obj39, (String) obj40, (String) list13.get(2)), "PrivateKey", obj38);
                        return;
                    }
                    return;
                }
                AbstractC0227o.p("channel-error", "Unable to establish connection on channel: 'dev.flutter.pigeon.webview_flutter_android.PrivateKey.pigeon_newInstance'.", StringUtils.EMPTY, "PrivateKey", obj38);
                return;
            case 14:
                Object obj41 = ((C0342f) this.f5658p).f5618p;
                if (obj instanceof List) {
                    List list14 = (List) obj;
                    if (list14.size() > 1) {
                        Object obj42 = list14.get(0);
                        q5.h.c(obj42, "null cannot be cast to non-null type kotlin.String");
                        Object obj43 = list14.get(1);
                        q5.h.c(obj43, "null cannot be cast to non-null type kotlin.String");
                        AbstractC0227o.m(new C0337a((String) obj42, (String) obj43, (String) list14.get(2)), "SslCertificate", obj41);
                        return;
                    }
                    return;
                }
                AbstractC0227o.p("channel-error", "Unable to establish connection on channel: 'dev.flutter.pigeon.webview_flutter_android.SslCertificate.pigeon_newInstance'.", StringUtils.EMPTY, "SslCertificate", obj41);
                return;
            case 15:
                Object obj44 = ((C0342f) this.f5658p).f5618p;
                if (obj instanceof List) {
                    List list15 = (List) obj;
                    if (list15.size() > 1) {
                        Object obj45 = list15.get(0);
                        q5.h.c(obj45, "null cannot be cast to non-null type kotlin.String");
                        Object obj46 = list15.get(1);
                        q5.h.c(obj46, "null cannot be cast to non-null type kotlin.String");
                        AbstractC0227o.m(new C0337a((String) obj45, (String) obj46, (String) list15.get(2)), "SslCertificateDName", obj44);
                        return;
                    }
                    return;
                }
                AbstractC0227o.p("channel-error", "Unable to establish connection on channel: 'dev.flutter.pigeon.webview_flutter_android.SslCertificateDName.pigeon_newInstance'.", StringUtils.EMPTY, "SslCertificateDName", obj44);
                return;
            case 16:
                Object obj47 = ((C0342f) this.f5658p).f5618p;
                if (obj instanceof List) {
                    List list16 = (List) obj;
                    if (list16.size() > 1) {
                        Object obj48 = list16.get(0);
                        q5.h.c(obj48, "null cannot be cast to non-null type kotlin.String");
                        Object obj49 = list16.get(1);
                        q5.h.c(obj49, "null cannot be cast to non-null type kotlin.String");
                        AbstractC0227o.m(new C0337a((String) obj48, (String) obj49, (String) list16.get(2)), "SslError", obj47);
                        return;
                    }
                    return;
                }
                AbstractC0227o.p("channel-error", "Unable to establish connection on channel: 'dev.flutter.pigeon.webview_flutter_android.SslError.pigeon_newInstance'.", StringUtils.EMPTY, "SslError", obj47);
                return;
            case 18:
                Object obj50 = ((C0342f) this.f5658p).f5618p;
                if (obj instanceof List) {
                    List list17 = (List) obj;
                    if (list17.size() > 1) {
                        Object obj51 = list17.get(0);
                        q5.h.c(obj51, "null cannot be cast to non-null type kotlin.String");
                        Object obj52 = list17.get(1);
                        q5.h.c(obj52, "null cannot be cast to non-null type kotlin.String");
                        AbstractC0227o.m(new C0337a((String) obj51, (String) obj52, (String) list17.get(2)), "SslErrorHandler", obj50);
                        return;
                    }
                    return;
                }
                AbstractC0227o.p("channel-error", "Unable to establish connection on channel: 'dev.flutter.pigeon.webview_flutter_android.SslErrorHandler.pigeon_newInstance'.", StringUtils.EMPTY, "SslErrorHandler", obj50);
                return;
            case 19:
                Object obj53 = ((C0342f) this.f5658p).f5618p;
                if (obj instanceof List) {
                    List list18 = (List) obj;
                    if (list18.size() > 1) {
                        Object obj54 = list18.get(0);
                        q5.h.c(obj54, "null cannot be cast to non-null type kotlin.String");
                        Object obj55 = list18.get(1);
                        q5.h.c(obj55, "null cannot be cast to non-null type kotlin.String");
                        AbstractC0227o.m(new C0337a((String) obj54, (String) obj55, (String) list18.get(2)), "View", obj53);
                        return;
                    }
                    return;
                }
                AbstractC0227o.p("channel-error", "Unable to establish connection on channel: 'dev.flutter.pigeon.webview_flutter_android.View.pigeon_newInstance'.", StringUtils.EMPTY, "View", obj53);
                return;
            case XMLReaderUtils.DEFAULT_MAX_ENTITY_EXPANSIONS /* 20 */:
                Object obj56 = ((C0342f) this.f5658p).f5618p;
                if (obj instanceof List) {
                    List list19 = (List) obj;
                    if (list19.size() > 1) {
                        Object obj57 = list19.get(0);
                        q5.h.c(obj57, "null cannot be cast to non-null type kotlin.String");
                        Object obj58 = list19.get(1);
                        q5.h.c(obj58, "null cannot be cast to non-null type kotlin.String");
                        AbstractC0227o.m(new C0337a((String) obj57, (String) obj58, (String) list19.get(2)), "WebResourceError", obj56);
                        return;
                    }
                    return;
                }
                AbstractC0227o.p("channel-error", "Unable to establish connection on channel: 'dev.flutter.pigeon.webview_flutter_android.WebResourceError.pigeon_newInstance'.", StringUtils.EMPTY, "WebResourceError", obj56);
                return;
            case 21:
                Object obj59 = ((C0342f) this.f5658p).f5618p;
                if (obj instanceof List) {
                    List list20 = (List) obj;
                    if (list20.size() > 1) {
                        Object obj60 = list20.get(0);
                        q5.h.c(obj60, "null cannot be cast to non-null type kotlin.String");
                        Object obj61 = list20.get(1);
                        q5.h.c(obj61, "null cannot be cast to non-null type kotlin.String");
                        AbstractC0227o.m(new C0337a((String) obj60, (String) obj61, (String) list20.get(2)), "WebResourceRequest", obj59);
                        return;
                    }
                    return;
                }
                AbstractC0227o.p("channel-error", "Unable to establish connection on channel: 'dev.flutter.pigeon.webview_flutter_android.WebResourceRequest.pigeon_newInstance'.", StringUtils.EMPTY, "WebResourceRequest", obj59);
                return;
            case 22:
                Object obj62 = ((C0342f) this.f5658p).f5618p;
                if (obj instanceof List) {
                    List list21 = (List) obj;
                    if (list21.size() > 1) {
                        Object obj63 = list21.get(0);
                        q5.h.c(obj63, "null cannot be cast to non-null type kotlin.String");
                        Object obj64 = list21.get(1);
                        q5.h.c(obj64, "null cannot be cast to non-null type kotlin.String");
                        AbstractC0227o.m(new C0337a((String) obj63, (String) obj64, (String) list21.get(2)), "WebResourceResponse", obj62);
                        return;
                    }
                    return;
                }
                AbstractC0227o.p("channel-error", "Unable to establish connection on channel: 'dev.flutter.pigeon.webview_flutter_android.WebResourceResponse.pigeon_newInstance'.", StringUtils.EMPTY, "WebResourceResponse", obj62);
                return;
            case 23:
                Object obj65 = ((C0342f) this.f5658p).f5618p;
                if (obj instanceof List) {
                    List list22 = (List) obj;
                    if (list22.size() > 1) {
                        Object obj66 = list22.get(0);
                        q5.h.c(obj66, "null cannot be cast to non-null type kotlin.String");
                        Object obj67 = list22.get(1);
                        q5.h.c(obj67, "null cannot be cast to non-null type kotlin.String");
                        AbstractC0227o.m(new C0337a((String) obj66, (String) obj67, (String) list22.get(2)), "WebSettings", obj65);
                        return;
                    }
                    return;
                }
                AbstractC0227o.p("channel-error", "Unable to establish connection on channel: 'dev.flutter.pigeon.webview_flutter_android.WebSettings.pigeon_newInstance'.", StringUtils.EMPTY, "WebSettings", obj65);
                return;
            case 24:
                Object obj68 = ((C0342f) this.f5658p).f5618p;
                if (obj instanceof List) {
                    List list23 = (List) obj;
                    if (list23.size() > 1) {
                        Object obj69 = list23.get(0);
                        q5.h.c(obj69, "null cannot be cast to non-null type kotlin.String");
                        Object obj70 = list23.get(1);
                        q5.h.c(obj70, "null cannot be cast to non-null type kotlin.String");
                        AbstractC0227o.m(new C0337a((String) obj69, (String) obj70, (String) list23.get(2)), "WebStorage", obj68);
                        return;
                    }
                    return;
                }
                AbstractC0227o.p("channel-error", "Unable to establish connection on channel: 'dev.flutter.pigeon.webview_flutter_android.WebStorage.pigeon_newInstance'.", StringUtils.EMPTY, "WebStorage", obj68);
                return;
            case 26:
                Object obj71 = ((C0342f) this.f5658p).f5618p;
                if (obj instanceof List) {
                    List list24 = (List) obj;
                    if (list24.size() > 1) {
                        Object obj72 = list24.get(0);
                        q5.h.c(obj72, "null cannot be cast to non-null type kotlin.String");
                        Object obj73 = list24.get(1);
                        q5.h.c(obj73, "null cannot be cast to non-null type kotlin.String");
                        AbstractC0227o.m(new C0337a((String) obj72, (String) obj73, (String) list24.get(2)), "WebView", obj71);
                        return;
                    }
                    return;
                }
                AbstractC0227o.p("channel-error", "Unable to establish connection on channel: 'dev.flutter.pigeon.webview_flutter_android.WebView.pigeon_newInstance'.", StringUtils.EMPTY, "WebView", obj71);
                return;
            case 27:
                Object obj74 = ((C0342f) this.f5658p).f5618p;
                if (obj instanceof List) {
                    List list25 = (List) obj;
                    if (list25.size() > 1) {
                        Object obj75 = list25.get(0);
                        q5.h.c(obj75, "null cannot be cast to non-null type kotlin.String");
                        Object obj76 = list25.get(1);
                        q5.h.c(obj76, "null cannot be cast to non-null type kotlin.String");
                        AbstractC0227o.m(new C0337a((String) obj75, (String) obj76, (String) list25.get(2)), "WebViewClient", obj74);
                        return;
                    }
                    return;
                }
                AbstractC0227o.p("channel-error", "Unable to establish connection on channel: 'dev.flutter.pigeon.webview_flutter_android.WebViewClient.pigeon_newInstance'.", StringUtils.EMPTY, "WebViewClient", obj74);
                return;
        }
    }
}
