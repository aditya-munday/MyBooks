package R1;

/* JADX WARN: Failed to restore enum class, 'enum' modifier and super class removed */
/* JADX WARN: Unknown enum class pattern. Please report as an issue! */
/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* loaded from: classes.dex */
public final class a {
    public static final a o;

    /* renamed from: p, reason: collision with root package name */
    public static final a f2294p;

    /* renamed from: q, reason: collision with root package name */
    public static final a f2295q;

    /* renamed from: r, reason: collision with root package name */
    public static final /* synthetic */ a[] f2296r;

    /* JADX WARN: Type inference failed for: r0v0, types: [java.lang.Enum, R1.a] */
    /* JADX WARN: Type inference failed for: r1v1, types: [java.lang.Enum, R1.a] */
    /* JADX WARN: Type inference failed for: r2v2, types: [java.lang.Enum, R1.a] */
    static {
        ?? r02 = new Enum("WIDTH", 0);
        o = r02;
        ?? r12 = new Enum("HEIGHT", 1);
        f2294p = r12;
        ?? r22 = new Enum("BOTH", 2);
        f2295q = r22;
        f2296r = new a[]{r02, r12, r22};
    }

    public static a valueOf(String str) {
        return (a) Enum.valueOf(a.class, str);
    }

    public static a[] values() {
        return (a[]) f2296r.clone();
    }
}
