package R1;

import com.shockwave.pdfium.util.Size;
import com.shockwave.pdfium.util.SizeF;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* loaded from: classes.dex */
public final class b {

    /* renamed from: a, reason: collision with root package name */
    public final a f2297a;

    /* renamed from: b, reason: collision with root package name */
    public final Size f2298b;

    /* renamed from: c, reason: collision with root package name */
    public final SizeF f2299c;

    /* renamed from: d, reason: collision with root package name */
    public final SizeF f2300d;
    public final float e;

    /* renamed from: f, reason: collision with root package name */
    public final float f2301f;

    /* renamed from: g, reason: collision with root package name */
    public final boolean f2302g;

    public b(a aVar, Size size, Size size2, Size size3, boolean z6) {
        int i6 = size3.f5834b;
        int i7 = size3.f5833a;
        this.f2297a = aVar;
        this.f2298b = size3;
        this.f2302g = z6;
        int ordinal = aVar.ordinal();
        if (ordinal != 1) {
            if (ordinal != 2) {
                SizeF c6 = c(size, i7);
                this.f2299c = c6;
                float f6 = c6.f5835a / size.f5833a;
                this.e = f6;
                this.f2300d = c(size2, size2.f5833a * f6);
                return;
            }
            float f7 = i6;
            SizeF a6 = a(size, i7, f7);
            float f8 = size.f5833a;
            SizeF a7 = a(size2, size2.f5833a * (a6.f5835a / f8), f7);
            this.f2300d = a7;
            float f9 = a7.f5836b / size2.f5834b;
            this.f2301f = f9;
            SizeF a8 = a(size, i7, size.f5834b * f9);
            this.f2299c = a8;
            this.e = a8.f5835a / f8;
            return;
        }
        SizeF b6 = b(size2, i6);
        this.f2300d = b6;
        float f10 = b6.f5836b / size2.f5834b;
        this.f2301f = f10;
        this.f2299c = b(size, size.f5834b * f10);
    }

    public static SizeF a(Size size, float f6, float f7) {
        float f8 = size.f5833a / size.f5834b;
        float floor = (float) Math.floor(f6 / f8);
        if (floor > f7) {
            f6 = (float) Math.floor(f8 * f7);
        } else {
            f7 = floor;
        }
        return new SizeF(f6, f7);
    }

    public static SizeF b(Size size, float f6) {
        return new SizeF((float) Math.floor(f6 / (size.f5834b / size.f5833a)), f6);
    }

    public static SizeF c(Size size, float f6) {
        return new SizeF(f6, (float) Math.floor(f6 / (size.f5833a / size.f5834b)));
    }
}
