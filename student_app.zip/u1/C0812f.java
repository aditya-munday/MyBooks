package u1;

import C4.AbstractC0034i;
import L.i;
import android.util.Log;
import androidx.datastore.preferences.protobuf.AbstractC0227o;
import b0.l;
import h5.C0467a;
import h5.m;
import java.util.ArrayList;
import java.util.Collection;
import org.apache.tika.mime.MimeTypesReaderMetKeys;
import s4.AbstractC0760a;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* renamed from: u1.f, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0812f extends AbstractC0760a {

    /* renamed from: a, reason: collision with root package name */
    public final Object f9755a;

    /* renamed from: b, reason: collision with root package name */
    public final String f9756b;

    /* renamed from: c, reason: collision with root package name */
    public final int f9757c;

    /* renamed from: d, reason: collision with root package name */
    public final l f9758d;

    /* JADX WARN: Type inference failed for: r6v3, types: [java.lang.Throwable, b0.l, java.lang.Exception] */
    public C0812f(Object obj, String str, C0807a c0807a, int i6) {
        Collection collection;
        q5.h.e(obj, MimeTypesReaderMetKeys.MATCH_VALUE_ATTR);
        AbstractC0227o.k(i6, "verificationMode");
        this.f9755a = obj;
        this.f9756b = str;
        this.f9757c = i6;
        String c6 = AbstractC0760a.c(obj, str);
        q5.h.e(c6, "message");
        ?? exc = new Exception(c6);
        StackTraceElement[] stackTrace = exc.getStackTrace();
        q5.h.d(stackTrace, "stackTrace");
        int length = stackTrace.length - 2;
        length = length < 0 ? 0 : length;
        if (length >= 0) {
            if (length != 0) {
                int length2 = stackTrace.length;
                if (length >= length2) {
                    int length3 = stackTrace.length;
                    if (length3 != 0) {
                        if (length3 != 1) {
                            collection = new ArrayList(new C0467a(stackTrace, false));
                        } else {
                            collection = android.support.v4.media.session.a.z(stackTrace[0]);
                        }
                    }
                } else if (length == 1) {
                    collection = android.support.v4.media.session.a.z(stackTrace[length2 - 1]);
                } else {
                    ArrayList arrayList = new ArrayList(length);
                    for (int i7 = length2 - length; i7 < length2; i7++) {
                        arrayList.add(stackTrace[i7]);
                    }
                    collection = arrayList;
                }
                exc.setStackTrace((StackTraceElement[]) collection.toArray(new StackTraceElement[0]));
                this.f9758d = exc;
                return;
            }
            collection = m.o;
            exc.setStackTrace((StackTraceElement[]) collection.toArray(new StackTraceElement[0]));
            this.f9758d = exc;
            return;
        }
        throw new IllegalArgumentException(AbstractC0034i.i("Requested element count ", length, " is less than zero.").toString());
    }

    @Override // s4.AbstractC0760a
    public final Object b() {
        int b6 = i.b(this.f9757c);
        if (b6 != 0) {
            if (b6 != 1) {
                if (b6 == 2) {
                    return null;
                }
                throw new RuntimeException();
            }
            String c6 = AbstractC0760a.c(this.f9755a, this.f9756b);
            q5.h.e(c6, "message");
            Log.d("g", c6);
            return null;
        }
        throw this.f9758d;
    }

    @Override // s4.AbstractC0760a
    public final AbstractC0760a h(String str, p5.l lVar) {
        return this;
    }
}
