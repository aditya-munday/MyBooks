package u1;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* renamed from: u1.a, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0807a {

    /* renamed from: a, reason: collision with root package name */
    public static final C0807a f9745a = new Object();
}
