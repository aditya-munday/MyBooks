package u1;

import androidx.datastore.preferences.protobuf.AbstractC0227o;
import org.apache.tika.mime.MimeTypesReaderMetKeys;
import p5.l;
import s4.AbstractC0760a;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* renamed from: u1.g, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0813g extends AbstractC0760a {

    /* renamed from: a, reason: collision with root package name */
    public final Object f9759a;

    /* renamed from: b, reason: collision with root package name */
    public final int f9760b;

    /* renamed from: c, reason: collision with root package name */
    public final C0807a f9761c;

    public C0813g(Object obj, int i6, C0807a c0807a) {
        q5.h.e(obj, MimeTypesReaderMetKeys.MATCH_VALUE_ATTR);
        AbstractC0227o.k(i6, "verificationMode");
        this.f9759a = obj;
        this.f9760b = i6;
        this.f9761c = c0807a;
    }

    @Override // s4.AbstractC0760a
    public final Object b() {
        return this.f9759a;
    }

    @Override // s4.AbstractC0760a
    public final AbstractC0760a h(String str, l lVar) {
        Object obj = this.f9759a;
        if (((Boolean) lVar.a(obj)).booleanValue()) {
            return this;
        }
        return new C0812f(obj, str, this.f9761c, this.f9760b);
    }
}
