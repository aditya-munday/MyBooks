package u1;

import androidx.window.extensions.WindowExtensionsProvider;
import q5.q;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* renamed from: u1.e, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public abstract class AbstractC0811e {
    static {
        q.a(AbstractC0811e.class).b();
    }

    public static int a() {
        try {
            return WindowExtensionsProvider.getWindowExtensions().getVendorApiLevel();
        } catch (NoClassDefFoundError | UnsupportedOperationException unused) {
            return 0;
        }
    }
}
