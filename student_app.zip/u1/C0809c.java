package u1;

import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Method;
import java.util.Map;
import q5.q;
import q5.s;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* renamed from: u1.c, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0809c implements InvocationHandler {

    /* renamed from: a, reason: collision with root package name */
    public final q5.e f9750a;

    /* renamed from: b, reason: collision with root package name */
    public final z1.b f9751b;

    public C0809c(q5.e eVar, z1.b bVar) {
        this.f9750a = eVar;
        this.f9751b = bVar;
    }

    @Override // java.lang.reflect.InvocationHandler
    public final Object invoke(Object obj, Method method, Object[] objArr) {
        boolean isInstance;
        String b6;
        q5.h.e(obj, "obj");
        q5.h.e(method, "method");
        boolean a6 = q5.h.a(method.getName(), "accept");
        z1.b bVar = this.f9751b;
        boolean z6 = false;
        if (a6 && objArr != null && objArr.length == 1) {
            Object obj2 = objArr[0];
            q5.e eVar = this.f9750a;
            Class cls = eVar.f9283a;
            q5.h.e(cls, "jClass");
            Map map = q5.e.f9282b;
            q5.h.c(map, "null cannot be cast to non-null type kotlin.collections.Map<K of kotlin.collections.MapsKt__MapsKt.get, V of kotlin.collections.MapsKt__MapsKt.get>");
            Integer num = (Integer) map.get(cls);
            if (num != null) {
                isInstance = s.c(num.intValue(), obj2);
            } else {
                if (cls.isPrimitive()) {
                    cls = android.support.v4.media.session.a.q(q.a(cls));
                }
                isInstance = cls.isInstance(obj2);
            }
            if (isInstance) {
                q5.h.c(obj2, "null cannot be cast to non-null type T of kotlin.reflect.KClasses.cast");
                bVar.a(obj2);
                return g5.h.f6800a;
            }
            StringBuilder sb = new StringBuilder("Value cannot be cast to ");
            Class cls2 = eVar.f9283a;
            q5.h.e(cls2, "jClass");
            String str = null;
            if (!cls2.isAnonymousClass() && !cls2.isLocalClass()) {
                if (cls2.isArray()) {
                    Class<?> componentType = cls2.getComponentType();
                    if (componentType.isPrimitive() && (b6 = s.b(componentType.getName())) != null) {
                        str = b6.concat("Array");
                    }
                    if (str == null) {
                        str = "kotlin.Array";
                    }
                } else {
                    str = s.b(cls2.getName());
                    if (str == null) {
                        str = cls2.getCanonicalName();
                    }
                }
            }
            sb.append(str);
            throw new ClassCastException(sb.toString());
        }
        if (q5.h.a(method.getName(), "equals") && method.getReturnType().equals(Boolean.TYPE) && objArr != null && objArr.length == 1) {
            if (obj == objArr[0]) {
                z6 = true;
            }
            return Boolean.valueOf(z6);
        }
        if (q5.h.a(method.getName(), "hashCode") && method.getReturnType().equals(Integer.TYPE) && objArr == null) {
            return Integer.valueOf(bVar.hashCode());
        }
        if (q5.h.a(method.getName(), "toString") && method.getReturnType().equals(String.class) && objArr == null) {
            return bVar.toString();
        }
        throw new UnsupportedOperationException("Unexpected method call object:" + obj + ", method: " + method + ", args: " + objArr);
    }
}
