package u1;

import C4.AbstractC0034i;
import J.I;
import g5.C0457f;
import java.math.BigInteger;
import org.apache.tika.utils.StringUtils;
import w5.j;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* renamed from: u1.h, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0814h implements Comparable {

    /* renamed from: t, reason: collision with root package name */
    public static final C0814h f9762t;
    public final int o;

    /* renamed from: p, reason: collision with root package name */
    public final int f9763p;

    /* renamed from: q, reason: collision with root package name */
    public final int f9764q;

    /* renamed from: r, reason: collision with root package name */
    public final String f9765r;

    /* renamed from: s, reason: collision with root package name */
    public final C0457f f9766s = new C0457f(new I(this, 8));

    static {
        new C0814h(0, 0, 0, StringUtils.EMPTY);
        f9762t = new C0814h(0, 1, 0, StringUtils.EMPTY);
        new C0814h(1, 0, 0, StringUtils.EMPTY);
    }

    public C0814h(int i6, int i7, int i8, String str) {
        this.o = i6;
        this.f9763p = i7;
        this.f9764q = i8;
        this.f9765r = str;
    }

    @Override // java.lang.Comparable
    public final int compareTo(Object obj) {
        C0814h c0814h = (C0814h) obj;
        q5.h.e(c0814h, "other");
        Object a6 = this.f9766s.a();
        q5.h.d(a6, "<get-bigInteger>(...)");
        Object a7 = c0814h.f9766s.a();
        q5.h.d(a7, "<get-bigInteger>(...)");
        return ((BigInteger) a6).compareTo((BigInteger) a7);
    }

    public final boolean equals(Object obj) {
        if (!(obj instanceof C0814h)) {
            return false;
        }
        C0814h c0814h = (C0814h) obj;
        if (this.o != c0814h.o || this.f9763p != c0814h.f9763p || this.f9764q != c0814h.f9764q) {
            return false;
        }
        return true;
    }

    public final int hashCode() {
        return ((((527 + this.o) * 31) + this.f9763p) * 31) + this.f9764q;
    }

    public final String toString() {
        String str;
        String str2 = this.f9765r;
        if (!j.i(str2)) {
            str = AbstractC0034i.j("-", str2);
        } else {
            str = StringUtils.EMPTY;
        }
        StringBuilder sb = new StringBuilder();
        sb.append(this.o);
        sb.append('.');
        sb.append(this.f9763p);
        sb.append('.');
        return AbstractC0034i.l(sb, this.f9764q, str);
    }
}
