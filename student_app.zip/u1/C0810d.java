package u1;

import java.lang.reflect.Method;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* renamed from: u1.d, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0810d {

    /* renamed from: a, reason: collision with root package name */
    public final /* synthetic */ Method f9752a;

    /* renamed from: b, reason: collision with root package name */
    public final /* synthetic */ Object f9753b;

    /* renamed from: c, reason: collision with root package name */
    public final /* synthetic */ Object f9754c;

    public C0810d(Method method, Object obj, Object obj2) {
        this.f9752a = method;
        this.f9753b = obj;
        this.f9754c = obj2;
    }
}
