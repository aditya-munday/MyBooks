package u1;

import C4.AbstractC0034i;
import android.graphics.Rect;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* renamed from: u1.b, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0808b {

    /* renamed from: a, reason: collision with root package name */
    public final int f9746a;

    /* renamed from: b, reason: collision with root package name */
    public final int f9747b;

    /* renamed from: c, reason: collision with root package name */
    public final int f9748c;

    /* renamed from: d, reason: collision with root package name */
    public final int f9749d;

    public C0808b(Rect rect) {
        int i6 = rect.left;
        int i7 = rect.top;
        int i8 = rect.right;
        int i9 = rect.bottom;
        this.f9746a = i6;
        this.f9747b = i7;
        this.f9748c = i8;
        this.f9749d = i9;
        if (i6 <= i8) {
            if (i7 <= i9) {
                return;
            } else {
                throw new IllegalArgumentException(AbstractC0034i.h(i7, i9, "top must be less than or equal to bottom, top: ", ", bottom: ").toString());
            }
        }
        throw new IllegalArgumentException(AbstractC0034i.h(i6, i8, "Left must be less than or equal to right, left: ", ", right: ").toString());
    }

    public final Rect a() {
        return new Rect(this.f9746a, this.f9747b, this.f9748c, this.f9749d);
    }

    public final boolean equals(Object obj) {
        Class<?> cls;
        if (this == obj) {
            return true;
        }
        if (obj != null) {
            cls = obj.getClass();
        } else {
            cls = null;
        }
        if (!C0808b.class.equals(cls)) {
            return false;
        }
        q5.h.c(obj, "null cannot be cast to non-null type androidx.window.core.Bounds");
        C0808b c0808b = (C0808b) obj;
        if (this.f9746a == c0808b.f9746a && this.f9747b == c0808b.f9747b && this.f9748c == c0808b.f9748c && this.f9749d == c0808b.f9749d) {
            return true;
        }
        return false;
    }

    public final int hashCode() {
        return (((((this.f9746a * 31) + this.f9747b) * 31) + this.f9748c) * 31) + this.f9749d;
    }

    public final String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(C0808b.class.getSimpleName());
        sb.append(" { [");
        sb.append(this.f9746a);
        sb.append(',');
        sb.append(this.f9747b);
        sb.append(',');
        sb.append(this.f9748c);
        sb.append(',');
        return AbstractC0034i.l(sb, this.f9749d, "] }");
    }
}
