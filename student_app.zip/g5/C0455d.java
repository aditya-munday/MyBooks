package g5;

import java.io.Serializable;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* renamed from: g5.d, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0455d implements Serializable {
    public final Throwable o;

    public C0455d(Throwable th) {
        q5.h.e(th, "exception");
        this.o = th;
    }

    public final boolean equals(Object obj) {
        if (obj instanceof C0455d) {
            if (q5.h.a(this.o, ((C0455d) obj).o)) {
                return true;
            }
            return false;
        }
        return false;
    }

    public final int hashCode() {
        return this.o.hashCode();
    }

    public final String toString() {
        return "Failure(" + this.o + ')';
    }
}
