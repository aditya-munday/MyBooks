package g5;

import java.io.Serializable;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* renamed from: g5.e, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0456e implements Serializable {
    public final Object o;

    public static final Throwable a(Object obj) {
        if (obj instanceof C0455d) {
            return ((C0455d) obj).o;
        }
        return null;
    }

    public final boolean equals(Object obj) {
        if (obj instanceof C0456e) {
            if (!q5.h.a(this.o, ((C0456e) obj).o)) {
                return false;
            }
            return true;
        }
        return false;
    }

    public final int hashCode() {
        Object obj = this.o;
        if (obj == null) {
            return 0;
        }
        return obj.hashCode();
    }

    public final String toString() {
        Object obj = this.o;
        if (obj instanceof C0455d) {
            return ((C0455d) obj).toString();
        }
        return "Success(" + obj + ')';
    }
}
