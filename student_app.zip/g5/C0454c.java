package g5;

import java.io.Serializable;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* renamed from: g5.c, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0454c implements Serializable {
    public final Object o;

    /* renamed from: p, reason: collision with root package name */
    public final Object f6796p;

    public C0454c(Object obj, Object obj2) {
        this.o = obj;
        this.f6796p = obj2;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof C0454c)) {
            return false;
        }
        C0454c c0454c = (C0454c) obj;
        if (q5.h.a(this.o, c0454c.o) && q5.h.a(this.f6796p, c0454c.f6796p)) {
            return true;
        }
        return false;
    }

    public final int hashCode() {
        int hashCode;
        int i6 = 0;
        Object obj = this.o;
        if (obj == null) {
            hashCode = 0;
        } else {
            hashCode = obj.hashCode();
        }
        int i7 = hashCode * 31;
        Object obj2 = this.f6796p;
        if (obj2 != null) {
            i6 = obj2.hashCode();
        }
        return i7 + i6;
    }

    public final String toString() {
        return "(" + this.o + ", " + this.f6796p + ')';
    }
}
