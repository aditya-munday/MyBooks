package g5;

import java.io.Serializable;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* renamed from: g5.f, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0457f implements Serializable {
    public p5.a o;

    /* renamed from: p, reason: collision with root package name */
    public volatile Object f6797p = g.f6799a;

    /* renamed from: q, reason: collision with root package name */
    public final Object f6798q = this;

    public C0457f(p5.a aVar) {
        this.o = aVar;
    }

    public final Object a() {
        Object obj;
        Object obj2 = this.f6797p;
        g gVar = g.f6799a;
        if (obj2 != gVar) {
            return obj2;
        }
        synchronized (this.f6798q) {
            obj = this.f6797p;
            if (obj == gVar) {
                p5.a aVar = this.o;
                q5.h.b(aVar);
                obj = aVar.c();
                this.f6797p = obj;
                this.o = null;
            }
        }
        return obj;
    }

    public final String toString() {
        if (this.f6797p != g.f6799a) {
            return String.valueOf(a());
        }
        return "Lazy value not initialized yet.";
    }
}
