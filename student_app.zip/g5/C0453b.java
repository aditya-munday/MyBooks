package g5;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* renamed from: g5.b, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0453b implements Comparable {

    /* renamed from: p, reason: collision with root package name */
    public static final C0453b f6795p = new C0453b();
    public final int o = 131604;

    @Override // java.lang.Comparable
    public final int compareTo(Object obj) {
        C0453b c0453b = (C0453b) obj;
        q5.h.e(c0453b, "other");
        return this.o - c0453b.o;
    }

    public final boolean equals(Object obj) {
        C0453b c0453b;
        if (this == obj) {
            return true;
        }
        if (obj instanceof C0453b) {
            c0453b = (C0453b) obj;
        } else {
            c0453b = null;
        }
        if (c0453b != null && this.o == c0453b.o) {
            return true;
        }
        return false;
    }

    public final int hashCode() {
        return this.o;
    }

    public final String toString() {
        return "2.2.20";
    }
}
