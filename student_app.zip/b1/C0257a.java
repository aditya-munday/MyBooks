package b1;

import E2.G;
import E2.I;
import E2.Z;
import U.b;
import U0.k;
import U0.l;
import V.AbstractC0133a;
import V.C;
import V.g;
import V.v;
import android.text.SpannableStringBuilder;
import android.text.style.ForegroundColorSpan;
import android.text.style.StyleSpan;
import android.text.style.TypefaceSpan;
import android.text.style.UnderlineSpan;
import androidx.datastore.preferences.protobuf.AbstractC0227o;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.util.List;
import org.apache.tika.fork.ForkServer;
import org.apache.tika.utils.StringUtils;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* renamed from: b1.a, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0257a implements l {
    public final v o = new v();

    /* renamed from: p, reason: collision with root package name */
    public final boolean f5275p;

    /* renamed from: q, reason: collision with root package name */
    public final int f5276q;

    /* renamed from: r, reason: collision with root package name */
    public final int f5277r;

    /* renamed from: s, reason: collision with root package name */
    public final String f5278s;

    /* renamed from: t, reason: collision with root package name */
    public final float f5279t;

    /* renamed from: u, reason: collision with root package name */
    public final int f5280u;

    public C0257a(List list) {
        if (list.size() == 1 && (((byte[]) list.get(0)).length == 48 || ((byte[]) list.get(0)).length == 53)) {
            byte[] bArr = (byte[]) list.get(0);
            this.f5276q = bArr[24];
            this.f5277r = ((bArr[26] & ForkServer.ERROR) << 24) | ((bArr[27] & ForkServer.ERROR) << 16) | ((bArr[28] & ForkServer.ERROR) << 8) | (bArr[29] & ForkServer.ERROR);
            this.f5278s = "Serif".equals(new String(bArr, 43, bArr.length - 43, StandardCharsets.UTF_8)) ? "serif" : "sans-serif";
            int i6 = bArr[25] * 20;
            this.f5280u = i6;
            boolean z6 = (bArr[0] & 32) != 0;
            this.f5275p = z6;
            if (z6) {
                this.f5279t = C.h(((bArr[11] & ForkServer.ERROR) | ((bArr[10] & ForkServer.ERROR) << 8)) / i6, 0.0f, 0.95f);
                return;
            } else {
                this.f5279t = 0.85f;
                return;
            }
        }
        this.f5276q = 0;
        this.f5277r = -1;
        this.f5278s = "sans-serif";
        this.f5275p = false;
        this.f5279t = 0.85f;
        this.f5280u = -1;
    }

    public static void a(SpannableStringBuilder spannableStringBuilder, int i6, int i7, int i8, int i9, int i10) {
        if (i6 != i7) {
            spannableStringBuilder.setSpan(new ForegroundColorSpan((i6 >>> 8) | ((i6 & 255) << 24)), i8, i9, i10 | 33);
        }
    }

    public static void b(SpannableStringBuilder spannableStringBuilder, int i6, int i7, int i8, int i9, int i10) {
        boolean z6;
        boolean z7;
        if (i6 != i7) {
            int i11 = i10 | 33;
            boolean z8 = true;
            if ((i6 & 1) != 0) {
                z6 = true;
            } else {
                z6 = false;
            }
            if ((i6 & 2) != 0) {
                z7 = true;
            } else {
                z7 = false;
            }
            if (z6) {
                if (z7) {
                    spannableStringBuilder.setSpan(new StyleSpan(3), i8, i9, i11);
                } else {
                    spannableStringBuilder.setSpan(new StyleSpan(1), i8, i9, i11);
                }
            } else if (z7) {
                spannableStringBuilder.setSpan(new StyleSpan(2), i8, i9, i11);
            }
            if ((i6 & 4) == 0) {
                z8 = false;
            }
            if (z8) {
                spannableStringBuilder.setSpan(new UnderlineSpan(), i8, i9, i11);
            }
            if (!z8 && !z6 && !z7) {
                spannableStringBuilder.setSpan(new StyleSpan(0), i8, i9, i11);
            }
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    @Override // U0.l
    public final void j(byte[] bArr, int i6, int i7, k kVar, g gVar) {
        boolean z6;
        String v6;
        int i8;
        boolean z7;
        boolean z8;
        boolean z9;
        int i9;
        v vVar = this.o;
        vVar.H(bArr, i6 + i7);
        vVar.J(i6);
        int i10 = 1;
        int i11 = 0;
        int i12 = 2;
        if (vVar.a() >= 2) {
            z6 = true;
        } else {
            z6 = false;
        }
        AbstractC0133a.c(z6);
        int D5 = vVar.D();
        if (D5 == 0) {
            v6 = StringUtils.EMPTY;
        } else {
            int i13 = vVar.f3121b;
            Charset F6 = vVar.F();
            int i14 = D5 - (vVar.f3121b - i13);
            if (F6 == null) {
                F6 = StandardCharsets.UTF_8;
            }
            v6 = vVar.v(i14, F6);
        }
        if (v6.isEmpty()) {
            G g2 = I.f699p;
            gVar.accept(new U0.a(-9223372036854775807L, -9223372036854775807L, Z.f721s));
            return;
        }
        SpannableStringBuilder spannableStringBuilder = new SpannableStringBuilder(v6);
        b(spannableStringBuilder, this.f5276q, 0, 0, spannableStringBuilder.length(), 16711680);
        a(spannableStringBuilder, this.f5277r, -1, 0, spannableStringBuilder.length(), 16711680);
        int length = spannableStringBuilder.length();
        String str = this.f5278s;
        if (str != "sans-serif") {
            spannableStringBuilder.setSpan(new TypefaceSpan(str), 0, length, 16711713);
        }
        float f6 = this.f5279t;
        while (vVar.a() >= 8) {
            int i15 = vVar.f3121b;
            int k6 = vVar.k();
            int k7 = vVar.k();
            if (k7 == 1937013100) {
                if (vVar.a() >= i12) {
                    z8 = i10;
                } else {
                    z8 = i11;
                }
                AbstractC0133a.c(z8);
                int D6 = vVar.D();
                int i16 = i11;
                while (i16 < D6) {
                    if (vVar.a() >= 12) {
                        z9 = i10;
                    } else {
                        z9 = i11;
                    }
                    AbstractC0133a.c(z9);
                    int D7 = vVar.D();
                    int D8 = vVar.D();
                    vVar.K(i12);
                    int i17 = i16;
                    int x6 = vVar.x();
                    vVar.K(i10);
                    int k8 = vVar.k();
                    if (D8 > spannableStringBuilder.length()) {
                        StringBuilder i18 = AbstractC0227o.i("Truncating styl end (", D8, ") to cueText.length() (");
                        i18.append(spannableStringBuilder.length());
                        i18.append(").");
                        AbstractC0133a.A("Tx3gParser", i18.toString());
                        D8 = spannableStringBuilder.length();
                    }
                    if (D7 >= D8) {
                        AbstractC0133a.A("Tx3gParser", AbstractC0227o.e("Ignoring styl with start (", D7, ") >= end (", D8, ")."));
                        i9 = i17;
                    } else {
                        i9 = i17;
                        int i19 = D8;
                        b(spannableStringBuilder, x6, this.f5276q, D7, i19, 0);
                        a(spannableStringBuilder, k8, this.f5277r, D7, i19, 0);
                    }
                    i16 = i9 + 1;
                    i10 = 1;
                    i11 = 0;
                    i12 = 2;
                }
                i8 = i12;
            } else if (k7 == 1952608120 && this.f5275p) {
                i8 = 2;
                if (vVar.a() >= 2) {
                    z7 = true;
                } else {
                    z7 = false;
                }
                AbstractC0133a.c(z7);
                f6 = C.h(vVar.D() / this.f5280u, 0.0f, 0.95f);
            } else {
                i8 = 2;
            }
            vVar.J(i15 + k6);
            i12 = i8;
            i10 = 1;
            i11 = 0;
        }
        gVar.accept(new U0.a(-9223372036854775807L, -9223372036854775807L, I.y(new b(spannableStringBuilder, null, null, null, f6, 0, 0, -3.4028235E38f, Integer.MIN_VALUE, Integer.MIN_VALUE, -3.4028235E38f, -3.4028235E38f, -3.4028235E38f, false, -16777216, Integer.MIN_VALUE, 0.0f, 0))));
    }

    @Override // U0.l
    public final int z() {
        return 2;
    }
}
