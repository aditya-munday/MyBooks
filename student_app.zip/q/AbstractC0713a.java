package q;

import q5.h;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* renamed from: q.a, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public abstract class AbstractC0713a {

    /* renamed from: a, reason: collision with root package name */
    public static final int[] f9170a = new int[0];

    /* renamed from: b, reason: collision with root package name */
    public static final Object[] f9171b = new Object[0];

    public static final int a(int i6, int i7, int[] iArr) {
        h.e(iArr, "array");
        int i8 = i6 - 1;
        int i9 = 0;
        while (i9 <= i8) {
            int i10 = (i9 + i8) >>> 1;
            int i11 = iArr[i10];
            if (i11 < i7) {
                i9 = i10 + 1;
            } else if (i11 > i7) {
                i8 = i10 - 1;
            } else {
                return i10;
            }
        }
        return ~i9;
    }

    public static final int b(long[] jArr, int i6, long j6) {
        h.e(jArr, "array");
        int i7 = i6 - 1;
        int i8 = 0;
        while (i8 <= i7) {
            int i9 = (i8 + i7) >>> 1;
            long j7 = jArr[i9];
            if (j7 < j6) {
                i8 = i9 + 1;
            } else if (j7 > j6) {
                i7 = i9 - 1;
            } else {
                return i9;
            }
        }
        return ~i8;
    }
}
