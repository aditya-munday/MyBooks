package K0;

import C4.AbstractC0034i;
import S.B;
import S.D;
import java.util.Arrays;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* loaded from: classes.dex */
public final class c implements D {

    /* renamed from: a, reason: collision with root package name */
    public final byte[] f1334a;

    /* renamed from: b, reason: collision with root package name */
    public final String f1335b;

    /* renamed from: c, reason: collision with root package name */
    public final String f1336c;

    public c(byte[] bArr, String str, String str2) {
        this.f1334a = bArr;
        this.f1335b = str;
        this.f1336c = str2;
    }

    @Override // S.D
    public final void b(B b6) {
        String str = this.f1335b;
        if (str != null) {
            b6.f2384a = str;
        }
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj != null && c.class == obj.getClass()) {
            return Arrays.equals(this.f1334a, ((c) obj).f1334a);
        }
        return false;
    }

    public final int hashCode() {
        return Arrays.hashCode(this.f1334a);
    }

    public final String toString() {
        int length = this.f1334a.length;
        StringBuilder sb = new StringBuilder("ICY: title=\"");
        sb.append(this.f1335b);
        sb.append("\", url=\"");
        sb.append(this.f1336c);
        sb.append("\", rawMetadata.length=\"");
        return AbstractC0034i.l(sb, length, "\"");
    }
}
