package K0;

import C4.AbstractC0034i;
import S.B;
import S.D;
import V.AbstractC0133a;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import org.apache.tika.pipes.pipesiterator.PipesIterator;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* loaded from: classes.dex */
public final class b implements D {

    /* renamed from: a, reason: collision with root package name */
    public final int f1329a;

    /* renamed from: b, reason: collision with root package name */
    public final String f1330b;

    /* renamed from: c, reason: collision with root package name */
    public final String f1331c;

    /* renamed from: d, reason: collision with root package name */
    public final String f1332d;
    public final boolean e;

    /* renamed from: f, reason: collision with root package name */
    public final int f1333f;

    public b(int i6, String str, String str2, String str3, boolean z6, int i7) {
        boolean z7;
        if (i7 != -1 && i7 <= 0) {
            z7 = false;
        } else {
            z7 = true;
        }
        AbstractC0133a.c(z7);
        this.f1329a = i6;
        this.f1330b = str;
        this.f1331c = str2;
        this.f1332d = str3;
        this.e = z6;
        this.f1333f = i7;
    }

    /* JADX WARN: Removed duplicated region for block: B:12:0x004b  */
    /* JADX WARN: Removed duplicated region for block: B:15:0x005f  */
    /* JADX WARN: Removed duplicated region for block: B:18:0x0073  */
    /* JADX WARN: Removed duplicated region for block: B:21:0x0087  */
    /* JADX WARN: Removed duplicated region for block: B:24:0x00a1  */
    /* JADX WARN: Removed duplicated region for block: B:40:0x00c9  */
    /* JADX WARN: Removed duplicated region for block: B:43:? A[RETURN, SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:44:0x0096  */
    /* JADX WARN: Removed duplicated region for block: B:45:0x007c  */
    /* JADX WARN: Removed duplicated region for block: B:46:0x0068  */
    /* JADX WARN: Removed duplicated region for block: B:47:0x0054  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public static b d(Map map) {
        boolean z6;
        int i6;
        List list;
        String str;
        List list2;
        String str2;
        List list3;
        String str3;
        List list4;
        boolean z7;
        List list5;
        int i7;
        List list6 = (List) map.get("icy-br");
        boolean z8 = true;
        int i8 = -1;
        if (list6 != null) {
            String str4 = (String) list6.get(0);
            try {
                i7 = Integer.parseInt(str4) * PipesIterator.DEFAULT_QUEUE_SIZE;
                if (i7 > 0) {
                    z6 = true;
                } else {
                    try {
                        AbstractC0133a.A("IcyHeaders", "Invalid bitrate: " + str4);
                        z6 = false;
                        i7 = -1;
                    } catch (NumberFormatException unused) {
                        AbstractC0034i.t("Invalid bitrate header: ", str4, "IcyHeaders");
                        z6 = false;
                        i6 = i7;
                        list = (List) map.get("icy-genre");
                        if (list == null) {
                        }
                        list2 = (List) map.get("icy-name");
                        if (list2 == null) {
                        }
                        list3 = (List) map.get("icy-url");
                        if (list3 == null) {
                        }
                        list4 = (List) map.get("icy-pub");
                        if (list4 == null) {
                        }
                        list5 = (List) map.get("icy-metaint");
                        if (list5 != null) {
                        }
                        int i9 = i8;
                        if (!z6) {
                        }
                    }
                }
            } catch (NumberFormatException unused2) {
                i7 = -1;
            }
            i6 = i7;
        } else {
            z6 = false;
            i6 = -1;
        }
        list = (List) map.get("icy-genre");
        if (list == null) {
            str = (String) list.get(0);
            z6 = true;
        } else {
            str = null;
        }
        list2 = (List) map.get("icy-name");
        if (list2 == null) {
            str2 = (String) list2.get(0);
            z6 = true;
        } else {
            str2 = null;
        }
        list3 = (List) map.get("icy-url");
        if (list3 == null) {
            str3 = (String) list3.get(0);
            z6 = true;
        } else {
            str3 = null;
        }
        list4 = (List) map.get("icy-pub");
        if (list4 == null) {
            z7 = ((String) list4.get(0)).equals("1");
            z6 = true;
        } else {
            z7 = false;
        }
        list5 = (List) map.get("icy-metaint");
        if (list5 != null) {
            String str5 = (String) list5.get(0);
            try {
                int parseInt = Integer.parseInt(str5);
                if (parseInt > 0) {
                    i8 = parseInt;
                } else {
                    try {
                        AbstractC0133a.A("IcyHeaders", "Invalid metadata interval: " + str5);
                        z8 = z6;
                    } catch (NumberFormatException unused3) {
                        i8 = parseInt;
                        AbstractC0034i.t("Invalid metadata interval: ", str5, "IcyHeaders");
                        int i92 = i8;
                        if (!z6) {
                        }
                    }
                }
                z6 = z8;
            } catch (NumberFormatException unused4) {
            }
        }
        int i922 = i8;
        if (!z6) {
            return null;
        }
        return new b(i6, str, str2, str3, z7, i922);
    }

    @Override // S.D
    public final void b(B b6) {
        String str = this.f1331c;
        if (str != null) {
            b6.f2405x = str;
        }
        String str2 = this.f1330b;
        if (str2 != null) {
            b6.f2404w = str2;
        }
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj != null && b.class == obj.getClass()) {
            b bVar = (b) obj;
            if (this.f1329a == bVar.f1329a && Objects.equals(this.f1330b, bVar.f1330b) && Objects.equals(this.f1331c, bVar.f1331c) && Objects.equals(this.f1332d, bVar.f1332d) && this.e == bVar.e && this.f1333f == bVar.f1333f) {
                return true;
            }
        }
        return false;
    }

    public final int hashCode() {
        int i6;
        int i7;
        int i8 = (527 + this.f1329a) * 31;
        int i9 = 0;
        String str = this.f1330b;
        if (str != null) {
            i6 = str.hashCode();
        } else {
            i6 = 0;
        }
        int i10 = (i8 + i6) * 31;
        String str2 = this.f1331c;
        if (str2 != null) {
            i7 = str2.hashCode();
        } else {
            i7 = 0;
        }
        int i11 = (i10 + i7) * 31;
        String str3 = this.f1332d;
        if (str3 != null) {
            i9 = str3.hashCode();
        }
        return ((((i11 + i9) * 31) + (this.e ? 1 : 0)) * 31) + this.f1333f;
    }

    public final String toString() {
        return "IcyHeaders: name=\"" + this.f1331c + "\", genre=\"" + this.f1330b + "\", bitrate=" + this.f1329a + ", metadataInterval=" + this.f1333f;
    }
}
