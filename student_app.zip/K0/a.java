package K0;

import S.E;
import a.AbstractC0194a;
import java.nio.ByteBuffer;
import java.nio.charset.CharacterCodingException;
import java.nio.charset.CharsetDecoder;
import java.nio.charset.StandardCharsets;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* loaded from: classes.dex */
public final class a extends AbstractC0194a {

    /* renamed from: s, reason: collision with root package name */
    public static final Pattern f1326s = Pattern.compile("(.+?)='(.*?)';", 32);

    /* renamed from: q, reason: collision with root package name */
    public final CharsetDecoder f1327q;

    /* renamed from: r, reason: collision with root package name */
    public final CharsetDecoder f1328r;

    public a() {
        super(4);
        this.f1327q = StandardCharsets.UTF_8.newDecoder();
        this.f1328r = StandardCharsets.ISO_8859_1.newDecoder();
    }

    @Override // a.AbstractC0194a
    public final E x(G0.a aVar, ByteBuffer byteBuffer) {
        String str;
        CharsetDecoder charsetDecoder = this.f1328r;
        CharsetDecoder charsetDecoder2 = this.f1327q;
        String str2 = null;
        try {
            str = charsetDecoder2.decode(byteBuffer).toString();
        } catch (CharacterCodingException unused) {
            try {
                String charBuffer = charsetDecoder.decode(byteBuffer).toString();
                charsetDecoder.reset();
                byteBuffer.rewind();
                str = charBuffer;
            } catch (CharacterCodingException unused2) {
                charsetDecoder.reset();
                byteBuffer.rewind();
                str = null;
            } catch (Throwable th) {
                charsetDecoder.reset();
                byteBuffer.rewind();
                throw th;
            }
        } finally {
            charsetDecoder2.reset();
            byteBuffer.rewind();
        }
        byte[] bArr = new byte[byteBuffer.limit()];
        byteBuffer.get(bArr);
        if (str == null) {
            return new E(new c(bArr, null, null));
        }
        Matcher matcher = f1326s.matcher(str);
        String str3 = null;
        for (int i6 = 0; matcher.find(i6); i6 = matcher.end()) {
            String group = matcher.group(1);
            String group2 = matcher.group(2);
            if (group != null) {
                String M6 = Q5.a.M(group);
                M6.getClass();
                if (!M6.equals("streamurl")) {
                    if (M6.equals("streamtitle")) {
                        str2 = group2;
                    }
                } else {
                    str3 = group2;
                }
            }
        }
        return new E(new c(bArr, str2, str3));
    }
}
