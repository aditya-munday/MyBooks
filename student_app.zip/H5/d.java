package H5;

import java.nio.charset.Charset;
import java.nio.file.OpenOption;
import java.util.function.IntUnaryOperator;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* loaded from: classes.dex */
public abstract class d extends b {
    static {
        OpenOption[] openOptionArr = I5.a.f1094a;
    }

    public d() {
        Charset.defaultCharset();
        Charset.defaultCharset();
        new IntUnaryOperator() { // from class: H5.c
            @Override // java.util.function.IntUnaryOperator
            public final int applyAsInt(int i6) {
                d.this.getClass();
                if (i6 <= Integer.MAX_VALUE) {
                    return i6;
                }
                throw new IllegalArgumentException(String.format("Request %,d exceeds maximum %,d", Integer.valueOf(i6), Integer.MAX_VALUE));
            }
        };
    }
}
