package H5;

import java.util.Objects;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* loaded from: classes.dex */
public final class a extends android.support.v4.media.session.a {

    /* renamed from: b, reason: collision with root package name */
    public final Object f1050b;

    public a(byte[] bArr) {
        Objects.requireNonNull(bArr, "origin");
        this.f1050b = bArr;
    }

    public final String toString() {
        return a.class.getSimpleName() + "[" + this.f1050b.toString() + "]";
    }
}
