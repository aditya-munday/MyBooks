package H5;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* loaded from: classes.dex */
public abstract class b extends android.support.v4.media.session.a {

    /* renamed from: b, reason: collision with root package name */
    public a f1051b;
}
