package E1;

import android.bluetooth.BluetoothManager;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.location.LocationManager;
import android.net.Uri;
import android.os.Build;
import android.provider.Settings;
import android.telephony.TelephonyManager;
import android.util.Log;
import java.util.List;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* loaded from: classes.dex */
public final class d {
    /* JADX WARN: Code restructure failed: missing block: B:57:0x00cd, code lost:
    
        if (android.provider.Settings.Secure.getInt(r7.getContentResolver(), "location_mode") != 0) goto L60;
     */
    /* JADX WARN: Multi-variable type inference failed */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public static void a(int i6, Context context, a aVar, a aVar2) {
        List<ResolveInfo> queryIntentActivities;
        if (context == null) {
            Log.d("permissions_handler", "Context cannot be null.");
            aVar2.f682p.d("PermissionHandler.ServiceManager", "Android context cannot be null.", null);
            return;
        }
        int i7 = 1;
        if (i6 != 3 && i6 != 4 && i6 != 5) {
            if (i6 == 21) {
                aVar.a(((BluetoothManager) context.getSystemService("bluetooth")).getAdapter().isEnabled() ? 1 : 0);
                return;
            }
            if (i6 == 8) {
                PackageManager packageManager = context.getPackageManager();
                if (!packageManager.hasSystemFeature("android.hardware.telephony")) {
                    aVar.a(2);
                    return;
                }
                TelephonyManager telephonyManager = (TelephonyManager) context.getSystemService("phone");
                if (telephonyManager != null && telephonyManager.getPhoneType() != 0) {
                    Intent intent = new Intent("android.intent.action.CALL");
                    intent.setData(Uri.parse("tel:123123"));
                    if (Build.VERSION.SDK_INT >= 33) {
                        queryIntentActivities = packageManager.queryIntentActivities(intent, PackageManager.ResolveInfoFlags.of(0L));
                    } else {
                        queryIntentActivities = packageManager.queryIntentActivities(intent, 0);
                    }
                    if (queryIntentActivities.isEmpty()) {
                        aVar.a(2);
                        return;
                    } else if (telephonyManager.getSimState() != 5) {
                        aVar.a(0);
                        return;
                    } else {
                        aVar.a(1);
                        return;
                    }
                }
                aVar.a(2);
                return;
            }
            if (i6 == 16) {
                aVar.a(1);
                return;
            } else {
                aVar.a(2);
                return;
            }
        }
        if (Build.VERSION.SDK_INT >= 28) {
            LocationManager locationManager = (LocationManager) context.getSystemService(LocationManager.class);
            if (locationManager != null) {
                i7 = locationManager.isLocationEnabled();
            }
            i7 = 0;
        } else {
            try {
            } catch (Settings.SettingNotFoundException e) {
                e.printStackTrace();
            }
        }
        aVar.a(i7);
    }
}
