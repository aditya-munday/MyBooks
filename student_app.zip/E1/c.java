package E1;

import M4.r;
import M4.t;
import android.app.Activity;
import android.app.AlarmManager;
import android.app.NotificationManager;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.os.PowerManager;
import android.provider.Settings;
import android.util.Log;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import org.apache.tika.fork.ContentHandlerProxy;
import org.apache.tika.pipes.PipesServer;
import org.apache.tika.utils.XMLReaderUtils;
import u.AbstractC0803c;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* loaded from: classes.dex */
public final class c implements r, t {
    public final Context o;

    /* renamed from: p, reason: collision with root package name */
    public a f685p;

    /* renamed from: q, reason: collision with root package name */
    public Activity f686q;

    /* renamed from: r, reason: collision with root package name */
    public int f687r;

    /* renamed from: s, reason: collision with root package name */
    public HashMap f688s;

    public c(Context context) {
        this.o = context;
    }

    /* JADX WARN: Code restructure failed: missing block: B:6:0x0021, code lost:
    
        if (new t.C0769G(r6).f9530b.areNotificationsEnabled() != false) goto L8;
     */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final int a(int i6) {
        int i7;
        int i8 = 1;
        int i9 = 0;
        Context context = this.o;
        if (i6 == 17) {
            if (Build.VERSION.SDK_INT >= 33) {
                if (context.checkSelfPermission("android.permission.POST_NOTIFICATIONS") != 0) {
                    return E.d.b(this.f686q, "android.permission.POST_NOTIFICATIONS");
                }
            }
            return 1;
        }
        if (i6 == 21) {
            ArrayList f6 = E.d.f(context, 21);
            if (f6 != null && !f6.isEmpty()) {
                return 1;
            }
            Log.d("permissions_handler", "Bluetooth permission missing in manifest");
            return 0;
        }
        if ((i6 == 30 || i6 == 28 || i6 == 29) && Build.VERSION.SDK_INT < 31) {
            ArrayList f7 = E.d.f(context, 21);
            if (f7 != null && !f7.isEmpty()) {
                return 1;
            }
            Log.d("permissions_handler", "Bluetooth permission missing in manifest");
            return 0;
        }
        if ((i6 != 37 && i6 != 0) || b()) {
            ArrayList f8 = E.d.f(context, i6);
            if (f8 == null) {
                Log.d("permissions_handler", "No android specific permissions needed for: " + i6);
                return 1;
            }
            if (f8.size() == 0) {
                Log.d("permissions_handler", "No permissions found in manifest for: " + f8 + i6);
                if (i6 == 22 && Build.VERSION.SDK_INT < 30) {
                    return 2;
                }
            } else {
                int i10 = 23;
                if (context.getApplicationInfo().targetSdkVersion >= 23) {
                    HashSet hashSet = new HashSet();
                    int size = f8.size();
                    int i11 = 0;
                    while (i11 < size) {
                        Object obj = f8.get(i11);
                        i11++;
                        String str = (String) obj;
                        int i12 = i8;
                        if (i6 == 16) {
                            String packageName = context.getPackageName();
                            PowerManager powerManager = (PowerManager) context.getSystemService("power");
                            if (powerManager != null && powerManager.isIgnoringBatteryOptimizations(packageName)) {
                                hashSet.add(1);
                            } else {
                                hashSet.add(Integer.valueOf(i9));
                            }
                        } else if (i6 == 22) {
                            if (Build.VERSION.SDK_INT < 30) {
                                hashSet.add(2);
                            }
                            hashSet.add(Integer.valueOf(Environment.isExternalStorageManager() ? 1 : 0));
                        } else if (i6 == i10) {
                            hashSet.add(Integer.valueOf(Settings.canDrawOverlays(context) ? 1 : 0));
                        } else if (i6 == 24) {
                            if (Build.VERSION.SDK_INT >= 26) {
                                hashSet.add(Integer.valueOf(context.getPackageManager().canRequestPackageInstalls() ? 1 : 0));
                            }
                        } else if (i6 == 27) {
                            hashSet.add(Integer.valueOf(((NotificationManager) context.getSystemService("notification")).isNotificationPolicyAccessGranted() ? 1 : 0));
                        } else if (i6 == 34) {
                            if (Build.VERSION.SDK_INT >= 31) {
                                hashSet.add(Integer.valueOf(((AlarmManager) context.getSystemService("alarm")).canScheduleExactAlarms() ? 1 : 0));
                            } else {
                                hashSet.add(1);
                            }
                        } else if (i6 != 9 && i6 != 32) {
                            if (AbstractC0803c.a(context, str) != 0) {
                                hashSet.add(Integer.valueOf(E.d.b(this.f686q, str)));
                            }
                        } else {
                            int a6 = AbstractC0803c.a(context, str);
                            if (Build.VERSION.SDK_INT >= 34) {
                                i7 = AbstractC0803c.a(context, "android.permission.READ_MEDIA_VISUAL_USER_SELECTED");
                            } else {
                                i7 = a6;
                            }
                            if (i7 == 0 && a6 == -1) {
                                hashSet.add(3);
                            } else if (a6 == 0) {
                                hashSet.add(1);
                            } else {
                                hashSet.add(Integer.valueOf(E.d.b(this.f686q, str)));
                            }
                        }
                        i8 = i12;
                        i9 = 0;
                        i10 = 23;
                    }
                    int i13 = i8;
                    if (!hashSet.isEmpty()) {
                        return E.d.n(hashSet).intValue();
                    }
                    return i13;
                }
                return 1;
            }
        }
        return 0;
    }

    public final boolean b() {
        boolean z6;
        boolean z7;
        ArrayList f6 = E.d.f(this.o, 37);
        if (f6 != null && f6.contains("android.permission.WRITE_CALENDAR")) {
            z6 = true;
        } else {
            z6 = false;
        }
        if (f6 != null && f6.contains("android.permission.READ_CALENDAR")) {
            z7 = true;
        } else {
            z7 = false;
        }
        if (z6 && z7) {
            return true;
        }
        if (!z6) {
            Log.d("permissions_handler", "android.permission.WRITE_CALENDAR missing in manifest");
        }
        if (!z7) {
            Log.d("permissions_handler", "android.permission.READ_CALENDAR missing in manifest");
        }
        return false;
    }

    public final void c(int i6, String str) {
        if (this.f686q == null) {
            return;
        }
        Intent intent = new Intent(str);
        if (!str.equals("android.settings.NOTIFICATION_POLICY_ACCESS_SETTINGS")) {
            intent.setData(Uri.parse("package:" + this.f686q.getPackageName()));
        }
        this.f686q.startActivityForResult(intent, i6);
        this.f687r++;
    }

    /* JADX WARN: Multi-variable type inference failed */
    @Override // M4.r
    public final boolean onActivityResult(int i6, int i7, Intent intent) {
        boolean z6;
        int i8;
        int i9;
        Activity activity = this.f686q;
        boolean z7 = false;
        z7 = false;
        if (activity != null) {
            if (this.f688s == null) {
                this.f687r = 0;
                return false;
            }
            if (i6 == 209) {
                Context context = this.o;
                String packageName = context.getPackageName();
                PowerManager powerManager = (PowerManager) context.getSystemService("power");
                if (powerManager != null && powerManager.isIgnoringBatteryOptimizations(packageName)) {
                    z7 = true;
                }
                i8 = 16;
                i9 = z7;
            } else if (i6 == 210) {
                if (Build.VERSION.SDK_INT >= 30) {
                    i8 = 22;
                    i9 = Environment.isExternalStorageManager();
                }
            } else if (i6 == 211) {
                i8 = 23;
                i9 = Settings.canDrawOverlays(activity);
            } else if (i6 == 212) {
                if (Build.VERSION.SDK_INT >= 26) {
                    i8 = 24;
                    i9 = activity.getPackageManager().canRequestPackageInstalls();
                }
            } else if (i6 == 213) {
                i8 = 27;
                i9 = ((NotificationManager) activity.getSystemService("notification")).isNotificationPolicyAccessGranted();
            } else if (i6 == 214) {
                AlarmManager alarmManager = (AlarmManager) activity.getSystemService("alarm");
                if (Build.VERSION.SDK_INT >= 31) {
                    z6 = alarmManager.canScheduleExactAlarms();
                } else {
                    z6 = true;
                }
                i8 = 34;
                i9 = z6;
            }
            this.f688s.put(Integer.valueOf(i8), Integer.valueOf(i9));
            int i10 = this.f687r - 1;
            this.f687r = i10;
            a aVar = this.f685p;
            if (aVar != null && i10 == 0) {
                aVar.f682p.b(this.f688s);
            }
            return true;
        }
        return false;
    }

    /* JADX WARN: Failed to find 'out' block for switch in B:28:0x00c8. Please report as an issue. */
    @Override // M4.t
    public final boolean onRequestPermissionsResult(int i6, String[] strArr, int[] iArr) {
        int i7;
        int i8 = 8;
        if (i6 != 24) {
            this.f687r = 0;
            return false;
        }
        if (this.f688s == null) {
            return false;
        }
        if (strArr.length == 0 && iArr.length == 0) {
            this.f687r = 0;
            Log.w("permissions_handler", "onRequestPermissionsResult is called without results. This is probably caused by interfering request codes. If you see this error, please file an issue in flutter-permission-handler, including a list of plugins used by this application: https://github.com/Baseflow/flutter-permission-handler/issues");
            return false;
        }
        List asList = Arrays.asList(strArr);
        int indexOf = asList.indexOf("android.permission.WRITE_CALENDAR");
        if (indexOf >= 0) {
            int o = E.d.o(this.f686q, "android.permission.WRITE_CALENDAR", iArr[indexOf]);
            this.f688s.put(36, Integer.valueOf(o));
            int indexOf2 = asList.indexOf("android.permission.READ_CALENDAR");
            if (indexOf2 >= 0) {
                int o6 = E.d.o(this.f686q, "android.permission.READ_CALENDAR", iArr[indexOf2]);
                Integer valueOf = Integer.valueOf(o);
                Integer valueOf2 = Integer.valueOf(o6);
                HashSet hashSet = new HashSet();
                hashSet.add(valueOf);
                hashSet.add(valueOf2);
                Integer n6 = E.d.n(hashSet);
                this.f688s.put(37, n6);
                this.f688s.put(0, n6);
            }
        }
        int i9 = 0;
        while (i9 < strArr.length) {
            String str = strArr[i9];
            if (!str.equals("android.permission.WRITE_CALENDAR") && !str.equals("android.permission.READ_CALENDAR")) {
                int i10 = -1;
                switch (str.hashCode()) {
                    case -2062386608:
                        if (str.equals("android.permission.READ_SMS")) {
                            i10 = 0;
                            break;
                        }
                        break;
                    case -1928411001:
                        if (str.equals("android.permission.READ_CALENDAR")) {
                            i10 = 1;
                            break;
                        }
                        break;
                    case -1925850455:
                        if (str.equals("android.permission.POST_NOTIFICATIONS")) {
                            i10 = 2;
                            break;
                        }
                        break;
                    case -1921431796:
                        if (str.equals("android.permission.READ_CALL_LOG")) {
                            i10 = 3;
                            break;
                        }
                        break;
                    case -1888586689:
                        if (str.equals("android.permission.ACCESS_FINE_LOCATION")) {
                            i10 = 4;
                            break;
                        }
                        break;
                    case -1813079487:
                        if (str.equals("android.permission.MANAGE_EXTERNAL_STORAGE")) {
                            i10 = 5;
                            break;
                        }
                        break;
                    case -1783097621:
                        if (str.equals("android.permission.ACCESS_NOTIFICATION_POLICY")) {
                            i10 = 6;
                            break;
                        }
                        break;
                    case -1561629405:
                        if (str.equals("android.permission.SYSTEM_ALERT_WINDOW")) {
                            i10 = 7;
                            break;
                        }
                        break;
                    case -1479758289:
                        if (str.equals("android.permission.RECEIVE_WAP_PUSH")) {
                            i10 = i8;
                            break;
                        }
                        break;
                    case -1238066820:
                        if (str.equals("android.permission.BODY_SENSORS")) {
                            i10 = 9;
                            break;
                        }
                        break;
                    case -1164582768:
                        if (str.equals("android.permission.READ_PHONE_NUMBERS")) {
                            i10 = 10;
                            break;
                        }
                        break;
                    case -909527021:
                        if (str.equals("android.permission.NEARBY_WIFI_DEVICES")) {
                            i10 = 11;
                            break;
                        }
                        break;
                    case -895679497:
                        if (str.equals("android.permission.RECEIVE_MMS")) {
                            i10 = 12;
                            break;
                        }
                        break;
                    case -895673731:
                        if (str.equals("android.permission.RECEIVE_SMS")) {
                            i10 = 13;
                            break;
                        }
                        break;
                    case -798669607:
                        if (str.equals("android.permission.BLUETOOTH_CONNECT")) {
                            i10 = 14;
                            break;
                        }
                        break;
                    case -406040016:
                        if (str.equals("android.permission.READ_EXTERNAL_STORAGE")) {
                            i10 = 15;
                            break;
                        }
                        break;
                    case -63024214:
                        if (str.equals("android.permission.ACCESS_COARSE_LOCATION")) {
                            i10 = 16;
                            break;
                        }
                        break;
                    case -5573545:
                        if (str.equals("android.permission.READ_PHONE_STATE")) {
                            i10 = 17;
                            break;
                        }
                        break;
                    case 52602690:
                        if (str.equals("android.permission.SEND_SMS")) {
                            i10 = 18;
                            break;
                        }
                        break;
                    case 112197485:
                        if (str.equals("android.permission.CALL_PHONE")) {
                            i10 = 19;
                            break;
                        }
                        break;
                    case 175802396:
                        if (str.equals("android.permission.READ_MEDIA_IMAGES")) {
                            i10 = 20;
                            break;
                        }
                        break;
                    case 214526995:
                        if (str.equals("android.permission.WRITE_CONTACTS")) {
                            i10 = 21;
                            break;
                        }
                        break;
                    case 361658321:
                        if (str.equals("android.permission.BODY_SENSORS_BACKGROUND")) {
                            i10 = 22;
                            break;
                        }
                        break;
                    case 463403621:
                        if (str.equals("android.permission.CAMERA")) {
                            i10 = 23;
                            break;
                        }
                        break;
                    case 603653886:
                        if (str.equals("android.permission.WRITE_CALENDAR")) {
                            i10 = 24;
                            break;
                        }
                        break;
                    case 610633091:
                        if (str.equals("android.permission.WRITE_CALL_LOG")) {
                            i10 = 25;
                            break;
                        }
                        break;
                    case 691260818:
                        if (str.equals("android.permission.READ_MEDIA_AUDIO")) {
                            i10 = 26;
                            break;
                        }
                        break;
                    case 710297143:
                        if (str.equals("android.permission.READ_MEDIA_VIDEO")) {
                            i10 = 27;
                            break;
                        }
                        break;
                    case 784519842:
                        if (str.equals("android.permission.USE_SIP")) {
                            i10 = 28;
                            break;
                        }
                        break;
                    case 970694249:
                        if (str.equals("android.permission.SCHEDULE_EXACT_ALARM")) {
                            i10 = 29;
                            break;
                        }
                        break;
                    case 1166454870:
                        if (str.equals("android.permission.BLUETOOTH_ADVERTISE")) {
                            i10 = 30;
                            break;
                        }
                        break;
                    case 1271781903:
                        if (str.equals("android.permission.GET_ACCOUNTS")) {
                            i10 = 31;
                            break;
                        }
                        break;
                    case 1365911975:
                        if (str.equals("android.permission.WRITE_EXTERNAL_STORAGE")) {
                            i10 = 32;
                            break;
                        }
                        break;
                    case 1777263169:
                        if (str.equals("android.permission.REQUEST_INSTALL_PACKAGES")) {
                            i10 = 33;
                            break;
                        }
                        break;
                    case 1780337063:
                        if (str.equals("android.permission.ACTIVITY_RECOGNITION")) {
                            i10 = 34;
                            break;
                        }
                        break;
                    case 1831139720:
                        if (str.equals("android.permission.RECORD_AUDIO")) {
                            i10 = 35;
                            break;
                        }
                        break;
                    case 1977429404:
                        if (str.equals("android.permission.READ_CONTACTS")) {
                            i10 = 36;
                            break;
                        }
                        break;
                    case 2024715147:
                        if (str.equals("android.permission.ACCESS_BACKGROUND_LOCATION")) {
                            i10 = 37;
                            break;
                        }
                        break;
                    case 2062356686:
                        if (str.equals("android.permission.BLUETOOTH_SCAN")) {
                            i10 = 38;
                            break;
                        }
                        break;
                    case 2114579147:
                        if (str.equals("android.permission.ACCESS_MEDIA_LOCATION")) {
                            i10 = 39;
                            break;
                        }
                        break;
                    case 2133799037:
                        if (str.equals("com.android.voicemail.permission.ADD_VOICEMAIL")) {
                            i10 = 40;
                            break;
                        }
                        break;
                }
                switch (i10) {
                    case 0:
                    case 8:
                    case 12:
                    case 13:
                    case 18:
                        i7 = 13;
                        break;
                    case 1:
                    case 24:
                        i7 = 0;
                        break;
                    case 2:
                        i7 = 17;
                        break;
                    case 3:
                    case 10:
                    case PipesServer.TIMEOUT_EXIT_CODE /* 17 */:
                    case 19:
                    case 25:
                    case 28:
                    case 40:
                        i7 = i8;
                        break;
                    case 4:
                    case 16:
                        i7 = 3;
                        break;
                    case 5:
                        i7 = 22;
                        break;
                    case 6:
                        i7 = 27;
                        break;
                    case 7:
                        i7 = 23;
                        break;
                    case ContentHandlerProxy.PROCESSING_INSTRUCTION /* 9 */:
                        i7 = 12;
                        break;
                    case 11:
                        i7 = 31;
                        break;
                    case 14:
                        i7 = 30;
                        break;
                    case 15:
                    case 32:
                        i7 = 15;
                        break;
                    case XMLReaderUtils.DEFAULT_MAX_ENTITY_EXPANSIONS /* 20 */:
                        i7 = 9;
                        break;
                    case 21:
                    case 31:
                    case 36:
                        i7 = 2;
                        break;
                    case 22:
                        i7 = 35;
                        break;
                    case 23:
                        i7 = 1;
                        break;
                    case 26:
                        i7 = 33;
                        break;
                    case 27:
                        i7 = 32;
                        break;
                    case 29:
                        i7 = 34;
                        break;
                    case 30:
                        i7 = 29;
                        break;
                    case 33:
                        i7 = 24;
                        break;
                    case 34:
                        i7 = 19;
                        break;
                    case 35:
                        i7 = 7;
                        break;
                    case 37:
                        i7 = 4;
                        break;
                    case 38:
                        i7 = 28;
                        break;
                    case 39:
                        i7 = 18;
                        break;
                    default:
                        i7 = 20;
                        break;
                }
                if (i7 != 20) {
                    int i11 = iArr[i9];
                    if (i7 == i8) {
                        Integer num = (Integer) this.f688s.get(8);
                        Integer valueOf3 = Integer.valueOf(E.d.o(this.f686q, str, i11));
                        HashSet hashSet2 = new HashSet();
                        hashSet2.add(num);
                        hashSet2.add(valueOf3);
                        this.f688s.put(8, E.d.n(hashSet2));
                    } else if (i7 == 7) {
                        if (!this.f688s.containsKey(7)) {
                            this.f688s.put(7, Integer.valueOf(E.d.o(this.f686q, str, i11)));
                        }
                        if (!this.f688s.containsKey(14)) {
                            this.f688s.put(14, Integer.valueOf(E.d.o(this.f686q, str, i11)));
                        }
                    } else if (i7 == 4) {
                        int o7 = E.d.o(this.f686q, str, i11);
                        if (!this.f688s.containsKey(4)) {
                            this.f688s.put(4, Integer.valueOf(o7));
                        }
                    } else if (i7 == 3) {
                        int o8 = E.d.o(this.f686q, str, i11);
                        if (Build.VERSION.SDK_INT < 29 && !this.f688s.containsKey(4)) {
                            this.f688s.put(4, Integer.valueOf(o8));
                        }
                        if (!this.f688s.containsKey(5)) {
                            this.f688s.put(5, Integer.valueOf(o8));
                        }
                        this.f688s.put(Integer.valueOf(i7), Integer.valueOf(o8));
                    } else if (i7 != 9 && i7 != 32) {
                        if (!this.f688s.containsKey(Integer.valueOf(i7))) {
                            this.f688s.put(Integer.valueOf(i7), Integer.valueOf(E.d.o(this.f686q, str, i11)));
                        }
                    } else {
                        this.f688s.put(Integer.valueOf(i7), Integer.valueOf(a(i7)));
                    }
                }
            }
            i9++;
            i8 = 8;
        }
        int length = this.f687r - iArr.length;
        this.f687r = length;
        a aVar = this.f685p;
        if (aVar != null && length == 0) {
            aVar.f682p.b(this.f688s);
        }
        return true;
    }
}
