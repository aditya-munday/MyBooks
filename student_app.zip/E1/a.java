package E1;

import C2.i;
import L4.j;
import T4.f;
import java.util.HashMap;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* loaded from: classes.dex */
public final /* synthetic */ class a implements C2.d {
    public final /* synthetic */ int o;

    /* renamed from: p, reason: collision with root package name */
    public final /* synthetic */ j f682p;

    public /* synthetic */ a(j jVar, int i6) {
        this.o = i6;
        this.f682p = jVar;
    }

    public void a(int i6) {
        this.f682p.b(Integer.valueOf(i6));
    }

    @Override // C2.d
    public void v(i iVar) {
        String str;
        String str2;
        switch (this.o) {
            case 4:
                boolean f6 = iVar.f();
                j jVar = this.f682p;
                if (f6) {
                    jVar.b(iVar.d());
                    return;
                }
                Exception c6 = iVar.c();
                if (c6 != null) {
                    str = c6.getMessage();
                } else {
                    str = null;
                }
                HashMap hashMap = new HashMap();
                hashMap.put("code", "unknown");
                if (c6 != null) {
                    hashMap.put("message", c6.getMessage());
                } else {
                    hashMap.put("message", "An unknown error has occurred.");
                }
                jVar.d("firebase_dynamic_links", str, hashMap);
                return;
            default:
                boolean f7 = iVar.f();
                j jVar2 = this.f682p;
                if (f7) {
                    jVar2.b(iVar.d());
                    return;
                }
                Exception c7 = iVar.c();
                if (c7 != null) {
                    str2 = c7.getMessage();
                } else {
                    str2 = null;
                }
                HashMap hashMap2 = new HashMap();
                hashMap2.put("code", "unknown");
                if (c7 != null) {
                    hashMap2.put("message", c7.getMessage());
                } else {
                    hashMap2.put("message", "An unknown error has occurred.");
                }
                jVar2.d("firebase_messaging", str2, hashMap2);
                return;
        }
    }

    public /* synthetic */ a(f fVar, j jVar) {
        this.o = 5;
        this.f682p = jVar;
    }
}
