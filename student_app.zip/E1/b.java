package E1;

import M4.p;
import android.app.Activity;
import android.content.Context;
import j2.C0508g;
import java.util.HashSet;
import l.r0;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* loaded from: classes.dex */
public final class b implements I4.b, J4.a {
    public c o;

    /* renamed from: p, reason: collision with root package name */
    public p f683p;

    /* renamed from: q, reason: collision with root package name */
    public J4.b f684q;

    @Override // J4.a
    public final void onAttachedToActivity(J4.b bVar) {
        r0 r0Var = (r0) bVar;
        Activity activity = (Activity) r0Var.o;
        c cVar = this.o;
        if (cVar != null) {
            cVar.f686q = activity;
        }
        this.f684q = bVar;
        r0Var.a(cVar);
        ((r0) this.f684q).c(this.o);
    }

    /* JADX WARN: Type inference failed for: r4v1, types: [E1.d, java.lang.Object] */
    @Override // I4.b
    public final void onAttachedToEngine(I4.a aVar) {
        Context context = aVar.f1090a;
        this.o = new c(context);
        p pVar = new p(aVar.f1091b, "flutter.baseflow.com/permissions/methods");
        this.f683p = pVar;
        pVar.b(new A.c(context, new C0508g(2, false), this.o, (d) new Object()));
    }

    @Override // J4.a
    public final void onDetachedFromActivity() {
        c cVar = this.o;
        if (cVar != null) {
            cVar.f686q = null;
        }
        J4.b bVar = this.f684q;
        if (bVar != null) {
            ((r0) bVar).m(cVar);
            J4.b bVar2 = this.f684q;
            ((HashSet) ((r0) bVar2).f8182q).remove(this.o);
        }
        this.f684q = null;
    }

    @Override // J4.a
    public final void onDetachedFromActivityForConfigChanges() {
        onDetachedFromActivity();
    }

    @Override // I4.b
    public final void onDetachedFromEngine(I4.a aVar) {
        this.f683p.b(null);
        this.f683p = null;
    }

    @Override // J4.a
    public final void onReattachedToActivityForConfigChanges(J4.b bVar) {
        onAttachedToActivity(bVar);
    }
}
