package d1;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* loaded from: classes.dex */
public final class e {

    /* renamed from: c, reason: collision with root package name */
    public static final A.d f5983c = new A.d(4);

    /* renamed from: a, reason: collision with root package name */
    public final f f5984a;

    /* renamed from: b, reason: collision with root package name */
    public final int f5985b;

    public e(f fVar, int i6) {
        this.f5984a = fVar;
        this.f5985b = i6;
    }
}
