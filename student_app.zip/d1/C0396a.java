package d1;

import U0.k;
import U0.l;
import V.AbstractC0133a;
import V.C;
import V.v;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Collections;
import java.util.regex.Pattern;
import org.apache.tika.utils.StringUtils;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* renamed from: d1.a, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0396a implements l {
    public final v o;

    public C0396a(int i6) {
        switch (i6) {
            case 1:
                this.o = new v(10);
                return;
            default:
                this.o = new v();
                return;
        }
    }

    @Override // U0.l
    public void j(byte[] bArr, int i6, int i7, k kVar, V.g gVar) {
        boolean z6;
        U.b a6;
        boolean z7;
        v vVar = this.o;
        vVar.H(bArr, i6 + i7);
        vVar.J(i6);
        ArrayList arrayList = new ArrayList();
        while (vVar.a() > 0) {
            if (vVar.a() >= 8) {
                z6 = true;
            } else {
                z6 = false;
            }
            AbstractC0133a.b("Incomplete Mp4Webvtt Top Level box header found.", z6);
            int k6 = vVar.k();
            if (vVar.k() == 1987343459) {
                int i8 = k6 - 8;
                CharSequence charSequence = null;
                U.a aVar = null;
                while (i8 > 0) {
                    if (i8 >= 8) {
                        z7 = true;
                    } else {
                        z7 = false;
                    }
                    AbstractC0133a.b("Incomplete vtt cue box header found.", z7);
                    int k7 = vVar.k();
                    int k8 = vVar.k();
                    int i9 = k7 - 8;
                    byte[] bArr2 = vVar.f3120a;
                    int i10 = vVar.f3121b;
                    String str = C.f3053a;
                    String str2 = new String(bArr2, i10, i9, StandardCharsets.UTF_8);
                    vVar.K(i9);
                    i8 = (i8 - 8) - i9;
                    if (k8 == 1937011815) {
                        h hVar = new h();
                        i.e(str2, hVar);
                        aVar = hVar.a();
                    } else if (k8 == 1885436268) {
                        charSequence = i.f(null, Collections.EMPTY_LIST, str2.trim());
                    }
                }
                if (charSequence == null) {
                    charSequence = StringUtils.EMPTY;
                }
                if (aVar != null) {
                    aVar.f2872a = charSequence;
                    aVar.f2873b = null;
                    a6 = aVar.a();
                } else {
                    Pattern pattern = i.f6001a;
                    h hVar2 = new h();
                    hVar2.f5993c = charSequence;
                    a6 = hVar2.a().a();
                }
                arrayList.add(a6);
            } else {
                vVar.K(k6 - 8);
            }
        }
        gVar.accept(new U0.a(-9223372036854775807L, -9223372036854775807L, arrayList));
    }

    @Override // U0.l
    public int z() {
        return 2;
    }
}
