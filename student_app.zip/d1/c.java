package d1;

import java.util.Set;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* loaded from: classes.dex */
public final class c {

    /* renamed from: a, reason: collision with root package name */
    public String f5965a;

    /* renamed from: b, reason: collision with root package name */
    public String f5966b;

    /* renamed from: c, reason: collision with root package name */
    public Set f5967c;

    /* renamed from: d, reason: collision with root package name */
    public String f5968d;
    public String e;

    /* renamed from: f, reason: collision with root package name */
    public int f5969f;

    /* renamed from: g, reason: collision with root package name */
    public boolean f5970g;

    /* renamed from: h, reason: collision with root package name */
    public int f5971h;

    /* renamed from: i, reason: collision with root package name */
    public boolean f5972i;

    /* renamed from: j, reason: collision with root package name */
    public int f5973j;

    /* renamed from: k, reason: collision with root package name */
    public int f5974k;

    /* renamed from: l, reason: collision with root package name */
    public int f5975l;

    /* renamed from: m, reason: collision with root package name */
    public int f5976m;

    /* renamed from: n, reason: collision with root package name */
    public int f5977n;
    public float o;

    /* renamed from: p, reason: collision with root package name */
    public int f5978p;

    /* renamed from: q, reason: collision with root package name */
    public boolean f5979q;

    public static int a(int i6, int i7, String str, String str2) {
        if (!str.isEmpty() && i6 != -1) {
            if (!str.equals(str2)) {
                return -1;
            }
            return i6 + i7;
        }
        return i6;
    }
}
