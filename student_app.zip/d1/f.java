package d1;

import java.util.Set;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* loaded from: classes.dex */
public final class f {

    /* renamed from: a, reason: collision with root package name */
    public final String f5986a;

    /* renamed from: b, reason: collision with root package name */
    public final int f5987b;

    /* renamed from: c, reason: collision with root package name */
    public final String f5988c;

    /* renamed from: d, reason: collision with root package name */
    public final Set f5989d;

    public f(String str, int i6, String str2, Set set) {
        this.f5987b = i6;
        this.f5986a = str;
        this.f5988c = str2;
        this.f5989d = set;
    }
}
