package d1;

import S.G;
import V.C;
import V.v;
import java.nio.charset.StandardCharsets;
import java.util.regex.Pattern;
import org.apache.tika.metadata.TikaCoreProperties;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* loaded from: classes.dex */
public abstract class j {

    /* renamed from: a, reason: collision with root package name */
    public static final Pattern f6005a = Pattern.compile("^NOTE([ \t].*)?$");

    public static boolean a(v vVar) {
        vVar.getClass();
        String l6 = vVar.l(StandardCharsets.UTF_8);
        if (l6 != null && l6.startsWith("WEBVTT")) {
            return true;
        }
        return false;
    }

    public static float b(String str) {
        if (str.endsWith("%")) {
            return Float.parseFloat(str.substring(0, str.length() - 1)) / 100.0f;
        }
        throw new NumberFormatException("Percentages must end with %");
    }

    public static long c(String str) {
        String str2 = C.f3053a;
        String[] split = str.split("\\.", 2);
        long j6 = 0;
        for (String str3 : split[0].split(TikaCoreProperties.NAMESPACE_PREFIX_DELIMITER, -1)) {
            j6 = (j6 * 60) + Long.parseLong(str3);
        }
        long j7 = j6 * 1000;
        if (split.length == 2) {
            String trim = split[1].trim();
            if (trim.length() == 3) {
                j7 += Long.parseLong(trim);
            } else {
                throw new IllegalArgumentException("Expected 3 decimal places, got: ".concat(trim));
            }
        }
        return j7 * 1000;
    }

    public static void d(v vVar) {
        int i6 = vVar.f3121b;
        if (a(vVar)) {
            return;
        }
        vVar.J(i6);
        throw G.a(null, "Expected WEBVTT. Got " + vVar.l(StandardCharsets.UTF_8));
    }
}
