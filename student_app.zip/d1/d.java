package d1;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* loaded from: classes.dex */
public final class d {

    /* renamed from: a, reason: collision with root package name */
    public final U.b f5980a;

    /* renamed from: b, reason: collision with root package name */
    public final long f5981b;

    /* renamed from: c, reason: collision with root package name */
    public final long f5982c;

    public d(U.b bVar, long j6, long j7) {
        this.f5980a = bVar;
        this.f5981b = j6;
        this.f5982c = j7;
    }
}
