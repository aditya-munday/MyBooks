package d1;

import C4.AbstractC0034i;
import android.text.Layout;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* loaded from: classes.dex */
public final class h {

    /* renamed from: c, reason: collision with root package name */
    public CharSequence f5993c;

    /* renamed from: a, reason: collision with root package name */
    public long f5991a = 0;

    /* renamed from: b, reason: collision with root package name */
    public long f5992b = 0;

    /* renamed from: d, reason: collision with root package name */
    public int f5994d = 2;
    public float e = -3.4028235E38f;

    /* renamed from: f, reason: collision with root package name */
    public int f5995f = 1;

    /* renamed from: g, reason: collision with root package name */
    public int f5996g = 0;

    /* renamed from: h, reason: collision with root package name */
    public float f5997h = -3.4028235E38f;

    /* renamed from: i, reason: collision with root package name */
    public int f5998i = Integer.MIN_VALUE;

    /* renamed from: j, reason: collision with root package name */
    public float f5999j = 1.0f;

    /* renamed from: k, reason: collision with root package name */
    public int f6000k = Integer.MIN_VALUE;

    /* JADX WARN: Code restructure failed: missing block: B:52:0x0072, code lost:
    
        if (r7 == 0) goto L39;
     */
    /* JADX WARN: Removed duplicated region for block: B:36:0x0085  */
    /* JADX WARN: Removed duplicated region for block: B:43:0x00b0  */
    /* JADX WARN: Removed duplicated region for block: B:49:0x00a0  */
    /* JADX WARN: Removed duplicated region for block: B:51:0x0070  */
    /* JADX WARN: Removed duplicated region for block: B:52:0x0072  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final U.a a() {
        Layout.Alignment alignment;
        float f6;
        CharSequence charSequence;
        float f7 = this.f5997h;
        float f8 = -3.4028235E38f;
        if (f7 == -3.4028235E38f) {
            int i6 = this.f5994d;
            if (i6 != 4) {
                if (i6 != 5) {
                    f7 = 0.5f;
                } else {
                    f7 = 1.0f;
                }
            } else {
                f7 = 0.0f;
            }
        }
        int i7 = this.f5998i;
        if (i7 == Integer.MIN_VALUE) {
            int i8 = this.f5994d;
            if (i8 != 1) {
                if (i8 != 3) {
                    if (i8 != 4) {
                        if (i8 != 5) {
                            i7 = 1;
                        }
                    }
                }
                i7 = 2;
            }
            i7 = 0;
        }
        U.a aVar = new U.a();
        int i9 = this.f5994d;
        if (i9 != 1) {
            if (i9 != 2) {
                if (i9 != 3) {
                    if (i9 != 4) {
                        if (i9 != 5) {
                            AbstractC0034i.s("Unknown textAlignment: ", i9, "WebvttCueParser");
                            alignment = null;
                        }
                    }
                }
                alignment = Layout.Alignment.ALIGN_OPPOSITE;
            } else {
                alignment = Layout.Alignment.ALIGN_CENTER;
            }
            aVar.f2874c = alignment;
            f6 = this.e;
            int i10 = this.f5995f;
            if (f6 != -3.4028235E38f || i10 != 0 || (f6 >= 0.0f && f6 <= 1.0f)) {
                if (f6 == -3.4028235E38f) {
                    f8 = f6;
                }
                aVar.e = f8;
                aVar.f2876f = i10;
                aVar.f2877g = this.f5996g;
                aVar.f2878h = f7;
                aVar.f2879i = i7;
                float f9 = this.f5999j;
                if (i7 != 0) {
                    if (i7 != 1) {
                        if (i7 != 2) {
                            throw new IllegalStateException(String.valueOf(i7));
                        }
                    } else if (f7 <= 0.5f) {
                        f7 *= 2.0f;
                    } else {
                        f7 = (1.0f - f7) * 2.0f;
                    }
                } else {
                    f7 = 1.0f - f7;
                }
                aVar.f2882l = Math.min(f9, f7);
                aVar.f2885p = this.f6000k;
                charSequence = this.f5993c;
                if (charSequence != null) {
                    aVar.f2872a = charSequence;
                    aVar.f2873b = null;
                }
                return aVar;
            }
            f8 = 1.0f;
            aVar.e = f8;
            aVar.f2876f = i10;
            aVar.f2877g = this.f5996g;
            aVar.f2878h = f7;
            aVar.f2879i = i7;
            float f92 = this.f5999j;
            if (i7 != 0) {
            }
            aVar.f2882l = Math.min(f92, f7);
            aVar.f2885p = this.f6000k;
            charSequence = this.f5993c;
            if (charSequence != null) {
            }
            return aVar;
        }
        alignment = Layout.Alignment.ALIGN_NORMAL;
        aVar.f2874c = alignment;
        f6 = this.e;
        int i102 = this.f5995f;
        if (f6 != -3.4028235E38f) {
        }
        if (f6 == -3.4028235E38f) {
        }
        aVar.e = f8;
        aVar.f2876f = i102;
        aVar.f2877g = this.f5996g;
        aVar.f2878h = f7;
        aVar.f2879i = i7;
        float f922 = this.f5999j;
        if (i7 != 0) {
        }
        aVar.f2882l = Math.min(f922, f7);
        aVar.f2885p = this.f6000k;
        charSequence = this.f5993c;
        if (charSequence != null) {
        }
        return aVar;
    }
}
