package d1;

import V.AbstractC0133a;
import V.C;
import V.v;
import android.graphics.Color;
import android.text.SpannableStringBuilder;
import android.text.SpannedString;
import android.text.TextUtils;
import android.text.style.AbsoluteSizeSpan;
import android.text.style.BackgroundColorSpan;
import android.text.style.ForegroundColorSpan;
import android.text.style.RelativeSizeSpan;
import android.text.style.StrikethroughSpan;
import android.text.style.StyleSpan;
import android.text.style.TypefaceSpan;
import android.text.style.UnderlineSpan;
import java.nio.charset.StandardCharsets;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import org.apache.tika.metadata.TikaCoreProperties;
import org.apache.tika.utils.StringUtils;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* loaded from: classes.dex */
public abstract class i {

    /* renamed from: a, reason: collision with root package name */
    public static final Pattern f6001a = Pattern.compile("^(\\S+)\\s+-->\\s+(\\S+)((?:.|\\f)*)?$");

    /* renamed from: b, reason: collision with root package name */
    public static final Pattern f6002b = Pattern.compile("(\\S+?):(\\S+)");

    /* renamed from: c, reason: collision with root package name */
    public static final Map f6003c;

    /* renamed from: d, reason: collision with root package name */
    public static final Map f6004d;

    static {
        HashMap hashMap = new HashMap();
        hashMap.put("white", Integer.valueOf(Color.rgb(255, 255, 255)));
        hashMap.put("lime", Integer.valueOf(Color.rgb(0, 255, 0)));
        hashMap.put("cyan", Integer.valueOf(Color.rgb(0, 255, 255)));
        hashMap.put("red", Integer.valueOf(Color.rgb(255, 0, 0)));
        hashMap.put("yellow", Integer.valueOf(Color.rgb(255, 255, 0)));
        hashMap.put("magenta", Integer.valueOf(Color.rgb(255, 0, 255)));
        hashMap.put("blue", Integer.valueOf(Color.rgb(0, 0, 255)));
        hashMap.put("black", Integer.valueOf(Color.rgb(0, 0, 0)));
        f6003c = Collections.unmodifiableMap(hashMap);
        HashMap hashMap2 = new HashMap();
        hashMap2.put("bg_white", Integer.valueOf(Color.rgb(255, 255, 255)));
        hashMap2.put("bg_lime", Integer.valueOf(Color.rgb(0, 255, 0)));
        hashMap2.put("bg_cyan", Integer.valueOf(Color.rgb(0, 255, 255)));
        hashMap2.put("bg_red", Integer.valueOf(Color.rgb(255, 0, 0)));
        hashMap2.put("bg_yellow", Integer.valueOf(Color.rgb(255, 255, 0)));
        hashMap2.put("bg_magenta", Integer.valueOf(Color.rgb(255, 0, 255)));
        hashMap2.put("bg_blue", Integer.valueOf(Color.rgb(0, 0, 255)));
        hashMap2.put("bg_black", Integer.valueOf(Color.rgb(0, 0, 0)));
        f6004d = Collections.unmodifiableMap(hashMap2);
    }

    /* JADX WARN: Can't fix incorrect switch cases order, some code will duplicate */
    public static void a(String str, f fVar, List list, SpannableStringBuilder spannableStringBuilder, List list2) {
        char c6;
        char c7;
        char c8;
        int i6;
        int i7;
        int i8;
        int i9;
        int i10;
        int i11 = fVar.f5987b;
        int length = spannableStringBuilder.length();
        String str2 = fVar.f5986a;
        str2.getClass();
        int i12 = -1;
        switch (str2.hashCode()) {
            case 0:
                if (str2.equals(StringUtils.EMPTY)) {
                    c6 = 0;
                    break;
                }
                c6 = 65535;
                break;
            case 98:
                if (str2.equals("b")) {
                    c6 = 1;
                    break;
                }
                c6 = 65535;
                break;
            case 99:
                if (str2.equals("c")) {
                    c6 = 2;
                    break;
                }
                c6 = 65535;
                break;
            case 105:
                if (str2.equals("i")) {
                    c6 = 3;
                    break;
                }
                c6 = 65535;
                break;
            case 117:
                if (str2.equals("u")) {
                    c6 = 4;
                    break;
                }
                c6 = 65535;
                break;
            case 118:
                if (str2.equals("v")) {
                    c6 = 5;
                    break;
                }
                c6 = 65535;
                break;
            case 3314158:
                if (str2.equals("lang")) {
                    c6 = 6;
                    break;
                }
                c6 = 65535;
                break;
            case 3511770:
                if (str2.equals("ruby")) {
                    c6 = 7;
                    break;
                }
                c6 = 65535;
                break;
            default:
                c6 = 65535;
                break;
        }
        switch (c6) {
            case 0:
            case 6:
                break;
            case 1:
                spannableStringBuilder.setSpan(new StyleSpan(1), i11, length, 33);
                break;
            case 2:
                for (String str3 : fVar.f5989d) {
                    Map map = f6003c;
                    if (map.containsKey(str3)) {
                        spannableStringBuilder.setSpan(new ForegroundColorSpan(((Integer) map.get(str3)).intValue()), i11, length, 33);
                    } else {
                        Map map2 = f6004d;
                        if (map2.containsKey(str3)) {
                            spannableStringBuilder.setSpan(new BackgroundColorSpan(((Integer) map2.get(str3)).intValue()), i11, length, 33);
                        }
                    }
                }
                break;
            case 3:
                spannableStringBuilder.setSpan(new StyleSpan(2), i11, length, 33);
                break;
            case 4:
                spannableStringBuilder.setSpan(new UnderlineSpan(), i11, length, 33);
                break;
            case 5:
                spannableStringBuilder.setSpan(new U.h(fVar.f5988c), i11, length, 33);
                break;
            case 7:
                int c9 = c(list2, str, fVar);
                ArrayList arrayList = new ArrayList(list.size());
                arrayList.addAll(list);
                Collections.sort(arrayList, e.f5983c);
                int i13 = fVar.f5987b;
                int i14 = 0;
                int i15 = 0;
                while (i14 < arrayList.size()) {
                    if ("rt".equals(((e) arrayList.get(i14)).f5984a.f5986a)) {
                        e eVar = (e) arrayList.get(i14);
                        int c10 = c(list2, str, eVar.f5984a);
                        if (c10 == i12) {
                            if (c9 != i12) {
                                c10 = c9;
                            } else {
                                c10 = 1;
                            }
                        }
                        int i16 = eVar.f5984a.f5987b - i15;
                        int i17 = eVar.f5985b - i15;
                        CharSequence subSequence = spannableStringBuilder.subSequence(i16, i17);
                        spannableStringBuilder.delete(i16, i17);
                        spannableStringBuilder.setSpan(new U.f(subSequence.toString(), c10), i13, i16, 33);
                        i15 = subSequence.length() + i15;
                        i13 = i16;
                    }
                    i14++;
                    i12 = -1;
                }
                break;
            default:
                return;
        }
        ArrayList b6 = b(list2, str, fVar);
        for (int i18 = 0; i18 < b6.size(); i18++) {
            c cVar = ((g) b6.get(i18)).f5990p;
            int i19 = cVar.f5975l;
            if (i19 == -1 && cVar.f5976m == -1) {
                i6 = -1;
            } else {
                if (i19 == 1) {
                    c7 = 1;
                } else {
                    c7 = 0;
                }
                if (cVar.f5976m == 1) {
                    c8 = 2;
                } else {
                    c8 = 0;
                }
                i6 = c8 | c7;
            }
            if (i6 != -1) {
                int i20 = cVar.f5975l;
                if (i20 == -1 && cVar.f5976m == -1) {
                    i10 = -1;
                    i7 = 1;
                } else {
                    i7 = 1;
                    if (i20 == 1) {
                        i8 = 1;
                    } else {
                        i8 = 0;
                    }
                    if (cVar.f5976m == 1) {
                        i9 = 2;
                    } else {
                        i9 = 0;
                    }
                    i10 = i8 | i9;
                }
                T5.h.a(spannableStringBuilder, new StyleSpan(i10), i11, length);
            } else {
                i7 = 1;
            }
            if (cVar.f5973j == i7) {
                spannableStringBuilder.setSpan(new StrikethroughSpan(), i11, length, 33);
            }
            if (cVar.f5974k == i7) {
                spannableStringBuilder.setSpan(new UnderlineSpan(), i11, length, 33);
            }
            if (cVar.f5970g) {
                if (cVar.f5970g) {
                    T5.h.a(spannableStringBuilder, new ForegroundColorSpan(cVar.f5969f), i11, length);
                } else {
                    throw new IllegalStateException("Font color not defined");
                }
            }
            if (cVar.f5972i) {
                if (cVar.f5972i) {
                    T5.h.a(spannableStringBuilder, new BackgroundColorSpan(cVar.f5971h), i11, length);
                } else {
                    throw new IllegalStateException("Background color not defined.");
                }
            }
            if (cVar.e != null) {
                T5.h.a(spannableStringBuilder, new TypefaceSpan(cVar.e), i11, length);
            }
            int i21 = cVar.f5977n;
            if (i21 != 1) {
                if (i21 != 2) {
                    if (i21 == 3) {
                        T5.h.a(spannableStringBuilder, new RelativeSizeSpan(cVar.o / 100.0f), i11, length);
                    }
                } else {
                    T5.h.a(spannableStringBuilder, new RelativeSizeSpan(cVar.o), i11, length);
                }
            } else {
                T5.h.a(spannableStringBuilder, new AbsoluteSizeSpan((int) cVar.o, true), i11, length);
            }
            if (cVar.f5979q) {
                spannableStringBuilder.setSpan(new Object(), i11, length, 33);
            }
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    public static ArrayList b(List list, String str, f fVar) {
        int i6;
        ArrayList arrayList = new ArrayList();
        for (int i7 = 0; i7 < list.size(); i7++) {
            c cVar = (c) list.get(i7);
            String str2 = fVar.f5986a;
            Set set = fVar.f5989d;
            String str3 = fVar.f5988c;
            if (cVar.f5965a.isEmpty() && cVar.f5966b.isEmpty() && cVar.f5967c.isEmpty() && cVar.f5968d.isEmpty()) {
                i6 = TextUtils.isEmpty(str2);
            } else {
                int a6 = c.a(c.a(c.a(0, 1073741824, cVar.f5965a, str), 2, cVar.f5966b, str2), 4, cVar.f5968d, str3);
                if (a6 != -1 && set.containsAll(cVar.f5967c)) {
                    i6 = a6 + (cVar.f5967c.size() * 4);
                } else {
                    i6 = 0;
                }
            }
            if (i6 > 0) {
                arrayList.add(new g(i6, cVar));
            }
        }
        Collections.sort(arrayList);
        return arrayList;
    }

    public static int c(List list, String str, f fVar) {
        ArrayList b6 = b(list, str, fVar);
        for (int i6 = 0; i6 < b6.size(); i6++) {
            int i7 = ((g) b6.get(i6)).f5990p.f5978p;
            if (i7 != -1) {
                return i7;
            }
        }
        return -1;
    }

    public static d d(String str, Matcher matcher, v vVar, ArrayList arrayList) {
        h hVar = new h();
        try {
            String group = matcher.group(1);
            group.getClass();
            hVar.f5991a = j.c(group);
            String group2 = matcher.group(2);
            group2.getClass();
            hVar.f5992b = j.c(group2);
            String group3 = matcher.group(3);
            group3.getClass();
            e(group3, hVar);
            StringBuilder sb = new StringBuilder();
            vVar.getClass();
            String l6 = vVar.l(StandardCharsets.UTF_8);
            while (!TextUtils.isEmpty(l6)) {
                if (sb.length() > 0) {
                    sb.append("\n");
                }
                sb.append(l6.trim());
                l6 = vVar.l(StandardCharsets.UTF_8);
            }
            hVar.f5993c = f(str, arrayList, sb.toString());
            return new d(hVar.a().a(), hVar.f5991a, hVar.f5992b);
        } catch (IllegalArgumentException unused) {
            AbstractC0133a.A("WebvttCueParser", "Skipping cue with bad header: " + matcher.group());
            return null;
        }
    }

    /* JADX WARN: Code restructure failed: missing block: B:101:0x0081, code lost:
    
        if (r6.equals("center") == false) goto L14;
     */
    /* JADX WARN: Code restructure failed: missing block: B:54:0x00c5, code lost:
    
        if (r7.equals("start") == false) goto L53;
     */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public static void e(String str, h hVar) {
        int i6;
        int i7;
        int i8;
        Matcher matcher = f6002b.matcher(str);
        while (matcher.find()) {
            String group = matcher.group(1);
            group.getClass();
            String group2 = matcher.group(2);
            group2.getClass();
            try {
                if ("line".equals(group)) {
                    g(group2, hVar);
                } else {
                    char c6 = 5;
                    boolean z6 = false;
                    if ("align".equals(group)) {
                        switch (group2.hashCode()) {
                            case -1364013995:
                                break;
                            case -1074341483:
                                if (group2.equals("middle")) {
                                    z6 = true;
                                    break;
                                }
                                break;
                            case 100571:
                                if (group2.equals("end")) {
                                    z6 = 2;
                                    break;
                                }
                                break;
                            case 3317767:
                                if (group2.equals("left")) {
                                    z6 = 3;
                                    break;
                                }
                                break;
                            case 108511772:
                                if (group2.equals("right")) {
                                    z6 = 4;
                                    break;
                                }
                                break;
                            case 109757538:
                                if (group2.equals("start")) {
                                    z6 = 5;
                                    break;
                                }
                                break;
                        }
                        z6 = -1;
                        switch (z6) {
                            case false:
                            case true:
                                break;
                            case true:
                                i6 = 3;
                                break;
                            case true:
                                i6 = 4;
                                break;
                            case true:
                                i6 = 5;
                                break;
                            case true:
                                i6 = 1;
                                break;
                            default:
                                AbstractC0133a.A("WebvttCueParser", "Invalid alignment value: ".concat(group2));
                                break;
                        }
                        i6 = 2;
                        hVar.f5994d = i6;
                    } else if ("position".equals(group)) {
                        int indexOf = group2.indexOf(44);
                        if (indexOf != -1) {
                            String substring = group2.substring(indexOf + 1);
                            substring.getClass();
                            switch (substring.hashCode()) {
                                case -1842484672:
                                    if (substring.equals("line-left")) {
                                        c6 = 0;
                                        break;
                                    }
                                    break;
                                case -1364013995:
                                    if (substring.equals("center")) {
                                        c6 = 1;
                                        break;
                                    }
                                    break;
                                case -1276788989:
                                    if (substring.equals("line-right")) {
                                        c6 = 2;
                                        break;
                                    }
                                    break;
                                case -1074341483:
                                    if (substring.equals("middle")) {
                                        c6 = 3;
                                        break;
                                    }
                                    break;
                                case 100571:
                                    if (substring.equals("end")) {
                                        c6 = 4;
                                        break;
                                    }
                                    break;
                                case 109757538:
                                    break;
                            }
                            c6 = 65535;
                            switch (c6) {
                                case 0:
                                case 5:
                                    i7 = 0;
                                    break;
                                case 1:
                                case 3:
                                    i7 = 1;
                                    break;
                                case 2:
                                case 4:
                                    i7 = 2;
                                    break;
                                default:
                                    AbstractC0133a.A("WebvttCueParser", "Invalid anchor value: ".concat(substring));
                                    i7 = Integer.MIN_VALUE;
                                    break;
                            }
                            hVar.f5998i = i7;
                            group2 = group2.substring(0, indexOf);
                        }
                        hVar.f5997h = j.b(group2);
                    } else if ("size".equals(group)) {
                        hVar.f5999j = j.b(group2);
                    } else if ("vertical".equals(group)) {
                        if (!group2.equals("lr")) {
                            if (!group2.equals("rl")) {
                                AbstractC0133a.A("WebvttCueParser", "Invalid 'vertical' value: ".concat(group2));
                                i8 = Integer.MIN_VALUE;
                            } else {
                                i8 = 1;
                            }
                        } else {
                            i8 = 2;
                        }
                        hVar.f6000k = i8;
                    } else {
                        AbstractC0133a.A("WebvttCueParser", "Unknown cue setting " + group + TikaCoreProperties.NAMESPACE_PREFIX_DELIMITER + group2);
                    }
                }
            } catch (NumberFormatException unused) {
                AbstractC0133a.A("WebvttCueParser", "Skipping bad cue setting: " + matcher.group());
            }
        }
    }

    /* JADX WARN: Can't fix incorrect switch cases order, some code will duplicate */
    /* JADX WARN: Code restructure failed: missing block: B:30:0x01de, code lost:
    
        switch(r10) {
            case 0: goto L123;
            case 1: goto L122;
            case 2: goto L121;
            case 3: goto L120;
            default: goto L119;
        };
     */
    /* JADX WARN: Code restructure failed: missing block: B:31:0x01e1, code lost:
    
        V.AbstractC0133a.A("WebvttCueParser", "ignoring unsupported entity: '&" + r7 + ";'");
     */
    /* JADX WARN: Code restructure failed: missing block: B:32:0x0209, code lost:
    
        if (r6 != r15) goto L126;
     */
    /* JADX WARN: Code restructure failed: missing block: B:33:0x020b, code lost:
    
        r3.append((java.lang.CharSequence) org.apache.tika.utils.StringUtils.SPACE);
     */
    /* JADX WARN: Code restructure failed: missing block: B:34:0x020e, code lost:
    
        r7 = r6 + 1;
     */
    /* JADX WARN: Code restructure failed: missing block: B:36:0x01fa, code lost:
    
        r3.append(' ');
     */
    /* JADX WARN: Code restructure failed: missing block: B:37:0x01fe, code lost:
    
        r3.append('&');
     */
    /* JADX WARN: Code restructure failed: missing block: B:38:0x0202, code lost:
    
        r3.append('<');
     */
    /* JADX WARN: Code restructure failed: missing block: B:39:0x0206, code lost:
    
        r3.append('>');
     */
    /* JADX WARN: Failed to find 'out' block for switch in B:64:0x00a4. Please report as an issue. */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public static SpannedString f(String str, List list, String str2) {
        boolean z6;
        boolean z7;
        int i6;
        char c6;
        char c7;
        SpannableStringBuilder spannableStringBuilder = new SpannableStringBuilder();
        ArrayDeque arrayDeque = new ArrayDeque();
        ArrayList arrayList = new ArrayList();
        int i7 = 0;
        while (true) {
            int length = str2.length();
            String str3 = StringUtils.EMPTY;
            if (i7 < length) {
                char charAt = str2.charAt(i7);
                char c8 = 65535;
                if (charAt != '&') {
                    if (charAt != '<') {
                        spannableStringBuilder.append(charAt);
                        i7++;
                    } else {
                        int i8 = i7 + 1;
                        if (i8 < str2.length()) {
                            if (str2.charAt(i8) == '/') {
                                z6 = true;
                            } else {
                                z6 = false;
                            }
                            int indexOf = str2.indexOf(62, i8);
                            if (indexOf == -1) {
                                i8 = str2.length();
                            } else {
                                i8 = indexOf + 1;
                            }
                            int i9 = i8 - 2;
                            if (str2.charAt(i9) == '/') {
                                z7 = true;
                            } else {
                                z7 = false;
                            }
                            if (z6) {
                                i6 = 2;
                            } else {
                                i6 = 1;
                            }
                            int i10 = i7 + i6;
                            if (!z7) {
                                i9 = i8 - 1;
                            }
                            String substring = str2.substring(i10, i9);
                            if (!substring.trim().isEmpty()) {
                                String trim = substring.trim();
                                AbstractC0133a.c(!trim.isEmpty());
                                String str4 = C.f3053a;
                                String str5 = trim.split("[ \\.]", 2)[0];
                                str5.getClass();
                                switch (str5.hashCode()) {
                                    case 98:
                                        if (str5.equals("b")) {
                                            c6 = 0;
                                            break;
                                        }
                                        c6 = 65535;
                                        break;
                                    case 99:
                                        if (str5.equals("c")) {
                                            c6 = 1;
                                            break;
                                        }
                                        c6 = 65535;
                                        break;
                                    case 105:
                                        if (str5.equals("i")) {
                                            c6 = 2;
                                            break;
                                        }
                                        c6 = 65535;
                                        break;
                                    case 117:
                                        if (str5.equals("u")) {
                                            c6 = 3;
                                            break;
                                        }
                                        c6 = 65535;
                                        break;
                                    case 118:
                                        if (str5.equals("v")) {
                                            c6 = 4;
                                            break;
                                        }
                                        c6 = 65535;
                                        break;
                                    case 3650:
                                        if (str5.equals("rt")) {
                                            c6 = 5;
                                            break;
                                        }
                                        c6 = 65535;
                                        break;
                                    case 3314158:
                                        if (str5.equals("lang")) {
                                            c6 = 6;
                                            break;
                                        }
                                        c6 = 65535;
                                        break;
                                    case 3511770:
                                        if (str5.equals("ruby")) {
                                            c6 = 7;
                                            break;
                                        }
                                        c6 = 65535;
                                        break;
                                    default:
                                        c6 = 65535;
                                        break;
                                }
                                switch (c6) {
                                    case 0:
                                    case 1:
                                    case 2:
                                    case 3:
                                    case 4:
                                    case 5:
                                    case 6:
                                    case 7:
                                        if (!z6) {
                                            if (!z7) {
                                                int length2 = spannableStringBuilder.length();
                                                String trim2 = substring.trim();
                                                AbstractC0133a.c(!trim2.isEmpty());
                                                int indexOf2 = trim2.indexOf(StringUtils.SPACE);
                                                if (indexOf2 == -1) {
                                                    c7 = 0;
                                                } else {
                                                    str3 = trim2.substring(indexOf2).trim();
                                                    c7 = 0;
                                                    trim2 = trim2.substring(0, indexOf2);
                                                }
                                                String[] split = trim2.split("\\.", -1);
                                                String str6 = split[c7];
                                                HashSet hashSet = new HashSet();
                                                for (int i11 = 1; i11 < split.length; i11++) {
                                                    hashSet.add(split[i11]);
                                                }
                                                arrayDeque.push(new f(str6, length2, str3, hashSet));
                                            }
                                        }
                                        while (!arrayDeque.isEmpty()) {
                                            f fVar = (f) arrayDeque.pop();
                                            a(str, fVar, arrayList, spannableStringBuilder, list);
                                            if (!arrayDeque.isEmpty()) {
                                                arrayList.add(new e(fVar, spannableStringBuilder.length()));
                                            } else {
                                                arrayList.clear();
                                            }
                                            if (fVar.f5986a.equals(str5)) {
                                            }
                                        }
                                    default:
                                        i7 = i8;
                                        break;
                                }
                            }
                        }
                        i7 = i8;
                    }
                } else {
                    i7++;
                    int indexOf3 = str2.indexOf(59, i7);
                    int indexOf4 = str2.indexOf(32, i7);
                    if (indexOf3 == -1) {
                        indexOf3 = indexOf4;
                    } else if (indexOf4 != -1) {
                        indexOf3 = Math.min(indexOf3, indexOf4);
                    }
                    if (indexOf3 != -1) {
                        String substring2 = str2.substring(i7, indexOf3);
                        substring2.getClass();
                        switch (substring2.hashCode()) {
                            case 3309:
                                if (substring2.equals("gt")) {
                                    c8 = 0;
                                    break;
                                }
                                break;
                            case 3464:
                                if (substring2.equals("lt")) {
                                    c8 = 1;
                                    break;
                                }
                                break;
                            case 96708:
                                if (substring2.equals("amp")) {
                                    c8 = 2;
                                    break;
                                }
                                break;
                            case 3374865:
                                if (substring2.equals("nbsp")) {
                                    c8 = 3;
                                    break;
                                }
                                break;
                        }
                    } else {
                        spannableStringBuilder.append(charAt);
                    }
                }
            } else {
                while (!arrayDeque.isEmpty()) {
                    a(str, (f) arrayDeque.pop(), arrayList, spannableStringBuilder, list);
                }
                a(str, new f(StringUtils.EMPTY, 0, StringUtils.EMPTY, Collections.EMPTY_SET), Collections.EMPTY_LIST, spannableStringBuilder, list);
                return SpannedString.valueOf(spannableStringBuilder);
            }
        }
    }

    public static void g(String str, h hVar) {
        int indexOf = str.indexOf(44);
        char c6 = 65535;
        if (indexOf != -1) {
            String substring = str.substring(indexOf + 1);
            substring.getClass();
            int i6 = 2;
            switch (substring.hashCode()) {
                case -1364013995:
                    if (substring.equals("center")) {
                        c6 = 0;
                        break;
                    }
                    break;
                case -1074341483:
                    if (substring.equals("middle")) {
                        c6 = 1;
                        break;
                    }
                    break;
                case 100571:
                    if (substring.equals("end")) {
                        c6 = 2;
                        break;
                    }
                    break;
                case 109757538:
                    if (substring.equals("start")) {
                        c6 = 3;
                        break;
                    }
                    break;
            }
            switch (c6) {
                case 0:
                case 1:
                    i6 = 1;
                    break;
                case 2:
                    break;
                case 3:
                    i6 = 0;
                    break;
                default:
                    AbstractC0133a.A("WebvttCueParser", "Invalid anchor value: ".concat(substring));
                    i6 = Integer.MIN_VALUE;
                    break;
            }
            hVar.f5996g = i6;
            str = str.substring(0, indexOf);
        }
        if (str.endsWith("%")) {
            hVar.e = j.b(str);
            hVar.f5995f = 0;
        } else {
            hVar.e = Integer.parseInt(str);
            hVar.f5995f = 1;
        }
    }
}
