package d1;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* loaded from: classes.dex */
public final class g implements Comparable {
    public final int o;

    /* renamed from: p, reason: collision with root package name */
    public final c f5990p;

    public g(int i6, c cVar) {
        this.o = i6;
        this.f5990p = cVar;
    }

    @Override // java.lang.Comparable
    public final int compareTo(Object obj) {
        return Integer.compare(this.o, ((g) obj).o);
    }
}
