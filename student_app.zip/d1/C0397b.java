package d1;

import V.v;
import java.util.regex.Pattern;
import org.apache.tika.utils.StringUtils;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* renamed from: d1.b, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0397b {

    /* renamed from: c, reason: collision with root package name */
    public static final Pattern f5961c = Pattern.compile("\\[voice=\"([^\"]*)\"\\]");

    /* renamed from: d, reason: collision with root package name */
    public static final Pattern f5962d = Pattern.compile("^((?:[0-9]*\\.)?[0-9]+)(px|em|%)$");

    /* renamed from: a, reason: collision with root package name */
    public final v f5963a = new v();

    /* renamed from: b, reason: collision with root package name */
    public final StringBuilder f5964b = new StringBuilder();

    public static String a(v vVar, StringBuilder sb) {
        boolean z6 = false;
        sb.setLength(0);
        int i6 = vVar.f3121b;
        int i7 = vVar.f3122c;
        while (i6 < i7 && !z6) {
            char c6 = (char) vVar.f3120a[i6];
            if ((c6 < 'A' || c6 > 'Z') && ((c6 < 'a' || c6 > 'z') && ((c6 < '0' || c6 > '9') && c6 != '#' && c6 != '-' && c6 != '.' && c6 != '_'))) {
                z6 = true;
            } else {
                i6++;
                sb.append(c6);
            }
        }
        vVar.K(i6 - vVar.f3121b);
        return sb.toString();
    }

    public static String b(v vVar, StringBuilder sb) {
        c(vVar);
        if (vVar.a() == 0) {
            return null;
        }
        String a6 = a(vVar, sb);
        if (!a6.isEmpty()) {
            return a6;
        }
        return StringUtils.EMPTY + ((char) vVar.x());
    }

    public static void c(v vVar) {
        while (true) {
            for (boolean z6 = true; vVar.a() > 0 && z6; z6 = false) {
                int i6 = vVar.f3121b;
                byte[] bArr = vVar.f3120a;
                byte b6 = bArr[i6];
                char c6 = (char) b6;
                if (c6 != '\t' && c6 != '\n' && c6 != '\f' && c6 != '\r' && c6 != ' ') {
                    int i7 = vVar.f3122c;
                    int i8 = i6 + 2;
                    if (i8 <= i7) {
                        int i9 = i6 + 1;
                        if (b6 == 47 && bArr[i9] == 42) {
                            while (true) {
                                int i10 = i8 + 1;
                                if (i10 >= i7) {
                                    break;
                                }
                                if (((char) bArr[i8]) == '*' && ((char) bArr[i10]) == '/') {
                                    i8 += 2;
                                    i7 = i8;
                                } else {
                                    i8 = i10;
                                }
                            }
                            vVar.K(i7 - vVar.f3121b);
                        }
                    }
                } else {
                    vVar.K(1);
                }
            }
            return;
        }
    }
}
