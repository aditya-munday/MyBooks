package a4;

import android.media.MediaCodec;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* renamed from: a4.a, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0208a {

    /* renamed from: a, reason: collision with root package name */
    public final MediaCodec f4457a;

    public C0208a(MediaCodec mediaCodec) {
        this.f4457a = mediaCodec;
    }
}
