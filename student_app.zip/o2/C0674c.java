package o2;

import Q2.n;
import android.content.Context;
import android.os.Bundle;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Looper;
import j2.C0504c;
import l2.m;
import m2.AbstractC0654e;
import m2.k;
import u2.AbstractC0815a;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* renamed from: o2.c, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0674c extends AbstractC0654e {

    /* renamed from: M, reason: collision with root package name */
    public final k f8850M;

    public C0674c(Context context, Looper looper, n nVar, k kVar, m mVar, m mVar2) {
        super(context, looper, 270, nVar, mVar, mVar2, 0);
        this.f8850M = kVar;
    }

    @Override // k2.InterfaceC0550c
    public final int d() {
        return 203400000;
    }

    @Override // m2.AbstractC0654e
    public final IInterface n(IBinder iBinder) {
        if (iBinder == null) {
            return null;
        }
        IInterface queryLocalInterface = iBinder.queryLocalInterface("com.google.android.gms.common.internal.service.IClientTelemetryService");
        if (queryLocalInterface instanceof C0672a) {
            return (C0672a) queryLocalInterface;
        }
        return new AbstractC0815a(iBinder, "com.google.android.gms.common.internal.service.IClientTelemetryService");
    }

    @Override // m2.AbstractC0654e
    public final C0504c[] o() {
        return u2.c.f9771b;
    }

    @Override // m2.AbstractC0654e
    public final Bundle p() {
        this.f8850M.getClass();
        return new Bundle();
    }

    @Override // m2.AbstractC0654e
    public final String r() {
        return "com.google.android.gms.common.internal.service.IClientTelemetryService";
    }

    @Override // m2.AbstractC0654e
    public final String s() {
        return "com.google.android.gms.common.telemetry.service.START";
    }

    @Override // m2.AbstractC0654e
    public final boolean t() {
        return true;
    }
}
