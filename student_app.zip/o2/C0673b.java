package o2;

import C2.r;
import Z.C0179k;
import Z4.s;
import c5.C0351o;
import f3.C0441c;
import f3.h;
import j2.C0504c;
import k2.AbstractC0553f;
import m2.j;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* renamed from: o2.b, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0673b extends AbstractC0553f {

    /* renamed from: i, reason: collision with root package name */
    public static final C0179k f8849i = new C0179k("ClientTelemetry.API", new C0441c(1), (C0351o) new Object());

    /* JADX WARN: Type inference failed for: r0v0, types: [Z4.s, java.lang.Object] */
    public final r c(j jVar) {
        ?? obj = new Object();
        C0504c[] c0504cArr = {u2.c.f9770a};
        obj.o = new s(jVar);
        return b(2, new h(obj, c0504cArr, false));
    }
}
