package x2;

import java.io.Closeable;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* renamed from: x2.a, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0891a implements Closeable {
    public static final C0891a o = new Object();

    @Override // java.io.Closeable, java.lang.AutoCloseable
    public final void close() {
    }
}
