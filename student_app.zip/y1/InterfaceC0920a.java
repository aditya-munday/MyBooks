package y1;

import C4.o;
import android.content.Context;
import i1.ExecutorC0474b;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* renamed from: y1.a, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public interface InterfaceC0920a {
    void a(o oVar);

    void b(Context context, ExecutorC0474b executorC0474b, o oVar);
}
