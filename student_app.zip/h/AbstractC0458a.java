package h;

import android.content.Context;
import android.graphics.drawable.Drawable;
import java.util.WeakHashMap;
import l.N;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* renamed from: h.a, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public abstract class AbstractC0458a {

    /* renamed from: a, reason: collision with root package name */
    public static final Object f6801a = null;

    static {
        new ThreadLocal();
        new WeakHashMap(0);
    }

    public static Drawable a(Context context, int i6) {
        return N.b().c(context, i6);
    }
}
