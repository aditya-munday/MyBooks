package S1;

import androidx.datastore.preferences.protobuf.AbstractC0227o;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* loaded from: classes.dex */
public final class c {

    /* renamed from: a, reason: collision with root package name */
    public final String f2709a;

    public c(String str) {
        if (str != null) {
            this.f2709a = str;
            return;
        }
        throw new NullPointerException("name is null");
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof c)) {
            return false;
        }
        return this.f2709a.equals(((c) obj).f2709a);
    }

    public final int hashCode() {
        return this.f2709a.hashCode() ^ 1000003;
    }

    public final String toString() {
        return AbstractC0227o.h(new StringBuilder("Encoding{name=\""), this.f2709a, "\"}");
    }
}
