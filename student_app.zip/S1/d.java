package S1;

/* JADX WARN: Failed to restore enum class, 'enum' modifier and super class removed */
/* JADX WARN: Unknown enum class pattern. Please report as an issue! */
/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* loaded from: classes.dex */
public final class d {
    public static final d o;

    /* renamed from: p, reason: collision with root package name */
    public static final d f2710p;

    /* renamed from: q, reason: collision with root package name */
    public static final d f2711q;

    /* renamed from: r, reason: collision with root package name */
    public static final /* synthetic */ d[] f2712r;

    /* JADX WARN: Type inference failed for: r0v0, types: [S1.d, java.lang.Enum] */
    /* JADX WARN: Type inference failed for: r1v1, types: [S1.d, java.lang.Enum] */
    /* JADX WARN: Type inference failed for: r2v2, types: [S1.d, java.lang.Enum] */
    static {
        ?? r02 = new Enum("DEFAULT", 0);
        o = r02;
        ?? r12 = new Enum("VERY_LOW", 1);
        f2710p = r12;
        ?? r22 = new Enum("HIGHEST", 2);
        f2711q = r22;
        f2712r = new d[]{r02, r12, r22};
    }

    public static d valueOf(String str) {
        return (d) Enum.valueOf(d.class, str);
    }

    public static d[] values() {
        return (d[]) f2712r.clone();
    }
}
