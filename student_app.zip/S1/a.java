package S1;

import w3.C0871e;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* loaded from: classes.dex */
public final class a {

    /* renamed from: a, reason: collision with root package name */
    public final C0871e f2706a;

    /* renamed from: b, reason: collision with root package name */
    public final b f2707b;

    public a(C0871e c0871e, b bVar) {
        this.f2706a = c0871e;
        this.f2707b = bVar;
    }

    public final boolean equals(Object obj) {
        if (obj != this) {
            if (obj instanceof a) {
                a aVar = (a) obj;
                b bVar = aVar.f2707b;
                if (this.f2706a.equals(aVar.f2706a)) {
                    Object obj2 = d.o;
                    if (obj2.equals(obj2) && this.f2707b.equals(bVar)) {
                        return true;
                    }
                    return false;
                }
                return false;
            }
            return false;
        }
        return true;
    }

    public final int hashCode() {
        return this.f2707b.hashCode() ^ (((((1000003 * 1000003) ^ this.f2706a.hashCode()) * 1000003) ^ d.o.hashCode()) * 1000003);
    }

    public final String toString() {
        return "Event{code=null, payload=" + this.f2706a + ", priority=" + d.o + ", productData=" + this.f2707b + "}";
    }
}
