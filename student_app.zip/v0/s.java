package v0;

import S.C0123p;
import android.media.MediaFormat;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* loaded from: classes.dex */
public interface s {
    void a(long j6, long j7, C0123p c0123p, MediaFormat mediaFormat);
}
