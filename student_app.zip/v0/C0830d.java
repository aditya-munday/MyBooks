package v0;

import java.util.Arrays;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* renamed from: v0.d, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0830d {

    /* renamed from: a, reason: collision with root package name */
    public long f9798a;

    /* renamed from: b, reason: collision with root package name */
    public long f9799b;

    /* renamed from: c, reason: collision with root package name */
    public long f9800c;

    /* renamed from: d, reason: collision with root package name */
    public long f9801d;
    public long e;

    /* renamed from: f, reason: collision with root package name */
    public long f9802f;

    /* renamed from: g, reason: collision with root package name */
    public final boolean[] f9803g = new boolean[15];

    /* renamed from: h, reason: collision with root package name */
    public int f9804h;

    public final boolean a() {
        if (this.f9801d > 15 && this.f9804h == 0) {
            return true;
        }
        return false;
    }

    public final void b(long j6) {
        long j7 = this.f9801d;
        if (j7 == 0) {
            this.f9798a = j6;
        } else if (j7 == 1) {
            long j8 = j6 - this.f9798a;
            this.f9799b = j8;
            this.f9802f = j8;
            this.e = 1L;
        } else {
            long j9 = j6 - this.f9800c;
            int i6 = (int) (j7 % 15);
            long abs = Math.abs(j9 - this.f9799b);
            boolean[] zArr = this.f9803g;
            if (abs <= 1000000) {
                this.e++;
                this.f9802f += j9;
                if (zArr[i6]) {
                    zArr[i6] = false;
                    this.f9804h--;
                }
            } else if (!zArr[i6]) {
                zArr[i6] = true;
                this.f9804h++;
            }
        }
        this.f9801d++;
        this.f9800c = j6;
    }

    public final void c() {
        this.f9801d = 0L;
        this.e = 0L;
        this.f9802f = 0L;
        this.f9804h = 0;
        Arrays.fill(this.f9803g, false);
    }
}
