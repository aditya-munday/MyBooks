package v0;

import S.c0;
import Z.G;
import android.os.Handler;
import android.os.SystemClock;
import android.view.Surface;
import b0.C0256h;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* renamed from: v0.g, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0833g implements InterfaceC0824B {

    /* renamed from: b, reason: collision with root package name */
    public final /* synthetic */ k f9809b;

    public C0833g(k kVar) {
        this.f9809b = kVar;
    }

    @Override // v0.InterfaceC0824B
    public final void b() {
        k kVar = this.f9809b;
        Surface surface = kVar.f9844j1;
        if (surface != null) {
            C0256h c0256h = kVar.f9831V0;
            Handler handler = c0256h.f5195a;
            if (handler != null) {
                handler.post(new z(c0256h, surface, SystemClock.elapsedRealtime()));
            }
            kVar.f9847m1 = true;
        }
    }

    @Override // v0.InterfaceC0824B
    public final void c() {
        k kVar = this.f9809b;
        if (kVar.f9844j1 != null) {
            kVar.N0(0, 1);
        }
    }

    @Override // v0.InterfaceC0824B
    public final void d() {
        G g2 = this.f9809b.f6952U;
        if (g2 != null) {
            g2.a();
        }
    }

    @Override // v0.InterfaceC0824B
    public final void a(c0 c0Var) {
    }
}
