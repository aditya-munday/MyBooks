package v0;

import V.AbstractC0133a;
import android.content.Context;
import android.graphics.SurfaceTexture;
import android.os.Build;
import android.view.Surface;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* loaded from: classes.dex */
public final class m extends Surface {

    /* renamed from: r, reason: collision with root package name */
    public static int f9863r;

    /* renamed from: s, reason: collision with root package name */
    public static boolean f9864s;
    public final boolean o;

    /* renamed from: p, reason: collision with root package name */
    public final l f9865p;

    /* renamed from: q, reason: collision with root package name */
    public boolean f9866q;

    public m(l lVar, SurfaceTexture surfaceTexture, boolean z6) {
        super(surfaceTexture);
        this.f9865p = lVar;
        this.o = z6;
    }

    /* JADX WARN: Removed duplicated region for block: B:11:0x0034 A[Catch: i -> 0x0040, TRY_LEAVE, TryCatch #0 {i -> 0x0040, blocks: (B:3:0x0001, B:5:0x0007, B:7:0x0011, B:11:0x0034, B:19:0x001f, B:22:0x002c), top: B:2:0x0001 }] */
    /* JADX WARN: Removed duplicated region for block: B:17:0x0042 A[RETURN] */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public static int a(Context context) {
        boolean t6;
        try {
            int i6 = Build.VERSION.SDK_INT;
            if ((i6 >= 26 || (!"samsung".equals(Build.MANUFACTURER) && !"XT1650".equals(Build.MODEL))) && (i6 >= 26 || context.getPackageManager().hasSystemFeature("android.hardware.vr.high_performance"))) {
                t6 = AbstractC0133a.t("EGL_EXT_protected_content");
                if (t6) {
                    return 0;
                }
                if (AbstractC0133a.t("EGL_KHR_surfaceless_context")) {
                    return 1;
                }
                return 2;
            }
            t6 = false;
            if (t6) {
            }
        } catch (V.i e) {
            AbstractC0133a.m("PlaceholderSurface", "Failed to determine secure mode due to GL error: " + e.getMessage());
            return 0;
        }
    }

    public static synchronized boolean b(Context context) {
        boolean z6;
        synchronized (m.class) {
            try {
                z6 = true;
                if (!f9864s) {
                    f9863r = a(context);
                    f9864s = true;
                }
                if (f9863r == 0) {
                    z6 = false;
                }
            } catch (Throwable th) {
                throw th;
            }
        }
        return z6;
    }

    @Override // android.view.Surface
    public final void release() {
        super.release();
        synchronized (this.f9865p) {
            try {
                if (!this.f9866q) {
                    l lVar = this.f9865p;
                    lVar.f9859p.getClass();
                    lVar.f9859p.sendEmptyMessage(2);
                    this.f9866q = true;
                }
            } catch (Throwable th) {
                throw th;
            }
        }
    }
}
