package v0;

import S.a0;
import java.io.Serializable;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* loaded from: classes.dex */
public final class o implements a0 {
    static {
        boolean z6 = new D2.l(3) instanceof Serializable;
    }
}
