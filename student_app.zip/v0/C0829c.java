package v0;

import S.C0122o;
import S.C0123p;
import S.c0;
import V.AbstractC0133a;
import Z.C0181m;
import android.view.Surface;
import i1.ExecutorC0474b;
import java.util.ArrayDeque;
import java.util.List;
import java.util.concurrent.Executor;
import p3.C0711b;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* renamed from: v0.c, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0829c implements InterfaceC0826D {

    /* renamed from: a, reason: collision with root package name */
    public final t f9790a;

    /* renamed from: b, reason: collision with root package name */
    public final x f9791b;

    /* renamed from: c, reason: collision with root package name */
    public final ArrayDeque f9792c;

    /* renamed from: d, reason: collision with root package name */
    public Surface f9793d;
    public C0123p e;

    /* renamed from: f, reason: collision with root package name */
    public long f9794f;

    /* renamed from: g, reason: collision with root package name */
    public InterfaceC0824B f9795g;

    /* renamed from: h, reason: collision with root package name */
    public Executor f9796h;

    /* renamed from: i, reason: collision with root package name */
    public s f9797i;

    /* JADX WARN: Type inference failed for: r2v6, types: [v0.s, java.lang.Object] */
    public C0829c(t tVar, V.x xVar) {
        this.f9790a = tVar;
        tVar.f9897l = xVar;
        this.f9791b = new x(new C0711b(this), tVar);
        this.f9792c = new ArrayDeque();
        this.e = new C0123p(new C0122o());
        this.f9794f = -9223372036854775807L;
        this.f9795g = InterfaceC0824B.f9788a;
        this.f9796h = new ExecutorC0474b(1);
        this.f9797i = new Object();
    }

    @Override // v0.InterfaceC0826D
    public final void a() {
        this.f9793d = null;
        this.f9790a.h(null);
    }

    @Override // v0.InterfaceC0826D
    public final boolean b() {
        x xVar = this.f9791b;
        long j6 = xVar.f9930i;
        if (j6 != -9223372036854775807L && xVar.f9929h == j6) {
            return true;
        }
        return false;
    }

    @Override // v0.InterfaceC0826D
    public final Surface c() {
        Surface surface = this.f9793d;
        AbstractC0133a.j(surface);
        return surface;
    }

    @Override // v0.InterfaceC0826D
    public final boolean d() {
        return true;
    }

    @Override // v0.InterfaceC0826D
    public final void e(boolean z6) {
        boolean z7;
        if (z6) {
            t tVar = this.f9790a;
            w wVar = tVar.f9888b;
            wVar.f9919m = 0L;
            wVar.f9921p = -1L;
            wVar.f9920n = -1L;
            tVar.f9893h = -9223372036854775807L;
            tVar.f9891f = -9223372036854775807L;
            tVar.e = Math.min(tVar.e, 1);
            tVar.f9894i = -9223372036854775807L;
        }
        x xVar = this.f9791b;
        R0.e eVar = xVar.f9926d;
        R0.g gVar = xVar.f9927f;
        boolean z8 = false;
        gVar.f2147a = 0;
        gVar.f2148b = -1;
        gVar.f2149c = 0;
        xVar.f9928g = -9223372036854775807L;
        xVar.f9929h = -9223372036854775807L;
        xVar.f9930i = -9223372036854775807L;
        R0.e eVar2 = xVar.e;
        if (eVar2.f() > 0) {
            if (eVar2.f() > 0) {
                z7 = true;
            } else {
                z7 = false;
            }
            AbstractC0133a.c(z7);
            while (eVar2.f() > 1) {
                eVar2.c();
            }
            Object c6 = eVar2.c();
            c6.getClass();
            xVar.f9932k = ((Long) c6).longValue();
        }
        if (eVar.f() > 0) {
            if (eVar.f() > 0) {
                z8 = true;
            }
            AbstractC0133a.c(z8);
            while (eVar.f() > 1) {
                eVar.c();
            }
            Object c7 = eVar.c();
            c7.getClass();
            eVar.a(0L, (c0) c7);
        }
        this.f9792c.clear();
    }

    @Override // v0.InterfaceC0826D
    public final void f(Surface surface, V.w wVar) {
        this.f9793d = surface;
        this.f9790a.h(surface);
    }

    @Override // v0.InterfaceC0826D
    public final boolean g(C0123p c0123p) {
        return true;
    }

    @Override // v0.InterfaceC0826D
    public final void h(List list) {
        throw new UnsupportedOperationException();
    }

    @Override // v0.InterfaceC0826D
    public final void i() {
        this.f9790a.e();
    }

    @Override // v0.InterfaceC0826D
    public final void j(long j6, long j7) {
        try {
            this.f9791b.a(j6, j7);
        } catch (C0181m e) {
            throw new C0825C(e, this.e);
        }
    }

    @Override // v0.InterfaceC0826D
    public final void k(C0833g c0833g) {
        this.f9795g = c0833g;
        this.f9796h = I2.a.o;
    }

    @Override // v0.InterfaceC0826D
    public final void l(C0123p c0123p, long j6, int i6, List list) {
        long j7;
        long j8;
        AbstractC0133a.i(list.isEmpty());
        int i7 = c0123p.f2632u;
        int i8 = c0123p.f2633v;
        C0123p c0123p2 = this.e;
        int i9 = c0123p2.f2632u;
        x xVar = this.f9791b;
        if (i7 != i9 || i8 != c0123p2.f2633v) {
            R0.e eVar = xVar.f9926d;
            long j9 = xVar.f9928g;
            if (j9 == -9223372036854775807L) {
                j7 = 0;
            } else {
                j7 = j9 + 1;
            }
            eVar.a(j7, new c0(i7, i8));
        }
        float f6 = c0123p.y;
        if (f6 != this.e.y) {
            this.f9790a.g(f6);
        }
        this.e = c0123p;
        if (j6 != this.f9794f) {
            if (xVar.f9927f.f2149c == 0) {
                xVar.f9924b.f(i6);
                xVar.f9932k = j6;
            } else {
                R0.e eVar2 = xVar.e;
                long j10 = xVar.f9928g;
                if (j10 == -9223372036854775807L) {
                    j8 = -4611686018427387904L;
                } else {
                    j8 = j10 + 1;
                }
                eVar2.a(j8, Long.valueOf(j6));
            }
            this.f9794f = j6;
        }
    }

    @Override // v0.InterfaceC0826D
    public final void m(boolean z6) {
        this.f9790a.c(z6);
    }

    @Override // v0.InterfaceC0826D
    public final boolean n(boolean z6) {
        return this.f9790a.b(z6);
    }

    @Override // v0.InterfaceC0826D
    public final void o() {
        this.f9790a.d();
    }

    @Override // v0.InterfaceC0826D
    public final void p(s sVar) {
        this.f9797i = sVar;
    }

    @Override // v0.InterfaceC0826D
    public final void q() {
        throw new UnsupportedOperationException();
    }

    @Override // v0.InterfaceC0826D
    public final void r(long j6) {
        throw new UnsupportedOperationException();
    }

    @Override // v0.InterfaceC0826D
    public final boolean s(long j6, C0834h c0834h) {
        this.f9792c.add(c0834h);
        x xVar = this.f9791b;
        R0.g gVar = xVar.f9927f;
        int i6 = gVar.f2149c;
        long[] jArr = (long[]) gVar.e;
        if (i6 == jArr.length) {
            int length = jArr.length << 1;
            if (length >= 0) {
                long[] jArr2 = new long[length];
                int length2 = jArr.length;
                int i7 = gVar.f2147a;
                int i8 = length2 - i7;
                System.arraycopy(jArr, i7, jArr2, 0, i8);
                System.arraycopy((long[]) gVar.e, 0, jArr2, i8, i7);
                gVar.f2147a = 0;
                gVar.f2148b = gVar.f2149c - 1;
                gVar.e = jArr2;
                gVar.f2150d = length - 1;
            } else {
                throw new IllegalStateException();
            }
        }
        int i9 = (gVar.f2148b + 1) & gVar.f2150d;
        gVar.f2148b = i9;
        ((long[]) gVar.e)[i9] = j6;
        gVar.f2149c++;
        xVar.f9928g = j6;
        xVar.f9930i = -9223372036854775807L;
        this.f9796h.execute(new G4.d(this, 23));
        return true;
    }

    @Override // v0.InterfaceC0826D
    public final void t() {
        x xVar = this.f9791b;
        if (xVar.f9928g == -9223372036854775807L) {
            xVar.f9928g = Long.MIN_VALUE;
            xVar.f9929h = Long.MIN_VALUE;
        }
        xVar.f9930i = xVar.f9928g;
    }

    @Override // v0.InterfaceC0826D
    public final void u() {
        t tVar = this.f9790a;
        if (tVar.e == 0) {
            tVar.e = 1;
        }
    }

    @Override // v0.InterfaceC0826D
    public final void v(int i6) {
        w wVar = this.f9790a.f9888b;
        if (wVar.f9916j == i6) {
            return;
        }
        wVar.f9916j = i6;
        wVar.d(true);
    }

    @Override // v0.InterfaceC0826D
    public final void w(float f6) {
        this.f9790a.i(f6);
    }

    @Override // v0.InterfaceC0826D
    public final void release() {
    }
}
