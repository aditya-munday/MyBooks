package v0;

import Z.E;
import a0.C0195a;
import b0.C0256h;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* loaded from: classes.dex */
public final /* synthetic */ class z implements Runnable {
    public final /* synthetic */ C0256h o;

    /* renamed from: p, reason: collision with root package name */
    public final /* synthetic */ Object f9934p;

    /* renamed from: q, reason: collision with root package name */
    public final /* synthetic */ long f9935q;

    public /* synthetic */ z(C0256h c0256h, Object obj, long j6) {
        this.o = c0256h;
        this.f9934p = obj;
        this.f9935q = j6;
    }

    @Override // java.lang.Runnable
    public final void run() {
        Z.B b6 = this.o.f5196b;
        String str = V.C.f3053a;
        E e = b6.f3885a;
        a0.f fVar = e.f3936t;
        C0195a J6 = fVar.J();
        Object obj = this.f9934p;
        fVar.K(J6, 26, new a0.d(J6, obj, this.f9935q));
        if (e.f3903P == obj) {
            e.f3931n.e(26, new T.e(13));
        }
    }
}
