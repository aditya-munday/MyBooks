package v0;

import V.AbstractC0133a;
import android.content.Context;
import android.hardware.display.DisplayManager;
import android.os.Build;
import android.view.Display;
import android.view.Surface;
import c5.C0352p;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* loaded from: classes.dex */
public final class w {

    /* renamed from: a, reason: collision with root package name */
    public final C0831e f9908a;

    /* renamed from: b, reason: collision with root package name */
    public final C0352p f9909b;

    /* renamed from: c, reason: collision with root package name */
    public final v f9910c;

    /* renamed from: d, reason: collision with root package name */
    public boolean f9911d;
    public Surface e;

    /* renamed from: f, reason: collision with root package name */
    public float f9912f;

    /* renamed from: g, reason: collision with root package name */
    public float f9913g;

    /* renamed from: h, reason: collision with root package name */
    public float f9914h;

    /* renamed from: i, reason: collision with root package name */
    public float f9915i;

    /* renamed from: j, reason: collision with root package name */
    public int f9916j;

    /* renamed from: k, reason: collision with root package name */
    public long f9917k;

    /* renamed from: l, reason: collision with root package name */
    public long f9918l;

    /* renamed from: m, reason: collision with root package name */
    public long f9919m;

    /* renamed from: n, reason: collision with root package name */
    public long f9920n;
    public long o;

    /* renamed from: p, reason: collision with root package name */
    public long f9921p;

    /* renamed from: q, reason: collision with root package name */
    public long f9922q;

    /* JADX WARN: Type inference failed for: r0v0, types: [v0.e, java.lang.Object] */
    public w(Context context) {
        DisplayManager displayManager;
        C0352p c0352p;
        ?? obj = new Object();
        obj.f9805a = new C0830d();
        obj.f9806b = new C0830d();
        obj.f9808d = -9223372036854775807L;
        this.f9908a = obj;
        if (context == null || (displayManager = (DisplayManager) context.getSystemService("display")) == null) {
            c0352p = null;
        } else {
            c0352p = new C0352p(this, displayManager, 2);
        }
        this.f9909b = c0352p;
        this.f9910c = c0352p != null ? v.f9904s : null;
        this.f9917k = -9223372036854775807L;
        this.f9918l = -9223372036854775807L;
        this.f9912f = -1.0f;
        this.f9915i = 1.0f;
        this.f9916j = 0;
    }

    public static void a(w wVar, Display display) {
        if (display != null) {
            long refreshRate = (long) (1.0E9d / display.getRefreshRate());
            wVar.f9917k = refreshRate;
            wVar.f9918l = (refreshRate * 80) / 100;
        } else {
            AbstractC0133a.A("VideoFrameReleaseHelper", "Unable to query display refresh rate");
            wVar.f9917k = -9223372036854775807L;
            wVar.f9918l = -9223372036854775807L;
        }
    }

    public final void b() {
        Surface surface;
        if (Build.VERSION.SDK_INT >= 30 && (surface = this.e) != null && this.f9916j != Integer.MIN_VALUE && this.f9914h != 0.0f) {
            this.f9914h = 0.0f;
            E.c.g(surface, 0.0f);
        }
    }

    /* JADX WARN: Removed duplicated region for block: B:32:? A[RETURN, SYNTHETIC] */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final void c() {
        float f6;
        float f7;
        long j6;
        if (Build.VERSION.SDK_INT >= 30 && this.e != null) {
            C0831e c0831e = this.f9908a;
            if (c0831e.f9805a.a()) {
                if (c0831e.f9805a.a()) {
                    C0830d c0830d = c0831e.f9805a;
                    long j7 = c0830d.e;
                    long j8 = 0;
                    if (j7 != 0) {
                        j8 = c0830d.f9802f / j7;
                    }
                    f6 = (float) (1.0E9d / j8);
                } else {
                    f6 = -1.0f;
                }
            } else {
                f6 = this.f9912f;
            }
            float f8 = this.f9913g;
            if (f6 != f8) {
                if (f6 != -1.0f && f8 != -1.0f) {
                    if (c0831e.f9805a.a()) {
                        if (c0831e.f9805a.a()) {
                            j6 = c0831e.f9805a.f9802f;
                        } else {
                            j6 = -9223372036854775807L;
                        }
                        if (j6 >= 5000000000L) {
                            f7 = 0.02f;
                            if (Math.abs(f6 - this.f9913g) < f7) {
                                return;
                            }
                        }
                    }
                    f7 = 1.0f;
                    if (Math.abs(f6 - this.f9913g) < f7) {
                    }
                } else if (f6 == -1.0f && c0831e.e < 30) {
                    return;
                }
                this.f9913g = f6;
                d(false);
            }
        }
    }

    public final void d(boolean z6) {
        Surface surface;
        float f6;
        if (Build.VERSION.SDK_INT >= 30 && (surface = this.e) != null && this.f9916j != Integer.MIN_VALUE) {
            if (this.f9911d) {
                float f7 = this.f9913g;
                if (f7 != -1.0f) {
                    f6 = f7 * this.f9915i;
                    if (!z6 || this.f9914h != f6) {
                        this.f9914h = f6;
                        E.c.g(surface, f6);
                    }
                    return;
                }
            }
            f6 = 0.0f;
            if (!z6) {
            }
            this.f9914h = f6;
            E.c.g(surface, f6);
        }
    }
}
