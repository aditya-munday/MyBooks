package v0;

import E2.G;
import E2.I;
import E2.Z;
import S.C0115h;
import S.C0122o;
import S.C0123p;
import S.F;
import S.P;
import S.S;
import S.b0;
import S.c0;
import V.AbstractC0133a;
import Z.AbstractC0173e;
import Z.C0174f;
import Z.C0175g;
import Z.C0179k;
import Z.l0;
import Z.n0;
import android.content.Context;
import android.graphics.Point;
import android.media.MediaCodecInfo;
import android.media.MediaCrypto;
import android.media.MediaFormat;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.SystemClock;
import android.os.Trace;
import android.util.Pair;
import android.util.SparseArray;
import android.view.Surface;
import b0.C0256h;
import c5.C0324M;
import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.PriorityQueue;
import org.apache.tika.mime.MimeTypesReaderMetKeys;
import org.apache.tika.pipes.PipesConfigBase;
import org.apache.tika.pipes.PipesServer;
import p0.C0678A;
import p0.Y;
import s2.AbstractC0759a;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* loaded from: classes.dex */
public final class k extends i0.s {

    /* renamed from: J1, reason: collision with root package name */
    public static final int[] f9820J1 = {1920, 1600, 1440, 1280, 960, 854, 640, 540, 480};

    /* renamed from: K1, reason: collision with root package name */
    public static boolean f9821K1;

    /* renamed from: L1, reason: collision with root package name */
    public static boolean f9822L1;

    /* renamed from: A1, reason: collision with root package name */
    public int f9823A1;

    /* renamed from: B1, reason: collision with root package name */
    public boolean f9824B1;
    public int C1;

    /* renamed from: D1, reason: collision with root package name */
    public j f9825D1;

    /* renamed from: E1, reason: collision with root package name */
    public s f9826E1;

    /* renamed from: F1, reason: collision with root package name */
    public long f9827F1;

    /* renamed from: G1, reason: collision with root package name */
    public long f9828G1;
    public boolean H1;

    /* renamed from: I1, reason: collision with root package name */
    public int f9829I1;
    public final Context T0;

    /* renamed from: U0, reason: collision with root package name */
    public final boolean f9830U0;

    /* renamed from: V0, reason: collision with root package name */
    public final C0256h f9831V0;

    /* renamed from: W0, reason: collision with root package name */
    public final int f9832W0;

    /* renamed from: X0, reason: collision with root package name */
    public final boolean f9833X0;

    /* renamed from: Y0, reason: collision with root package name */
    public final t f9834Y0;

    /* renamed from: Z0, reason: collision with root package name */
    public final C4.D f9835Z0;

    /* renamed from: a1, reason: collision with root package name */
    public final long f9836a1;

    /* renamed from: b1, reason: collision with root package name */
    public final PriorityQueue f9837b1;

    /* renamed from: c1, reason: collision with root package name */
    public W.i f9838c1;

    /* renamed from: d1, reason: collision with root package name */
    public boolean f9839d1;

    /* renamed from: e1, reason: collision with root package name */
    public boolean f9840e1;

    /* renamed from: f1, reason: collision with root package name */
    public InterfaceC0826D f9841f1;
    public boolean g1;

    /* renamed from: h1, reason: collision with root package name */
    public int f9842h1;

    /* renamed from: i1, reason: collision with root package name */
    public List f9843i1;

    /* renamed from: j1, reason: collision with root package name */
    public Surface f9844j1;

    /* renamed from: k1, reason: collision with root package name */
    public m f9845k1;

    /* renamed from: l1, reason: collision with root package name */
    public V.w f9846l1;

    /* renamed from: m1, reason: collision with root package name */
    public boolean f9847m1;

    /* renamed from: n1, reason: collision with root package name */
    public int f9848n1;

    /* renamed from: o1, reason: collision with root package name */
    public int f9849o1;

    /* renamed from: p1, reason: collision with root package name */
    public long f9850p1;

    /* renamed from: q1, reason: collision with root package name */
    public int f9851q1;

    /* renamed from: r1, reason: collision with root package name */
    public int f9852r1;

    /* renamed from: s1, reason: collision with root package name */
    public int f9853s1;

    /* renamed from: t1, reason: collision with root package name */
    public n0 f9854t1;

    /* renamed from: u1, reason: collision with root package name */
    public boolean f9855u1;
    public long v1;
    public int w1;

    /* renamed from: x1, reason: collision with root package name */
    public long f9856x1;

    /* renamed from: y1, reason: collision with root package name */
    public c0 f9857y1;

    /* renamed from: z1, reason: collision with root package name */
    public c0 f9858z1;

    public k(C0835i c0835i) {
        super(2, c0835i.f9815c, 30.0f);
        boolean z6;
        Context applicationContext = c0835i.f9813a.getApplicationContext();
        this.T0 = applicationContext;
        this.f9832W0 = c0835i.f9818g;
        this.f9841f1 = null;
        this.f9831V0 = new C0256h(c0835i.e, c0835i.f9817f, 1);
        if (this.f9841f1 == null) {
            z6 = true;
        } else {
            z6 = false;
        }
        this.f9830U0 = z6;
        this.f9834Y0 = new t(applicationContext, this, c0835i.f9816d);
        this.f9835Z0 = new C4.D();
        this.f9833X0 = "NVIDIA".equals(Build.MANUFACTURER);
        this.f9846l1 = V.w.f3123c;
        this.f9848n1 = 1;
        this.f9849o1 = 0;
        this.f9857y1 = c0.f2533d;
        this.C1 = 0;
        this.f9858z1 = null;
        this.f9823A1 = -1000;
        this.f9827F1 = -9223372036854775807L;
        this.f9828G1 = -9223372036854775807L;
        this.f9837b1 = new PriorityQueue();
        this.f9836a1 = -9223372036854775807L;
        this.f9854t1 = null;
    }

    public static List A0(Context context, i0.j jVar, C0123p c0123p, boolean z6, boolean z7) {
        List a6;
        String str = c0123p.f2626n;
        if (str == null) {
            return Z.f721s;
        }
        if (Build.VERSION.SDK_INT >= 26 && "video/dolby-vision".equals(str) && !AbstractC0759a.b(context)) {
            String b6 = i0.x.b(c0123p);
            if (b6 == null) {
                a6 = Z.f721s;
            } else {
                a6 = jVar.a(b6, z6, z7);
            }
            if (!a6.isEmpty()) {
                return a6;
            }
        }
        return i0.x.f(jVar, c0123p, z6, z7);
    }

    public static int B0(i0.p pVar, C0123p c0123p) {
        int i6 = c0123p.o;
        List list = c0123p.f2628q;
        if (i6 != -1) {
            int size = list.size();
            int i7 = 0;
            for (int i8 = 0; i8 < size; i8++) {
                i7 += ((byte[]) list.get(i8)).length;
            }
            return c0123p.o + i7;
        }
        return z0(pVar, c0123p);
    }

    /* JADX WARN: Can't fix incorrect switch cases order, some code will duplicate */
    /* JADX WARN: Code restructure failed: missing block: B:396:0x0736, code lost:
    
        if (r0.equals("ELUGA_Ray_X") == false) goto L101;
     */
    /* JADX WARN: Code restructure failed: missing block: B:61:0x08b7, code lost:
    
        if (r13.equals("JSN-L21") == false) goto L664;
     */
    /* JADX WARN: Removed duplicated region for block: B:17:0x008b A[FALL_THROUGH] */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public static boolean y0(String str) {
        boolean z6;
        boolean z7;
        boolean z8 = false;
        if (str.startsWith("OMX.google")) {
            return false;
        }
        synchronized (k.class) {
            try {
                if (!f9821K1) {
                    int i6 = Build.VERSION.SDK_INT;
                    char c6 = 28;
                    if (i6 <= 28) {
                        String str2 = Build.DEVICE;
                        str2.getClass();
                        switch (str2.hashCode()) {
                            case -1339091551:
                                if (str2.equals("dangal")) {
                                    z7 = false;
                                    break;
                                }
                                z7 = -1;
                                break;
                            case -1220081023:
                                if (str2.equals("dangalFHD")) {
                                    z7 = true;
                                    break;
                                }
                                z7 = -1;
                                break;
                            case -1220066608:
                                if (str2.equals("dangalUHD")) {
                                    z7 = 2;
                                    break;
                                }
                                z7 = -1;
                                break;
                            case -1012436106:
                                if (str2.equals("oneday")) {
                                    z7 = 3;
                                    break;
                                }
                                z7 = -1;
                                break;
                            case -760312546:
                                if (str2.equals("aquaman")) {
                                    z7 = 4;
                                    break;
                                }
                                z7 = -1;
                                break;
                            case -64886864:
                                if (str2.equals("magnolia")) {
                                    z7 = 5;
                                    break;
                                }
                                z7 = -1;
                                break;
                            case 3415681:
                                if (str2.equals("once")) {
                                    z7 = 6;
                                    break;
                                }
                                z7 = -1;
                                break;
                            case 825323514:
                                if (str2.equals("machuca")) {
                                    z7 = 7;
                                    break;
                                }
                                z7 = -1;
                                break;
                            default:
                                z7 = -1;
                                break;
                        }
                        switch (z7) {
                            case false:
                            case true:
                            case true:
                            case true:
                            case true:
                            case true:
                            case true:
                            case true:
                                z8 = true;
                                break;
                        }
                        f9822L1 = z8;
                        f9821K1 = true;
                    }
                    if (i6 > 27 || !"HWEML".equals(Build.DEVICE)) {
                        String str3 = Build.MODEL;
                        str3.getClass();
                        switch (str3.hashCode()) {
                            case -349662828:
                                if (str3.equals("AFTJMST12")) {
                                    z6 = false;
                                    break;
                                }
                                z6 = -1;
                                break;
                            case -321033677:
                                if (str3.equals("AFTKMST12")) {
                                    z6 = true;
                                    break;
                                }
                                z6 = -1;
                                break;
                            case 2006354:
                                if (str3.equals("AFTA")) {
                                    z6 = 2;
                                    break;
                                }
                                z6 = -1;
                                break;
                            case 2006367:
                                if (str3.equals("AFTN")) {
                                    z6 = 3;
                                    break;
                                }
                                z6 = -1;
                                break;
                            case 2006371:
                                if (str3.equals("AFTR")) {
                                    z6 = 4;
                                    break;
                                }
                                z6 = -1;
                                break;
                            case 1785421873:
                                if (str3.equals("AFTEU011")) {
                                    z6 = 5;
                                    break;
                                }
                                z6 = -1;
                                break;
                            case 1785421876:
                                if (str3.equals("AFTEU014")) {
                                    z6 = 6;
                                    break;
                                }
                                z6 = -1;
                                break;
                            case 1798172390:
                                if (str3.equals("AFTSO001")) {
                                    z6 = 7;
                                    break;
                                }
                                z6 = -1;
                                break;
                            case 2119412532:
                                if (str3.equals("AFTEUFF014")) {
                                    z6 = 8;
                                    break;
                                }
                                z6 = -1;
                                break;
                            default:
                                z6 = -1;
                                break;
                        }
                        switch (z6) {
                            default:
                                if (i6 <= 26) {
                                    String str4 = Build.DEVICE;
                                    str4.getClass();
                                    switch (str4.hashCode()) {
                                        case -2144781245:
                                            if (str4.equals("GIONEE_SWW1609")) {
                                                c6 = 0;
                                                break;
                                            }
                                            c6 = 65535;
                                            break;
                                        case -2144781185:
                                            if (str4.equals("GIONEE_SWW1627")) {
                                                c6 = 1;
                                                break;
                                            }
                                            c6 = 65535;
                                            break;
                                        case -2144781160:
                                            if (str4.equals("GIONEE_SWW1631")) {
                                                c6 = 2;
                                                break;
                                            }
                                            c6 = 65535;
                                            break;
                                        case -2097309513:
                                            if (str4.equals("K50a40")) {
                                                c6 = 3;
                                                break;
                                            }
                                            c6 = 65535;
                                            break;
                                        case -2022874474:
                                            if (str4.equals("CP8676_I02")) {
                                                c6 = 4;
                                                break;
                                            }
                                            c6 = 65535;
                                            break;
                                        case -1978993182:
                                            if (str4.equals("NX541J")) {
                                                c6 = 5;
                                                break;
                                            }
                                            c6 = 65535;
                                            break;
                                        case -1978990237:
                                            if (str4.equals("NX573J")) {
                                                c6 = 6;
                                                break;
                                            }
                                            c6 = 65535;
                                            break;
                                        case -1936688988:
                                            if (str4.equals("PGN528")) {
                                                c6 = 7;
                                                break;
                                            }
                                            c6 = 65535;
                                            break;
                                        case -1936688066:
                                            if (str4.equals("PGN610")) {
                                                c6 = '\b';
                                                break;
                                            }
                                            c6 = 65535;
                                            break;
                                        case -1936688065:
                                            if (str4.equals("PGN611")) {
                                                c6 = '\t';
                                                break;
                                            }
                                            c6 = 65535;
                                            break;
                                        case -1931988508:
                                            if (str4.equals("AquaPowerM")) {
                                                c6 = '\n';
                                                break;
                                            }
                                            c6 = 65535;
                                            break;
                                        case -1885099851:
                                            if (str4.equals("RAIJIN")) {
                                                c6 = 11;
                                                break;
                                            }
                                            c6 = 65535;
                                            break;
                                        case -1696512866:
                                            if (str4.equals("XT1663")) {
                                                c6 = '\f';
                                                break;
                                            }
                                            c6 = 65535;
                                            break;
                                        case -1680025915:
                                            if (str4.equals("ComioS1")) {
                                                c6 = '\r';
                                                break;
                                            }
                                            c6 = 65535;
                                            break;
                                        case -1615810839:
                                            if (str4.equals("Phantom6")) {
                                                c6 = 14;
                                                break;
                                            }
                                            c6 = 65535;
                                            break;
                                        case -1600724499:
                                            if (str4.equals("pacificrim")) {
                                                c6 = 15;
                                                break;
                                            }
                                            c6 = 65535;
                                            break;
                                        case -1554255044:
                                            if (str4.equals("vernee_M5")) {
                                                c6 = 16;
                                                break;
                                            }
                                            c6 = 65535;
                                            break;
                                        case -1481772737:
                                            if (str4.equals("panell_dl")) {
                                                c6 = 17;
                                                break;
                                            }
                                            c6 = 65535;
                                            break;
                                        case -1481772730:
                                            if (str4.equals("panell_ds")) {
                                                c6 = 18;
                                                break;
                                            }
                                            c6 = 65535;
                                            break;
                                        case -1481772729:
                                            if (str4.equals("panell_dt")) {
                                                c6 = 19;
                                                break;
                                            }
                                            c6 = 65535;
                                            break;
                                        case -1320080169:
                                            if (str4.equals("GiONEE_GBL7319")) {
                                                c6 = 20;
                                                break;
                                            }
                                            c6 = 65535;
                                            break;
                                        case -1217592143:
                                            if (str4.equals("BRAVIA_ATV2")) {
                                                c6 = 21;
                                                break;
                                            }
                                            c6 = 65535;
                                            break;
                                        case -1180384755:
                                            if (str4.equals("iris60")) {
                                                c6 = 22;
                                                break;
                                            }
                                            c6 = 65535;
                                            break;
                                        case -1139198265:
                                            if (str4.equals("Slate_Pro")) {
                                                c6 = 23;
                                                break;
                                            }
                                            c6 = 65535;
                                            break;
                                        case -1052835013:
                                            if (str4.equals("namath")) {
                                                c6 = 24;
                                                break;
                                            }
                                            c6 = 65535;
                                            break;
                                        case -993250464:
                                            if (str4.equals("A10-70F")) {
                                                c6 = 25;
                                                break;
                                            }
                                            c6 = 65535;
                                            break;
                                        case -993250458:
                                            if (str4.equals("A10-70L")) {
                                                c6 = 26;
                                                break;
                                            }
                                            c6 = 65535;
                                            break;
                                        case -965403638:
                                            if (str4.equals("s905x018")) {
                                                c6 = 27;
                                                break;
                                            }
                                            c6 = 65535;
                                            break;
                                        case -958336948:
                                            break;
                                        case -879245230:
                                            if (str4.equals("tcl_eu")) {
                                                c6 = 29;
                                                break;
                                            }
                                            c6 = 65535;
                                            break;
                                        case -842500323:
                                            if (str4.equals("nicklaus_f")) {
                                                c6 = 30;
                                                break;
                                            }
                                            c6 = 65535;
                                            break;
                                        case -821392978:
                                            if (str4.equals("A7000-a")) {
                                                c6 = 31;
                                                break;
                                            }
                                            c6 = 65535;
                                            break;
                                        case -797483286:
                                            if (str4.equals("SVP-DTV15")) {
                                                c6 = ' ';
                                                break;
                                            }
                                            c6 = 65535;
                                            break;
                                        case -794946968:
                                            if (str4.equals("watson")) {
                                                c6 = '!';
                                                break;
                                            }
                                            c6 = 65535;
                                            break;
                                        case -788334647:
                                            if (str4.equals("whyred")) {
                                                c6 = '\"';
                                                break;
                                            }
                                            c6 = 65535;
                                            break;
                                        case -782144577:
                                            if (str4.equals("OnePlus5T")) {
                                                c6 = '#';
                                                break;
                                            }
                                            c6 = 65535;
                                            break;
                                        case -575125681:
                                            if (str4.equals("GiONEE_CBL7513")) {
                                                c6 = '$';
                                                break;
                                            }
                                            c6 = 65535;
                                            break;
                                        case -521118391:
                                            if (str4.equals("GIONEE_GBL7360")) {
                                                c6 = '%';
                                                break;
                                            }
                                            c6 = 65535;
                                            break;
                                        case -430914369:
                                            if (str4.equals("Pixi4-7_3G")) {
                                                c6 = '&';
                                                break;
                                            }
                                            c6 = 65535;
                                            break;
                                        case -290434366:
                                            if (str4.equals("taido_row")) {
                                                c6 = '\'';
                                                break;
                                            }
                                            c6 = 65535;
                                            break;
                                        case -282781963:
                                            if (str4.equals("BLACK-1X")) {
                                                c6 = '(';
                                                break;
                                            }
                                            c6 = 65535;
                                            break;
                                        case -277133239:
                                            if (str4.equals("Z12_PRO")) {
                                                c6 = ')';
                                                break;
                                            }
                                            c6 = 65535;
                                            break;
                                        case -173639913:
                                            if (str4.equals("ELUGA_A3_Pro")) {
                                                c6 = '*';
                                                break;
                                            }
                                            c6 = 65535;
                                            break;
                                        case -56598463:
                                            if (str4.equals("woods_fn")) {
                                                c6 = '+';
                                                break;
                                            }
                                            c6 = 65535;
                                            break;
                                        case 2126:
                                            if (str4.equals("C1")) {
                                                c6 = ',';
                                                break;
                                            }
                                            c6 = 65535;
                                            break;
                                        case 2564:
                                            if (str4.equals("Q5")) {
                                                c6 = '-';
                                                break;
                                            }
                                            c6 = 65535;
                                            break;
                                        case 2715:
                                            if (str4.equals("V1")) {
                                                c6 = '.';
                                                break;
                                            }
                                            c6 = 65535;
                                            break;
                                        case 2719:
                                            if (str4.equals("V5")) {
                                                c6 = '/';
                                                break;
                                            }
                                            c6 = 65535;
                                            break;
                                        case 3091:
                                            if (str4.equals("b5")) {
                                                c6 = '0';
                                                break;
                                            }
                                            c6 = 65535;
                                            break;
                                        case 3483:
                                            if (str4.equals("mh")) {
                                                c6 = '1';
                                                break;
                                            }
                                            c6 = 65535;
                                            break;
                                        case 73405:
                                            if (str4.equals("JGZ")) {
                                                c6 = '2';
                                                break;
                                            }
                                            c6 = 65535;
                                            break;
                                        case 75537:
                                            if (str4.equals("M04")) {
                                                c6 = '3';
                                                break;
                                            }
                                            c6 = 65535;
                                            break;
                                        case 75739:
                                            if (str4.equals("M5c")) {
                                                c6 = '4';
                                                break;
                                            }
                                            c6 = 65535;
                                            break;
                                        case 76779:
                                            if (str4.equals("MX6")) {
                                                c6 = '5';
                                                break;
                                            }
                                            c6 = 65535;
                                            break;
                                        case 78669:
                                            if (str4.equals("P85")) {
                                                c6 = '6';
                                                break;
                                            }
                                            c6 = 65535;
                                            break;
                                        case 79305:
                                            if (str4.equals("PLE")) {
                                                c6 = '7';
                                                break;
                                            }
                                            c6 = 65535;
                                            break;
                                        case 80618:
                                            if (str4.equals("QX1")) {
                                                c6 = '8';
                                                break;
                                            }
                                            c6 = 65535;
                                            break;
                                        case 88274:
                                            if (str4.equals("Z80")) {
                                                c6 = '9';
                                                break;
                                            }
                                            c6 = 65535;
                                            break;
                                        case 98846:
                                            if (str4.equals("cv1")) {
                                                c6 = ':';
                                                break;
                                            }
                                            c6 = 65535;
                                            break;
                                        case 98848:
                                            if (str4.equals("cv3")) {
                                                c6 = ';';
                                                break;
                                            }
                                            c6 = 65535;
                                            break;
                                        case 99329:
                                            if (str4.equals("deb")) {
                                                c6 = '<';
                                                break;
                                            }
                                            c6 = 65535;
                                            break;
                                        case 101481:
                                            if (str4.equals("flo")) {
                                                c6 = '=';
                                                break;
                                            }
                                            c6 = 65535;
                                            break;
                                        case 1513190:
                                            if (str4.equals("1601")) {
                                                c6 = '>';
                                                break;
                                            }
                                            c6 = 65535;
                                            break;
                                        case 1514184:
                                            if (str4.equals("1713")) {
                                                c6 = '?';
                                                break;
                                            }
                                            c6 = 65535;
                                            break;
                                        case 1514185:
                                            if (str4.equals("1714")) {
                                                c6 = '@';
                                                break;
                                            }
                                            c6 = 65535;
                                            break;
                                        case 2133089:
                                            if (str4.equals("F01H")) {
                                                c6 = 'A';
                                                break;
                                            }
                                            c6 = 65535;
                                            break;
                                        case 2133091:
                                            if (str4.equals("F01J")) {
                                                c6 = 'B';
                                                break;
                                            }
                                            c6 = 65535;
                                            break;
                                        case 2133120:
                                            if (str4.equals("F02H")) {
                                                c6 = 'C';
                                                break;
                                            }
                                            c6 = 65535;
                                            break;
                                        case 2133151:
                                            if (str4.equals("F03H")) {
                                                c6 = 'D';
                                                break;
                                            }
                                            c6 = 65535;
                                            break;
                                        case 2133182:
                                            if (str4.equals("F04H")) {
                                                c6 = 'E';
                                                break;
                                            }
                                            c6 = 65535;
                                            break;
                                        case 2133184:
                                            if (str4.equals("F04J")) {
                                                c6 = 'F';
                                                break;
                                            }
                                            c6 = 65535;
                                            break;
                                        case 2436959:
                                            if (str4.equals("P681")) {
                                                c6 = 'G';
                                                break;
                                            }
                                            c6 = 65535;
                                            break;
                                        case 2463773:
                                            if (str4.equals("Q350")) {
                                                c6 = 'H';
                                                break;
                                            }
                                            c6 = 65535;
                                            break;
                                        case 2464648:
                                            if (str4.equals("Q427")) {
                                                c6 = 'I';
                                                break;
                                            }
                                            c6 = 65535;
                                            break;
                                        case 2689555:
                                            if (str4.equals("XE2X")) {
                                                c6 = 'J';
                                                break;
                                            }
                                            c6 = 65535;
                                            break;
                                        case 3154429:
                                            if (str4.equals("fugu")) {
                                                c6 = 'K';
                                                break;
                                            }
                                            c6 = 65535;
                                            break;
                                        case 3284551:
                                            if (str4.equals("kate")) {
                                                c6 = 'L';
                                                break;
                                            }
                                            c6 = 65535;
                                            break;
                                        case 3351335:
                                            if (str4.equals("mido")) {
                                                c6 = 'M';
                                                break;
                                            }
                                            c6 = 65535;
                                            break;
                                        case 3386211:
                                            if (str4.equals("p212")) {
                                                c6 = 'N';
                                                break;
                                            }
                                            c6 = 65535;
                                            break;
                                        case 41325051:
                                            if (str4.equals("MEIZU_M5")) {
                                                c6 = 'O';
                                                break;
                                            }
                                            c6 = 65535;
                                            break;
                                        case 51349633:
                                            if (str4.equals("601LV")) {
                                                c6 = 'P';
                                                break;
                                            }
                                            c6 = 65535;
                                            break;
                                        case 51350594:
                                            if (str4.equals("602LV")) {
                                                c6 = 'Q';
                                                break;
                                            }
                                            c6 = 65535;
                                            break;
                                        case 55178625:
                                            if (str4.equals("Aura_Note_2")) {
                                                c6 = 'R';
                                                break;
                                            }
                                            c6 = 65535;
                                            break;
                                        case 61542055:
                                            if (str4.equals("A1601")) {
                                                c6 = 'S';
                                                break;
                                            }
                                            c6 = 65535;
                                            break;
                                        case 65355429:
                                            if (str4.equals("E5643")) {
                                                c6 = 'T';
                                                break;
                                            }
                                            c6 = 65535;
                                            break;
                                        case 66214468:
                                            if (str4.equals("F3111")) {
                                                c6 = 'U';
                                                break;
                                            }
                                            c6 = 65535;
                                            break;
                                        case 66214470:
                                            if (str4.equals("F3113")) {
                                                c6 = 'V';
                                                break;
                                            }
                                            c6 = 65535;
                                            break;
                                        case 66214473:
                                            if (str4.equals("F3116")) {
                                                c6 = 'W';
                                                break;
                                            }
                                            c6 = 65535;
                                            break;
                                        case 66215429:
                                            if (str4.equals("F3211")) {
                                                c6 = 'X';
                                                break;
                                            }
                                            c6 = 65535;
                                            break;
                                        case 66215431:
                                            if (str4.equals("F3213")) {
                                                c6 = 'Y';
                                                break;
                                            }
                                            c6 = 65535;
                                            break;
                                        case 66215433:
                                            if (str4.equals("F3215")) {
                                                c6 = 'Z';
                                                break;
                                            }
                                            c6 = 65535;
                                            break;
                                        case 66216390:
                                            if (str4.equals("F3311")) {
                                                c6 = '[';
                                                break;
                                            }
                                            c6 = 65535;
                                            break;
                                        case 76402249:
                                            if (str4.equals("PRO7S")) {
                                                c6 = '\\';
                                                break;
                                            }
                                            c6 = 65535;
                                            break;
                                        case 76404105:
                                            if (str4.equals("Q4260")) {
                                                c6 = ']';
                                                break;
                                            }
                                            c6 = 65535;
                                            break;
                                        case 76404911:
                                            if (str4.equals("Q4310")) {
                                                c6 = '^';
                                                break;
                                            }
                                            c6 = 65535;
                                            break;
                                        case 80963634:
                                            if (str4.equals("V23GB")) {
                                                c6 = '_';
                                                break;
                                            }
                                            c6 = 65535;
                                            break;
                                        case 82882791:
                                            if (str4.equals("X3_HK")) {
                                                c6 = '`';
                                                break;
                                            }
                                            c6 = 65535;
                                            break;
                                        case 98715550:
                                            if (str4.equals("i9031")) {
                                                c6 = 'a';
                                                break;
                                            }
                                            c6 = 65535;
                                            break;
                                        case 101370885:
                                            if (str4.equals("l5460")) {
                                                c6 = 'b';
                                                break;
                                            }
                                            c6 = 65535;
                                            break;
                                        case 102844228:
                                            if (str4.equals("le_x6")) {
                                                c6 = 'c';
                                                break;
                                            }
                                            c6 = 65535;
                                            break;
                                        case 165221241:
                                            if (str4.equals("A2016a40")) {
                                                c6 = 'd';
                                                break;
                                            }
                                            c6 = 65535;
                                            break;
                                        case 182191441:
                                            if (str4.equals("CPY83_I00")) {
                                                c6 = 'e';
                                                break;
                                            }
                                            c6 = 65535;
                                            break;
                                        case 245388979:
                                            if (str4.equals("marino_f")) {
                                                c6 = 'f';
                                                break;
                                            }
                                            c6 = 65535;
                                            break;
                                        case 287431619:
                                            if (str4.equals("griffin")) {
                                                c6 = 'g';
                                                break;
                                            }
                                            c6 = 65535;
                                            break;
                                        case 307593612:
                                            if (str4.equals("A7010a48")) {
                                                c6 = 'h';
                                                break;
                                            }
                                            c6 = 65535;
                                            break;
                                        case 308517133:
                                            if (str4.equals("A7020a48")) {
                                                c6 = 'i';
                                                break;
                                            }
                                            c6 = 65535;
                                            break;
                                        case 316215098:
                                            if (str4.equals("TB3-730F")) {
                                                c6 = 'j';
                                                break;
                                            }
                                            c6 = 65535;
                                            break;
                                        case 316215116:
                                            if (str4.equals("TB3-730X")) {
                                                c6 = 'k';
                                                break;
                                            }
                                            c6 = 65535;
                                            break;
                                        case 316246811:
                                            if (str4.equals("TB3-850F")) {
                                                c6 = 'l';
                                                break;
                                            }
                                            c6 = 65535;
                                            break;
                                        case 316246818:
                                            if (str4.equals("TB3-850M")) {
                                                c6 = 'm';
                                                break;
                                            }
                                            c6 = 65535;
                                            break;
                                        case 407160593:
                                            if (str4.equals("Pixi5-10_4G")) {
                                                c6 = 'n';
                                                break;
                                            }
                                            c6 = 65535;
                                            break;
                                        case 507412548:
                                            if (str4.equals("QM16XE_U")) {
                                                c6 = 'o';
                                                break;
                                            }
                                            c6 = 65535;
                                            break;
                                        case 793982701:
                                            if (str4.equals("GIONEE_WBL5708")) {
                                                c6 = 'p';
                                                break;
                                            }
                                            c6 = 65535;
                                            break;
                                        case 794038622:
                                            if (str4.equals("GIONEE_WBL7365")) {
                                                c6 = 'q';
                                                break;
                                            }
                                            c6 = 65535;
                                            break;
                                        case 794040393:
                                            if (str4.equals("GIONEE_WBL7519")) {
                                                c6 = 'r';
                                                break;
                                            }
                                            c6 = 65535;
                                            break;
                                        case 835649806:
                                            if (str4.equals("manning")) {
                                                c6 = 's';
                                                break;
                                            }
                                            c6 = 65535;
                                            break;
                                        case 917340916:
                                            if (str4.equals("A7000plus")) {
                                                c6 = 't';
                                                break;
                                            }
                                            c6 = 65535;
                                            break;
                                        case 958008161:
                                            if (str4.equals("j2xlteins")) {
                                                c6 = 'u';
                                                break;
                                            }
                                            c6 = 65535;
                                            break;
                                        case 1060579533:
                                            if (str4.equals("panell_d")) {
                                                c6 = 'v';
                                                break;
                                            }
                                            c6 = 65535;
                                            break;
                                        case 1150207623:
                                            if (str4.equals("LS-5017")) {
                                                c6 = 'w';
                                                break;
                                            }
                                            c6 = 65535;
                                            break;
                                        case 1176899427:
                                            if (str4.equals("itel_S41")) {
                                                c6 = 'x';
                                                break;
                                            }
                                            c6 = 65535;
                                            break;
                                        case 1280332038:
                                            if (str4.equals("hwALE-H")) {
                                                c6 = 'y';
                                                break;
                                            }
                                            c6 = 65535;
                                            break;
                                        case 1306947716:
                                            if (str4.equals("EverStar_S")) {
                                                c6 = 'z';
                                                break;
                                            }
                                            c6 = 65535;
                                            break;
                                        case 1349174697:
                                            if (str4.equals("htc_e56ml_dtul")) {
                                                c6 = '{';
                                                break;
                                            }
                                            c6 = 65535;
                                            break;
                                        case 1522194893:
                                            if (str4.equals("woods_f")) {
                                                c6 = '|';
                                                break;
                                            }
                                            c6 = 65535;
                                            break;
                                        case 1691543273:
                                            if (str4.equals("CPH1609")) {
                                                c6 = '}';
                                                break;
                                            }
                                            c6 = 65535;
                                            break;
                                        case 1691544261:
                                            if (str4.equals("CPH1715")) {
                                                c6 = '~';
                                                break;
                                            }
                                            c6 = 65535;
                                            break;
                                        case 1709443163:
                                            if (str4.equals("iball8735_9806")) {
                                                c6 = 127;
                                                break;
                                            }
                                            c6 = 65535;
                                            break;
                                        case 1865889110:
                                            if (str4.equals("santoni")) {
                                                c6 = 128;
                                                break;
                                            }
                                            c6 = 65535;
                                            break;
                                        case 1906253259:
                                            if (str4.equals("PB2-670M")) {
                                                c6 = 129;
                                                break;
                                            }
                                            c6 = 65535;
                                            break;
                                        case 1977196784:
                                            if (str4.equals("Infinix-X572")) {
                                                c6 = 130;
                                                break;
                                            }
                                            c6 = 65535;
                                            break;
                                        case 2006372676:
                                            if (str4.equals("BRAVIA_ATV3_4K")) {
                                                c6 = 131;
                                                break;
                                            }
                                            c6 = 65535;
                                            break;
                                        case 2019281702:
                                            if (str4.equals("DM-01K")) {
                                                c6 = 132;
                                                break;
                                            }
                                            c6 = 65535;
                                            break;
                                        case 2029784656:
                                            if (str4.equals("HWBLN-H")) {
                                                c6 = 133;
                                                break;
                                            }
                                            c6 = 65535;
                                            break;
                                        case 2030379515:
                                            if (str4.equals("HWCAM-H")) {
                                                c6 = 134;
                                                break;
                                            }
                                            c6 = 65535;
                                            break;
                                        case 2033393791:
                                            if (str4.equals("ASUS_X00AD_2")) {
                                                c6 = 135;
                                                break;
                                            }
                                            c6 = 65535;
                                            break;
                                        case 2047190025:
                                            if (str4.equals("ELUGA_Note")) {
                                                c6 = 136;
                                                break;
                                            }
                                            c6 = 65535;
                                            break;
                                        case 2047252157:
                                            if (str4.equals("ELUGA_Prim")) {
                                                c6 = 137;
                                                break;
                                            }
                                            c6 = 65535;
                                            break;
                                        case 2048319463:
                                            if (str4.equals("HWVNS-H")) {
                                                c6 = 138;
                                                break;
                                            }
                                            c6 = 65535;
                                            break;
                                        case 2048855701:
                                            if (str4.equals("HWWAS-H")) {
                                                c6 = 139;
                                                break;
                                            }
                                            c6 = 65535;
                                            break;
                                        default:
                                            c6 = 65535;
                                            break;
                                    }
                                    switch (c6) {
                                    }
                                }
                                break;
                            case false:
                            case true:
                            case true:
                            case true:
                            case true:
                            case true:
                            case true:
                            case true:
                            case true:
                                break;
                        }
                        f9822L1 = z8;
                        f9821K1 = true;
                    }
                    z8 = true;
                    f9822L1 = z8;
                    f9821K1 = true;
                }
            } catch (Throwable th) {
                throw th;
            }
        }
        return f9822L1;
    }

    /* JADX WARN: Can't fix incorrect switch cases order, some code will duplicate */
    /* JADX WARN: Code restructure failed: missing block: B:56:0x0084, code lost:
    
        if (r3.equals("video/av01") == false) goto L22;
     */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public static int z0(i0.p pVar, C0123p c0123p) {
        int i6 = c0123p.f2632u;
        int i7 = c0123p.f2633v;
        if (i6 != -1 && i7 != -1) {
            String str = c0123p.f2626n;
            str.getClass();
            char c6 = 1;
            if ("video/dolby-vision".equals(str)) {
                HashMap hashMap = i0.x.f6987a;
                Pair c7 = V.d.c(c0123p);
                if (c7 != null) {
                    int intValue = ((Integer) c7.first).intValue();
                    if (intValue == 512 || intValue == 1 || intValue == 2) {
                        str = "video/avc";
                    } else if (intValue == 1024) {
                        str = "video/av01";
                    }
                }
                str = "video/hevc";
            }
            switch (str.hashCode()) {
                case -1664118616:
                    if (str.equals("video/3gpp")) {
                        c6 = 0;
                        break;
                    }
                    c6 = 65535;
                    break;
                case -1662735862:
                    break;
                case -1662541442:
                    if (str.equals("video/hevc")) {
                        c6 = 2;
                        break;
                    }
                    c6 = 65535;
                    break;
                case 1187890754:
                    if (str.equals("video/mp4v-es")) {
                        c6 = 3;
                        break;
                    }
                    c6 = 65535;
                    break;
                case 1331836730:
                    if (str.equals("video/avc")) {
                        c6 = 4;
                        break;
                    }
                    c6 = 65535;
                    break;
                case 1599127256:
                    if (str.equals("video/x-vnd.on2.vp8")) {
                        c6 = 5;
                        break;
                    }
                    c6 = 65535;
                    break;
                case 1599127257:
                    if (str.equals("video/x-vnd.on2.vp9")) {
                        c6 = 6;
                        break;
                    }
                    c6 = 65535;
                    break;
                default:
                    c6 = 65535;
                    break;
            }
            switch (c6) {
                case 0:
                case 1:
                case 3:
                case 5:
                    return ((i6 * i7) * 3) / 4;
                case 2:
                    return Math.max(2097152, ((i6 * i7) * 3) / 4);
                case 4:
                    String str2 = Build.MODEL;
                    if (!"BRAVIA 4K 2015".equals(str2) && (!"Amazon".equals(Build.MANUFACTURER) || (!"KFSOWI".equals(str2) && (!"AFTS".equals(str2) || !pVar.f6907f)))) {
                        return ((V.C.f(i7, 16) * V.C.f(i6, 16)) * 768) / 4;
                    }
                    break;
                case 6:
                    return ((i6 * i7) * 3) / 8;
            }
        }
        return -1;
    }

    @Override // i0.s, Z.AbstractC0173e
    public final void A(float f6, float f7) {
        super.A(f6, f7);
        InterfaceC0826D interfaceC0826D = this.f9841f1;
        if (interfaceC0826D != null) {
            interfaceC0826D.w(f6);
        } else {
            this.f9834Y0.i(f6);
        }
    }

    /* JADX WARN: Removed duplicated region for block: B:29:0x0056  */
    /* JADX WARN: Removed duplicated region for block: B:32:0x0070 A[EXC_TOP_SPLITTER, SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:64:0x0059  */
    /* JADX WARN: Type inference failed for: r0v10, types: [android.os.HandlerThread, java.lang.Thread, android.os.Handler$Callback, java.lang.Object, v0.l] */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final Surface C0(i0.p pVar) {
        boolean z6;
        ?? handlerThread;
        int i6;
        InterfaceC0826D interfaceC0826D = this.f9841f1;
        if (interfaceC0826D != null) {
            return interfaceC0826D.c();
        }
        Surface surface = this.f9844j1;
        if (surface != null) {
            return surface;
        }
        if (Build.VERSION.SDK_INT >= 35 && pVar.f6909h) {
            return null;
        }
        AbstractC0133a.i(L0(pVar));
        m mVar = this.f9845k1;
        if (mVar != null && mVar.o != pVar.f6907f && mVar != null) {
            mVar.release();
            this.f9845k1 = null;
        }
        if (this.f9845k1 == null) {
            Context context = this.T0;
            boolean z7 = pVar.f6907f;
            boolean z8 = false;
            if (z7) {
                if (!m.b(context)) {
                    z6 = false;
                    AbstractC0133a.i(z6);
                    handlerThread = new HandlerThread("ExoPlayer:PlaceholderSurface");
                    if (!z7) {
                        i6 = m.f9863r;
                    } else {
                        i6 = 0;
                    }
                    handlerThread.start();
                    Handler handler = new Handler(handlerThread.getLooper(), handlerThread);
                    handlerThread.f9859p = handler;
                    handlerThread.o = new V.h(handler);
                    synchronized (handlerThread) {
                        handlerThread.f9859p.obtainMessage(1, i6, 0).sendToTarget();
                        while (handlerThread.f9862s == null && handlerThread.f9861r == null && handlerThread.f9860q == null) {
                            try {
                                handlerThread.wait();
                            } catch (InterruptedException unused) {
                                z8 = true;
                            }
                        }
                    }
                    if (z8) {
                        Thread.currentThread().interrupt();
                    }
                    RuntimeException runtimeException = handlerThread.f9861r;
                    if (runtimeException == null) {
                        Error error = handlerThread.f9860q;
                        if (error == null) {
                            m mVar2 = handlerThread.f9862s;
                            mVar2.getClass();
                            this.f9845k1 = mVar2;
                        } else {
                            throw error;
                        }
                    } else {
                        throw runtimeException;
                    }
                }
            } else {
                int i7 = m.f9863r;
            }
            z6 = true;
            AbstractC0133a.i(z6);
            handlerThread = new HandlerThread("ExoPlayer:PlaceholderSurface");
            if (!z7) {
            }
            handlerThread.start();
            Handler handler2 = new Handler(handlerThread.getLooper(), handlerThread);
            handlerThread.f9859p = handler2;
            handlerThread.o = new V.h(handler2);
            synchronized (handlerThread) {
            }
        }
        return this.f9845k1;
    }

    public final boolean D0(i0.p pVar) {
        if (this.f9841f1 == null) {
            Surface surface = this.f9844j1;
            if (surface == null || !surface.isValid()) {
                if ((Build.VERSION.SDK_INT < 35 || !pVar.f6909h) && !L0(pVar)) {
                    return false;
                }
                return true;
            }
            return true;
        }
        return true;
    }

    @Override // i0.s
    public final C0175g E(i0.p pVar, C0123p c0123p, C0123p c0123p2) {
        int i6;
        C0175g b6 = pVar.b(c0123p, c0123p2);
        int i7 = b6.e;
        W.i iVar = this.f9838c1;
        iVar.getClass();
        if (c0123p2.f2632u > iVar.f3373a || c0123p2.f2633v > iVar.f3374b) {
            i7 |= 256;
        }
        if (B0(pVar, c0123p2) > iVar.f3375c) {
            i7 |= 64;
        }
        int i8 = i7;
        String str = pVar.f6903a;
        if (i8 != 0) {
            i6 = 0;
        } else {
            i6 = b6.f4162d;
        }
        return new C0175g(str, c0123p, c0123p2, i6, i8);
    }

    public final boolean E0(Y.f fVar) {
        if (l() || fVar.d(536870912)) {
            return true;
        }
        long j6 = this.f9828G1;
        if (j6 == -9223372036854775807L || j6 - (fVar.f3737u - this.f6937L0.f6919c) <= PipesConfigBase.DEFAULT_MAX_FOR_EMIT_BATCH) {
            return true;
        }
        return false;
    }

    @Override // i0.s
    public final i0.o F(IllegalStateException illegalStateException, i0.p pVar) {
        Surface surface = this.f9844j1;
        i0.o oVar = new i0.o(illegalStateException, pVar);
        System.identityHashCode(surface);
        if (surface != null) {
            surface.isValid();
        }
        return oVar;
    }

    public final void F0() {
        if (this.f9851q1 > 0) {
            this.f4113u.getClass();
            long elapsedRealtime = SystemClock.elapsedRealtime();
            long j6 = elapsedRealtime - this.f9850p1;
            int i6 = this.f9851q1;
            C0256h c0256h = this.f9831V0;
            Handler handler = c0256h.f5195a;
            if (handler != null) {
                handler.post(new y(c0256h, i6, j6));
            }
            this.f9851q1 = 0;
            this.f9850p1 = elapsedRealtime;
        }
    }

    public final void G0() {
        if (this.f9824B1) {
            int i6 = Build.VERSION.SDK_INT;
            i0.m mVar = this.f6957Z;
            if (mVar != null) {
                this.f9825D1 = new j(this, mVar);
                if (i6 >= 33) {
                    Bundle bundle = new Bundle();
                    bundle.putInt("tunnel-peek", 1);
                    mVar.b(bundle);
                }
            }
        }
    }

    public final void H0(long j6) {
        boolean z6;
        Surface surface;
        x0(j6);
        c0 c0Var = this.f9857y1;
        boolean equals = c0Var.equals(c0.f2533d);
        C0256h c0256h = this.f9831V0;
        if (!equals && !c0Var.equals(this.f9858z1)) {
            this.f9858z1 = c0Var;
            c0256h.b(c0Var);
        }
        this.f6935K0.e++;
        t tVar = this.f9834Y0;
        if (tVar.e != 3) {
            z6 = true;
        } else {
            z6 = false;
        }
        tVar.e = 3;
        tVar.f9897l.getClass();
        tVar.f9892g = V.C.N(SystemClock.elapsedRealtime());
        if (z6 && (surface = this.f9844j1) != null) {
            Handler handler = c0256h.f5195a;
            if (handler != null) {
                handler.post(new z(c0256h, surface, SystemClock.elapsedRealtime()));
            }
            this.f9847m1 = true;
        }
        c0(j6);
    }

    public final void I0(i0.m mVar, int i6, long j6) {
        Surface surface;
        Trace.beginSection("releaseOutputBuffer");
        mVar.e(j6, i6);
        Trace.endSection();
        this.f6935K0.e++;
        boolean z6 = false;
        this.f9852r1 = 0;
        if (this.f9841f1 == null) {
            c0 c0Var = this.f9857y1;
            boolean equals = c0Var.equals(c0.f2533d);
            C0256h c0256h = this.f9831V0;
            if (!equals && !c0Var.equals(this.f9858z1)) {
                this.f9858z1 = c0Var;
                c0256h.b(c0Var);
            }
            t tVar = this.f9834Y0;
            if (tVar.e != 3) {
                z6 = true;
            }
            tVar.e = 3;
            tVar.f9897l.getClass();
            tVar.f9892g = V.C.N(SystemClock.elapsedRealtime());
            if (z6 && (surface = this.f9844j1) != null) {
                Handler handler = c0256h.f5195a;
                if (handler != null) {
                    handler.post(new z(c0256h, surface, SystemClock.elapsedRealtime()));
                }
                this.f9847m1 = true;
            }
        }
    }

    public final void J0(Object obj) {
        Surface surface;
        Handler handler;
        if (obj instanceof Surface) {
            surface = (Surface) obj;
        } else {
            surface = null;
        }
        Surface surface2 = this.f9844j1;
        C0256h c0256h = this.f9831V0;
        if (surface2 != surface) {
            this.f9844j1 = surface;
            InterfaceC0826D interfaceC0826D = this.f9841f1;
            t tVar = this.f9834Y0;
            if (interfaceC0826D == null) {
                tVar.h(surface);
            }
            this.f9847m1 = false;
            int i6 = this.f4114v;
            i0.m mVar = this.f6957Z;
            if (mVar != null && this.f9841f1 == null) {
                i0.p pVar = this.f6964g0;
                pVar.getClass();
                boolean D02 = D0(pVar);
                int i7 = Build.VERSION.SDK_INT;
                if (D02 && !this.f9839d1) {
                    Surface C02 = C0(pVar);
                    if (C02 != null) {
                        mVar.k(C02);
                    } else if (i7 >= 35) {
                        mVar.i();
                    } else {
                        throw new IllegalStateException();
                    }
                } else {
                    i0();
                    T();
                }
            }
            if (surface != null) {
                c0 c0Var = this.f9858z1;
                if (c0Var != null) {
                    c0256h.b(c0Var);
                }
            } else {
                this.f9858z1 = null;
                InterfaceC0826D interfaceC0826D2 = this.f9841f1;
                if (interfaceC0826D2 != null) {
                    interfaceC0826D2.a();
                }
            }
            if (i6 == 2) {
                InterfaceC0826D interfaceC0826D3 = this.f9841f1;
                if (interfaceC0826D3 != null) {
                    interfaceC0826D3.m(true);
                } else {
                    tVar.c(true);
                }
            }
            G0();
            return;
        }
        if (surface != null) {
            c0 c0Var2 = this.f9858z1;
            if (c0Var2 != null) {
                c0256h.b(c0Var2);
            }
            Surface surface3 = this.f9844j1;
            if (surface3 != null && this.f9847m1 && (handler = c0256h.f5195a) != null) {
                handler.post(new z(c0256h, surface3, SystemClock.elapsedRealtime()));
            }
        }
    }

    public final boolean K0(long j6, long j7, boolean z6, boolean z7) {
        if (this.f9841f1 != null && this.f9830U0) {
            j7 -= -this.f9827F1;
        }
        if (j6 < -500000 && !z6) {
            Y y = this.f4115w;
            y.getClass();
            int o = y.o(j7 - this.y);
            if (o != 0) {
                PriorityQueue priorityQueue = this.f9837b1;
                if (z7) {
                    C0174f c0174f = this.f6935K0;
                    int i6 = c0174f.f4132d + o;
                    c0174f.f4132d = i6;
                    c0174f.f4133f += this.f9853s1;
                    c0174f.f4132d = priorityQueue.size() + i6;
                } else {
                    this.f6935K0.f4137j++;
                    N0(priorityQueue.size() + o, this.f9853s1);
                }
                if (J()) {
                    T();
                }
                InterfaceC0826D interfaceC0826D = this.f9841f1;
                if (interfaceC0826D != null) {
                    interfaceC0826D.e(false);
                }
                return true;
            }
        }
        return false;
    }

    @Override // i0.s
    public final int L(Y.f fVar) {
        if (Build.VERSION.SDK_INT >= 34) {
            if ((this.f9854t1 != null || this.f9824B1) && fVar.f3737u < this.f4117z && !E0(fVar)) {
                return 32;
            }
            return 0;
        }
        return 0;
    }

    public final boolean L0(i0.p pVar) {
        if (!this.f9824B1 && !y0(pVar.f6903a)) {
            if (!pVar.f6907f || m.b(this.T0)) {
                return true;
            }
            return false;
        }
        return false;
    }

    @Override // i0.s
    public final float M(float f6, C0123p c0123p, C0123p[] c0123pArr) {
        float f7;
        i0.p pVar;
        float f8 = -1.0f;
        for (C0123p c0123p2 : c0123pArr) {
            float f9 = c0123p2.y;
            if (f9 != -1.0f) {
                f8 = Math.max(f8, f9);
            }
        }
        if (f8 == -1.0f) {
            f7 = -1.0f;
        } else {
            f7 = f8 * f6;
        }
        if (this.f9854t1 != null && (pVar = this.f6964g0) != null) {
            int i6 = c0123p.f2632u;
            int i7 = c0123p.f2633v;
            float f10 = -3.4028235E38f;
            if (pVar.f6910i) {
                float f11 = pVar.f6913l;
                if (f11 != -3.4028235E38f && pVar.f6911j == i6 && pVar.f6912k == i7) {
                    f10 = f11;
                } else {
                    float f12 = 1024.0f;
                    if (pVar.g(i6, i7, 1024.0f)) {
                        f10 = 1024.0f;
                    } else {
                        f10 = 0.0f;
                        while (true) {
                            float f13 = f12 - f10;
                            if (Math.abs(f13) <= 5.0f) {
                                break;
                            }
                            float f14 = (f13 / 2.0f) + f10;
                            if (pVar.g(i6, i7, f14)) {
                                f10 = f14;
                            } else {
                                f12 = f14;
                            }
                        }
                    }
                    pVar.f6913l = f10;
                    pVar.f6911j = i6;
                    pVar.f6912k = i7;
                }
            }
            if (f7 != -1.0f) {
                return Math.max(f7, f10);
            }
            return f10;
        }
        return f7;
    }

    public final void M0(i0.m mVar, int i6) {
        Trace.beginSection("skipVideoBuffer");
        mVar.f(i6);
        Trace.endSection();
        this.f6935K0.f4133f++;
    }

    @Override // i0.s
    public final ArrayList N(i0.j jVar, C0123p c0123p, boolean z6) {
        List A02 = A0(this.T0, jVar, c0123p, z6, this.f9824B1);
        HashMap hashMap = i0.x.f6987a;
        ArrayList arrayList = new ArrayList(A02);
        Collections.sort(arrayList, new i0.t(new C0324M(c0123p, 4)));
        return arrayList;
    }

    public final void N0(int i6, int i7) {
        C0174f c0174f = this.f6935K0;
        c0174f.f4135h += i6;
        int i8 = i6 + i7;
        c0174f.f4134g += i8;
        this.f9851q1 += i8;
        int i9 = this.f9852r1 + i8;
        this.f9852r1 = i9;
        c0174f.f4136i = Math.max(i9, c0174f.f4136i);
        int i10 = this.f9832W0;
        if (i10 > 0 && this.f9851q1 >= i10) {
            F0();
        }
    }

    public final void O0(long j6) {
        C0174f c0174f = this.f6935K0;
        c0174f.f4138k += j6;
        c0174f.f4139l++;
        this.v1 += j6;
        this.w1++;
    }

    @Override // i0.s
    public final Q2.n P(i0.p pVar, C0123p c0123p, MediaCrypto mediaCrypto, float f6) {
        C0115h c0115h;
        int i6;
        W.i iVar;
        boolean z6;
        int i7;
        int i8;
        Point point;
        MediaCodecInfo.VideoCapabilities videoCapabilities;
        int i9;
        int i10;
        char c6;
        boolean z7;
        int i11;
        boolean z8;
        int z02;
        String str = pVar.f6905c;
        C0123p[] c0123pArr = this.f4116x;
        c0123pArr.getClass();
        int i12 = c0123p.f2632u;
        float f7 = c0123p.y;
        C0115h c0115h2 = c0123p.f2602D;
        int i13 = c0123p.f2633v;
        int B02 = B0(pVar, c0123p);
        if (c0123pArr.length == 1) {
            if (B02 != -1 && (z02 = z0(pVar, c0123p)) != -1) {
                B02 = Math.min((int) (B02 * 1.5f), z02);
            }
            iVar = new W.i(i12, i13, B02);
            c0115h = c0115h2;
            i6 = i13;
        } else {
            int length = c0123pArr.length;
            int i14 = i12;
            int i15 = i13;
            int i16 = 0;
            boolean z9 = false;
            while (i16 < length) {
                C0123p c0123p2 = c0123pArr[i16];
                C0123p[] c0123pArr2 = c0123pArr;
                if (c0115h2 != null && c0123p2.f2602D == null) {
                    C0122o a6 = c0123p2.a();
                    a6.f2565C = c0115h2;
                    c0123p2 = new C0123p(a6);
                }
                C0175g b6 = pVar.b(c0123p, c0123p2);
                int i17 = length;
                int i18 = c0123p2.f2633v;
                if (b6.f4162d != 0) {
                    int i19 = c0123p2.f2632u;
                    i10 = i16;
                    c6 = 65535;
                    if (i19 != -1 && i18 != -1) {
                        z7 = false;
                    } else {
                        z7 = true;
                    }
                    z9 |= z7;
                    i14 = Math.max(i14, i19);
                    i15 = Math.max(i15, i18);
                    B02 = Math.max(B02, B0(pVar, c0123p2));
                } else {
                    i10 = i16;
                    c6 = 65535;
                }
                length = i17;
                i16 = i10 + 1;
                c0123pArr = c0123pArr2;
            }
            if (z9) {
                AbstractC0133a.A("MediaCodecVideoRenderer", "Resolutions unknown. Codec max resolution: " + i14 + "x" + i15);
                if (i13 > i12) {
                    z6 = true;
                } else {
                    z6 = false;
                }
                if (z6) {
                    i7 = i13;
                } else {
                    i7 = i12;
                }
                boolean z10 = z6;
                if (z6) {
                    i8 = i12;
                } else {
                    i8 = i13;
                }
                float f8 = i8 / i7;
                int i20 = 0;
                while (true) {
                    c0115h = c0115h2;
                    if (i20 >= 9) {
                        break;
                    }
                    int i21 = f9820J1[i20];
                    int i22 = i20;
                    int i23 = (int) (i21 * f8);
                    if (i21 <= i7 || i23 <= i8) {
                        break;
                    }
                    if (!z10) {
                        i23 = i21;
                    }
                    if (!z10) {
                        i21 = i23;
                    }
                    int i24 = i8;
                    MediaCodecInfo.CodecCapabilities codecCapabilities = pVar.f6906d;
                    if (codecCapabilities == null || (videoCapabilities = codecCapabilities.getVideoCapabilities()) == null) {
                        i9 = i7;
                        point = null;
                    } else {
                        int widthAlignment = videoCapabilities.getWidthAlignment();
                        i9 = i7;
                        int heightAlignment = videoCapabilities.getHeightAlignment();
                        point = new Point(V.C.f(i23, widthAlignment) * widthAlignment, V.C.f(i21, heightAlignment) * heightAlignment);
                    }
                    if (point != null) {
                        i6 = i13;
                        if (pVar.g(point.x, point.y, f7)) {
                            break;
                        }
                    } else {
                        i6 = i13;
                    }
                    i20 = i22 + 1;
                    i13 = i6;
                    c0115h2 = c0115h;
                    i8 = i24;
                    i7 = i9;
                }
                i6 = i13;
                point = null;
                if (point != null) {
                    i14 = Math.max(i14, point.x);
                    i15 = Math.max(i15, point.y);
                    C0122o a7 = c0123p.a();
                    a7.f2593t = i14;
                    a7.f2594u = i15;
                    B02 = Math.max(B02, z0(pVar, new C0123p(a7)));
                    AbstractC0133a.A("MediaCodecVideoRenderer", "Codec max resolution adjusted to: " + i14 + "x" + i15);
                }
            } else {
                c0115h = c0115h2;
                i6 = i13;
            }
            iVar = new W.i(i14, i15, B02);
        }
        this.f9838c1 = iVar;
        if (this.f9824B1) {
            i11 = this.C1;
        } else {
            i11 = 0;
        }
        MediaFormat mediaFormat = new MediaFormat();
        mediaFormat.setString("mime", str);
        mediaFormat.setInteger("width", i12);
        mediaFormat.setInteger("height", i6);
        AbstractC0133a.z(mediaFormat, c0123p.f2628q);
        if (f7 != -1.0f) {
            mediaFormat.setFloat("frame-rate", f7);
        }
        AbstractC0133a.v(mediaFormat, "rotation-degrees", c0123p.f2636z);
        if (c0115h != null) {
            C0115h c0115h3 = c0115h;
            AbstractC0133a.v(mediaFormat, "color-transfer", c0115h3.f2547c);
            AbstractC0133a.v(mediaFormat, "color-standard", c0115h3.f2545a);
            AbstractC0133a.v(mediaFormat, "color-range", c0115h3.f2546b);
            byte[] bArr = c0115h3.f2548d;
            if (bArr != null) {
                mediaFormat.setByteBuffer("hdr-static-info", ByteBuffer.wrap(bArr));
            }
        }
        if ("video/dolby-vision".equals(c0123p.f2626n)) {
            HashMap hashMap = i0.x.f6987a;
            Pair c7 = V.d.c(c0123p);
            if (c7 != null) {
                AbstractC0133a.v(mediaFormat, "profile", ((Integer) c7.first).intValue());
            }
        }
        mediaFormat.setInteger("max-width", iVar.f3373a);
        mediaFormat.setInteger("max-height", iVar.f3374b);
        AbstractC0133a.v(mediaFormat, "max-input-size", iVar.f3375c);
        int i25 = Build.VERSION.SDK_INT;
        mediaFormat.setInteger(MimeTypesReaderMetKeys.MAGIC_PRIORITY_ATTR, 0);
        if (f6 != -1.0f) {
            mediaFormat.setFloat("operating-rate", f6);
        }
        if (this.f9833X0) {
            z8 = true;
            mediaFormat.setInteger("no-post-process", 1);
            mediaFormat.setInteger("auto-frc", 0);
        } else {
            z8 = true;
        }
        if (i11 != 0) {
            mediaFormat.setFeatureEnabled("tunneled-playback", z8);
            mediaFormat.setInteger("audio-session-id", i11);
        }
        if (i25 >= 35) {
            mediaFormat.setInteger("importance", Math.max(0, -this.f9823A1));
        }
        Surface C02 = C0(pVar);
        if (this.f9841f1 != null && !V.C.J(this.T0)) {
            mediaFormat.setInteger("allow-frame-drop", 0);
        }
        return new Q2.n(pVar, mediaFormat, c0123p, C02, mediaCrypto, null);
    }

    @Override // i0.s
    public final void Q(Y.f fVar) {
        if (this.f9840e1) {
            ByteBuffer byteBuffer = fVar.f3738v;
            byteBuffer.getClass();
            if (byteBuffer.remaining() >= 7) {
                byte b6 = byteBuffer.get();
                short s3 = byteBuffer.getShort();
                short s5 = byteBuffer.getShort();
                byte b7 = byteBuffer.get();
                byte b8 = byteBuffer.get();
                byteBuffer.position(0);
                if (b6 == -75 && s3 == 60 && s5 == 1 && b7 == 4) {
                    if (b8 == 0 || b8 == 1) {
                        byte[] bArr = new byte[byteBuffer.remaining()];
                        byteBuffer.get(bArr);
                        byteBuffer.position(0);
                        i0.m mVar = this.f6957Z;
                        mVar.getClass();
                        Bundle bundle = new Bundle();
                        bundle.putByteArray("hdr10-plus-info", bArr);
                        mVar.b(bundle);
                    }
                }
            }
        }
    }

    @Override // i0.s
    public final boolean V(C0123p c0123p) {
        InterfaceC0826D interfaceC0826D = this.f9841f1;
        if (interfaceC0826D != null && !interfaceC0826D.d()) {
            try {
                return this.f9841f1.g(c0123p);
            } catch (C0825C e) {
                throw g(e, c0123p, false, 7000);
            }
        }
        return true;
    }

    @Override // i0.s
    public final void W(Exception exc) {
        AbstractC0133a.n("MediaCodecVideoRenderer", "Video codec error", exc);
        C0256h c0256h = this.f9831V0;
        Handler handler = c0256h.f5195a;
        if (handler != null) {
            handler.post(new y(c0256h, exc, 1));
        }
    }

    @Override // i0.s
    public final void X(long j6, long j7, String str) {
        String str2;
        MediaCodecInfo.CodecProfileLevel[] codecProfileLevelArr;
        C0256h c0256h = this.f9831V0;
        Handler handler = c0256h.f5195a;
        if (handler != null) {
            str2 = str;
            handler.post(new y(c0256h, str2, j6, j7));
        } else {
            str2 = str;
        }
        this.f9839d1 = y0(str2);
        i0.p pVar = this.f6964g0;
        pVar.getClass();
        boolean z6 = false;
        if (Build.VERSION.SDK_INT >= 29 && "video/x-vnd.on2.vp9".equals(pVar.f6904b)) {
            MediaCodecInfo.CodecCapabilities codecCapabilities = pVar.f6906d;
            if (codecCapabilities == null || (codecProfileLevelArr = codecCapabilities.profileLevels) == null) {
                codecProfileLevelArr = new MediaCodecInfo.CodecProfileLevel[0];
            }
            int length = codecProfileLevelArr.length;
            int i6 = 0;
            while (true) {
                if (i6 >= length) {
                    break;
                }
                if (codecProfileLevelArr[i6].profile == 16384) {
                    z6 = true;
                    break;
                }
                i6++;
            }
        }
        this.f9840e1 = z6;
        G0();
    }

    @Override // i0.s
    public final void Y(String str) {
        C0256h c0256h = this.f9831V0;
        Handler handler = c0256h.f5195a;
        if (handler != null) {
            handler.post(new y(c0256h, str, 2));
        }
    }

    @Override // i0.s
    public final C0175g Z(C0179k c0179k) {
        C0175g Z5 = super.Z(c0179k);
        C0123p c0123p = (C0123p) c0179k.f4194q;
        c0123p.getClass();
        C0256h c0256h = this.f9831V0;
        Handler handler = c0256h.f5195a;
        if (handler != null) {
            handler.post(new org.apache.tika.pipes.async.b(c0256h, c0123p, Z5));
        }
        return Z5;
    }

    @Override // i0.s
    public final void a0(C0123p c0123p, MediaFormat mediaFormat) {
        boolean z6;
        int integer;
        int integer2;
        int i6;
        int i7;
        i0.m mVar = this.f6957Z;
        if (mVar != null) {
            mVar.g(this.f9848n1);
        }
        if (this.f9824B1) {
            i7 = c0123p.f2632u;
            i6 = c0123p.f2633v;
        } else {
            mediaFormat.getClass();
            if (mediaFormat.containsKey("crop-right") && mediaFormat.containsKey("crop-left") && mediaFormat.containsKey("crop-bottom") && mediaFormat.containsKey("crop-top")) {
                z6 = true;
            } else {
                z6 = false;
            }
            if (z6) {
                integer = (mediaFormat.getInteger("crop-right") - mediaFormat.getInteger("crop-left")) + 1;
            } else {
                integer = mediaFormat.getInteger("width");
            }
            if (z6) {
                integer2 = (mediaFormat.getInteger("crop-bottom") - mediaFormat.getInteger("crop-top")) + 1;
            } else {
                integer2 = mediaFormat.getInteger("height");
            }
            int i8 = integer;
            i6 = integer2;
            i7 = i8;
        }
        float f6 = c0123p.f2599A;
        int i9 = c0123p.f2636z;
        if (i9 == 90 || i9 == 270) {
            f6 = 1.0f / f6;
            int i10 = i6;
            i6 = i7;
            i7 = i10;
        }
        this.f9857y1 = new c0(f6, i7, i6);
        InterfaceC0826D interfaceC0826D = this.f9841f1;
        if (interfaceC0826D != null && this.H1) {
            C0122o a6 = c0123p.a();
            a6.f2593t = i7;
            a6.f2594u = i6;
            a6.f2598z = f6;
            C0123p c0123p2 = new C0123p(a6);
            int i11 = this.f9842h1;
            List list = this.f9843i1;
            if (list == null) {
                G g2 = I.f699p;
                list = Z.f721s;
            }
            interfaceC0826D.l(c0123p2, this.f6937L0.f6918b, i11, list);
            this.f9842h1 = 2;
        } else {
            this.f9834Y0.g(c0123p.y);
        }
        this.H1 = false;
    }

    @Override // i0.s
    public final void c0(long j6) {
        super.c0(j6);
        if (!this.f9824B1) {
            this.f9853s1--;
        }
    }

    @Override // Z.AbstractC0173e, Z.h0
    public final void d(int i6, Object obj) {
        boolean z6;
        boolean z7 = true;
        if (i6 != 1) {
            if (i6 != 7) {
                if (i6 != 10) {
                    if (i6 != 4) {
                        if (i6 != 5) {
                            if (i6 != 13) {
                                if (i6 != 14) {
                                    switch (i6) {
                                        case 16:
                                            obj.getClass();
                                            this.f9823A1 = ((Integer) obj).intValue();
                                            i0.m mVar = this.f6957Z;
                                            if (mVar != null && Build.VERSION.SDK_INT >= 35) {
                                                Bundle bundle = new Bundle();
                                                bundle.putInt("importance", Math.max(0, -this.f9823A1));
                                                mVar.b(bundle);
                                                return;
                                            }
                                            return;
                                        case PipesServer.TIMEOUT_EXIT_CODE /* 17 */:
                                            Surface surface = this.f9844j1;
                                            J0(null);
                                            obj.getClass();
                                            ((k) obj).d(1, surface);
                                            return;
                                        case 18:
                                            if (this.f9854t1 != null) {
                                                z6 = true;
                                            } else {
                                                z6 = false;
                                            }
                                            n0 n0Var = (n0) obj;
                                            this.f9854t1 = n0Var;
                                            if (n0Var == null) {
                                                z7 = false;
                                            }
                                            if (z6 != z7) {
                                                v0(this.f6958a0);
                                                return;
                                            }
                                            return;
                                        default:
                                            if (i6 == 11) {
                                                Z.G g2 = (Z.G) obj;
                                                g2.getClass();
                                                this.f6952U = g2;
                                                return;
                                            }
                                            return;
                                    }
                                }
                                obj.getClass();
                                V.w wVar = (V.w) obj;
                                if (wVar.f3124a != 0 && wVar.f3125b != 0) {
                                    this.f9846l1 = wVar;
                                    InterfaceC0826D interfaceC0826D = this.f9841f1;
                                    if (interfaceC0826D != null) {
                                        Surface surface2 = this.f9844j1;
                                        AbstractC0133a.j(surface2);
                                        interfaceC0826D.f(surface2, wVar);
                                        return;
                                    }
                                    return;
                                }
                                return;
                            }
                            obj.getClass();
                            List list = (List) obj;
                            if (list.equals(b0.f2532a)) {
                                InterfaceC0826D interfaceC0826D2 = this.f9841f1;
                                if (interfaceC0826D2 != null && interfaceC0826D2.d()) {
                                    this.f9841f1.q();
                                    return;
                                }
                                return;
                            }
                            this.f9843i1 = list;
                            InterfaceC0826D interfaceC0826D3 = this.f9841f1;
                            if (interfaceC0826D3 != null) {
                                interfaceC0826D3.h(list);
                                return;
                            }
                            return;
                        }
                        obj.getClass();
                        int intValue = ((Integer) obj).intValue();
                        this.f9849o1 = intValue;
                        InterfaceC0826D interfaceC0826D4 = this.f9841f1;
                        if (interfaceC0826D4 != null) {
                            interfaceC0826D4.v(intValue);
                            return;
                        }
                        w wVar2 = this.f9834Y0.f9888b;
                        if (wVar2.f9916j != intValue) {
                            wVar2.f9916j = intValue;
                            wVar2.d(true);
                            return;
                        }
                        return;
                    }
                    obj.getClass();
                    int intValue2 = ((Integer) obj).intValue();
                    this.f9848n1 = intValue2;
                    i0.m mVar2 = this.f6957Z;
                    if (mVar2 != null) {
                        mVar2.g(intValue2);
                        return;
                    }
                    return;
                }
                obj.getClass();
                int intValue3 = ((Integer) obj).intValue();
                if (this.C1 != intValue3) {
                    this.C1 = intValue3;
                    if (this.f9824B1) {
                        i0();
                        return;
                    }
                    return;
                }
                return;
            }
            obj.getClass();
            s sVar = (s) obj;
            this.f9826E1 = sVar;
            InterfaceC0826D interfaceC0826D5 = this.f9841f1;
            if (interfaceC0826D5 != null) {
                interfaceC0826D5.p(sVar);
                return;
            }
            return;
        }
        J0(obj);
    }

    @Override // i0.s
    public final void d0() {
        InterfaceC0826D interfaceC0826D = this.f9841f1;
        if (interfaceC0826D != null) {
            interfaceC0826D.t();
            if (this.f9827F1 == -9223372036854775807L) {
                this.f9827F1 = this.f6937L0.f6918b;
            }
            this.f9841f1.r(-this.f9827F1);
        } else {
            this.f9834Y0.f(2);
        }
        this.H1 = true;
        G0();
    }

    @Override // i0.s
    public final void e0(Y.f fVar) {
        this.f9829I1 = 0;
        int L6 = L(fVar);
        if ((Build.VERSION.SDK_INT < 34 || (L6 & 32) == 0) && !this.f9824B1) {
            this.f9853s1++;
        }
    }

    @Override // i0.s
    public final boolean g0(long j6, long j7, i0.m mVar, ByteBuffer byteBuffer, int i6, int i7, int i8, long j8, boolean z6, boolean z7, C0123p c0123p) {
        int i9;
        mVar.getClass();
        long j9 = j8 - this.f6937L0.f6919c;
        int i10 = 0;
        while (true) {
            PriorityQueue priorityQueue = this.f9837b1;
            Long l6 = (Long) priorityQueue.peek();
            if (l6 == null || l6.longValue() >= j8) {
                break;
            }
            i10++;
            priorityQueue.poll();
        }
        N0(i10, 0);
        InterfaceC0826D interfaceC0826D = this.f9841f1;
        if (interfaceC0826D != null) {
            if (z6 && !z7) {
                M0(mVar, i6);
                return true;
            }
            return interfaceC0826D.s(j8, new C0834h(this, mVar, i6, j9));
        }
        int a6 = this.f9834Y0.a(j8, j6, j7, this.f6937L0.f6918b, z6, z7, this.f9835Z0);
        C4.D d6 = this.f9835Z0;
        if (a6 != 0) {
            if (a6 != 1) {
                if (a6 != 2) {
                    if (a6 != 3) {
                        if (a6 == 4 || a6 == 5) {
                            return false;
                        }
                        throw new IllegalStateException(String.valueOf(a6));
                    }
                    M0(mVar, i6);
                    O0(d6.f380a);
                    return true;
                }
                Trace.beginSection("dropVideoBuffer");
                mVar.f(i6);
                Trace.endSection();
                N0(0, 1);
                O0(d6.f380a);
                return true;
            }
            long j10 = d6.f381b;
            long j11 = d6.f380a;
            if (j10 == this.f9856x1) {
                M0(mVar, i6);
            } else {
                s sVar = this.f9826E1;
                if (sVar != null) {
                    i9 = i6;
                    sVar.a(j9, j10, c0123p, this.f6959b0);
                } else {
                    i9 = i6;
                }
                I0(mVar, i9, j10);
            }
            O0(j11);
            this.f9856x1 = j10;
            return true;
        }
        this.f4113u.getClass();
        long nanoTime = System.nanoTime();
        s sVar2 = this.f9826E1;
        if (sVar2 != null) {
            sVar2.a(j9, nanoTime, c0123p, this.f6959b0);
        }
        I0(mVar, i6, nanoTime);
        O0(d6.f380a);
        return true;
    }

    @Override // Z.AbstractC0173e
    public final void h() {
        InterfaceC0826D interfaceC0826D = this.f9841f1;
        if (interfaceC0826D != null) {
            int i6 = this.f9842h1;
            if (i6 != 0 && i6 != 1) {
                interfaceC0826D.u();
                return;
            } else {
                this.f9842h1 = 0;
                return;
            }
        }
        t tVar = this.f9834Y0;
        if (tVar.e == 0) {
            tVar.e = 1;
        }
    }

    @Override // i0.s
    public final void j0() {
        InterfaceC0826D interfaceC0826D = this.f9841f1;
        if (interfaceC0826D != null) {
            interfaceC0826D.t();
        }
    }

    @Override // Z.AbstractC0173e
    public final String k() {
        return "MediaCodecVideoRenderer";
    }

    @Override // i0.s
    public final void l0() {
        super.l0();
        this.f9837b1.clear();
        this.f9853s1 = 0;
        this.f9829I1 = 0;
        this.f9855u1 = false;
    }

    @Override // Z.AbstractC0173e
    public final boolean m() {
        if (this.f6928G0) {
            InterfaceC0826D interfaceC0826D = this.f9841f1;
            if (interfaceC0826D == null || interfaceC0826D.b()) {
                return true;
            }
            return false;
        }
        return false;
    }

    @Override // i0.s, Z.AbstractC0173e
    public final boolean o() {
        boolean o = super.o();
        InterfaceC0826D interfaceC0826D = this.f9841f1;
        if (interfaceC0826D != null) {
            return interfaceC0826D.n(o);
        }
        if (o && (this.f6957Z == null || this.f9824B1)) {
            return true;
        }
        return this.f9834Y0.b(o);
    }

    @Override // i0.s, Z.AbstractC0173e
    public final void p() {
        C0256h c0256h = this.f9831V0;
        this.f9858z1 = null;
        this.f9828G1 = -9223372036854775807L;
        G0();
        this.f9847m1 = false;
        this.f9825D1 = null;
        this.f9855u1 = true;
        try {
            super.p();
            C0174f c0174f = this.f6935K0;
            c0256h.getClass();
            synchronized (c0174f) {
            }
            Handler handler = c0256h.f5195a;
            if (handler != null) {
                handler.post(new org.apache.tika.pipes.async.b(c0256h, c0174f, 7));
            }
            c0256h.b(c0.f2533d);
        } catch (Throwable th) {
            C0174f c0174f2 = this.f6935K0;
            c0256h.getClass();
            synchronized (c0174f2) {
                Handler handler2 = c0256h.f5195a;
                if (handler2 != null) {
                    handler2.post(new org.apache.tika.pipes.async.b(c0256h, c0174f2, 7));
                }
                c0256h.b(c0.f2533d);
                throw th;
            }
        }
    }

    @Override // i0.s
    public final boolean p0(Y.f fVar) {
        boolean z6;
        boolean z7 = false;
        if (!E0(fVar)) {
            if (fVar.f3737u < this.f4117z) {
                z6 = true;
            } else {
                z6 = false;
            }
            if (z6 && !fVar.d(268435456)) {
                if (fVar.d(67108864)) {
                    fVar.f();
                    z7 = true;
                }
                if (z7) {
                    if (z6) {
                        this.f6935K0.f4132d++;
                    } else {
                        this.f9837b1.add(Long.valueOf(fVar.f3737u));
                        this.f9829I1++;
                    }
                }
                return z7;
            }
        }
        return false;
    }

    /* JADX WARN: Type inference failed for: r7v1, types: [Z.f, java.lang.Object] */
    @Override // Z.AbstractC0173e
    public final void q(boolean z6, boolean z7) {
        boolean z8;
        InterfaceC0826D interfaceC0826D;
        this.f6935K0 = new Object();
        l0 l0Var = this.f4110r;
        l0Var.getClass();
        boolean z9 = l0Var.f4206b;
        if (z9 && this.C1 == 0) {
            z8 = false;
        } else {
            z8 = true;
        }
        AbstractC0133a.i(z8);
        if (this.f9824B1 != z9) {
            this.f9824B1 = z9;
            i0();
        }
        C0174f c0174f = this.f6935K0;
        C0256h c0256h = this.f9831V0;
        Handler handler = c0256h.f5195a;
        if (handler != null) {
            handler.post(new y(c0256h, c0174f, 5));
        }
        boolean z10 = this.g1;
        t tVar = this.f9834Y0;
        if (!z10) {
            if (this.f9843i1 != null && this.f9841f1 == null) {
                D4.f fVar = new D4.f(this.T0, tVar);
                fVar.o = true;
                V.x xVar = this.f4113u;
                xVar.getClass();
                fVar.f667t = xVar;
                AbstractC0133a.i(!fVar.f663p);
                if (((p) fVar.f666s) == null) {
                    fVar.f666s = new p();
                }
                r rVar = new r(fVar);
                fVar.f663p = true;
                rVar.o = 1;
                SparseArray sparseArray = rVar.f9876c;
                if (V.C.k(sparseArray, 0)) {
                    interfaceC0826D = (InterfaceC0826D) sparseArray.get(0);
                } else {
                    n nVar = new n(rVar, rVar.f9874a);
                    rVar.f9879g.add(nVar);
                    sparseArray.put(0, nVar);
                    interfaceC0826D = nVar;
                }
                this.f9841f1 = interfaceC0826D;
            }
            this.g1 = true;
        }
        InterfaceC0826D interfaceC0826D2 = this.f9841f1;
        if (interfaceC0826D2 != null) {
            interfaceC0826D2.k(new C0833g(this));
            s sVar = this.f9826E1;
            if (sVar != null) {
                this.f9841f1.p(sVar);
            }
            if (this.f9844j1 != null && !this.f9846l1.equals(V.w.f3123c)) {
                this.f9841f1.f(this.f9844j1, this.f9846l1);
            }
            this.f9841f1.v(this.f9849o1);
            this.f9841f1.w(this.f6955X);
            List list = this.f9843i1;
            if (list != null) {
                this.f9841f1.h(list);
            }
            this.f9842h1 = !z7 ? 1 : 0;
            this.f6943O0 = true;
            return;
        }
        V.x xVar2 = this.f4113u;
        xVar2.getClass();
        tVar.f9897l = xVar2;
        tVar.f(!z7 ? 1 : 0);
    }

    @Override // i0.s
    public final boolean q0() {
        C0123p c0123p = this.f6958a0;
        if (this.f9854t1 != null && !this.f9855u1 && !this.f9824B1) {
            if ((c0123p == null || c0123p.f2627p <= 0) && !this.f6945P0 && this.E0 == -9223372036854775807L) {
                return false;
            }
            return true;
        }
        return true;
    }

    @Override // i0.s, Z.AbstractC0173e
    public final void r(long j6, boolean z6) {
        InterfaceC0826D interfaceC0826D = this.f9841f1;
        if (interfaceC0826D != null && !z6) {
            interfaceC0826D.e(true);
        }
        super.r(j6, z6);
        InterfaceC0826D interfaceC0826D2 = this.f9841f1;
        t tVar = this.f9834Y0;
        if (interfaceC0826D2 == null) {
            w wVar = tVar.f9888b;
            wVar.f9919m = 0L;
            wVar.f9921p = -1L;
            wVar.f9920n = -1L;
            tVar.f9893h = -9223372036854775807L;
            tVar.f9891f = -9223372036854775807L;
            tVar.e = Math.min(tVar.e, 1);
            tVar.f9894i = -9223372036854775807L;
        }
        if (z6) {
            InterfaceC0826D interfaceC0826D3 = this.f9841f1;
            if (interfaceC0826D3 != null) {
                interfaceC0826D3.m(false);
            } else {
                tVar.c(false);
            }
        }
        G0();
        this.f9852r1 = 0;
    }

    @Override // i0.s
    public final boolean r0(i0.p pVar) {
        return D0(pVar);
    }

    @Override // Z.AbstractC0173e
    public final void s() {
        InterfaceC0826D interfaceC0826D = this.f9841f1;
        if (interfaceC0826D != null && this.f9830U0) {
            interfaceC0826D.release();
        }
    }

    @Override // i0.s
    public final boolean s0() {
        i0.p pVar = this.f6964g0;
        if (this.f9841f1 != null && pVar != null) {
            String str = pVar.f6903a;
            if (str.equals("c2.mtk.avc.decoder") || str.equals("c2.mtk.hevc.decoder")) {
                return true;
            }
        }
        return super.s0();
    }

    @Override // Z.AbstractC0173e
    public final void t() {
        try {
            try {
                this.f6977t0 = false;
                k0();
                i0();
                X2.b bVar = this.f6951T;
                if (bVar != null) {
                    bVar.C(null);
                }
                this.f6951T = null;
            } catch (Throwable th) {
                X2.b bVar2 = this.f6951T;
                if (bVar2 != null) {
                    bVar2.C(null);
                }
                this.f6951T = null;
                throw th;
            }
        } finally {
            this.g1 = false;
            this.f9827F1 = -9223372036854775807L;
            m mVar = this.f9845k1;
            if (mVar != null) {
                mVar.release();
                this.f9845k1 = null;
            }
        }
    }

    @Override // Z.AbstractC0173e
    public final void u() {
        this.f9851q1 = 0;
        this.f4113u.getClass();
        this.f9850p1 = SystemClock.elapsedRealtime();
        this.v1 = 0L;
        this.w1 = 0;
        InterfaceC0826D interfaceC0826D = this.f9841f1;
        if (interfaceC0826D != null) {
            interfaceC0826D.o();
        } else {
            this.f9834Y0.d();
        }
    }

    @Override // i0.s
    public final int u0(i0.j jVar, C0123p c0123p) {
        boolean z6;
        boolean z7;
        int i6;
        int i7;
        int i8;
        int i9;
        int i10 = 0;
        if (!F.m(c0123p.f2626n)) {
            return AbstractC0173e.f(0, 0, 0, 0);
        }
        if (c0123p.f2629r != null) {
            z6 = true;
        } else {
            z6 = false;
        }
        Context context = this.T0;
        List A02 = A0(context, jVar, c0123p, z6, false);
        if (z6 && A02.isEmpty()) {
            A02 = A0(context, jVar, c0123p, false, false);
        }
        if (A02.isEmpty()) {
            return AbstractC0173e.f(1, 0, 0, 0);
        }
        int i11 = c0123p.f2612O;
        if (i11 != 0 && i11 != 2) {
            return AbstractC0173e.f(2, 0, 0, 0);
        }
        i0.p pVar = (i0.p) A02.get(0);
        boolean e = pVar.e(c0123p);
        if (!e) {
            for (int i12 = 1; i12 < A02.size(); i12++) {
                i0.p pVar2 = (i0.p) A02.get(i12);
                if (pVar2.e(c0123p)) {
                    z7 = false;
                    e = true;
                    pVar = pVar2;
                    break;
                }
            }
        }
        z7 = true;
        int i13 = 4;
        if (e) {
            i6 = 4;
        } else {
            i6 = 3;
        }
        if (pVar.f(c0123p)) {
            i7 = 16;
        } else {
            i7 = 8;
        }
        if (pVar.f6908g) {
            i8 = 64;
        } else {
            i8 = 0;
        }
        if (z7) {
            i9 = 128;
        } else {
            i9 = 0;
        }
        if (Build.VERSION.SDK_INT >= 26 && "video/dolby-vision".equals(c0123p.f2626n) && !AbstractC0759a.b(context)) {
            i9 = 256;
        }
        if (e) {
            List A03 = A0(context, jVar, c0123p, z6, true);
            if (!A03.isEmpty()) {
                HashMap hashMap = i0.x.f6987a;
                ArrayList arrayList = new ArrayList(A03);
                Collections.sort(arrayList, new i0.t(new C0324M(c0123p, i13)));
                i0.p pVar3 = (i0.p) arrayList.get(0);
                if (pVar3.e(c0123p) && pVar3.f(c0123p)) {
                    i10 = 32;
                }
            }
        }
        return i6 | i7 | i10 | i8 | i9;
    }

    @Override // Z.AbstractC0173e
    public final void v() {
        F0();
        int i6 = this.w1;
        if (i6 != 0) {
            long j6 = this.v1;
            C0256h c0256h = this.f9831V0;
            Handler handler = c0256h.f5195a;
            if (handler != null) {
                handler.post(new y(c0256h, j6, i6));
            }
            this.v1 = 0L;
            this.w1 = 0;
        }
        InterfaceC0826D interfaceC0826D = this.f9841f1;
        if (interfaceC0826D != null) {
            interfaceC0826D.i();
        } else {
            this.f9834Y0.e();
        }
    }

    @Override // i0.s, Z.AbstractC0173e
    public final void w(C0123p[] c0123pArr, long j6, long j7, C0678A c0678a) {
        super.w(c0123pArr, j6, j7, c0678a);
        S s3 = this.f4105D;
        if (s3.p()) {
            this.f9828G1 = -9223372036854775807L;
        } else {
            c0678a.getClass();
            this.f9828G1 = s3.g(c0678a.f8898a, new P()).f2456d;
        }
    }

    @Override // i0.s, Z.AbstractC0173e
    public final void y(long j6, long j7) {
        InterfaceC0826D interfaceC0826D = this.f9841f1;
        if (interfaceC0826D != null) {
            try {
                interfaceC0826D.j(j6, j7);
            } catch (C0825C e) {
                throw g(e, e.o, false, 7001);
            }
        }
        super.y(j6, j7);
    }
}
