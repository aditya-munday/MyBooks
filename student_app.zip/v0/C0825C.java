package v0;

import S.C0123p;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* renamed from: v0.C, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0825C extends Exception {
    public final C0123p o;

    public C0825C(Exception exc, C0123p c0123p) {
        super(exc);
        this.o = c0123p;
    }
}
