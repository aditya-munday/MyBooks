package v0;

import V.AbstractC0133a;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.Looper;
import android.os.Message;
import android.view.Choreographer;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* loaded from: classes.dex */
public final class v implements Choreographer.FrameCallback, Handler.Callback {

    /* renamed from: s, reason: collision with root package name */
    public static final v f9904s = new v();
    public volatile long o = -9223372036854775807L;

    /* renamed from: p, reason: collision with root package name */
    public final Handler f9905p;

    /* renamed from: q, reason: collision with root package name */
    public Choreographer f9906q;

    /* renamed from: r, reason: collision with root package name */
    public int f9907r;

    public v() {
        HandlerThread handlerThread = new HandlerThread("ExoPlayer:FrameReleaseChoreographer");
        handlerThread.start();
        Looper looper = handlerThread.getLooper();
        String str = V.C.f3053a;
        Handler handler = new Handler(looper, this);
        this.f9905p = handler;
        handler.sendEmptyMessage(1);
    }

    @Override // android.view.Choreographer.FrameCallback
    public final void doFrame(long j6) {
        this.o = j6;
        Choreographer choreographer = this.f9906q;
        choreographer.getClass();
        choreographer.postFrameCallbackDelayed(this, 500L);
    }

    @Override // android.os.Handler.Callback
    public final boolean handleMessage(Message message) {
        int i6 = message.what;
        if (i6 != 1) {
            if (i6 != 2) {
                if (i6 != 3) {
                    return false;
                }
                Choreographer choreographer = this.f9906q;
                if (choreographer != null) {
                    int i7 = this.f9907r - 1;
                    this.f9907r = i7;
                    if (i7 == 0) {
                        choreographer.removeFrameCallback(this);
                        this.o = -9223372036854775807L;
                    }
                }
                return true;
            }
            Choreographer choreographer2 = this.f9906q;
            if (choreographer2 != null) {
                int i8 = this.f9907r + 1;
                this.f9907r = i8;
                if (i8 == 1) {
                    choreographer2.postFrameCallback(this);
                }
            }
            return true;
        }
        try {
            this.f9906q = Choreographer.getInstance();
        } catch (RuntimeException e) {
            AbstractC0133a.B("VideoFrameReleaseHelper", "Vsync sampling disabled due to platform error", e);
        }
        return true;
    }
}
