package v0;

import android.content.Context;
import android.os.Handler;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* renamed from: v0.i, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0835i {

    /* renamed from: a, reason: collision with root package name */
    public final Context f9813a;

    /* renamed from: b, reason: collision with root package name */
    public boolean f9814b;

    /* renamed from: c, reason: collision with root package name */
    public i0.l f9815c;

    /* renamed from: d, reason: collision with root package name */
    public long f9816d;
    public Handler e;

    /* renamed from: f, reason: collision with root package name */
    public Z.B f9817f;

    /* renamed from: g, reason: collision with root package name */
    public int f9818g;

    public C0835i(Context context) {
        this.f9813a = context;
        this.f9815c = new V4.a(context);
    }
}
