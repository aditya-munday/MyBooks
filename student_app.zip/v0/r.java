package v0;

import E2.G;
import E2.I;
import E2.Z;
import S.C0122o;
import V.AbstractC0133a;
import android.content.Context;
import android.util.Pair;
import android.util.SparseArray;
import i1.ExecutorC0474b;
import java.util.concurrent.CopyOnWriteArraySet;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* loaded from: classes.dex */
public final class r {

    /* renamed from: p, reason: collision with root package name */
    public static final ExecutorC0474b f9873p = new ExecutorC0474b(1);

    /* renamed from: a, reason: collision with root package name */
    public final Context f9874a;

    /* renamed from: b, reason: collision with root package name */
    public final p f9875b;

    /* renamed from: c, reason: collision with root package name */
    public final SparseArray f9876c;

    /* renamed from: d, reason: collision with root package name */
    public final boolean f9877d;
    public final C0829c e;

    /* renamed from: f, reason: collision with root package name */
    public final V.x f9878f;

    /* renamed from: g, reason: collision with root package name */
    public final CopyOnWriteArraySet f9879g;

    /* renamed from: h, reason: collision with root package name */
    public R0.e f9880h = new R0.e();

    /* renamed from: i, reason: collision with root package name */
    public V.z f9881i;

    /* renamed from: j, reason: collision with root package name */
    public Pair f9882j;

    /* renamed from: k, reason: collision with root package name */
    public int f9883k;

    /* renamed from: l, reason: collision with root package name */
    public int f9884l;

    /* renamed from: m, reason: collision with root package name */
    public long f9885m;

    /* renamed from: n, reason: collision with root package name */
    public boolean f9886n;
    public int o;

    public r(D4.f fVar) {
        this.f9874a = (Context) fVar.f664q;
        p pVar = (p) fVar.f666s;
        AbstractC0133a.j(pVar);
        this.f9875b = pVar;
        this.f9876c = new SparseArray();
        G g2 = I.f699p;
        Z z6 = Z.f721s;
        this.f9877d = fVar.o;
        V.x xVar = (V.x) fVar.f667t;
        this.f9878f = xVar;
        this.e = new C0829c((t) fVar.f665r, xVar);
        this.f9879g = new CopyOnWriteArraySet();
        new C0122o().a();
        this.f9885m = -9223372036854775807L;
        this.o = -1;
        this.f9884l = 0;
    }
}
