package v0;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* renamed from: v0.h, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0834h {

    /* renamed from: a, reason: collision with root package name */
    public final /* synthetic */ i0.m f9810a;

    /* renamed from: b, reason: collision with root package name */
    public final /* synthetic */ int f9811b;

    /* renamed from: c, reason: collision with root package name */
    public final /* synthetic */ k f9812c;

    public C0834h(k kVar, i0.m mVar, int i6, long j6) {
        this.f9812c = kVar;
        this.f9810a = mVar;
        this.f9811b = i6;
    }
}
