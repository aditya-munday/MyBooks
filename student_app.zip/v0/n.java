package v0;

import E2.G;
import E2.I;
import E2.Z;
import S.C0115h;
import S.C0122o;
import S.C0123p;
import V.AbstractC0133a;
import android.content.Context;
import android.os.Build;
import android.os.Looper;
import android.util.Pair;
import android.view.Surface;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.Executor;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* loaded from: classes.dex */
public final class n implements InterfaceC0826D {

    /* renamed from: a, reason: collision with root package name */
    public I f9867a;

    /* renamed from: b, reason: collision with root package name */
    public C0123p f9868b;

    /* renamed from: c, reason: collision with root package name */
    public long f9869c;

    /* renamed from: d, reason: collision with root package name */
    public long f9870d;
    public Executor e;

    /* renamed from: f, reason: collision with root package name */
    public final /* synthetic */ r f9871f;

    public n(r rVar, Context context) {
        this.f9871f = rVar;
        V.C.J(context);
        G g2 = I.f699p;
        this.f9867a = Z.f721s;
        this.f9870d = -9223372036854775807L;
        this.e = r.f9873p;
    }

    @Override // v0.InterfaceC0826D
    public final void a() {
        int i6 = V.w.f3123c.f3124a;
        this.f9871f.f9882j = null;
    }

    @Override // v0.InterfaceC0826D
    public final boolean b() {
        return false;
    }

    @Override // v0.InterfaceC0826D
    public final Surface c() {
        AbstractC0133a.i(false);
        throw null;
    }

    @Override // v0.InterfaceC0826D
    public final boolean d() {
        return false;
    }

    @Override // v0.InterfaceC0826D
    public final void e(boolean z6) {
        this.f9870d = -9223372036854775807L;
        r rVar = this.f9871f;
        C0829c c0829c = rVar.e;
        if (rVar.f9884l == 1) {
            rVar.f9883k++;
            c0829c.e(z6);
            while (rVar.f9880h.f() > 1) {
                rVar.f9880h.c();
            }
            if (rVar.f9880h.f() != 1) {
                rVar.f9885m = -9223372036854775807L;
                rVar.f9886n = false;
                V.z zVar = rVar.f9881i;
                AbstractC0133a.j(zVar);
                zVar.c(new G4.d(rVar, 24));
                return;
            }
            ((q) rVar.f9880h.c()).getClass();
            throw null;
        }
    }

    @Override // v0.InterfaceC0826D
    public final void f(Surface surface, V.w wVar) {
        r rVar = this.f9871f;
        Pair pair = rVar.f9882j;
        if (pair != null && ((Surface) pair.first).equals(surface) && ((V.w) rVar.f9882j.second).equals(wVar)) {
            return;
        }
        rVar.f9882j = Pair.create(surface, wVar);
        int i6 = wVar.f3124a;
    }

    @Override // v0.InterfaceC0826D
    public final boolean g(C0123p c0123p) {
        boolean z6;
        boolean z7 = true;
        AbstractC0133a.i(!false);
        r rVar = this.f9871f;
        if (rVar.f9884l == 0) {
            z6 = true;
        } else {
            z6 = false;
        }
        AbstractC0133a.i(z6);
        C0115h c0115h = c0123p.f2602D;
        if (c0115h == null || !c0115h.d()) {
            c0115h = C0115h.f2544h;
        }
        int i6 = c0115h.f2547c;
        if (i6 == 7) {
            try {
                int i7 = Build.VERSION.SDK_INT;
                if (i7 < 34 && i7 >= 33 && AbstractC0133a.t("EGL_EXT_gl_colorspace_bt2020_pq")) {
                    V.x xVar = rVar.f9878f;
                    Looper myLooper = Looper.myLooper();
                    AbstractC0133a.j(myLooper);
                    rVar.f9881i = xVar.a(myLooper, null);
                    rVar.f9875b.a();
                    throw null;
                }
            } catch (V.i e) {
                throw new C0825C(e, c0123p);
            }
        }
        if (i6 == 6) {
            if (Build.VERSION.SDK_INT < 33 || !AbstractC0133a.t("EGL_EXT_gl_colorspace_bt2020_pq")) {
                z7 = false;
            }
        } else if (i6 == 7) {
            z7 = AbstractC0133a.t("EGL_EXT_gl_colorspace_bt2020_hlg");
        }
        if (!z7 && Build.VERSION.SDK_INT >= 29) {
            Locale locale = Locale.US;
            AbstractC0133a.A("PlaybackVidGraphWrapper", "Color transfer " + i6 + " is not supported. Falling back to OpenGl tone mapping.");
            C0115h c0115h2 = C0115h.f2544h;
        }
        V.x xVar2 = rVar.f9878f;
        Looper myLooper2 = Looper.myLooper();
        AbstractC0133a.j(myLooper2);
        rVar.f9881i = xVar2.a(myLooper2, null);
        rVar.f9875b.a();
        throw null;
    }

    @Override // v0.InterfaceC0826D
    public final void h(List list) {
        if (!this.f9867a.equals(list)) {
            this.f9867a = I.u(list);
            C0123p c0123p = this.f9868b;
            if (c0123p == null) {
                return;
            }
            C0122o a6 = c0123p.a();
            C0115h c0115h = c0123p.f2602D;
            if (c0115h == null || !c0115h.d()) {
                c0115h = C0115h.f2544h;
            }
            a6.f2565C = c0115h;
            a6.a();
            throw null;
        }
    }

    @Override // v0.InterfaceC0826D
    public final void i() {
        r rVar = this.f9871f;
        if (rVar.f9877d) {
            rVar.e.i();
        }
    }

    @Override // v0.InterfaceC0826D
    public final void j(long j6, long j7) {
        this.f9871f.e.j(j6 + this.f9869c, j7);
    }

    @Override // v0.InterfaceC0826D
    public final void k(C0833g c0833g) {
        this.e = I2.a.o;
    }

    @Override // v0.InterfaceC0826D
    public final void l(C0123p c0123p, long j6, int i6, List list) {
        AbstractC0133a.i(false);
        this.f9867a = I.u(list);
        this.f9868b = c0123p;
        this.f9871f.f9886n = false;
        C0122o a6 = c0123p.a();
        C0115h c0115h = c0123p.f2602D;
        if (c0115h == null || !c0115h.d()) {
            c0115h = C0115h.f2544h;
        }
        a6.f2565C = c0115h;
        a6.a();
        throw null;
    }

    @Override // v0.InterfaceC0826D
    public final void m(boolean z6) {
        r rVar = this.f9871f;
        if (rVar.f9877d) {
            rVar.e.m(z6);
        }
    }

    @Override // v0.InterfaceC0826D
    public final boolean n(boolean z6) {
        return this.f9871f.e.f9790a.b(false);
    }

    @Override // v0.InterfaceC0826D
    public final void o() {
        r rVar = this.f9871f;
        if (rVar.f9877d) {
            rVar.e.o();
        }
    }

    @Override // v0.InterfaceC0826D
    public final void p(s sVar) {
        this.f9871f.e.f9797i = sVar;
    }

    @Override // v0.InterfaceC0826D
    public final void r(long j6) {
        this.f9869c = j6;
    }

    @Override // v0.InterfaceC0826D
    public final void release() {
        r rVar = this.f9871f;
        if (rVar.f9884l == 2) {
            return;
        }
        V.z zVar = rVar.f9881i;
        if (zVar != null) {
            zVar.f3129a.removeCallbacksAndMessages(null);
        }
        rVar.f9882j = null;
        rVar.f9884l = 2;
    }

    @Override // v0.InterfaceC0826D
    public final boolean s(long j6, C0834h c0834h) {
        AbstractC0133a.i(false);
        int i6 = this.f9871f.o;
        if (i6 != -1 && i6 == 0) {
            throw null;
        }
        return false;
    }

    @Override // v0.InterfaceC0826D
    public final void t() {
        long j6 = this.f9870d;
        r rVar = this.f9871f;
        if (rVar.f9885m >= j6) {
            rVar.e.t();
            rVar.f9886n = true;
        }
    }

    @Override // v0.InterfaceC0826D
    public final void u() {
        r rVar = this.f9871f;
        if (rVar.f9880h.f() == 0) {
            rVar.e.u();
            return;
        }
        R0.e eVar = new R0.e();
        if (rVar.f9880h.f() <= 0) {
            rVar.f9880h = eVar;
        } else {
            ((q) rVar.f9880h.c()).getClass();
            throw null;
        }
    }

    @Override // v0.InterfaceC0826D
    public final void v(int i6) {
        this.f9871f.e.v(i6);
    }

    @Override // v0.InterfaceC0826D
    public final void w(float f6) {
        this.f9871f.e.w(f6);
    }

    @Override // v0.InterfaceC0826D
    public final void q() {
    }
}
