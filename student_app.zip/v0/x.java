package v0;

import S.C0122o;
import S.C0123p;
import S.F;
import S.c0;
import android.os.SystemClock;
import java.util.NoSuchElementException;
import p3.C0711b;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* loaded from: classes.dex */
public final class x {

    /* renamed from: a, reason: collision with root package name */
    public final C0711b f9923a;

    /* renamed from: b, reason: collision with root package name */
    public final t f9924b;

    /* renamed from: c, reason: collision with root package name */
    public final C4.D f9925c = new C4.D();

    /* renamed from: d, reason: collision with root package name */
    public final R0.e f9926d = new R0.e();
    public final R0.e e = new R0.e();

    /* renamed from: f, reason: collision with root package name */
    public final R0.g f9927f;

    /* renamed from: g, reason: collision with root package name */
    public long f9928g;

    /* renamed from: h, reason: collision with root package name */
    public long f9929h;

    /* renamed from: i, reason: collision with root package name */
    public long f9930i;

    /* renamed from: j, reason: collision with root package name */
    public c0 f9931j;

    /* renamed from: k, reason: collision with root package name */
    public long f9932k;

    /* JADX WARN: Type inference failed for: r4v4, types: [R0.g, java.lang.Object] */
    public x(C0711b c0711b, t tVar) {
        this.f9923a = c0711b;
        this.f9924b = tVar;
        ?? obj = new Object();
        int highestOneBit = Integer.bitCount(16) != 1 ? Integer.highestOneBit(15) << 1 : 16;
        obj.f2147a = 0;
        obj.f2148b = -1;
        obj.f2149c = 0;
        obj.e = new long[highestOneBit];
        obj.f2150d = highestOneBit - 1;
        this.f9927f = obj;
        this.f9928g = -9223372036854775807L;
        this.f9931j = c0.f2533d;
        this.f9929h = -9223372036854775807L;
        this.f9930i = -9223372036854775807L;
    }

    public final void a(long j6, long j7) {
        boolean z6;
        long j8;
        C0123p c0123p;
        final C0711b c0711b = this.f9923a;
        C0829c c0829c = (C0829c) c0711b.f9145p;
        while (true) {
            R0.g gVar = this.f9927f;
            int i6 = gVar.f2149c;
            if (i6 == 0) {
                return;
            }
            if (i6 != 0) {
                long j9 = ((long[]) gVar.e)[gVar.f2147a];
                Long l6 = (Long) this.e.d(j9);
                t tVar = this.f9924b;
                if (l6 != null && l6.longValue() != this.f9932k) {
                    this.f9932k = l6.longValue();
                    tVar.f(2);
                }
                long j10 = this.f9932k;
                t tVar2 = this.f9924b;
                C4.D d6 = this.f9925c;
                int a6 = tVar2.a(j9, j6, j7, j10, false, false, d6);
                boolean z7 = true;
                if (a6 != 0 && a6 != 1) {
                    if (a6 != 2 && a6 != 3) {
                        if (a6 != 4) {
                            if (a6 == 5) {
                                return;
                            } else {
                                throw new IllegalStateException(String.valueOf(a6));
                            }
                        }
                        this.f9929h = j9;
                    } else {
                        this.f9929h = j9;
                        gVar.d();
                        final int i7 = 1;
                        c0829c.f9796h.execute(new Runnable() { // from class: v0.b
                            @Override // java.lang.Runnable
                            public final void run() {
                                switch (i7) {
                                    case 0:
                                        ((C0829c) c0711b.f9145p).f9795g.b();
                                        return;
                                    default:
                                        ((C0829c) c0711b.f9145p).f9795g.c();
                                        return;
                                }
                            }
                        });
                        C0834h c0834h = (C0834h) c0829c.f9792c.remove();
                        c0834h.f9812c.M0(c0834h.f9810a, c0834h.f9811b);
                    }
                } else {
                    this.f9929h = j9;
                    if (a6 == 0) {
                        z6 = true;
                    } else {
                        z6 = false;
                    }
                    long d7 = gVar.d();
                    c0 c0Var = (c0) this.f9926d.d(d7);
                    if (c0Var != null && !c0Var.equals(c0.f2533d) && !c0Var.equals(this.f9931j)) {
                        this.f9931j = c0Var;
                        C0122o c0122o = new C0122o();
                        c0122o.f2593t = c0Var.f2534a;
                        c0122o.f2594u = c0Var.f2535b;
                        c0122o.f2587m = F.n("video/raw");
                        c0711b.o = new C0123p(c0122o);
                        c0829c.f9796h.execute(new org.apache.tika.pipes.async.b(c0711b, c0Var, 4));
                    }
                    if (z6) {
                        j8 = System.nanoTime();
                    } else {
                        j8 = d6.f381b;
                    }
                    long j11 = j8;
                    if (tVar.e == 3) {
                        z7 = false;
                    }
                    tVar.e = 3;
                    tVar.f9897l.getClass();
                    tVar.f9892g = V.C.N(SystemClock.elapsedRealtime());
                    if (z7 && c0829c.f9793d != null) {
                        final int i8 = 0;
                        c0829c.f9796h.execute(new Runnable() { // from class: v0.b
                            @Override // java.lang.Runnable
                            public final void run() {
                                switch (i8) {
                                    case 0:
                                        ((C0829c) c0711b.f9145p).f9795g.b();
                                        return;
                                    default:
                                        ((C0829c) c0711b.f9145p).f9795g.c();
                                        return;
                                }
                            }
                        });
                    }
                    C0123p c0123p2 = (C0123p) c0711b.o;
                    if (c0123p2 == null) {
                        c0123p = new C0123p(new C0122o());
                    } else {
                        c0123p = c0123p2;
                    }
                    c0829c.f9797i.a(d7, j11, c0123p, null);
                    C0834h c0834h2 = (C0834h) c0829c.f9792c.remove();
                    c0834h2.f9812c.I0(c0834h2.f9810a, c0834h2.f9811b, j11);
                }
            } else {
                throw new NoSuchElementException();
            }
        }
    }
}
