package v0;

import S.c0;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* renamed from: v0.B, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public interface InterfaceC0824B {

    /* renamed from: a, reason: collision with root package name */
    public static final C0823A f9788a = new Object();

    default void b() {
    }

    default void c() {
    }

    default void d() {
    }

    default void a(c0 c0Var) {
    }
}
