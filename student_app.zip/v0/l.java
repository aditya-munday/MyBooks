package v0;

import V.AbstractC0133a;
import android.graphics.SurfaceTexture;
import android.opengl.EGL14;
import android.opengl.EGLConfig;
import android.opengl.EGLContext;
import android.opengl.EGLDisplay;
import android.opengl.EGLSurface;
import android.opengl.GLES20;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.Message;
import java.util.Locale;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* loaded from: classes.dex */
public final class l extends HandlerThread implements Handler.Callback {
    public V.h o;

    /* renamed from: p, reason: collision with root package name */
    public Handler f9859p;

    /* renamed from: q, reason: collision with root package name */
    public Error f9860q;

    /* renamed from: r, reason: collision with root package name */
    public RuntimeException f9861r;

    /* renamed from: s, reason: collision with root package name */
    public m f9862s;

    public final void a(int i6) {
        boolean z6;
        boolean z7;
        int[] iArr;
        boolean z8;
        int[] iArr2;
        EGLSurface eglCreatePbufferSurface;
        boolean z9;
        this.o.getClass();
        V.h hVar = this.o;
        int[] iArr3 = hVar.f3083p;
        boolean z10 = false;
        EGLDisplay eglGetDisplay = EGL14.eglGetDisplay(0);
        if (eglGetDisplay != null) {
            z6 = true;
        } else {
            z6 = false;
        }
        AbstractC0133a.e("eglGetDisplay failed", z6);
        int[] iArr4 = new int[2];
        AbstractC0133a.e("eglInitialize failed", EGL14.eglInitialize(eglGetDisplay, iArr4, 0, iArr4, 1));
        hVar.f3084q = eglGetDisplay;
        EGLConfig[] eGLConfigArr = new EGLConfig[1];
        int[] iArr5 = new int[1];
        boolean eglChooseConfig = EGL14.eglChooseConfig(eglGetDisplay, V.h.f3082u, 0, eGLConfigArr, 0, 1, iArr5, 0);
        if (eglChooseConfig && iArr5[0] > 0 && eGLConfigArr[0] != null) {
            z7 = true;
        } else {
            z7 = false;
        }
        Object[] objArr = {Boolean.valueOf(eglChooseConfig), Integer.valueOf(iArr5[0]), eGLConfigArr[0]};
        String str = V.C.f3053a;
        AbstractC0133a.e(String.format(Locale.US, "eglChooseConfig failed: success=%b, numConfigs[0]=%d, configs[0]=%s", objArr), z7);
        EGLConfig eGLConfig = eGLConfigArr[0];
        EGLDisplay eGLDisplay = hVar.f3084q;
        if (i6 == 0) {
            iArr = new int[]{12440, 2, 12344};
        } else {
            iArr = new int[]{12440, 2, 12992, 1, 12344};
        }
        EGLContext eglCreateContext = EGL14.eglCreateContext(eGLDisplay, eGLConfig, EGL14.EGL_NO_CONTEXT, iArr, 0);
        if (eglCreateContext != null) {
            z8 = true;
        } else {
            z8 = false;
        }
        AbstractC0133a.e("eglCreateContext failed", z8);
        hVar.f3085r = eglCreateContext;
        EGLDisplay eGLDisplay2 = hVar.f3084q;
        if (i6 == 1) {
            eglCreatePbufferSurface = EGL14.EGL_NO_SURFACE;
        } else {
            if (i6 == 2) {
                iArr2 = new int[]{12375, 1, 12374, 1, 12992, 1, 12344};
            } else {
                iArr2 = new int[]{12375, 1, 12374, 1, 12344};
            }
            eglCreatePbufferSurface = EGL14.eglCreatePbufferSurface(eGLDisplay2, eGLConfig, iArr2, 0);
            if (eglCreatePbufferSurface != null) {
                z9 = true;
            } else {
                z9 = false;
            }
            AbstractC0133a.e("eglCreatePbufferSurface failed", z9);
        }
        AbstractC0133a.e("eglMakeCurrent failed", EGL14.eglMakeCurrent(eGLDisplay2, eglCreatePbufferSurface, eglCreatePbufferSurface, eglCreateContext));
        hVar.f3086s = eglCreatePbufferSurface;
        GLES20.glGenTextures(1, iArr3, 0);
        AbstractC0133a.d();
        SurfaceTexture surfaceTexture = new SurfaceTexture(iArr3[0]);
        hVar.f3087t = surfaceTexture;
        surfaceTexture.setOnFrameAvailableListener(hVar);
        SurfaceTexture surfaceTexture2 = this.o.f3087t;
        surfaceTexture2.getClass();
        if (i6 != 0) {
            z10 = true;
        }
        this.f9862s = new m(this, surfaceTexture2, z10);
    }

    /* JADX WARN: Multi-variable type inference failed */
    public final void b() {
        this.o.getClass();
        V.h hVar = this.o;
        hVar.o.removeCallbacks(hVar);
        try {
            SurfaceTexture surfaceTexture = hVar.f3087t;
            if (surfaceTexture != null) {
                surfaceTexture.release();
                GLES20.glDeleteTextures(1, hVar.f3083p, 0);
            }
        } finally {
            EGLDisplay eGLDisplay = hVar.f3084q;
            if (eGLDisplay != null && !eGLDisplay.equals(EGL14.EGL_NO_DISPLAY)) {
                EGLDisplay eGLDisplay2 = hVar.f3084q;
                EGLSurface eGLSurface = EGL14.EGL_NO_SURFACE;
                EGL14.eglMakeCurrent(eGLDisplay2, eGLSurface, eGLSurface, EGL14.EGL_NO_CONTEXT);
            }
            EGLSurface eGLSurface2 = hVar.f3086s;
            if (eGLSurface2 != null && !eGLSurface2.equals(EGL14.EGL_NO_SURFACE)) {
                EGL14.eglDestroySurface(hVar.f3084q, hVar.f3086s);
            }
            EGLContext eGLContext = hVar.f3085r;
            if (eGLContext != null) {
                EGL14.eglDestroyContext(hVar.f3084q, eGLContext);
            }
            EGL14.eglReleaseThread();
            EGLDisplay eGLDisplay3 = hVar.f3084q;
            if (eGLDisplay3 != null && !eGLDisplay3.equals(EGL14.EGL_NO_DISPLAY)) {
                EGL14.eglTerminate(hVar.f3084q);
            }
            hVar.f3084q = null;
            hVar.f3085r = null;
            hVar.f3086s = null;
            hVar.f3087t = null;
        }
    }

    @Override // android.os.Handler.Callback
    public final boolean handleMessage(Message message) {
        int i6 = message.what;
        try {
            if (i6 != 1) {
                if (i6 == 2) {
                    try {
                        b();
                        return true;
                    } catch (Throwable th) {
                        try {
                            AbstractC0133a.n("PlaceholderSurface", "Failed to release placeholder surface", th);
                            return true;
                        } finally {
                            quit();
                        }
                    }
                }
            } else {
                try {
                    a(message.arg1);
                    synchronized (this) {
                        notify();
                    }
                    return true;
                } catch (V.i e) {
                    AbstractC0133a.n("PlaceholderSurface", "Failed to initialize placeholder surface", e);
                    this.f9861r = new IllegalStateException(e);
                    synchronized (this) {
                        notify();
                    }
                } catch (Error e6) {
                    AbstractC0133a.n("PlaceholderSurface", "Failed to initialize placeholder surface", e6);
                    this.f9860q = e6;
                    synchronized (this) {
                        notify();
                    }
                } catch (RuntimeException e7) {
                    AbstractC0133a.n("PlaceholderSurface", "Failed to initialize placeholder surface", e7);
                    this.f9861r = e7;
                    synchronized (this) {
                        notify();
                    }
                }
            }
            return true;
        } catch (Throwable th2) {
            synchronized (this) {
                notify();
                throw th2;
            }
        }
    }
}
