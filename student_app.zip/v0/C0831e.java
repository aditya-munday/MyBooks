package v0;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* renamed from: v0.e, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0831e {

    /* renamed from: a, reason: collision with root package name */
    public C0830d f9805a;

    /* renamed from: b, reason: collision with root package name */
    public C0830d f9806b;

    /* renamed from: c, reason: collision with root package name */
    public boolean f9807c;

    /* renamed from: d, reason: collision with root package name */
    public long f9808d;
    public int e;
}
