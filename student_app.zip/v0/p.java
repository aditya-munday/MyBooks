package v0;

import S.a0;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* loaded from: classes.dex */
public final class p {

    /* renamed from: a, reason: collision with root package name */
    public final o f9872a = new Object();

    public final void a() {
        try {
            ((p) Class.forName("androidx.media3.effect.SingleInputVideoGraph$Factory").getConstructor(a0.class).newInstance(this.f9872a)).a();
        } catch (Exception e) {
            throw new IllegalStateException(e);
        }
    }
}
