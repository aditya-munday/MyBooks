package v0;

import b0.C0256h;
import p0.C0678A;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* loaded from: classes.dex */
public final /* synthetic */ class y implements Runnable {
    public final /* synthetic */ int o;

    /* renamed from: p, reason: collision with root package name */
    public final /* synthetic */ C0256h f9933p;

    public /* synthetic */ y(C0256h c0256h, int i6, long j6) {
        this.o = 3;
        this.f9933p = c0256h;
    }

    @Override // java.lang.Runnable
    public final void run() {
        int i6 = this.o;
        C0256h c0256h = this.f9933p;
        switch (i6) {
            case 0:
                Z.B b6 = c0256h.f5196b;
                String str = V.C.f3053a;
                a0.f fVar = b6.f3885a.f3936t;
                fVar.K(fVar.J(), 1016, new a0.c(1));
                return;
            case 1:
                Z.B b7 = c0256h.f5196b;
                String str2 = V.C.f3053a;
                a0.f fVar2 = b7.f3885a.f3936t;
                fVar2.K(fVar2.J(), 1030, new a0.e(1));
                return;
            case 2:
                Z.B b8 = c0256h.f5196b;
                String str3 = V.C.f3053a;
                a0.f fVar3 = b8.f3885a.f3936t;
                fVar3.K(fVar3.J(), 1019, new T.e(21));
                return;
            case 3:
                Z.B b9 = c0256h.f5196b;
                String str4 = V.C.f3053a;
                a0.f fVar4 = b9.f3885a.f3936t;
                fVar4.K(fVar4.H((C0678A) fVar4.f4343d.f2111f), 1018, new a0.c(11));
                return;
            case 4:
                Z.B b10 = c0256h.f5196b;
                String str5 = V.C.f3053a;
                a0.f fVar5 = b10.f3885a.f3936t;
                fVar5.K(fVar5.H((C0678A) fVar5.f4343d.f2111f), 1021, new a0.c(12));
                return;
            default:
                Z.B b11 = c0256h.f5196b;
                String str6 = V.C.f3053a;
                a0.f fVar6 = b11.f3885a.f3936t;
                fVar6.K(fVar6.J(), 1015, new a0.c(21));
                return;
        }
    }

    public /* synthetic */ y(C0256h c0256h, long j6, int i6) {
        this.o = 4;
        this.f9933p = c0256h;
    }

    public /* synthetic */ y(C0256h c0256h, Object obj, int i6) {
        this.o = i6;
        this.f9933p = c0256h;
    }

    public /* synthetic */ y(C0256h c0256h, String str, long j6, long j7) {
        this.o = 0;
        this.f9933p = c0256h;
    }
}
