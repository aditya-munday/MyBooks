package v0;

import android.util.Range;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* loaded from: classes.dex */
public abstract class u {

    /* renamed from: a, reason: collision with root package name */
    public long f9900a;

    /* renamed from: b, reason: collision with root package name */
    public long f9901b;

    /* renamed from: c, reason: collision with root package name */
    public double f9902c;

    /* renamed from: d, reason: collision with root package name */
    public Range f9903d;

    public abstract void a();
}
