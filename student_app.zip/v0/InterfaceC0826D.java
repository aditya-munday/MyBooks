package v0;

import S.C0123p;
import android.view.Surface;
import java.util.List;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* renamed from: v0.D, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public interface InterfaceC0826D {
    void a();

    boolean b();

    Surface c();

    boolean d();

    void e(boolean z6);

    void f(Surface surface, V.w wVar);

    boolean g(C0123p c0123p);

    void h(List list);

    void i();

    void j(long j6, long j7);

    void k(C0833g c0833g);

    void l(C0123p c0123p, long j6, int i6, List list);

    void m(boolean z6);

    boolean n(boolean z6);

    void o();

    void p(s sVar);

    void q();

    void r(long j6);

    void release();

    boolean s(long j6, C0834h c0834h);

    void t();

    void u();

    void v(int i6);

    void w(float f6);
}
