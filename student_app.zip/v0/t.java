package v0;

import V.AbstractC0133a;
import android.content.Context;
import android.hardware.display.DisplayManager;
import android.os.SystemClock;
import android.view.Surface;
import c5.C0352p;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* loaded from: classes.dex */
public final class t {

    /* renamed from: a, reason: collision with root package name */
    public final k f9887a;

    /* renamed from: b, reason: collision with root package name */
    public final w f9888b;

    /* renamed from: c, reason: collision with root package name */
    public final long f9889c;

    /* renamed from: d, reason: collision with root package name */
    public boolean f9890d;

    /* renamed from: g, reason: collision with root package name */
    public long f9892g;

    /* renamed from: j, reason: collision with root package name */
    public boolean f9895j;

    /* renamed from: m, reason: collision with root package name */
    public boolean f9898m;

    /* renamed from: n, reason: collision with root package name */
    public boolean f9899n;
    public int e = 0;

    /* renamed from: f, reason: collision with root package name */
    public long f9891f = -9223372036854775807L;

    /* renamed from: h, reason: collision with root package name */
    public long f9893h = -9223372036854775807L;

    /* renamed from: i, reason: collision with root package name */
    public long f9894i = -9223372036854775807L;

    /* renamed from: k, reason: collision with root package name */
    public float f9896k = 1.0f;

    /* renamed from: l, reason: collision with root package name */
    public V.x f9897l = V.x.f3126a;

    public t(Context context, k kVar, long j6) {
        this.f9887a = kVar;
        this.f9889c = j6;
        this.f9888b = new w(context);
    }

    /* JADX WARN: Code restructure failed: missing block: B:121:0x0149, code lost:
    
        if (r4 > org.apache.tika.pipes.PipesConfigBase.DEFAULT_MAX_FOR_EMIT_BATCH) goto L74;
     */
    /* JADX WARN: Code restructure failed: missing block: B:125:0x0155, code lost:
    
        if (r29 >= r33) goto L74;
     */
    /* JADX WARN: Code restructure failed: missing block: B:136:0x007a, code lost:
    
        if (r7 != false) goto L24;
     */
    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Removed duplicated region for block: B:49:0x015c A[RETURN] */
    /* JADX WARN: Removed duplicated region for block: B:50:0x015d  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final int a(long j6, long j7, long j8, long j9, boolean z6, boolean z7, C4.D d6) {
        long j10;
        long j11;
        long j12;
        boolean z8;
        int i6;
        long j13;
        int i7;
        int i8;
        boolean z9;
        long j14;
        long j15;
        boolean z10;
        int i9;
        d6.f380a = -9223372036854775807L;
        d6.f381b = -9223372036854775807L;
        if (this.f9890d && this.f9891f == -9223372036854775807L) {
            this.f9891f = j7;
        }
        int i10 = 0;
        if (this.f9893h != j6) {
            w wVar = this.f9888b;
            j10 = -9223372036854775807L;
            long j16 = wVar.f9920n;
            if (j16 != -1) {
                wVar.f9921p = j16;
                wVar.f9922q = wVar.o;
            }
            wVar.f9919m++;
            C0831e c0831e = wVar.f9908a;
            j11 = -1;
            long j17 = j6 * 1000;
            c0831e.f9805a.b(j17);
            if (c0831e.f9805a.a()) {
                c0831e.f9807c = false;
                j12 = 0;
            } else {
                j12 = 0;
                if (c0831e.f9808d != -9223372036854775807L) {
                    if (c0831e.f9807c) {
                        C0830d c0830d = c0831e.f9806b;
                        long j18 = c0830d.f9801d;
                        if (j18 == 0) {
                            z10 = false;
                        } else {
                            z10 = c0830d.f9803g[(int) ((j18 - 1) % 15)];
                        }
                    }
                    c0831e.f9806b.c();
                    c0831e.f9806b.b(c0831e.f9808d);
                    c0831e.f9807c = true;
                    c0831e.f9806b.b(j17);
                }
            }
            if (c0831e.f9807c && c0831e.f9806b.a()) {
                C0830d c0830d2 = c0831e.f9805a;
                c0831e.f9805a = c0831e.f9806b;
                c0831e.f9806b = c0830d2;
                c0831e.f9807c = false;
            }
            c0831e.f9808d = j17;
            if (c0831e.f9805a.a()) {
                i9 = 0;
            } else {
                i9 = c0831e.e + 1;
            }
            c0831e.e = i9;
            wVar.c();
            this.f9893h = j6;
        } else {
            j10 = -9223372036854775807L;
            j11 = -1;
            j12 = 0;
        }
        long j19 = (long) ((j6 - j7) / this.f9896k);
        if (this.f9890d) {
            this.f9897l.getClass();
            j19 -= V.C.N(SystemClock.elapsedRealtime()) - j8;
        }
        long j20 = j19;
        d6.f380a = j20;
        if (!z6 || z7) {
            if (!this.f9898m) {
                this.f9899n = true;
                if (!this.f9887a.K0(j20, j7, z7, true)) {
                    if (!this.f9890d || d6.f380a >= 30000) {
                        return 5;
                    }
                } else {
                    return 4;
                }
            } else {
                if (this.f9894i == j10 || this.f9895j) {
                    int i11 = this.e;
                    if (i11 != 0) {
                        if (i11 != 1) {
                            if (i11 != 2) {
                                if (i11 == 3) {
                                    this.f9897l.getClass();
                                    long N5 = V.C.N(SystemClock.elapsedRealtime()) - this.f9892g;
                                    if (this.f9890d) {
                                        long j21 = this.f9891f;
                                        if (j21 != j10) {
                                            if (j21 != j7) {
                                                if (j20 < -30000) {
                                                }
                                            }
                                        }
                                    }
                                } else {
                                    throw new IllegalStateException();
                                }
                            }
                        }
                        z8 = true;
                    } else {
                        z8 = this.f9890d;
                    }
                    if (!z8) {
                        return 0;
                    }
                    if (this.f9890d && j7 != this.f9891f) {
                        this.f9897l.getClass();
                        long nanoTime = System.nanoTime();
                        w wVar2 = this.f9888b;
                        long j22 = (d6.f380a * 1000) + nanoTime;
                        if (wVar2.f9921p != j11 && wVar2.f9908a.f9805a.a()) {
                            C0831e c0831e2 = wVar2.f9908a;
                            if (c0831e2.f9805a.a()) {
                                C0830d c0830d3 = c0831e2.f9805a;
                                i6 = 3;
                                j13 = -30000;
                                long j23 = c0830d3.e;
                                if (j23 == j12) {
                                    j15 = j12;
                                } else {
                                    j15 = c0830d3.f9802f / j23;
                                }
                            } else {
                                i6 = 3;
                                j13 = -30000;
                                j15 = j10;
                            }
                            i7 = 2;
                            i8 = 1;
                            long j24 = wVar2.f9922q + (((float) ((wVar2.f9919m - wVar2.f9921p) * j15)) / wVar2.f9915i);
                            if (Math.abs(j22 - j24) <= 20000000) {
                                j22 = j24;
                            } else {
                                wVar2.f9919m = j12;
                                long j25 = j11;
                                wVar2.f9921p = j25;
                                wVar2.f9920n = j25;
                            }
                        } else {
                            i6 = 3;
                            j13 = -30000;
                            i7 = 2;
                            i8 = 1;
                        }
                        wVar2.f9920n = wVar2.f9919m;
                        wVar2.o = j22;
                        v vVar = wVar2.f9910c;
                        if (vVar != null && wVar2.f9917k != j10) {
                            long j26 = vVar.o;
                            if (j26 != j10) {
                                long j27 = wVar2.f9917k;
                                long j28 = (((j22 - j26) / j27) * j27) + j26;
                                if (j22 <= j28) {
                                    j14 = j28 - j27;
                                } else {
                                    j14 = j28;
                                    j28 = j27 + j28;
                                }
                                if (j28 - j22 >= j22 - j14) {
                                    j28 = j14;
                                }
                                j22 = j28 - wVar2.f9918l;
                            }
                        }
                        d6.f381b = j22;
                        long j29 = (j22 - nanoTime) / 1000;
                        d6.f380a = j29;
                        if (this.f9894i != j10 && !this.f9895j) {
                            z9 = i8;
                        } else {
                            z9 = 0;
                        }
                        if (this.f9887a.K0(j29, j7, z7, z9)) {
                            return 4;
                        }
                        long j30 = d6.f380a;
                        if (j30 < j13 && !z7) {
                            i10 = i8;
                        }
                        if (i10 != 0) {
                            if (z9 != 0) {
                                return i6;
                            }
                            return i7;
                        }
                        if (j30 <= 50000) {
                            return i8;
                        }
                        return 5;
                    }
                    return 5;
                }
                z8 = false;
                if (!z8) {
                }
            }
        }
        return 3;
    }

    public final boolean b(boolean z6) {
        if (z6 && (this.e == 3 || (!this.f9898m && this.f9899n))) {
            this.f9894i = -9223372036854775807L;
            return true;
        }
        if (this.f9894i == -9223372036854775807L) {
            return false;
        }
        this.f9897l.getClass();
        if (SystemClock.elapsedRealtime() < this.f9894i) {
            return true;
        }
        this.f9894i = -9223372036854775807L;
        return false;
    }

    public final void c(boolean z6) {
        long j6;
        this.f9895j = z6;
        long j7 = this.f9889c;
        if (j7 > 0) {
            this.f9897l.getClass();
            j6 = SystemClock.elapsedRealtime() + j7;
        } else {
            j6 = -9223372036854775807L;
        }
        this.f9894i = j6;
    }

    public final void d() {
        this.f9890d = true;
        this.f9897l.getClass();
        this.f9892g = V.C.N(SystemClock.elapsedRealtime());
        w wVar = this.f9888b;
        wVar.f9911d = true;
        wVar.f9919m = 0L;
        wVar.f9921p = -1L;
        wVar.f9920n = -1L;
        C0352p c0352p = wVar.f9909b;
        if (c0352p != null) {
            DisplayManager displayManager = c0352p.f5635b;
            v vVar = wVar.f9910c;
            vVar.getClass();
            vVar.f9905p.sendEmptyMessage(2);
            displayManager.registerDisplayListener(c0352p, V.C.p(null));
            w.a((w) c0352p.f5636c, displayManager.getDisplay(0));
        }
        wVar.d(false);
    }

    public final void e() {
        this.f9890d = false;
        this.f9894i = -9223372036854775807L;
        w wVar = this.f9888b;
        wVar.f9911d = false;
        C0352p c0352p = wVar.f9909b;
        if (c0352p != null) {
            c0352p.f5635b.unregisterDisplayListener(c0352p);
            v vVar = wVar.f9910c;
            vVar.getClass();
            vVar.f9905p.sendEmptyMessage(3);
        }
        wVar.b();
    }

    public final void f(int i6) {
        if (i6 != 0) {
            if (i6 != 1) {
                if (i6 == 2) {
                    this.e = Math.min(this.e, 2);
                    return;
                }
                throw new IllegalStateException();
            }
            this.e = 0;
            return;
        }
        this.e = 1;
    }

    public final void g(float f6) {
        w wVar = this.f9888b;
        wVar.f9912f = f6;
        C0831e c0831e = wVar.f9908a;
        c0831e.f9805a.c();
        c0831e.f9806b.c();
        c0831e.f9807c = false;
        c0831e.f9808d = -9223372036854775807L;
        c0831e.e = 0;
        wVar.c();
    }

    public final void h(Surface surface) {
        boolean z6;
        if (surface != null) {
            z6 = true;
        } else {
            z6 = false;
        }
        this.f9898m = z6;
        this.f9899n = false;
        w wVar = this.f9888b;
        if (wVar.e != surface) {
            wVar.b();
            wVar.e = surface;
            wVar.d(true);
        }
        this.e = Math.min(this.e, 1);
    }

    public final void i(float f6) {
        boolean z6;
        if (f6 > 0.0f) {
            z6 = true;
        } else {
            z6 = false;
        }
        AbstractC0133a.c(z6);
        if (f6 == this.f9896k) {
            return;
        }
        this.f9896k = f6;
        w wVar = this.f9888b;
        wVar.f9915i = f6;
        wVar.f9919m = 0L;
        wVar.f9921p = -1L;
        wVar.f9920n = -1L;
        wVar.d(false);
    }
}
