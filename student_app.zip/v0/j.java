package v0;

import Z.C0181m;
import android.os.Handler;
import android.os.Message;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* loaded from: classes.dex */
public final class j implements Handler.Callback {
    public final Handler o;

    /* renamed from: p, reason: collision with root package name */
    public final /* synthetic */ k f9819p;

    public j(k kVar, i0.m mVar) {
        this.f9819p = kVar;
        Handler p6 = V.C.p(this);
        this.o = p6;
        mVar.n(this, p6);
    }

    public final void a(long j6) {
        k kVar = this.f9819p;
        if (this == kVar.f9825D1 && kVar.f6957Z != null) {
            if (j6 == Long.MAX_VALUE) {
                kVar.f6932I0 = true;
                return;
            }
            try {
                kVar.H0(j6);
            } catch (C0181m e) {
                kVar.f6934J0 = e;
            }
        }
    }

    @Override // android.os.Handler.Callback
    public final boolean handleMessage(Message message) {
        if (message.what != 0) {
            return false;
        }
        int i6 = message.arg1;
        int i7 = message.arg2;
        String str = V.C.f3053a;
        a(((i6 & 4294967295L) << 32) | (4294967295L & i7));
        return true;
    }
}
