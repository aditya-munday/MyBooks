package W1;

import android.content.Context;
import androidx.datastore.preferences.protobuf.AbstractC0227o;
import e2.InterfaceC0418a;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* loaded from: classes.dex */
public final class b extends c {

    /* renamed from: a, reason: collision with root package name */
    public final Context f3475a;

    /* renamed from: b, reason: collision with root package name */
    public final InterfaceC0418a f3476b;

    /* renamed from: c, reason: collision with root package name */
    public final InterfaceC0418a f3477c;

    /* renamed from: d, reason: collision with root package name */
    public final String f3478d;

    public b(Context context, InterfaceC0418a interfaceC0418a, InterfaceC0418a interfaceC0418a2, String str) {
        if (context != null) {
            this.f3475a = context;
            if (interfaceC0418a != null) {
                this.f3476b = interfaceC0418a;
                if (interfaceC0418a2 != null) {
                    this.f3477c = interfaceC0418a2;
                    if (str != null) {
                        this.f3478d = str;
                        return;
                    }
                    throw new NullPointerException("Null backendName");
                }
                throw new NullPointerException("Null monotonicClock");
            }
            throw new NullPointerException("Null wallClock");
        }
        throw new NullPointerException("Null applicationContext");
    }

    public final boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        if (obj instanceof c) {
            b bVar = (b) ((c) obj);
            if (this.f3475a.equals(bVar.f3475a) && this.f3476b.equals(bVar.f3476b) && this.f3477c.equals(bVar.f3477c) && this.f3478d.equals(bVar.f3478d)) {
                return true;
            }
        }
        return false;
    }

    public final int hashCode() {
        return ((((((this.f3475a.hashCode() ^ 1000003) * 1000003) ^ this.f3476b.hashCode()) * 1000003) ^ this.f3477c.hashCode()) * 1000003) ^ this.f3478d.hashCode();
    }

    public final String toString() {
        StringBuilder sb = new StringBuilder("CreationContext{applicationContext=");
        sb.append(this.f3475a);
        sb.append(", wallClock=");
        sb.append(this.f3476b);
        sb.append(", monotonicClock=");
        sb.append(this.f3477c);
        sb.append(", backendName=");
        return AbstractC0227o.h(sb, this.f3478d, "}");
    }
}
