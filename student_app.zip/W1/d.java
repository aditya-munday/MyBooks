package W1;

import A1.i;
import android.content.Context;
import com.google.android.datatransport.cct.CctBackendFactory;
import e2.InterfaceC0418a;
import java.util.HashMap;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* loaded from: classes.dex */
public final class d {

    /* renamed from: a, reason: collision with root package name */
    public final A.c f3479a;

    /* renamed from: b, reason: collision with root package name */
    public final i f3480b;

    /* renamed from: c, reason: collision with root package name */
    public final HashMap f3481c;

    public d(Context context, i iVar) {
        A.c cVar = new A.c(context, 25);
        this.f3481c = new HashMap();
        this.f3479a = cVar;
        this.f3480b = iVar;
    }

    public final synchronized e a(String str) {
        if (this.f3481c.containsKey(str)) {
            return (e) this.f3481c.get(str);
        }
        CctBackendFactory o = this.f3479a.o(str);
        if (o == null) {
            return null;
        }
        i iVar = this.f3480b;
        e create = o.create(new b((Context) iVar.f50p, (InterfaceC0418a) iVar.f51q, (InterfaceC0418a) iVar.f52r, str));
        this.f3481c.put(str, create);
        return create;
    }
}
