package W1;

import C4.AbstractC0034i;
import L.i;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* loaded from: classes.dex */
public final class a {

    /* renamed from: a, reason: collision with root package name */
    public final int f3473a;

    /* renamed from: b, reason: collision with root package name */
    public final long f3474b;

    public a(long j6, int i6) {
        if (i6 != 0) {
            this.f3473a = i6;
            this.f3474b = j6;
            return;
        }
        throw new NullPointerException("Null status");
    }

    public final boolean equals(Object obj) {
        if (obj != this) {
            if (obj instanceof a) {
                a aVar = (a) obj;
                if (i.a(this.f3473a, aVar.f3473a) && this.f3474b == aVar.f3474b) {
                    return true;
                }
                return false;
            }
            return false;
        }
        return true;
    }

    public final int hashCode() {
        int b6 = (i.b(this.f3473a) ^ 1000003) * 1000003;
        long j6 = this.f3474b;
        return b6 ^ ((int) ((j6 >>> 32) ^ j6));
    }

    public final String toString() {
        String str;
        StringBuilder sb = new StringBuilder("BackendResponse{status=");
        int i6 = this.f3473a;
        if (i6 != 1) {
            if (i6 != 2) {
                if (i6 != 3) {
                    if (i6 != 4) {
                        str = "null";
                    } else {
                        str = "INVALID_PAYLOAD";
                    }
                } else {
                    str = "FATAL_ERROR";
                }
            } else {
                str = "TRANSIENT_ERROR";
            }
        } else {
            str = "OK";
        }
        sb.append(str);
        sb.append(", nextRequestWaitMillis=");
        return AbstractC0034i.m(sb, this.f3474b, "}");
    }
}
