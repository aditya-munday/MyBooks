package z1;

import C4.o;
import android.content.Context;
import h5.m;
import i1.ExecutorC0474b;
import x1.i;
import y1.InterfaceC0920a;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* loaded from: classes.dex */
public final class a implements InterfaceC0920a {
    @Override // y1.InterfaceC0920a
    public final void b(Context context, ExecutorC0474b executorC0474b, o oVar) {
        oVar.accept(new i(m.o));
    }

    @Override // y1.InterfaceC0920a
    public final void a(o oVar) {
    }
}
