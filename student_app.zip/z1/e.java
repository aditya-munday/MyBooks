package z1;

import C4.AbstractC0034i;
import D.A;
import D.B;
import D.C;
import D.D;
import D.E;
import D.P;
import D.y;
import android.app.Activity;
import android.content.Context;
import android.content.ContextWrapper;
import android.graphics.Point;
import android.graphics.Rect;
import android.inputmethodservice.InputMethodService;
import android.os.Build;
import android.view.Display;
import android.view.WindowManager;
import androidx.window.extensions.layout.FoldingFeature;
import androidx.window.extensions.layout.WindowLayoutInfo;
import java.util.ArrayList;
import java.util.List;
import q5.h;
import u1.C0808b;
import x1.C0889b;
import x1.C0890c;
import x1.i;
import x1.j;
import x1.l;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* loaded from: classes.dex */
public abstract class e {
    public static C0890c a(j jVar, FoldingFeature foldingFeature) {
        C0889b c0889b;
        C0889b c0889b2;
        int type = foldingFeature.getType();
        if (type != 1) {
            if (type == 2) {
                c0889b = C0889b.f10256v;
            } else {
                return null;
            }
        } else {
            c0889b = C0889b.f10255u;
        }
        int state = foldingFeature.getState();
        if (state != 1) {
            if (state == 2) {
                c0889b2 = C0889b.f10254t;
            } else {
                return null;
            }
        } else {
            c0889b2 = C0889b.f10253s;
        }
        Rect bounds = foldingFeature.getBounds();
        h.d(bounds, "oemFeature.bounds");
        int i6 = bounds.left;
        int i7 = bounds.top;
        int i8 = bounds.right;
        int i9 = bounds.bottom;
        if (i6 <= i8) {
            if (i7 <= i9) {
                Rect a6 = jVar.f10272a.a();
                int i10 = i9 - i7;
                if (i10 != 0 || i8 - i6 != 0) {
                    int i11 = i8 - i6;
                    if (i11 == a6.width() || i10 == a6.height()) {
                        if (i11 >= a6.width() || i10 >= a6.height()) {
                            if (i11 == a6.width() && i10 == a6.height()) {
                                return null;
                            }
                            Rect bounds2 = foldingFeature.getBounds();
                            h.d(bounds2, "oemFeature.bounds");
                            return new C0890c(new C0808b(bounds2), c0889b, c0889b2);
                        }
                        return null;
                    }
                    return null;
                }
                return null;
            }
            throw new IllegalArgumentException(AbstractC0034i.h(i7, i9, "top must be less than or equal to bottom, top: ", ", bottom: ").toString());
        }
        throw new IllegalArgumentException(AbstractC0034i.h(i6, i8, "Left must be less than or equal to right, left: ", ", right: ").toString());
    }

    public static i b(Context context, WindowLayoutInfo windowLayoutInfo) {
        E yVar;
        j jVar;
        h.e(windowLayoutInfo, "info");
        int i6 = Build.VERSION.SDK_INT;
        if (i6 >= 30) {
            int i7 = l.f10275b;
            if (i6 >= 30) {
                jVar = B1.a.c(context);
            } else {
                Context context2 = context;
                while (context2 instanceof ContextWrapper) {
                    boolean z6 = context2 instanceof Activity;
                    if (!z6 && !(context2 instanceof InputMethodService)) {
                        ContextWrapper contextWrapper = (ContextWrapper) context2;
                        if (contextWrapper.getBaseContext() != null) {
                            context2 = contextWrapper.getBaseContext();
                            h.d(context2, "iterator.baseContext");
                        }
                    }
                    if (z6) {
                        jVar = l.a((Activity) context);
                    } else if (context2 instanceof InputMethodService) {
                        Object systemService = context.getSystemService("window");
                        h.c(systemService, "null cannot be cast to non-null type android.view.WindowManager");
                        Display defaultDisplay = ((WindowManager) systemService).getDefaultDisplay();
                        h.d(defaultDisplay, "wm.defaultDisplay");
                        Point point = new Point();
                        defaultDisplay.getRealSize(point);
                        Rect rect = new Rect(0, 0, point.x, point.y);
                        int i8 = Build.VERSION.SDK_INT;
                        if (i8 >= 34) {
                            yVar = new D();
                        } else if (i8 >= 31) {
                            yVar = new C();
                        } else if (i8 >= 30) {
                            yVar = new B();
                        } else if (i8 >= 29) {
                            yVar = new A();
                        } else {
                            yVar = new y();
                        }
                        P b6 = yVar.b();
                        h.d(b6, "Builder().build()");
                        jVar = new j(new C0808b(rect), b6);
                    } else {
                        throw new IllegalArgumentException(context + " is not a UiContext");
                    }
                }
                throw new IllegalArgumentException("Context " + context + " is not a UiContext");
            }
            return c(jVar, windowLayoutInfo);
        }
        if (i6 >= 29 && (context instanceof Activity)) {
            int i9 = l.f10275b;
            return c(l.a((Activity) context), windowLayoutInfo);
        }
        throw new UnsupportedOperationException("Display Features are only supported after Q. Display features for non-Activity contexts are not expected to be reported on devices running Q.");
    }

    public static i c(j jVar, WindowLayoutInfo windowLayoutInfo) {
        C0890c c0890c;
        h.e(windowLayoutInfo, "info");
        List<FoldingFeature> displayFeatures = windowLayoutInfo.getDisplayFeatures();
        h.d(displayFeatures, "info.displayFeatures");
        ArrayList arrayList = new ArrayList();
        for (FoldingFeature foldingFeature : displayFeatures) {
            if (foldingFeature instanceof FoldingFeature) {
                h.d(foldingFeature, "feature");
                c0890c = a(jVar, foldingFeature);
            } else {
                c0890c = null;
            }
            if (c0890c != null) {
                arrayList.add(c0890c);
            }
        }
        return new i(arrayList);
    }
}
