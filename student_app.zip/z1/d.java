package z1;

import C4.o;
import android.content.Context;
import androidx.window.extensions.layout.WindowLayoutComponent;
import g5.h;
import i1.ExecutorC0474b;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.concurrent.locks.ReentrantLock;
import y1.InterfaceC0920a;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* loaded from: classes.dex */
public final class d implements InterfaceC0920a {

    /* renamed from: a, reason: collision with root package name */
    public final WindowLayoutComponent f10425a;

    /* renamed from: b, reason: collision with root package name */
    public final ReentrantLock f10426b = new ReentrantLock();

    /* renamed from: c, reason: collision with root package name */
    public final LinkedHashMap f10427c = new LinkedHashMap();

    /* renamed from: d, reason: collision with root package name */
    public final LinkedHashMap f10428d = new LinkedHashMap();

    public d(WindowLayoutComponent windowLayoutComponent) {
        this.f10425a = windowLayoutComponent;
    }

    @Override // y1.InterfaceC0920a
    public final void a(o oVar) {
        LinkedHashMap linkedHashMap = this.f10427c;
        LinkedHashMap linkedHashMap2 = this.f10428d;
        ReentrantLock reentrantLock = this.f10426b;
        reentrantLock.lock();
        try {
            Context context = (Context) linkedHashMap2.get(oVar);
            if (context == null) {
                return;
            }
            f fVar = (f) linkedHashMap.get(context);
            if (fVar == null) {
                return;
            }
            LinkedHashSet linkedHashSet = fVar.f10432d;
            ReentrantLock reentrantLock2 = fVar.f10430b;
            reentrantLock2.lock();
            try {
                linkedHashSet.remove(oVar);
                reentrantLock2.unlock();
                linkedHashMap2.remove(oVar);
                if (linkedHashSet.isEmpty()) {
                    linkedHashMap.remove(context);
                    this.f10425a.removeWindowLayoutInfoListener(fVar);
                }
            } catch (Throwable th) {
                reentrantLock2.unlock();
                throw th;
            }
        } finally {
            reentrantLock.unlock();
        }
    }

    @Override // y1.InterfaceC0920a
    public final void b(Context context, ExecutorC0474b executorC0474b, o oVar) {
        h hVar;
        LinkedHashMap linkedHashMap = this.f10427c;
        ReentrantLock reentrantLock = this.f10426b;
        reentrantLock.lock();
        try {
            f fVar = (f) linkedHashMap.get(context);
            LinkedHashMap linkedHashMap2 = this.f10428d;
            if (fVar != null) {
                fVar.b(oVar);
                linkedHashMap2.put(oVar, context);
                hVar = h.f6800a;
            } else {
                hVar = null;
            }
            if (hVar == null) {
                f fVar2 = new f(context);
                linkedHashMap.put(context, fVar2);
                linkedHashMap2.put(oVar, context);
                fVar2.b(oVar);
                this.f10425a.addWindowLayoutInfoListener(context, fVar2);
            }
            reentrantLock.unlock();
        } catch (Throwable th) {
            reentrantLock.unlock();
            throw th;
        }
    }
}
