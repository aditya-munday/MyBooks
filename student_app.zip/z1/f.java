package z1;

import C4.o;
import android.content.Context;
import androidx.window.extensions.core.util.function.Consumer;
import androidx.window.extensions.layout.WindowLayoutInfo;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.concurrent.locks.ReentrantLock;
import org.apache.tika.mime.MimeTypesReaderMetKeys;
import q5.h;
import x1.i;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* loaded from: classes.dex */
public final class f implements C.a, Consumer {

    /* renamed from: a, reason: collision with root package name */
    public final Context f10429a;

    /* renamed from: c, reason: collision with root package name */
    public i f10431c;

    /* renamed from: b, reason: collision with root package name */
    public final ReentrantLock f10430b = new ReentrantLock();

    /* renamed from: d, reason: collision with root package name */
    public final LinkedHashSet f10432d = new LinkedHashSet();

    public f(Context context) {
        this.f10429a = context;
    }

    @Override // C.a
    /* renamed from: a, reason: merged with bridge method [inline-methods] */
    public final void accept(WindowLayoutInfo windowLayoutInfo) {
        h.e(windowLayoutInfo, MimeTypesReaderMetKeys.MATCH_VALUE_ATTR);
        ReentrantLock reentrantLock = this.f10430b;
        reentrantLock.lock();
        try {
            this.f10431c = e.b(this.f10429a, windowLayoutInfo);
            Iterator it = this.f10432d.iterator();
            while (it.hasNext()) {
                ((C.a) it.next()).accept(this.f10431c);
            }
        } finally {
            reentrantLock.unlock();
        }
    }

    public final void b(o oVar) {
        ReentrantLock reentrantLock = this.f10430b;
        reentrantLock.lock();
        try {
            i iVar = this.f10431c;
            if (iVar != null) {
                oVar.accept(iVar);
            }
            this.f10432d.add(oVar);
            reentrantLock.unlock();
        } catch (Throwable th) {
            reentrantLock.unlock();
            throw th;
        }
    }
}
