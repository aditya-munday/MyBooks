package z1;

import C4.o;
import android.app.Activity;
import android.content.Context;
import androidx.window.extensions.layout.WindowLayoutComponent;
import androidx.window.extensions.layout.WindowLayoutInfo;
import g5.h;
import h5.m;
import i1.ExecutorC0474b;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.concurrent.locks.ReentrantLock;
import q5.g;
import q5.q;
import t1.C0786a;
import u1.C0810d;
import y1.InterfaceC0920a;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* loaded from: classes.dex */
public final class c implements InterfaceC0920a {

    /* renamed from: a, reason: collision with root package name */
    public final WindowLayoutComponent f10420a;

    /* renamed from: b, reason: collision with root package name */
    public final C0786a f10421b;

    /* renamed from: c, reason: collision with root package name */
    public final ReentrantLock f10422c = new ReentrantLock();

    /* renamed from: d, reason: collision with root package name */
    public final LinkedHashMap f10423d = new LinkedHashMap();
    public final LinkedHashMap e = new LinkedHashMap();

    /* renamed from: f, reason: collision with root package name */
    public final LinkedHashMap f10424f = new LinkedHashMap();

    public c(WindowLayoutComponent windowLayoutComponent, C0786a c0786a) {
        this.f10420a = windowLayoutComponent;
        this.f10421b = c0786a;
    }

    @Override // y1.InterfaceC0920a
    public final void a(o oVar) {
        LinkedHashMap linkedHashMap = this.f10423d;
        LinkedHashMap linkedHashMap2 = this.e;
        ReentrantLock reentrantLock = this.f10422c;
        reentrantLock.lock();
        try {
            Context context = (Context) linkedHashMap2.get(oVar);
            if (context == null) {
                return;
            }
            f fVar = (f) linkedHashMap.get(context);
            if (fVar == null) {
                return;
            }
            LinkedHashSet linkedHashSet = fVar.f10432d;
            ReentrantLock reentrantLock2 = fVar.f10430b;
            reentrantLock2.lock();
            try {
                linkedHashSet.remove(oVar);
                reentrantLock2.unlock();
                linkedHashMap2.remove(oVar);
                if (linkedHashSet.isEmpty()) {
                    linkedHashMap.remove(context);
                    C0810d c0810d = (C0810d) this.f10424f.remove(fVar);
                    if (c0810d != null) {
                        c0810d.f9752a.invoke(c0810d.f9753b, c0810d.f9754c);
                    }
                }
            } catch (Throwable th) {
                reentrantLock2.unlock();
                throw th;
            }
        } finally {
            reentrantLock.unlock();
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r3v0, types: [z1.b, q5.g] */
    @Override // y1.InterfaceC0920a
    public final void b(Context context, ExecutorC0474b executorC0474b, o oVar) {
        h hVar;
        LinkedHashMap linkedHashMap = this.f10423d;
        ReentrantLock reentrantLock = this.f10422c;
        reentrantLock.lock();
        try {
            f fVar = (f) linkedHashMap.get(context);
            LinkedHashMap linkedHashMap2 = this.e;
            if (fVar != null) {
                fVar.b(oVar);
                linkedHashMap2.put(oVar, context);
                hVar = h.f6800a;
            } else {
                hVar = null;
            }
            if (hVar == null) {
                f fVar2 = new f(context);
                linkedHashMap.put(context, fVar2);
                linkedHashMap2.put(oVar, context);
                fVar2.b(oVar);
                if (context instanceof Activity) {
                    this.f10424f.put(fVar2, this.f10421b.a(this.f10420a, q.a(WindowLayoutInfo.class), (Activity) context, new g(1, fVar2, f.class, "accept", "accept(Landroidx/window/extensions/layout/WindowLayoutInfo;)V", 0, 0)));
                } else {
                    fVar2.accept(new WindowLayoutInfo(m.o));
                    reentrantLock.unlock();
                    return;
                }
            }
            reentrantLock.unlock();
        } catch (Throwable th) {
            reentrantLock.unlock();
            throw th;
        }
    }
}
