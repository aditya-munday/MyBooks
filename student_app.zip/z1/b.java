package z1;

import androidx.window.extensions.layout.WindowLayoutInfo;
import p5.l;
import q5.g;
import q5.h;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* loaded from: classes.dex */
public final /* synthetic */ class b extends g implements l {
    @Override // p5.l
    public final Object a(Object obj) {
        WindowLayoutInfo windowLayoutInfo = (WindowLayoutInfo) obj;
        h.e(windowLayoutInfo, "p0");
        ((f) this.f9277p).accept(windowLayoutInfo);
        return g5.h.f6800a;
    }
}
