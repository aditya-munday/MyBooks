package A5;

import j5.EnumC0522a;
import k5.AbstractC0562c;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* loaded from: classes.dex */
public final class c extends B5.e {

    /* renamed from: r, reason: collision with root package name */
    public final B5.c f98r;

    /* renamed from: s, reason: collision with root package name */
    public final B5.c f99s;

    public c(B5.c cVar, i5.i iVar, int i6, z5.a aVar) {
        super(iVar, i6, aVar);
        this.f98r = cVar;
        this.f99s = cVar;
    }

    /* JADX WARN: Removed duplicated region for block: B:12:0x0053 A[RETURN] */
    /* JADX WARN: Removed duplicated region for block: B:14:0x0054  */
    /* JADX WARN: Removed duplicated region for block: B:18:0x0033  */
    /* JADX WARN: Removed duplicated region for block: B:8:0x0023  */
    @Override // B5.e
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final Object a(z5.p pVar, i5.d dVar) {
        b bVar;
        int i6;
        if (dVar instanceof b) {
            bVar = (b) dVar;
            int i7 = bVar.f97u;
            if ((i7 & Integer.MIN_VALUE) != 0) {
                bVar.f97u = i7 - Integer.MIN_VALUE;
                Object obj = bVar.f95s;
                i6 = bVar.f97u;
                g5.h hVar = g5.h.f6800a;
                if (i6 == 0) {
                    if (i6 == 1) {
                        pVar = bVar.f94r;
                        Q5.a.K(obj);
                    } else {
                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                    }
                } else {
                    Q5.a.K(obj);
                    bVar.f94r = pVar;
                    bVar.f97u = 1;
                    Object h6 = this.f98r.h(pVar, bVar);
                    EnumC0522a enumC0522a = EnumC0522a.o;
                    if (h6 != enumC0522a) {
                        h6 = hVar;
                    }
                    if (h6 == enumC0522a) {
                        return enumC0522a;
                    }
                }
                if (!((z5.o) pVar).f10495r.s()) {
                    return hVar;
                }
                throw new IllegalStateException("'awaitClose { yourCallbackOrListener.cancel() }' should be used in the end of callbackFlow block.\nOtherwise, a callback/listener may leak in case of external cancellation.\nSee callbackFlow API documentation for the details.");
            }
        }
        bVar = new b(this, (AbstractC0562c) dVar);
        Object obj2 = bVar.f95s;
        i6 = bVar.f97u;
        g5.h hVar2 = g5.h.f6800a;
        if (i6 == 0) {
        }
        if (!((z5.o) pVar).f10495r.s()) {
        }
    }

    @Override // B5.e
    public final String toString() {
        return "block[" + this.f98r + "] -> " + super.toString();
    }
}
