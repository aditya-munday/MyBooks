package A5;

import k5.AbstractC0562c;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* loaded from: classes.dex */
public final class n extends AbstractC0562c {

    /* renamed from: r, reason: collision with root package name */
    public X4.l f133r;

    /* renamed from: s, reason: collision with root package name */
    public /* synthetic */ Object f134s;

    /* renamed from: t, reason: collision with root package name */
    public int f135t;

    /* renamed from: u, reason: collision with root package name */
    public final /* synthetic */ X4.l f136u;

    /* renamed from: v, reason: collision with root package name */
    public Object f137v;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public n(X4.l lVar, i5.d dVar) {
        super(dVar);
        this.f136u = lVar;
    }

    @Override // k5.AbstractC0560a
    public final Object p(Object obj) {
        this.f134s = obj;
        this.f135t |= Integer.MIN_VALUE;
        return this.f136u.l(null, this);
    }
}
