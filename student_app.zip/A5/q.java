package A5;

import j5.EnumC0522a;
import k5.AbstractC0562c;
import x5.T;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* loaded from: classes.dex */
public final class q extends AbstractC0562c {

    /* renamed from: r, reason: collision with root package name */
    public r f143r;

    /* renamed from: s, reason: collision with root package name */
    public e f144s;

    /* renamed from: t, reason: collision with root package name */
    public t f145t;

    /* renamed from: u, reason: collision with root package name */
    public T f146u;

    /* renamed from: v, reason: collision with root package name */
    public Object f147v;

    /* renamed from: w, reason: collision with root package name */
    public /* synthetic */ Object f148w;

    /* renamed from: x, reason: collision with root package name */
    public final /* synthetic */ r f149x;
    public int y;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public q(r rVar, i5.d dVar) {
        super(dVar);
        this.f149x = rVar;
    }

    @Override // k5.AbstractC0560a
    public final Object p(Object obj) {
        this.f148w = obj;
        this.y |= Integer.MIN_VALUE;
        this.f149x.k(null, this);
        return EnumC0522a.o;
    }
}
