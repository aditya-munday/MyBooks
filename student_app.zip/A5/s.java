package A5;

import C5.v;
import J.C0096p;
import j5.EnumC0522a;
import java.util.concurrent.CancellationException;
import k5.AbstractC0562c;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* loaded from: classes.dex */
public abstract class s {

    /* renamed from: a, reason: collision with root package name */
    public static final v f152a = new v("NONE", 0);

    /* renamed from: b, reason: collision with root package name */
    public static final v f153b = new v("PENDING", 0);

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Removed duplicated region for block: B:18:0x0031  */
    /* JADX WARN: Removed duplicated region for block: B:9:0x001f  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public static final Object a(u uVar, C0096p c0096p, Throwable th, AbstractC0562c abstractC0562c) {
        g gVar;
        int i6;
        try {
            if (abstractC0562c instanceof g) {
                g gVar2 = (g) abstractC0562c;
                int i7 = gVar2.f108t;
                if ((i7 & Integer.MIN_VALUE) != 0) {
                    gVar2.f108t = i7 - Integer.MIN_VALUE;
                    gVar = gVar2;
                    Object obj = gVar.f107s;
                    i6 = gVar.f108t;
                    if (i6 == 0) {
                        if (i6 == 1) {
                            th = gVar.f106r;
                            Q5.a.K(obj);
                        } else {
                            throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                        }
                    } else {
                        Q5.a.K(obj);
                        gVar.f106r = th;
                        gVar.f108t = 1;
                        Object b6 = c0096p.b(uVar, th, gVar);
                        Object obj2 = EnumC0522a.o;
                        if (b6 == obj2) {
                            return obj2;
                        }
                    }
                    return g5.h.f6800a;
                }
            }
            if (i6 == 0) {
            }
            return g5.h.f6800a;
        } catch (Throwable th2) {
            if (th != null && th != th2) {
                android.support.v4.media.session.a.a(th2, th);
            }
            throw th2;
        }
        gVar = new AbstractC0562c(abstractC0562c);
        Object obj3 = gVar.f107s;
        i6 = gVar.f108t;
    }

    /* JADX WARN: Code restructure failed: missing block: B:27:0x0094, code lost:
    
        if (r11 == r5) goto L37;
     */
    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Removed duplicated region for block: B:16:0x006e  */
    /* JADX WARN: Removed duplicated region for block: B:19:0x006f  */
    /* JADX WARN: Removed duplicated region for block: B:22:0x007a A[Catch: all -> 0x0036, TryCatch #1 {all -> 0x0036, blocks: (B:12:0x002f, B:14:0x005e, B:20:0x0072, B:22:0x007a, B:24:0x0080, B:26:0x0086, B:28:0x0097, B:29:0x009f, B:30:0x00a0, B:31:0x00a7, B:39:0x0049, B:42:0x0054), top: B:7:0x0021 }] */
    /* JADX WARN: Removed duplicated region for block: B:32:0x00a8  */
    /* JADX WARN: Removed duplicated region for block: B:40:0x004d  */
    /* JADX WARN: Removed duplicated region for block: B:9:0x0023  */
    /* JADX WARN: Type inference failed for: r0v2, types: [A5.f, i5.d] */
    /* JADX WARN: Type inference failed for: r0v5 */
    /* JADX WARN: Type inference failed for: r0v6 */
    /* JADX WARN: Type inference failed for: r1v13 */
    /* JADX WARN: Type inference failed for: r1v14 */
    /* JADX WARN: Type inference failed for: r1v2, types: [A5.e] */
    /* JADX WARN: Type inference failed for: r1v3, types: [z5.b] */
    /* JADX WARN: Type inference failed for: r1v4 */
    /* JADX WARN: Type inference failed for: r1v6 */
    /* JADX WARN: Type inference failed for: r9v4, types: [z5.q] */
    /* JADX WARN: Type inference failed for: r9v6, types: [z5.q] */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:27:0x0094 -> B:13:0x0032). Please report as a decompilation issue!!! */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public static final Object b(e eVar, z5.o oVar, boolean z6, AbstractC0562c abstractC0562c) {
        ?? r02;
        int i6;
        CancellationException cancellationException;
        z5.o oVar2;
        z5.b bVar;
        ?? r12;
        z5.o oVar3;
        ?? r13;
        try {
            if (abstractC0562c instanceof f) {
                f fVar = (f) abstractC0562c;
                int i7 = fVar.f105w;
                if ((i7 & Integer.MIN_VALUE) != 0) {
                    fVar.f105w = i7 - Integer.MIN_VALUE;
                    r02 = fVar;
                    Object obj = r02.f104v;
                    i6 = r02.f105w;
                    cancellationException = null;
                    EnumC0522a enumC0522a = EnumC0522a.o;
                    if (i6 == 0) {
                        if (i6 != 1) {
                            if (i6 == 2) {
                                z6 = r02.f103u;
                                bVar = r02.f102t;
                                ?? r9 = r02.f101s;
                                e eVar2 = r02.f100r;
                                Q5.a.K(obj);
                                e eVar3 = eVar2;
                                z5.o oVar4 = r9;
                                e eVar4 = eVar3;
                                r13 = bVar;
                                eVar = eVar4;
                                oVar3 = oVar4;
                                r02.f100r = eVar;
                                r02.f101s = oVar3;
                                r02.f102t = r13;
                                r02.f103u = z6;
                                r02.f105w = 1;
                                obj = r13.b(r02);
                                if (obj == enumC0522a) {
                                    z5.b bVar2 = r13;
                                    r12 = eVar;
                                    bVar = bVar2;
                                    oVar2 = oVar3;
                                    if (((Boolean) obj).booleanValue()) {
                                        Object obj2 = bVar.o;
                                        v vVar = z5.e.f10482p;
                                        if (obj2 != vVar) {
                                            bVar.o = vVar;
                                            if (obj2 != z5.e.f10479l) {
                                                r02.f100r = r12;
                                                r02.f101s = oVar2;
                                                r02.f102t = bVar;
                                                r02.f103u = z6;
                                                r02.f105w = 2;
                                                Object l6 = r12.l(obj2, r02);
                                                eVar3 = r12;
                                                oVar4 = oVar2;
                                            } else {
                                                Throwable n6 = bVar.f10458q.n();
                                                int i8 = C5.u.f518a;
                                                throw n6;
                                            }
                                        } else {
                                            throw new IllegalStateException("`hasNext()` has not been invoked");
                                        }
                                    } else {
                                        if (z6) {
                                            oVar2.b(null);
                                        }
                                        return g5.h.f6800a;
                                    }
                                } else {
                                    return enumC0522a;
                                }
                            } else {
                                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                            }
                        } else {
                            z6 = r02.f103u;
                            bVar = r02.f102t;
                            ?? r92 = r02.f101s;
                            e eVar5 = r02.f100r;
                            Q5.a.K(obj);
                            r12 = eVar5;
                            oVar2 = r92;
                            if (((Boolean) obj).booleanValue()) {
                            }
                        }
                    } else {
                        Q5.a.K(obj);
                        if (!(eVar instanceof u)) {
                            z5.c cVar = oVar.f10495r;
                            cVar.getClass();
                            r13 = new z5.b(cVar);
                            oVar3 = oVar;
                            r02.f100r = eVar;
                            r02.f101s = oVar3;
                            r02.f102t = r13;
                            r02.f103u = z6;
                            r02.f105w = 1;
                            obj = r13.b(r02);
                            if (obj == enumC0522a) {
                            }
                        } else {
                            throw ((u) eVar).o;
                        }
                    }
                }
            }
            if (i6 == 0) {
            }
        } catch (Throwable th) {
            try {
                throw th;
            } catch (Throwable th2) {
                if (z6) {
                    if (th instanceof CancellationException) {
                        cancellationException = th;
                    }
                    if (cancellationException == null) {
                        cancellationException = new CancellationException("Channel was consumed, consumer had failed");
                        cancellationException.initCause(th);
                    }
                    oVar.b(cancellationException);
                }
                throw th2;
            }
        }
        r02 = new AbstractC0562c(abstractC0562c);
        Object obj3 = r02.f104v;
        i6 = r02.f105w;
        cancellationException = null;
        EnumC0522a enumC0522a2 = EnumC0522a.o;
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Removed duplicated region for block: B:19:0x005d  */
    /* JADX WARN: Removed duplicated region for block: B:22:0x0033  */
    /* JADX WARN: Removed duplicated region for block: B:8:0x001f  */
    /* JADX WARN: Type inference failed for: r5v2, types: [q5.p, java.lang.Object] */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public static final Object c(d dVar, AbstractC0562c abstractC0562c) {
        p pVar;
        int i6;
        q5.p pVar2;
        B5.a e;
        o oVar;
        if (abstractC0562c instanceof p) {
            p pVar3 = (p) abstractC0562c;
            int i7 = pVar3.f142u;
            if ((i7 & Integer.MIN_VALUE) != 0) {
                pVar3.f142u = i7 - Integer.MIN_VALUE;
                pVar = pVar3;
                Object obj = pVar.f141t;
                i6 = pVar.f142u;
                if (i6 == 0) {
                    if (i6 == 1) {
                        oVar = pVar.f140s;
                        pVar2 = pVar.f139r;
                        try {
                            Q5.a.K(obj);
                        } catch (B5.a e6) {
                            e = e6;
                            if (e.o != oVar) {
                            }
                            return pVar2.o;
                        }
                    } else {
                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                    }
                } else {
                    Q5.a.K(obj);
                    ?? obj2 = new Object();
                    o oVar2 = new o(obj2, 0);
                    try {
                        pVar.f139r = obj2;
                        pVar.f140s = oVar2;
                        pVar.f142u = 1;
                        Object k6 = dVar.k(oVar2, pVar);
                        Object obj3 = EnumC0522a.o;
                        if (k6 == obj3) {
                            return obj3;
                        }
                        pVar2 = obj2;
                    } catch (B5.a e7) {
                        pVar2 = obj2;
                        e = e7;
                        oVar = oVar2;
                        if (e.o != oVar) {
                            throw e;
                        }
                        return pVar2.o;
                    }
                }
                return pVar2.o;
            }
        }
        pVar = new AbstractC0562c(abstractC0562c);
        Object obj4 = pVar.f141t;
        i6 = pVar.f142u;
        if (i6 == 0) {
        }
        return pVar2.o;
    }
}
