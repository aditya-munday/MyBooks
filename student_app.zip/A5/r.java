package A5;

import C5.v;
import j5.EnumC0522a;
import java.util.Arrays;
import java.util.concurrent.atomic.AtomicReference;
import java.util.concurrent.atomic.AtomicReferenceFieldUpdater;
import x5.C0899f;
import x5.C0912t;
import x5.T;
import x5.d0;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* loaded from: classes.dex */
public final class r extends B5.b implements d, e, B5.h {

    /* renamed from: s, reason: collision with root package name */
    public static final /* synthetic */ AtomicReferenceFieldUpdater f150s = AtomicReferenceFieldUpdater.newUpdater(r.class, Object.class, "_state$volatile");
    private volatile /* synthetic */ Object _state$volatile;

    /* renamed from: r, reason: collision with root package name */
    public int f151r;

    public r(Object obj) {
        this._state$volatile = obj;
    }

    public final boolean a(Object obj, Object obj2) {
        int i6;
        t[] tVarArr;
        v vVar;
        synchronized (this) {
            AtomicReferenceFieldUpdater atomicReferenceFieldUpdater = f150s;
            Object obj3 = atomicReferenceFieldUpdater.get(this);
            if (obj != null && !q5.h.a(obj3, obj)) {
                return false;
            }
            if (q5.h.a(obj3, obj2)) {
                return true;
            }
            atomicReferenceFieldUpdater.set(this, obj2);
            int i7 = this.f151r;
            if ((i7 & 1) == 0) {
                int i8 = i7 + 1;
                this.f151r = i8;
                t[] tVarArr2 = this.o;
                while (true) {
                    if (tVarArr2 != null) {
                        for (t tVar : tVarArr2) {
                            if (tVar != null) {
                                AtomicReference atomicReference = tVar.f154a;
                                while (true) {
                                    Object obj4 = atomicReference.get();
                                    if (obj4 != null && obj4 != (vVar = s.f153b)) {
                                        v vVar2 = s.f152a;
                                        if (obj4 == vVar2) {
                                            while (!atomicReference.compareAndSet(obj4, vVar)) {
                                                if (atomicReference.get() != obj4) {
                                                    break;
                                                }
                                            }
                                        } else {
                                            while (!atomicReference.compareAndSet(obj4, vVar2)) {
                                                if (atomicReference.get() != obj4) {
                                                    break;
                                                }
                                            }
                                            ((C0899f) obj4).g(g5.h.f6800a);
                                            break;
                                        }
                                    }
                                }
                            }
                        }
                    }
                    synchronized (this) {
                        i6 = this.f151r;
                        if (i6 == i8) {
                            this.f151r = i8 + 1;
                            return true;
                        }
                        tVarArr = this.o;
                    }
                    tVarArr2 = tVarArr;
                    i8 = i6;
                }
            } else {
                this.f151r = i7 + 2;
                return true;
            }
        }
    }

    /* JADX WARN: Code restructure failed: missing block: B:27:0x00e3, code lost:
    
        if (r0.equals(r4) != false) goto L68;
     */
    /* JADX WARN: Code restructure failed: missing block: B:42:0x0145, code lost:
    
        if (r5 == r3) goto L82;
     */
    /* JADX WARN: Code restructure failed: missing block: B:44:0x0148, code lost:
    
        if (r4 != r3) goto L83;
     */
    /* JADX WARN: Removed duplicated region for block: B:18:0x00cf A[Catch: all -> 0x003f, TryCatch #2 {all -> 0x003f, blocks: (B:13:0x0039, B:16:0x00c7, B:18:0x00cf, B:21:0x00d6, B:22:0x00dc, B:26:0x00df, B:28:0x0100, B:31:0x0110, B:32:0x012c, B:39:0x013c, B:34:0x0133, B:38:0x0139, B:47:0x00e5, B:50:0x00ec, B:58:0x0054, B:60:0x005f, B:61:0x00b7), top: B:7:0x0027 }] */
    /* JADX WARN: Removed duplicated region for block: B:30:0x010f  */
    /* JADX WARN: Removed duplicated region for block: B:31:0x0110 A[Catch: all -> 0x003f, TryCatch #2 {all -> 0x003f, blocks: (B:13:0x0039, B:16:0x00c7, B:18:0x00cf, B:21:0x00d6, B:22:0x00dc, B:26:0x00df, B:28:0x0100, B:31:0x0110, B:32:0x012c, B:39:0x013c, B:34:0x0133, B:38:0x0139, B:47:0x00e5, B:50:0x00ec, B:58:0x0054, B:60:0x005f, B:61:0x00b7), top: B:7:0x0027 }] */
    /* JADX WARN: Removed duplicated region for block: B:49:0x00e9  */
    /* JADX WARN: Removed duplicated region for block: B:52:0x00fe  */
    /* JADX WARN: Removed duplicated region for block: B:54:0x00eb  */
    /* JADX WARN: Removed duplicated region for block: B:62:0x0063  */
    /* JADX WARN: Removed duplicated region for block: B:9:0x0029  */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:30:0x010f -> B:16:0x00c7). Please report as a decompilation issue!!! */
    @Override // A5.d
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final Object k(e eVar, i5.d dVar) {
        q qVar;
        EnumC0522a enumC0522a;
        int i6;
        t tVar;
        AtomicReference atomicReference;
        e eVar2;
        r rVar;
        t tVar2;
        T t6;
        e eVar3;
        Object obj;
        Object obj2;
        Object andSet;
        Object obj3;
        try {
            if (dVar instanceof q) {
                qVar = (q) dVar;
                int i7 = qVar.y;
                if ((i7 & Integer.MIN_VALUE) != 0) {
                    qVar.y = i7 - Integer.MIN_VALUE;
                    Object obj4 = qVar.f148w;
                    enumC0522a = EnumC0522a.o;
                    i6 = qVar.y;
                    int i8 = 3;
                    int i9 = 2;
                    if (i6 == 0) {
                        if (i6 != 1) {
                            if (i6 != 2) {
                                if (i6 == 3) {
                                    Object obj5 = qVar.f147v;
                                    t6 = qVar.f146u;
                                    tVar2 = qVar.f145t;
                                    eVar3 = qVar.f144s;
                                    rVar = qVar.f143r;
                                    Q5.a.K(obj4);
                                    obj = obj5;
                                    i8 = 3;
                                    i9 = 2;
                                    obj2 = f150s.get(rVar);
                                    if (t6 != null && !t6.a()) {
                                        throw ((d0) t6).z();
                                    }
                                    if (obj2 != B5.j.f236a) {
                                        obj3 = null;
                                    } else {
                                        obj3 = obj2;
                                    }
                                    qVar.f143r = rVar;
                                    qVar.f144s = eVar3;
                                    qVar.f145t = tVar2;
                                    qVar.f146u = t6;
                                    qVar.f147v = obj2;
                                    qVar.y = i9;
                                    if (eVar3.l(obj3, qVar) == enumC0522a) {
                                        return enumC0522a;
                                    }
                                    obj = obj2;
                                    AtomicReference atomicReference2 = tVar2.f154a;
                                    v vVar = s.f152a;
                                    andSet = atomicReference2.getAndSet(vVar);
                                    q5.h.b(andSet);
                                    if (andSet == s.f153b) {
                                        obj2 = f150s.get(rVar);
                                        if (t6 != null) {
                                            throw ((d0) t6).z();
                                        }
                                        if (obj2 != B5.j.f236a) {
                                        }
                                        qVar.f143r = rVar;
                                        qVar.f144s = eVar3;
                                        qVar.f145t = tVar2;
                                        qVar.f146u = t6;
                                        qVar.f147v = obj2;
                                        qVar.y = i9;
                                        if (eVar3.l(obj3, qVar) == enumC0522a) {
                                        }
                                        obj = obj2;
                                        AtomicReference atomicReference22 = tVar2.f154a;
                                        v vVar2 = s.f152a;
                                        andSet = atomicReference22.getAndSet(vVar2);
                                        q5.h.b(andSet);
                                        if (andSet == s.f153b) {
                                            qVar.f143r = rVar;
                                            qVar.f144s = eVar3;
                                            qVar.f145t = tVar2;
                                            qVar.f146u = t6;
                                            qVar.f147v = obj;
                                            qVar.y = i8;
                                            g5.h hVar = g5.h.f6800a;
                                            C0899f c0899f = new C0899f(1, Q5.a.w(qVar));
                                            c0899f.u();
                                            AtomicReference atomicReference3 = tVar2.f154a;
                                            while (true) {
                                                if (atomicReference3.compareAndSet(vVar2, c0899f)) {
                                                    break;
                                                }
                                                if (atomicReference3.get() != vVar2) {
                                                    c0899f.g(hVar);
                                                    break;
                                                }
                                            }
                                            Object t7 = c0899f.t();
                                            if (t7 == EnumC0522a.o) {
                                            }
                                        }
                                    }
                                } else {
                                    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                                }
                            } else {
                                obj2 = qVar.f147v;
                                t6 = qVar.f146u;
                                tVar2 = qVar.f145t;
                                eVar3 = qVar.f144s;
                                rVar = qVar.f143r;
                                Q5.a.K(obj4);
                                obj = obj2;
                                AtomicReference atomicReference222 = tVar2.f154a;
                                v vVar22 = s.f152a;
                                andSet = atomicReference222.getAndSet(vVar22);
                                q5.h.b(andSet);
                                if (andSet == s.f153b) {
                                }
                            }
                        } else {
                            tVar2 = qVar.f145t;
                            eVar2 = qVar.f144s;
                            rVar = qVar.f143r;
                            Q5.a.K(obj4);
                        }
                    } else {
                        Q5.a.K(obj4);
                        synchronized (this) {
                            try {
                                t[] tVarArr = this.o;
                                if (tVarArr == null) {
                                    tVarArr = new t[2];
                                    this.o = tVarArr;
                                } else if (this.f221p >= tVarArr.length) {
                                    Object[] copyOf = Arrays.copyOf(tVarArr, tVarArr.length * 2);
                                    q5.h.d(copyOf, "copyOf(...)");
                                    this.o = (t[]) copyOf;
                                    tVarArr = (t[]) copyOf;
                                }
                                int i10 = this.f222q;
                                do {
                                    tVar = tVarArr[i10];
                                    if (tVar == null) {
                                        tVar = new t();
                                        tVarArr[i10] = tVar;
                                    }
                                    i10++;
                                    if (i10 >= tVarArr.length) {
                                        i10 = 0;
                                    }
                                    atomicReference = tVar.f154a;
                                } while (atomicReference.get() != null);
                                atomicReference.set(s.f152a);
                                this.f222q = i10;
                                this.f221p++;
                            } catch (Throwable th) {
                                throw th;
                            }
                        }
                        eVar2 = eVar;
                        rVar = this;
                        tVar2 = tVar;
                    }
                    i5.i iVar = qVar.f8000p;
                    q5.h.b(iVar);
                    t6 = (T) iVar.m(C0912t.f10343p);
                    eVar3 = eVar2;
                    obj = null;
                    obj2 = f150s.get(rVar);
                    if (t6 != null) {
                    }
                    if (obj2 != B5.j.f236a) {
                    }
                    qVar.f143r = rVar;
                    qVar.f144s = eVar3;
                    qVar.f145t = tVar2;
                    qVar.f146u = t6;
                    qVar.f147v = obj2;
                    qVar.y = i9;
                    if (eVar3.l(obj3, qVar) == enumC0522a) {
                    }
                    obj = obj2;
                    AtomicReference atomicReference2222 = tVar2.f154a;
                    v vVar222 = s.f152a;
                    andSet = atomicReference2222.getAndSet(vVar222);
                    q5.h.b(andSet);
                    if (andSet == s.f153b) {
                    }
                }
            }
            if (i6 == 0) {
            }
            i5.i iVar2 = qVar.f8000p;
            q5.h.b(iVar2);
            t6 = (T) iVar2.m(C0912t.f10343p);
            eVar3 = eVar2;
            obj = null;
            obj2 = f150s.get(rVar);
            if (t6 != null) {
            }
            if (obj2 != B5.j.f236a) {
            }
            qVar.f143r = rVar;
            qVar.f144s = eVar3;
            qVar.f145t = tVar2;
            qVar.f146u = t6;
            qVar.f147v = obj2;
            qVar.y = i9;
            if (eVar3.l(obj3, qVar) == enumC0522a) {
            }
            obj = obj2;
            AtomicReference atomicReference22222 = tVar2.f154a;
            v vVar2222 = s.f152a;
            andSet = atomicReference22222.getAndSet(vVar2222);
            q5.h.b(andSet);
            if (andSet == s.f153b) {
            }
        } catch (Throwable th2) {
            synchronized (rVar) {
                try {
                    int i11 = rVar.f221p - 1;
                    rVar.f221p = i11;
                    if (i11 == 0) {
                        rVar.f222q = 0;
                    }
                    q5.h.c(tVar2, "null cannot be cast to non-null type kotlinx.coroutines.flow.internal.AbstractSharedFlowSlot<kotlin.Any>");
                    tVar2.f154a.set(null);
                    throw th2;
                } catch (Throwable th3) {
                    throw th3;
                }
            }
        }
        qVar = new q(this, dVar);
        Object obj42 = qVar.f148w;
        enumC0522a = EnumC0522a.o;
        i6 = qVar.y;
        int i82 = 3;
        int i92 = 2;
    }

    @Override // A5.e
    public final Object l(Object obj, i5.d dVar) {
        if (obj == null) {
            obj = B5.j.f236a;
        }
        a(null, obj);
        return g5.h.f6800a;
    }
}
