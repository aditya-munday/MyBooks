package A5;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* loaded from: classes.dex */
public final class u implements e {
    public final Throwable o;

    public u(Throwable th) {
        this.o = th;
    }

    @Override // A5.e
    public final Object l(Object obj, i5.d dVar) {
        throw this.o;
    }
}
