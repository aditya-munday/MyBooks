package A5;

import J.C0096p;
import j5.EnumC0522a;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* loaded from: classes.dex */
public final class i implements d {
    public final /* synthetic */ A1.l o;

    /* renamed from: p, reason: collision with root package name */
    public final /* synthetic */ C0096p f114p;

    public i(A1.l lVar, C0096p c0096p) {
        this.o = lVar;
        this.f114p = c0096p;
    }

    /* JADX WARN: Removed duplicated region for block: B:32:0x007c  */
    /* JADX WARN: Removed duplicated region for block: B:33:0x00a0 A[RETURN] */
    /* JADX WARN: Removed duplicated region for block: B:41:? A[RETURN, SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:42:0x0050  */
    /* JADX WARN: Removed duplicated region for block: B:8:0x0024  */
    @Override // A5.d
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final Object k(e eVar, i5.d dVar) {
        h hVar;
        int i6;
        EnumC0522a enumC0522a;
        i iVar;
        u uVar;
        C0096p c0096p;
        B5.l lVar;
        Throwable th;
        B5.l lVar2;
        C0096p c0096p2;
        try {
            if (dVar instanceof h) {
                hVar = (h) dVar;
                int i7 = hVar.f110s;
                if ((i7 & Integer.MIN_VALUE) != 0) {
                    hVar.f110s = i7 - Integer.MIN_VALUE;
                    Object obj = hVar.f109r;
                    i6 = hVar.f110s;
                    enumC0522a = EnumC0522a.o;
                    if (i6 == 0) {
                        if (i6 != 1) {
                            if (i6 != 2) {
                                if (i6 == 3) {
                                    lVar2 = (B5.l) hVar.f112u;
                                    try {
                                        Q5.a.K(obj);
                                        lVar2.q();
                                        return g5.h.f6800a;
                                    } catch (Throwable th2) {
                                        th = th2;
                                        lVar2.q();
                                        throw th;
                                    }
                                }
                                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                            }
                            Throwable th3 = (Throwable) hVar.f112u;
                            Q5.a.K(obj);
                            throw th3;
                        }
                        eVar = hVar.f113v;
                        iVar = (i) hVar.f112u;
                        try {
                            Q5.a.K(obj);
                        } catch (Throwable th4) {
                            th = th4;
                            uVar = new u(th);
                            c0096p = iVar.f114p;
                            hVar.f112u = th;
                            hVar.f113v = null;
                            hVar.f110s = 2;
                            if (s.a(uVar, c0096p, th, hVar) != enumC0522a) {
                            }
                        }
                    } else {
                        Q5.a.K(obj);
                        try {
                            A1.l lVar3 = this.o;
                            hVar.f112u = this;
                            hVar.f113v = eVar;
                            hVar.f110s = 1;
                            if (lVar3.k(eVar, hVar) != enumC0522a) {
                                iVar = this;
                            }
                        } catch (Throwable th5) {
                            th = th5;
                            iVar = this;
                            uVar = new u(th);
                            c0096p = iVar.f114p;
                            hVar.f112u = th;
                            hVar.f113v = null;
                            hVar.f110s = 2;
                            if (s.a(uVar, c0096p, th, hVar) != enumC0522a) {
                                return enumC0522a;
                            }
                            throw th;
                        }
                        return enumC0522a;
                    }
                    i5.i iVar2 = hVar.f8000p;
                    q5.h.b(iVar2);
                    lVar = new B5.l(eVar, iVar2);
                    c0096p2 = iVar.f114p;
                    hVar.f112u = lVar;
                    hVar.f113v = null;
                    hVar.f110s = 3;
                    if (c0096p2.b(lVar, null, hVar) != enumC0522a) {
                        lVar2 = lVar;
                        lVar2.q();
                        return g5.h.f6800a;
                    }
                    return enumC0522a;
                }
            }
            c0096p2 = iVar.f114p;
            hVar.f112u = lVar;
            hVar.f113v = null;
            hVar.f110s = 3;
            if (c0096p2.b(lVar, null, hVar) != enumC0522a) {
            }
            return enumC0522a;
        } catch (Throwable th6) {
            th = th6;
            lVar2 = lVar;
            lVar2.q();
            throw th;
        }
        hVar = new h(this, dVar);
        Object obj2 = hVar.f109r;
        i6 = hVar.f110s;
        enumC0522a = EnumC0522a.o;
        if (i6 == 0) {
        }
        i5.i iVar22 = hVar.f8000p;
        q5.h.b(iVar22);
        lVar = new B5.l(eVar, iVar22);
    }
}
