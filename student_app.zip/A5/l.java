package A5;

import J.C0095o;
import X4.B;
import X4.C;
import j5.EnumC0522a;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* loaded from: classes.dex */
public final class l implements e {
    public final /* synthetic */ int o = 2;

    /* renamed from: p, reason: collision with root package name */
    public final Object f126p;

    /* renamed from: q, reason: collision with root package name */
    public final Object f127q;

    /* renamed from: r, reason: collision with root package name */
    public final Object f128r;

    public l(e eVar, M.d dVar, B b6) {
        this.f127q = eVar;
        this.f126p = dVar;
        this.f128r = b6;
    }

    /* JADX WARN: Removed duplicated region for block: B:10:0x0024  */
    /* JADX WARN: Removed duplicated region for block: B:17:0x0032  */
    /* JADX WARN: Removed duplicated region for block: B:33:0x0098  */
    /* JADX WARN: Removed duplicated region for block: B:41:0x00e4  */
    /* JADX WARN: Removed duplicated region for block: B:46:? A[RETURN, SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:49:0x00b2  */
    @Override // A5.e
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final Object l(Object obj, i5.d dVar) {
        k kVar;
        Object obj2;
        int i6;
        l lVar;
        X4.o oVar;
        int i7;
        switch (this.o) {
            case 0:
                if (dVar instanceof k) {
                    kVar = (k) dVar;
                    int i8 = kVar.f125v;
                    if ((i8 & Integer.MIN_VALUE) != 0) {
                        kVar.f125v = i8 - Integer.MIN_VALUE;
                        obj2 = kVar.f123t;
                        i6 = kVar.f125v;
                        g5.h hVar = g5.h.f6800a;
                        EnumC0522a enumC0522a = EnumC0522a.o;
                        if (i6 == 0) {
                            if (i6 != 1) {
                                if (i6 != 2) {
                                    if (i6 != 3) {
                                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                                    }
                                } else {
                                    obj = kVar.f122s;
                                    lVar = kVar.f121r;
                                    Q5.a.K(obj2);
                                }
                            }
                            Q5.a.K(obj2);
                            return hVar;
                        }
                        Q5.a.K(obj2);
                        if (((q5.n) this.f126p).o) {
                            e eVar = (e) this.f127q;
                            kVar.f125v = 1;
                            if (eVar.l(obj, kVar) != enumC0522a) {
                                return hVar;
                            }
                        } else {
                            C0095o c0095o = (C0095o) this.f128r;
                            kVar.f121r = this;
                            kVar.f122s = obj;
                            kVar.f125v = 2;
                            obj2 = c0095o.h(obj, kVar);
                            if (obj2 != enumC0522a) {
                                lVar = this;
                            }
                        }
                        return enumC0522a;
                        if (((Boolean) obj2).booleanValue()) {
                            ((q5.n) lVar.f126p).o = true;
                            e eVar2 = (e) lVar.f127q;
                            kVar.f121r = null;
                            kVar.f122s = null;
                            kVar.f125v = 3;
                            if (eVar2.l(obj, kVar) != enumC0522a) {
                                return hVar;
                            }
                            return enumC0522a;
                        }
                        return hVar;
                    }
                }
                kVar = new k(this, dVar);
                obj2 = kVar.f123t;
                i6 = kVar.f125v;
                g5.h hVar2 = g5.h.f6800a;
                EnumC0522a enumC0522a2 = EnumC0522a.o;
                if (i6 == 0) {
                }
                if (((Boolean) obj2).booleanValue()) {
                }
            case 1:
                Object b6 = B5.j.b((i5.i) this.f126p, obj, this.f127q, (B5.d) this.f128r, dVar);
                if (b6 != EnumC0522a.o) {
                    return g5.h.f6800a;
                }
                return b6;
            default:
                if (dVar instanceof X4.o) {
                    oVar = (X4.o) dVar;
                    int i9 = oVar.f3681s;
                    if ((i9 & Integer.MIN_VALUE) != 0) {
                        oVar.f3681s = i9 - Integer.MIN_VALUE;
                        Object obj3 = oVar.f3680r;
                        i7 = oVar.f3681s;
                        if (i7 == 0) {
                            if (i7 == 1) {
                                Q5.a.K(obj3);
                            } else {
                                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                            }
                        } else {
                            Q5.a.K(obj3);
                            e eVar3 = (e) this.f127q;
                            Double d6 = (Double) C.c(((M.b) obj).c((M.d) this.f126p), ((B) this.f128r).f3639q);
                            oVar.f3681s = 1;
                            Object l6 = eVar3.l(d6, oVar);
                            EnumC0522a enumC0522a3 = EnumC0522a.o;
                            if (l6 == enumC0522a3) {
                                return enumC0522a3;
                            }
                        }
                        return g5.h.f6800a;
                    }
                }
                oVar = new X4.o(this, dVar);
                Object obj32 = oVar.f3680r;
                i7 = oVar.f3681s;
                if (i7 == 0) {
                }
                return g5.h.f6800a;
        }
    }

    public l(q5.n nVar, e eVar, C0095o c0095o) {
        this.f126p = nVar;
        this.f127q = eVar;
        this.f128r = c0095o;
    }

    public l(e eVar, i5.i iVar) {
        this.f126p = iVar;
        this.f127q = C5.a.k(iVar);
        this.f128r = new B5.d(eVar, (i5.d) null, 2);
    }
}
