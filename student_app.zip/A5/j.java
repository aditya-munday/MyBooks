package A5;

import k5.AbstractC0562c;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* loaded from: classes.dex */
public final class j extends AbstractC0562c {

    /* renamed from: r, reason: collision with root package name */
    public /* synthetic */ Object f115r;

    /* renamed from: s, reason: collision with root package name */
    public int f116s;

    /* renamed from: t, reason: collision with root package name */
    public final /* synthetic */ A.c f117t;

    /* renamed from: u, reason: collision with root package name */
    public A.c f118u;

    /* renamed from: v, reason: collision with root package name */
    public e f119v;

    /* renamed from: w, reason: collision with root package name */
    public B5.l f120w;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public j(A.c cVar, i5.d dVar) {
        super(dVar);
        this.f117t = cVar;
    }

    @Override // k5.AbstractC0560a
    public final Object p(Object obj) {
        this.f115r = obj;
        this.f116s |= Integer.MIN_VALUE;
        return this.f117t.k(null, this);
    }
}
