package A5;

import J.E;
import J.P;
import j5.EnumC0522a;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* loaded from: classes.dex */
public final class o implements e {
    public final /* synthetic */ int o;

    /* renamed from: p, reason: collision with root package name */
    public final /* synthetic */ Object f138p;

    public /* synthetic */ o(Object obj, int i6) {
        this.o = i6;
        this.f138p = obj;
    }

    @Override // A5.e
    public final Object l(Object obj, i5.d dVar) {
        Object e;
        switch (this.o) {
            case 0:
                ((q5.p) this.f138p).o = obj;
                throw new B5.a(this);
            case 1:
                E e6 = (E) this.f138p;
                if ((e6.f1125v.p() instanceof P) || (e = E.e(e6, true, dVar)) != EnumC0522a.o) {
                    return g5.h.f6800a;
                }
                return e;
            default:
                ((C.a) this.f138p).accept(obj);
                return g5.h.f6800a;
        }
    }
}
