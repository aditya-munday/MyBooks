package A5;

import k5.AbstractC0562c;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* loaded from: classes.dex */
public final class b extends AbstractC0562c {

    /* renamed from: r, reason: collision with root package name */
    public z5.p f94r;

    /* renamed from: s, reason: collision with root package name */
    public /* synthetic */ Object f95s;

    /* renamed from: t, reason: collision with root package name */
    public final /* synthetic */ c f96t;

    /* renamed from: u, reason: collision with root package name */
    public int f97u;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public b(c cVar, AbstractC0562c abstractC0562c) {
        super(abstractC0562c);
        this.f96t = cVar;
    }

    @Override // k5.AbstractC0560a
    public final Object p(Object obj) {
        this.f95s = obj;
        this.f97u |= Integer.MIN_VALUE;
        return this.f96t.a(null, this);
    }
}
