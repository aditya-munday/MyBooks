package A5;

import k5.AbstractC0562c;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* loaded from: classes.dex */
public final class g extends AbstractC0562c {

    /* renamed from: r, reason: collision with root package name */
    public Throwable f106r;

    /* renamed from: s, reason: collision with root package name */
    public /* synthetic */ Object f107s;

    /* renamed from: t, reason: collision with root package name */
    public int f108t;

    @Override // k5.AbstractC0560a
    public final Object p(Object obj) {
        this.f107s = obj;
        this.f108t |= Integer.MIN_VALUE;
        return s.a(null, null, null, this);
    }
}
