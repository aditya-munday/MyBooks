package A5;

import k5.AbstractC0562c;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* loaded from: classes.dex */
public final class a extends AbstractC0562c {

    /* renamed from: r, reason: collision with root package name */
    public B5.l f90r;

    /* renamed from: s, reason: collision with root package name */
    public /* synthetic */ Object f91s;

    /* renamed from: t, reason: collision with root package name */
    public final /* synthetic */ x3.c f92t;

    /* renamed from: u, reason: collision with root package name */
    public int f93u;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public a(x3.c cVar, i5.d dVar) {
        super(dVar);
        this.f92t = cVar;
    }

    @Override // k5.AbstractC0560a
    public final Object p(Object obj) {
        this.f91s = obj;
        this.f93u |= Integer.MIN_VALUE;
        return this.f92t.k(null, this);
    }
}
