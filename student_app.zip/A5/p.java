package A5;

import k5.AbstractC0562c;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* loaded from: classes.dex */
public final class p extends AbstractC0562c {

    /* renamed from: r, reason: collision with root package name */
    public q5.p f139r;

    /* renamed from: s, reason: collision with root package name */
    public o f140s;

    /* renamed from: t, reason: collision with root package name */
    public /* synthetic */ Object f141t;

    /* renamed from: u, reason: collision with root package name */
    public int f142u;

    @Override // k5.AbstractC0560a
    public final Object p(Object obj) {
        this.f141t = obj;
        this.f142u |= Integer.MIN_VALUE;
        return s.c(null, this);
    }
}
