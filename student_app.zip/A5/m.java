package A5;

import k5.AbstractC0562c;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* loaded from: classes.dex */
public final class m extends AbstractC0562c {

    /* renamed from: r, reason: collision with root package name */
    public /* synthetic */ Object f129r;

    /* renamed from: s, reason: collision with root package name */
    public int f130s;

    /* renamed from: t, reason: collision with root package name */
    public final /* synthetic */ A.c f131t;

    /* renamed from: u, reason: collision with root package name */
    public X4.l f132u;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public m(A.c cVar, i5.d dVar) {
        super(dVar);
        this.f131t = cVar;
    }

    @Override // k5.AbstractC0560a
    public final Object p(Object obj) {
        this.f129r = obj;
        this.f130s |= Integer.MIN_VALUE;
        return this.f131t.k(null, this);
    }
}
