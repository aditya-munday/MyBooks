package A5;

import k5.AbstractC0562c;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* loaded from: classes.dex */
public final class h extends AbstractC0562c {

    /* renamed from: r, reason: collision with root package name */
    public /* synthetic */ Object f109r;

    /* renamed from: s, reason: collision with root package name */
    public int f110s;

    /* renamed from: t, reason: collision with root package name */
    public final /* synthetic */ i f111t;

    /* renamed from: u, reason: collision with root package name */
    public Object f112u;

    /* renamed from: v, reason: collision with root package name */
    public e f113v;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public h(i iVar, i5.d dVar) {
        super(dVar);
        this.f111t = iVar;
    }

    @Override // k5.AbstractC0560a
    public final Object p(Object obj) {
        this.f109r = obj;
        this.f110s |= Integer.MIN_VALUE;
        return this.f111t.k(null, this);
    }
}
