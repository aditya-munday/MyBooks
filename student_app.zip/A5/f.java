package A5;

import k5.AbstractC0562c;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* loaded from: classes.dex */
public final class f extends AbstractC0562c {

    /* renamed from: r, reason: collision with root package name */
    public e f100r;

    /* renamed from: s, reason: collision with root package name */
    public z5.q f101s;

    /* renamed from: t, reason: collision with root package name */
    public z5.b f102t;

    /* renamed from: u, reason: collision with root package name */
    public boolean f103u;

    /* renamed from: v, reason: collision with root package name */
    public /* synthetic */ Object f104v;

    /* renamed from: w, reason: collision with root package name */
    public int f105w;

    @Override // k5.AbstractC0560a
    public final Object p(Object obj) {
        this.f104v = obj;
        this.f105w |= Integer.MIN_VALUE;
        return s.b(null, null, false, this);
    }
}
