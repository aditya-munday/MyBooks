package w;

import A.m;
import android.graphics.Typeface;
import android.graphics.fonts.Font;
import android.net.Uri;
import android.text.TextUtils;
import android.util.Log;
import java.io.IOException;
import java.util.Objects;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* renamed from: w.j, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0864j extends C0863i {
    @Override // w.C0863i
    public final Font s(m mVar) {
        String str;
        Font d6;
        Uri uri = mVar.f31a;
        boolean equals = Objects.equals(uri.getScheme(), "systemfont");
        String str2 = mVar.e;
        if (equals) {
            str = uri.getAuthority();
        } else {
            str = null;
        }
        if (str != null) {
            Typeface create = Typeface.create(str, 0);
            Typeface create2 = Typeface.create(Typeface.DEFAULT, 0);
            if (create == null || create.equals(create2)) {
                create = null;
            }
            if (create != null && (d6 = AbstractC0858d.d(create)) != null) {
                if (TextUtils.isEmpty(str2)) {
                    return d6;
                }
                try {
                    return new Font.Builder(d6).setFontVariationSettings(str2).build();
                } catch (IOException unused) {
                    Log.e("TypefaceCompatApi31Impl", "Failed to clone Font instance. Fall back to provider font.");
                    return null;
                }
            }
        }
        return null;
    }
}
