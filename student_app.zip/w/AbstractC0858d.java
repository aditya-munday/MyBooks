package w;

import A.k;
import A.p;
import A.q;
import Z4.s;
import android.content.Context;
import android.content.res.Resources;
import android.graphics.Paint;
import android.graphics.Typeface;
import android.graphics.fonts.Font;
import android.graphics.fonts.FontFamily;
import android.graphics.text.PositionedGlyphs;
import android.graphics.text.TextRunShaper;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.os.Trace;
import android.text.TextUtils;
import android.util.Log;
import java.io.IOException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Objects;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;
import l.r;
import org.apache.tika.utils.StringUtils;
import v.C0819b;
import v.C0821d;
import v.InterfaceC0818a;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* renamed from: w.d, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public abstract class AbstractC0858d {

    /* renamed from: a, reason: collision with root package name */
    public static final s4.d f10056a;

    /* renamed from: b, reason: collision with root package name */
    public static final p.i f10057b;

    /* renamed from: c, reason: collision with root package name */
    public static Paint f10058c;

    static {
        Trace.beginSection(T5.h.M("TypefaceCompat static init"));
        int i6 = Build.VERSION.SDK_INT;
        if (i6 >= 31) {
            f10056a = new s4.d();
        } else if (i6 >= 29) {
            f10056a = new s4.d();
        } else if (i6 >= 28) {
            f10056a = new C0861g();
        } else if (i6 >= 26) {
            f10056a = new C0861g();
        } else {
            Method method = C0860f.f10065c;
            if (method == null) {
                Log.w("TypefaceCompatApi24Impl", "Unable to collect necessary private methods.Fallback to legacy implementation.");
            }
            if (method != null) {
                f10056a = new s4.d();
            } else {
                f10056a = new s4.d();
            }
        }
        f10057b = new p.i(16);
        f10058c = null;
        Trace.endSection();
    }

    /* JADX WARN: Type inference failed for: r5v11, types: [Z4.s, java.lang.Object] */
    public static Typeface a(Context context, InterfaceC0818a interfaceC0818a, Resources resources, int i6, String str, int i7, int i8, r rVar) {
        Typeface b6;
        Typeface build;
        FontFamily build2;
        boolean z6;
        Handler handler;
        int i9 = 3;
        if (interfaceC0818a instanceof C0821d) {
            C0821d c0821d = (C0821d) interfaceC0818a;
            String str2 = c0821d.f9786d;
            b6 = null;
            int i10 = 1;
            int i11 = 0;
            if (TextUtils.isEmpty(str2) || (build = c(str2)) == null) {
                ArrayList arrayList = c0821d.f9783a;
                if (arrayList.size() == 1) {
                    build = c(((A.g) arrayList.get(0)).e);
                } else {
                    if (Build.VERSION.SDK_INT >= 31) {
                        int i12 = 0;
                        while (true) {
                            if (i12 < arrayList.size()) {
                                if (c(((A.g) arrayList.get(i12)).e) == null) {
                                    break;
                                }
                                i12++;
                            } else {
                                Typeface.CustomFallbackBuilder customFallbackBuilder = null;
                                int i13 = 0;
                                while (true) {
                                    if (i13 >= arrayList.size()) {
                                        break;
                                    }
                                    A.g gVar = (A.g) arrayList.get(i13);
                                    if (i13 == arrayList.size() - 1 && TextUtils.isEmpty(gVar.f15f)) {
                                        customFallbackBuilder.setSystemFallback(gVar.e);
                                        break;
                                    }
                                    String str3 = gVar.e;
                                    String str4 = gVar.f15f;
                                    Font d6 = d(c(str3));
                                    if (d6 == null) {
                                        Log.w("TypefaceCompat", "Unable identify the primary font for " + gVar.e + ". Falling back to provider font.");
                                        break;
                                    }
                                    if (TextUtils.isEmpty(str4)) {
                                        try {
                                            build2 = new FontFamily.Builder(AbstractC0857c.a(d6).setFontVariationSettings(str4).build()).build();
                                        } catch (IOException unused) {
                                            Log.e("TypefaceCompat", "Failed to clone Font instance. Fall back to provider font.");
                                        }
                                    } else {
                                        build2 = new FontFamily.Builder(d6).build();
                                    }
                                    if (customFallbackBuilder == null) {
                                        customFallbackBuilder = new Typeface.CustomFallbackBuilder(build2);
                                    } else {
                                        customFallbackBuilder.addCustomFallback(build2);
                                    }
                                    i13++;
                                }
                                build = customFallbackBuilder.build();
                            }
                        }
                    }
                    build = null;
                }
            }
            if (build != null) {
                new Handler(Looper.getMainLooper()).post(new org.apache.tika.pipes.async.b(rVar, build, i9));
                f10057b.b(b(resources, i6, str, i7, i8), build);
                return build;
            }
            if (c0821d.f9785c == 0) {
                z6 = true;
            } else {
                z6 = false;
            }
            int i14 = c0821d.f9784b;
            Handler handler2 = new Handler(Looper.getMainLooper());
            ?? obj = new Object();
            obj.o = rVar;
            ArrayList arrayList2 = c0821d.f9783a;
            p pVar = new p(handler2, 0);
            A.c cVar = new A.c(obj, pVar, i11);
            if (z6) {
                if (arrayList2.size() <= 1) {
                    A.g gVar2 = (A.g) arrayList2.get(0);
                    p.i iVar = k.f25a;
                    ArrayList arrayList3 = new ArrayList(1);
                    Object obj2 = new Object[]{gVar2}[0];
                    Objects.requireNonNull(obj2);
                    arrayList3.add(obj2);
                    String a6 = k.a(i8, Collections.unmodifiableList(arrayList3));
                    Typeface typeface = (Typeface) k.f25a.a(a6);
                    if (typeface != null) {
                        pVar.execute(new A.a(obj, typeface, i11));
                        b6 = typeface;
                    } else if (i14 == -1) {
                        ArrayList arrayList4 = new ArrayList(1);
                        Object obj3 = new Object[]{gVar2}[0];
                        Objects.requireNonNull(obj3);
                        arrayList4.add(obj3);
                        A.j b7 = k.b(a6, context, Collections.unmodifiableList(arrayList4), i8);
                        cVar.t(b7);
                        b6 = b7.f23a;
                    } else {
                        try {
                            try {
                                try {
                                    A.j jVar = (A.j) k.f26b.submit(new A.h(a6, context, gVar2, i8, 0)).get(i14, TimeUnit.MILLISECONDS);
                                    cVar.t(jVar);
                                    b6 = jVar.f23a;
                                } catch (InterruptedException e) {
                                    throw e;
                                }
                            } catch (ExecutionException e6) {
                                throw new RuntimeException(e6);
                            } catch (TimeoutException unused2) {
                                throw new InterruptedException("timeout");
                            }
                        } catch (InterruptedException unused3) {
                            ((p) cVar.f5q).execute(new A.b((s) cVar.f4p, -3));
                        }
                    }
                } else {
                    throw new IllegalArgumentException("Fallbacks with blocking fetches are not supported for performance reasons");
                }
            } else {
                String a7 = k.a(i8, arrayList2);
                Typeface typeface2 = (Typeface) k.f25a.a(a7);
                if (typeface2 != null) {
                    pVar.execute(new A.a(obj, typeface2, i11));
                    b6 = typeface2;
                } else {
                    A.i iVar2 = new A.i(cVar, i11);
                    synchronized (k.f27c) {
                        try {
                            p.j jVar2 = k.f28d;
                            ArrayList arrayList5 = (ArrayList) jVar2.get(a7);
                            if (arrayList5 != null) {
                                arrayList5.add(iVar2);
                            } else {
                                ArrayList arrayList6 = new ArrayList();
                                arrayList6.add(iVar2);
                                jVar2.put(a7, arrayList6);
                                A.h hVar = new A.h(a7, context, arrayList2, i8, 1);
                                ThreadPoolExecutor threadPoolExecutor = k.f26b;
                                A.i iVar3 = new A.i(a7, i10);
                                if (Looper.myLooper() == null) {
                                    handler = new Handler(Looper.getMainLooper());
                                } else {
                                    handler = new Handler();
                                }
                                q qVar = new q();
                                qVar.f37p = hVar;
                                qVar.f38q = iVar3;
                                qVar.f39r = handler;
                                threadPoolExecutor.execute(qVar);
                            }
                        } finally {
                        }
                    }
                }
            }
        } else {
            b6 = f10056a.b(context, (C0819b) interfaceC0818a, resources, i8);
            if (b6 != null) {
                new Handler(Looper.getMainLooper()).post(new org.apache.tika.pipes.async.b(rVar, b6, i9));
            } else {
                rVar.a();
            }
        }
        if (b6 != null) {
            f10057b.b(b(resources, i6, str, i7, i8), b6);
        }
        return b6;
    }

    public static String b(Resources resources, int i6, String str, int i7, int i8) {
        return resources.getResourcePackageName(i6) + '-' + str + '-' + i7 + '-' + i6 + '-' + i8;
    }

    public static Typeface c(String str) {
        if (str != null && !str.isEmpty()) {
            Typeface create = Typeface.create(str, 0);
            Typeface create2 = Typeface.create(Typeface.DEFAULT, 0);
            if (create != null && !create.equals(create2)) {
                return create;
            }
        }
        return null;
    }

    public static Font d(Typeface typeface) {
        if (f10058c == null) {
            f10058c = new Paint();
        }
        f10058c.setTextSize(10.0f);
        f10058c.setTypeface(typeface);
        PositionedGlyphs shapeTextRun = TextRunShaper.shapeTextRun((CharSequence) StringUtils.SPACE, 0, 1, 0, 1, 0.0f, 0.0f, false, f10058c);
        if (shapeTextRun.glyphCount() == 0) {
            return null;
        }
        return shapeTextRun.getFont(0);
    }
}
