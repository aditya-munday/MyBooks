package w;

import A.m;
import android.content.Context;
import android.content.res.AssetManager;
import android.content.res.Resources;
import android.graphics.Typeface;
import android.graphics.fonts.FontVariationAxis;
import android.net.Uri;
import android.os.ParcelFileDescriptor;
import android.util.Log;
import java.io.IOException;
import java.lang.reflect.Array;
import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.nio.ByteBuffer;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import v.C0819b;
import v.C0820c;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* renamed from: w.g, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public class C0861g extends C0859e {

    /* renamed from: f, reason: collision with root package name */
    public final Class f10067f;

    /* renamed from: g, reason: collision with root package name */
    public final Constructor f10068g;

    /* renamed from: h, reason: collision with root package name */
    public final Method f10069h;

    /* renamed from: i, reason: collision with root package name */
    public final Method f10070i;

    /* renamed from: j, reason: collision with root package name */
    public final Method f10071j;

    /* renamed from: k, reason: collision with root package name */
    public final Method f10072k;

    /* renamed from: l, reason: collision with root package name */
    public final Method f10073l;

    public C0861g() {
        Method method;
        Constructor<?> constructor;
        Method method2;
        Method method3;
        Method method4;
        Method method5;
        Class<?> cls = null;
        try {
            Class<?> cls2 = Class.forName("android.graphics.FontFamily");
            constructor = cls2.getConstructor(null);
            method2 = v(cls2);
            Class cls3 = Integer.TYPE;
            method3 = cls2.getMethod("addFontFromBuffer", ByteBuffer.class, cls3, FontVariationAxis[].class, cls3, cls3);
            method4 = cls2.getMethod("freeze", null);
            method5 = cls2.getMethod("abortCreation", null);
            method = w(cls2);
            cls = cls2;
        } catch (ClassNotFoundException | NoSuchMethodException e) {
            Log.e("TypefaceCompatApi26Impl", "Unable to collect necessary methods for class ".concat(e.getClass().getName()), e);
            method = null;
            constructor = null;
            method2 = null;
            method3 = null;
            method4 = null;
            method5 = null;
        }
        this.f10067f = cls;
        this.f10068g = constructor;
        this.f10069h = method2;
        this.f10070i = method3;
        this.f10071j = method4;
        this.f10072k = method5;
        this.f10073l = method;
    }

    public static Method v(Class cls) {
        Class cls2 = Boolean.TYPE;
        Class cls3 = Integer.TYPE;
        return cls.getMethod("addFontFromAssetManager", AssetManager.class, String.class, cls3, cls2, cls3, cls3, cls3, FontVariationAxis[].class);
    }

    @Override // w.C0859e, s4.d
    public final Typeface b(Context context, C0819b c0819b, Resources resources, int i6) {
        Object obj;
        Method method = this.f10069h;
        if (method == null) {
            Log.w("TypefaceCompatApi26Impl", "Unable to collect necessary private methods. Fallback to legacy implementation.");
        }
        if (method != null) {
            try {
                obj = this.f10068g.newInstance(null);
            } catch (IllegalAccessException | InstantiationException | InvocationTargetException unused) {
                obj = null;
            }
            if (obj != null) {
                C0820c[] c0820cArr = c0819b.f9777a;
                int length = c0820cArr.length;
                int i7 = 0;
                while (true) {
                    if (i7 < length) {
                        C0820c c0820c = c0820cArr[i7];
                        Context context2 = context;
                        if (!s(context2, obj, c0820c.f9778a, c0820c.e, c0820c.f9779b, c0820c.f9780c ? 1 : 0, FontVariationAxis.fromFontVariationSettings(c0820c.f9781d))) {
                            try {
                                this.f10072k.invoke(obj, null);
                                break;
                            } catch (IllegalAccessException | InvocationTargetException unused2) {
                            }
                        } else {
                            i7++;
                            context = context2;
                        }
                    } else if (u(obj)) {
                        return t(obj);
                    }
                }
            }
            return null;
        }
        return super.b(context, c0819b, resources, i6);
    }

    @Override // w.C0859e, s4.d
    public final Typeface c(Context context, m[] mVarArr, int i6) {
        Object obj;
        Typeface t6;
        boolean z6;
        if (mVarArr.length >= 1) {
            Method method = this.f10069h;
            if (method == null) {
                Log.w("TypefaceCompatApi26Impl", "Unable to collect necessary private methods. Fallback to legacy implementation.");
            }
            try {
                if (method != null) {
                    HashMap hashMap = new HashMap();
                    for (m mVar : mVarArr) {
                        if (mVar.f35f == 0) {
                            Uri uri = mVar.f31a;
                            if (!hashMap.containsKey(uri)) {
                                hashMap.put(uri, t0.e.k(context, uri));
                            }
                        }
                    }
                    Map unmodifiableMap = Collections.unmodifiableMap(hashMap);
                    try {
                        obj = this.f10068g.newInstance(null);
                    } catch (IllegalAccessException | InstantiationException | InvocationTargetException unused) {
                        obj = null;
                    }
                    if (obj != null) {
                        int length = mVarArr.length;
                        int i7 = 0;
                        boolean z7 = false;
                        while (true) {
                            Method method2 = this.f10072k;
                            if (i7 < length) {
                                m mVar2 = mVarArr[i7];
                                ByteBuffer byteBuffer = (ByteBuffer) unmodifiableMap.get(mVar2.f31a);
                                if (byteBuffer != null) {
                                    try {
                                        z6 = ((Boolean) this.f10070i.invoke(obj, byteBuffer, Integer.valueOf(mVar2.f32b), null, Integer.valueOf(mVar2.f33c), Integer.valueOf(mVar2.f34d ? 1 : 0))).booleanValue();
                                    } catch (IllegalAccessException | InvocationTargetException unused2) {
                                        z6 = false;
                                    }
                                    if (!z6) {
                                        method2.invoke(obj, null);
                                        break;
                                    }
                                    z7 = true;
                                }
                                i7++;
                                z7 = z7;
                            } else if (!z7) {
                                method2.invoke(obj, null);
                            } else if (u(obj) && (t6 = t(obj)) != null) {
                                return Typeface.create(t6, i6);
                            }
                        }
                    }
                } else {
                    m g2 = g(mVarArr, i6);
                    ParcelFileDescriptor openFileDescriptor = context.getContentResolver().openFileDescriptor(g2.f31a, "r", null);
                    if (openFileDescriptor == null) {
                        if (openFileDescriptor != null) {
                            openFileDescriptor.close();
                            return null;
                        }
                    } else {
                        try {
                            Typeface build = new Typeface.Builder(openFileDescriptor.getFileDescriptor()).setWeight(g2.f33c).setItalic(g2.f34d).build();
                            openFileDescriptor.close();
                            return build;
                        } finally {
                        }
                    }
                }
            } catch (IOException | IllegalAccessException | InvocationTargetException unused3) {
            }
        }
        return null;
    }

    @Override // s4.d
    public final Typeface f(Context context, Resources resources, int i6, String str, int i7) {
        Object obj;
        Method method = this.f10069h;
        if (method == null) {
            Log.w("TypefaceCompatApi26Impl", "Unable to collect necessary private methods. Fallback to legacy implementation.");
        }
        if (method != null) {
            try {
                obj = this.f10068g.newInstance(null);
            } catch (IllegalAccessException | InstantiationException | InvocationTargetException unused) {
                obj = null;
            }
            if (obj != null) {
                if (!s(context, obj, str, 0, -1, -1, null)) {
                    try {
                        this.f10072k.invoke(obj, null);
                    } catch (IllegalAccessException | InvocationTargetException unused2) {
                    }
                } else if (u(obj)) {
                    return t(obj);
                }
            }
            return null;
        }
        return super.f(context, resources, i6, str, i7);
    }

    public final boolean s(Context context, Object obj, String str, int i6, int i7, int i8, FontVariationAxis[] fontVariationAxisArr) {
        try {
            return ((Boolean) this.f10069h.invoke(obj, context.getAssets(), str, 0, Boolean.FALSE, Integer.valueOf(i6), Integer.valueOf(i7), Integer.valueOf(i8), fontVariationAxisArr)).booleanValue();
        } catch (IllegalAccessException | InvocationTargetException unused) {
            return false;
        }
    }

    public Typeface t(Object obj) {
        try {
            Object newInstance = Array.newInstance((Class<?>) this.f10067f, 1);
            Array.set(newInstance, 0, obj);
            return (Typeface) this.f10073l.invoke(null, newInstance, -1, -1);
        } catch (IllegalAccessException | InvocationTargetException unused) {
            return null;
        }
    }

    public final boolean u(Object obj) {
        try {
            return ((Boolean) this.f10071j.invoke(obj, null)).booleanValue();
        } catch (IllegalAccessException | InvocationTargetException unused) {
            return false;
        }
    }

    public Method w(Class cls) {
        Class<?> cls2 = Array.newInstance((Class<?>) cls, 1).getClass();
        Class cls3 = Integer.TYPE;
        Method declaredMethod = Typeface.class.getDeclaredMethod("createFromFamiliesWithDefault", cls2, cls3, cls3);
        declaredMethod.setAccessible(true);
        return declaredMethod;
    }
}
