package w;

import A.m;
import android.content.ContentResolver;
import android.content.Context;
import android.content.res.Resources;
import android.graphics.Typeface;
import android.graphics.fonts.Font;
import android.graphics.fonts.FontFamily;
import android.graphics.fonts.FontStyle;
import android.net.Uri;
import android.os.ParcelFileDescriptor;
import android.text.TextUtils;
import android.util.Log;
import java.io.IOException;
import java.io.InputStream;
import java.util.List;
import java.util.Objects;
import v.C0819b;
import v.C0820c;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* renamed from: w.i, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public class C0863i extends s4.d {
    public static Font q(FontFamily fontFamily, int i6) {
        int i7;
        int i8;
        if ((i6 & 1) != 0) {
            i7 = 700;
        } else {
            i7 = 400;
        }
        if ((i6 & 2) != 0) {
            i8 = 1;
        } else {
            i8 = 0;
        }
        FontStyle fontStyle = new FontStyle(i7, i8);
        Font font = fontFamily.getFont(0);
        int t6 = t(fontStyle, font.getStyle());
        for (int i9 = 1; i9 < fontFamily.getSize(); i9++) {
            Font font2 = fontFamily.getFont(i9);
            int t7 = t(fontStyle, font2.getStyle());
            if (t7 < t6) {
                font = font2;
                t6 = t7;
            }
        }
        return font;
    }

    public static int t(FontStyle fontStyle, FontStyle fontStyle2) {
        int i6;
        int abs = Math.abs(fontStyle.getWeight() - fontStyle2.getWeight()) / 100;
        if (fontStyle.getSlant() == fontStyle2.getSlant()) {
            i6 = 0;
        } else {
            i6 = 2;
        }
        return abs + i6;
    }

    @Override // s4.d
    public final Typeface b(Context context, C0819b c0819b, Resources resources, int i6) {
        try {
            FontFamily.Builder builder = null;
            for (C0820c c0820c : c0819b.f9777a) {
                try {
                    Font build = new Font.Builder(resources, c0820c.f9782f).setWeight(c0820c.f9779b).setSlant(c0820c.f9780c ? 1 : 0).setTtcIndex(c0820c.e).setFontVariationSettings(c0820c.f9781d).build();
                    if (builder == null) {
                        builder = new FontFamily.Builder(build);
                    } else {
                        builder.addFont(build);
                    }
                } catch (IOException unused) {
                }
            }
            if (builder == null) {
                return null;
            }
            FontFamily build2 = builder.build();
            return new Typeface.CustomFallbackBuilder(build2).setStyle(q(build2, i6).getStyle()).build();
        } catch (Exception e) {
            Log.w("TypefaceCompatApi29Impl", "Font load failed", e);
            return null;
        }
    }

    @Override // s4.d
    public final Typeface c(Context context, m[] mVarArr, int i6) {
        try {
            FontFamily r6 = r(mVarArr, context.getContentResolver());
            if (r6 == null) {
                return null;
            }
            return new Typeface.CustomFallbackBuilder(r6).setStyle(q(r6, i6).getStyle()).build();
        } catch (Exception e) {
            Log.w("TypefaceCompatApi29Impl", "Font load failed", e);
            return null;
        }
    }

    @Override // s4.d
    public final Typeface d(Context context, List list, int i6) {
        ContentResolver contentResolver = context.getContentResolver();
        try {
            FontFamily r6 = r((m[]) list.get(0), contentResolver);
            if (r6 == null) {
                return null;
            }
            Typeface.CustomFallbackBuilder customFallbackBuilder = new Typeface.CustomFallbackBuilder(r6);
            for (int i7 = 1; i7 < list.size(); i7++) {
                FontFamily r7 = r((m[]) list.get(i7), contentResolver);
                if (r7 != null) {
                    customFallbackBuilder.addCustomFallback(r7);
                }
            }
            return customFallbackBuilder.setStyle(q(r6, i6).getStyle()).build();
        } catch (Exception e) {
            Log.w("TypefaceCompatApi29Impl", "Font load failed", e);
            return null;
        }
    }

    @Override // s4.d
    public final Typeface e(Context context, InputStream inputStream) {
        throw new RuntimeException("Do not use this function in API 29 or later.");
    }

    @Override // s4.d
    public final Typeface f(Context context, Resources resources, int i6, String str, int i7) {
        try {
            Font build = new Font.Builder(resources, i6).build();
            return new Typeface.CustomFallbackBuilder(new FontFamily.Builder(build).build()).setStyle(build.getStyle()).build();
        } catch (Exception e) {
            Log.w("TypefaceCompatApi29Impl", "Font load failed", e);
            return null;
        }
    }

    @Override // s4.d
    public final m g(m[] mVarArr, int i6) {
        throw new RuntimeException("Do not use this function in API 29 or later.");
    }

    public final FontFamily r(m[] mVarArr, ContentResolver contentResolver) {
        Font font;
        String str;
        ParcelFileDescriptor openFileDescriptor;
        FontFamily.Builder builder = null;
        for (m mVar : mVarArr) {
            if (Objects.equals(mVar.f31a.getScheme(), "systemfont")) {
                font = s(mVar);
            } else {
                try {
                    Uri uri = mVar.f31a;
                    str = mVar.e;
                    openFileDescriptor = contentResolver.openFileDescriptor(uri, "r", null);
                } catch (IOException e) {
                    Log.w("TypefaceCompatApi29Impl", "Font load failed", e);
                }
                if (openFileDescriptor == null) {
                    if (openFileDescriptor != null) {
                        openFileDescriptor.close();
                    }
                    font = null;
                } else {
                    try {
                        Font.Builder ttcIndex = new Font.Builder(openFileDescriptor).setWeight(mVar.f33c).setSlant(mVar.f34d ? 1 : 0).setTtcIndex(mVar.f32b);
                        if (!TextUtils.isEmpty(str)) {
                            ttcIndex.setFontVariationSettings(str);
                        }
                        font = ttcIndex.build();
                        openFileDescriptor.close();
                    } catch (Throwable th) {
                        try {
                            openFileDescriptor.close();
                        } catch (Throwable th2) {
                            th.addSuppressed(th2);
                        }
                        throw th;
                        break;
                    }
                }
            }
            if (font != null) {
                if (builder == null) {
                    builder = new FontFamily.Builder(font);
                } else {
                    builder.addFont(font);
                }
            }
        }
        if (builder == null) {
            return null;
        }
        return builder.build();
    }

    public Font s(m mVar) {
        throw new UnsupportedOperationException("Getting font from Typeface is not supported before API31");
    }
}
