package w;

import A.m;
import android.content.Context;
import android.content.res.Resources;
import android.graphics.Typeface;
import android.os.ParcelFileDescriptor;
import android.system.ErrnoException;
import android.system.Os;
import android.system.OsConstants;
import android.util.Log;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.lang.reflect.Array;
import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import v.C0819b;
import v.C0820c;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* renamed from: w.e, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public class C0859e extends s4.d {

    /* renamed from: a, reason: collision with root package name */
    public static Class f10059a = null;

    /* renamed from: b, reason: collision with root package name */
    public static Constructor f10060b = null;

    /* renamed from: c, reason: collision with root package name */
    public static Method f10061c = null;

    /* renamed from: d, reason: collision with root package name */
    public static Method f10062d = null;
    public static boolean e = false;

    public static boolean q(Object obj, String str, int i6, boolean z6) {
        r();
        try {
            return ((Boolean) f10061c.invoke(obj, str, Integer.valueOf(i6), Boolean.valueOf(z6))).booleanValue();
        } catch (IllegalAccessException | InvocationTargetException e6) {
            throw new RuntimeException(e6);
        }
    }

    public static void r() {
        Method method;
        Class<?> cls;
        Method method2;
        if (e) {
            return;
        }
        e = true;
        Constructor<?> constructor = null;
        try {
            cls = Class.forName("android.graphics.FontFamily");
            Constructor<?> constructor2 = cls.getConstructor(null);
            method2 = cls.getMethod("addFontWeightStyle", String.class, Integer.TYPE, Boolean.TYPE);
            method = Typeface.class.getMethod("createFromFamiliesWithDefault", Array.newInstance(cls, 1).getClass());
            constructor = constructor2;
        } catch (ClassNotFoundException | NoSuchMethodException e6) {
            Log.e("TypefaceCompatApi21Impl", e6.getClass().getName(), e6);
            method = null;
            cls = null;
            method2 = null;
        }
        f10060b = constructor;
        f10059a = cls;
        f10061c = method2;
        f10062d = method;
    }

    @Override // s4.d
    public Typeface b(Context context, C0819b c0819b, Resources resources, int i6) {
        r();
        try {
            Object newInstance = f10060b.newInstance(null);
            for (C0820c c0820c : c0819b.f9777a) {
                File h6 = t0.e.h(context);
                if (h6 == null) {
                    return null;
                }
                try {
                    if (!t0.e.c(h6, resources, c0820c.f9782f)) {
                        return null;
                    }
                    if (!q(newInstance, h6.getPath(), c0820c.f9779b, c0820c.f9780c)) {
                        return null;
                    }
                    h6.delete();
                } catch (RuntimeException unused) {
                    return null;
                } finally {
                    h6.delete();
                }
            }
            r();
            try {
                Object newInstance2 = Array.newInstance((Class<?>) f10059a, 1);
                Array.set(newInstance2, 0, newInstance);
                return (Typeface) f10062d.invoke(null, newInstance2);
            } catch (IllegalAccessException | InvocationTargetException e6) {
                throw new RuntimeException(e6);
            }
        } catch (IllegalAccessException | InstantiationException | InvocationTargetException e7) {
            throw new RuntimeException(e7);
        }
    }

    @Override // s4.d
    public Typeface c(Context context, m[] mVarArr, int i6) {
        File file;
        String readlink;
        if (mVarArr.length >= 1) {
            try {
                ParcelFileDescriptor openFileDescriptor = context.getContentResolver().openFileDescriptor(g(mVarArr, i6).f31a, "r", null);
                if (openFileDescriptor == null) {
                    if (openFileDescriptor != null) {
                        openFileDescriptor.close();
                        return null;
                    }
                } else {
                    try {
                        try {
                            readlink = Os.readlink("/proc/self/fd/" + openFileDescriptor.getFd());
                        } catch (Throwable th) {
                            try {
                                openFileDescriptor.close();
                            } catch (Throwable th2) {
                                th.addSuppressed(th2);
                            }
                            throw th;
                        }
                    } catch (ErrnoException unused) {
                    }
                    try {
                        if (OsConstants.S_ISREG(Os.stat(readlink).st_mode)) {
                            file = new File(readlink);
                            if (file != null && file.canRead()) {
                                Typeface createFromFile = Typeface.createFromFile(file);
                                openFileDescriptor.close();
                                return createFromFile;
                            }
                            FileInputStream fileInputStream = new FileInputStream(openFileDescriptor.getFileDescriptor());
                            Typeface e6 = e(context, fileInputStream);
                            fileInputStream.close();
                            openFileDescriptor.close();
                            return e6;
                        }
                        Typeface e62 = e(context, fileInputStream);
                        fileInputStream.close();
                        openFileDescriptor.close();
                        return e62;
                    } finally {
                    }
                    file = null;
                    if (file != null) {
                        Typeface createFromFile2 = Typeface.createFromFile(file);
                        openFileDescriptor.close();
                        return createFromFile2;
                    }
                    FileInputStream fileInputStream2 = new FileInputStream(openFileDescriptor.getFileDescriptor());
                }
            } catch (IOException unused2) {
            }
        }
        return null;
    }
}
