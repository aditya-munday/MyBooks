package w;

import android.graphics.Color;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* renamed from: w.a, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public abstract class AbstractC0855a {

    /* renamed from: a, reason: collision with root package name */
    public static final /* synthetic */ int f10051a = 0;

    static {
        new ThreadLocal();
    }

    public static int a(int i6, int i7) {
        int alpha = Color.alpha(i7);
        int alpha2 = Color.alpha(i6);
        int i8 = 255 - (((255 - alpha2) * (255 - alpha)) / 255);
        return Color.argb(i8, b(Color.red(i6), alpha2, Color.red(i7), alpha, i8), b(Color.green(i6), alpha2, Color.green(i7), alpha, i8), b(Color.blue(i6), alpha2, Color.blue(i7), alpha, i8));
    }

    public static int b(int i6, int i7, int i8, int i9, int i10) {
        if (i10 == 0) {
            return 0;
        }
        return (((255 - i7) * (i8 * i9)) + ((i6 * 255) * i7)) / (i10 * 255);
    }
}
