package w;

import android.graphics.Typeface;
import java.lang.reflect.Array;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* renamed from: w.h, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0862h extends C0861g {
    @Override // w.C0861g
    public final Typeface t(Object obj) {
        try {
            Object newInstance = Array.newInstance((Class<?>) this.f10067f, 1);
            Array.set(newInstance, 0, obj);
            return (Typeface) this.f10073l.invoke(null, newInstance, "sans-serif", -1, -1);
        } catch (IllegalAccessException | InvocationTargetException e) {
            throw new RuntimeException(e);
        }
    }

    @Override // w.C0861g
    public final Method w(Class cls) {
        Class<?> cls2 = Array.newInstance((Class<?>) cls, 1).getClass();
        Class cls3 = Integer.TYPE;
        Method declaredMethod = Typeface.class.getDeclaredMethod("createFromFamiliesWithDefault", cls2, String.class, cls3, cls3);
        declaredMethod.setAccessible(true);
        return declaredMethod;
    }
}
