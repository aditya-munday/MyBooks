package w;

import A.m;
import android.content.Context;
import android.content.res.Resources;
import android.graphics.Typeface;
import android.net.Uri;
import android.util.Log;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.lang.reflect.Array;
import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.nio.ByteBuffer;
import java.nio.MappedByteBuffer;
import java.nio.channels.FileChannel;
import java.util.List;
import v.C0819b;
import v.C0820c;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* renamed from: w.f, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0860f extends s4.d {

    /* renamed from: a, reason: collision with root package name */
    public static final Class f10063a;

    /* renamed from: b, reason: collision with root package name */
    public static final Constructor f10064b;

    /* renamed from: c, reason: collision with root package name */
    public static final Method f10065c;

    /* renamed from: d, reason: collision with root package name */
    public static final Method f10066d;

    static {
        Class<?> cls;
        Method method;
        Method method2;
        Constructor<?> constructor = null;
        try {
            cls = Class.forName("android.graphics.FontFamily");
            Constructor<?> constructor2 = cls.getConstructor(null);
            Class cls2 = Integer.TYPE;
            method2 = cls.getMethod("addFontWeightStyle", ByteBuffer.class, cls2, List.class, cls2, Boolean.TYPE);
            method = Typeface.class.getMethod("createFromFamiliesWithDefault", Array.newInstance(cls, 1).getClass());
            constructor = constructor2;
        } catch (ClassNotFoundException | NoSuchMethodException e) {
            Log.e("TypefaceCompatApi24Impl", e.getClass().getName(), e);
            cls = null;
            method = null;
            method2 = null;
        }
        f10064b = constructor;
        f10063a = cls;
        f10065c = method2;
        f10066d = method;
    }

    public static boolean q(Object obj, ByteBuffer byteBuffer, int i6, int i7, boolean z6) {
        try {
            return ((Boolean) f10065c.invoke(obj, byteBuffer, Integer.valueOf(i6), null, Integer.valueOf(i7), Boolean.valueOf(z6))).booleanValue();
        } catch (IllegalAccessException | InvocationTargetException unused) {
            return false;
        }
    }

    public static Typeface r(Object obj) {
        try {
            Object newInstance = Array.newInstance((Class<?>) f10063a, 1);
            Array.set(newInstance, 0, obj);
            return (Typeface) f10066d.invoke(null, newInstance);
        } catch (IllegalAccessException | InvocationTargetException unused) {
            return null;
        }
    }

    @Override // s4.d
    public final Typeface b(Context context, C0819b c0819b, Resources resources, int i6) {
        Object obj;
        MappedByteBuffer mappedByteBuffer;
        FileInputStream fileInputStream;
        try {
            obj = f10064b.newInstance(null);
        } catch (IllegalAccessException | InstantiationException | InvocationTargetException unused) {
            obj = null;
        }
        if (obj != null) {
            for (C0820c c0820c : c0819b.f9777a) {
                int i7 = c0820c.f9782f;
                File h6 = t0.e.h(context);
                if (h6 != null) {
                    try {
                        if (t0.e.c(h6, resources, i7)) {
                            try {
                                fileInputStream = new FileInputStream(h6);
                            } catch (IOException unused2) {
                                mappedByteBuffer = null;
                            }
                            try {
                                FileChannel channel = fileInputStream.getChannel();
                                mappedByteBuffer = channel.map(FileChannel.MapMode.READ_ONLY, 0L, channel.size());
                                fileInputStream.close();
                                if (mappedByteBuffer != null && q(obj, mappedByteBuffer, c0820c.e, c0820c.f9779b, c0820c.f9780c)) {
                                }
                            } finally {
                                break;
                            }
                        }
                    } finally {
                        h6.delete();
                    }
                }
                mappedByteBuffer = null;
                if (mappedByteBuffer != null) {
                }
            }
            return r(obj);
        }
        return null;
    }

    @Override // s4.d
    public final Typeface c(Context context, m[] mVarArr, int i6) {
        Object obj;
        try {
            obj = f10064b.newInstance(null);
        } catch (IllegalAccessException | InstantiationException | InvocationTargetException unused) {
            obj = null;
        }
        if (obj != null) {
            int i7 = 0;
            p.j jVar = new p.j(0);
            int length = mVarArr.length;
            while (true) {
                if (i7 < length) {
                    m mVar = mVarArr[i7];
                    Uri uri = mVar.f31a;
                    ByteBuffer byteBuffer = (ByteBuffer) jVar.get(uri);
                    if (byteBuffer == null) {
                        byteBuffer = t0.e.k(context, uri);
                        jVar.put(uri, byteBuffer);
                    }
                    if (byteBuffer == null || !q(obj, byteBuffer, mVar.f32b, mVar.f33c, mVar.f34d)) {
                        break;
                    }
                    i7++;
                } else {
                    Typeface r6 = r(obj);
                    if (r6 != null) {
                        return Typeface.create(r6, i6);
                    }
                }
            }
        }
        return null;
    }
}
