package w;

import android.graphics.Insets;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* renamed from: w.b, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0856b {
    public static final C0856b e = new C0856b(0, 0, 0, 0);

    /* renamed from: a, reason: collision with root package name */
    public final int f10052a;

    /* renamed from: b, reason: collision with root package name */
    public final int f10053b;

    /* renamed from: c, reason: collision with root package name */
    public final int f10054c;

    /* renamed from: d, reason: collision with root package name */
    public final int f10055d;

    public C0856b(int i6, int i7, int i8, int i9) {
        this.f10052a = i6;
        this.f10053b = i7;
        this.f10054c = i8;
        this.f10055d = i9;
    }

    public static C0856b a(int i6, int i7, int i8, int i9) {
        if (i6 == 0 && i7 == 0 && i8 == 0 && i9 == 0) {
            return e;
        }
        return new C0856b(i6, i7, i8, i9);
    }

    public static C0856b b(Insets insets) {
        int i6;
        int i7;
        int i8;
        int i9;
        i6 = insets.left;
        i7 = insets.top;
        i8 = insets.right;
        i9 = insets.bottom;
        return a(i6, i7, i8, i9);
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null || C0856b.class != obj.getClass()) {
            return false;
        }
        C0856b c0856b = (C0856b) obj;
        if (this.f10055d == c0856b.f10055d && this.f10052a == c0856b.f10052a && this.f10054c == c0856b.f10054c && this.f10053b == c0856b.f10053b) {
            return true;
        }
        return false;
    }

    public final int hashCode() {
        return (((((this.f10052a * 31) + this.f10053b) * 31) + this.f10054c) * 31) + this.f10055d;
    }

    public final String toString() {
        return "Insets{left=" + this.f10052a + ", top=" + this.f10053b + ", right=" + this.f10054c + ", bottom=" + this.f10055d + '}';
    }
}
