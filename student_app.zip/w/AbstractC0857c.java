package w;

import android.graphics.fonts.Font;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* renamed from: w.c, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public abstract /* synthetic */ class AbstractC0857c {
    public static /* synthetic */ Font.Builder a(Font font) {
        return new Font.Builder(font);
    }
}
