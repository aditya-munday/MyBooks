package S5;

import T5.e;
import java.io.Serializable;
import java.util.Queue;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* loaded from: classes.dex */
public final class a implements R5.b, Serializable {
    public String o;

    /* renamed from: p, reason: collision with root package name */
    public e f2718p;

    /* renamed from: q, reason: collision with root package name */
    public Queue f2719q;

    @Override // R5.b
    public final void A(String str, Object obj, Serializable serializable) {
        B(3, str, obj, serializable);
    }

    public final void B(int i6, String str, Object obj, Object obj2) {
        if (obj2 instanceof Throwable) {
            D(i6, new Object[]{obj});
        } else {
            D(i6, new Object[]{obj, obj2});
        }
    }

    /* JADX WARN: Removed duplicated region for block: B:17:0x002d  */
    /* JADX WARN: Removed duplicated region for block: B:7:0x0013  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final void C(int i6, String str, Object[] objArr) {
        Throwable th;
        if (objArr.length != 0) {
            Object obj = objArr[objArr.length - 1];
            if (obj instanceof Throwable) {
                th = (Throwable) obj;
                if (th == null) {
                    if (objArr.length != 0) {
                        int length = objArr.length - 1;
                        Object[] objArr2 = new Object[length];
                        if (length > 0) {
                            System.arraycopy(objArr, 0, objArr2, 0, length);
                        }
                        D(i6, objArr2);
                        return;
                    }
                    throw new IllegalStateException("non-sensical empty or null argument array");
                }
                D(i6, objArr);
                return;
            }
        }
        th = null;
        if (th == null) {
        }
    }

    /* JADX WARN: Type inference failed for: r0v0, types: [S5.b, java.lang.Object] */
    public final void D(int i6, Object[] objArr) {
        ?? obj = new Object();
        System.currentTimeMillis();
        obj.f2720a = i6;
        obj.f2721b = this.f2718p;
        Thread.currentThread().getName();
        obj.f2722c = objArr;
        this.f2719q.add(obj);
    }

    @Override // R5.b
    public final void a(Object obj, String str) {
        D(1, new Object[]{obj});
    }

    @Override // R5.b
    public final void b(String str, Object... objArr) {
        C(4, str, objArr);
    }

    @Override // R5.b
    public final boolean c() {
        return true;
    }

    @Override // R5.b
    public final boolean d() {
        return true;
    }

    @Override // R5.b
    public final void e(Object... objArr) {
        C(1, "pipesClientId={} didn't receive ready byte from server within StartupTimeoutMillis {}; ms elapsed {}; did read >{}<", objArr);
    }

    @Override // R5.b
    public final void f(Integer num, String str) {
        D(2, new Object[]{num});
    }

    @Override // R5.b
    public final void g(String str, Throwable th) {
        D(2, null);
    }

    @Override // R5.b
    public final String getName() {
        return this.o;
    }

    @Override // R5.b
    public final void h(Object obj, Object obj2) {
        B(1, "Error assigning value '{}' to '{}'", obj, obj2);
    }

    @Override // R5.b
    public final void j(String str, Throwable th) {
        D(4, null);
    }

    @Override // R5.b
    public final void k(String str, Throwable th) {
        D(1, null);
    }

    @Override // R5.b
    public final void l(String str) {
        D(3, null);
    }

    @Override // R5.b
    public final void m(Object obj, String str) {
        D(5, new Object[]{obj});
    }

    @Override // R5.b
    public final void n(String str) {
        D(2, null);
    }

    @Override // R5.b
    public final void o(String str) {
        D(5, null);
    }

    @Override // R5.b
    public final boolean p() {
        return true;
    }

    @Override // R5.b
    public final void r(String str, Object... objArr) {
        C(2, str, objArr);
    }

    @Override // R5.b
    public final void s(Object obj, Object obj2, String str) {
        B(2, str, obj, obj2);
    }

    @Override // R5.b
    public final void t(Object obj, String str) {
        D(4, new Object[]{obj});
    }

    @Override // R5.b
    public final boolean u() {
        return true;
    }

    @Override // R5.b
    public final void v(String str) {
        D(4, null);
    }

    @Override // R5.b
    public final boolean w() {
        return true;
    }

    @Override // R5.b
    public final void x(Object obj, Object obj2, String str) {
        B(4, str, obj, obj2);
    }

    @Override // R5.b
    public final void y(String str, Object obj, Serializable serializable) {
        B(5, str, obj, serializable);
    }

    @Override // R5.b
    public final void z(Integer num, String str) {
        D(3, new Object[]{num});
    }
}
