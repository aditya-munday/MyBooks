package S5;

import T5.e;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* loaded from: classes.dex */
public final class b {

    /* renamed from: a, reason: collision with root package name */
    public int f2720a;

    /* renamed from: b, reason: collision with root package name */
    public e f2721b;

    /* renamed from: c, reason: collision with root package name */
    public Object[] f2722c;
}
