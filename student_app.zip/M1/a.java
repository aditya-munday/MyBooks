package M1;

import K1.g;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.util.Log;
import com.shockwave.pdfium.PdfDocument;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* loaded from: classes.dex */
public final class a implements b {

    /* renamed from: a, reason: collision with root package name */
    public g f1720a;

    @Override // M1.b
    public final void a(O1.a aVar) {
        g gVar = this.f1720a;
        PdfDocument.Link link = aVar.f1856a;
        String str = link.f5829c;
        Integer num = link.f5828b;
        if (str != null && !str.isEmpty()) {
            Intent intent = new Intent("android.intent.action.VIEW", Uri.parse(str));
            Context context = gVar.getContext();
            if (intent.resolveActivity(context.getPackageManager()) != null) {
                context.startActivity(intent);
                return;
            } else {
                Log.w("a", "No activity found for URI: ".concat(str));
                return;
            }
        }
        if (num != null) {
            gVar.k(num.intValue());
        }
    }
}
