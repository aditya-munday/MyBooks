package e2;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* renamed from: e2.a, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public interface InterfaceC0418a {
    long h();
}
