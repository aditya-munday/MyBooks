package k3;

import i3.InterfaceC0477a;
import j3.C0516a;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* loaded from: classes.dex */
public abstract class g implements InterfaceC0477a {

    /* renamed from: a, reason: collision with root package name */
    public static final C0516a f7994a = new C0516a(2);
}
