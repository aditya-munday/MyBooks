package k3;

import C4.AbstractC0034i;
import h3.C0464c;
import j3.C0516a;
import java.io.ByteArrayOutputStream;
import java.io.OutputStream;
import java.lang.annotation.Annotation;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.charset.Charset;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import org.apache.tika.mime.MimeTypesReaderMetKeys;
import org.apache.tika.parser.external.ExternalParsersConfigReaderMetKeys;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* loaded from: classes.dex */
public final class f implements h3.e {

    /* renamed from: f, reason: collision with root package name */
    public static final Charset f7986f = Charset.forName("UTF-8");

    /* renamed from: g, reason: collision with root package name */
    public static final C0464c f7987g = new C0464c(ExternalParsersConfigReaderMetKeys.METADATA_KEY_ATTR, AbstractC0034i.o(AbstractC0034i.n(e.class, new C0559a(1))));

    /* renamed from: h, reason: collision with root package name */
    public static final C0464c f7988h = new C0464c(MimeTypesReaderMetKeys.MATCH_VALUE_ATTR, AbstractC0034i.o(AbstractC0034i.n(e.class, new C0559a(2))));

    /* renamed from: i, reason: collision with root package name */
    public static final C0516a f7989i = new C0516a(1);

    /* renamed from: a, reason: collision with root package name */
    public OutputStream f7990a;

    /* renamed from: b, reason: collision with root package name */
    public final HashMap f7991b;

    /* renamed from: c, reason: collision with root package name */
    public final HashMap f7992c;

    /* renamed from: d, reason: collision with root package name */
    public final h3.d f7993d;
    public final h e = new h(this);

    public f(ByteArrayOutputStream byteArrayOutputStream, HashMap hashMap, HashMap hashMap2, h3.d dVar) {
        this.f7990a = byteArrayOutputStream;
        this.f7991b = hashMap;
        this.f7992c = hashMap2;
        this.f7993d = dVar;
    }

    public static int g(C0464c c0464c) {
        e eVar = (e) ((Annotation) c0464c.f6843b.get(e.class));
        if (eVar != null) {
            return ((C0559a) eVar).f7984a;
        }
        throw new RuntimeException("Field has no @Protobuf config");
    }

    @Override // h3.e
    public final h3.e a(C0464c c0464c, Object obj) {
        c(c0464c, obj, true);
        return this;
    }

    public final void b(C0464c c0464c, int i6, boolean z6) {
        if (z6 && i6 == 0) {
            return;
        }
        e eVar = (e) ((Annotation) c0464c.f6843b.get(e.class));
        if (eVar != null) {
            h(((C0559a) eVar).f7984a << 3);
            h(i6);
            return;
        }
        throw new RuntimeException("Field has no @Protobuf config");
    }

    public final void c(C0464c c0464c, Object obj, boolean z6) {
        if (obj != null) {
            if (obj instanceof CharSequence) {
                CharSequence charSequence = (CharSequence) obj;
                if (!z6 || charSequence.length() != 0) {
                    h((g(c0464c) << 3) | 2);
                    byte[] bytes = charSequence.toString().getBytes(f7986f);
                    h(bytes.length);
                    this.f7990a.write(bytes);
                    return;
                }
                return;
            }
            if (obj instanceof Collection) {
                Iterator it = ((Collection) obj).iterator();
                while (it.hasNext()) {
                    c(c0464c, it.next(), false);
                }
                return;
            }
            if (obj instanceof Map) {
                Iterator it2 = ((Map) obj).entrySet().iterator();
                while (it2.hasNext()) {
                    f(f7989i, c0464c, (Map.Entry) it2.next(), false);
                }
                return;
            }
            if (obj instanceof Double) {
                double doubleValue = ((Double) obj).doubleValue();
                if (!z6 || doubleValue != 0.0d) {
                    h((g(c0464c) << 3) | 1);
                    this.f7990a.write(ByteBuffer.allocate(8).order(ByteOrder.LITTLE_ENDIAN).putDouble(doubleValue).array());
                    return;
                }
                return;
            }
            if (obj instanceof Float) {
                float floatValue = ((Float) obj).floatValue();
                if (!z6 || floatValue != 0.0f) {
                    h((g(c0464c) << 3) | 5);
                    this.f7990a.write(ByteBuffer.allocate(4).order(ByteOrder.LITTLE_ENDIAN).putFloat(floatValue).array());
                    return;
                }
                return;
            }
            if (obj instanceof Number) {
                long longValue = ((Number) obj).longValue();
                if (!z6 || longValue != 0) {
                    e eVar = (e) ((Annotation) c0464c.f6843b.get(e.class));
                    if (eVar != null) {
                        h(((C0559a) eVar).f7984a << 3);
                        i(longValue);
                        return;
                    }
                    throw new RuntimeException("Field has no @Protobuf config");
                }
                return;
            }
            if (obj instanceof Boolean) {
                b(c0464c, ((Boolean) obj).booleanValue() ? 1 : 0, z6);
                return;
            }
            if (obj instanceof byte[]) {
                byte[] bArr = (byte[]) obj;
                if (z6 && bArr.length == 0) {
                    return;
                }
                h((g(c0464c) << 3) | 2);
                h(bArr.length);
                this.f7990a.write(bArr);
                return;
            }
            h3.d dVar = (h3.d) this.f7991b.get(obj.getClass());
            if (dVar != null) {
                f(dVar, c0464c, obj, z6);
                return;
            }
            h3.f fVar = (h3.f) this.f7992c.get(obj.getClass());
            if (fVar != null) {
                h hVar = this.e;
                hVar.f7995a = false;
                hVar.f7997c = c0464c;
                hVar.f7996b = z6;
                fVar.a(obj, hVar);
                return;
            }
            if (obj instanceof c) {
                b(c0464c, ((c) obj).a(), true);
            } else if (obj instanceof Enum) {
                b(c0464c, ((Enum) obj).ordinal(), true);
            } else {
                f(this.f7993d, c0464c, obj, z6);
            }
        }
    }

    @Override // h3.e
    public final h3.e d(C0464c c0464c, long j6) {
        if (j6 == 0) {
            return this;
        }
        e eVar = (e) ((Annotation) c0464c.f6843b.get(e.class));
        if (eVar != null) {
            h(((C0559a) eVar).f7984a << 3);
            i(j6);
            return this;
        }
        throw new RuntimeException("Field has no @Protobuf config");
    }

    @Override // h3.e
    public final h3.e e(C0464c c0464c, int i6) {
        b(c0464c, i6, true);
        return this;
    }

    /* JADX WARN: Type inference failed for: r0v0, types: [java.io.OutputStream, k3.b] */
    public final void f(h3.d dVar, C0464c c0464c, Object obj, boolean z6) {
        ?? outputStream = new OutputStream();
        outputStream.o = 0L;
        try {
            OutputStream outputStream2 = this.f7990a;
            this.f7990a = outputStream;
            try {
                dVar.a(obj, this);
                this.f7990a = outputStream2;
                long j6 = outputStream.o;
                outputStream.close();
                if (z6 && j6 == 0) {
                    return;
                }
                h((g(c0464c) << 3) | 2);
                i(j6);
                dVar.a(obj, this);
            } catch (Throwable th) {
                this.f7990a = outputStream2;
                throw th;
            }
        } catch (Throwable th2) {
            try {
                outputStream.close();
            } catch (Throwable th3) {
                th2.addSuppressed(th3);
            }
            throw th2;
        }
    }

    public final void h(int i6) {
        while ((i6 & (-128)) != 0) {
            this.f7990a.write((i6 & 127) | 128);
            i6 >>>= 7;
        }
        this.f7990a.write(i6 & 127);
    }

    public final void i(long j6) {
        while (((-128) & j6) != 0) {
            this.f7990a.write((((int) j6) & 127) | 128);
            j6 >>>= 7;
        }
        this.f7990a.write(((int) j6) & 127);
    }
}
