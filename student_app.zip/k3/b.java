package k3;

import java.io.OutputStream;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* loaded from: classes.dex */
public final class b extends OutputStream {
    public long o;

    @Override // java.io.OutputStream
    public final void write(int i6) {
        this.o++;
    }

    @Override // java.io.OutputStream
    public final void write(byte[] bArr) {
        this.o += bArr.length;
    }

    @Override // java.io.OutputStream
    public final void write(byte[] bArr, int i6, int i7) {
        int i8;
        if (i6 >= 0 && i6 <= bArr.length && i7 >= 0 && (i8 = i6 + i7) <= bArr.length && i8 >= 0) {
            this.o += i7;
            return;
        }
        throw new IndexOutOfBoundsException();
    }
}
