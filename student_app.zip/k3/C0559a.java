package k3;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* renamed from: k3.a, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0559a implements e {

    /* renamed from: a, reason: collision with root package name */
    public final int f7984a;

    public C0559a(int i6) {
        this.f7984a = i6;
    }

    @Override // java.lang.annotation.Annotation
    public final Class annotationType() {
        return e.class;
    }

    @Override // java.lang.annotation.Annotation
    public final boolean equals(Object obj) {
        if (this != obj) {
            if (obj instanceof e) {
                if (this.f7984a == ((C0559a) ((e) obj)).f7984a) {
                    Object obj2 = d.o;
                    if (obj2.equals(obj2)) {
                        return true;
                    }
                    return false;
                }
                return false;
            }
            return false;
        }
        return true;
    }

    @Override // java.lang.annotation.Annotation
    public final int hashCode() {
        return (14552422 ^ this.f7984a) + (d.o.hashCode() ^ 2041407134);
    }

    @Override // java.lang.annotation.Annotation
    public final String toString() {
        return "@com.google.firebase.encoders.proto.Protobuf(tag=" + this.f7984a + "intEncoding=" + d.o + ')';
    }
}
