package k3;

/* JADX WARN: Method from annotation default annotation not found: intEncoding */
/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* loaded from: classes.dex */
public @interface e {
}
