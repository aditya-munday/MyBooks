package k3;

/* JADX WARN: Failed to restore enum class, 'enum' modifier and super class removed */
/* JADX WARN: Unknown enum class pattern. Please report as an issue! */
/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* loaded from: classes.dex */
public final class d {
    public static final d o;

    /* renamed from: p, reason: collision with root package name */
    public static final /* synthetic */ d[] f7985p;

    /* JADX WARN: Type inference failed for: r0v0, types: [java.lang.Enum, k3.d] */
    /* JADX WARN: Type inference failed for: r1v1, types: [java.lang.Enum, k3.d] */
    /* JADX WARN: Type inference failed for: r2v2, types: [java.lang.Enum, k3.d] */
    static {
        ?? r02 = new Enum("DEFAULT", 0);
        o = r02;
        f7985p = new d[]{r02, new Enum("SIGNED", 1), new Enum("FIXED", 2)};
    }

    public static d valueOf(String str) {
        return (d) Enum.valueOf(d.class, str);
    }

    public static d[] values() {
        return (d[]) f7985p.clone();
    }
}
