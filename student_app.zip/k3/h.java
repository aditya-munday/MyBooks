package k3;

import h3.C0464c;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* loaded from: classes.dex */
public final class h implements h3.g {

    /* renamed from: a, reason: collision with root package name */
    public boolean f7995a = false;

    /* renamed from: b, reason: collision with root package name */
    public boolean f7996b = false;

    /* renamed from: c, reason: collision with root package name */
    public C0464c f7997c;

    /* renamed from: d, reason: collision with root package name */
    public final f f7998d;

    public h(f fVar) {
        this.f7998d = fVar;
    }

    @Override // h3.g
    public final h3.g b(String str) {
        if (!this.f7995a) {
            this.f7995a = true;
            this.f7998d.c(this.f7997c, str, this.f7996b);
            return this;
        }
        throw new RuntimeException("Cannot encode a second value in the ValueEncoderContext");
    }

    @Override // h3.g
    public final h3.g c(boolean z6) {
        if (!this.f7995a) {
            this.f7995a = true;
            this.f7998d.b(this.f7997c, z6 ? 1 : 0, this.f7996b);
            return this;
        }
        throw new RuntimeException("Cannot encode a second value in the ValueEncoderContext");
    }
}
