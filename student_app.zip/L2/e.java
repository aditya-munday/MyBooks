package L2;

import a.AbstractC0194a;
import androidx.datastore.preferences.protobuf.C0219g;
import com.google.crypto.tink.shaded.protobuf.B;
import com.google.crypto.tink.shaded.protobuf.C0369g;
import com.google.crypto.tink.shaded.protobuf.C0371i;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.security.GeneralSecurityException;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* loaded from: classes.dex */
public abstract class e {

    /* renamed from: a, reason: collision with root package name */
    public int f1585a;

    /* renamed from: b, reason: collision with root package name */
    public Object f1586b;

    public static int d(int i6) {
        return (-(i6 & 1)) ^ (i6 >>> 1);
    }

    public static long e(long j6) {
        return (-(j6 & 1)) ^ (j6 >>> 1);
    }

    public static C0371i h(byte[] bArr, int i6, int i7, boolean z6) {
        C0371i c0371i = new C0371i(bArr, i6, i7, z6);
        try {
            c0371i.l(i7);
            return c0371i;
        } catch (B e) {
            throw new IllegalArgumentException(e);
        }
    }

    public abstract String A();

    public abstract String B();

    public abstract int C();

    public abstract int D();

    public abstract long E();

    public abstract boolean F(int i6);

    public void G() {
        int C6;
        do {
            C6 = C();
            if (C6 != 0) {
                int i6 = this.f1585a;
                if (i6 < 100) {
                    this.f1585a = i6 + 1;
                    this.f1585a--;
                } else {
                    throw new IOException("Protocol message had too many levels of nesting.  May be malicious.  Use setRecursionLimit() to increase the recursion depth limit.");
                }
            } else {
                return;
            }
        } while (F(C6));
    }

    public ByteBuffer a(byte[] bArr, int i6) {
        int[] c6 = c(a.c(bArr), i6);
        int[] iArr = (int[]) c6.clone();
        a.b(iArr);
        for (int i7 = 0; i7 < c6.length; i7++) {
            c6[i7] = c6[i7] + iArr[i7];
        }
        ByteBuffer order = ByteBuffer.allocate(64).order(ByteOrder.LITTLE_ENDIAN);
        order.asIntBuffer().put(c6, 0, 16);
        return order;
    }

    public abstract void b(int i6);

    public abstract int[] c(int[] iArr, int i6);

    public abstract int f();

    public abstract boolean g();

    public abstract int i();

    public abstract void j(int i6);

    public void k(byte[] bArr, ByteBuffer byteBuffer, ByteBuffer byteBuffer2) {
        if (bArr.length == i()) {
            int remaining = byteBuffer2.remaining();
            int i6 = remaining / 64;
            int i7 = i6 + 1;
            for (int i8 = 0; i8 < i7; i8++) {
                ByteBuffer a6 = a(bArr, this.f1585a + i8);
                if (i8 == i6) {
                    AbstractC0194a.o0(byteBuffer, byteBuffer2, a6, remaining % 64);
                } else {
                    AbstractC0194a.o0(byteBuffer, byteBuffer2, a6, 64);
                }
            }
            return;
        }
        throw new GeneralSecurityException("The nonce length (in bytes) must be " + i());
    }

    public abstract int l(int i6);

    public abstract boolean m();

    public abstract C0219g n();

    public abstract C0369g o();

    public abstract double p();

    public abstract int q();

    public abstract int r();

    public abstract long s();

    public abstract float t();

    public abstract int u();

    public abstract long v();

    public abstract int w();

    public abstract long x();

    public abstract int y();

    public abstract long z();
}
