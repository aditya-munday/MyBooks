package L2;

import W2.j;
import java.security.GeneralSecurityException;
import java.security.SecureRandom;
import javax.crypto.Cipher;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* loaded from: classes.dex */
public final class b extends ThreadLocal {

    /* renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f1580a;

    @Override // java.lang.ThreadLocal
    public final Object initialValue() {
        switch (this.f1580a) {
            case 0:
                try {
                    return (Cipher) j.f3505b.f3507a.a("AES/GCM/NoPadding");
                } catch (GeneralSecurityException e) {
                    throw new IllegalStateException(e);
                }
            case 1:
                try {
                    return (Cipher) j.f3505b.f3507a.a("AES/GCM-SIV/NoPadding");
                } catch (GeneralSecurityException e6) {
                    throw new IllegalStateException(e6);
                }
            case 2:
                try {
                    return (Cipher) j.f3505b.f3507a.a("AES/CTR/NoPadding");
                } catch (GeneralSecurityException e7) {
                    throw new IllegalStateException(e7);
                }
            case 3:
                try {
                    return (Cipher) j.f3505b.f3507a.a("AES/ECB/NOPADDING");
                } catch (GeneralSecurityException e8) {
                    throw new IllegalStateException(e8);
                }
            case 4:
                try {
                    return (Cipher) j.f3505b.f3507a.a("AES/CTR/NOPADDING");
                } catch (GeneralSecurityException e9) {
                    throw new IllegalStateException(e9);
                }
            default:
                SecureRandom secureRandom = new SecureRandom();
                secureRandom.nextLong();
                return secureRandom;
        }
    }
}
