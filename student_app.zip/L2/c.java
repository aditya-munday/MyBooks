package L2;

import C4.AbstractC0034i;
import Q2.s;
import W2.p;
import android.os.Build;
import java.security.GeneralSecurityException;
import java.security.spec.AlgorithmParameterSpec;
import java.util.Objects;
import javax.crypto.spec.GCMParameterSpec;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* loaded from: classes.dex */
public final class c {

    /* renamed from: c, reason: collision with root package name */
    public static final b f1581c = new b(0);

    /* renamed from: a, reason: collision with root package name */
    public final SecretKeySpec f1582a;

    /* renamed from: b, reason: collision with root package name */
    public final boolean f1583b;

    public c(byte[] bArr) {
        if (AbstractC0034i.f(2)) {
            p.a(bArr.length);
            this.f1582a = new SecretKeySpec(bArr, "AES");
            this.f1583b = true;
            return;
        }
        throw new GeneralSecurityException("Can not use AES-GCM in FIPS-mode, as BoringCrypto module is not available.");
    }

    public static AlgorithmParameterSpec a(byte[] bArr) {
        Integer valueOf;
        int length = bArr.length;
        int i6 = s.f2121a;
        if (!Objects.equals(System.getProperty("java.vendor"), "The Android Project")) {
            valueOf = null;
        } else {
            valueOf = Integer.valueOf(Build.VERSION.SDK_INT);
        }
        if (valueOf != null && valueOf.intValue() <= 19) {
            return new IvParameterSpec(bArr, 0, length);
        }
        return new GCMParameterSpec(128, bArr, 0, length);
    }
}
