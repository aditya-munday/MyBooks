package L2;

import C4.AbstractC0034i;
import java.security.GeneralSecurityException;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* loaded from: classes.dex */
public final class f extends g {

    /* renamed from: c, reason: collision with root package name */
    public final /* synthetic */ int f1587c;

    public f(byte[] bArr, int i6) {
        this.f1587c = i6;
        if (AbstractC0034i.e(1)) {
            this.f1588a = d(bArr, 1);
            this.f1589b = d(bArr, 0);
            return;
        }
        throw new GeneralSecurityException("Can not use ChaCha20Poly1305 in FIPS-mode.");
    }

    @Override // L2.g
    public final e d(byte[] bArr, int i6) {
        switch (this.f1587c) {
            case 0:
                return new d(bArr, i6, 0);
            default:
                return new d(bArr, i6, 1);
        }
    }
}
