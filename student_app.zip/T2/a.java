package T2;

import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* loaded from: classes.dex */
public final class a {

    /* renamed from: b, reason: collision with root package name */
    public static final a f2799b = new a(Collections.unmodifiableMap(new HashMap()));

    /* renamed from: a, reason: collision with root package name */
    public final Map f2800a;

    public a(Map map) {
        this.f2800a = map;
    }

    public final boolean equals(Object obj) {
        if (!(obj instanceof a)) {
            return false;
        }
        return this.f2800a.equals(((a) obj).f2800a);
    }

    public final int hashCode() {
        return this.f2800a.hashCode();
    }

    public final String toString() {
        return this.f2800a.toString();
    }
}
