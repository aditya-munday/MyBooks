package T2;

import J2.f;
import java.util.Objects;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* loaded from: classes.dex */
public final class b {

    /* renamed from: a, reason: collision with root package name */
    public final f f2801a;

    /* renamed from: b, reason: collision with root package name */
    public final int f2802b;

    /* renamed from: c, reason: collision with root package name */
    public final String f2803c;

    /* renamed from: d, reason: collision with root package name */
    public final String f2804d;

    public b(f fVar, int i6, String str, String str2) {
        this.f2801a = fVar;
        this.f2802b = i6;
        this.f2803c = str;
        this.f2804d = str2;
    }

    public final boolean equals(Object obj) {
        if (!(obj instanceof b)) {
            return false;
        }
        b bVar = (b) obj;
        if (this.f2801a != bVar.f2801a || this.f2802b != bVar.f2802b || !this.f2803c.equals(bVar.f2803c) || !this.f2804d.equals(bVar.f2804d)) {
            return false;
        }
        return true;
    }

    public final int hashCode() {
        return Objects.hash(this.f2801a, Integer.valueOf(this.f2802b), this.f2803c, this.f2804d);
    }

    public final String toString() {
        return "(status=" + this.f2801a + ", keyId=" + this.f2802b + ", keyType='" + this.f2803c + "', keyPrefix='" + this.f2804d + "')";
    }
}
