package L4;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* loaded from: classes.dex */
public final class o {

    /* renamed from: a, reason: collision with root package name */
    public final int f1684a;

    /* renamed from: b, reason: collision with root package name */
    public final boolean f1685b;

    /* renamed from: c, reason: collision with root package name */
    public final boolean f1686c;

    public o(int i6, boolean z6, boolean z7) {
        this.f1684a = i6;
        this.f1685b = z6;
        this.f1686c = z7;
    }
}
