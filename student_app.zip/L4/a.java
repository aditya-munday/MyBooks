package L4;

import M4.w;
import android.window.BackEvent;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* loaded from: classes.dex */
public final class a {

    /* renamed from: a, reason: collision with root package name */
    public final M4.p f1619a;

    public a(E4.b bVar) {
        m3.e eVar = new m3.e(7);
        M4.p pVar = new M4.p(bVar, "flutter/backgesture", w.f1742b, null);
        this.f1619a = pVar;
        pVar.b(eVar);
    }

    public static HashMap a(BackEvent backEvent) {
        List list;
        HashMap hashMap = new HashMap(3);
        float touchX = backEvent.getTouchX();
        float touchY = backEvent.getTouchY();
        if (!Float.isNaN(touchX) && !Float.isNaN(touchY)) {
            list = Arrays.asList(Float.valueOf(touchX), Float.valueOf(touchY));
        } else {
            list = null;
        }
        hashMap.put("touchOffset", list);
        hashMap.put("progress", Float.valueOf(backEvent.getProgress()));
        hashMap.put("swipeEdge", Integer.valueOf(backEvent.getSwipeEdge()));
        return hashMap;
    }
}
