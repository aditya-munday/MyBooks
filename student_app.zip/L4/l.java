package L4;

import android.util.DisplayMetrics;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* loaded from: classes.dex */
public final class l {

    /* renamed from: c, reason: collision with root package name */
    public static int f1667c = Integer.MIN_VALUE;

    /* renamed from: a, reason: collision with root package name */
    public final int f1668a;

    /* renamed from: b, reason: collision with root package name */
    public final DisplayMetrics f1669b;

    public l(DisplayMetrics displayMetrics) {
        int i6 = f1667c;
        f1667c = i6 + 1;
        this.f1668a = i6;
        this.f1669b = displayMetrics;
    }
}
