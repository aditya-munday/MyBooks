package L4;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* loaded from: classes.dex */
public final class g {

    /* renamed from: a, reason: collision with root package name */
    public final int f1642a;

    /* renamed from: b, reason: collision with root package name */
    public final Number f1643b;

    /* renamed from: c, reason: collision with root package name */
    public final Number f1644c;

    /* renamed from: d, reason: collision with root package name */
    public final int f1645d;
    public final int e;

    /* renamed from: f, reason: collision with root package name */
    public final Object f1646f;

    /* renamed from: g, reason: collision with root package name */
    public final Object f1647g;

    /* renamed from: h, reason: collision with root package name */
    public final int f1648h;

    /* renamed from: i, reason: collision with root package name */
    public final int f1649i;

    /* renamed from: j, reason: collision with root package name */
    public final float f1650j;

    /* renamed from: k, reason: collision with root package name */
    public final float f1651k;

    /* renamed from: l, reason: collision with root package name */
    public final int f1652l;

    /* renamed from: m, reason: collision with root package name */
    public final int f1653m;

    /* renamed from: n, reason: collision with root package name */
    public final int f1654n;
    public final int o;

    /* renamed from: p, reason: collision with root package name */
    public final long f1655p;

    public g(int i6, Number number, Number number2, int i7, int i8, Object obj, Object obj2, int i9, int i10, float f6, float f7, int i11, int i12, int i13, int i14, long j6) {
        this.f1642a = i6;
        this.f1643b = number;
        this.f1644c = number2;
        this.f1645d = i7;
        this.e = i8;
        this.f1646f = obj;
        this.f1647g = obj2;
        this.f1648h = i9;
        this.f1649i = i10;
        this.f1650j = f6;
        this.f1651k = f7;
        this.f1652l = i11;
        this.f1653m = i12;
        this.f1654n = i13;
        this.o = i14;
        this.f1655p = j6;
    }
}
