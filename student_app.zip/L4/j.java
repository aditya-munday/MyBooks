package L4;

import android.util.Log;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* loaded from: classes.dex */
public final class j implements M4.o {

    /* renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f1659a;

    /* renamed from: b, reason: collision with root package name */
    public final /* synthetic */ Object f1660b;

    /* renamed from: c, reason: collision with root package name */
    public final /* synthetic */ Object f1661c;

    public /* synthetic */ j(Object obj, Object obj2, int i6) {
        this.f1659a = i6;
        this.f1661c = obj;
        this.f1660b = obj2;
    }

    @Override // M4.o
    public final void b(Object obj) {
        switch (this.f1659a) {
            case 0:
                ((k) this.f1661c).f1663b = (byte[]) this.f1660b;
                return;
            default:
                ((E4.g) this.f1660b).a(((M4.p) ((A.c) this.f1661c).f5q).f1737c.a(obj));
                return;
        }
    }

    @Override // M4.o
    public final void c() {
        switch (this.f1659a) {
            case 0:
                return;
            default:
                ((E4.g) this.f1660b).a(null);
                return;
        }
    }

    @Override // M4.o
    public final void d(String str, String str2, Object obj) {
        switch (this.f1659a) {
            case 0:
                Log.e("RestorationChannel", "Error " + str + " while sending restoration data to framework: " + str2);
                return;
            default:
                ((E4.g) this.f1660b).a(((M4.p) ((A.c) this.f1661c).f5q).f1737c.c(str, str2, obj));
                return;
        }
    }

    private final void a() {
    }
}
