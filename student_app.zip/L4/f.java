package L4;

import java.nio.ByteBuffer;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* loaded from: classes.dex */
public final class f {

    /* renamed from: a, reason: collision with root package name */
    public final int f1634a;

    /* renamed from: b, reason: collision with root package name */
    public final String f1635b;

    /* renamed from: c, reason: collision with root package name */
    public final double f1636c;

    /* renamed from: d, reason: collision with root package name */
    public final double f1637d;
    public final double e;

    /* renamed from: f, reason: collision with root package name */
    public final double f1638f;

    /* renamed from: g, reason: collision with root package name */
    public final int f1639g;

    /* renamed from: h, reason: collision with root package name */
    public final int f1640h;

    /* renamed from: i, reason: collision with root package name */
    public final ByteBuffer f1641i;

    public f(int i6, String str, double d6, double d7, double d8, double d9, int i7, int i8, ByteBuffer byteBuffer) {
        this.f1634a = i6;
        this.f1635b = str;
        this.e = d6;
        this.f1638f = d7;
        this.f1636c = d8;
        this.f1637d = d9;
        this.f1639g = i7;
        this.f1640h = i8;
        this.f1641i = byteBuffer;
    }
}
