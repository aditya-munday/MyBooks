package L4;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* loaded from: classes.dex */
public final class h {

    /* renamed from: a, reason: collision with root package name */
    public final int f1656a;

    /* renamed from: b, reason: collision with root package name */
    public final double f1657b;

    /* renamed from: c, reason: collision with root package name */
    public final double f1658c;

    public h(int i6, double d6, double d7) {
        this.f1656a = i6;
        this.f1657b = d6;
        this.f1658c = d7;
    }
}
