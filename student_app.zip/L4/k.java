package L4;

import M4.w;
import java.util.HashMap;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* loaded from: classes.dex */
public final class k {

    /* renamed from: a, reason: collision with root package name */
    public final boolean f1662a;

    /* renamed from: b, reason: collision with root package name */
    public byte[] f1663b;

    /* renamed from: c, reason: collision with root package name */
    public final M4.p f1664c;

    /* renamed from: d, reason: collision with root package name */
    public j f1665d;
    public boolean e;

    /* renamed from: f, reason: collision with root package name */
    public boolean f1666f;

    public k(E4.b bVar, boolean z6) {
        M4.p pVar = new M4.p(bVar, "flutter/restoration", w.f1742b, null);
        this.e = false;
        this.f1666f = false;
        x3.c cVar = new x3.c(this, 16);
        this.f1664c = pVar;
        this.f1662a = z6;
        pVar.b(cVar);
    }

    public static HashMap a(byte[] bArr) {
        HashMap hashMap = new HashMap();
        hashMap.put("enabled", Boolean.TRUE);
        hashMap.put("data", bArr);
        return hashMap;
    }
}
