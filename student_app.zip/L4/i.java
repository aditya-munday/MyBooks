package L4;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* loaded from: classes.dex */
public interface i {
    void A(int i6);

    long B(f fVar);

    void a(boolean z6);

    void h(int i6, double d6, double d7);

    void i(int i6, int i7);

    void k(f fVar);

    void s(int i6);

    void u(h hVar, E1.a aVar);

    void x(g gVar);
}
