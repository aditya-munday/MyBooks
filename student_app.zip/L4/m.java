package L4;

import j2.C0508g;
import v3.u;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* loaded from: classes.dex */
public final class m {

    /* renamed from: b, reason: collision with root package name */
    public static final A1.i f1670b = new A1.i(11);

    /* renamed from: a, reason: collision with root package name */
    public final u f1671a;

    public m(E4.b bVar) {
        this.f1671a = new u(bVar, "flutter/settings", M4.j.f1731a, (C0508g) null);
    }
}
