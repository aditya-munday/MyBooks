package L4;

import C4.AbstractC0034i;
import org.apache.tika.mime.MimeTypes;

/* JADX WARN: Failed to restore enum class, 'enum' modifier and super class removed */
/* JADX WARN: Unknown enum class pattern. Please report as an issue! */
/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* loaded from: classes.dex */
public final class c {
    public static final c o;

    /* renamed from: p, reason: collision with root package name */
    public static final /* synthetic */ c[] f1624p;

    /* JADX WARN: Type inference failed for: r0v0, types: [java.lang.Enum, L4.c] */
    static {
        ?? r02 = new Enum("PLAIN_TEXT", 0);
        o = r02;
        f1624p = new c[]{r02};
    }

    public static c a(String str) {
        for (c cVar : values()) {
            cVar.getClass();
            if (MimeTypes.PLAIN_TEXT.equals(str)) {
                return cVar;
            }
        }
        throw new NoSuchFieldException(AbstractC0034i.j("No such ClipboardContentFormat: ", str));
    }

    public static c valueOf(String str) {
        return (c) Enum.valueOf(c.class, str);
    }

    public static c[] values() {
        return (c[]) f1624p.clone();
    }
}
