package L4;

import M4.x;
import j2.C0508g;
import java.util.Locale;
import java.util.TreeSet;
import l0.C0620i;
import l0.C0621j;
import v3.u;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* loaded from: classes.dex */
public final class b {

    /* renamed from: a, reason: collision with root package name */
    public int f1620a;

    /* renamed from: b, reason: collision with root package name */
    public int f1621b;

    /* renamed from: c, reason: collision with root package name */
    public boolean f1622c;

    /* renamed from: d, reason: collision with root package name */
    public final Object f1623d;

    public b(E4.b bVar) {
        u uVar = new u(bVar, "flutter/lifecycle", x.f1745b, (C0508g) null);
        this.f1620a = 0;
        this.f1621b = 0;
        this.f1622c = true;
        this.f1623d = uVar;
    }

    public static int b(int i6, int i7) {
        int min;
        int i8 = i6 - i7;
        if (Math.abs(i8) > 1000 && (min = (Math.min(i6, i7) - Math.max(i6, i7)) + 65535) < 1000) {
            if (i6 < i7) {
                return min;
            }
            return -min;
        }
        return i8;
    }

    public synchronized void a(C0621j c0621j) {
        this.f1620a = c0621j.f8325a.f8322c;
        ((TreeSet) this.f1623d).add(c0621j);
    }

    public synchronized C0620i c(long j6) {
        if (((TreeSet) this.f1623d).isEmpty()) {
            return null;
        }
        C0621j c0621j = (C0621j) ((TreeSet) this.f1623d).first();
        int i6 = c0621j.f8325a.f8322c;
        if (i6 != C0620i.a(this.f1621b) && j6 < c0621j.f8326b) {
            return null;
        }
        ((TreeSet) this.f1623d).pollFirst();
        this.f1621b = i6;
        return c0621j.f8325a;
    }

    public synchronized void d() {
        ((TreeSet) this.f1623d).clear();
        this.f1622c = false;
        this.f1621b = -1;
        this.f1620a = -1;
    }

    /* JADX WARN: Removed duplicated region for block: B:22:0x0032 A[ORIG_RETURN, RETURN] */
    /* JADX WARN: Removed duplicated region for block: B:23:0x0033  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public void e(int i6, boolean z6) {
        int i7;
        String str;
        int i8 = this.f1620a;
        if (i8 != i6 || z6 != this.f1622c) {
            if (i6 == 0 && i8 == 0) {
                this.f1622c = z6;
                return;
            }
            int b6 = L.i.b(i6);
            if (b6 != 0) {
                int i9 = 3;
                if (b6 != 1) {
                    if (b6 != 2 && b6 != 3 && b6 != 4) {
                        i7 = 0;
                    }
                } else {
                    if (z6) {
                        i9 = 2;
                    }
                    i7 = i9;
                }
                this.f1620a = i6;
                this.f1622c = z6;
                if (i7 != this.f1621b) {
                    return;
                }
                StringBuilder sb = new StringBuilder("AppLifecycleState.");
                if (i7 != 1) {
                    if (i7 != 2) {
                        if (i7 != 3) {
                            if (i7 != 4) {
                                if (i7 == 5) {
                                    str = "PAUSED";
                                } else {
                                    throw null;
                                }
                            } else {
                                str = "HIDDEN";
                            }
                        } else {
                            str = "INACTIVE";
                        }
                    } else {
                        str = "RESUMED";
                    }
                } else {
                    str = "DETACHED";
                }
                sb.append(str.toLowerCase(Locale.ROOT));
                ((u) this.f1623d).x(sb.toString(), null);
                this.f1621b = i7;
                return;
            }
            i7 = i6;
            this.f1620a = i6;
            this.f1622c = z6;
            if (i7 != this.f1621b) {
            }
        }
    }

    public b() {
        this.f1623d = new TreeSet(new A.d(7));
        d();
    }
}
