package L4;

import android.os.HandlerThread;
import b3.C0261a;
import b3.C0269i;
import b3.C0277q;
import b3.InterfaceC0264d;
import java.io.Serializable;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.ListIterator;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* loaded from: classes.dex */
public final class d implements n4.h {
    public int o;

    /* renamed from: p, reason: collision with root package name */
    public int f1625p;

    /* renamed from: q, reason: collision with root package name */
    public Object f1626q;

    /* renamed from: r, reason: collision with root package name */
    public final Serializable f1627r;

    /* renamed from: s, reason: collision with root package name */
    public final Serializable f1628s;

    /* renamed from: t, reason: collision with root package name */
    public Object f1629t;

    /* renamed from: u, reason: collision with root package name */
    public final Serializable f1630u;

    public d(int i6, int i7) {
        this.f1627r = new LinkedList();
        this.f1628s = new HashSet();
        this.f1629t = new HashSet();
        this.f1630u = new HashMap();
        this.f1626q = "Sqflite";
        this.o = i6;
        this.f1625p = i7;
    }

    @Override // n4.h
    public synchronized void a() {
        try {
            Iterator it = ((HashSet) this.f1628s).iterator();
            while (it.hasNext()) {
                n4.g gVar = (n4.g) it.next();
                synchronized (gVar) {
                    HandlerThread handlerThread = gVar.f8755c;
                    if (handlerThread != null) {
                        handlerThread.quit();
                        gVar.f8755c = null;
                        gVar.f8756d = null;
                    }
                }
            }
            Iterator it2 = ((HashSet) this.f1629t).iterator();
            while (it2.hasNext()) {
                n4.g gVar2 = (n4.g) it2.next();
                synchronized (gVar2) {
                    HandlerThread handlerThread2 = gVar2.f8755c;
                    if (handlerThread2 != null) {
                        handlerThread2.quit();
                        gVar2.f8755c = null;
                        gVar2.f8756d = null;
                    }
                }
            }
        } catch (Throwable th) {
            throw th;
        }
    }

    @Override // n4.h
    public synchronized void b(n4.f fVar) {
        ((LinkedList) this.f1627r).add(fVar);
        Iterator it = new HashSet((HashSet) this.f1628s).iterator();
        while (it.hasNext()) {
            g((n4.g) it.next());
        }
    }

    public void d(C0269i c0269i) {
        if (!((HashSet) this.f1627r).contains(c0269i.f5321a)) {
            ((HashSet) this.f1628s).add(c0269i);
            return;
        }
        throw new IllegalArgumentException("Components are not allowed to depend on interfaces they themselves provide.");
    }

    public C0261a e() {
        boolean z6;
        if (((InterfaceC0264d) this.f1629t) != null) {
            z6 = true;
        } else {
            z6 = false;
        }
        if (z6) {
            return new C0261a((String) this.f1626q, new HashSet((HashSet) this.f1627r), new HashSet((HashSet) this.f1628s), this.o, this.f1625p, (InterfaceC0264d) this.f1629t, (HashSet) this.f1630u);
        }
        throw new IllegalStateException("Missing required property: factory.");
    }

    public synchronized n4.f f(n4.g gVar) {
        n4.g gVar2;
        n4.f fVar;
        try {
            ListIterator listIterator = ((LinkedList) this.f1627r).listIterator();
            do {
                gVar2 = null;
                if (!listIterator.hasNext()) {
                    return null;
                }
                fVar = (n4.f) listIterator.next();
                if (fVar.a() != null) {
                    gVar2 = (n4.g) ((HashMap) this.f1630u).get(fVar.a());
                }
                if (gVar2 == null) {
                    break;
                }
            } while (gVar2 != gVar);
            listIterator.remove();
            return fVar;
        } catch (Throwable th) {
            throw th;
        }
    }

    public synchronized void g(n4.g gVar) {
        try {
            n4.f f6 = f(gVar);
            if (f6 != null) {
                ((HashSet) this.f1629t).add(gVar);
                ((HashSet) this.f1628s).remove(gVar);
                if (f6.a() != null) {
                    ((HashMap) this.f1630u).put(f6.a(), gVar);
                }
                gVar.f8756d.post(new I3.b(gVar, f6, 27));
            }
        } catch (Throwable th) {
            throw th;
        }
    }

    @Override // n4.h
    public synchronized void start() {
        for (int i6 = 0; i6 < this.o; i6++) {
            n4.g gVar = new n4.g(((String) this.f1626q) + i6, this.f1625p);
            gVar.a(new I3.b(this, gVar, 28));
            ((HashSet) this.f1628s).add(gVar);
        }
    }

    public d(Class cls, Class[] clsArr) {
        this.f1626q = null;
        HashSet hashSet = new HashSet();
        this.f1627r = hashSet;
        this.f1628s = new HashSet();
        this.o = 0;
        this.f1625p = 0;
        this.f1630u = new HashSet();
        hashSet.add(C0277q.a(cls));
        for (Class cls2 : clsArr) {
            T5.h.b(cls2, "Null interface");
            ((HashSet) this.f1627r).add(C0277q.a(cls2));
        }
    }

    public d(C0277q c0277q, C0277q[] c0277qArr) {
        this.f1626q = null;
        HashSet hashSet = new HashSet();
        this.f1627r = hashSet;
        this.f1628s = new HashSet();
        this.o = 0;
        this.f1625p = 0;
        this.f1630u = new HashSet();
        hashSet.add(c0277q);
        for (C0277q c0277q2 : c0277qArr) {
            T5.h.b(c0277q2, "Null interface");
        }
        Collections.addAll((HashSet) this.f1627r, c0277qArr);
    }

    public d(Integer num, int i6, Boolean bool, Integer num2, int i7, Integer num3, Boolean bool2) {
        this.f1626q = num;
        this.o = i6;
        this.f1629t = bool;
        this.f1627r = num2;
        this.f1625p = i7;
        this.f1628s = num3;
        this.f1630u = bool2;
    }
}
