package L4;

import java.util.Locale;
import v3.u;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* loaded from: classes.dex */
public final class n {

    /* renamed from: a, reason: collision with root package name */
    public final boolean f1672a;

    /* renamed from: b, reason: collision with root package name */
    public final boolean f1673b;

    /* renamed from: c, reason: collision with root package name */
    public final boolean f1674c;

    /* renamed from: d, reason: collision with root package name */
    public final boolean f1675d;
    public final boolean e;

    /* renamed from: f, reason: collision with root package name */
    public final int f1676f;

    /* renamed from: g, reason: collision with root package name */
    public final o f1677g;

    /* renamed from: h, reason: collision with root package name */
    public final Integer f1678h;

    /* renamed from: i, reason: collision with root package name */
    public final String f1679i;

    /* renamed from: j, reason: collision with root package name */
    public final u f1680j;

    /* renamed from: k, reason: collision with root package name */
    public final String[] f1681k;

    /* renamed from: l, reason: collision with root package name */
    public final n[] f1682l;

    /* renamed from: m, reason: collision with root package name */
    public final Locale[] f1683m;

    public n(boolean z6, boolean z7, boolean z8, boolean z9, boolean z10, int i6, o oVar, Integer num, String str, u uVar, String[] strArr, n[] nVarArr, Locale[] localeArr) {
        this.f1672a = z6;
        this.f1673b = z7;
        this.f1674c = z8;
        this.f1675d = z9;
        this.e = z10;
        this.f1676f = i6;
        this.f1677g = oVar;
        this.f1678h = num;
        this.f1679i = str;
        this.f1680j = uVar;
        this.f1681k = strArr;
        this.f1682l = nVarArr;
        this.f1683m = localeArr;
    }

    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r8v1 L4.n, still in use, count: 2, list:
          (r8v1 L4.n) from 0x0221: PHI (r8v2 L4.n) = (r8v1 L4.n), (r8v4 L4.n) binds: [B:69:0x0214, B:76:0x04ff] A[DONT_GENERATE, DONT_INLINE]
          (r8v1 L4.n) from 0x01eb: MOVE (r31v5 L4.n) = (r8v1 L4.n) (LINE:492)
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:151)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:116)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:80)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:56)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:447)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:96)
        */
    public static L4.n a(org.json.JSONObject r35) {
        /*
            Method dump skipped, instructions count: 1746
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: L4.n.a(org.json.JSONObject):L4.n");
    }
}
