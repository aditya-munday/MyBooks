package L4;

import org.json.JSONObject;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* loaded from: classes.dex */
public final class p {

    /* renamed from: a, reason: collision with root package name */
    public final String f1687a;

    /* renamed from: b, reason: collision with root package name */
    public final int f1688b;

    /* renamed from: c, reason: collision with root package name */
    public final int f1689c;

    /* renamed from: d, reason: collision with root package name */
    public final int f1690d;
    public final int e;

    public p(String str, int i6, int i7, int i8, int i9) {
        if ((i6 == -1 && i7 == -1) || (i6 >= 0 && i7 >= 0)) {
            if ((i8 == -1 && i9 == -1) || (i8 >= 0 && i8 <= i9)) {
                if (i9 <= str.length()) {
                    if (i6 <= str.length()) {
                        if (i7 <= str.length()) {
                            this.f1687a = str;
                            this.f1688b = i6;
                            this.f1689c = i7;
                            this.f1690d = i8;
                            this.e = i9;
                            return;
                        }
                        throw new IndexOutOfBoundsException("invalid selection end: " + String.valueOf(i7));
                    }
                    throw new IndexOutOfBoundsException("invalid selection start: " + String.valueOf(i6));
                }
                throw new IndexOutOfBoundsException("invalid composing start: " + String.valueOf(i8));
            }
            throw new IndexOutOfBoundsException("invalid composing range: (" + String.valueOf(i8) + ", " + String.valueOf(i9) + ")");
        }
        throw new IndexOutOfBoundsException("invalid selection: (" + String.valueOf(i6) + ", " + String.valueOf(i7) + ")");
    }

    public static p a(JSONObject jSONObject) {
        return new p(jSONObject.getString("text"), jSONObject.getInt("selectionBase"), jSONObject.getInt("selectionExtent"), jSONObject.getInt("composingBase"), jSONObject.getInt("composingExtent"));
    }
}
