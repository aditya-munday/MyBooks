package x3;

import java.util.Collections;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* loaded from: classes.dex */
public final class b {

    /* renamed from: a, reason: collision with root package name */
    public final String f10278a;

    /* renamed from: b, reason: collision with root package name */
    public final c f10279b;

    public b(Set set, c cVar) {
        this.f10278a = b(set);
        this.f10279b = cVar;
    }

    public static String b(Set set) {
        StringBuilder sb = new StringBuilder();
        Iterator it = set.iterator();
        while (it.hasNext()) {
            C0892a c0892a = (C0892a) it.next();
            sb.append(c0892a.f10276a);
            sb.append('/');
            sb.append(c0892a.f10277b);
            if (it.hasNext()) {
                sb.append(' ');
            }
        }
        return sb.toString();
    }

    public final String a() {
        Set unmodifiableSet;
        Set unmodifiableSet2;
        String str = this.f10278a;
        c cVar = this.f10279b;
        synchronized (((HashSet) cVar.f10281p)) {
            unmodifiableSet = Collections.unmodifiableSet((HashSet) cVar.f10281p);
        }
        if (unmodifiableSet.isEmpty()) {
            return str;
        }
        StringBuilder sb = new StringBuilder();
        sb.append(str);
        sb.append(' ');
        synchronized (((HashSet) cVar.f10281p)) {
            unmodifiableSet2 = Collections.unmodifiableSet((HashSet) cVar.f10281p);
        }
        sb.append(b(unmodifiableSet2));
        return sb.toString();
    }
}
