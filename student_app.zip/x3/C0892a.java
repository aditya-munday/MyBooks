package x3;

import androidx.datastore.preferences.protobuf.AbstractC0227o;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* renamed from: x3.a, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0892a {

    /* renamed from: a, reason: collision with root package name */
    public final String f10276a;

    /* renamed from: b, reason: collision with root package name */
    public final String f10277b;

    public C0892a(String str, String str2) {
        this.f10276a = str;
        if (str2 != null) {
            this.f10277b = str2;
            return;
        }
        throw new NullPointerException("Null version");
    }

    public final boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        if (obj instanceof C0892a) {
            C0892a c0892a = (C0892a) obj;
            if (this.f10276a.equals(c0892a.f10276a) && this.f10277b.equals(c0892a.f10277b)) {
                return true;
            }
        }
        return false;
    }

    public final int hashCode() {
        return ((this.f10276a.hashCode() ^ 1000003) * 1000003) ^ this.f10277b.hashCode();
    }

    public final String toString() {
        StringBuilder sb = new StringBuilder("LibraryVersion{libraryName=");
        sb.append(this.f10276a);
        sb.append(", version=");
        return AbstractC0227o.h(sb, this.f10277b, "}");
    }
}
