package x3;

import A1.i;
import A5.d;
import B5.l;
import C4.AbstractActivityC0029d;
import C4.AbstractC0034i;
import C4.I;
import C4.InterfaceC0032g;
import C4.J;
import D.C0044i;
import D.P;
import D.w;
import J.C0083c;
import J.InterfaceC0087g;
import J.S;
import J.Z;
import J.a0;
import L4.j;
import M4.f;
import M4.k;
import M4.m;
import M4.n;
import M4.o;
import S.AbstractC0110c;
import S.AbstractC0111d;
import S.C0112e;
import S.C0115h;
import S.G;
import V.v;
import Z4.s;
import android.app.Activity;
import android.app.ActivityManager;
import android.content.ClipData;
import android.content.ClipDescription;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.media.AudioAttributes;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.util.SparseArray;
import android.view.View;
import android.view.accessibility.AccessibilityEvent;
import android.view.inputmethod.InputMethodManager;
import androidx.lifecycle.r;
import androidx.lifecycle.x;
import c5.C0346j;
import com.shockwave.pdfium.PdfDocument;
import com.shockwave.pdfium.PdfiumCore;
import d.AbstractDialogC0388a;
import d.InterfaceC0389b;
import g5.h;
import io.flutter.embedding.engine.FlutterJNI;
import io.flutter.plugin.platform.e;
import io.flutter.plugin.platform.g;
import j2.C0508g;
import j5.EnumC0522a;
import java.lang.reflect.Field;
import java.nio.ByteBuffer;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.concurrent.atomic.AtomicInteger;
import k5.AbstractC0567h;
import org.apache.tika.fork.ContentHandlerProxy;
import org.apache.tika.fork.ForkServer;
import org.apache.tika.mime.MimeTypes;
import org.apache.tika.mime.MimeTypesReaderMetKeys;
import org.apache.tika.parser.external.ExternalParsersConfigReaderMetKeys;
import org.apache.tika.pipes.PipesServer;
import org.apache.tika.pipes.pipesiterator.PipesIterator;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import p5.p;
import v3.u;
import x0.F;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* loaded from: classes.dex */
public final class c implements d, I, f, M4.b, n, InterfaceC0087g, x, Q1.a, X1.b {

    /* renamed from: q, reason: collision with root package name */
    public static volatile c f10280q;
    public final /* synthetic */ int o;

    /* renamed from: p, reason: collision with root package name */
    public Object f10281p;

    public /* synthetic */ c(Object obj, int i6) {
        this.o = i6;
        this.f10281p = obj;
    }

    /* JADX WARN: Can't fix incorrect switch cases order, some code will duplicate */
    /* JADX WARN: Failed to find 'out' block for switch in B:7:0x001f. Please report as an issue. */
    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Removed duplicated region for block: B:34:0x00ab A[Catch: JSONException -> 0x0056, TryCatch #6 {JSONException -> 0x0056, blocks: (B:5:0x0015, B:8:0x0024, B:16:0x004a, B:18:0x0059, B:25:0x0079, B:27:0x0085, B:29:0x008d, B:39:0x0091, B:32:0x00a1, B:34:0x00ab, B:36:0x00bb, B:41:0x0096, B:42:0x00c3, B:49:0x00e7, B:51:0x00f3, B:73:0x0135, B:75:0x0141, B:77:0x0149, B:80:0x016d, B:82:0x0160, B:85:0x0167, B:86:0x017f, B:88:0x0187, B:90:0x019a, B:93:0x01a2, B:95:0x01b2, B:96:0x01bf, B:100:0x01c8, B:102:0x01d4, B:105:0x01dc, B:109:0x01f2, B:111:0x01fe, B:125:0x0244, B:127:0x0250, B:129:0x0258, B:131:0x027a, B:133:0x0282, B:135:0x02a9, B:137:0x02b1, B:139:0x02bf, B:141:0x02ca, B:143:0x02d2, B:145:0x02da, B:147:0x0308, B:149:0x0310, B:151:0x0322, B:152:0x0327, B:154:0x032e, B:114:0x0206, B:116:0x0210, B:117:0x0213, B:119:0x0229, B:120:0x023b, B:123:0x0232), top: B:4:0x0015, inners: #0, #1, #10, #11 }] */
    /* JADX WARN: Removed duplicated region for block: B:36:0x00bb A[Catch: JSONException -> 0x0056, TryCatch #6 {JSONException -> 0x0056, blocks: (B:5:0x0015, B:8:0x0024, B:16:0x004a, B:18:0x0059, B:25:0x0079, B:27:0x0085, B:29:0x008d, B:39:0x0091, B:32:0x00a1, B:34:0x00ab, B:36:0x00bb, B:41:0x0096, B:42:0x00c3, B:49:0x00e7, B:51:0x00f3, B:73:0x0135, B:75:0x0141, B:77:0x0149, B:80:0x016d, B:82:0x0160, B:85:0x0167, B:86:0x017f, B:88:0x0187, B:90:0x019a, B:93:0x01a2, B:95:0x01b2, B:96:0x01bf, B:100:0x01c8, B:102:0x01d4, B:105:0x01dc, B:109:0x01f2, B:111:0x01fe, B:125:0x0244, B:127:0x0250, B:129:0x0258, B:131:0x027a, B:133:0x0282, B:135:0x02a9, B:137:0x02b1, B:139:0x02bf, B:141:0x02ca, B:143:0x02d2, B:145:0x02da, B:147:0x0308, B:149:0x0310, B:151:0x0322, B:152:0x0327, B:154:0x032e, B:114:0x0206, B:116:0x0210, B:117:0x0213, B:119:0x0229, B:120:0x023b, B:123:0x0232), top: B:4:0x0015, inners: #0, #1, #10, #11 }] */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    private final void r(m mVar, o oVar) {
        ClipDescription primaryClipDescription;
        int i6;
        L4.c a6;
        CharSequence c6;
        A.c cVar = (A.c) this.f10281p;
        if (((io.flutter.plugin.platform.o) cVar.f5q) != null) {
            String str = mVar.f1733a;
            Object obj = mVar.f1734b;
            try {
                boolean z6 = false;
                switch (str.hashCode()) {
                    case -1501580720:
                        if (str.equals("SystemNavigator.setFrameworkHandlesBack")) {
                            boolean booleanValue = ((Boolean) obj).booleanValue();
                            InterfaceC0032g interfaceC0032g = ((g) ((io.flutter.plugin.platform.o) cVar.f5q).f7214p).f7197c;
                            if (interfaceC0032g != null) {
                                ((AbstractActivityC0029d) interfaceC0032g).i(booleanValue);
                            }
                            ((j) oVar).b(null);
                            return;
                        }
                        ((j) oVar).c();
                        return;
                    case -931781241:
                        if (str.equals("Share.invoke")) {
                            g gVar = (g) ((io.flutter.plugin.platform.o) cVar.f5q).f7214p;
                            Intent intent = new Intent();
                            intent.setAction("android.intent.action.SEND");
                            intent.setType(MimeTypes.PLAIN_TEXT);
                            intent.putExtra("android.intent.extra.TEXT", (String) obj);
                            gVar.f7195a.startActivity(Intent.createChooser(intent, null));
                            ((j) oVar).b(null);
                            return;
                        }
                        ((j) oVar).c();
                        return;
                    case -766342101:
                        if (str.equals("SystemNavigator.pop")) {
                            Activity activity = ((g) ((io.flutter.plugin.platform.o) cVar.f5q).f7214p).f7195a;
                            if (!(activity instanceof InterfaceC0389b)) {
                                activity.finish();
                                ((j) oVar).b(null);
                                return;
                            } else {
                                ((AbstractDialogC0388a) ((InterfaceC0389b) activity)).getClass();
                                throw null;
                            }
                        }
                        ((j) oVar).c();
                        return;
                    case -720677196:
                        if (str.equals("Clipboard.setData")) {
                            ((ClipboardManager) ((g) ((io.flutter.plugin.platform.o) cVar.f5q).f7214p).f7195a.getSystemService("clipboard")).setPrimaryClip(ClipData.newPlainText("text label?", ((JSONObject) obj).getString("text")));
                            ((j) oVar).b(null);
                            return;
                        }
                        ((j) oVar).c();
                        return;
                    case -577225884:
                        if (str.equals("SystemChrome.setSystemUIChangeListener")) {
                            g gVar2 = (g) ((io.flutter.plugin.platform.o) cVar.f5q).f7214p;
                            View decorView = gVar2.f7195a.getWindow().getDecorView();
                            decorView.setOnSystemUiVisibilityChangeListener(new io.flutter.plugin.platform.f(gVar2, decorView));
                            ((j) oVar).b(null);
                            return;
                        }
                        ((j) oVar).c();
                        return;
                    case -548468504:
                        if (str.equals("SystemChrome.setApplicationSwitcherDescription")) {
                            try {
                                JSONObject jSONObject = (JSONObject) obj;
                                int i7 = jSONObject.getInt("primaryColor");
                                if (i7 != 0) {
                                    i7 |= -16777216;
                                }
                                String string = jSONObject.getString("label");
                                Activity activity2 = ((g) ((io.flutter.plugin.platform.o) cVar.f5q).f7214p).f7195a;
                                if (Build.VERSION.SDK_INT < 28) {
                                    activity2.setTaskDescription(new ActivityManager.TaskDescription(string, (Bitmap) null, i7));
                                } else {
                                    activity2.setTaskDescription(e.a(i7, string));
                                }
                                ((j) oVar).b(null);
                                return;
                            } catch (JSONException e) {
                                ((j) oVar).d("error", e.getMessage(), null);
                                return;
                            }
                        }
                        ((j) oVar).c();
                        return;
                    case -247230243:
                        if (str.equals("HapticFeedback.vibrate")) {
                            try {
                                ((io.flutter.plugin.platform.o) cVar.f5q).f(AbstractC0034i.c((String) obj));
                                ((j) oVar).b(null);
                                return;
                            } catch (NoSuchFieldException e6) {
                                ((j) oVar).d("error", e6.getMessage(), null);
                                return;
                            }
                        }
                        ((j) oVar).c();
                        return;
                    case -215273374:
                        if (str.equals("SystemSound.play")) {
                            try {
                                int d6 = AbstractC0034i.d((String) obj);
                                g gVar3 = (g) ((io.flutter.plugin.platform.o) cVar.f5q).f7214p;
                                if (d6 == 1) {
                                    gVar3.f7195a.getWindow().getDecorView().playSoundEffect(0);
                                }
                                ((j) oVar).b(null);
                                return;
                            } catch (NoSuchFieldException e7) {
                                ((j) oVar).d("error", e7.getMessage(), null);
                                return;
                            }
                        }
                        ((j) oVar).c();
                        return;
                    case 241845679:
                        if (str.equals("SystemChrome.restoreSystemUIOverlays")) {
                            ((g) ((io.flutter.plugin.platform.o) cVar.f5q).f7214p).b();
                            ((j) oVar).b(null);
                            return;
                        }
                        ((j) oVar).c();
                        return;
                    case 875995648:
                        if (str.equals("Clipboard.hasStrings")) {
                            ClipboardManager clipboardManager = (ClipboardManager) ((g) ((io.flutter.plugin.platform.o) cVar.f5q).f7214p).f7195a.getSystemService("clipboard");
                            if (clipboardManager.hasPrimaryClip() && (primaryClipDescription = clipboardManager.getPrimaryClipDescription()) != null) {
                                z6 = primaryClipDescription.hasMimeType("text/*");
                            }
                            JSONObject jSONObject2 = new JSONObject();
                            jSONObject2.put(MimeTypesReaderMetKeys.MATCH_VALUE_ATTR, z6);
                            ((j) oVar).b(jSONObject2);
                            return;
                        }
                        ((j) oVar).c();
                        return;
                    case 1128339786:
                        if (str.equals("SystemChrome.setEnabledSystemUIMode")) {
                            try {
                                int e8 = A.c.e(cVar, (String) obj);
                                g gVar4 = (g) ((io.flutter.plugin.platform.o) cVar.f5q).f7214p;
                                if (e8 == 1) {
                                    i6 = 1798;
                                } else if (e8 == 2) {
                                    i6 = 3846;
                                } else if (e8 == 3) {
                                    i6 = 5894;
                                } else {
                                    if (e8 == 4 && Build.VERSION.SDK_INT >= 29) {
                                        i6 = 1792;
                                    }
                                    ((j) oVar).b(null);
                                    return;
                                }
                                gVar4.e = i6;
                                gVar4.b();
                                ((j) oVar).b(null);
                                return;
                            } catch (NoSuchFieldException | JSONException e9) {
                                ((j) oVar).d("error", e9.getMessage(), null);
                                return;
                            }
                        }
                        ((j) oVar).c();
                        return;
                    case 1390477857:
                        if (str.equals("SystemChrome.setSystemUIOverlayStyle")) {
                            try {
                                ((g) ((io.flutter.plugin.platform.o) cVar.f5q).f7214p).a(A.c.h(cVar, (JSONObject) obj));
                                ((j) oVar).b(null);
                                return;
                            } catch (NoSuchFieldException | JSONException e10) {
                                ((j) oVar).d("error", e10.getMessage(), null);
                                return;
                            }
                        }
                        ((j) oVar).c();
                        return;
                    case 1514180520:
                        if (str.equals("Clipboard.getData")) {
                            String str2 = (String) obj;
                            if (str2 != null) {
                                try {
                                    a6 = L4.c.a(str2);
                                } catch (NoSuchFieldException unused) {
                                    ((j) oVar).d("error", "No such clipboard content format: ".concat(str2), null);
                                }
                                c6 = ((io.flutter.plugin.platform.o) cVar.f5q).c(a6);
                                if (c6 == null) {
                                    JSONObject jSONObject3 = new JSONObject();
                                    jSONObject3.put("text", c6);
                                    ((j) oVar).b(jSONObject3);
                                    return;
                                }
                                ((j) oVar).b(null);
                                return;
                            }
                            a6 = null;
                            c6 = ((io.flutter.plugin.platform.o) cVar.f5q).c(a6);
                            if (c6 == null) {
                            }
                        }
                        ((j) oVar).c();
                        return;
                    case 1674312266:
                        if (str.equals("SystemChrome.setEnabledSystemUIOverlays")) {
                            try {
                                ((io.flutter.plugin.platform.o) cVar.f5q).e(A.c.d(cVar, (JSONArray) obj));
                                ((j) oVar).b(null);
                                return;
                            } catch (NoSuchFieldException | JSONException e11) {
                                ((j) oVar).d("error", e11.getMessage(), null);
                                return;
                            }
                        }
                        ((j) oVar).c();
                        return;
                    case 2119655719:
                        if (str.equals("SystemChrome.setPreferredOrientations")) {
                            try {
                                ((g) ((io.flutter.plugin.platform.o) cVar.f5q).f7214p).f7195a.setRequestedOrientation(A.c.c(cVar, (JSONArray) obj));
                                ((j) oVar).b(null);
                                return;
                            } catch (NoSuchFieldException | JSONException e12) {
                                ((j) oVar).d("error", e12.getMessage(), null);
                                return;
                            }
                        }
                        ((j) oVar).c();
                        return;
                    default:
                        ((j) oVar).c();
                        return;
                }
            } catch (JSONException e13) {
                ((j) oVar).d("error", "JSON error: " + e13.getMessage(), null);
            }
        }
    }

    @Override // M4.f
    public void a(String str, ByteBuffer byteBuffer, M4.e eVar) {
        ((E4.j) this.f10281p).a(str, byteBuffer, eVar);
    }

    @Override // J.InterfaceC0087g
    public Object b(p pVar, AbstractC0567h abstractC0567h) {
        return ((InterfaceC0087g) this.f10281p).b(new M.c(pVar, null, 0), abstractC0567h);
    }

    @Override // C4.I
    public void d() {
        J j6 = (J) this.f10281p;
        j6.f390a.setAlpha(0.0f);
        io.flutter.embedding.engine.renderer.j jVar = j6.f391b;
        if (jVar != null) {
            jVar.g(j6.f393d);
        }
        j6.f391b = null;
    }

    @Override // M4.b
    public void e(Object obj, A.c cVar) {
        i iVar = (i) this.f10281p;
        if (((s) iVar.f52r) == null) {
            cVar.g(null);
            return;
        }
        HashMap hashMap = (HashMap) obj;
        String str = (String) hashMap.get("type");
        HashMap hashMap2 = (HashMap) hashMap.get("data");
        str.getClass();
        char c6 = 65535;
        switch (str.hashCode()) {
            case -1140076541:
                if (str.equals("tooltip")) {
                    c6 = 0;
                    break;
                }
                break;
            case -649620375:
                if (str.equals("announce")) {
                    c6 = 1;
                    break;
                }
                break;
            case 114595:
                if (str.equals("tap")) {
                    c6 = 2;
                    break;
                }
                break;
            case 97604824:
                if (str.equals("focus")) {
                    c6 = 3;
                    break;
                }
                break;
            case 114203431:
                if (str.equals("longPress")) {
                    c6 = 4;
                    break;
                }
                break;
        }
        switch (c6) {
            case 0:
                String str2 = (String) hashMap2.get("message");
                if (str2 != null) {
                    io.flutter.view.f fVar = (io.flutter.view.f) ((s) iVar.f52r).o;
                    if (Build.VERSION.SDK_INT < 28) {
                        AccessibilityEvent e = fVar.e(0, 32);
                        e.getText().add(str2);
                        fVar.i(e);
                        break;
                    }
                }
                break;
            case 1:
                String str3 = (String) hashMap2.get("message");
                if (str3 != null) {
                    s sVar = (s) iVar.f52r;
                    if (Build.VERSION.SDK_INT >= 36) {
                        sVar.getClass();
                        Log.w("AccessibilityBridge", "Using AnnounceSemanticsEvent for accessibility is deprecated on Android. Migrate to using semantic properties for a more robust and accessible user experience.\nFlutter: If you are unsure why you are seeing this bug, it might be because you are using a widget that calls this method. See https://github.com/flutter/flutter/issues/165510 for more details.\nAndroid documentation: https://developer.android.com/reference/android/view/View#announceForAccessibility(java.lang.CharSequence)");
                    }
                    ((io.flutter.view.f) sVar.o).f7360a.announceForAccessibility(str3);
                    break;
                }
                break;
            case 2:
                Integer num = (Integer) hashMap.get("nodeId");
                if (num != null) {
                    ((io.flutter.view.f) ((s) iVar.f52r).o).h(num.intValue(), 1);
                    break;
                }
                break;
            case 3:
                Integer num2 = (Integer) hashMap.get("nodeId");
                if (num2 != null) {
                    ((io.flutter.view.f) ((s) iVar.f52r).o).h(num2.intValue(), 8);
                    break;
                }
                break;
            case 4:
                Integer num3 = (Integer) hashMap.get("nodeId");
                if (num3 != null) {
                    ((io.flutter.view.f) ((s) iVar.f52r).o).h(num3.intValue(), 2);
                    break;
                }
                break;
        }
        cVar.g(null);
    }

    @Override // M4.f
    public C0508g f(k kVar) {
        return ((E4.j) this.f10281p).f(kVar);
    }

    @Override // M4.f
    public void g(String str, M4.d dVar, C0508g c0508g) {
        ((E4.j) this.f10281p).g(str, dVar, c0508g);
    }

    @Override // f5.InterfaceC0446a
    public Object get() {
        return new i((Context) ((X1.c) this.f10281p).o, new Object(), new C0346j(6), 28);
    }

    @Override // J.InterfaceC0087g
    public d getData() {
        return ((InterfaceC0087g) this.f10281p).getData();
    }

    @Override // C4.I
    public void h() {
        J j6 = (J) this.f10281p;
        io.flutter.embedding.engine.renderer.j jVar = j6.f391b;
        if (jVar != null) {
            jVar.a(j6.f393d);
        }
    }

    @Override // M4.f
    public void i(String str, ByteBuffer byteBuffer) {
        ((E4.j) this.f10281p).a(str, byteBuffer, null);
    }

    @Override // Q1.a
    public PdfDocument j(Context context, PdfiumCore pdfiumCore, String str) {
        return pdfiumCore.h(context.getContentResolver().openFileDescriptor((Uri) this.f10281p, "r"), str);
    }

    /* JADX WARN: Removed duplicated region for block: B:21:0x0033  */
    /* JADX WARN: Removed duplicated region for block: B:8:0x0021  */
    /* JADX WARN: Type inference failed for: r6v4, types: [p5.p, k5.h] */
    @Override // A5.d
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public Object k(A5.e eVar, i5.d dVar) {
        A5.a aVar;
        int i6;
        Throwable th;
        l lVar;
        if (dVar instanceof A5.a) {
            aVar = (A5.a) dVar;
            int i7 = aVar.f93u;
            if ((i7 & Integer.MIN_VALUE) != 0) {
                aVar.f93u = i7 - Integer.MIN_VALUE;
                Object obj = aVar.f91s;
                i6 = aVar.f93u;
                h hVar = h.f6800a;
                if (i6 == 0) {
                    if (i6 == 1) {
                        lVar = aVar.f90r;
                        try {
                            Q5.a.K(obj);
                        } catch (Throwable th2) {
                            th = th2;
                            lVar.q();
                            throw th;
                        }
                    } else {
                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                    }
                } else {
                    Q5.a.K(obj);
                    i5.i iVar = aVar.f8000p;
                    q5.h.b(iVar);
                    l lVar2 = new l(eVar, iVar);
                    try {
                        aVar.f90r = lVar2;
                        aVar.f93u = 1;
                        Object h6 = ((AbstractC0567h) this.f10281p).h(lVar2, aVar);
                        EnumC0522a enumC0522a = EnumC0522a.o;
                        if (h6 != enumC0522a) {
                            h6 = hVar;
                        }
                        if (h6 == enumC0522a) {
                            return enumC0522a;
                        }
                        lVar = lVar2;
                    } catch (Throwable th3) {
                        th = th3;
                        lVar = lVar2;
                        lVar.q();
                        throw th;
                    }
                }
                lVar.q();
                return hVar;
            }
        }
        aVar = new A5.a(this, dVar);
        Object obj2 = aVar.f91s;
        i6 = aVar.f93u;
        h hVar2 = h.f6800a;
        if (i6 == 0) {
        }
        lVar.q();
        return hVar2;
    }

    @Override // C4.I
    public void l(io.flutter.embedding.engine.renderer.j jVar) {
        J j6 = (J) this.f10281p;
        io.flutter.embedding.engine.renderer.j jVar2 = j6.f391b;
        if (jVar2 != null) {
            jVar2.g(j6.f393d);
        }
        j6.f391b = jVar;
    }

    @Override // M4.f
    public void m(String str, M4.d dVar) {
        ((E4.j) this.f10281p).g(str, dVar, null);
    }

    @Override // androidx.lifecycle.x
    public void n(Object obj) {
        r rVar = (r) obj;
        O.d dVar = (O.d) this.f10281p;
        if (rVar != null && dVar.y) {
            dVar.getClass();
            throw new IllegalStateException("Fragment " + dVar + " did not return a View from onCreateView() or this was called before onCreateView().");
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    public void o(int i6, int i7, x0.p pVar) {
        int i8;
        int i9;
        int i10;
        long j6;
        int i11;
        int i12;
        int i13;
        int i14;
        int i15;
        P0.d dVar = (P0.d) this.f10281p;
        P0.e eVar = dVar.f1984b;
        SparseArray sparseArray = dVar.f1986c;
        v vVar = dVar.f1996k;
        v vVar2 = dVar.f1994i;
        int i16 = 1;
        int i17 = 0;
        if (i6 != 161 && i6 != 163) {
            if (i6 != 165) {
                if (i6 != 16877) {
                    if (i6 != 16981) {
                        if (i6 != 18402) {
                            if (i6 != 21419) {
                                if (i6 != 25506) {
                                    if (i6 == 30322) {
                                        dVar.c(i6);
                                        byte[] bArr = new byte[i7];
                                        dVar.f2008x.f1949x = bArr;
                                        pVar.readFully(bArr, 0, i7);
                                        return;
                                    }
                                    throw G.a(null, "Unexpected id: " + i6);
                                }
                                dVar.c(i6);
                                byte[] bArr2 = new byte[i7];
                                dVar.f2008x.f1938l = bArr2;
                                pVar.readFully(bArr2, 0, i7);
                                return;
                            }
                            Arrays.fill(vVar.f3120a, (byte) 0);
                            pVar.readFully(vVar.f3120a, 4 - i7, i7);
                            vVar.J(0);
                            dVar.f2009z = (int) vVar.z();
                            return;
                        }
                        byte[] bArr3 = new byte[i7];
                        pVar.readFully(bArr3, 0, i7);
                        dVar.c(i6);
                        dVar.f2008x.f1937k = new F(1, 0, 0, bArr3);
                        return;
                    }
                    dVar.c(i6);
                    byte[] bArr4 = new byte[i7];
                    dVar.f2008x.f1936j = bArr4;
                    pVar.readFully(bArr4, 0, i7);
                    return;
                }
                dVar.c(i6);
                P0.c cVar = dVar.f2008x;
                int i18 = cVar.f1934h;
                if (i18 != 1685485123 && i18 != 1685480259) {
                    pVar.q(i7);
                    return;
                }
                byte[] bArr5 = new byte[i7];
                cVar.f1916P = bArr5;
                pVar.readFully(bArr5, 0, i7);
                return;
            }
            if (dVar.f1966J == 2) {
                P0.c cVar2 = (P0.c) sparseArray.get(dVar.f1971P);
                int i19 = dVar.f1974S;
                v vVar3 = dVar.f2000p;
                if (i19 == 4 && "V_VP9".equals(cVar2.f1930c)) {
                    vVar3.G(i7);
                    pVar.readFully(vVar3.f3120a, 0, i7);
                    return;
                } else {
                    pVar.q(i7);
                    return;
                }
            }
            return;
        }
        if (dVar.f1966J == 0) {
            dVar.f1971P = (int) eVar.b(pVar, false, true, 8);
            dVar.f1972Q = eVar.f2013c;
            dVar.f1967L = -9223372036854775807L;
            dVar.f1966J = 1;
            vVar2.G(0);
        }
        P0.c cVar3 = (P0.c) sparseArray.get(dVar.f1971P);
        if (cVar3 == null) {
            pVar.q(i7 - dVar.f1972Q);
            dVar.f1966J = 0;
            return;
        }
        cVar3.f1926Z.getClass();
        if (dVar.f1966J == 1) {
            dVar.i(pVar, 3);
            int i20 = (vVar2.f3120a[2] & 6) >> 1;
            int i21 = 255;
            if (i20 == 0) {
                dVar.f1969N = 1;
                int[] iArr = dVar.f1970O;
                if (iArr == null) {
                    iArr = new int[1];
                } else if (iArr.length < 1) {
                    iArr = new int[Math.max(iArr.length * 2, 1)];
                }
                dVar.f1970O = iArr;
                iArr[0] = (i7 - dVar.f1972Q) - 3;
            } else {
                dVar.i(pVar, 4);
                int i22 = (vVar2.f3120a[3] & 255) + 1;
                dVar.f1969N = i22;
                int[] iArr2 = dVar.f1970O;
                if (iArr2 == null) {
                    iArr2 = new int[i22];
                } else if (iArr2.length < i22) {
                    iArr2 = new int[Math.max(iArr2.length * 2, i22)];
                }
                dVar.f1970O = iArr2;
                if (i20 == 2) {
                    int i23 = (i7 - dVar.f1972Q) - 4;
                    int i24 = dVar.f1969N;
                    Arrays.fill(iArr2, 0, i24, i23 / i24);
                } else if (i20 == 1) {
                    int i25 = 0;
                    int i26 = 0;
                    int i27 = 4;
                    while (true) {
                        i12 = dVar.f1969N - 1;
                        if (i25 >= i12) {
                            break;
                        }
                        dVar.f1970O[i25] = 0;
                        while (true) {
                            i13 = i27 + 1;
                            dVar.i(pVar, i13);
                            int i28 = vVar2.f3120a[i27] & 255;
                            int[] iArr3 = dVar.f1970O;
                            i14 = iArr3[i25] + i28;
                            iArr3[i25] = i14;
                            if (i28 != 255) {
                                break;
                            } else {
                                i27 = i13;
                            }
                        }
                        i26 += i14;
                        i25++;
                        i27 = i13;
                    }
                    dVar.f1970O[i12] = ((i7 - dVar.f1972Q) - i27) - i26;
                } else {
                    if (i20 == 3) {
                        int i29 = 0;
                        int i30 = 0;
                        int i31 = 4;
                        while (true) {
                            int i32 = dVar.f1969N - i16;
                            if (i29 < i32) {
                                dVar.f1970O[i29] = i17;
                                int i33 = i31 + 1;
                                dVar.i(pVar, i33);
                                if (vVar2.f3120a[i31] != 0) {
                                    int i34 = i16;
                                    int i35 = i17;
                                    while (true) {
                                        if (i35 < 8) {
                                            int i36 = i34 << (7 - i35);
                                            i10 = i17;
                                            if ((vVar2.f3120a[i31] & i36) != 0) {
                                                i11 = i33 + i35;
                                                dVar.i(pVar, i11);
                                                j6 = vVar2.f3120a[i31] & i21 & (~i36);
                                                while (i33 < i11) {
                                                    j6 = (j6 << 8) | (vVar2.f3120a[i33] & i21);
                                                    i33++;
                                                    i21 = 255;
                                                }
                                                if (i29 > 0) {
                                                    j6 -= (1 << ((i35 * 7) + 6)) - 1;
                                                }
                                            } else {
                                                i35++;
                                                i17 = i10;
                                                i21 = 255;
                                            }
                                        } else {
                                            i10 = i17;
                                            j6 = 0;
                                            i11 = i33;
                                            break;
                                        }
                                    }
                                    if (j6 < -2147483648L || j6 > 2147483647L) {
                                        break;
                                    }
                                    int i37 = (int) j6;
                                    int[] iArr4 = dVar.f1970O;
                                    if (i29 != 0) {
                                        i37 += iArr4[i29 - 1];
                                    }
                                    iArr4[i29] = i37;
                                    i30 += i37;
                                    i29++;
                                    i31 = i11;
                                    i16 = i34;
                                    i17 = i10;
                                    i21 = 255;
                                } else {
                                    throw G.a(null, "No valid varint length mask found");
                                }
                            } else {
                                i8 = i16;
                                i9 = i17;
                                dVar.f1970O[i32] = ((i7 - dVar.f1972Q) - i31) - i30;
                                break;
                            }
                        }
                        throw G.a(null, "EBML lacing sample size out of range.");
                    }
                    throw G.a(null, "Unexpected lacing value: " + i20);
                }
            }
            i8 = 1;
            i9 = 0;
            byte[] bArr6 = vVar2.f3120a;
            dVar.K = dVar.l((bArr6[i8] & ForkServer.ERROR) | (bArr6[i9] << 8)) + dVar.f1961E;
            if (cVar3.e != 2 && (i6 != 163 || (vVar2.f3120a[2] & 128) != 128)) {
                i15 = i9;
            } else {
                i15 = i8;
            }
            dVar.f1973R = i15;
            dVar.f1966J = 2;
            dVar.f1968M = i9;
        } else {
            i8 = 1;
        }
        if (i6 == 163) {
            while (true) {
                int i38 = dVar.f1968M;
                if (i38 < dVar.f1969N) {
                    dVar.d(cVar3, ((dVar.f1968M * cVar3.f1932f) / PipesIterator.DEFAULT_QUEUE_SIZE) + dVar.K, dVar.f1973R, dVar.m(pVar, cVar3, dVar.f1970O[i38], false), 0);
                    dVar.f1968M++;
                } else {
                    dVar.f1966J = 0;
                    return;
                }
            }
        } else {
            while (true) {
                int i39 = dVar.f1968M;
                if (i39 < dVar.f1969N) {
                    int[] iArr5 = dVar.f1970O;
                    boolean z6 = i8;
                    iArr5[i39] = dVar.m(pVar, cVar3, iArr5[i39], z6);
                    dVar.f1968M += z6 ? 1 : 0;
                } else {
                    return;
                }
            }
        }
    }

    /* JADX WARN: Can't fix incorrect switch cases order, some code will duplicate */
    @Override // M4.n
    public void onMethodCall(m mVar, o oVar) {
        String str;
        char c6;
        ByteBuffer byteBuffer;
        Object obj;
        char c7;
        Bundle bundle;
        boolean z6 = false;
        int i6 = 3;
        int i7 = 4;
        int i8 = 1;
        int i9 = 8;
        switch (this.o) {
            case 12:
                A.c cVar = (A.c) this.f10281p;
                if (((A1.l) cVar.f5q) != null) {
                    if (!mVar.f1733a.equals("Localization.getStringResource")) {
                        ((j) oVar).c();
                        return;
                    }
                    JSONObject jSONObject = (JSONObject) mVar.f1734b;
                    try {
                        String string = jSONObject.getString(ExternalParsersConfigReaderMetKeys.METADATA_KEY_ATTR);
                        if (jSONObject.has("locale")) {
                            str = jSONObject.getString("locale");
                        } else {
                            str = null;
                        }
                        ((j) oVar).b(((A1.l) cVar.f5q).m(string, str));
                        return;
                    } catch (JSONException e) {
                        ((j) oVar).d("error", e.getMessage(), null);
                        return;
                    }
                }
                return;
            case 13:
            default:
                A.c cVar2 = (A.c) this.f10281p;
                io.flutter.plugin.editing.j jVar = (io.flutter.plugin.editing.j) cVar2.f5q;
                if (jVar != null) {
                    String str2 = mVar.f1733a;
                    Object obj2 = mVar.f1734b;
                    switch (str2.hashCode()) {
                        case -1779068172:
                            if (str2.equals("TextInput.setPlatformViewClient")) {
                                c7 = 0;
                                break;
                            }
                            c7 = 65535;
                            break;
                        case -1015421462:
                            if (str2.equals("TextInput.setEditingState")) {
                                c7 = 1;
                                break;
                            }
                            c7 = 65535;
                            break;
                        case -37561188:
                            if (str2.equals("TextInput.setClient")) {
                                c7 = 2;
                                break;
                            }
                            c7 = 65535;
                            break;
                        case 270476819:
                            if (str2.equals("TextInput.hide")) {
                                c7 = 3;
                                break;
                            }
                            c7 = 65535;
                            break;
                        case 270803918:
                            if (str2.equals("TextInput.show")) {
                                c7 = 4;
                                break;
                            }
                            c7 = 65535;
                            break;
                        case 649192816:
                            if (str2.equals("TextInput.sendAppPrivateCommand")) {
                                c7 = 5;
                                break;
                            }
                            c7 = 65535;
                            break;
                        case 1204752139:
                            if (str2.equals("TextInput.setEditableSizeAndTransform")) {
                                c7 = 6;
                                break;
                            }
                            c7 = 65535;
                            break;
                        case 1727570905:
                            if (str2.equals("TextInput.finishAutofillContext")) {
                                c7 = 7;
                                break;
                            }
                            c7 = 65535;
                            break;
                        case 1904427655:
                            if (str2.equals("TextInput.clearClient")) {
                                c7 = '\b';
                                break;
                            }
                            c7 = 65535;
                            break;
                        case 2113369584:
                            if (str2.equals("TextInput.requestAutofill")) {
                                c7 = '\t';
                                break;
                            }
                            c7 = 65535;
                            break;
                        default:
                            c7 = 65535;
                            break;
                    }
                    switch (c7) {
                        case 0:
                            try {
                                JSONObject jSONObject2 = (JSONObject) obj2;
                                int i10 = jSONObject2.getInt("platformViewId");
                                boolean optBoolean = jSONObject2.optBoolean("usesVirtualDisplay", false);
                                io.flutter.plugin.editing.k kVar = (io.flutter.plugin.editing.k) ((io.flutter.plugin.editing.j) cVar2.f5q).f7159a;
                                View view = kVar.f7160a;
                                if (optBoolean) {
                                    view.requestFocus();
                                    kVar.e = new C0044i(i6, i10, i9);
                                    kVar.f7161b.restartInput(view);
                                    kVar.f7167i = false;
                                } else {
                                    kVar.e = new C0044i(i7, i10, i9);
                                    kVar.f7168j = null;
                                }
                                ((j) oVar).b(null);
                                return;
                            } catch (JSONException e6) {
                                ((j) oVar).d("error", e6.getMessage(), null);
                                return;
                            }
                        case 1:
                            try {
                                jVar.j(L4.p.a((JSONObject) obj2));
                                ((j) oVar).b(null);
                                return;
                            } catch (JSONException e7) {
                                ((j) oVar).d("error", e7.getMessage(), null);
                                return;
                            }
                        case 2:
                            try {
                                JSONArray jSONArray = (JSONArray) obj2;
                                ((io.flutter.plugin.editing.j) cVar2.f5q).h(jSONArray.getInt(0), L4.n.a(jSONArray.getJSONObject(1)));
                                ((j) oVar).b(null);
                                return;
                            } catch (NoSuchFieldException | JSONException e8) {
                                ((j) oVar).d("error", e8.getMessage(), null);
                                return;
                            }
                        case 3:
                            io.flutter.plugin.editing.k kVar2 = (io.flutter.plugin.editing.k) jVar.f7159a;
                            if (kVar2.e.f569b == 4) {
                                kVar2.f();
                            } else {
                                View view2 = kVar2.f7160a;
                                kVar2.f();
                                kVar2.f7161b.hideSoftInputFromWindow(view2.getApplicationWindowToken(), 0);
                            }
                            ((j) oVar).b(null);
                            return;
                        case 4:
                            io.flutter.plugin.editing.k kVar3 = (io.flutter.plugin.editing.k) jVar.f7159a;
                            InputMethodManager inputMethodManager = kVar3.f7161b;
                            View view3 = kVar3.f7160a;
                            L4.n nVar = kVar3.f7164f;
                            if (nVar != null && nVar.f1677g.f1684a == 11) {
                                kVar3.f();
                                inputMethodManager.hideSoftInputFromWindow(view3.getApplicationWindowToken(), 0);
                            } else {
                                view3.requestFocus();
                                inputMethodManager.showSoftInput(view3, 0);
                            }
                            ((j) oVar).b(null);
                            return;
                        case 5:
                            try {
                                JSONObject jSONObject3 = (JSONObject) obj2;
                                String string2 = jSONObject3.getString("action");
                                String string3 = jSONObject3.getString("data");
                                if (string3 != null && !string3.isEmpty()) {
                                    bundle = new Bundle();
                                    bundle.putString("data", string3);
                                } else {
                                    bundle = null;
                                }
                                io.flutter.plugin.editing.k kVar4 = (io.flutter.plugin.editing.k) ((io.flutter.plugin.editing.j) cVar2.f5q).f7159a;
                                kVar4.f7161b.sendAppPrivateCommand(kVar4.f7160a, string2, bundle);
                                ((j) oVar).b(null);
                                return;
                            } catch (JSONException e9) {
                                ((j) oVar).d("error", e9.getMessage(), null);
                                return;
                            }
                        case 6:
                            try {
                                JSONObject jSONObject4 = (JSONObject) obj2;
                                double d6 = jSONObject4.getDouble("width");
                                double d7 = jSONObject4.getDouble("height");
                                JSONArray jSONArray2 = jSONObject4.getJSONArray("transform");
                                double[] dArr = new double[16];
                                for (int i11 = 0; i11 < 16; i11++) {
                                    dArr[i11] = jSONArray2.getDouble(i11);
                                }
                                ((io.flutter.plugin.editing.j) cVar2.f5q).i(d6, d7, dArr);
                                ((j) oVar).b(null);
                                return;
                            } catch (JSONException e10) {
                                ((j) oVar).d("error", e10.getMessage(), null);
                                return;
                            }
                        case 7:
                            jVar.c(((Boolean) obj2).booleanValue());
                            ((j) oVar).b(null);
                            return;
                        case '\b':
                            io.flutter.plugin.editing.k kVar5 = (io.flutter.plugin.editing.k) jVar.f7159a;
                            View view4 = kVar5.f7160a;
                            if (kVar5.e.f569b != 3) {
                                kVar5.f7166h.e(kVar5);
                                kVar5.f();
                                kVar5.f7164f = null;
                                kVar5.g(null);
                                kVar5.e = new C0044i(i8, z6 ? 1 : 0, i9);
                                kVar5.f7171m = null;
                                Field field = w.f577a;
                                P a6 = D.r.a(view4);
                                if (a6 != null && !a6.f548a.m(8)) {
                                    kVar5.f7161b.restartInput(view4);
                                }
                            }
                            ((j) oVar).b(null);
                            return;
                        case ContentHandlerProxy.PROCESSING_INSTRUCTION /* 9 */:
                            io.flutter.plugin.editing.k.b((io.flutter.plugin.editing.k) jVar.f7159a);
                            ((j) oVar).b(null);
                            return;
                        default:
                            ((j) oVar).c();
                            return;
                    }
                }
                return;
            case 14:
                r(mVar, oVar);
                return;
            case 15:
                A.c cVar3 = (A.c) this.f10281p;
                io.flutter.plugin.platform.o oVar2 = (io.flutter.plugin.platform.o) cVar3.f5q;
                if (oVar2 != null) {
                    String str3 = mVar.f1733a;
                    Object obj3 = mVar.f1734b;
                    switch (str3.hashCode()) {
                        case -1352294148:
                            if (str3.equals("create")) {
                                c6 = 0;
                                break;
                            }
                            c6 = 65535;
                            break;
                        case -756050293:
                            if (str3.equals("clearFocus")) {
                                c6 = 1;
                                break;
                            }
                            c6 = 65535;
                            break;
                        case 110550847:
                            if (str3.equals("touch")) {
                                c6 = 2;
                                break;
                            }
                            c6 = 65535;
                            break;
                        case 576796989:
                            if (str3.equals("setDirection")) {
                                c6 = 3;
                                break;
                            }
                            c6 = 65535;
                            break;
                        case 751366695:
                            if (str3.equals("isSurfaceControlEnabled")) {
                                c6 = 4;
                                break;
                            }
                            c6 = 65535;
                            break;
                        case 1671767583:
                            if (str3.equals("dispose")) {
                                c6 = 5;
                                break;
                            }
                            c6 = 65535;
                            break;
                        default:
                            c6 = 65535;
                            break;
                    }
                    switch (c6) {
                        case 0:
                            Map map = (Map) obj3;
                            if (map.containsKey("params")) {
                                byteBuffer = ByteBuffer.wrap((byte[]) map.get("params"));
                            } else {
                                byteBuffer = null;
                            }
                            try {
                                int intValue = ((Integer) map.get("id")).intValue();
                                String str4 = (String) map.get("viewType");
                                int intValue2 = ((Integer) map.get("direction")).intValue();
                                io.flutter.plugin.platform.p pVar = (io.flutter.plugin.platform.p) ((io.flutter.plugin.platform.o) cVar3.f5q).f7214p;
                                A4.e eVar = (A4.e) ((HashMap) pVar.o.f7214p).get(str4);
                                if (eVar != null) {
                                    if (byteBuffer != null) {
                                        obj = eVar.f87a.b(byteBuffer);
                                    } else {
                                        obj = null;
                                    }
                                    io.flutter.plugin.platform.h a7 = eVar.a(pVar.f7220q, intValue, obj);
                                    View view5 = a7.getView();
                                    if (view5 != null) {
                                        view5.setLayoutDirection(intValue2);
                                        pVar.f7226w.put(intValue, a7);
                                        ((j) oVar).b(null);
                                        return;
                                    }
                                    throw new IllegalStateException("PlatformView#getView() returned null, but an Android view reference was expected.");
                                }
                                throw new IllegalStateException("Trying to create a platform view of unregistered type: " + str4);
                            } catch (IllegalStateException e11) {
                                ((j) oVar).d("error", Log.getStackTraceString(e11), null);
                                return;
                            }
                        case 1:
                            try {
                                ((io.flutter.plugin.platform.o) cVar3.f5q).s(((Integer) obj3).intValue());
                                ((j) oVar).b(null);
                                return;
                            } catch (IllegalStateException e12) {
                                ((j) oVar).d("error", Log.getStackTraceString(e12), null);
                                return;
                            }
                        case 2:
                            List list = (List) obj3;
                            try {
                                ((io.flutter.plugin.platform.o) cVar3.f5q).x(new L4.g(((Integer) list.get(0)).intValue(), (Number) list.get(1), (Number) list.get(2), ((Integer) list.get(3)).intValue(), ((Integer) list.get(4)).intValue(), list.get(5), list.get(6), ((Integer) list.get(7)).intValue(), ((Integer) list.get(8)).intValue(), (float) ((Double) list.get(9)).doubleValue(), (float) ((Double) list.get(10)).doubleValue(), ((Integer) list.get(11)).intValue(), ((Integer) list.get(12)).intValue(), ((Integer) list.get(13)).intValue(), ((Integer) list.get(14)).intValue(), ((Number) list.get(15)).longValue()));
                                ((j) oVar).b(null);
                                return;
                            } catch (IllegalStateException e13) {
                                ((j) oVar).d("error", Log.getStackTraceString(e13), null);
                                return;
                            }
                        case 3:
                            Map map2 = (Map) obj3;
                            try {
                                ((io.flutter.plugin.platform.o) cVar3.f5q).i(((Integer) map2.get("id")).intValue(), ((Integer) map2.get("direction")).intValue());
                                ((j) oVar).b(null);
                                return;
                            } catch (IllegalStateException e14) {
                                ((j) oVar).d("error", Log.getStackTraceString(e14), null);
                                return;
                            }
                        case 4:
                            FlutterJNI flutterJNI = ((io.flutter.plugin.platform.p) oVar2.f7214p).f7222s;
                            if (flutterJNI != null) {
                                z6 = flutterJNI.IsSurfaceControlEnabled();
                            }
                            ((j) oVar).b(Boolean.valueOf(z6));
                            return;
                        case 5:
                            try {
                                ((io.flutter.plugin.platform.o) cVar3.f5q).A(((Integer) ((Map) obj3).get("id")).intValue());
                                ((j) oVar).b(null);
                                return;
                            } catch (IllegalStateException e15) {
                                ((j) oVar).d("error", Log.getStackTraceString(e15), null);
                                return;
                            }
                        default:
                            ((j) oVar).c();
                            return;
                    }
                }
                return;
            case 16:
                L4.k kVar6 = (L4.k) this.f10281p;
                String str5 = mVar.f1733a;
                Object obj4 = mVar.f1734b;
                if (!str5.equals("get")) {
                    if (!str5.equals("put")) {
                        ((j) oVar).c();
                        return;
                    } else {
                        kVar6.f1663b = (byte[]) obj4;
                        ((j) oVar).b(null);
                        return;
                    }
                }
                kVar6.f1666f = true;
                if (!kVar6.e && kVar6.f1662a) {
                    kVar6.f1665d = (j) oVar;
                    return;
                } else {
                    ((j) oVar).b(L4.k.a(kVar6.f1663b));
                    return;
                }
        }
    }

    public Z p() {
        A5.r rVar = (A5.r) this.f10281p;
        rVar.getClass();
        Object obj = A5.r.f150s.get(rVar);
        if (obj == B5.j.f236a) {
            obj = null;
        }
        return (Z) obj;
    }

    public void q(long j6, int i6) {
        P0.d dVar = (P0.d) this.f10281p;
        if (i6 != 20529) {
            if (i6 != 20530) {
                boolean z6 = false;
                switch (i6) {
                    case 131:
                        dVar.c(i6);
                        dVar.f2008x.e = (int) j6;
                        return;
                    case 136:
                        dVar.c(i6);
                        P0.c cVar = dVar.f2008x;
                        if (j6 == 1) {
                            z6 = true;
                        }
                        cVar.f1924X = z6;
                        return;
                    case 155:
                        dVar.f1967L = dVar.l(j6);
                        return;
                    case 159:
                        dVar.c(i6);
                        dVar.f2008x.f1917Q = (int) j6;
                        return;
                    case 176:
                        dVar.c(i6);
                        dVar.f2008x.f1940n = (int) j6;
                        return;
                    case 179:
                        dVar.b(i6);
                        dVar.f1962F.b(dVar.l(j6));
                        return;
                    case 186:
                        dVar.c(i6);
                        dVar.f2008x.o = (int) j6;
                        return;
                    case 215:
                        dVar.c(i6);
                        dVar.f2008x.f1931d = (int) j6;
                        return;
                    case 231:
                        dVar.f1961E = dVar.l(j6);
                        return;
                    case 238:
                        dVar.f1974S = (int) j6;
                        return;
                    case 241:
                        if (!dVar.f1964H) {
                            dVar.b(i6);
                            dVar.f1963G.b(j6);
                            dVar.f1964H = true;
                            return;
                        }
                        return;
                    case 251:
                        dVar.f1975T = true;
                        return;
                    case 16871:
                        dVar.c(i6);
                        dVar.f2008x.f1934h = (int) j6;
                        return;
                    case 16980:
                        if (j6 != 3) {
                            throw G.a(null, "ContentCompAlgo " + j6 + " not supported");
                        }
                        return;
                    case 17029:
                        if (j6 < 1 || j6 > 2) {
                            throw G.a(null, "DocTypeReadVersion " + j6 + " not supported");
                        }
                        return;
                    case 17143:
                        if (j6 != 1) {
                            throw G.a(null, "EBMLReadVersion " + j6 + " not supported");
                        }
                        return;
                    case 18401:
                        if (j6 != 5) {
                            throw G.a(null, "ContentEncAlgo " + j6 + " not supported");
                        }
                        return;
                    case 18408:
                        if (j6 != 1) {
                            throw G.a(null, "AESSettingsCipherMode " + j6 + " not supported");
                        }
                        return;
                    case 21420:
                        dVar.f1957A = j6 + dVar.f2003s;
                        return;
                    case 21432:
                        int i7 = (int) j6;
                        dVar.c(i6);
                        if (i7 != 0) {
                            if (i7 != 1) {
                                if (i7 != 3) {
                                    if (i7 == 15) {
                                        dVar.f2008x.y = 3;
                                        return;
                                    }
                                    return;
                                }
                                dVar.f2008x.y = 1;
                                return;
                            }
                            dVar.f2008x.y = 2;
                            return;
                        }
                        dVar.f2008x.y = 0;
                        return;
                    case 21680:
                        dVar.c(i6);
                        dVar.f2008x.f1942q = (int) j6;
                        return;
                    case 21682:
                        dVar.c(i6);
                        dVar.f2008x.f1944s = (int) j6;
                        return;
                    case 21690:
                        dVar.c(i6);
                        dVar.f2008x.f1943r = (int) j6;
                        return;
                    case 21930:
                        dVar.c(i6);
                        P0.c cVar2 = dVar.f2008x;
                        if (j6 == 1) {
                            z6 = true;
                        }
                        cVar2.f1923W = z6;
                        return;
                    case 21938:
                        dVar.c(i6);
                        P0.c cVar3 = dVar.f2008x;
                        cVar3.f1950z = true;
                        cVar3.f1941p = (int) j6;
                        return;
                    case 21998:
                        dVar.c(i6);
                        dVar.f2008x.f1933g = (int) j6;
                        return;
                    case 22186:
                        dVar.c(i6);
                        dVar.f2008x.f1920T = j6;
                        return;
                    case 22203:
                        dVar.c(i6);
                        dVar.f2008x.f1921U = j6;
                        return;
                    case 25188:
                        dVar.c(i6);
                        dVar.f2008x.f1918R = (int) j6;
                        return;
                    case 30114:
                        dVar.f1976U = j6;
                        return;
                    case 30321:
                        dVar.c(i6);
                        int i8 = (int) j6;
                        if (i8 != 0) {
                            if (i8 != 1) {
                                if (i8 != 2) {
                                    if (i8 == 3) {
                                        dVar.f2008x.f1945t = 3;
                                        return;
                                    }
                                    return;
                                }
                                dVar.f2008x.f1945t = 2;
                                return;
                            }
                            dVar.f2008x.f1945t = 1;
                            return;
                        }
                        dVar.f2008x.f1945t = 0;
                        return;
                    case 2352003:
                        dVar.c(i6);
                        dVar.f2008x.f1932f = (int) j6;
                        return;
                    case 2807729:
                        dVar.f2004t = j6;
                        return;
                    default:
                        switch (i6) {
                            case 21945:
                                dVar.c(i6);
                                int i9 = (int) j6;
                                if (i9 != 1) {
                                    if (i9 == 2) {
                                        dVar.f2008x.f1904C = 1;
                                        return;
                                    }
                                    return;
                                }
                                dVar.f2008x.f1904C = 2;
                                return;
                            case 21946:
                                dVar.c(i6);
                                int g2 = C0115h.g((int) j6);
                                if (g2 != -1) {
                                    dVar.f2008x.f1903B = g2;
                                    return;
                                }
                                return;
                            case 21947:
                                dVar.c(i6);
                                dVar.f2008x.f1950z = true;
                                int f6 = C0115h.f((int) j6);
                                if (f6 != -1) {
                                    dVar.f2008x.f1902A = f6;
                                    return;
                                }
                                return;
                            case 21948:
                                dVar.c(i6);
                                dVar.f2008x.f1905D = (int) j6;
                                return;
                            case 21949:
                                dVar.c(i6);
                                dVar.f2008x.f1906E = (int) j6;
                                return;
                            default:
                                return;
                        }
                }
            }
            if (j6 != 1) {
                throw G.a(null, "ContentEncodingScope " + j6 + " not supported");
            }
            return;
        }
        if (j6 == 0) {
            return;
        }
        throw G.a(null, "ContentEncodingOrder " + j6 + " not supported");
    }

    /* JADX WARN: Code restructure failed: missing block: B:12:0x0031, code lost:
    
        if (r7.f1191a > r3.f1191a) goto L16;
     */
    /* JADX WARN: Removed duplicated region for block: B:14:0x003b  */
    /* JADX WARN: Removed duplicated region for block: B:16:0x003f  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public void s(Z z6) {
        Object obj;
        Object obj2;
        boolean a6;
        q5.h.e(z6, "newState");
        A5.r rVar = (A5.r) this.f10281p;
        do {
            rVar.getClass();
            Object obj3 = A5.r.f150s.get(rVar);
            obj = B5.j.f236a;
            obj2 = obj3;
            if (obj3 == obj) {
                obj2 = null;
            }
            Z z7 = (Z) obj2;
            if (z7 instanceof S) {
                a6 = true;
            } else {
                a6 = q5.h.a(z7, a0.f1192b);
            }
            if (!a6) {
                if (!(z7 instanceof C0083c)) {
                    if (!(z7 instanceof J.P)) {
                        throw new RuntimeException();
                    }
                }
                if (obj2 == null) {
                    obj2 = obj;
                }
                if (z7 != null) {
                    obj = z7;
                }
            }
            z7 = z6;
            if (obj2 == null) {
            }
            if (z7 != null) {
            }
        } while (!rVar.a(obj2, obj));
    }

    public c(E4.b bVar, int i6) {
        this.o = i6;
        switch (i6) {
            case PipesServer.TIMEOUT_EXIT_CODE /* 17 */:
                new M4.p(bVar, "flutter/scribe", k.f1732a, null).b(new A1.l(this, 16));
                return;
            case 18:
                new M4.p(bVar, "flutter/sensitivecontent", M4.w.f1742b, null).b(new A1.l(this, 17));
                return;
            case 19:
                new M4.p(bVar, "flutter/spellcheck", M4.w.f1742b, null).b(new A1.l(this, 18));
                return;
            default:
                new M4.p(bVar, "flutter/mousecursor", M4.w.f1742b, null).b(new A1.l(this, 12));
                return;
        }
    }

    public c(int i6) {
        this.o = i6;
        switch (i6) {
            case 8:
                this.f10281p = new AtomicInteger(0);
                return;
            case ContentHandlerProxy.PROCESSING_INSTRUCTION /* 9 */:
                this.f10281p = new A5.r(a0.f1192b);
                return;
            case 24:
                return;
            default:
                this.f10281p = new HashSet();
                return;
        }
    }

    public c(f fVar) {
        this.o = 11;
        this.f10281p = new u(fVar, "flutter/keyevent", M4.j.f1731a, (C0508g) null);
    }

    public c(C0112e c0112e) {
        this.o = 26;
        AudioAttributes.Builder usage = new AudioAttributes.Builder().setContentType(c0112e.f2538a).setFlags(0).setUsage(1);
        int i6 = Build.VERSION.SDK_INT;
        if (i6 >= 29) {
            AbstractC0110c.i(usage);
        }
        if (i6 >= 32) {
            AbstractC0111d.b(usage);
            AbstractC0111d.a(usage);
        }
        this.f10281p = usage.build();
    }

    /* JADX WARN: Multi-variable type inference failed */
    public c(p pVar) {
        this.o = 1;
        this.f10281p = (AbstractC0567h) pVar;
    }
}
