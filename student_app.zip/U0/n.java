package U0;

import V.AbstractC0133a;
import V.v;
import a0.C0195a;
import java.util.HashMap;
import p0.C0678A;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* loaded from: classes.dex */
public final /* synthetic */ class n implements V.g, V.l {
    public final /* synthetic */ int o;

    /* renamed from: p, reason: collision with root package name */
    public final /* synthetic */ long f2966p;

    /* renamed from: q, reason: collision with root package name */
    public final /* synthetic */ Object f2967q;

    public /* synthetic */ n(o oVar, long j6, int i6) {
        this.f2967q = oVar;
        this.f2966p = j6;
        this.o = i6;
    }

    @Override // V.l
    public void a(Object obj) {
        long longValue;
        C0195a c0195a = (C0195a) this.f2967q;
        a0.i iVar = (a0.i) ((a0.b) obj);
        HashMap hashMap = iVar.f4370h;
        HashMap hashMap2 = iVar.f4371i;
        C0678A c0678a = c0195a.f4334d;
        if (c0678a != null) {
            String c6 = iVar.f4366c.c(c0195a.f4332b, c0678a);
            Long l6 = (Long) hashMap2.get(c6);
            Long l7 = (Long) hashMap.get(c6);
            long j6 = 0;
            if (l6 == null) {
                longValue = 0;
            } else {
                longValue = l6.longValue();
            }
            hashMap2.put(c6, Long.valueOf(longValue + this.f2966p));
            if (l7 != null) {
                j6 = l7.longValue();
            }
            hashMap.put(c6, Long.valueOf(j6 + this.o));
        }
    }

    @Override // V.g
    public void accept(Object obj) {
        o oVar = (o) this.f2967q;
        a aVar = (a) obj;
        AbstractC0133a.j(oVar.f2974h);
        byte[] n6 = m3.e.n(aVar.f2940c, aVar.f2938a);
        v vVar = oVar.f2970c;
        vVar.getClass();
        vVar.H(n6, n6.length);
        boolean z6 = false;
        oVar.f2968a.d(vVar, n6.length, 0);
        long j6 = aVar.f2939b;
        long j7 = this.f2966p;
        if (j6 == -9223372036854775807L) {
            if (oVar.f2974h.f2630s == Long.MAX_VALUE) {
                z6 = true;
            }
            AbstractC0133a.i(z6);
        } else {
            long j8 = oVar.f2974h.f2630s;
            if (j8 == Long.MAX_VALUE) {
                j7 += j6;
            } else {
                j7 = j6 + j8;
            }
        }
        oVar.f2968a.c(j7, this.o | 1, n6.length, 0, null);
    }

    public /* synthetic */ n(C0195a c0195a, int i6, long j6, long j7) {
        this.f2967q = c0195a;
        this.o = i6;
        this.f2966p = j6;
    }
}
