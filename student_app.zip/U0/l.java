package U0;

import E2.F;
import E2.I;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* loaded from: classes.dex */
public interface l {
    void j(byte[] bArr, int i6, int i7, k kVar, V.g gVar);

    default d q(byte[] bArr, int i6, int i7) {
        F t6 = I.t();
        j(bArr, 0, i7, k.f2960c, new B3.h(t6, 10));
        return new b(t6.f());
    }

    int z();

    default void reset() {
    }
}
