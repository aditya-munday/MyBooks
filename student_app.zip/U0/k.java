package U0;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* loaded from: classes.dex */
public final class k {

    /* renamed from: c, reason: collision with root package name */
    public static final k f2960c = new k(-9223372036854775807L, false);

    /* renamed from: a, reason: collision with root package name */
    public final long f2961a;

    /* renamed from: b, reason: collision with root package name */
    public final boolean f2962b;

    public k(long j6, boolean z6) {
        this.f2961a = j6;
        this.f2962b = z6;
    }
}
