package U0;

import S.C0122o;
import S.C0123p;
import S.F;
import S.r;
import V.AbstractC0133a;
import V.C;
import V.v;
import java.util.ArrayList;
import java.util.Arrays;
import x0.G;
import x0.p;
import x0.q;
import x0.x;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* loaded from: classes.dex */
public final class h implements x0.o {

    /* renamed from: a, reason: collision with root package name */
    public final l f2949a;

    /* renamed from: b, reason: collision with root package name */
    public final C0123p f2950b;

    /* renamed from: c, reason: collision with root package name */
    public final ArrayList f2951c;

    /* renamed from: f, reason: collision with root package name */
    public G f2953f;

    /* renamed from: g, reason: collision with root package name */
    public int f2954g;

    /* renamed from: h, reason: collision with root package name */
    public int f2955h;

    /* renamed from: i, reason: collision with root package name */
    public long[] f2956i;

    /* renamed from: j, reason: collision with root package name */
    public long f2957j;
    public byte[] e = C.f3054b;

    /* renamed from: d, reason: collision with root package name */
    public final v f2952d = new v();

    public h(l lVar, C0123p c0123p) {
        C0123p c0123p2;
        this.f2949a = lVar;
        if (c0123p != null) {
            C0122o a6 = c0123p.a();
            a6.f2587m = F.n("application/x-media3-cues");
            a6.f2584j = c0123p.f2626n;
            a6.K = lVar.z();
            c0123p2 = new C0123p(a6);
        } else {
            c0123p2 = null;
        }
        this.f2950b = c0123p2;
        this.f2951c = new ArrayList();
        this.f2955h = 0;
        this.f2956i = C.f3055c;
        this.f2957j = -9223372036854775807L;
    }

    @Override // x0.o
    public final void a(long j6, long j7) {
        boolean z6;
        int i6 = this.f2955h;
        if (i6 != 0 && i6 != 5) {
            z6 = true;
        } else {
            z6 = false;
        }
        AbstractC0133a.i(z6);
        this.f2957j = j7;
        if (this.f2955h == 2) {
            this.f2955h = 1;
        }
        if (this.f2955h == 4) {
            this.f2955h = 3;
        }
    }

    public final void b(g gVar) {
        AbstractC0133a.j(this.f2953f);
        byte[] bArr = gVar.f2948p;
        int length = bArr.length;
        v vVar = this.f2952d;
        vVar.getClass();
        vVar.H(bArr, bArr.length);
        this.f2953f.d(vVar, length, 0);
        this.f2953f.c(gVar.o, 1, length, 0, null);
    }

    @Override // x0.o
    public final boolean f(p pVar) {
        return true;
    }

    /* JADX WARN: Code restructure failed: missing block: B:27:0x0077, code lost:
    
        if (r20.f2954g != r14) goto L32;
     */
    /* JADX WARN: Code restructure failed: missing block: B:28:0x007c, code lost:
    
        if (r2 == (-1)) goto L68;
     */
    /* JADX WARN: Code restructure failed: missing block: B:52:0x007e, code lost:
    
        r4 = r20.f2957j;
     */
    /* JADX WARN: Code restructure failed: missing block: B:53:0x0082, code lost:
    
        if (r4 == (-9223372036854775807L)) goto L37;
     */
    /* JADX WARN: Code restructure failed: missing block: B:54:0x0084, code lost:
    
        r2 = new U0.k(r4, true);
     */
    /* JADX WARN: Code restructure failed: missing block: B:56:0x008f, code lost:
    
        r20.f2949a.j(r20.e, 0, r20.f2954g, r2, new B3.h(r20, 9));
        java.util.Collections.sort(r11);
        r20.f2956i = new long[r11.size()];
        r2 = r22;
     */
    /* JADX WARN: Code restructure failed: missing block: B:58:0x00b6, code lost:
    
        if (r2 >= r11.size()) goto L72;
     */
    /* JADX WARN: Code restructure failed: missing block: B:59:0x00b8, code lost:
    
        r20.f2956i[r2] = ((U0.g) r11.get(r2)).o;
        r2 = r2 + 1;
     */
    /* JADX WARN: Code restructure failed: missing block: B:61:0x00c9, code lost:
    
        r20.e = V.C.f3054b;
     */
    /* JADX WARN: Code restructure failed: missing block: B:62:0x00cd, code lost:
    
        r20.f2955h = 4;
     */
    /* JADX WARN: Code restructure failed: missing block: B:64:0x008c, code lost:
    
        r2 = U0.k.f2960c;
     */
    /* JADX WARN: Code restructure failed: missing block: B:65:0x00c7, code lost:
    
        r0 = move-exception;
     */
    /* JADX WARN: Code restructure failed: missing block: B:68:0x00d6, code lost:
    
        throw S.G.a(r0, "SubtitleParser failed.");
     */
    @Override // x0.o
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final int h(p pVar, r rVar) {
        boolean z6;
        int i6;
        int e;
        int i7;
        int i8 = this.f2955h;
        if (i8 != 0 && i8 != 5) {
            z6 = true;
        } else {
            z6 = false;
        }
        AbstractC0133a.i(z6);
        int i9 = 1024;
        if (this.f2955h == 1) {
            if (pVar.getLength() != -1) {
                i7 = Q5.a.j(pVar.getLength());
            } else {
                i7 = 1024;
            }
            if (i7 > this.e.length) {
                this.e = new byte[i7];
            }
            this.f2954g = 0;
            this.f2955h = 2;
        }
        int i10 = this.f2955h;
        ArrayList arrayList = this.f2951c;
        if (i10 == 2) {
            byte[] bArr = this.e;
            if (bArr.length == this.f2954g) {
                this.e = Arrays.copyOf(bArr, bArr.length + 1024);
            }
            byte[] bArr2 = this.e;
            int i11 = this.f2954g;
            int read = pVar.read(bArr2, i11, bArr2.length - i11);
            if (read != -1) {
                this.f2954g += read;
            }
            long length = pVar.getLength();
            if (length != -1) {
                i6 = 0;
            } else {
                i6 = 0;
            }
        } else {
            i6 = 0;
        }
        if (this.f2955h == 3) {
            if (pVar.getLength() != -1) {
                i9 = Q5.a.j(pVar.getLength());
            }
            if (pVar.d(i9) == -1) {
                long j6 = this.f2957j;
                if (j6 == -9223372036854775807L) {
                    e = i6;
                } else {
                    e = C.e(this.f2956i, j6, true);
                }
                while (e < arrayList.size()) {
                    b((g) arrayList.get(e));
                    e++;
                }
                this.f2955h = 4;
            }
        }
        if (this.f2955h == 4) {
            return -1;
        }
        return i6;
    }

    @Override // x0.o
    public final void k(q qVar) {
        boolean z6;
        if (this.f2955h == 0) {
            z6 = true;
        } else {
            z6 = false;
        }
        AbstractC0133a.i(z6);
        G w6 = qVar.w(0, 3);
        this.f2953f = w6;
        C0123p c0123p = this.f2950b;
        if (c0123p != null) {
            w6.b(c0123p);
            qVar.g();
            qVar.o(new x(-9223372036854775807L, new long[]{0}, new long[]{0}));
        }
        this.f2955h = 1;
    }

    @Override // x0.o
    public final void release() {
        if (this.f2955h == 5) {
            return;
        }
        this.f2949a.reset();
        this.f2955h = 5;
    }
}
