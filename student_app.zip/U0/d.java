package U0;

import java.util.List;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* loaded from: classes.dex */
public interface d {
    int a(long j6);

    long e(int i6);

    List q(long j6);

    int w();
}
