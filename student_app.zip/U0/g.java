package U0;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* loaded from: classes.dex */
public final class g implements Comparable {
    public final long o;

    /* renamed from: p, reason: collision with root package name */
    public final byte[] f2948p;

    public g(long j6, byte[] bArr) {
        this.o = j6;
        this.f2948p = bArr;
    }

    @Override // java.lang.Comparable
    public final int compareTo(Object obj) {
        return Long.compare(this.o, ((g) obj).o);
    }
}
