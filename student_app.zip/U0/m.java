package U0;

import V.x;
import V.z;
import Z.B;
import Z.C0169a;
import android.content.Context;
import android.os.Looper;
import android.util.SparseArray;
import x0.G;
import x0.InterfaceC0878A;
import x0.q;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* loaded from: classes.dex */
public final class m implements q {
    public boolean o;

    /* renamed from: p, reason: collision with root package name */
    public final Object f2963p;

    /* renamed from: q, reason: collision with root package name */
    public final Object f2964q;

    /* renamed from: r, reason: collision with root package name */
    public final Object f2965r;

    public m(q qVar, j jVar) {
        this.f2963p = qVar;
        this.f2964q = jVar;
        this.f2965r = new SparseArray();
    }

    public void a() {
        z zVar = (z) this.f2965r;
        if (!this.o) {
            return;
        }
        zVar.c(new G4.d(this, 4));
        this.o = false;
    }

    @Override // x0.q
    public void g() {
        SparseArray sparseArray = (SparseArray) this.f2965r;
        ((q) this.f2963p).g();
        if (this.o) {
            for (int i6 = 0; i6 < sparseArray.size(); i6++) {
                ((o) sparseArray.valueAt(i6)).f2975i = true;
            }
        }
    }

    @Override // x0.q
    public void o(InterfaceC0878A interfaceC0878A) {
        ((q) this.f2963p).o(interfaceC0878A);
    }

    @Override // x0.q
    public G w(int i6, int i7) {
        SparseArray sparseArray = (SparseArray) this.f2965r;
        q qVar = (q) this.f2963p;
        if (i7 != 3) {
            this.o = true;
            return qVar.w(i6, i7);
        }
        o oVar = (o) sparseArray.get(i6);
        if (oVar != null) {
            return oVar;
        }
        o oVar2 = new o(qVar.w(i6, i7), (j) this.f2964q);
        sparseArray.put(i6, oVar2);
        return oVar2;
    }

    public m(Context context, Looper looper, Looper looper2, B b6, x xVar) {
        this.f2963p = context.getApplicationContext();
        this.f2965r = xVar.a(looper, null);
        this.f2964q = new C0169a(this, xVar.a(looper2, null), b6);
    }
}
