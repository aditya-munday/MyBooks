package U0;

import S.C0123p;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* loaded from: classes.dex */
public interface j {

    /* renamed from: c, reason: collision with root package name */
    public static final m3.e f2959c = new m3.e(16);

    l c(C0123p c0123p);

    boolean g(C0123p c0123p);

    int i(C0123p c0123p);
}
