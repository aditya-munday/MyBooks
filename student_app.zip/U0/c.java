package U0;

import java.util.List;
import r0.C0733b;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* loaded from: classes.dex */
public final class c extends Y.g implements d {

    /* renamed from: s, reason: collision with root package name */
    public d f2944s;

    /* renamed from: t, reason: collision with root package name */
    public long f2945t;

    /* renamed from: u, reason: collision with root package name */
    public final /* synthetic */ int f2946u = 1;

    /* renamed from: v, reason: collision with root package name */
    public Object f2947v;

    public /* synthetic */ c() {
    }

    @Override // U0.d
    public final int a(long j6) {
        d dVar = this.f2944s;
        dVar.getClass();
        return dVar.a(j6 - this.f2945t);
    }

    @Override // U0.d
    public final long e(int i6) {
        d dVar = this.f2944s;
        dVar.getClass();
        return dVar.e(i6) + this.f2945t;
    }

    @Override // Y.g
    public final void f() {
        this.f3365p = 0;
        this.f3740q = 0L;
        this.f3741r = false;
        this.f2944s = null;
    }

    @Override // Y.g
    public final void g() {
        switch (this.f2946u) {
            case 0:
                ((C0733b) this.f2947v).m(this);
                return;
            default:
                V0.h hVar = (V0.h) ((B3.h) this.f2947v).f184p;
                hVar.getClass();
                f();
                hVar.f3205b.add(this);
                return;
        }
    }

    @Override // U0.d
    public final List q(long j6) {
        d dVar = this.f2944s;
        dVar.getClass();
        return dVar.q(j6 - this.f2945t);
    }

    @Override // U0.d
    public final int w() {
        d dVar = this.f2944s;
        dVar.getClass();
        return dVar.w();
    }

    public c(C0733b c0733b) {
        this.f2947v = c0733b;
    }
}
