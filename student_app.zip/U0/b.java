package U0;

import E2.C0072q;
import E2.G;
import E2.I;
import E2.X;
import E2.Z;
import V.AbstractC0133a;
import V.C;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* loaded from: classes.dex */
public final class b implements d {

    /* renamed from: q, reason: collision with root package name */
    public static final C0072q f2942q = new C0072q(new T.e(4), X.f719p);
    public final I o;

    /* renamed from: p, reason: collision with root package name */
    public final long[] f2943p;

    /* JADX WARN: Removed duplicated region for block: B:45:0x0105  */
    /* JADX WARN: Removed duplicated region for block: B:48:0x0111 A[SYNTHETIC] */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public b(Z z6) {
        long j6;
        long j7;
        int i6 = z6.f723r;
        long j8 = -9223372036854775807L;
        int i7 = 0;
        if (i6 == 1) {
            G listIterator = z6.listIterator(0);
            Object next = listIterator.next();
            if (!listIterator.hasNext()) {
                a aVar = (a) next;
                long j9 = aVar.f2939b;
                I i8 = aVar.f2938a;
                long j10 = aVar.f2940c;
                if (j9 == -9223372036854775807L) {
                    j7 = 0;
                } else {
                    j7 = j9;
                }
                if (j10 == -9223372036854775807L) {
                    this.o = I.y(i8);
                    this.f2943p = new long[]{j7};
                    return;
                } else {
                    G g2 = I.f699p;
                    this.o = I.z(i8, Z.f721s);
                    this.f2943p = new long[]{j7, j10 + j7};
                    return;
                }
            }
            StringBuilder sb = new StringBuilder("expected one element but was: <");
            sb.append(next);
            while (i7 < 4 && listIterator.hasNext()) {
                sb.append(", ");
                sb.append(listIterator.next());
                i7++;
            }
            if (listIterator.hasNext()) {
                sb.append(", ...");
            }
            sb.append('>');
            throw new IllegalArgumentException(sb.toString());
        }
        long[] jArr = new long[i6 * 2];
        this.f2943p = jArr;
        Arrays.fill(jArr, Long.MAX_VALUE);
        ArrayList arrayList = new ArrayList();
        Z A6 = I.A(f2942q, z6);
        int i9 = 0;
        while (i7 < A6.f723r) {
            a aVar2 = (a) A6.get(i7);
            long j11 = aVar2.f2939b;
            long j12 = aVar2.f2940c;
            I i10 = aVar2.f2938a;
            j11 = j11 == j8 ? 0L : j11;
            long j13 = j11 + j12;
            if (i9 != 0) {
                int i11 = i9 - 1;
                long j14 = this.f2943p[i11];
                if (j14 >= j11) {
                    if (j14 == j11 && ((I) arrayList.get(i11)).isEmpty()) {
                        arrayList.set(i11, i10);
                        j6 = j8;
                    } else {
                        j6 = j8;
                        AbstractC0133a.A("CuesWithTimingSubtitle", "Truncating unsupported overlapping cues.");
                        this.f2943p[i11] = j11;
                        arrayList.set(i11, i10);
                    }
                    if (j12 == j6) {
                        this.f2943p[i9] = j13;
                        arrayList.add(Z.f721s);
                        i9++;
                    }
                    i7++;
                    j8 = j6;
                }
            }
            j6 = j8;
            this.f2943p[i9] = j11;
            arrayList.add(i10);
            i9++;
            if (j12 == j6) {
            }
            i7++;
            j8 = j6;
        }
        this.o = I.u(arrayList);
    }

    @Override // U0.d
    public final int a(long j6) {
        int a6 = C.a(this.f2943p, j6, false);
        if (a6 < this.o.size()) {
            return a6;
        }
        return -1;
    }

    @Override // U0.d
    public final long e(int i6) {
        boolean z6;
        if (i6 < this.o.size()) {
            z6 = true;
        } else {
            z6 = false;
        }
        AbstractC0133a.c(z6);
        return this.f2943p[i6];
    }

    @Override // U0.d
    public final List q(long j6) {
        int e = C.e(this.f2943p, j6, false);
        if (e == -1) {
            G g2 = I.f699p;
            return Z.f721s;
        }
        return (I) this.o.get(e);
    }

    @Override // U0.d
    public final int w() {
        return this.o.size();
    }
}
