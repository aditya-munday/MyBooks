package U0;

import E2.I;
import java.util.List;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* loaded from: classes.dex */
public final class a {

    /* renamed from: a, reason: collision with root package name */
    public final I f2938a;

    /* renamed from: b, reason: collision with root package name */
    public final long f2939b;

    /* renamed from: c, reason: collision with root package name */
    public final long f2940c;

    /* renamed from: d, reason: collision with root package name */
    public final long f2941d;

    public a(long j6, long j7, List list) {
        this.f2938a = I.u(list);
        this.f2939b = j6;
        this.f2940c = j7;
        long j8 = -9223372036854775807L;
        if (j6 != -9223372036854775807L && j7 != -9223372036854775807L) {
            j8 = j6 + j7;
        }
        this.f2941d = j8;
    }
}
