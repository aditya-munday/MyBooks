package U0;

import S.C0122o;
import S.C0123p;
import S.F;
import S.InterfaceC0116i;
import V.AbstractC0133a;
import V.C;
import V.v;
import androidx.datastore.preferences.protobuf.AbstractC0227o;
import java.io.EOFException;
import x0.G;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* loaded from: classes.dex */
public final class o implements G {

    /* renamed from: a, reason: collision with root package name */
    public final G f2968a;

    /* renamed from: b, reason: collision with root package name */
    public final j f2969b;

    /* renamed from: g, reason: collision with root package name */
    public l f2973g;

    /* renamed from: h, reason: collision with root package name */
    public C0123p f2974h;

    /* renamed from: i, reason: collision with root package name */
    public boolean f2975i;

    /* renamed from: d, reason: collision with root package name */
    public int f2971d = 0;
    public int e = 0;

    /* renamed from: f, reason: collision with root package name */
    public byte[] f2972f = C.f3054b;

    /* renamed from: c, reason: collision with root package name */
    public final v f2970c = new v();

    public o(G g2, j jVar) {
        this.f2968a = g2;
        this.f2969b = jVar;
    }

    @Override // x0.G
    public final int a(InterfaceC0116i interfaceC0116i, int i6, boolean z6) {
        if (this.f2973g == null) {
            return this.f2968a.a(interfaceC0116i, i6, z6);
        }
        e(i6);
        int read = interfaceC0116i.read(this.f2972f, this.e, i6);
        if (read == -1) {
            if (z6) {
                return -1;
            }
            throw new EOFException();
        }
        this.e += read;
        return read;
    }

    @Override // x0.G
    public final void b(C0123p c0123p) {
        boolean z6;
        l lVar;
        c0123p.f2626n.getClass();
        String str = c0123p.f2626n;
        if (F.h(str) == 3) {
            z6 = true;
        } else {
            z6 = false;
        }
        AbstractC0133a.c(z6);
        boolean equals = c0123p.equals(this.f2974h);
        j jVar = this.f2969b;
        if (!equals) {
            this.f2974h = c0123p;
            if (jVar.g(c0123p)) {
                lVar = jVar.c(c0123p);
            } else {
                lVar = null;
            }
            this.f2973g = lVar;
        }
        l lVar2 = this.f2973g;
        G g2 = this.f2968a;
        if (lVar2 == null) {
            g2.b(c0123p);
            return;
        }
        C0122o a6 = c0123p.a();
        a6.f2587m = F.n("application/x-media3-cues");
        a6.f2584j = str;
        a6.f2591r = Long.MAX_VALUE;
        a6.K = jVar.i(c0123p);
        AbstractC0227o.l(a6, g2);
    }

    @Override // x0.G
    public final void c(long j6, int i6, int i7, int i8, x0.F f6) {
        boolean z6;
        if (this.f2973g == null) {
            this.f2968a.c(j6, i6, i7, i8, f6);
            return;
        }
        if (f6 == null) {
            z6 = true;
        } else {
            z6 = false;
        }
        AbstractC0133a.b("DRM on subtitles is not supported", z6);
        int i9 = (this.e - i8) - i7;
        try {
            this.f2973g.j(this.f2972f, i9, i7, k.f2960c, new n(this, j6, i6));
        } catch (RuntimeException e) {
            if (this.f2975i) {
                AbstractC0133a.B("SubtitleTranscodingTO", "Parsing subtitles failed, ignoring sample.", e);
            } else {
                throw e;
            }
        }
        int i10 = i9 + i7;
        this.f2971d = i10;
        if (i10 == this.e) {
            this.f2971d = 0;
            this.e = 0;
        }
    }

    @Override // x0.G
    public final void d(v vVar, int i6, int i7) {
        if (this.f2973g == null) {
            this.f2968a.d(vVar, i6, i7);
            return;
        }
        e(i6);
        vVar.i(this.f2972f, this.e, i6);
        this.e += i6;
    }

    public final void e(int i6) {
        byte[] bArr;
        int length = this.f2972f.length;
        int i7 = this.e;
        if (length - i7 >= i6) {
            return;
        }
        int i8 = i7 - this.f2971d;
        int max = Math.max(i8 * 2, i6 + i8);
        byte[] bArr2 = this.f2972f;
        if (max <= bArr2.length) {
            bArr = bArr2;
        } else {
            bArr = new byte[max];
        }
        System.arraycopy(bArr2, this.f2971d, bArr, 0, i8);
        this.f2971d = 0;
        this.e = i8;
        this.f2972f = bArr;
    }
}
