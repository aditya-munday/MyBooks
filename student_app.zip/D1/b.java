package D1;

import android.util.Log;
import android.view.Surface;
import app.rive.rive_native.RiveNativePluginKt;
import io.flutter.view.TextureRegistry$SurfaceProducer;
import io.flutter.view.n;
import q5.h;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* loaded from: classes.dex */
public final class b implements n {

    /* renamed from: b, reason: collision with root package name */
    public final TextureRegistry$SurfaceProducer f612b;

    /* renamed from: c, reason: collision with root package name */
    public Surface f613c;

    /* renamed from: d, reason: collision with root package name */
    public long f614d;

    public b(TextureRegistry$SurfaceProducer textureRegistry$SurfaceProducer, int i6, int i7) {
        this.f612b = textureRegistry$SurfaceProducer;
        textureRegistry$SurfaceProducer.setSize(i6, i7);
        textureRegistry$SurfaceProducer.setCallback(this);
        Surface surface = textureRegistry$SurfaceProducer.getSurface();
        h.d(surface, "getSurface(...)");
        this.f613c = surface;
        this.f614d = RiveNativePluginKt.createRiveRenderer(surface, i6, i7);
    }

    @Override // io.flutter.view.n
    public final void a() {
        synchronized (this) {
            long j6 = this.f614d;
            if (j6 != 0) {
                RiveNativePluginKt.markDestroyedRiveRenderer(j6);
            }
        }
        Surface surface = this.f612b.getSurface();
        h.d(surface, "getSurface(...)");
        this.f613c = surface;
    }

    @Override // io.flutter.view.n
    public final void b() {
        synchronized (this) {
            long j6 = this.f614d;
            if (j6 != 0) {
                RiveNativePluginKt.markDestroyedRiveRenderer(j6);
            }
        }
    }

    public final void c() {
        synchronized (this) {
            long j6 = this.f614d;
            if (j6 != 0) {
                RiveNativePluginKt.destroyRiveRenderer(j6);
                this.f614d = 0L;
            }
            try {
                this.f613c.release();
                this.f612b.release();
            } catch (Exception e) {
                Log.w("RiveNativePlugin", "release: error releasing surface: " + e);
            }
        }
    }
}
