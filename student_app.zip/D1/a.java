package D1;

import M4.m;
import M4.n;
import M4.o;
import M4.p;
import android.util.Log;
import g5.C0454c;
import io.flutter.embedding.engine.renderer.j;
import io.flutter.view.TextureRegistry$SurfaceProducer;
import java.util.Collections;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map;
import q5.h;
import s4.AbstractC0760a;

/* compiled from: r8-map-id-588b4a2f2e29ac3209aabccae086cd8511f292417566a657287f76a773ccd590 */
/* loaded from: classes.dex */
public final class a implements I4.b, n {
    public p o;

    /* renamed from: p, reason: collision with root package name */
    public j f610p;

    /* renamed from: q, reason: collision with root package name */
    public final LinkedHashMap f611q = new LinkedHashMap();

    static {
        System.loadLibrary("rive_native");
    }

    @Override // I4.b
    public final void onAttachedToEngine(I4.a aVar) {
        h.e(aVar, "flutterPluginBinding");
        p pVar = new p(aVar.f1091b, "rive_native");
        this.o = pVar;
        pVar.b(this);
        j jVar = aVar.f1092c;
        h.d(jVar, "getTextureRegistry(...)");
        this.f610p = jVar;
    }

    @Override // I4.b
    public final void onDetachedFromEngine(I4.a aVar) {
        h.e(aVar, "binding");
        LinkedHashMap linkedHashMap = this.f611q;
        Iterator it = linkedHashMap.values().iterator();
        while (it.hasNext()) {
            ((b) it.next()).c();
        }
        linkedHashMap.clear();
        p pVar = this.o;
        if (pVar != null) {
            pVar.b(null);
        } else {
            h.h("channel");
            throw null;
        }
    }

    @Override // M4.n
    public final void onMethodCall(m mVar, o oVar) {
        Long l6;
        h.e(mVar, "call");
        String str = mVar.f1733a;
        int hashCode = str.hashCode();
        if (hashCode != -1057393789) {
            LinkedHashMap linkedHashMap = this.f611q;
            if (hashCode != -222324745) {
                if (hashCode == 828700799 && str.equals("createTexture")) {
                    Integer num = (Integer) mVar.a("width");
                    Integer num2 = (Integer) mVar.a("height");
                    if (num != null && num2 != null) {
                        j jVar = this.f610p;
                        if (jVar != null) {
                            TextureRegistry$SurfaceProducer d6 = jVar.d(1);
                            b bVar = new b(d6, num.intValue(), num2.intValue());
                            linkedHashMap.put(Long.valueOf(d6.id()), bVar);
                            C0454c c0454c = new C0454c("textureId", Long.valueOf(d6.id()));
                            long j6 = bVar.f614d;
                            AbstractC0760a.a(16);
                            String l7 = Long.toString(j6, 16);
                            h.d(l7, "toString(...)");
                            C0454c[] c0454cArr = {c0454c, new C0454c("renderer", l7)};
                            LinkedHashMap linkedHashMap2 = new LinkedHashMap(h5.p.V(2));
                            h5.p.W(linkedHashMap2, c0454cArr);
                            ((L4.j) oVar).b(linkedHashMap2);
                            return;
                        }
                        h.h("textureRegistry");
                        throw null;
                    }
                    ((L4.j) oVar).d("CreateTexture Error", "Width and height are required", null);
                    return;
                }
            } else if (str.equals("removeTexture")) {
                if (((Integer) mVar.a("id")) != null) {
                    l6 = Long.valueOf(r7.intValue());
                } else {
                    l6 = null;
                }
                if (l6 == null) {
                    ((L4.j) oVar).d("removeTexture Error", "Texture ID is required", null);
                    return;
                }
                b bVar2 = (b) linkedHashMap.get(l6);
                if (bVar2 != null) {
                    bVar2.c();
                    linkedHashMap.remove(l6);
                    ((L4.j) oVar).b(null);
                    return;
                } else {
                    Log.e("RiveNativePlugin", "removeTexture: texture " + l6 + " not found");
                    ((L4.j) oVar).d("removeTexture Error", "Texture not found", null);
                    return;
                }
            }
        } else if (str.equals("getRenderContext")) {
            Map singletonMap = Collections.singletonMap("rendererContext", "android");
            h.d(singletonMap, "singletonMap(...)");
            ((L4.j) oVar).b(singletonMap);
            return;
        }
        ((L4.j) oVar).c();
    }
}
